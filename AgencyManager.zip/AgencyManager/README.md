# Centiva am gke

## About

Replace this text with a description of your application or service.

## Contents

### Files

* `BUILD` - Bazel file containing build and test targets for CI (using Bazel as
  a wrapper for "mvn") and SABRE2 service definition

* `CODEOWNERS.sabre` - list of code owners for this directory, if applicable

* `Dockerfile` - instructions for container build on GKE

* `Makefile`

* `pom.xml` - project-level POM file for Java service

* `.prompts.json` -  recorded generation options  used to generate service

### Directories

* `acceptance-tests` - automated acceptance tests

* `configuration` - "infrastructure as code" for automated deployment\
  inherited from `//templates/gke_deployment_configs/bg-5.x`

* `service/main` - Java application

* `service/test` - automated unit tests

## Setup

Add the ngp-test-toolkit path to the checkout set

```bash
s2 get testing/bom
```

Follow applicable steps in the [NGP Getting
Started](http://ngp.sabre.com/tech-docs/Guides/chunks/getting_started.html) guide.

## How to build

```bash
# from this directory
mvn clean install -pl service -am -DskipTests
```

### Using make

```bash
# to show available build options
make

# regular build
make build

# build on SABRE2 Jenkins server
make build-ci
```

## How to run

```bash
# using mvn
mvn spring-boot:run

# using Make
make run
```

## How to test

```bash
# using mvn
mvn test

# using make
make test

# run acceptance tests against the app running in another terminal with defaults
make acceptance

# or...
mvn test -pl acceptance-tests -P acceptance-tests

# run acceptance tests against the app running in another terminal with custom framework args
tags=<CUKE_TAG_TO_BE_EXECUTED> \
  product=<UAP_PRODUCT> \
  environment=<SABRE_ENV> \
  uapZone=<UAP_ZONE_WHERE_REPORTS_DUMPED> \
  releaseId=<UAP_REPORTING_RELEASEID> \
  liveReporting=true \
  productArea=<UAP_REPORTING_PRODUCT_AREA> \
  threadCount=<NUMERIC_VALUE_TO_SPAWN_CUKE_TESTS_IN_PARALLEL> \
  mvn test -pl acceptance-tests -P acceptance-tests

# e.g. command
tags=@acceptance \
  product=Config_Management \
  test_env=environment=DEV \
  uapZone=Green \
  releaseId=Config_Management_Sandbox \
  liveReporting=true \
  productArea=Reservations \
  threadCount=5 \
  mvn test -pl acceptance-tests -P acceptance-tests
```

## Performance tests

Basic short performance tests (~5min) are executed via external Jenkins.
You can find configuration file under this path: configuration/files/plab/short-request.json.
You can find more details in [Sabre2 Dev Handbook](http://gitdocs.sabre.com/gitdocs/developer-handbook/prod/sabre2/ci_cd.html#_short_performance_tests).

## How to validate service metadata

```bash
# using Bazel
bazel build :centiva-am-gke

# using Make
make build-service
```

## How to verify service will build with CI

```bash
# run these commands after making any changes to the BUILD file
bazel build :service
bazel test :unit_tests
```

## How to run SonarQube analysis (only applicable to GCP)

There is a `sonarqube` rule in generated `BUILD` file with
`project_key` and `project_name` attributes.
Those attributes need to be created through a service request.
Please refer to our [SonarQube Documentation](http://gitdocs.sabre.com/gitdocs/developer-handbook/prod/sabre2/ci_cd.html#_sonarqube).
Other scan options should be set in project pom.xml files
acording to sonrcube documentation. Once you fill out the `project_key`,
`project_name`, uncomment the `sonarqube_target` in the `service` rule.
The SonarQube analysis will be performed during the build process on the
SABRE2 Jenkins server.
Please note that Sonar Analysis is only performed on master and PR builds at present.

You can also trigger the SonarQube analysis locally.
Please refer to our [SonarQube Documentation](http://gitdocs.sabre.com/gitdocs/developer-handbook/prod/sabre2/ci_cd.html#_sonarqube).

## How to deploy locally (only applicable to GCP)

```bash
# using make
make deploy-local
```

## Other interaction with Armada

```bash
# Open application in Armada
make open-in-armada
```

Does not work in S2E. Click URL printed by command and copy/paste it into browser.

## How to contribute

Replace this text with any special rules or instructions for contributing to
this application.

## Known issues

None

## References
