package com.sabre.centivaamgke.validators;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SaleDocumentValidator {
  public void validate() {
    log.info("SaleDocumentValidator :");
  }
}
