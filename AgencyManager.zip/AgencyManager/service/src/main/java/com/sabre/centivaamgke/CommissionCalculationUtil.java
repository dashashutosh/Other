package com.sabre.centivaamgke;

public class CommissionCalculationUtil {}
