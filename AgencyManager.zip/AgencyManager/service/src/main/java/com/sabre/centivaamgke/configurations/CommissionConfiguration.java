package com.sabre.centivaamgke.configurations;

public class CommissionConfiguration {}
