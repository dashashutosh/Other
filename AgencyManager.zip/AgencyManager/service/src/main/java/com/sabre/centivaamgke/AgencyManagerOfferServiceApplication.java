package com.sabre.centivaamgke;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgencyManagerOfferServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(AgencyManagerOfferServiceApplication.class, args);
  }
}
