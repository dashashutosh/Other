# `/configuration/vars` directory

`/configuration/vars` directory contains deployment variables for each target
environment and common variables that serve as defaults.

It contains:

* `env/service-specific.yaml` - variables with defaults for all deployment environments.
  This file requires customization for each new app/service.

* `env/<environment>` -  Default configuration is used from '//templates/gke_deployment_configs/bg-5.x`'.

Default envs are defined `templates/gke_deployment_configs/bg-5.x`\
in common template along with configuration,
if you want to override certain configuration of an environment\
you can create under /configuration/vars/app folder.
