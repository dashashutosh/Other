package com.sabre.centivaamgke.stepdefs;

import com.sabre.centivaamgke.helpers.ServiceHelper;
import com.sabre.centivaamgke.state.TestContext;
import com.sabre.nsq.lite.services.base.AssertionService;
import com.sabre.nsq.lite.services.base.JsonService;
import com.sabre.nsq.lite.services.base.RestAssuredService;
import com.sabre.nsq.lite.services.base.SubstitutorService;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.hamcrest.CoreMatchers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GenericApplicationApiStepDef {

  private TestContext testContext;
  private RestAssuredService restAssuredService;
  private AssertionService assertionService;
  private JsonService jsonService;
  private SubstitutorService substitutorService;
  private ServiceHelper serviceHelper;

  Logger LOGGER = LoggerFactory.getLogger(this.getClass());

  public GenericApplicationApiStepDef(TestContext testContext) {
    this.testContext = testContext;
    this.restAssuredService = testContext.getRestAssuredService();
    this.assertionService = testContext.getAssertionService();
    this.jsonService = testContext.getJsonService();
    this.substitutorService = testContext.getSubstitutorService();
    this.serviceHelper = new ServiceHelper(testContext);
  }

  @Given("user performs get request for path {string}")
  public void userPerformsGetRequestForPath(String path) {
    String serviceEndpoint = serviceHelper.getServiceUrl() + path;
    Response response = restAssuredService.getRequest(serviceEndpoint);
    testContext.setResponse(response);
  }

  @Then("verify status code is {int}")
  public void verifyStatusCodeIs(int expected) {
    Response response = testContext.getResponse();
    assertionService.assertThat(
        "Verify Status Code matches", response.getStatusCode(), CoreMatchers.is(expected));
  }

  @Then("verify response is {string}")
  public void verifyResponseIs(String expectedResponse) {
    Response response = testContext.getResponse();
    assertionService.assertThat(
        "Verify Response body matches",
        response.getBody().asString(),
        CoreMatchers.is(expectedResponse));
  }
}
