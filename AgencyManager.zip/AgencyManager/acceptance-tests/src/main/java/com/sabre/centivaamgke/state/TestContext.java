package com.sabre.centivaamgke.state;

import com.sabre.nsq.lite.model.lite.global.LiteGlobal;
import com.sabre.nsq.lite.services.base.AssertionService;
import com.sabre.nsq.lite.services.base.BrowserService;
import com.sabre.nsq.lite.services.base.JsonService;
import com.sabre.nsq.lite.services.base.RestAssuredService;
import com.sabre.nsq.lite.services.base.SubstitutorService;
import io.restassured.response.Response;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Data
public class TestContext {
  private static final Logger LOGGER = LoggerFactory.getLogger(TestContext.class);

  private LiteGlobal global;
  private JsonService jsonService;
  private SubstitutorService substitutorService;
  private RestAssuredService restAssuredService;
  private BrowserService browserService;
  private AssertionService assertionService;
  private Response response;

  public TestContext() {
    global = new LiteGlobal();
    browserService = new BrowserService();
    restAssuredService = new RestAssuredService();
    assertionService = new AssertionService();
    jsonService = new JsonService();
    substitutorService = new SubstitutorService();
  }
}
