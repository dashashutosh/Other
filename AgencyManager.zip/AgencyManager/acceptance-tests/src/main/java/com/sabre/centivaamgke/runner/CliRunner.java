package com.sabre.centivaamgke.runner;

import io.cucumber.core.cli.Main;
import java.util.Optional;

public class CliRunner {

  public static void main(String[] args) {
    String tags = Optional.ofNullable(System.getenv("tags")).orElse("@acceptance");
    String threadCount = Optional.ofNullable(System.getenv("threadCount")).orElse("1");
    String productArea =
        Optional.ofNullable(System.getenv("productArea")).orElse("HelloWorldProductArea");
    String product = Optional.ofNullable(System.getenv("product")).orElse("HelloWorldProduct");
    String releaseId =
        Optional.ofNullable(System.getenv("releaseId")).orElse("HelloWorldReleaseID");
    String uapZone = Optional.ofNullable(System.getenv("uapZone")).orElse("Green");
    String livereporting = Optional.ofNullable(System.getenv("livereporting")).orElse("true");
    String environment = Optional.ofNullable(System.getenv("environment")).orElse("DEV");
    //    String rallyIntegration =
    // Optional.ofNullable(System.getenv("rallyIntegration")).orElse("false");
    System.setProperty("productArea", productArea);
    System.setProperty("product", product);
    System.setProperty("releaseId", releaseId);
    System.setProperty("uapZone", uapZone);
    System.setProperty("livereporting", livereporting);
    //    System.setProperty("rallyIntegration", rallyIntegration);
    System.setProperty("environment", environment);

    // Pass cucumber cmd line
    Main.main(
        "-g",
        "com.sabre.centivaamgke.stepdefs",
        "-g",
        "com.sabre.centivaamgke.events",
        "-g",
        "com.sabre.nsq",
        "-p",
        "com.sabre.nsq.lite.cucumber.events.CustomFormatter",
        "classpath:features",
        "--tags",
        tags,
        "--threads",
        threadCount);
  }
}
