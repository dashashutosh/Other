package com.sabre.centivaamgke.helpers;

import com.sabre.centivaamgke.state.TestContext;
import com.sabre.nsq.lite.services.base.SubstitutorService;
import org.apache.commons.lang3.StringUtils;

public class ServiceHelper {
  private final TestContext testContext;
  private final SubstitutorService substitutorService;

  private static final String INT = "int";
  private static final String DEV = "dev";

  public ServiceHelper(TestContext testContext) {
    this.testContext = testContext;
    this.substitutorService = testContext.getSubstitutorService();
  }

  public String getServiceUrl() {
    String projectName = System.getProperty("ngp.project.name");
    String serviceName = System.getProperty("ngp.service.name");
    String servicePort = System.getProperty("ngp.service.port");
    String host = System.getProperty("host");
    String testURL = System.getProperty("ngp.test.serviceUrl");

    if (servicePort == null) servicePort = "8080";

    if (host == null) {
      host =
          !StringUtils.isBlank(projectName)
              ? serviceName + "." + projectName + ".svc"
              : "localhost";
    }

    return testURL != null ? testURL : "http://" + host + ":" + servicePort;
  }
}
