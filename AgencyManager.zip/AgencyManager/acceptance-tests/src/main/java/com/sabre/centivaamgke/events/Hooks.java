package com.sabre.centivaamgke.events;

import com.sabre.centivaamgke.state.TestContext;
import com.sabre.nsq.lite.model.lite.global.LiteGlobal;
import com.sabre.nsq.lite.services.base.SubstitutorService;
import com.sabre.reporting.logger.Reporting;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {
  private TestContext testContext;
  private SubstitutorService substitutorService;
  private LiteGlobal global;
  private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(Hooks.class);

  public Hooks(TestContext testContext) {
    this.testContext = testContext;
    this.substitutorService = testContext.getSubstitutorService();
    this.global = testContext.getGlobal();
  }

  @Before(order = 1)
  public void cucumberSetUp() {}

  @After(order = 1)
  public void cucumberTearDown(Scenario scenario) {
    try {
      if (System.getProperty("livereporting").equalsIgnoreCase("true")) {
        Reporting.getLogger().publishJson();
      }
    } catch (Exception e) {
      // Not fail the build stage in NGP if live reporting fails due to some unexpected issue
      LOGGER.error("Failed to dump report to UAP for scenario : " + scenario.getName());
      e.printStackTrace();
    }
  }
}
