package com.sabre.centivaamgke.runner;

import com.sabre.nsq.lite.cucumber.runner.BaseTestRunner;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

@CucumberOptions(
    features = {"classpath:features"},
    glue = {"com.sabre.centivaamgke.stepdefs", "com.sabre.centivaamgke.events"},
    tags = "@acceptance")
public class TestRunner extends BaseTestRunner {

  @Parameters({
    "sprintId",
    "env",
    "productArea",
    "product",
    "component",
    "cucumber.options",
    "uapZone",
    "jenkinsBuild",
    "sonarQubeUri",
    "livereporting",
    "phase",
    "rallyIntegration",
    "enableWiremockServer",
    "jenkinsJobName"
  })
  @BeforeTest(alwaysRun = true)
  public void setUpTest(
      @Optional("Cucumber_Sandbox") String sprintId,
      @Optional("DEV") String env,
      @Optional("Test") String productArea,
      @Optional("Test") String product,
      @Optional("") String component,
      @Optional("") String tags,
      @Optional("Green") String uapZone,
      @Optional("1.1.0-969-gc8ca18a") String jenkinsBuild,
      @Optional("https://sonarqube-ngp-cicd.apps.ocusw2.scs.dev.ascint.sabrecirrus.com/api/")
          String sonarQubeUri,
      @Optional("true") String livereporting,
      @Optional("CI") String phase,
      @Optional("false") String rallyIntegration,
      @Optional("false") String enableWiremockServer,
      @Optional("Starter_Kit_Run") String jenkinsJobName) {
    reportingMetaData.setProductArea(productArea);
    reportingMetaData.setProduct(product);
    reportingMetaData.setSprintId(sprintId);
    reportingMetaData.setComponent(component);
    reportingMetaData.setUapZone(uapZone);
    reportingMetaData.setJenkinsBuild(jenkinsBuild);
    reportingMetaData.setSonarQubeUri(sonarQubeUri);
    reportingMetaData.setLivereporting(livereporting);
    reportingMetaData.setPhase(phase);
    reportingMetaData.setRallyIntegration(rallyIntegration);
    reportingMetaData.setEnableWiremockServer(enableWiremockServer);
    reportingMetaData.setJenkinsJob(jenkinsJobName);
    reportingMetaData.setEnv(env);
  }
}
