package com.walmart.dms.service;

import com.walmart.platform.metrics.spring.CountedAnnotationBeanPostProcessor;
import com.walmart.platform.metrics.spring.ExceptionCountedAnnotationBeanPostProcessor;
import com.walmart.platform.metrics.spring.TimedAnnotationBeanPostProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Created by n0a008p on 08/03/18.
 */
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class,
		MongoAutoConfiguration.class, MongoDataAutoConfiguration.class})
@EnableScheduling
@Slf4j
@EnableRetry
@PropertySource({"classpath:/${runtime.context.environment}/application.properties"})
@ComponentScan(basePackages = {"com.walmart.dms.service", "com.walmart.dms.common", "com.walmart.dms.biz",
		"com.walmart.dms.server.common", "com.walmart.dms.scheduler", "com.walmart.dms.common.elasticsearch",
		"com.walmart.dms.suggestion", "com.walmart.platform.metrics.spring"})
@ServletComponentScan(basePackages = {"io.strati.ecv.servlet", "io.strati.ecv.listeners"})
public class DMSApplication {

	public static void main(String[] args) {

		try {
// 			System.setProperty("javax.net.ssl.trustStore", "truststore.jks");
// 			System.setProperty("javax.net.ssl.trustStorePassword", "storepass");

			System.out.println("######### DMSApplication starting... #########");
			log.info("DMSApplication app loaded started");
			SpringApplication.run(DMSApplication.class, args);
			log.info("DMSApplication app loaded successfully");
			System.out.println("######### DMSApplication successfully started #########");
		} catch (Exception e) {
			log.error("DMSApplication Error loading boot app", e);
			e.printStackTrace();
		}

	}


}
