cpid=`ps -ef | grep "dms-service" | grep -v 'grep' | awk '{print $2}'`;

count=`echo $cpid | wc -w`;

echo "Total No Of Instances For DMS-Service " $count;

for pid in $cpid;

do

        kill -9 $pid;

        echo "Process Terminated: " $pid;

done
