package com.walmart.dms.dal;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.walmart.dms.dal.jpa.entity.DriverEntity;
import com.walmart.dms.dal.jpa.entity.key.DriverEntityPK;

import java.util.concurrent.TimeUnit;

public class DriverEntityCache {

    private final LoadingCache<DriverEntityPK, DriverEntity> driverEntityCache;

    public DriverEntityCache() {
        driverEntityCache = CacheBuilder.newBuilder()
                .maximumSize(100)                             // maximum 100 records can be cached
                .expireAfterAccess(30, TimeUnit.MINUTES)      // cache will expire after 30 minutes of access
                .build(new CacheLoader<DriverEntityPK, DriverEntity>() {  // build the cacheloader

                    @Override
                    public DriverEntity load(final DriverEntityPK driverEntityPK) throws Exception {
                        //make the expensive call
                        return getDriverEntityFromDB(driverEntityPK);
                    }
                });
    }

    private DriverEntity getDriverEntityFromDB(final DriverEntityPK driverEntityPK) {
        return null;
    }


}
