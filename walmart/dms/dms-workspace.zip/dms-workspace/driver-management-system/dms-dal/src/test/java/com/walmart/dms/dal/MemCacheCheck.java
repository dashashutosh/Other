package com.walmart.dms.dal;

import net.spy.memcached.MemcachedClient;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Future;

public class MemCacheCheck {

    private final MemcachedClient memcachedClient;

    private MemCacheCheck() throws IOException {
        final InetSocketAddress add = new InetSocketAddress("localhost", 8000);
        memcachedClient = new MemcachedClient(add);
    }

    public static void main(final String[] args) {
        try {
            final MemCacheCheck cacheTest = new MemCacheCheck();
            cacheTest.test1();
        } catch (final IOException e) {
            e.printStackTrace();
        }
    }

    private void test1() {

        final String key = "name";
        final String value = "Minal";

        final Future<Boolean> future = memcachedClient.set(key, 10, value);

        final String fetchedValue = (String) memcachedClient.get("name1");

        Assert.assertEquals(value, fetchedValue);
    }
}
