package com.walmart.dms.dal;

import com.walmart.dms.common.enums.Tenant;
import com.walmart.dms.common.enums.Vertical;
import com.walmart.dms.common.utils.HeaderDTO;
import com.walmart.dms.dal.jpa.entity.DriverFeedbackCauseEntity;
import com.walmart.dms.dal.jpa.repository.DriverFeedbackCauseEntityRepository;
import com.walmart.dms.dal.jpa.service.DriverFeedbackCauseDALService;
import com.walmart.dms.server.common.exception.DataAccessException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DriverFeedbackCauseDALServiceTest {
    
    @Mock
    private DriverFeedbackCauseEntityRepository repository;

    @InjectMocks
    private DriverFeedbackCauseDALService dalService;
    
    protected HeaderDTO getUSHeaderDTO() {
        final HeaderDTO dto = new HeaderDTO(Tenant.US.getTenantId(), Vertical.GROCERIES.getVerticalId());
        return dto;
    }
    
    @Test
    public void testGetCauseByLangCodeAndTenantId() throws DataAccessException {
        final List<DriverFeedbackCauseEntity> entities = new ArrayList<>();
        
        DriverFeedbackCauseEntity entity = new DriverFeedbackCauseEntity();
        entity.setId("C101");
        entity.setCause("APP");
        entities.add(entity);
        
        entity = new DriverFeedbackCauseEntity();
        entity.setId("C102");
        entity.setCause("CUSTOMER");
        entities.add(entity);
        
        doReturn(entities).when(repository).findByLanguageCodeAndTenantId(any(), any());
        
        final List<DriverFeedbackCauseEntity> returnedEntities = dalService.getDriverFeedbackCauseByLanguageCodeAndTenantId("en-US", getUSHeaderDTO());
        assertEquals(entities.get(0), returnedEntities.get(0));
        assertEquals(entities.get(1), returnedEntities.get(1));
    }
    
    @Test(expected=DataAccessException.class)
    public void testExceptionInGetCauseByLangCodeAndTenantId() throws DataAccessException {
        final List<DriverFeedbackCauseEntity> entities = new ArrayList<>();
        
        DriverFeedbackCauseEntity entity = new DriverFeedbackCauseEntity();
        entity.setId("C101");
        entity.setCause("APP");
        entities.add(entity);
        
        entity = new DriverFeedbackCauseEntity();
        entity.setId("C102");
        entity.setCause("CUSTOMER");
        entities.add(entity);
        
        doReturn(entities).when(repository).findByLanguageCodeAndTenantId(any(), any());
        
        dalService.getDriverFeedbackCauseByLanguageCodeAndTenantId(null, getUSHeaderDTO());
    }
    
    @Test
    public void testGetCauseById() throws DataAccessException {
        final DriverFeedbackCauseEntity entity = new DriverFeedbackCauseEntity();
        entity.setId("C101");
        entity.setCause("APP");

        doReturn(Optional.of(entity)).when(repository).findById(any());

        final DriverFeedbackCauseEntity returnedEntity = dalService.getDriverFeedbackCauseById("C101", getUSHeaderDTO());
        assertEquals(entity, returnedEntity);
    }
}
