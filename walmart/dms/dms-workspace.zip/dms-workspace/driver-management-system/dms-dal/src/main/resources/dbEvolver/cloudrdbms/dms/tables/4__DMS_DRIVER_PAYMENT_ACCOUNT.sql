--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset sdhaka:dms.DMS_DRIVER_PAYMENT_ACCOUNT_1_0_0 dbms:mysql
CREATE TABLE `DMS_DRIVER_PAYMENT_ACCOUNT` (
  `DRIVER_PAYMENT_ACCOUNT_ID` varchar(50) NOT NULL,
  `DRIVER_USER_ID` varchar(255) NOT NULL,
  `STATUS` varchar(255) NOT NULL,
  `PAYMENT_PROVIDER` varchar(255) NOT NULL,
  `REGISTRATION_LINK` varchar(255) DEFAULT NULL,
  `TENANT_ID` varchar(50) NOT NULL,
  `IS_ACTIVE` boolean NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  PRIMARY KEY (`DRIVER_PAYMENT_ACCOUNT_ID`),
  UNIQUE KEY `UK_driverUserIdPaymentProvider` (`DRIVER_USER_ID`,`TENANT_ID`,`PAYMENT_PROVIDER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE INDEX PAYMENT_STATUS_INDEX ON DMS_DRIVER_PAYMENT_ACCOUNT (STATUS);
CREATE INDEX PAYMENT_USRID_ACTIVE_INDEX ON DMS_DRIVER_PAYMENT_ACCOUNT (DRIVER_USER_ID,IS_ACTIVE);

