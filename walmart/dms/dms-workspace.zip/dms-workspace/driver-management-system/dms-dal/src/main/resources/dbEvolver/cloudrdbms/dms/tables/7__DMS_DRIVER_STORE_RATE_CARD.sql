--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)
-
--
--changeset sdhaka:dms.DMS_DRIVER_STORE_RATE_CARD_1_0_0 dbms:mysql
CREATE TABLE `DMS_DRIVER_STORE_RATE_CARD` (
  `DMS_DRIVER_STORE_RATE_CARD_PK` varchar(50) NOT NULL,
  `STORE_ID` varchar(50) NOT NULL,
  `PAYMENT_MODEL` varchar(255) NOT NULL,
  `PAYMENT_MODEL_RATE` DOUBLE NOT NULL,
  `IS_ACTIVE` boolean NOT NULL,
  `PAYMENT_MODEL_SLOT` varchar(255) DEFAULT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  PRIMARY KEY (`DMS_DRIVER_STORE_RATE_CARD_PK`),
  UNIQUE KEY `UK_storeIdPayModel` (`STORE_ID`,`PAYMENT_MODEL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE INDEX DRSTRACARD_SRID_ACT_INDEX ON DMS_DRIVER_STORE_RATE_CARD(STORE_ID,IS_ACTIVE);

--changeset sdhaka:dms.DMS_DRIVER_STORE_RATE_CARD_2_0_0 dbms:mysql

DROP TABLE DMS_DRIVER_STORE_RATE_CARD;