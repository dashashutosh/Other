--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset k0a009k:dms.DMS_DRIVER_AVAILABILITY_STATUS_AUDIT_1_0_0 dbms:mysql
CREATE TABLE `DMS_VENDOR_TIP_EVENT` (
  `DMS_VENDOR_TIP_EVENT_ID` varchar(255) NOT NULL,
  `ORDER_ID` varchar(255) NOT NULL,
  `TRANSACTION_AMOUNT` double NOT NULL,
  `TRANSACTION_STATUS` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) NOT NULL,
  `DB_LOCK_VERSION` int(11) DEFAULT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `CARRIER` varchar(255) NOT NULL,
  `SERVICE_PROVIDER` varchar(255) NOT NULL,
  PRIMARY KEY (`DMS_VENDOR_TIP_EVENT_ID`),
  UNIQUE KEY `UK_DmsDriverPaymentCspTip` (`ORDER_ID`),
  UNIQUE KEY `UK340mkl4v7ad24d3qbn4rxw147` (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `DMS_VENDOR_PAYMENT_TRANSACTION` (
  `DMS_VENDOR_PAYMENT_TRANSACTION_ID` varchar(255) NOT NULL,
  `ORDER_ID` varchar(255) NOT NULL,
  `DELIVERY_ID` varchar(255) NOT NULL,
  `TIP_AMOUNT` double NOT NULL,
  `ERROR_REASON` varchar(255) DEFAULT NULL,
  `TRANSACTION_STATUS` varchar(255) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  PRIMARY KEY (`DMS_VENDOR_PAYMENT_TRANSACTION_ID`),
  UNIQUE KEY `UKDmsVendorTipEventOrderIdDeliveryId` (`ORDER_ID`,`DELIVERY_ID`),
  CONSTRAINT `FKDmsVendorTipEventOrderId` FOREIGN KEY (`ORDER_ID`) REFERENCES `DMS_VENDOR_TIP_EVENT` (`ORDER_ID`),
  CONSTRAINT `FKnpr1jx2ljlb6tvm46kg9hvydo` FOREIGN KEY (`ORDER_ID`) REFERENCES `DMS_VENDOR_TIP_EVENT` (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--changeset k0a009k:dms.DMS_DRIVER_AVAILABILITY_STATUS_AUDIT_2_0_0 dbms:mysql

ALTER TABLE `DMS_VENDOR_TIP_EVENT` DROP INDEX `UK340mkl4v7ad24d3qbn4rxw147`;
ALTER TABLE `DMS_VENDOR_PAYMENT_TRANSACTION` DROP FOREIGN KEY `FKnpr1jx2ljlb6tvm46kg9hvydo`;

--changeset k0a009k:dms.DMS_DRIVER_AVAILABILITY_STATUS_AUDIT_3_0_0 dbms:mysql

ALTER TABLE `DMS_VENDOR_TIP_EVENT` CHANGE `TRANSACTION_STATUS` `TIP_STATUS` varchar(255) DEFAULT NULL;
ALTER TABLE `DMS_VENDOR_TIP_EVENT` ADD COLUMN `STORE_ID` varchar(255) NOT NULL;
ALTER TABLE `DMS_VENDOR_TIP_EVENT` CHANGE `TRANSACTION_AMOUNT` `TIP_AMOUNT` double NOT NULL;
ALTER TABLE `DMS_VENDOR_TIP_EVENT` DROP COLUMN `TRANSACTION_TYPE`;
ALTER TABLE `DMS_VENDOR_PAYMENT_TRANSACTION` CHANGE `TIP_AMOUNT` `TRANSACTION_AMOUNT` double NOT NULL;
ALTER TABLE `DMS_VENDOR_PAYMENT_TRANSACTION` ADD COLUMN `TRANSACTION_TYPE` varchar(255) NOT NULL;

--changeset nsc001m:dms.DMS_VENDOR_TIP_EVENT_4_0_0 dbms:mysql
ALTER TABLE `DMS_VENDOR_TIP_EVENT` ADD COLUMN `ERROR_REASON` varchar(255);

--changeset n0k008c:dms.DMS_VENDOR_TIP_EVENT_5_0_0 dbms:mysql
CREATE INDEX DMS_VENDOR_CREATED_TIME_TIP_STATUS_INDEX ON DMS_VENDOR_TIP_EVENT (CREATED_TIME, TIP_STATUS);