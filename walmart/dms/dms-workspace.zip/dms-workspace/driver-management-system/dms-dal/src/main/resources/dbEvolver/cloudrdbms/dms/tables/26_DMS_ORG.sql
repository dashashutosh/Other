--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset m0b018e:dms.DMS_ORG_1_0_0 dbms:mysql
CREATE TABLE `DMS_ORG` (
  `ORG_UUID` varchar(50) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `ORG_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` bit(1) DEFAULT NULL,
  `CONTRACT_TYPE` varchar(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `PHONE` varchar(255) NOT NULL,
  `SCAC_CODE` varchar(255) NOT NULL,
  PRIMARY KEY (`ORG_UUID`),
  UNIQUE KEY `UK45tpim2m3j4s0o3t88jmhaj8v` (`ORG_NAME`,`CONTRACT_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--changeset m0b018e:dms.DMS_ORG_2_0_0 dbms:mysql
ALTER TABLE DMS_ORG ADD CONSTRAINT UK_ScacCode UNIQUE (SCAC_CODE);
