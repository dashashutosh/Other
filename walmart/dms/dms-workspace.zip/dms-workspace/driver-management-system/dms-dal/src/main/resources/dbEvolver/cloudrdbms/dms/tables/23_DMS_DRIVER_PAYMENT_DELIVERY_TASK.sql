--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset n0k008c:dms.DMS_DRIVER_PAYMENT_DELIVERY_TASK_1_0_0 dbms:mysql
CREATE TABLE `DMS_DRIVER_PAYMENT_DELIVERY_TASK` (
  `DELIVERY_TASK_UUID` varchar(50) NOT NULL,
  `DMS_DRIVER_PAYMENT_TRIP_EVENT_PK` varchar(50) NOT NULL,
  `ORDER_ID` varchar(50) NOT NULL,
  `ORDER_STATUS` varchar(255) NOT NULL,
  `TENANT_ID` varchar(50) NOT NULL,
  `VERTICAL_ID` varchar(50) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `REASON_CODE` varchar(50) DEFAULT NULL,
  `REASON_CODE_DESCRIPTION` varchar(255) DEFAULT NULL,
  `ENTITY_TYPE` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT NULL,
  `PAYABLE` char(1) DEFAULT NULL,
  `LATEST_ORDER_STATUS` varchar(255) DEFAULT NULL,
  `DB_LOCK_VERSION` INT NOT NULL,
  PRIMARY KEY (`DELIVERY_TASK_UUID`),
  UNIQUE KEY `UK_tripEventOrderId` (`DMS_DRIVER_PAYMENT_TRIP_EVENT_PK`,`ORDER_ID`),
  CONSTRAINT `FK_driverPaymentTripEventPk` FOREIGN KEY (`DMS_DRIVER_PAYMENT_TRIP_EVENT_PK`) REFERENCES `DMS_DRIVER_PAYMENT_TRIP_EVENT` (`DMS_DRIVER_PAYMENT_TRIP_EVENT_PK`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `DMS_DRIVER_PAYMENT_DELIVERY_TASK` (`CREATED_TIME`, `UPDATED_BY`, `UPDATED_TIME`, `ACTION`, `DMS_DRIVER_PAYMENT_TRIP_EVENT_PK`,`ENTITY_TYPE`,`LATEST_ORDER_STATUS`,`ORDER_ID`,`ORDER_STATUS`,`PAYABLE`,`REASON_CODE`, `REASON_CODE_DESCRIPTION`,`TENANT_ID`,`VERTICAL_ID`, `DELIVERY_TASK_UUID`, `DB_LOCK_VERSION`) SELECT `CREATED_TIME`, `UPDATED_BY`, `UPDATED_TIME`, `ACTION`, `DMS_DRIVER_PAYMENT_TRIP_EVENT_PK`,`ENTITY_TYPE`,`LATEST_EVENT`,`ORDER_ID`,`EVENT_NAME`,`PAYABLE`,`REASON_CODE`, `REASON_CODE_DESCRIPTION`,`TENANT_ID`,`VERTICAL_ID`,UUID(), `DB_LOCK_VERSION` FROM `DMS_DRIVER_PAYMENT_TRIP_EVENT`;
