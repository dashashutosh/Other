--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset n0k008c:dms.DMS_DRIVER_INCENTIVE_1_0_0 dbms:mysql
CREATE TABLE `DMS_DRIVER_INCENTIVE` (
  `DRIVER_INCENTIVE_PK` varchar(50) NOT NULL,
  `DRIVER_USER_ID` varchar(255) NOT NULL,
  `INCENTIVE_RULE_ID` varchar(255) NOT NULL,
  `INCENTIVE_TYPE` varchar(50) NOT NULL,
  `INCENTIVE_AMOUNT` DOUBLE NOT NULL,
  `TENANT_ID` varchar(50) NOT NULL,
  `VERTICAL_ID` varchar(50) NOT NULL,
  `ORDER_ID` varchar(50) DEFAULT NULL,
  `MARKET_NAME` varchar(200) DEFAULT NULL,
  `STORE_ID` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  PRIMARY KEY (`DRIVER_INCENTIVE_PK`),
  UNIQUE KEY `UK_DriverIdRuleIdIncentiveType` (`DRIVER_USER_ID`, `INCENTIVE_RULE_ID`, `INCENTIVE_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--changeset n0k008c:dms.DMS_DRIVER_INCENTIVE_2_0_0 dbms:mysql
ALTER TABLE DMS_DRIVER_INCENTIVE MODIFY STORE_ID varchar(50) NOT NULL;
ALTER TABLE DMS_DRIVER_INCENTIVE ADD COLUMN DB_LOCK_VERSION INT NOT NULL;

--changeset n0k008c:dms.DMS_DRIVER_INCENTIVE_3_0_0 dbms:mysql
ALTER TABLE DMS_DRIVER_INCENTIVE MODIFY STORE_ID varchar(50) DEFAULT NULL;