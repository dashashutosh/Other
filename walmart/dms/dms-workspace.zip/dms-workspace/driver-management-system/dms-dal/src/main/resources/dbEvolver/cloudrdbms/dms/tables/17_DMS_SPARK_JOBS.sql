--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset k0a009k:dms.DMS_DRIVER_AVAILABILITY_STATUS_AUDIT_1_0_0 dbms:mysql
CREATE TABLE `DMS_SPARK_JOBS` (
  `SPARK_JOB_UUID` varchar(255) NOT NULL,
  `IS_ACTIVE` bit(1) DEFAULT NULL,
  `SPARK_JOB_NAME` varchar(255) DEFAULT NULL,
  `SPARK_JOB_STATUS` varchar(255) DEFAULT NULL,
  `SPARK_SUBMISSION_ID` varchar(255) DEFAULT NULL,
  `REQUEST_BODY` varchar(10000) DEFAULT NULL,
  `REQUEST_DOMAIN` varchar(255) DEFAULT NULL,
  `RESPONSE_BODY` varchar(10000) DEFAULT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  PRIMARY KEY (`SPARK_JOB_UUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8


