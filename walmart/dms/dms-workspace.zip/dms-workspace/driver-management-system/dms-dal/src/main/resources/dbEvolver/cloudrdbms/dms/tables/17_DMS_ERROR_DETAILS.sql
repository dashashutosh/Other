--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset n0k008c:dms.DMS_ERROR_DETAILS_1_0_0 dbms:mysql
CREATE TABLE `DMS_ERROR_DETAILS` (
  `ERROR_ID` varchar(50) NOT NULL,
  `EVENT_NAME` varchar(255) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `LAST_PROCESSED_TIME` datetime DEFAULT NULL,
  `TENANT_ID` varchar(50) DEFAULT NULL,
  `VERTICAL_ID` varchar(50) DEFAULT NULL,
  `ERROR_TYPE` varchar(255) DEFAULT NULL,
  `ERROR_MESSAGE` varchar(255) DEFAULT NULL,
  `ERROR_STACK_TRACE` varchar(3000) DEFAULT NULL,
  `PAYLOAD` varchar(10000) DEFAULT NULL,
  `COMPUTE_IP` varchar(255) DEFAULT NULL,
  `VERSION` INT NOT NULL,
  PRIMARY KEY (`ERROR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE INDEX LAST_PROCESSED_TIME_INDEX ON DMS_ERROR_DETAILS (LAST_PROCESSED_TIME);

--changeset n0k008c:dms.DMS_ERROR_DETAILS_2_0_0 dbms:mysql
CREATE INDEX EVENT_NAME_CREATED_TIME_INDEX ON DMS_ERROR_DETAILS (EVENT_NAME, CREATED_TIME);