--liquibase formatted sql

--This table will be used by Global Search application to store reindexing process data for Disaster Recovery

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset s0g0aw5:dms.DMS_DMS_DRIVER_DOCUMENTS_1_0_0 dbms:mysql
CREATE TABLE `DMS_DRIVER_DOCUMENTS` (
  `DRIVER_DOCUMENT_UUID` varchar(50) NOT NULL,
  `DRIVER_USER_ID` varchar(255) NOT NULL,
  `DOCUMENT_TYPE` varchar(255) NOT NULL,
  `DOCUMENT_UPLOAD_TIME` DATETIME NOT NULL,
  `DOCUMENT_STATUS` varchar(255) NOT NULL,
  `DOCUMENT_LINK` varchar(255) NOT NULL,
  `DOCUMENT_VALIDATION_TIME` DATETIME NULL,
  `DOCUMENT_REJECT_REASON_CODE` varchar(255) NULL,
  `CREATED_TIME` DATETIME NOT NULL,
  `UPDATED_TIME` DATETIME NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  PRIMARY KEY (`DRIVER_DOCUMENT_UUID`),
  KEY `DMS_DRIVER_DOCUMENTS_INDEX` (`DRIVER_USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4