--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset s0k00tl:dms.WALMART_CALENDAR_1_0_0 dbms:mysql
CREATE TABLE WALMART_CALENDAR (
  CAL_DT date NOT NULL,
  JULIAN_DT int(11) DEFAULT NULL,
  DATE_DESC varchar(255) DEFAULT NULL,
  CAL_DAY_ALPHA_NBR varchar(255) DEFAULT NULL,
  CAL_WK_DAY_NBR int(11) DEFAULT NULL,
  CAL_WK_DAY_NM varchar(255) DEFAULT NULL,
  CAL_WK_DAY_ABBR varchar(255) DEFAULT NULL,
  CAL_DT_START_TS varchar(255) DEFAULT NULL,
  CAL_DT_END_TS varchar(255) DEFAULT NULL,
  DAY_CNT int(11) DEFAULT NULL,
  CAL_WK_NBR int(11) DEFAULT NULL,
  CAL_WK_NM varchar(255) DEFAULT NULL,
  CAL_WK_CNT int(11) DEFAULT NULL,
  CAL_MTH_ALPHA_NBR varchar(255) DEFAULT NULL,
  CAL_MTH_NBR int(11) DEFAULT NULL,
  CAL_MTH_DESC varchar(255) DEFAULT NULL,
  CAL_MTH_ABBR varchar(255) DEFAULT NULL,
  CAL_QTR_NBR int(11) DEFAULT NULL,
  CAL_MTH_CNT int(11) DEFAULT NULL,
  CAL_QTR_DESC varchar(255) DEFAULT NULL,
  CAL_QTR_CNT int(11) DEFAULT NULL,
  CAL_HALF_YR_NBR int(11) DEFAULT NULL,
  CAL_HALF_YR_NM varchar(255) DEFAULT NULL,
  CAL_HALF_CNT int(11) DEFAULT NULL,
  CAL_FULL_YR_NBR int(11) DEFAULT NULL,
  CAL_YR_NM varchar(255) DEFAULT NULL,
  FISCAL_MTH_NBR int(11) DEFAULT NULL,
  FISCAL_MTH_ALPHA_NBR varchar(255) DEFAULT NULL,
  FISCAL_MTH_NM varchar(255) DEFAULT NULL,
  FISCAL_MTH_ABBR varchar(255) DEFAULT NULL,
  FISCAL_MTH_CNT int(11) DEFAULT NULL,
  FISCAL_QTR_NBR int(11) DEFAULT NULL,
  FISCAL_QTR_NM varchar(255) DEFAULT NULL,
  FISCAL_QTR_CNT int(11) DEFAULT NULL,
  FISCAL_HALF_YR_NBR int(11) DEFAULT NULL,
  FISCAL_HALF_YR_NM varchar(255) DEFAULT NULL,
  FISCAL_HALF_CNT int(11) DEFAULT NULL,
  FISCAL_FULL_YR_NBR int(11) DEFAULT NULL,
  FISCAL_YR_NM varchar(255) DEFAULT NULL,
  LY_COMP_VISIT_DT varchar(255) DEFAULT NULL,
  WM_WK_DAY_NBR int(11) DEFAULT NULL,
  WM_WK_CNT int(11) DEFAULT NULL,
  WM_WK_NBR int(11) DEFAULT NULL,
  WM_WK_NM varchar(255) NOT NULL,
  WM_YR_WK_NBR int(11) DEFAULT NULL,
  WM_MTH_NBR int(11) DEFAULT NULL,
  WM_MTH_ALPHA_NBR varchar(255) DEFAULT NULL,
  WM_MTH_NM varchar(255) DEFAULT NULL,
  WM_MTH_ABBR varchar(255) DEFAULT NULL,
  WM_MTH_CNT int(11) DEFAULT NULL,
  WM_QTR_NBR int(11) DEFAULT NULL,
  WM_QTR_NM varchar(255) DEFAULT NULL,
  WM_REFER_QTR_CNT int(11) DEFAULT NULL,
  WM_HALF_YR_NBR int(11) DEFAULT NULL,
  WM_HALF_YR_NM varchar(255) DEFAULT NULL,
  WM_EPOC_HALF_CNT int(11) DEFAULT NULL,
  WM_FULL_YR_NBR int(11) DEFAULT NULL,
  WM_YR_DESC varchar(255) DEFAULT NULL,
  LY_COMP_YR_WK_NBR int(11) DEFAULT NULL,
  SRC_RCV_TS varchar(255) DEFAULT NULL,
  LOAD_TS varchar(255) DEFAULT NULL,
  LOAD_USERID varchar(255) DEFAULT NULL,
  GEO_REGION_CD varchar(255) DEFAULT NULL,
  UNIQUE KEY CAL_DT (CAL_DT)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
