--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset n0k008c:dms.DMS_ERROR_STATUS_1_0_0 dbms:mysql
CREATE TABLE `DMS_ERROR_STATUS` (
  `ERROR_STATUS_ID` varchar(50) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `ERROR_ID` varchar(50) NOT NULL,
  `ERROR_STATUS` varchar(50) NOT NULL,
  `ERROR_RETRY_COUNT` INT,
  `MAX_ERROR_RETRY_COUNT` INT,
  `VERSION` INT NOT NULL,
  PRIMARY KEY (`ERROR_STATUS_ID`),
  CONSTRAINT `FK_errorID` FOREIGN KEY (`ERROR_ID`) REFERENCES `DMS_ERROR_DETAILS` (`ERROR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE INDEX ERROR_STATUS_INDEX ON DMS_ERROR_STATUS (ERROR_STATUS);

--changeset s0g03ta:dms.DMS_ERROR_STATUS_2_0_0 dbms:mysql
ALTER TABLE DMS_ERROR_STATUS ADD COLUMN `NEXT_RETRY_TIME` datetime DEFAULT NULL,
ADD INDEX NEXT_RETRY_TIME_INDEX(NEXT_RETRY_TIME) ;
