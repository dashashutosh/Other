--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset nsc001m:dms.DMS_DRIVER_RELATIONS_1_0_0 dbms:mysql
CREATE TABLE DMS_DRIVER_RELATIONS (
DRIVER_RELATION_UUID varchar(50) NOT NULL,
CREATED_TIME datetime NOT NULL,
UPDATED_BY varchar(255) NOT NULL,
UPDATED_TIME datetime NOT NULL,
IS_ACTIVE bit(1) DEFAULT NULL,
RELATION_ENTITY_ID varchar(255) DEFAULT NULL,
RELATION_ENTITY_TYPE varchar(255) DEFAULT NULL,
DRIVER_PROGRAM_ID varchar(255) NOT NULL,
DRIVER_USER_ID varchar(255) NOT NULL,
REASON_CODE_ID varchar(50) DEFAULT NULL,
PRIMARY KEY (`DRIVER_RELATION_UUID`),
UNIQUE KEY `UKhuxeurs7c49mnink3sq11y85t` (`DRIVER_PROGRAM_ID`,`DRIVER_USER_ID`,`RELATION_ENTITY_TYPE`,`RELATION_ENTITY_ID`),
CONSTRAINT `FK_DmsDriverRelations` FOREIGN KEY (`DRIVER_PROGRAM_ID`, `DRIVER_USER_ID`) REFERENCES `DMS_DRIVER` (`DRIVER_PROGRAM_UUID`, `DRIVER_USER_ID`),
CONSTRAINT `FKdmsDriverReasonCodeId` FOREIGN KEY (`REASON_CODE_ID`) REFERENCES `DMS_REASON_CODE_CONFIG` (`REASON_CODE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1