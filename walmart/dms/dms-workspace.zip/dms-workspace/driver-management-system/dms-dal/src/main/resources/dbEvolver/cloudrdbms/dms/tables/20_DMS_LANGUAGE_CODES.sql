--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset m0m01pg:dms.DMS_LANGUAGE_CODES_1_0_0 dbms:mysql
CREATE TABLE `DMS_LANGUAGE_CODES` (
  `LANGUAGE_CODE` varchar(10) NOT NULL,
  `LANGUAGE_FAMILY` varchar(50) NOT NULL,
  `LANGUAGE_VARIANT` varchar(255) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  PRIMARY KEY (`LANGUAGE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
