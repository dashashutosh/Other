--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset n0k008c:dms.DMS_REASON_CODE_CONFIG_1_0_0 dbms:mysql
CREATE TABLE `DMS_REASON_CODE_CONFIG` (
  `REASON_CODE_ID` varchar(50) NOT NULL,
  `ACTION` varchar(255) NOT NULL,
  `REASON_CODE` varchar(50) NOT NULL,
  `REASON_CODE_DESCRIPTION` varchar(255) NOT NULL,
  `ACTIVE` bit(1) NOT NULL,
  `TENANT_ID` varchar(50) DEFAULT NULL,
  `VERTICAL_ID` varchar(50) DEFAULT NULL,
  `CAREER` varchar(50) DEFAULT NULL,
  `SERVICE_PROVIDER` varchar(50) DEFAULT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `DB_LOCK_VERSION` INT NOT NULL,
   PRIMARY KEY (`REASON_CODE_ID`),
   UNIQUE KEY `UK_Action_ReasonCode` (`ACTION`, `REASON_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE INDEX REASON_CODE_ACTION_INDEX ON DMS_REASON_CODE_CONFIG (ACTION, REASON_CODE);

--changeset n0k008c:dms.DMS_REASON_CODE_CONFIG_2_0_0 dbms:mysql
ALTER TABLE DMS_REASON_CODE_CONFIG CHANGE `CAREER` `CARRIER` varchar(50) DEFAULT NULL;