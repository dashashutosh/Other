--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset g0s00pv:dms.DMS_DRIVER_BLOCK_DETAILS_1_0_0 dbms:mysql
CREATE TABLE `DMS_DRIVER_BLOCK_DETAILS` (
  `DRIVER_BLOCK_DETAIL_UUID` varchar(50) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  `ACCEPTED_DATE_TIME` datetime DEFAULT NULL,
  `BLOCK_DATE_TIMESTAMP` bigint(20) DEFAULT NULL,
  `BLOCK_END_TIME` datetime DEFAULT NULL,
  `BLOCK_END_TIMESTAMP` bigint(20) DEFAULT NULL,
  `BLOCK_ID` varchar(50) NOT NULL,
  `BLOCK_START_TIME` datetime DEFAULT NULL,
  `BLOCK_START_TIMESTAMP` bigint(20) DEFAULT NULL,
  `BLOCK_STATUS` VARCHAR(255) DEFAULT NULL,
  `DRIVER_USER_ID` varchar(50) DEFAULT NULL,
  `IS_ACTIVE` bit(1) DEFAULT NULL,
  `STORE_ID` varchar(50) NOT NULL,
  `TENANT_ID` varchar(50) NOT NULL,
  PRIMARY KEY (`DRIVER_BLOCK_DETAIL_UUID`),
  UNIQUE KEY `idx_DMS_DRIVER_BLOCK_DETAILS_BLOCK_ID_TENANT_ID` (`BLOCK_ID`,`TENANT_ID`),
  KEY `idx_DMS_DRIVER_BLOCK_DETAILS_BLOCK_DATE_TIMESTAMP` (`BLOCK_DATE_TIMESTAMP`),
  KEY `idx_DMS_DRIVER_BLOCK_DETAILS_STORE_ID` (`STORE_ID`),
  KEY `idx_DMS_DRIVER_BLOCK_DETAILS_BLOCK_START_TIMESTAMP` (`BLOCK_START_TIMESTAMP`),
  KEY `idx_DMS_DRIVER_BLOCK_DETAILS_BLOCK_END_TIMESTAMP` (`BLOCK_END_TIMESTAMP`),
  KEY `idx_DMS_DRIVER_BLOCK_DETAILS_BLOCK_ID` (`BLOCK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8