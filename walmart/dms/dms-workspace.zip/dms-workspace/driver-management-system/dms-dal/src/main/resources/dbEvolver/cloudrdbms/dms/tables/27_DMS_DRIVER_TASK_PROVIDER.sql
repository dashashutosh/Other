--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset m0m01pg:dms.DMS_DRIVER_TASK_PROVIDER_1_0_0 dbms:mysql
CREATE TABLE `DMS_DRIVER_TASK_PROVIDER` (
  `DRIVER_TASK_PROVIDER_PK` varchar(255) NOT NULL,
  `DRIVER_ID` varchar(255) NOT NULL,
  `DRIVER_PROGRAM_ID` varchar(255) NOT NULL,
  `TASK_PROVIDER` varchar(255) NOT NULL,
  `IS_ACTIVE` bit(1) DEFAULT NULL,
  `STATUS` varchar(255) NOT NULL,
  `TOKEN_ID` varchar(255) DEFAULT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  PRIMARY KEY (`DRIVER_TASK_PROVIDER_PK`),
  UNIQUE KEY `UQg0wdnd5iuds73x5lkj6sod99y` (`DRIVER_ID`,`TASK_PROVIDER`),
  CONSTRAINT `FKhwedymixiroeahheeup2rdngd` FOREIGN KEY (`DRIVER_PROGRAM_ID`, `DRIVER_ID`) REFERENCES `DMS_DRIVER` (`DRIVER_PROGRAM_UUID`, `DRIVER_USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `DMS_DRIVER_TASK_PROVIDER_AUD` (
  `DRIVER_TASK_PROVIDER_PK` varchar(255) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `IS_ACTIVE` bit(1) DEFAULT NULL,
  `STATUS` varchar(255) NOT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  `UPDATED_TIME` datetime NOT NULL,
  PRIMARY KEY (`DRIVER_TASK_PROVIDER_PK`,`REV`),
  KEY `FKgubogllv10rh9q5x1b591uhd4` (`REV`),
  CONSTRAINT `FKgubogggv9srh9q5x1b591uhd4` FOREIGN KEY (`REV`) REFERENCES `REVINFO` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
