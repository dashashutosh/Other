--liquibase formatted sql

-- general
-- do make schema changes backward compatible. all changes that change backward compatibility should be done in post-scripts.
-- do not modify a changeset that has already been released, add a new one.
-- do not include data changes in this script.
-- changeset definition format: {author}:{release}_{env} dbms:mysql context:{env}
-- {author}: the author of the changeset
-- {release}: the release containing this changeset. Do not use quotes, '-' or '.'. Safe characters include '0-9, a-z, A-Z, _'
-- {env}: if appropriate, an environment name can be included making the changeset conditional to a specific environmemt. (dev, qa, preprod, prod)

--
--changeset s0p012h:dms.DMS_DRIVER_PAYMENT_TRANSACTION_LOG_TRAIL_1_0_0 dbms:mysql
CREATE TABLE `DMS_DRIVER_PAYMENT_TRANSACTION_LOG_TRAIL` (
  `PAYMENT_LOG_TRAILS_UUID` varchar(255) NOT NULL,
  `TRANSACTION_ID` varchar(50) NOT NULL,
  `ORDER_ID` varchar(255) NOT NULL,
  `DRIVER_USER_ID` varchar(255) NOT NULL,
  `TRANSACTION_AMOUNT` DOUBLE NOT NULL,
  `TRANSACTION_STATUS` varchar(255) NOT NULL,
  `TRANSACTION_TYPE` varchar(255) NOT NULL,
  `CREATED_TIME` datetime NOT NULL,
  `UPDATED_TIME` datetime DEFAULT NULL,
  `UPDATED_BY` varchar(255) NOT NULL,
  PRIMARY KEY (`PAYMENT_LOG_TRAILS_UUID`),
  UNIQUE KEY `UK_driverTransactionIdTransactionStatus` (`TRANSACTION_ID`,`TRANSACTION_STATUS`),
  CONSTRAINT `FK_driverTransactionId` FOREIGN KEY (`TRANSACTION_ID`) REFERENCES `DMS_DRIVER_PAYMENT_TRANSACTION` (`DRIVER_PAYMENT_TRANSACTION_ID`),
  KEY `idx_DMS_DRIVER_ORDER_ID` (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;