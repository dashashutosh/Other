package com.walmart.dms.biz.util;

import com.walmart.dms.dal.jpa.entity.DriverScheduleEntity;
import com.walmart.dms.model.availability.dto.PickupPointCapacityTemplateDTO;
import org.springframework.data.util.Pair;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class DriverCapacityUtil {

    public static List<DriverScheduleEntity> getScheduleEntityList() {
        List<DriverScheduleEntity> driverScheduleEntities = new ArrayList<>();

        DriverScheduleEntity driverScheduleEntity = new DriverScheduleEntity();
        driverScheduleEntity.setDriverUserId("jp@walmart.com");
        driverScheduleEntity.setStartTime(LocalTime.of(8,40));
        driverScheduleEntity.setEndTime(LocalTime.of(12,01));
        driverScheduleEntity.setDayOfWeek(DayOfWeek.MONDAY);
        driverScheduleEntities.add(driverScheduleEntity);

        driverScheduleEntity = new DriverScheduleEntity();
        driverScheduleEntity.setDriverUserId("jp@walmart.com");
        driverScheduleEntity.setStartTime(LocalTime.of(8,40));
        driverScheduleEntity.setEndTime(LocalTime.of(12,01));
        driverScheduleEntity.setDayOfWeek(DayOfWeek.TUESDAY);
        driverScheduleEntities.add(driverScheduleEntity);

        driverScheduleEntity = new DriverScheduleEntity();
        driverScheduleEntity.setDriverUserId("jp@walmart.com");
        driverScheduleEntity.setStartTime(LocalTime.of(8,40));
        driverScheduleEntity.setEndTime(LocalTime.of(12,01));
        driverScheduleEntity.setDayOfWeek(DayOfWeek.WEDNESDAY);
        driverScheduleEntities.add(driverScheduleEntity);

        driverScheduleEntity = new DriverScheduleEntity();
        driverScheduleEntity.setDriverUserId("jp@walmart.com");
        driverScheduleEntity.setStartTime(LocalTime.of(12,40));
        driverScheduleEntity.setEndTime(LocalTime.of(16,01));
        driverScheduleEntity.setDayOfWeek(DayOfWeek.THURSDAY);
        driverScheduleEntities.add(driverScheduleEntity);

        driverScheduleEntity = new DriverScheduleEntity();
        driverScheduleEntity.setDriverUserId("jp@walmart.com");
        driverScheduleEntity.setStartTime(LocalTime.of(12,40));
        driverScheduleEntity.setEndTime(LocalTime.of(16,01));
        driverScheduleEntity.setDayOfWeek(DayOfWeek.FRIDAY);
        driverScheduleEntities.add(driverScheduleEntity);

        driverScheduleEntity = new DriverScheduleEntity();
        driverScheduleEntity.setDriverUserId("jp@walmart.com");
        driverScheduleEntity.setStartTime(LocalTime.of(16,40));
        driverScheduleEntity.setEndTime(LocalTime.of(20,01));
        driverScheduleEntity.setDayOfWeek(DayOfWeek.FRIDAY);
        return driverScheduleEntities;
    }

    public static PickupPointCapacityTemplateDTO fetchPickupPointCapacityTemplate() {
        PickupPointCapacityTemplateDTO pickupPointCapacityTemplateDTO = new PickupPointCapacityTemplateDTO();
        pickupPointCapacityTemplateDTO.setAcceptanceProbability(0.5);
        pickupPointCapacityTemplateDTO.setUnassignedTripMultipler(1.0);
        pickupPointCapacityTemplateDTO.setAvailableTime(30);
        pickupPointCapacityTemplateDTO.setPickupTime(14);
        pickupPointCapacityTemplateDTO.setSlotEndTime(60);
        return pickupPointCapacityTemplateDTO;
    }

    public static Pair<ZonedDateTime, ZonedDateTime> getPairOfTime() {
        ZonedDateTime min = ZonedDateTime.now(ZoneId.of("UTC"));
        ZonedDateTime max = min.plusHours(1);
       return Pair.of(min, max);
    }
}
