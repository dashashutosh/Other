package com.walmart.dms.biz.boosteroffer;

import com.walmart.dms.biz.scheduling.dto.DriverBoosterOfferResponseDTO;
import com.walmart.dms.biz.scheduling.dto.DriverBoosterOfferScheduleDTO;
import com.walmart.dms.biz.scheduling.dto.RandomIDVerificationStatus;
import com.walmart.dms.common.enums.DriverOfflineReason;
import com.walmart.dms.common.utils.HeaderDTO;
import com.walmart.dms.dal.jpa.entity.DriverBoosterOfferScheduleEntity;

import java.time.ZonedDateTime;

/**
 * @author j0p060t
 */
public class BoosterOfferScheduleHelper {

    public static DriverBoosterOfferScheduleEntity getDriverBoosterOfferEntity(String driverId, ZonedDateTime endTime, String status, DriverOfflineReason reason) {
        DriverBoosterOfferScheduleEntity driverBoosterOfferScheduleEntity = new DriverBoosterOfferScheduleEntity();
        driverBoosterOfferScheduleEntity.setDriverUserId(driverId);
        driverBoosterOfferScheduleEntity.setEndTime(endTime);
        driverBoosterOfferScheduleEntity.setStatus(status);
        driverBoosterOfferScheduleEntity.setReason(reason);
        return driverBoosterOfferScheduleEntity;
    }

    public static DriverBoosterOfferScheduleDTO getDriverBoosterOfferDTO(String status, ZonedDateTime endTime, DriverOfflineReason reason) {
        DriverBoosterOfferScheduleDTO driverBoosterOfferScheduleDTO = new DriverBoosterOfferScheduleDTO();
        driverBoosterOfferScheduleDTO.setStatus(status);
        driverBoosterOfferScheduleDTO.setTill(endTime);
        driverBoosterOfferScheduleDTO.setReason(reason);
        return driverBoosterOfferScheduleDTO;
    }

    public static DriverBoosterOfferResponseDTO getDriverBoosterOfferResponseDTO(String status, ZonedDateTime endTime, DriverOfflineReason reason) {
        DriverBoosterOfferResponseDTO driverBoosterOfferResponseDTO = new DriverBoosterOfferResponseDTO();
        driverBoosterOfferResponseDTO.setStatus(status);
        driverBoosterOfferResponseDTO.setTill(endTime.toString());
        driverBoosterOfferResponseDTO.setReason(reason.toString());
        return driverBoosterOfferResponseDTO;
    }

    public static HeaderDTO getHeaders() {
        HeaderDTO headerDTO = new HeaderDTO("0","2");
        headerDTO.setCountryCode("US");
        return headerDTO;
    }

    public static RandomIDVerificationStatus getRandomIDVerificationStatus() {
        RandomIDVerificationStatus randomIDVerificationStatus = new RandomIDVerificationStatus("OFFLINE",DriverOfflineReason.ID_VERIFICATION_NEEDED);
        return randomIDVerificationStatus;
    }

}

