package com.walmart.dms.biz.arranger;

import com.walmart.dms.biz.availability.ccm.DMSAvailabilityConfig;
import com.walmart.dms.common.enums.DriverOfferStatus;
import com.walmart.dms.common.enums.DriverSuggestionPriority;
import com.walmart.dms.common.enums.DriverType;
import com.walmart.dms.dal.jpa.entity.DriverOfferDetailsEntity;
import com.walmart.dms.dal.jpa.entity.key.DriverOfferDetailsEntityPK;
import com.walmart.dms.dal.jpa.repository.DriverTripDetailRepository;
import com.walmart.dms.dal.jpa.service.DriverOfferDetailsDALService;
import com.walmart.dms.integration.elasticsearch.ESAPIImpl;
import com.walmart.dms.model.availability.dto.AvailabilityRequestSlot;
import com.walmart.dms.model.availability.dto.DriverOfferDetailsEsDto;
import com.walmart.dms.model.availability.dto.GetAvailableDriversRequestDTO;
import com.walmart.dms.model.onboarding.dto.DriverDTO;
import com.walmart.dms.model.scheduling.dto.ESDriverOfferTripResponseDTO;
import com.walmart.dms.model.scheduling.dto.TripHitsDTO;
import com.walmart.dms.model.scheduling.dto.TripHitsResponseDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.ZonedDateTime;
import java.util.*;


import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RRDriverSlotArrangerTest {

    @Mock
    private DriverOfferDetailsDALService driverOfferDetailsDALService;

    @Mock
    private DMSAvailabilityConfig dMSAvailabilityConfig;

    @InjectMocks
    private RRDriverSlotArranger rrDriverSlotArranger;

    @Mock
    private DriverTripDetailRepository driverTripDetailRepository;

    @Mock
    private ESAPIImpl esAPI;

    @Before
    public void init() {

        when(dMSAvailabilityConfig.getDmsDriverAvailabilityResultLimit()).thenReturn(10);
        when(dMSAvailabilityConfig.getDmsDriverSuggestionThreadpoolSize()).thenReturn(16);
        when(dMSAvailabilityConfig.getDmsSuggestionAPIFilterBackupAndTForceForCallers()).thenReturn("dispatcher-cron,xyz-cron");
        when(driverTripDetailRepository.countDriversTripDetail(Mockito.anySet(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anySet())).thenReturn(new ArrayList<>());
        rrDriverSlotArranger.init();
    }

    @Test
    public void testRejectedDrivers() {

        ZonedDateTime startTime = ZonedDateTime.parse("2018-10-01T17:00:00-00:00");
        ZonedDateTime endTime = ZonedDateTime.parse("2018-10-01T17:59:59-00:00");
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.REJECTED, 1, 1);

        when(driverOfferDetailsDALService.getDriversWithExpiredAndRejectedStatus(Mockito.anySet(),
                Mockito.any(ZonedDateTime.class), Mockito.any(ZonedDateTime.class)
        )).thenReturn(driverOfferDetailsEntities);

        Set<String> selectedDrivers = createSelectedDrivers();
        GetAvailableDriversRequestDTO request = new GetAvailableDriversRequestDTO();
        request.setStoreId("10");
        Map<String, List<DriverDTO>> userIdToDtoMap = Collections.emptyMap();
        Map<String, DriverSuggestionPriority> driversWithPriority = rrDriverSlotArranger.arrange(selectedDrivers, request, startTime, endTime, userIdToDtoMap);
        Assert.assertEquals(6, driversWithPriority.size());
    }

    @Test
    public void testExpiredDrivers() {

        ZonedDateTime startTime = ZonedDateTime.parse("2018-10-01T17:00:00-00:00");
        ZonedDateTime endTime = ZonedDateTime.parse("2018-10-01T17:59:59-00:00");
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.EXPIRED, 1, 1);

        when(driverOfferDetailsDALService.getDriversWithExpiredAndRejectedStatus(Mockito.anySet(),
                Mockito.any(ZonedDateTime.class), Mockito.any(ZonedDateTime.class)
        )).thenReturn(driverOfferDetailsEntities);

        Set<String> selectedDrivers = createSelectedDrivers();
        GetAvailableDriversRequestDTO request = new GetAvailableDriversRequestDTO();
        request.setStoreId("10");
        Map<String, List<DriverDTO>> userIdToDtoMap = Collections.emptyMap();
        Map<String, DriverSuggestionPriority> driversWithPriority = rrDriverSlotArranger.arrange(selectedDrivers, request, startTime, endTime, userIdToDtoMap);
        Assert.assertEquals(6, driversWithPriority.size());
    }

    @Test
    public void testRejectedDriversWithDifferentStore() {

        ZonedDateTime startTime = ZonedDateTime.parse("2018-10-01T17:00:00-00:00");
        ZonedDateTime endTime = ZonedDateTime.parse("2018-10-01T17:59:59-00:00");
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = createDriverOfferDetailsEntities("11", startTime, endTime,
                DriverOfferStatus.REJECTED, 1, 1);

        when(driverOfferDetailsDALService.getDriversWithExpiredAndRejectedStatus(Mockito.anySet(),
                Mockito.any(ZonedDateTime.class), Mockito.any(ZonedDateTime.class)
        )).thenReturn(driverOfferDetailsEntities);

        Set<String> selectedDrivers = createSelectedDrivers();
        GetAvailableDriversRequestDTO request = new GetAvailableDriversRequestDTO();
        request.setStoreId("10");
        Map<String, List<DriverDTO>> userIdToDtoMap = Collections.emptyMap();
        Map<String, DriverSuggestionPriority> driversWithPriority = rrDriverSlotArranger.arrange(selectedDrivers, request, startTime, endTime, userIdToDtoMap);
        Assert.assertEquals(6, driversWithPriority.size());
    }

    @Test
    public void testMultipleRejectedDrivers() {

        ZonedDateTime startTime = ZonedDateTime.parse("2018-10-01T17:00:00-00:00");
        ZonedDateTime endTime = ZonedDateTime.parse("2018-10-01T17:59:59-00:00");
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.REJECTED, 1, 1);

        driverOfferDetailsEntities.addAll(createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.EXPIRED, 2, 1));

        when(driverOfferDetailsDALService.getDriversWithExpiredAndRejectedStatus(Mockito.anySet(),
                Mockito.any(ZonedDateTime.class), Mockito.any(ZonedDateTime.class)
        )).thenReturn(driverOfferDetailsEntities);

        Set<String> selectedDrivers = createSelectedDrivers();
        GetAvailableDriversRequestDTO request = new GetAvailableDriversRequestDTO();
        request.setStoreId("10");
        Map<String, List<DriverDTO>> userIdToDtoMap = Collections.emptyMap();
        Map<String, DriverSuggestionPriority> driversWithPriority = rrDriverSlotArranger.arrange(selectedDrivers, request, startTime, endTime, userIdToDtoMap);
        Assert.assertEquals(6, driversWithPriority.size());
    }

    @Test
    public void testMix() {

        ZonedDateTime startTime = ZonedDateTime.parse("2018-10-01T17:00:00-00:00");
        ZonedDateTime endTime = ZonedDateTime.parse("2018-10-01T17:59:59-00:00");
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.REJECTED, 1, 1);

        driverOfferDetailsEntities.addAll(createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.EXPIRED, 2, 1));

        driverOfferDetailsEntities.addAll(createDriverOfferDetailsEntities("11", startTime, endTime,
                DriverOfferStatus.REJECTED, 3, 1));

        when(driverOfferDetailsDALService.getDriversWithExpiredAndRejectedStatus(Mockito.anySet(),
                Mockito.any(ZonedDateTime.class), Mockito.any(ZonedDateTime.class)
        )).thenReturn(driverOfferDetailsEntities);

        Set<String> selectedDrivers = createSelectedDrivers();
        GetAvailableDriversRequestDTO request = new GetAvailableDriversRequestDTO();
        request.setStoreId("10");
        Map<String, List<DriverDTO>> userIdToDtoMap = Collections.emptyMap();
        Map<String, DriverSuggestionPriority> driversWithPriority = rrDriverSlotArranger.arrange(selectedDrivers, request, startTime, endTime, userIdToDtoMap);
        Assert.assertEquals(6, driversWithPriority.size());
    }


    @Test
    public void testMix2() {

        ZonedDateTime startTime = ZonedDateTime.parse("2018-10-01T17:00:00-00:00");
        ZonedDateTime endTime = ZonedDateTime.parse("2018-10-01T17:59:59-00:00");
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.REJECTED, 1, 1);

        driverOfferDetailsEntities.addAll(createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.EXPIRED, 2, 1));

        driverOfferDetailsEntities.addAll(createDriverOfferDetailsEntities("11", startTime, endTime,
                DriverOfferStatus.REJECTED, 3, 1));

        driverOfferDetailsEntities.addAll(createDriverOfferDetailsEntities("11", startTime, endTime,
                DriverOfferStatus.REJECTED, 1, 1));

        when(driverOfferDetailsDALService.getDriversWithExpiredAndRejectedStatus(Mockito.anySet(),
                Mockito.any(ZonedDateTime.class), Mockito.any(ZonedDateTime.class)
        )).thenReturn(driverOfferDetailsEntities);

        Set<String> selectedDrivers = createSelectedDrivers();
        GetAvailableDriversRequestDTO request = new GetAvailableDriversRequestDTO();
        request.setStoreId("10");
        Map<String, List<DriverDTO>> userIdToDtoMap = Collections.emptyMap();
        Map<String, DriverSuggestionPriority> driversWithPriority = rrDriverSlotArranger.arrange(selectedDrivers, request, startTime, endTime, userIdToDtoMap);
        Assert.assertEquals(6, driversWithPriority.size());
    }

    @Test
    public void testMixLimit() {

        when(dMSAvailabilityConfig.getDmsDriverAvailabilityResultLimit()).thenReturn(1);
        ZonedDateTime startTime = ZonedDateTime.parse("2018-10-01T17:00:00-00:00");
        ZonedDateTime endTime = ZonedDateTime.parse("2018-10-01T17:59:59-00:00");
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.REJECTED, 1, 1);

        driverOfferDetailsEntities.addAll(createDriverOfferDetailsEntities("10", startTime, endTime,
                DriverOfferStatus.EXPIRED, 2, 1));

        driverOfferDetailsEntities.addAll(createDriverOfferDetailsEntities("11", startTime, endTime,
                DriverOfferStatus.REJECTED, 3, 1));

        when(driverOfferDetailsDALService.getDriversWithExpiredAndRejectedStatus(Mockito.anySet(),
                Mockito.any(ZonedDateTime.class), Mockito.any(ZonedDateTime.class)
        )).thenReturn(driverOfferDetailsEntities);

        Set<String> selectedDrivers = createSelectedDrivers();
        GetAvailableDriversRequestDTO request = new GetAvailableDriversRequestDTO();
        request.setStoreId("11");
        Map<String, List<DriverDTO>> userIdToDtoMap = Collections.emptyMap();
        Map<String, DriverSuggestionPriority> driversWithPriority = rrDriverSlotArranger.arrange(selectedDrivers, request, startTime, endTime, userIdToDtoMap);
        Assert.assertEquals(1, driversWithPriority.size());
    }


    @Test
    public void testIgnoreDrivers() {
        Assert.assertEquals(true, rrDriverSlotArranger.ignoreDriver("dispatcher-cron", "some-backup-thing", getDriverUserIdToDTOMap()));
        Assert.assertEquals(true, rrDriverSlotArranger.ignoreDriver("dispatcher-cron", "some-tforce-thing", getDriverUserIdToDTOMap()));
        Assert.assertEquals( false, rrDriverSlotArranger.ignoreDriver("dispatcher-cron", "some-thing", getDriverUserIdToDTOMap()));

        Assert.assertEquals(true, rrDriverSlotArranger.ignoreDriver("xyz-cron", "some-backup-thing", getDriverUserIdToDTOMap()));
        Assert.assertEquals(true, rrDriverSlotArranger.ignoreDriver("xyz-cron", "some-tforce-thing", getDriverUserIdToDTOMap()));
        Assert.assertEquals(false, rrDriverSlotArranger.ignoreDriver("xyz-cron", "some-thing", getDriverUserIdToDTOMap()));


        Assert.assertEquals(false, rrDriverSlotArranger.ignoreDriver("", "some-backup-thing", getDriverUserIdToDTOMap()));
        Assert.assertEquals(false, rrDriverSlotArranger.ignoreDriver("dispatcher-cron-1", "some-tforce-thing", getDriverUserIdToDTOMap()));
        Assert.assertEquals(false, rrDriverSlotArranger.ignoreDriver(null, "some-thing", getDriverUserIdToDTOMap()));
    }

    @Test
    public void testExpiredDriversRearrangement() {

        GetAvailableDriversRequestDTO getAvailableDriversRequestDTO = new GetAvailableDriversRequestDTO();
        getAvailableDriversRequestDTO.setStoreId("121");

        List<AvailabilityRequestSlot> listSlots = new ArrayList<AvailabilityRequestSlot>();
        AvailabilityRequestSlot slotTime = new AvailabilityRequestSlot();
        slotTime.setStartTime(ZonedDateTime.parse("2018-11-22T15:00-00:00"));
        slotTime.setEndTime(ZonedDateTime.parse("2018-11-22T16:00-00:00"));
        listSlots.add(slotTime);
        getAvailableDriversRequestDTO.setSlots(listSlots);

        ESDriverOfferTripResponseDTO res = new ESDriverOfferTripResponseDTO();
        TripHitsResponseDTO hits = new TripHitsResponseDTO();
        List<TripHitsDTO> hitsList = new ArrayList<>();
        TripHitsDTO tripHits = new TripHitsDTO();
        DriverOfferDetailsEsDto source = new DriverOfferDetailsEsDto();
        List<String> expiryDriverIds = new ArrayList<String>();
        expiryDriverIds.add("d1");
        expiryDriverIds.add("d2");
        expiryDriverIds.add("d3");
        expiryDriverIds.add("d1");
        expiryDriverIds.add("d2");
        source.setExpiryDriverIds(expiryDriverIds);
        tripHits.setSource(source);
        hitsList.add(tripHits);
        hits.setHits(hitsList);
        res.setHits(hits);

        try {
            when(esAPI.getDriverTripOfferDetail(Mockito.any())).thenReturn(res);
            Set<String> priorityWiseListOfExpiredDrivers = new LinkedHashSet<String>();
            priorityWiseListOfExpiredDrivers.add("d1");
            priorityWiseListOfExpiredDrivers.add("d5");
            priorityWiseListOfExpiredDrivers.add("d3");
            priorityWiseListOfExpiredDrivers = rrDriverSlotArranger
                    .rearrangeExpiredDrivers(priorityWiseListOfExpiredDrivers, "121", getAvailableDriversRequestDTO);

            Set<String> priorityWiseListOfExpiredDriversShouldBe = new LinkedHashSet<String>();
            priorityWiseListOfExpiredDriversShouldBe.add("d5");
            priorityWiseListOfExpiredDriversShouldBe.add("d3");
            priorityWiseListOfExpiredDriversShouldBe.add("d1");
            Assert.assertEquals(true,priorityWiseListOfExpiredDrivers.equals(priorityWiseListOfExpiredDriversShouldBe));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private Set<String> createSelectedDrivers() {
        Set<String> selectedDrivers = new LinkedHashSet<>();

        selectedDrivers.add("1@walmartlabs.com");
        selectedDrivers.add("2@walmartlabs.com");
        selectedDrivers.add("3@walmartlabs.com");
        selectedDrivers.add("4@walmartlabs.com");
        selectedDrivers.add("5@walmartlabs.com");
        selectedDrivers.add("6@walmartlabs.com");

        return selectedDrivers;
    }

    private List<DriverOfferDetailsEntity> createDriverOfferDetailsEntities(String storeId, ZonedDateTime startTime, ZonedDateTime endTime,
                                                                            DriverOfferStatus status, int i, int count) {
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = new ArrayList<>();

        for (int j = i; j < count + i; j++) {
            driverOfferDetailsEntities.add(createDriverOfferDetailsEntity(j + "@walmartlabs.com", storeId, startTime, endTime, status));
        }

        return driverOfferDetailsEntities;
    }

    private DriverOfferDetailsEntity createDriverOfferDetailsEntity(String driverId, String storeId, ZonedDateTime startTime, ZonedDateTime endTime,
                                                                    DriverOfferStatus status) {
        DriverOfferDetailsEntity driverOfferDetailsEntity = new DriverOfferDetailsEntity();
        DriverOfferDetailsEntityPK driverOfferDetailsEntityPK = new DriverOfferDetailsEntityPK();

        driverOfferDetailsEntityPK.setDriverId(driverId);
        driverOfferDetailsEntityPK.setStoreId(storeId);
        driverOfferDetailsEntityPK.setStartTime(startTime);
        driverOfferDetailsEntityPK.setEndTime(endTime);

        driverOfferDetailsEntity.setId(driverOfferDetailsEntityPK);
        driverOfferDetailsEntity.setStatus(status);

        return driverOfferDetailsEntity;
    }

    private Map<String, List<DriverDTO>> getDriverUserIdToDTOMap() {
        Map<String, List<DriverDTO>> userIdToDtoMap = new HashMap<>();
        DriverDTO driverDTO = new DriverDTO();
        driverDTO.setDriverType(DriverType.BACKUP);
        userIdToDtoMap.put("some-backup-thing", Arrays.asList(driverDTO));

        DriverDTO driverDTOTF = new DriverDTO();
        driverDTOTF.setDriverType(DriverType.TFORCE);
        userIdToDtoMap.put("some-tforce-thing", Arrays.asList(driverDTOTF));

        DriverDTO driverDTORG = new DriverDTO();
        driverDTORG.setDriverType(DriverType.REGULAR);
        userIdToDtoMap.put("some-thing", Arrays.asList(driverDTORG));


        return userIdToDtoMap;
    }
}
