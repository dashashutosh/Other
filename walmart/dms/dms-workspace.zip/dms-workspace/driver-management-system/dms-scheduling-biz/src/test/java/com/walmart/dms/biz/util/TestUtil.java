package com.walmart.dms.biz.util;

import com.walmart.dms.biz.availability.manager.AvailabilityManagerImpl;
import com.walmart.dms.common.enums.AvailabilityType;
import com.walmart.dms.common.enums.DriverBatchingPreference;
import com.walmart.dms.dal.jpa.entity.DriverScheduleEntity;
import com.walmart.dms.model.availability.dto.DriverSuggestionData;
import com.walmart.dms.model.availability.dto.GeoPoint;
import com.walmart.dms.model.availability.dto.SuggestionRequestDTO;
import com.walmart.dms.model.common.dto.Location;
import com.walmart.dms.model.driversuggestion.dto.MCSuggestionRequestDTO;
import com.walmart.dms.model.onboarding.dto.ContactDTO;
import com.walmart.dms.model.onboarding.dto.DriverDTO;
import org.springframework.data.util.Pair;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Utility class for test cases.
 *
 * @author a0d02yr
 */
public class TestUtil {

    /**
     * Gets driver suggestion data map with default values.
     *
     * @return driver suggestion data map
     */
    public static Map<String, DriverSuggestionData> getDriverData() {

        DriverSuggestionData D1 = getDriverSuggestionData("5567", "warrior.priya@walmartlabs.com", "warrior", "priya", LocalDate.ofYearDay(1988, 30), "1234567890", 4.5D, "warrior.priya@walmartlabs.com");
        DriverSuggestionData D2 = getDriverSuggestionData("5567", "warrior.priya2@walmartlabs.com", "warrior2", "priya2", LocalDate.ofYearDay(1988, 40), "1234569870", 4.52D, "warrior.priya2@walmartlabs.com");
        DriverSuggestionData D3 = getDriverSuggestionData("5567", "warrior.priya3@walmartlabs.com", "warrior3", "priya3", LocalDate.ofYearDay(1988, 50), "1234587690", 4.54D, "warrior.priya3@walmartlabs.com");

        Map<String, DriverSuggestionData> data = new HashMap<>();
        data.put("warrior.priya@walmartlabs.com", D1);
        data.put("warrior.priya2@walmartlabs.com", D2);
        data.put("warrior.priya3@walmartlabs.com", D3);

        return data;
    }

    /**
     * Gets driver suggestion data map with default values.
     *
     * @param storeIdVsDriverIdsMap map of store id vs list of driver ids
     * @return Driver suggestion data map
     */
    public static Map<String, Map<String, DriverSuggestionData>> getDriverSuggestionDataByStore(final Map<String, List<String>> storeIdVsDriverIdsMap) {

        Map<String, Map<String, DriverSuggestionData>> getDriverSuggestionDataByStoreMap = new HashMap<>();

        for (final String storeId : storeIdVsDriverIdsMap.keySet()) {
            int i = 1;

            final Map<String, DriverSuggestionData> driverSuggestionDataMap = new HashMap<>();
            for (final String driverId : storeIdVsDriverIdsMap.get(storeId)) {
                driverSuggestionDataMap.put(driverId, getDriverSuggestionData(storeId, driverId, "testFirstName-" + i, "testLastName-" + i++,
                        LocalDate.ofYearDay(1988, 30), "1234567890", 4.5D, driverId));
            }

            getDriverSuggestionDataByStoreMap.put(storeId, driverSuggestionDataMap);
        }

        return getDriverSuggestionDataByStoreMap;
    }

    /**
     * Gets an object of DriverSuggestionData class initialized with given parameters.
     *
     * @param storeId      the store id
     * @param driverUserId the driver user id
     * @param firstName    the first name
     * @param lastName     the last name
     * @param dob          the date of birth
     * @param mobile       the mobile
     * @param rating       the rating
     * @param email        the email id
     * @return an object of DriverSuggestionData class
     */
    public static DriverSuggestionData getDriverSuggestionData(String storeId, String driverUserId, String firstName, String lastName,
                                                               LocalDate dob, String mobile, Double rating, String email) {
        DriverSuggestionData driverSuggestionData = new DriverSuggestionData() {
            public String getStore() {
                return storeId;
            }

            public String getDriverUserId() {
                return driverUserId;
            }

            public String getFirstName() {
                return firstName;
            }

            public String getLastName() {
                return lastName;
            }

            public LocalDate getDateOfBirth() {
                return dob;
            }

            public String getMobile() {
                return mobile;
            }

            public Double getRating() {
                return rating;
            }

            public String getEmail() {
                return email;
            }

            public int getBoosterOffer() {
                return 0;
            }

            public DriverBatchingPreference getBatchingPreference() {
                return DriverBatchingPreference.AUTO_ACCEPT;
            }

			public Location getDriverLocation() {
				return null;
			}

			public Long getLocationUpdatedTimeEpoch() {
				return null;
			}

            public List<String> getSkills() {
                return null;
            }
        };

        return driverSuggestionData;
    }

    /**
     * Gets a new instance of SuggestionRequestDTO initialized with given parameters.
     *
     * @param caller       the caller
     * @param startZonedDT the start zoned date time
     * @param endZonedDT   the end zoned date time
     * @param stores       the stores
     * @return a new instance of SuggestionRequestDTO
     */
    public static SuggestionRequestDTO getSuggestionRequestDTO(final String caller, final ZonedDateTime startZonedDT,
                                                               final ZonedDateTime endZonedDT, final Integer... stores) {
        final SuggestionRequestDTO dto = new SuggestionRequestDTO();
        dto.setCaller(caller);
        dto.setStartTime(startZonedDT);
        dto.setEndTime(endZonedDT);
        dto.setStores(Arrays.asList(stores));
        dto.setDriverSuggestionType(AvailabilityType.ALL.name());
        dto.setIncludeAlreadyPublishedDrivers(true);
        dto.setMarket("LiverMore");
        dto.setRoundNumber(3);
        return dto;
    }

    /**
     * Populates the given collections for the test case.
     *
     * @param storeIds                       the store ids
     * @param storeIdVsAllDriversMap         a map of store id vs all drivers
     * @param storeIdVsAvailableDriversMap   a map of store id vs available drivers
     * @param storeIdVsUnavailableDriversMap a map of store id vs unavailable drivers
     */
    public static void populateStoreVsDriverMaps(final Integer[] storeIds, final Map<String, List<String>> storeIdVsAllDriversMap,
                                                 final Map<String, List<String>> storeIdVsAvailableDriversMap, final Map<String, List<String>> storeIdVsUnavailableDriversMap) {
        final Random random = new Random();
        for (final Integer storeID : storeIds) {
            int availableDriverCount = random.nextInt(5) + 1;
            int unavailableDriverCount = random.nextInt(5) + 1;

            final List<String> availableDrivers = new ArrayList<>();
            while (availableDriverCount > 0) {
                availableDrivers.add("available_abhi_" + availableDriverCount-- + "@walmartlabs.com");
            }

            final List<String> unavailableDrivers = new ArrayList<>();
            while (unavailableDriverCount > 0) {
                unavailableDrivers.add("unavailable_abhi_" + unavailableDriverCount-- + "@walmartlabs.com");
            }

            final String storeId = String.valueOf(storeID);
            storeIdVsAvailableDriversMap.put(storeId, availableDrivers);
            storeIdVsUnavailableDriversMap.put(storeId, unavailableDrivers);

            storeIdVsAllDriversMap.put(storeId, new ArrayList() {{
                addAll(availableDrivers);
                addAll(unavailableDrivers);
            }});
        }
    }

    /**
     * Gets a list of drivers with no schedules set.
     *
     * @param drivers the collection of drivers
     * @return a list of drivers with no schedules set
     */
    public static List<DriverScheduleEntity> getDriversWithNoSchedule(Collection<String> drivers) {
        List<DriverScheduleEntity> scheduleMap = new ArrayList<DriverScheduleEntity>();
        for (String driver : drivers) {
            DriverScheduleEntity driverScheduleEntity = new DriverScheduleEntity();
            driverScheduleEntity.setDriverUserId(driver);
            scheduleMap.add(driverScheduleEntity);
        }
        return scheduleMap;
    }

    /**
     * Converts the given min and max slot time WRT to the store time zone.
     *
     * @param storeTimeZone the store time zone
     * @param minSlotTime   the min slot time
     * @param maxSlotTime   the max slot time
     * @return converted slot time as a pair of min (first) and max (second) slot time
     */
    public static Pair<ZonedDateTime, ZonedDateTime> convertSlotTime(final String storeTimeZone, final ZonedDateTime minSlotTime, final ZonedDateTime maxSlotTime) {
        final ZoneId zoneId = ZoneId.of(storeTimeZone);
        final ZonedDateTime minSlotTimeConverted = minSlotTime.withZoneSameInstant(zoneId).with(AvailabilityManagerImpl.nextOrSameMinutes());
        final ZonedDateTime maxSlotTimeConverted = maxSlotTime.withZoneSameInstant(zoneId).with(AvailabilityManagerImpl.nextOrSameMinutes());
        return Pair.of(minSlotTimeConverted, maxSlotTimeConverted);
    }


    public static DriverDTO getDriverDTO(final String driverUserId, final String dateOfBirth) {
        final DriverDTO driverDTO = new DriverDTO();
        driverDTO.setDriverUserId(driverUserId);
        driverDTO.setDateOfBirth(dateOfBirth);
        ContactDTO contactDTO = new ContactDTO();
        contactDTO.setEmail(driverUserId);
        contactDTO.setPhoneNumber("8966360963");
        driverDTO.setContact(contactDTO);
        return driverDTO;
    }
}
