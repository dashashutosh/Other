package com.walmart.dms.biz.arranger;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.walmart.dms.common.utils.TimeUtils;
import com.walmart.dms.dal.jpa.entity.StoreConfig;
import com.walmart.dms.dal.jpa.service.StoreConfigDalService;
import com.walmart.dms.integration.elasticsearch.ESAPIImpl;
import com.walmart.dms.model.scheduling.dto.TripHitsDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.dms.biz.availability.ccm.DMSAvailabilityConfig;
import com.walmart.dms.common.enums.DriverOfferStatus;
import com.walmart.dms.common.enums.DriverSuggestionPriority;
import com.walmart.dms.common.enums.DriverType;
import com.walmart.dms.dal.jpa.custom.DriverTripCount;
import com.walmart.dms.dal.jpa.entity.DriverOfferDetailsEntity;
import com.walmart.dms.dal.jpa.repository.DriverTripDetailRepository;
import com.walmart.dms.dal.jpa.service.DriverOfferDetailsDALService;
import com.walmart.dms.integration.elasticsearch.ESDriverTripRequestDTO;
import com.walmart.dms.integration.elasticsearch.TripMatchDTO;
import com.walmart.dms.model.availability.dto.DriverOfferDetailsEsDto;
import com.walmart.dms.model.availability.dto.GetAvailableDriversRequestDTO;
import com.walmart.dms.model.onboarding.dto.DriverDTO;
import com.walmart.dms.model.scheduling.dto.ESDriverOfferTripResponseDTO;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RRDriverSlotArranger implements DriverSlotArranger {


    @Autowired
    private DMSAvailabilityConfig dmsAvailabilityConfig;

    @Autowired
    private DriverOfferDetailsDALService driverOfferDetailsDALService;

    @Autowired
    private ESAPIImpl esAPI;

    @Autowired
    private DriverTripDetailRepository driverTripDetailRepository;

    private Set<String> filterBackupTForceForCallers;

    @Autowired
    private StoreConfigDalService storeConfigDalService;

    private Set<String> allowedStatusForTripCount;
    
    @PostConstruct
    public void init() {
        filterBackupTForceForCallers = new HashSet<>();
        String filterStr = dmsAvailabilityConfig.getDmsSuggestionAPIFilterBackupAndTForceForCallers();
        if(StringUtils.isNotBlank(filterStr)) {
            Arrays.stream(filterStr.split(",")).forEach(s->filterBackupTForceForCallers.add(s));
        }
        log.info("filterBackupTForceForCallers:{}", filterBackupTForceForCallers);

        allowedStatusForTripCount = new HashSet<>(Arrays.asList("DELIVERED","COMPLETED"));
    }

    @Override
    public Map<String, DriverSuggestionPriority> arrange(Set<String> drivers, GetAvailableDriversRequestDTO request, ZonedDateTime startTime, ZonedDateTime endTime, Map<String, List<DriverDTO>> userIdToDtoMap) {

        log.info("Querying for request:{}, startTime:{}, endTime:{}, drivers:{}", request, startTime, endTime, drivers);
        String storeId = request.getStoreId();
        List<DriverOfferDetailsEntity> driverOfferDetailsEntities = driverOfferDetailsDALService.getDriversWithExpiredAndRejectedStatus(drivers, 
                startTime, endTime);

        log.info("Driver Offers returned:{}", driverOfferDetailsEntities);
        Map<String, Integer> driverIdsToTripCountMap = getTripsCountForDrivers(drivers, endTime);

        Map<String, DriverSuggestionPriority> driversWithPriority = arrangeDrivers(storeId, drivers, driverOfferDetailsEntities, request, driverIdsToTripCountMap, userIdToDtoMap);
        driversWithPriority = limitDrivers(driversWithPriority);
        
        return driversWithPriority;
    }

    private Map<String, DriverSuggestionPriority> limitDrivers(Map<String, DriverSuggestionPriority> drivers) {

        if (drivers.size() <= dmsAvailabilityConfig.getDmsDriverAvailabilityResultLimit()) {
            return drivers;
        }

        return drivers.entrySet().stream().limit(dmsAvailabilityConfig.getDmsDriverAvailabilityResultLimit())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (v1,v2) -> v1,
                        LinkedHashMap::new));
    }

	protected Map<String, Map<String, ESDriverTripRequestDTO>> createESDriverTripRequest(String storeId,
			GetAvailableDriversRequestDTO request) {
		ESDriverTripRequestDTO driverTripRequestDTO = new ESDriverTripRequestDTO();
		List<TripMatchDTO> matchDTOList = new ArrayList<TripMatchDTO>();
		TripMatchDTO tripMatchDTOSlot = new TripMatchDTO();
		TripMatchDTO tripMatchDTOStoreId = new TripMatchDTO();
        TripMatchDTO tripMatchDTODate = new TripMatchDTO();
		Map<String, String> slotMap = new HashMap<String, String>();
        StoreConfig storeConfig = storeConfigDalService.findByStoreId(storeId);
        slotMap.put("slot", TimeUtils.getDateInHHmmFormate(request.getSlots().get(0).getStartTime(), ZoneId.of(storeConfig.getTimeZone())));
        Map<String, String> dateMap = new HashMap<String, String>();
        dateMap.put("tripDate",TimeUtils.getDateInYYYYMMDDFormate(request.getSlots().get(0).getStartTime(), ZoneId.of(storeConfig.getTimeZone())));
		Map<String, String> storeIdMap = new HashMap<String, String>();
		storeIdMap.put("storeId", storeId);
		tripMatchDTOSlot.setMatch(slotMap);
		tripMatchDTOStoreId.setMatch(storeIdMap);
		tripMatchDTODate.setMatch(dateMap);
		matchDTOList.add(tripMatchDTOSlot);
		matchDTOList.add(tripMatchDTOStoreId);
		matchDTOList.add(tripMatchDTODate);
		driverTripRequestDTO.setMust(matchDTOList);
		Map<String, ESDriverTripRequestDTO> bool = new HashMap<String, ESDriverTripRequestDTO>();
		Map<String, Map<String, ESDriverTripRequestDTO>> query = new HashMap<String, Map<String, ESDriverTripRequestDTO>>();
		bool.put("bool", driverTripRequestDTO);
		query.put("query", bool);

		return query;
	}

	protected Set<String> rearrangeExpiredDrivers(Set<String> priorityWiseListForExpiredDrivers, String storeId,
			GetAvailableDriversRequestDTO request) {
		if (priorityWiseListForExpiredDrivers.size() > 1) {
			ESDriverOfferTripResponseDTO res;
			try {
                Map<String, Map<String, ESDriverTripRequestDTO>> esTripRequest = createESDriverTripRequest(storeId, request);
                res = esAPI.getDriverTripOfferDetail(esTripRequest);
                if (res != null && res.getHits() != null && res.getHits().getHits() != null && res.getHits().getHits().size() > 0) {
                    priorityWiseListForExpiredDrivers =  rearrangeExpiredDriver(priorityWiseListForExpiredDrivers, res);
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                log.error("Rearranging the expired Drivers Failed for request:{} and Expired Driver List:{}", request,
                        priorityWiseListForExpiredDrivers);
                log.error("Exception: ", e);
            }

		}
		return priorityWiseListForExpiredDrivers;
	}

    private Map<String, DriverSuggestionPriority> arrangeDrivers(String storeId, Set<String> selectedDrivers, List<DriverOfferDetailsEntity> driverOfferDetailsEntities,  GetAvailableDriversRequestDTO request,
                                       Map<String, Integer> driverIdsToTripCountMap, Map<String, List<DriverDTO>> userIdToDtoMap) {
        //  driverIdsToTripCountMap.size() == 0) && CollectionUtils.isEmpty(driverOfferDetailsEntities)
        if ((driverIdsToTripCountMap == null || driverOfferDetailsEntities == null)) {
            return selectedDrivers.stream().collect(Collectors.toMap(Function.identity(), s -> DriverSuggestionPriority.valueOf(0),
                    (v1,v2) -> v1,
                    LinkedHashMap::new));
        }
        Set<String>[] priorityWiseList = new LinkedHashSet[DriverSuggestionPriority.values().length];
        for (int i = 0; i < priorityWiseList.length; i++) {
            priorityWiseList[i] = new LinkedHashSet<>();
        }
        for (String driverId : selectedDrivers) {
            DriverSuggestionPriority driverSuggestionPriority = priority(storeId, driverId, driverOfferDetailsEntities, request, driverIdsToTripCountMap, userIdToDtoMap);

            if (!driverSuggestionPriority.isEligibleForSuggestion() && StringUtils.isNotEmpty(request.getCaller())) {
                continue;
            }
            priorityWiseList[driverSuggestionPriority.getPriority()].add(driverId);
		}
		priorityWiseList[DriverSuggestionPriority.EXPIRED_IN_STORE.getPriority()] = rearrangeExpiredDrivers(
				priorityWiseList[DriverSuggestionPriority.EXPIRED_IN_STORE.getPriority()], storeId, request);

		return flatten(priorityWiseList);
    }

    private DriverSuggestionPriority priority(String storeId, String driverId, List<DriverOfferDetailsEntity> driverOfferDetailsEntities, GetAvailableDriversRequestDTO request,
                         Map<String, Integer> driverIdsToTripCountMap, Map<String, List<DriverDTO>> userIdToDtoMap) {

        DriverSuggestionPriority priority = DriverSuggestionPriority.SELECTED;
        if(ignoreDriver(request.getCaller(), driverId, userIdToDtoMap)) {
            priority = DriverSuggestionPriority.REJECTED_IN_STORE;
            return priority;
        }
        
        List<DriverOfferDetailsEntity> matchedDriverOfferDetailsEntities = new ArrayList<>();

        for(DriverOfferDetailsEntity driverOfferDetailsEntity : driverOfferDetailsEntities) {
            if (driverId.equals(driverOfferDetailsEntity.getId().getDriverId())) {
                matchedDriverOfferDetailsEntities.add(driverOfferDetailsEntity);
            }
        }

        Integer tripCount = driverIdsToTripCountMap.get(driverId) == null ? 0 :
                driverIdsToTripCountMap.get(driverId);

        if (tripCount > dmsAvailabilityConfig.getDmsSuggestionApiMaxTripCountForStarvation()) {
            priority = DriverSuggestionPriority.STARVED;
        }

        for (DriverOfferDetailsEntity driverOfferDetailsEntity : matchedDriverOfferDetailsEntities) {
            DriverSuggestionPriority newPriority = priority(storeId, driverOfferDetailsEntity);

            if (newPriority.getPriority() > priority.getPriority()) {
                priority = newPriority;
            }
        }

        return priority;
    }

    private DriverSuggestionPriority priority(String storeId, DriverOfferDetailsEntity driverOfferDetailsEntity) {



        if (storeId.equals(driverOfferDetailsEntity.getId().getStoreId())) {
            if (DriverOfferStatus.EXPIRED.equals(driverOfferDetailsEntity.getStatus())) {
                return DriverSuggestionPriority.EXPIRED_IN_STORE;
            }

            if (DriverOfferStatus.REJECTED.equals(driverOfferDetailsEntity.getStatus())) {
                return DriverSuggestionPriority.REJECTED_IN_STORE;
            }
        }

        if (DriverOfferStatus.REJECTED.equals(driverOfferDetailsEntity.getStatus())) {
            return DriverSuggestionPriority.REJECTED_IN_MARKET;
        }

        return DriverSuggestionPriority.SELECTED;
    }


    protected boolean ignoreDriver(String caller,
            String driverUserId, Map<String, List<DriverDTO>> userIdToDtoMap) {
        //Filter Backup and TForce drivers for certain callers.
        DriverDTO driverDTO = null;
        if(CollectionUtils.isNotEmpty(userIdToDtoMap.get(driverUserId))) {
            driverDTO = userIdToDtoMap.get(driverUserId).get(0);
        } else {
            return true;
        }
        if(StringUtils.isNotBlank(caller) && filterBackupTForceForCallers.contains(caller)) {
            if(DriverType.BACKUP.equals(driverDTO.getDriverType()) || DriverType.TFORCE.equals(driverDTO.getDriverType())) {
                log.info("Removing driver: {} from suggestion list", driverUserId);
                return true;
            }
        }
        return false;
    }

    private Map<String, DriverSuggestionPriority> flatten(Set<String>[] lists) {

        Map<String, DriverSuggestionPriority> drivers = new LinkedHashMap<>();

        for (int i = 0; i < lists.length; i++) {

            final int priority = i;

            if(lists[i] != null && lists[i].size() > 0) {
                Map<String, DriverSuggestionPriority> map = lists[i].stream().collect(Collectors.toMap(Function.identity(), s -> DriverSuggestionPriority.valueOf(priority),
                        (u,v) -> { return u; },
                        LinkedHashMap::new));

                drivers.putAll(map);
            }
        }

        return drivers;
    }

    private Map<String, Integer> getTripsCountForDrivers(Set<String> uniqueDriverIds, ZonedDateTime maxTime) {

        if(CollectionUtils.isEmpty(uniqueDriverIds)) {
            return Collections.emptyMap();
        }
        long endTime = maxTime.toInstant().toEpochMilli();
        long startTime = maxTime.minusDays(dmsAvailabilityConfig.getDmsSuggestionApiDaysForTripCountForStarvation()).toInstant().toEpochMilli();


        List<DriverTripCount> tripCountTupleByDriver = driverTripDetailRepository.countDriversTripDetail(uniqueDriverIds, startTime, endTime, allowedStatusForTripCount);
        Map<String, Integer> tripCountMap = new HashMap<>();

        for (DriverTripCount tuple : tripCountTupleByDriver) {
            tripCountMap.put(tuple.getDriverId(), tuple.getTripCount());
        }
        log.info("tripCountMap for Drivers to avoid starvation: {}",tripCountMap);
        return tripCountMap;
    }

    private Set<String> rearrangeExpiredDriver(Set<String> priorityWiseListForExpiredDrivers, ESDriverOfferTripResponseDTO res){
        List<String> expiredDriversList = new ArrayList<>(priorityWiseListForExpiredDrivers);
        Map<String, Integer> mapExpiredDriverCount = new HashMap<String, Integer>();

        for (String expiredDriver : expiredDriversList) {
            mapExpiredDriverCount.put(expiredDriver, 0);
        }

        for (TripHitsDTO tripHitsDTO : res.getHits().getHits()) {
            DriverOfferDetailsEsDto driverOfferDetailsEsDto = tripHitsDTO.getSource();

            if (driverOfferDetailsEsDto == null || driverOfferDetailsEsDto.getExpiryDriverIds() == null) {
                continue;
            }

            List<String> expiredDriversES = driverOfferDetailsEsDto.getExpiryDriverIds();
            for (String driver : expiredDriversES) {
                if (mapExpiredDriverCount.get(driver) != null) {
                    mapExpiredDriverCount.put(driver, mapExpiredDriverCount.get(driver) + 1);
                } else {
                    continue;
                }
            }
        }

        Comparator<String> expiredDriverComparator = Comparator.comparing((String d) -> d,
                new ExpiredDriversComparator(mapExpiredDriverCount, expiredDriversList));

        log.info("before expiry count sorting" + expiredDriversList);
        expiredDriversList.sort(expiredDriverComparator);
        log.info("after expiry count sorting" + expiredDriversList);

        priorityWiseListForExpiredDrivers = new LinkedHashSet<>();
        for (String expiredDriver : expiredDriversList) {
            priorityWiseListForExpiredDrivers.add(expiredDriver);
        }
        return priorityWiseListForExpiredDrivers;
    }
}
