package com.walmart.dms.biz.scheduler;

import com.walmart.dms.model.availability.dto.GetAvailableDriversRequestDTO;

import java.time.ZonedDateTime;
import java.util.Set;

public interface DriverSlotArranger {

    Set<String> arrange(Set<String> drivers, String marketId, GetAvailableDriversRequestDTO storeId, ZonedDateTime startTime, ZonedDateTime endTime);
}
