package com.walmart.dms.biz.arranger;

import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

;

public class ExpiredDriversComparator implements Comparator<String>, Serializable {
	private static final long serialVersionUID = 1L;

	private Map<String, Integer> driverExpiredMap;
	private List<String> drivers;

	public ExpiredDriversComparator(Map<String, Integer> mapExpiredDriverCount, List<String> drivers) {
		this.driverExpiredMap = mapExpiredDriverCount;
		this.drivers = drivers;
	}

	@Override
	public int compare(String d1, String d2) {
		if (driverExpiredMap.get(d1) > driverExpiredMap.get(d2)) {
			return 1;
		} else if (driverExpiredMap.get(d1) < driverExpiredMap.get(d2)) {
			return -1;
		}
		return 0;
	}

}