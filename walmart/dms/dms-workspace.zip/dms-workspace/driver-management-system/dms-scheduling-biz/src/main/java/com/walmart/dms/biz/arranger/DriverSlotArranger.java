package com.walmart.dms.biz.arranger;

import com.walmart.dms.common.enums.DriverSuggestionPriority;
import com.walmart.dms.model.availability.dto.GetAvailableDriversRequestDTO;
import com.walmart.dms.model.onboarding.dto.DriverDTO;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface DriverSlotArranger {

    Map<String, DriverSuggestionPriority> arrange(Set<String> drivers, GetAvailableDriversRequestDTO request, ZonedDateTime startTime, ZonedDateTime endTime, Map<String, List<DriverDTO>> userIdToDtoMap);
}
