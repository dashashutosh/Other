package com.walmart.dms.scheduler;

import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

/**
 * Super Mockito test class for the mockito test classes.
 *
 * @author a0d02yr
 */
@Slf4j
@RunWith(MockitoJUnitRunner.class)
public class MockitoTest {

    @Test
    public void contextLoads() {
        String value = "Initialized Mockito successfully";
        log.info(value);
        assertEquals("Initialized Mockito successfully", value);
    }
    /**
     * Fails the test case with given throwable as unexpected throwable.
     *
     * @param t the throwable
     */
    public void failTestWithUnexpectedThrowable(final Throwable t) {
        t.printStackTrace();
        Assert.fail("Unexpected exception occurred: " + t.getMessage());
    }
}
