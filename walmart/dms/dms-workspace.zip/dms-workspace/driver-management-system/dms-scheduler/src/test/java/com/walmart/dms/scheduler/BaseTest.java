package com.walmart.dms.scheduler;

import com.walmart.dms.common.enums.AuthenticationProvider;
import com.walmart.dms.common.enums.DeactivationType;
import com.walmart.dms.common.enums.DriverProgram;
import com.walmart.dms.common.enums.DriverStatus;
import com.walmart.dms.common.enums.DriverSubType;
import com.walmart.dms.common.enums.DriverType;
import com.walmart.dms.common.enums.HiringProvider;
import com.walmart.dms.common.enums.OnBoardingState;
import com.walmart.dms.common.enums.PaymentProvider;
import com.walmart.dms.common.enums.PictureStatus;
import com.walmart.dms.common.enums.Tenant;
import com.walmart.dms.common.enums.Vertical;
import com.walmart.dms.dal.jpa.entity.DmsReasonCodeConfigEntity;
import com.walmart.dms.dal.jpa.entity.DriverAddressEntity;
import com.walmart.dms.dal.jpa.entity.DriverAssociatedStoreEntity;
import com.walmart.dms.dal.jpa.entity.DriverEntity;
import com.walmart.dms.dal.jpa.entity.DriverExtensionEntity;
import com.walmart.dms.dal.jpa.entity.DriverProgramEntity;
import com.walmart.dms.dal.jpa.entity.DriverVehicleEntity;
import com.walmart.dms.dal.jpa.entity.key.DriverEntityPK;
import com.walmart.dms.model.dto.DriverPictureDetailsDTO;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertEquals;

public class BaseTest {

    protected DriverEntity createDriverEntity(OnBoardingState onBoardingState, DriverStatus status, Boolean isActive) {
        return createDriverEntity("Shubhangi.Priya@walmartlabs.com", onBoardingState, status, isActive);
    }

    protected DriverEntity createDriverEntity(String driverId, OnBoardingState onBoardingState, DriverStatus status, Boolean isActive) {
        List<DriverAddressEntity> driverAddressEntityList = new ArrayList<>();
        List<DriverVehicleEntity> driverVehiclesEntityList = new ArrayList<>();
        List<DriverAssociatedStoreEntity> associatedStores = new ArrayList<>();

        DriverVehicleEntity addedVehicle = new DriverVehicleEntity();
        addedVehicle.setVehicleUUID("987");
        addedVehicle.setType("mercedes");
        addedVehicle.setMake("yamaha");
        addedVehicle.setModel("MercedesBenzGLEClass");
        addedVehicle.setLicensePlate("999");
        driverVehiclesEntityList.add(addedVehicle);

        DriverEntityPK driverEntityPK = new DriverEntityPK();
        driverEntityPK.setUserId(driverId);
        driverEntityPK.setProgramUUID("101");

        DriverProgramEntity driverProgramEntity = new DriverProgramEntity();
        driverProgramEntity.setProgramId("101");
        LocalDate dateOfBirth = LocalDate.of(1994, 1, 1);

        DriverEntity entity = new DriverEntity();
        entity.setId(driverEntityPK);
        entity.setProgram(driverProgramEntity);
        entity.setExternalId("777");
        entity.setFirstName("Shubhangi");
        entity.setMiddleName("Walmart");
        entity.setLastName("Priya");
        entity.setDateOfBirth(dateOfBirth);
        entity.setOnBoardingState(onBoardingState);
        entity.setHiringComments("nice");
        entity.setStatus(status);
        entity.setCityOfInterest("Bengaluru");
        entity.setPictureUrl("url");
        entity.setEmail(driverId);
        entity.setMobile("987654321");
        entity.setMobileOS("BlackBerry");
        entity.setPaymentRegistrationLink("payurl");
        entity.setPaymentRegistrationId("payid");
        entity.setIsActive(isActive);
        entity.setAddresses(driverAddressEntityList);
        entity.setVehicles(driverVehiclesEntityList);
        entity.setAssociatedStores(associatedStores);
        entity.setDriverType(DriverType.REGULAR);

        associatedStores.add(getDriverAssociatedStoreEntity(entity, "1234"));
        associatedStores.add(getDriverAssociatedStoreEntity(entity, "567"));

        return entity;
    }

    protected DriverAssociatedStoreEntity getDriverAssociatedStoreEntity(DriverEntity driverEntity, String storeId) {

        DriverAssociatedStoreEntity driverAssociatedStoreEntity = new DriverAssociatedStoreEntity();
        driverAssociatedStoreEntity.setActive(true);
        driverAssociatedStoreEntity.setAssociatedStoreId(storeId);
        driverAssociatedStoreEntity.setDriver(driverEntity);

        return driverAssociatedStoreEntity;
    }

    protected DriverEntity createDriverEntityForDriverDetails(String driverUserId, String email, Boolean activeStatus, DriverType driverType, DriverSubType driverSubType) {
        DriverProgramEntity programEntity = new DriverProgramEntity();
        programEntity.setName("SWIFT");
        programEntity.setProgramId("8aa5f272636298ec016362c5ea780000");
        programEntity.setTenantId(Tenant.US);
        programEntity.setVerticalId(Vertical.GROCERIES);
        programEntity.setAuthProvider(AuthenticationProvider.WALMART_IAM);
        programEntity.setFlowFileName("swift-program-flow.xml");
        programEntity.setHiringProvider(HiringProvider.DDI);
        programEntity.setPaymentProvider(PaymentProvider.DDI);

        DriverEntity driverEntity = new DriverEntity();
        DriverEntityPK driverEntityPK1 = new DriverEntityPK();
        driverEntityPK1.setUserId(driverUserId);
        driverEntityPK1.setProgramUUID(DriverProgram.SWIFT.getProgramId());
        driverEntity.setId(driverEntityPK1);
        driverEntity.setDriverType(driverType);
        driverEntity.setDriverSubType(driverSubType);
        driverEntity.setEmail(email);
        driverEntity.setDriverLicenseExpiry(LocalDate.of(2025, 1, 1));
        driverEntity.setDriverLicenseNo("FICC545453");
        driverEntity.setDriverUUID(UUID.fromString("1fc01163-8034-4eae-a5dc-a5663dfa5754"));
        driverEntity.setProgram(programEntity);
        driverEntity.setFirstName("Sam");
        driverEntity.setLastName("Walton");
        driverEntity.setIsActive(activeStatus);
        driverEntity.setStatus(DriverStatus.APPROVED);
        driverEntity.setDeactivationType(DeactivationType.NONE);
        driverEntity.setOnBoardingState(OnBoardingState.ONBOARDING_SUCCESS);

        DriverExtensionEntity driverExtensionEntity = new DriverExtensionEntity();
        driverExtensionEntity.setDriver(driverEntity);
        driverExtensionEntity.setWinNumber(12345678L);
        driverExtensionEntity.setBadgeId("ABcCiVxJRVytNU0MEjrCyR");
        driverExtensionEntity.setPictureUrl(null);
        driverExtensionEntity.setPictureStatus(PictureStatus.PHOTO_NOT_SUBMITTED);
        driverExtensionEntity.setUpdatedBy("m0m0qvd");

        DmsReasonCodeConfigEntity reasonCodeConfigEntity = new DmsReasonCodeConfigEntity();
        reasonCodeConfigEntity.setReasonCode("DMS801");
        reasonCodeConfigEntity.setReasonCodeDescription("Image not clear");

        DriverPictureDetailsDTO driverPictureDetailsDTO = new DriverPictureDetailsDTO();
        driverPictureDetailsDTO.setPictureUrl("http://blob.com");
        driverPictureDetailsDTO.setPictureStatus(PictureStatus.REVIEW_NEEDED);
        driverPictureDetailsDTO.setUpdatedBy("m0m0qvd");
        driverEntity.setHireDate("2022-12-12");
        driverEntity.setWinNumber(12345678L);
        driverEntity.setDriverTimeZone("America/Chicago");
        return driverEntity;
    }
    @Test
    public void test(){
        String str = "test";
        String str1 = "test";
        assertEquals(str,str1);
    }
}
