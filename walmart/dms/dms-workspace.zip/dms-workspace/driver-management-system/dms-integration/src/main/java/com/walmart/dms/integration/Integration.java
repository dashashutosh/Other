package com.walmart.dms.integration;

/**
 * @author n0a008p on Mar 4, 2018
 *
 */
public interface Integration {

}
