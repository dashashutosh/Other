package com.walmart.dms.common.utils;

import com.walmart.dms.server.common.exception.BusinessException;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;


public class AuthorizationUtilsTest {

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @InjectMocks
    private AuthorizationUtils authorizationUtils;

    @Test(expected = BusinessException.class)
    public void isCarrierAdminRoleTest() throws Exception {
        authorizationUtils.isCarrierAdminRole("abc@gmail.com", "CARRIER_ADMIN");
        authorizationUtils.isCarrierAdminRole("abc@gmail.com", "DRIVER");
    }

    @Test(expected = BusinessException.class)
    public void validateAuthCheckForScacTest() throws Exception {
        authorizationUtils.validateAuthCheckForScac("abc@gmail.com", "abc", "abc");
        authorizationUtils.validateAuthCheckForScac("abc@gmail.com", "abc", "def");
    }

    @Test()
    public void validateAuthCheckForScacInputScacNullTest() throws Exception {
        assertDoesNotThrow(() -> authorizationUtils.validateAuthCheckForScac("abc@gmail.com", null, "abc"));
    }
}
