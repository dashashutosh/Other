package com.walmart.dms.common.utils;

import com.walmart.dms.common.config.CommonConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * Test class for LogUtil class.
 *
 * @author a0d02yr
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class LogUtilTest {

    private static final String payload_100_char = "1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111";

    private static final String payload_1000_char;

    static {
        final StringBuilder strBuilder = new StringBuilder();
        for (int count = 0; count < 10; count++) {
            strBuilder.append(payload_100_char);
        }
        payload_1000_char = strBuilder.toString();
    }

    @InjectMocks
    private LogUtil logUtil;

    @Mock
    private CommonConfig commonConfig;

    /**
     * Tests getLogPayload() method with positive use case. Use case is to pass a string argument with length less than
     * than maximum length configured, disable the truncation flag and expect it not to be truncated.
     */
    @Test
    public void testGetLogPayload_Positive_1() {
        Mockito.when(commonConfig.isLogTruncationEnabled()).thenReturn(false);

        final String logPayload = logUtil.getLogPayload(payload_100_char);

        Mockito.verify(commonConfig, Mockito.times(1)).isLogTruncationEnabled();
        Mockito.verify(commonConfig, Mockito.times(0)).getLogTruncationMaxCharLength();

        Assert.assertNotNull(logPayload);
        Assert.assertEquals(payload_100_char.length(), logPayload.length());
    }

    /**
     * Tests getLogPayload() method with positive use case. Use case is to pass a string argument with length greater
     * than maximum length configured, disable the truncation flag and expect it not to be truncated.
     */
    @Test
    public void testGetLogPayload_Positive_2() {
        Mockito.when(commonConfig.isLogTruncationEnabled()).thenReturn(false);
        final String logPayload = logUtil.getLogPayload(payload_1000_char);

        Mockito.verify(commonConfig, Mockito.times(1)).isLogTruncationEnabled();
        Mockito.verify(commonConfig, Mockito.times(0)).getLogTruncationMaxCharLength();

        Assert.assertNotNull(logPayload);
        Assert.assertEquals(payload_1000_char.length(), logPayload.length());
    }

    /**
     * Tests getLogPayload() method with positive use case. Use case is to pass a string argument with length less than
     * maximum length configured, enable the truncation flag a and expect it not to be truncated.
     */
    @Test
    public void testGetLogPayload_Positive_3() {
        Mockito.when(commonConfig.isLogTruncationEnabled()).thenReturn(true);
        Mockito.when(commonConfig.getLogTruncationMaxCharLength()).thenReturn(1000);

        final String logPayload = logUtil.getLogPayload(payload_100_char);

        Mockito.verify(commonConfig, Mockito.times(1)).isLogTruncationEnabled();
        Mockito.verify(commonConfig, Mockito.times(1)).getLogTruncationMaxCharLength();

        Assert.assertNotNull(logPayload);
        Assert.assertEquals(payload_100_char.length(), logPayload.length());
    }

    /**
     * Tests getLogPayload() method with positive use case. Use case is to pass a string argument with length equal
     * maximum length configured, enable the truncation flag a and expect it not to be truncated.
     */
    @Test
    public void testGetLogPayload_Positive_4() {
        Mockito.when(commonConfig.isLogTruncationEnabled()).thenReturn(true);
        Mockito.when(commonConfig.getLogTruncationMaxCharLength()).thenReturn(1000);

        final String logPayload = logUtil.getLogPayload(payload_1000_char);

        Mockito.verify(commonConfig, Mockito.times(1)).isLogTruncationEnabled();
        Mockito.verify(commonConfig, Mockito.times(1)).getLogTruncationMaxCharLength();

        Assert.assertNotNull(logPayload);
        Assert.assertEquals(payload_1000_char.length(), logPayload.length());
    }

    /**
     * Tests getLogPayload() method with positive use case. Use case is to pass a string argument with length greater
     * than maximum length configured, enable the truncation flag a and expect it to be truncated.
     */
    @Test
    public void testGetLogPayload_Positive_5() {
        Mockito.when(commonConfig.isLogTruncationEnabled()).thenReturn(true);
        Mockito.when(commonConfig.getLogTruncationMaxCharLength()).thenReturn(500);

        final String logPayload = logUtil.getLogPayload(payload_1000_char);

        Mockito.verify(commonConfig, Mockito.times(1)).isLogTruncationEnabled();
        Mockito.verify(commonConfig, Mockito.times(2)).getLogTruncationMaxCharLength();

        Assert.assertNotNull(logPayload);
        Assert.assertEquals(500 + LogUtil.TRUNCATION_SUFFIX.length(), logPayload.length());
        Assert.assertTrue(logPayload.contains(LogUtil.TRUNCATION_SUFFIX));
    }

    /**
     * Tests getLogPayload() method with positive use case. Use case is to pass an object argument with toString()
     * length greater maximum length configured, enable the truncation flag a and expect it to be truncated.
     */
    //@Test
    public void testGetLogPayload_Positive_6() {
        Mockito.when(commonConfig.isLogTruncationEnabled()).thenReturn(true);
        Mockito.when(commonConfig.getLogTruncationMaxCharLength()).thenReturn(500);

        final Object payloadObj = new String(payload_1000_char);
        final String logPayload = logUtil.getLogPayload(payloadObj);

        Mockito.verify(commonConfig, Mockito.times(1)).isLogTruncationEnabled();
        Mockito.verify(commonConfig, Mockito.times(2)).getLogTruncationMaxCharLength();

        Assert.assertNotNull(logPayload);
        Assert.assertEquals(500 + LogUtil.TRUNCATION_SUFFIX.length(), logPayload.length());
        Assert.assertTrue(logPayload.contains(LogUtil.TRUNCATION_SUFFIX));
    }

    /**
     * Tests getLogPayload() method with negative use case. Use case is to pass an null string and expect empty string
     * to be returned.
     */
    @Test
    public void testGetLogPayload_Negative_1() {
        Mockito.when(commonConfig.isLogTruncationEnabled()).thenReturn(true);
        Mockito.when(commonConfig.getLogTruncationMaxCharLength()).thenReturn(500);

        final String logPayload = logUtil.getLogPayload(null);

        Mockito.verify(commonConfig, Mockito.times(0)).isLogTruncationEnabled();
        Mockito.verify(commonConfig, Mockito.times(0)).getLogTruncationMaxCharLength();

        Assert.assertNotNull(logPayload);
        Assert.assertEquals(0, logPayload.length());
    }

    /**
     * Tests getLogPayload() method with negative use case. Use case is to pass an null object and expect empty string
     * to be returned.
     */
    //@Test
    public void testGetLogPayload_Negative_2() {
        Mockito.when(commonConfig.isLogTruncationEnabled()).thenReturn(true);
        Mockito.when(commonConfig.getLogTruncationMaxCharLength()).thenReturn(500);

        final String logPayload = logUtil.getLogPayload((Object) null);

        Mockito.verify(commonConfig, Mockito.times(0)).isLogTruncationEnabled();
        Mockito.verify(commonConfig, Mockito.times(0)).getLogTruncationMaxCharLength();

        Assert.assertNotNull(logPayload);
        Assert.assertEquals(0, logPayload.length());
    }
}
