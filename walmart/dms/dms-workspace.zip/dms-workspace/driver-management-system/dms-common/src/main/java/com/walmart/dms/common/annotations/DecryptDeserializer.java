package com.walmart.dms.common.annotations;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.walmart.dms.common.utils.EncryptDecryptUtil;

import java.io.IOException;

public class DecryptDeserializer extends JsonDeserializer<Object> {

    @Override
    public Object deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
        return EncryptDecryptUtil.decrypt(jsonParser.getText());
    }
}
