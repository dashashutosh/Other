package com.walmart.dms.common.queue;

import java.lang.Thread.State;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ProcessingThreads<E extends WorkerThread<QueueItem>> {

	private int numThreads = 1;
	private ArrayList<E> workerThreads;
	private E worker;

	public ProcessingThreads(E worker, int numThreads) {
		this.numThreads = numThreads;
		this.worker = worker;
		workerThreads = new ArrayList<E>(numThreads);
		if (numThreads > 0) {
			for (int i = 0; i < numThreads; i++) {
				startWorker(worker.getInstance(), i);
			}
		} else {
			log.error("[ProcessingThreads] Invalid numThreads");
		}
	}

	public void restartWorker() {
		log.info("[ProcessingThreads] restartWorker called numThreads:" + numThreads);
		terminate();
		workerThreads.clear();
		workerThreads = new ArrayList<E>(numThreads);
		if (numThreads > 0) {
			for (int i = 0; i < numThreads; i++) {
				startWorker(worker.getInstance(), i);
			}
		}

	}

	public ProcessingThreads(E worker, int numThreads, boolean exceptionLog) {
		// ProcessingThreads Method with 3 argument
	}

	public ProcessingThreads(E worker, int numThreads, long timeout, TimeUnit timeunit) {
		// ProcessingThreads Method with 4 argument
	}

	public ProcessingThreads(E worker, int numThreads, long timeout, TimeUnit timeunit, boolean exceptionLog) {
		// ProcessingThreads Method with 5 argument
	}

	@SuppressWarnings("unchecked")
	private void startWorker(WorkerThread<QueueItem> worker, int i) {
		worker.setName("QueueWorker - " + worker.getClass().getCanonicalName() + " - " + i);
		worker.start();
		workerThreads.add((E) worker);
		log.info("[ProcessingThreads] Worker:{} started", worker.getName());
	}

	public void offer(QueueItem e) {
		E consumer = workerThreads.get(Math.abs(e.hashCode() % numThreads));
		consumer.offer(e);
	}

	public void add(QueueItem e) {
		E consumer = workerThreads.get(Math.abs(e.hashCode() % numThreads));
		consumer.add(e);
	}

	public void put(QueueItem e) throws InterruptedException {
		E consumer = workerThreads.get(Math.abs(e.hashCode() % numThreads));
		consumer.put(e);
	}

	public int size() {
		int size = 0;
		for (E workers : workerThreads) {
			size += workers.size();
		}
		return size;
	}

	public boolean isProcessing() {
		boolean processing = false;
		for (E workers : workerThreads) {
			log.info(workers.getState().toString() + " " + workers.isLock());
			if (workers.getState() != State.WAITING || workers.isLock()) {
				processing = true;
				break;
			}
		}
		return processing;
	}

	@SuppressWarnings("deprecation")
	public void terminate() {
		try {
			log.info("[ProcessingThreads] terminate called");
			for (E e : workerThreads) {
				e.stopWorker();
				e.interrupt();
//				e.destroy();
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

	}

}