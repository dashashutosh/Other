package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

/**
 * DMS event config class.
 *
 * @author a0d02yr
 */
@Data
@Configuration(configName = "dmsEventsConfig")
public class DMSEventsConfig {

	@Property(propertyName = "dms.reporting.events.kafka.topic")
	private String dmsReportingEventsKafkaTopic;

	@Property(propertyName = "dms.reporting.events.kafka.cluster")
	private String dmsReportingEventsKafkaCluster;

	@Property(propertyName = "dms.reporting.order.payment.event.schema.id")
	private String dmsReportingOrderPaymentEventSchemaId;

	@Property(propertyName = "dms.reporting.tip.payment.event.schema.id")
	private String dmsReportingTipPaymentEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.payment.transaction.event.schema.id")
    private String dmsReportingDriverPaymentTransactionEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.payment.trip.event.schema.id")
    private String dmsReportingDriverPaymentTripEventSchemaId;

	@Property(propertyName = "dms.reporting.store.rate.card.event.schema.id")
    private String dmsReportingStoreRateCardEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.feedback.event.schema.id")
	private String dmsReportingDriverFeedbackEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.created.event.schema.id")
	private String dmsReportingDriverCreatedEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.updated.event.schema.id")
	private String dmsReportingDriverUpdatedEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.activated.event.schema.id")
	private String dmsReportingDriverActivatedEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.deactivated.event.schema.id")
	private String dmsReportingDriverDeactivatedEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.suspended.event.schema.id")
	private String dmsReportingDriverSuspendedEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.schedule.updated.event.schema.id")
	private String dmsReportingDriverScheduleUpdatedEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.zone.migrated.event.schema.id")
	private String dmsReportingDriverZoneMigratedEventSchemaId;

	@Property(propertyName = "dms.reporting.reason.code.config.event.schema.id")
    private String dmsReportingReasonCodeConfigEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.relation.event.schema.id")
    private String dmsReportingDriverRelationEventSchemaId;

	@Property(propertyName = "dms.reporting.update.driver.task.provider.schema.id")
	private String  dmsReportingUpdateDriverTaskProviderSchemaId;

	@Property(propertyName = "dms.reporting.driver.booster.offer.create.schema.id")
	private String dmsReportingDriverBoosterOfferCreateSchemaId;

	@Property(propertyName = "dms.reporting.driver.score.updated.schema.id")
	private String dmsReportingDriverScoreUpdatedSchemaId;

	@Property(propertyName = "dms.reporting.driver.referral.joined.event.schema.id")
	private String dmsReportingDriverReferralJoinedEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.batching.preference.updated.schema.id")
	private String dmsReportingDriverBatchingPreferenceUpdatedSchemaId;

	@Property(propertyName = "dms.reporting.driver.booster.offer.updated.event.schema.id")
	private String dmsReportingDriverBoosterOfferUpdatedEventSchemaId;

	@Property(propertyName = "dms.reporting.legal.doc.status.event.schema.id")
	private String dmsReportingLegalDocStatusEventSchemaId;

	@Property(propertyName = "dms.reporting.delete.driver.event.schema.id")
	private String  dmsReportingDeleteDriverEventSchemaId;

	@Property(propertyName = "dms.reporting.hc.doc.event.schema.id")
	private String dmsHCDocEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.deletion.requested.event.schema.id")
	private String dmsReportingDriverDeletionRequestedEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.verification.event.schema.id")
	private String dmsReportingDriverVerificationEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.login.event.schema.id")
	private String dmsDriverLoginSchemaId;

	@Property(propertyName = "dms.reporting.driver.logout.event.schema.id")
	private String dmsDriverLogoutSchemaId;

	@Property(propertyName = "dms.reporting.driver.reset.password.event.schema.id")
	private String dmsDriverResetPasswordSchemaId;

	@Property(propertyName = "dms.reporting.driver.device.status.event.schema.id")
	private String dmsReportingDriverDeviceStatusEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.status.update.request.event.schema.id")
	private String dmsReportingDriverStatusUpdateRequestEventSchemaId;

    @Property(propertyName = "dms.reporting.persona.data.event.schema.id")
    private String dmsReportingPersonaDataEventSchemaId;

	@Property(propertyName = "dms.reporting.driver.document.update.schema.id")
	private String  dmsReportingDriverDocumentUpdateSchemaId;
}
