package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;
import lombok.Data;

import java.util.List;

/**
 * @author g0s00pv on 7/26/18
 */
@Data
@Configuration(configName = "elasticConfig")
public class ElasticSearchConfig {

    @Property(propertyName = "elasticsearch.csp.domain")
    private String cspEsHost;

    @Property(propertyName = "elasticsearch.csp.index")
    private String cspIndex;

    @Property(propertyName = "elasticsearch.csp.type")
    private String cspIndexType;

    @Property(propertyName = "elasticsearch.dms.domain")
    private String dmsEsHost;

    @Property(propertyName = "elasticsearch.dms.index.driverEntity")
    private String dmsDriverEntityIndex;

    @Property(propertyName = "elasticsearch.dms.index.driverPayment")
    private String dmsDriverPaymentEntityIndex;

    @Property(propertyName = "elasticsearch.dms.type")
    private String dmsIndexType;

    @Property(propertyName = "elasticsearch.dms.reindex.data.size")
    @DefaultValue.Int(5)
    private int elasticSearchReindexDataSize;

    @Property(propertyName = "elasticsearch.log.level")
    public String elasticsearchLogLevel;

    @Property(propertyName = "elasticsearch.read.timeout.sec")
    public int elasticsearchReadTimeOutInSec;

    @Property(propertyName = "elasticsearch.connect.timeout.sec")
    public int elasticsearchConnectTimeOutInSec;

    @Property(propertyName = "elasticsearch.api.header")
    public String elasticsearchApiHeaders;

    @Property(propertyName = "elasticsearch.dms.index.tripOffer")
    public String elasticTripOfferIndex;

    @Property(propertyName = "elasticsearch.dms.index.onboarding.response")
    public String elasticOnboardingIndex;

    @Property(propertyName = "elasticsearch.dms.index.driverFeedback")
    public String elasticDriverFeedbackIndex;

    @Property(propertyName = "elasticsearch.dms.index.request.response.log")
    public String elasticDMSRequestResponseLogIndex;

    @Property(propertyName = "elastic.dms.searchOnlySource.urlSuffix")
    public String elasticUrlForSourceOnly;

    @Property(propertyName = "elastic.dms.tripOffer.search.payload.with.slot")
    public String elasticSearchPayloadForTripOffersWithSlot;

    @Property(propertyName = "elastic.dms.tripOffer.search.payload")
    public String elasticSearchPayloadForTripOffers;

    @Property(propertyName = "elastic.dms.delete.driver.calendar.payload")
    public String deleteByQueryPayloadForDriverCalendar;

    @Property(propertyName = "elastic.dms.deleteByQuery.urlSuffix")
    public String deleteByQueryUrlSuffix;

    @Property(propertyName = "elastic.dms.es.async.rest.timeout.sec")
    @DefaultValue.Int(10)
    public int elasticEsAsyncRestTimeoutInSec;

    @Property(propertyName = "elasticsearch.save.api.header")
    public String elasticsearchSaveApiHeaders;

    @Property(propertyName = "elasticsearch.dms.index.paymentReconcilation")
    public String dmsPaymentReconcilationIndex;

    @Property(propertyName = "elasticsearch.dms.index.onboardingFailures")
    public String dmsOnboardingFailuresIndex;

    @Property(propertyName = "elastic.dms.es.count.driver.calender.payload")
    public String elasticSearchDriverCalenderCountQuery;

    @Property(propertyName = "es.dms.media.type")
    public String esMediaType;

    // New ES with auth: Start
    // Here PC and SC stand for primary cluster and secondary cluster respectively
    @Property(propertyName = "new.es.dms.primary.cluster")
    private String dmsNewESPCluster;

    @Property(propertyName = "new.es.dms.primary.cluster.username")
    private String dmsNewESPCUserName;

    @Property(propertyName = "new.es.dms.primary.cluster.password")
    private String dmsNewESPCPassword;

    @Property(propertyName = "new.es.dms.secondary.cluster")
    private String dmsNewESSCluster;

    @Property(propertyName = "new.es.dms.secondary.cluster.username")
    private String dmsNewESSCUserName;

    @Property(propertyName = "new.es.dms.secondary.cluster.password")
    private String dmsNewESSCPassword;

    @Property(propertyName = "new.es.dms.api.headers")
    private String dmsNewESAPIHeaders;

    @Property(propertyName = "new.es.dms.is.es.request.logging.enabled")
    @DefaultValue.Boolean(false)
    private boolean isESRequestLoggingEnabled;
    // New ES with auth: End

    @Property(propertyName = "new.es.dms.is.driver.onboarding.failure.flow.enabled")
    @DefaultValue.Boolean(true)
    private boolean isDriverOnboardingFailureFlowEnabled;

    @Property(propertyName = "new.es.dms.is.driver.onboarding.success.flow.enabled")
    @DefaultValue.Boolean(true)
    private boolean isDriverOnboardingSuccessFlowEnabled;

    @Property(propertyName = "new.es.dms.is.eood.feedback.flow.enabled")
    @DefaultValue.Boolean(true)
    private boolean isEOODFeedbackFlowEnabled;

    @Property(propertyName = "new.es.dms.enabled.countryCodes", delimiter = ",")
    private List<String> dmsNewESEnabledCountryCodes;

    @Property(propertyName = "elasticsearch.connect.timeout.ms")
    @DefaultValue.Int(5000)
    private Integer connectTimeoutMs;

    @Property(propertyName = "elasticsearch.read.timeout.ms")
    @DefaultValue.Int(5000)
    private Integer readTimeoutMs;

    @Property(propertyName = "dms.primary.elastic.search.cluster.enabled")
    @DefaultValue.Boolean(false)
    private boolean isDMSPrimaryESClusterEnabled;

    @Property(propertyName = "dms.secondary.elastic.search.cluster.enabled")
    @DefaultValue.Boolean(false)
    private boolean isDMSSecondaryESClusterEnabled;

    @Property(propertyName = "es.pc.dms.verification.cluster")
    private String esPCDMSVerificationCluster;

    @Property(propertyName = "es.pc.dms.verification.cluster.username")
    private String esPCDMSVerificationClusterUserName;

    @Property(propertyName = "es.pc.dms.verification.cluster.password")
    private String esPCDMSVerificationClusterPassword;

    @Property(propertyName = "es.sc.dms.verification.cluster")
    private String esSCDMSVerificationCluster;

    @Property(propertyName = "es.sc.dms.verification.cluster.username")
    private String esSCDMSVerificationClusterUserName;

    @Property(propertyName = "es.sc.dms.verification.cluster.password")
    private String esSCDMSVerificationClusterPassword;

    @Property(propertyName = "es.dms.verification.index")
    private String esDMSVerificationIndex;

    @Property(propertyName = "dms.verification.primary.elastic.search.cluster.enabled")
    @DefaultValue.Boolean(false)
    private boolean isDMSVerificationPrimaryESClusterEnabled;

    @Property(propertyName = "dms.verification.secondary.elastic.search.cluster.enabled")
    @DefaultValue.Boolean(false)
    private boolean isDMSVerificationSecondaryESClusterEnabled;
}
