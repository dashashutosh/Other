package com.walmart.dms.common.enums;

public enum SpotLightPriority {
    
    LOW, HIGH, MEDIUM
    
}
