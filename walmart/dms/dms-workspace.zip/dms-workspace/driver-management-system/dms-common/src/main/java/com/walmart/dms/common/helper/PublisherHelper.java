package com.walmart.dms.common.helper;

import com.google.gson.Gson;
import com.walmart.dms.common.ccm.DMSEventsConfig;
import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.executors.AsyncVerificationTasks;
import com.walmart.dms.common.kafka.event.DMSReportingEvent;
import com.walmart.dms.common.kafka.event.DMSReportingEventHeader;
import com.walmart.dms.common.kafka.producers.DMSReportingEventsProducer;
import com.walmart.dms.common.utils.LogUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class PublisherHelper {
    @Autowired
    private DMSEventsConfig dmsEventsConfig;

    @Autowired
    private CommonConfig commonConfig;

    @Autowired
    private DMSReportingEventsProducer dmsReportingEventsProducer;

    @Autowired
    @Lazy
    private AsyncVerificationTasks asyncVerificationTasks;

    private final String TENANT_ID = "0";

    private final String VERTICAL_ID = "2";

    public void publishIdVerificationData(String requestPayload) {
        try {
            log.info(LogUtil.buildJsonLog("Driver ID verification status V2 payload to be published"));
            asyncVerificationTasks.createIdVerificationPayloadPublish(requestPayload);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }


    public void publishPersonaData(String request) {
        try {
            long beforeProduce = System.currentTimeMillis();
            log.info("DRIVER_VERIFICATION_INFO event enabled, publishing event");
            Gson gson = new Gson();
            Object data = gson.fromJson(request, Object.class);

            final DMSReportingEvent<Object> personaDataReportingEvent = new DMSReportingEvent<>();
            DMSReportingEventHeader header = DMSReportingEventsProducer.prepareReportingEventHeader(
                    Constant.DRIVER_VERIFICATION_INFO,
                    dmsEventsConfig.getDmsReportingPersonaDataEventSchemaId(), TENANT_ID, VERTICAL_ID);
            header.setIsStressTestOrder(false);
            header.setSchemaId(dmsEventsConfig.getDmsReportingPersonaDataEventSchemaId());
            personaDataReportingEvent.setHeader(header);

            personaDataReportingEvent.setPayload(data);
            log.info("Publishing in DRIVER_VERIFICATION_INFO event enabled, publishing event");
            dmsReportingEventsProducer.produce(personaDataReportingEvent);
            long afterProduce = System.currentTimeMillis();
            long executionTime = afterProduce - beforeProduce;
            log.info(LogUtil.buildJsonLog(
                    "[publishPersonaData] Execution time",
                    com.walmart.dms.common.utils.Pair.with("publish_persona_data_exec_time", executionTime))
            );
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }
}