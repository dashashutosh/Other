package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Configuration(configName = "quartz")
@Data
public class QuartzConfig {

    @Property(propertyName = "org.quartz.scheduler.skipUpdateCheck")
    public String skipUpdateCheck;

    @Property(propertyName = "org.quartz.scheduler.jobFactory.class")
    public String jobFactoryClass;

    @Property(propertyName = "org.quartz.scheduler.instanceId")
    public String instanceId;

    @Property(propertyName = "org.quartz.jobStore.class")
    public String jobStoreClass;

    @Property(propertyName = "org.quartz.jobStore.driverDelegateClass")
    public String jobStoreDriverDelegateCLass;

    @Property(propertyName = "org.quartz.jobStore.dataSource")
    public String jobStoreDataSource;

    @Property(propertyName = "org.quartz.jobStore.tablePrefix")
    public String jobStoreTablePrefix;

    @Property(propertyName = "org.quartz.threadPool.class")
    public String threadPoolClass;

    @Property(propertyName = "org.quartz.threadPool.threadCount")
    public String threadCount;

    @Property(propertyName = "org.quartz.jobStore.isClustered")
    public String isClustered;

    @Property(propertyName = "org.quartz.jobStore.clusterCheckinInterval")
    public String clusterCheckinInterval;

    @Property(propertyName = "org.quartz.scheduler.instanceName")
    public String instanceName;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.driver")
    public String quartzDataSourceDriver;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.URL")
    public String quartzDataSourceUrl;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.user")
    public String quartzDataSourceUser;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.password")
    public String quartzDataSourcePassword;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.maxConnections")
    public String quartzDataSourceMaxConnections;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.validationQuery")
    public String quartzDataSourceValidationQuery;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.idleConnectionValidationSeconds")
    public String quartzDataSourceIdleConnectionValidationSeconds;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.testConnectionOnCheckout")
    public String quartzDataSourceTestConnectionOnCheckout;

    @Property(propertyName = "org.quartz.dataSource.quartzDataSource.maxIdleTime")
    public String quartzDataSourceMaxIdleTime;

}