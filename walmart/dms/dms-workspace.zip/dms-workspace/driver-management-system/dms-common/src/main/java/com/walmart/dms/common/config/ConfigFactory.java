package com.walmart.dms.common.config;

import com.walmart.dms.common.config.scope.ScopeParameter;
import com.walmart.dms.common.constant.Constant;
import io.strati.StratiServiceProvider;
import io.strati.configuration.ConfigType;
import io.strati.configuration.ConfigurationService;
import io.strati.configuration.context.ConfigurationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Component
public class ConfigFactory {

    @Autowired
    private ConfigurationService configurationService;

    private final Map<ScopeParameter, Map<Class, Map<String, Object>>> configs;

    private final Map<Class, Object> defaultConfigs;

    public ConfigFactory() {

        this.configs = new HashMap<>();
        this.defaultConfigs = new HashMap<>();

        Arrays.stream(ScopeParameter.values()).forEach(scopeParameter -> {
            this.configs.put(scopeParameter, new HashMap<>());
        });
    }

    /**
     * This method returns config instance of given type for specified scope parameter.
     * @param type Config class type
     * @param scopeParameter Valid scope parameter.
     * @param scopeParameterValue Valid scope parameter value
     * @param <T>
     * @return Instance of specified type
     */
    public <T>  T config(Class<T> type, ScopeParameter scopeParameter, String scopeParameterValue) {

        Map<Class, Map<String, Object>> scopedConfigs = this.configs.get(scopeParameter);

        Map<String, Object> keyValueConfigs = scopedConfigs.get(type);

        if (keyValueConfigs == null) {
            keyValueConfigs = new HashMap<>();
            scopedConfigs.put(type, keyValueConfigs);
        }

        Object config = keyValueConfigs.get(scopeParameterValue);

        if (config == null) {
            ConfigurationContext context = configurationService.getNewContext();
            context.setService(Constant.APP_NAME);
            context.setScopeParameter(scopeParameter.id, scopeParameterValue);

            config = configurationService.getConfiguration(context, type,
                ConfigType.SIMPLE);

            /*
             * If config against given tenant is null then use default config.
             */
            if (config == null) {
                config = config(type);
            }

            keyValueConfigs.put(scopeParameterValue, config);
        }

        return (type.cast(config)) ;
    }

    /**
     * This method returns default config of given type.
     * @param type config class type
     * @param <T>
     * @return Instance of specified type
     */
    public <T> T config(Class<T> type) {

        Object defaultConfig = defaultConfigs.get(type);

        if (defaultConfig == null) {
            ConfigurationContext context = configurationService.getNewContext();
            defaultConfig = configurationService.getConfiguration(context, type,
                    ConfigType.SIMPLE);


            defaultConfigs.put(type, defaultConfig);
        }

        return type.cast(defaultConfig);
    }
}
