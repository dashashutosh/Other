package com.walmart.dms.common.spotlight;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.walmart.dms.common.interceptor.LoggingInterceptor;
import com.walmart.dms.common.interceptor.LoggingInterceptor.Level;
import com.walmart.dms.common.spotlight.model.BaseSpotlightEvent;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * @author n0a008p on Apr 12, 2018
 *
 */
@Slf4j
@Component
public class SpotLightService {

	private SpotLightAPI api;

	@Autowired
	private SpotLightConfig config;

	@PostConstruct
	public void init() throws Exception {
		LoggingInterceptor loggingInterceptor = new LoggingInterceptor(Level.BODY);
		OkHttpClient okHttpClient = new OkHttpClient().newBuilder().addInterceptor(loggingInterceptor).build();
		Gson gson = new GsonBuilder().setLenient().create();
		Retrofit retrofit = new Retrofit.Builder().addConverterFactory(GsonConverterFactory.create(gson))
				.baseUrl(config.getUrl()).client(okHttpClient).build();
		api = retrofit.create(SpotLightAPI.class);

	}

	@SuppressFBWarnings(value="SIC_INNER_SHOULD_BE_STATIC_ANON")
	public void sendEvent(BaseSpotlightEvent request) {
		Callback<Object> callback = new Callback<Object>() {
			@Override
			public void onResponse(Call<Object> call, Response<Object> response) {
				log.info("[SpotLightService] [success] response:{}", response.body());
			}

			@Override
			public void onFailure(Call<Object> call, Throwable t) {
				log.error("[SpotLightService] [error]", t);
			}
		};
		
		try {
		    if(Boolean.valueOf(config.getEnabled())) api.publishEvent(request).enqueue(callback);
		} catch (Exception e) {
			log.error("Exception occured while sending spotlight alert",e);
		}
	}

}
