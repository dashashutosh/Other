package com.walmart.dms.common.enums;

public enum DriverSuggestionProfile {

    DEFAULT,
    PROMOTE_GOOD,
    PROMOTE_DORMANT,
    PROMOTE_NEW,
    PROMOTE_SUPERENGAGED,
    PROMOTE_ENGAGED,
    PROMOTE_ACTIVE,
    PROMOTE_INACTIVE;
}
