package com.walmart.dms.common.exception;

import java.util.List;

import com.walmart.dms.server.common.error.Error;
import com.walmart.dms.server.common.exception.PlatformException;

public class IntegrationException extends PlatformException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IntegrationException(String errorMessage) {
		super(errorMessage);
	}

	public IntegrationException(String errorMessage, Throwable cause) {
		super(errorMessage, cause);
	}

	public IntegrationException(Throwable throwable) {
		super(throwable);
	}

	public IntegrationException(Error error, String message, Throwable throwable) {
		super(error, message, throwable);
	}

	public IntegrationException(Error error, String message, Throwable throwable, int httpStatusCode) {
		super(error, message, throwable, httpStatusCode);
	}

	public IntegrationException(Error error, Throwable throwable) {
		super(error, throwable);
	}

	public IntegrationException(Error error, Throwable throwable, int httpStatusCode) {
		super(error, throwable, httpStatusCode);
	}

	public IntegrationException(Error error) {
		super(error);
	}

	public IntegrationException(Error error, int httpStatusCode) {
		super(error, httpStatusCode);
	}

	public IntegrationException(List<Error> errors) {
		super(errors);
	}

	public IntegrationException(List<Error> errors, String message) {
		super(errors, message);
	}

	public IntegrationException(List<Error> errors, int httpStatusCode) {
		super(errors, httpStatusCode);
	}

	public IntegrationException(List<Error> errors, Throwable throwable) {
		super(errors, throwable);
	}

	public IntegrationException(List<Error> errors, Throwable throwable, int httpStatusCode) {
		super(errors, throwable, httpStatusCode);
	}
}