package com.walmart.dms.common.utils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.walmart.dms.common.Base62Coder;
import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.config.ConfigFactory;
import com.walmart.dms.common.config.scope.ScopeParameter;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.enums.DriverType;
import com.walmart.dms.common.enums.Tenant;
import com.walmart.dms.common.enums.UserRole;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import io.strati.libs.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.Objects;

@Component
public class PasswordGenerator {

    @Autowired
    private ConfigFactory configFactory;

    @Autowired
    private StressTestUtil stressTestUtil;

    private Gson gson = new Gson();

    @SuppressFBWarnings
    public String generatePassword(DriverType driverType, String input, HeaderDTO headerDTO, String marketName) {

        CommonConfig commonConfig = configFactory.config(CommonConfig.class, ScopeParameter.TENANT, headerDTO.getTenantId());
        Map<String, Map<String, String>> defaultPasswordMap = gson.fromJson(commonConfig.defaultPasswordByType, new TypeToken<Map<String, Map<String, String>>>() {}.getType());

        if(stressTestUtil.checkStressTestOrderStatus(marketName)) {
            return commonConfig.defaultStressTestPassword;
        }

        if (defaultPasswordMap == null) {
            return commonConfig.defaultPassword;
        }

        Map<String, String> tenantMap = defaultPasswordMap.get(headerDTO.getTenantId());

        if (tenantMap == null) {
            return commonConfig.defaultPassword;
        }

        return tenantMap.get(driverType.name()) == null ? commonConfig.defaultPassword : tenantMap.get(driverType.name());
    }

    public String generatePassword(String scacCode, String contactNumber, String role){
        // this method is for ntransit specific - SCAC needed
        if(StringUtils.isNotEmpty(scacCode)
                && StringUtils.isNotEmpty(role)
                && contactNumber.trim().length() > 4) {
            StringBuilder sb = new StringBuilder(scacCode.trim());
            if(UserRole.CARRIER_ADMIN.name().equalsIgnoreCase(role)){
                sb.append(StringUtils.right(contactNumber.trim(), 4));
            } else {
                sb.append(Constant.DRIVER_ACCESS_SUFFIX);
            }
            return sb.toString();
        } else {
            return Constant.DRIVER_ACCESS_TEMP;
        }
    }

    public String generateDefaultPassword(HeaderDTO headerDTO) {
        CommonConfig commonConfig = configFactory.config(CommonConfig.class, ScopeParameter.TENANT, headerDTO.getTenantId());
        return commonConfig.getDmsDefaultLoginPassword();
    }
}