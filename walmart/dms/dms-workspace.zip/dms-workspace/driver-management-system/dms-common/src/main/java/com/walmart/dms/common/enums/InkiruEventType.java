package com.walmart.dms.common.enums;

public enum InkiruEventType {

    INKIRU_OFFLINE_JOB, INKIRU_REAL_TIME_JOB

}
