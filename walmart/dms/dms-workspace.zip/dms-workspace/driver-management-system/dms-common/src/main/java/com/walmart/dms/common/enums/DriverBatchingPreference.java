package com.walmart.dms.common.enums;

public enum DriverBatchingPreference {
    AUTO_ACCEPT, MANUAL_ACCEPT
}
