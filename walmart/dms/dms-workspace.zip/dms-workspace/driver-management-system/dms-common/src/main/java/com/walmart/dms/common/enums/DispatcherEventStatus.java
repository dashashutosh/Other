package com.walmart.dms.common.enums;

public enum DispatcherEventStatus {

	RECEIVED,
	CONSUMED
}
