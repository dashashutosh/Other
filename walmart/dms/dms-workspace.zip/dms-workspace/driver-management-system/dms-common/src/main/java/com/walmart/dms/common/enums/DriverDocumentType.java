package com.walmart.dms.common.enums;

public enum DriverDocumentType {
    HealthCare_Subsidy, DRIVER_LICENCE, PROFILE_PIC;

    public static boolean contains(String value){
        for(DriverDocumentType driverDocumentType : DriverDocumentType.values()){
            if(driverDocumentType.name().equals(value)){
                return true;
            }
        }
        return false;
    }
}
