package com.walmart.dms.common.enums;

public enum DriverZoneType {
  DEFAULT, CUSTOM
}
