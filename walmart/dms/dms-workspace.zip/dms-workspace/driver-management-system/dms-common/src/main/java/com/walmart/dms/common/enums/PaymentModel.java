package com.walmart.dms.common.enums;

public enum PaymentModel {

	PER_ORDER("Per Order"),
	PER_HOUR("Per Hour");
	
	private String value;
	
	private PaymentModel(String value) {
		this.value=value;
	}
	
	public String getValue() {
		return value;
	}
}
