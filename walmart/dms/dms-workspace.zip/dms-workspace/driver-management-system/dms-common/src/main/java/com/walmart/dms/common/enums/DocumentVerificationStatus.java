package com.walmart.dms.common.enums;

public enum DocumentVerificationStatus {
    APPROVED, PENDING, REJECTED
}
