package com.walmart.dms.common.enums;

public enum ReplayEventsTopic {
    @Deprecated
    DMS_EVENTS("dms_events"),
    @Deprecated
    DMS_REPORTING_EVENTS("dms_reporting_events"),
    DMS_EVENTS_DEV("dms_events_dev"), DMS_REPORTING_EVENTS_DEV("dms_reporting_events_dev"),
    DMS_EVENTS_QA("dms_events_qa"), DMS_REPORTING_EVENTS_QA("dms_reporting_events_qa"),
    DMS_EVENTS_STAGE("dms_events_stage"), DMS_REPORTING_EVENTS_STAGE("dms_reporting_events_stage"),
    DMS_EVENTS_PROD("dms_events_prod"), DMS_REPORTING_EVENTS_PROD("dms_reporting_events_prod");

    private String topic;

    ReplayEventsTopic(String topic) {
        this.topic = topic;
    }

    public String getTopicId() {
        return topic;
    }

    // Temporary method until DMS has integration with old Kafka.
    public ReplayEventsTopic getOldKafkaTopic() {
        switch (this) {
            case DMS_EVENTS:
            case DMS_EVENTS_DEV:
            case DMS_EVENTS_QA:
            case DMS_EVENTS_STAGE:
            case DMS_EVENTS_PROD:
                return DMS_EVENTS;
            case DMS_REPORTING_EVENTS:
            case DMS_REPORTING_EVENTS_DEV:
            case DMS_REPORTING_EVENTS_QA:
            case DMS_REPORTING_EVENTS_STAGE:
            case DMS_REPORTING_EVENTS_PROD:
                return DMS_REPORTING_EVENTS;
            default:
                return this;
        }
    }
}
