package com.walmart.dms.common.enums;

/**
 * Created by s0v035d on 01/08/23.
 */
public enum LoginStatus {
    FAIL, SUCCESS
}
