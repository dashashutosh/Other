package com.walmart.dms.common.spotlight;

import com.walmart.dms.common.spotlight.model.BaseSpotlightEvent;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * @author n0a008p on Apr 4, 2018
 *
 */
public interface SpotLightAPI {

	@POST("events/")
	Call<Object> publishEvent(@Body BaseSpotlightEvent event);

}
