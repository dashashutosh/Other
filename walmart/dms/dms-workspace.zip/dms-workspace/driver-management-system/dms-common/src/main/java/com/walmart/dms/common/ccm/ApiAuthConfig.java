package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Data
@Configuration(configName = "apiAuthConfig")
public class ApiAuthConfig {
    @Property(propertyName = "api.consumer.id.auth.check.enabled")
    public boolean dmsApiConsumerIdAuthCheckEnabled;

    @Property(propertyName = "api.pii.get.driver.consumer.id.map")
    public String getDriverPIIConsumers;

    @Property(propertyName = "api.pii.search.driver.consumer.id.map")
    public String searchDriverPIIConsumers;

    @Property(propertyName = "api.pii.edit.driver.data.consumer.id.map")
    public String editDriverPIIDataConsumers;

    @Property(propertyName = "api.pii.get.driver.audit.details.consumer.id.map")
    public String getDriverPIIAuditDetailsConsumers;
}
