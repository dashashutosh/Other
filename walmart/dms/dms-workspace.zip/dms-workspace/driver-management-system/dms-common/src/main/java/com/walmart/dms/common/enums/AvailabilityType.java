package com.walmart.dms.common.enums;

import java.util.Locale;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor
@Getter
public enum AvailabilityType {

    EXACT(0), DAY(1), WEEK(2), ALL(3);

    private int availability;

    public static AvailabilityType getValue(String type) {
        try {
            return AvailabilityType.valueOf(type.toUpperCase(Locale.getDefault()));

        } catch (Exception e) {
            log.error("Exception occurred in [AvailabilityType] [getValue] ", e);
            return ALL;
        }

    }
}
