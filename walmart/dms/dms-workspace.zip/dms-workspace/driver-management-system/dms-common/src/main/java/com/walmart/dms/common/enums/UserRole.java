package com.walmart.dms.common.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.deserializers.UserRoleJsonDeserializer;
import lombok.AllArgsConstructor;

import java.io.IOException;

@AllArgsConstructor
@JsonDeserialize(using = UserRoleJsonDeserializer.class)
public enum UserRole {

    ADMIN("admin", Constant.HOME_OFFICE, false),
    MANAGER("manager", Constant.HOME_OFFICE, false),
    SYS_ADMIN("sys_admin", Constant.HOME_OFFICE, false),
    DISPATCH("dispatch", Constant.HOME_OFFICE, false),
    BU_MANAGER("bu_manager", "ext", true),
    DRIVER("driver", "ext", true),
    CARRIER_ADMIN("carrier_admin", "ext", true);

    public final String strName;
    public final String domain;
    public final boolean external;// TODO: add getter

    public static UserRole fromText(String name) {
        return UserRole.valueOf(name);
    }
}
