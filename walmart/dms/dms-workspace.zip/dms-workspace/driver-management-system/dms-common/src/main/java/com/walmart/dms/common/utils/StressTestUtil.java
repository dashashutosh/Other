package com.walmart.dms.common.utils;

import com.walmart.dms.common.config.CommonConfig;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

/**
 * Utility class for stress test related operations.
 * @author m0m0qvd
 */
@Component
public class StressTestUtil {

    @Autowired
    private CommonConfig commonConfig;

    /**
     * @param driverMarketName the market name of the driver
     * @return boolean value whether the driver market name is enabled for stress test
     */
    public Boolean checkStressTestOrderStatus(final String driverMarketName){
        Set<String> dmsStressTestEnabledMarkets = commonConfig.getDmsStressTestEnabledMarkets();

        if(CollectionUtils.isNotEmpty(dmsStressTestEnabledMarkets)) {
            if(driverMarketName != null){
                return dmsStressTestEnabledMarkets.contains(driverMarketName);
            }else{
                return Boolean.FALSE;
            }
        } else {
            return Boolean.FALSE;
        }
    }
}
