package com.walmart.dms.common.enums;

public enum DispatcherEventName {

	DELIVERED("Order delivered"),
	RETURNED("Order returned"),
	ENROUTE_TO_PICKUP("Order picked up");

	private String value;

	private DispatcherEventName(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static DispatcherEventName find(String type) {

		for (DispatcherEventName testEnum : DispatcherEventName.values()) {
			if (testEnum.name().equals(type)) {
				return testEnum;
			}
		}
		return null;
	}

	public static boolean contains(String type) {
		for (DispatcherEventName eventName : DispatcherEventName.values()) {
			if (eventName.name().equals(type)) {
				return true;
			}
		}
		return false;
	}
}
