package com.walmart.dms.common.kafka;

import com.walmart.dms.common.kafka.configs.DMSKafkaConfig;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Abstract DMS Kafka consumer class. This is class will serve as the parent class of all the DMS consumers.
 *
 * @author a0d02yr
 */
public class AbstractDMSKafkaConsumer {

    @Autowired
    protected DMSKafkaConfig dmsKafkaConfig;
}
