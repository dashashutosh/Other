package com.walmart.dms.common.enums;

/**
 * @author a0s0od1
 * Driver Sub type to check for specific skills
 */

public enum DriverSubType {

    INHOME
}
