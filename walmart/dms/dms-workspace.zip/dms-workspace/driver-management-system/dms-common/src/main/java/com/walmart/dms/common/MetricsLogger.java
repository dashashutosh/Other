package com.walmart.dms.common;

import org.springframework.stereotype.Component;

import io.strati.StratiServiceProvider;
import io.strati.metrics.DuplicatedMetricsException;
import io.strati.metrics.InvalidArgumentException;
import io.strati.metrics.MetricDimensions;
import io.strati.metrics.MetricsService;
import io.strati.metrics.TooManyRegisteredMetricsException;
import io.strati.metrics.instrument.Counter;
import io.strati.metrics.instrument.Histogram;
import io.strati.metrics.instrument.Instrument;
import io.strati.metrics.instrument.Instrument.TimeUnit;
import io.strati.metrics.instrument.Timer;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author n0k008c
 *
 */

@Component
@Slf4j
public class MetricsLogger {

    private static MetricsService metricsService = StratiServiceProvider.getInstance().getMetricsService().get();

    private final static double[] myTaskTimePercentiles = { 0.01, 0.5, 0.95, 0.985, 0.99 };

    public Timer getTimer(String serviceName, String httpMethod) {

        if (!serviceName.startsWith("dms_")) {
            serviceName = "dms_" + serviceName;
        }

        MetricDimensions basicDims = metricsService
                .createMetricDimensionsQuietly(MetricsLogger.MetricLevel.SERVICE.toString(), serviceName, httpMethod);
        Instrument instrument = null;

        try {
            instrument = metricsService.getMetricRegistry().find(basicDims, serviceName);
        } catch (InvalidArgumentException invalidArgumentException) {
            log.error(invalidArgumentException.getMessage(), invalidArgumentException);
        }

        try {

            if (instrument == null || !(instrument instanceof Histogram)) {
                instrument = metricsService.getMetricRegistry().histogram(basicDims, serviceName, TimeUnit.MILLISECONDS,
                        myTaskTimePercentiles);
            }
            return metricsService.getMetricRegistry().createTimer((Histogram) instrument);
        } catch (InvalidArgumentException | TooManyRegisteredMetricsException | DuplicatedMetricsException e) {
            log.error(e.getMessage(), e);
        }

        return null;

    }

    /**
     * Records the http status code of given service in metrics log
     *
     * @param serviceName
     * @param httpStatusCode
     */
    public void recordServiceResponseCode(String serviceName, String httpStatusCode) {

        if (!serviceName.startsWith("dms_")) {
            serviceName = "dms_" + serviceName;
        }
        HttpStatusCode httpCode = null;

        if (httpStatusCode.startsWith("1")) {
            httpCode = HttpStatusCode.HTTP_1XX;
        } else if (httpStatusCode.startsWith("2")) {
            httpCode = HttpStatusCode.HTTP_2XX;
        } else if (httpStatusCode.startsWith("3")) {
            httpCode = HttpStatusCode.HTTP_3XX;
        } else if (httpStatusCode.startsWith("4")) {
            httpCode = HttpStatusCode.HTTP_4XX;
        } else {
            httpCode = HttpStatusCode.HTTP_5XX;
        }

        try {
            // create a dimension for logging the metric
            MetricDimensions dimension = metricsService.createMetricDimensions(MetricLevel.SERVICE.name(), serviceName,
                    httpCode.name());

            // find the instrument in registry
            Instrument instrument = metricsService.getMetricRegistry().find(dimension, "httpCodeStats");

            // if not found in registry, then create and register
            if (instrument == null || !(instrument instanceof Counter)) {
                instrument = metricsService.getMetricRegistry().counter(dimension, "httpCodeStats");
            }

            // record measurement
            ((Counter) instrument).inc(1);

        } catch (Exception e) {
            log.error("[MetricsLogger][recordServiceResponseCode]: Error occurred while logging exception metrics. Message: ", e);
        }
    }
    
    /**
     * Records the counter for a given key in metrics log
     *
     * @param component
     * @param key
     */
    public void recordCounter(String component, String key, String metricName, Long time) {
        
        if (!component.startsWith("dms_")) {
            component = "dms_" + component;
        }
        
        try {
            // create a dimension for logging the metric
            MetricDimensions dimension = metricsService.createMetricDimensions(MetricLevel.GENERIC.name(), component, key);

            // find the instrument in registry
            Instrument instrument = metricsService.getMetricRegistry().find(dimension, metricName);

            // if not found in registry, then create and register
            if (instrument == null || !(instrument instanceof Counter)) {
                instrument = metricsService.getMetricRegistry().counter(dimension, metricName);
            }

            // record measurement
            ((Counter) instrument).inc(time);

        } catch (Exception e) {
            log.error("[MetricsLogger][recordCounter]: Error occurred while logging exception metrics. Message: ", e);
        }
        
    }

    /**
     * Records the counter for a given key in metrics log
     *
     * @param component
     * @param key
     */
    public void recordExceptionCounter(String component, String key, String metricName) {

        if (!component.startsWith("dms_")) {
            component = "dms_" + component;
        }

        try {
            // create a dimension for logging the metric
            MetricDimensions dimension = metricsService.createMetricDimensions(MetricLevel.EXCEPTION.name(), component, key);

            // find the instrument in registry
            Instrument instrument = metricsService.getMetricRegistry().find(dimension, metricName);

            // if not found in registry, then create and register
            if (instrument == null || !(instrument instanceof Counter)) {
                instrument = metricsService.getMetricRegistry().counter(dimension, metricName);
            }

            // record measurement
            ((Counter) instrument).inc(1L);

        } catch (Exception e) {
            log.error("[MetricsLogger][recordCounter]: Error occurred while logging exception metrics. Message: ", e);
        }

    }

    public enum MetricLevel {
        SERVICE, EXCEPTION, GENERIC
    }

    enum HttpStatusCode {
        HTTP_1XX, HTTP_2XX, HTTP_3XX, HTTP_4XX, HTTP_5XX;
    }
}
