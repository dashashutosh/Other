package com.walmart.dms.common.enums;

/**
 * Enum that specifies the driver suggestion filter modes.
 *
 * @author a0d02yr
 */
public enum DriverSuggestionFilter {
	AVAILABLE, // Get only available drivers (available as per their schedule)
	ONLINE, // Get only online drivers (Spark Now or Booster offer or Real time availability)
	AVAILABLE_OR_ONLINE // hybrid model for schedule and online filter
}
