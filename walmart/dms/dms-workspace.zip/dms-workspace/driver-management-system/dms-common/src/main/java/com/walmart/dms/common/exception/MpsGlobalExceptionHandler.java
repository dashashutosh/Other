package com.walmart.dms.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class MpsGlobalExceptionHandler {

    public static final int DLQ_ERR_CD = 701;

    @ExceptionHandler({DLQMessageException.class})
    public ResponseEntity<String> handleDlqMessageException(DLQMessageException ex) {
        return ResponseEntity.status(DLQ_ERR_CD).body(ex.getMessage());
    }

    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    public ResponseEntity<String> handleMethodNotAllowed(HttpRequestMethodNotSupportedException ex) {
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(ex.getMessage());
    }

    @ExceptionHandler({InvalidMpsRequestException.class})
    public ResponseEntity<String> handleInvalidRequestException(InvalidMpsRequestException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }

    @ExceptionHandler({MessageProcessNotEnabledException.class})
    public ResponseEntity<String> handleMessageProcessNotEnabledException(MessageProcessNotEnabledException ex) {
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(ex.getMessage());
    }

}