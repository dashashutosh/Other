package com.walmart.dms.common.filter;

import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.enums.Tenant;
import com.walmart.dms.common.enums.Vertical;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import java.io.IOException;


@Slf4j
@SuppressFBWarnings
@Component
public class HeaderCheckFilter implements ContainerRequestFilter {


    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        String verticalId = requestContext.getHeaderString(Constant.VERTICAL_ID_HEADER_KEY);
        String tenantId = requestContext.getHeaderString(Constant.TENANT_ID_HEADER_KEY);
        String method = requestContext.getMethod();
        String path = requestContext.getUriInfo().getPath();
        if(tenantId==null || tenantId.isEmpty())
            log.info("Request: Method : {}, Path : {}, TenantId is missing",method,path);
        else if(!Tenant.contains(tenantId))
            log.info("Request: Method : {}, Path : {}, Invalid TenantId : {}",method,path,tenantId);
        if(verticalId==null || verticalId.isEmpty())
            log.info("Request: Method : {}, Path : {}, VerticalId is missing",method,path);
        else if(!Vertical.contains(verticalId))
            log.info("Request: Method : {}, Path : {}, Invalid VerticalId : {}",method,path,verticalId);
    }
}
