package com.walmart.dms.common.enums;

/**
 * @author s0p012h on Sep 3, 2018
 *
 */

public enum PictureStatus {

    NOT_APPROVED, MANUAL_APPROVED, AUTO_APPROVED, APPROVED, REJECTED, PHOTO_NOT_SUBMITTED, REVIEW_NEEDED
}
