package com.walmart.dms.common.error;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author n0k008c
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorRetryDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @NotNull(message="eventName is a mandatory Field")
    private String eventName;
    
    @NotNull(message="errorId is a mandatory Field")
    private String errorId;
    
    private String tenantId;

    private String verticalId;
    
    private String payload;
    
    private String errorType;

    private String errorMessage;
    
    private String errorStackTrace;
    
    private int maxRetryCount;
    
    private String computeIP;

}
