package com.walmart.dms.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

@AllArgsConstructor
@Getter
public enum DriverSuggestionPriority {
    SELECTED (0, true, "available"),
    STARVED (1, true, "available"),
    EXPIRED_IN_STORE (2, true, "expired"),
    REJECTED_IN_MARKET (3, true, "rejected"),
    REJECTED_IN_STORE (4, false, "rejected");

    private int priority;
    private boolean eligibleForSuggestion;
    private String displayName;

    public static DriverSuggestionPriority valueOf(int priority) {
        Optional<DriverSuggestionPriority> driverSuggestionPriority = Arrays.stream(DriverSuggestionPriority.values()).filter(p -> p.getPriority() == priority)
                .findFirst();

        if (driverSuggestionPriority.isPresent()) {
            return driverSuggestionPriority.get();
        }

        return SELECTED;
    }
}