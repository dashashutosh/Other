package com.walmart.dms.common.utils;

import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.server.common.error.Error;
import com.walmart.dms.server.common.exception.BusinessException;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;
import com.walmart.dms.common.enums.UserRole;

import java.util.Objects;

import static com.walmart.dms.common.enums.UserRole.CARRIER_ADMIN;

@Slf4j
@Component
public class AuthorizationUtils {

    @Autowired
    private CommonConfig commonConfig;

    /**
     * This method does authority check for given combination of realmId, loginId and driverUserId
     * @param realmId
     * @param loginId
     * @param driverUserId
     * @throws BusinessException
     */
    public void authorityCheck(String realmId, String loginId, String driverUserId) throws BusinessException {
        if (!commonConfig.isAuthorityCheckEnabled()) {
            return;
        }

        if (!commonConfig.getRealmIdsForAuthCheck().contains(realmId)) {
            return;
        }

        if (loginId == null || driverUserId == null || !loginId.equalsIgnoreCase(driverUserId)) {
            Error error = new Error("401", "driverUserId", "Authorization error",
                    "logged in user: " + loginId + " is not authorized to access: " + driverUserId);
            throw new BusinessException(error, 401);
        }
    }

    /**
     * This method does authority check and validated the realmId, loginId and driverUserId
     * * @param realmId
     * * @param loginId
     * * @param driverUserId
     * * @throws BusinessException
     */
    @SuppressFBWarnings("RCN_REDUNDANT_NULLCHECK_OF_NONNULL_VALUE")
    public void authCheckForRealmIds(String realmId, String loginId, String driverUserId) throws BusinessException {

        if (!commonConfig.isAuthorityCheckEnabled()) {
            return;
        }
        //If both realmId and loginId is null , its for internal services
        if (realmId == null || loginId == null) {
            return;
        }
        //check realmId
        if (!commonConfig.getDmsRealmIds().contains(realmId)) {
            Error error = new Error("401", "realmId", "Authorization RealmId error",
                    "Invalid realmId: " + realmId + " is not authorized to access");
            throw new BusinessException(error, 401);

        }

        //validate driverUserId
        if ((commonConfig.getDmsRealmIdsFromSparkApp().contains(realmId)) && (loginId == null || driverUserId == null || !loginId.equalsIgnoreCase(driverUserId))) {
            Error error = new Error("401", "driverUserId", "Authorization LoginId error",
                    "logged in user: " + loginId + " is not authorized to access: " + driverUserId);
            throw new BusinessException(error, 401);
        }

    }

    /**
     * This method does authority check and validated the loggedin user scac with request scac
     * @param loginId
     * @param inputScacCode
     * @param loginUserScacCode
     * @throws BusinessException
     */
    public void validateAuthCheckForScac(String loginId, String inputScacCode, String loginUserScacCode ) throws BusinessException {
        if(Objects.nonNull(inputScacCode) && !loginUserScacCode.equalsIgnoreCase(inputScacCode)) {
            log.error("Authorization error : LoggedIn User {} is unauthorized to perform this operation for the scac : {}", loginId, inputScacCode);
            Error error = new Error("401.035", null, "Authorization error",
                    "LoggedIn User : " + loginId + " is unauthorized to perform this operation for the scac : " + inputScacCode);
            throw new BusinessException(error, 401);
        }
    }

    /**
     * This method does authority check and validated the loggedin user scac with request scac
     * @param loginId
     * @param inputOrg
     * @param loginUserOrg
     * @throws BusinessException
     */
    public void validateAuthCheckForOrg(String loginId, String inputOrg, String loginUserOrg ) throws BusinessException {
        if(!loginUserOrg.equalsIgnoreCase(inputOrg)) {
            log.error("Authorization error : LoggedIn User {} is unauthorized to perform this operation for the org : {}", loginId, inputOrg);
            Error error = new Error("401.035", null, "Authorization error",
                    "LoggedIn User : " + loginId + " is unauthorized to perform this operation for the org : " + inputOrg);
            throw new BusinessException(error, 401);
        }
    }
    /**
     * This method does check and validates the loggedin user role is Carrier_Admin
     * @param loginId
     * @param role
     * @throws BusinessException
     */
    public void isCarrierAdminRole(String loginId, String role) throws BusinessException {
        if(!role.equalsIgnoreCase(CARRIER_ADMIN.toString())) {
            log.error("Authorization error : LoggedIn User {} is unauthorized to perform this operation for his role : {}", loginId, role);
            Error error = new Error("401.036", null, "Authorization error",
                    "LoggedIn User : " + loginId + " is unauthorized to perform this operation for his role : "+role);
            throw new BusinessException(error, 401);
        }
    }
}
