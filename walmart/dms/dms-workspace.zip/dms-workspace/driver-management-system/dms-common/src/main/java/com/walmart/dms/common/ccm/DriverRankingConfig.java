package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Data
@Configuration(configName = "driverRankingConfig")
public class DriverRankingConfig {

    @Property(propertyName = "driverRanking.host")
    private String host;

    @Property(propertyName = "driverRanking.maas.host")
    private String maasHost;

    @Property(propertyName = "driverRanking.log.level")
    public String logLevel;

    @Property(propertyName = "driverRanking.read.timeout.sec")
    public int readTimeOutInSec;

    @Property(propertyName = "driverRanking.connect.timeout.sec")
    public int connectTimeOutInSec;

    @Property(propertyName = "driverRanking.api.header")
    public String apiHeaders;

    @Property(propertyName = "driverRanking.maas.api.header")
    public String maasApiHeaders;

    @Property(propertyName = "driverRanking.max.retry.count")
    public int maxRetryCount;

    @Property(propertyName = "driverRanking.maas.deployment.enabled")
    private boolean maasDeploymentEnabled = false;
}
