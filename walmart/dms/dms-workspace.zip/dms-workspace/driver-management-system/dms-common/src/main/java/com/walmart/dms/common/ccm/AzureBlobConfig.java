package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Configuration(configName = "azureBlobConfig")
@Data
public class AzureBlobConfig {
    @Property(propertyName = "dms.driver.pii.driver.license.container.name")
    public String dmsDriverPIIDriverLicenseContainerName;

    @Property(propertyName = "dms.driver.pii.driver.profile.pic.container.name")
    public String dmsDriverPIIDriverProfilePicContainerName;

    @Property(propertyName = "dms.driver.pii.azure.driver.license.connection.string")
    public String dmsDriverPIIAzureDriverLicenseConnectionString;

    @Property(propertyName = "dms.driver.pii.azure.driver.sas.token.expired.minutes")
    public int dmsDriverPIIAzureDriverSasTokenExpiredMinutes;

    @Property(propertyName = "dms.driver.pii.azure.driver.sas.token.pre.expired.minutes")
    public int dmsDriverPIIAzureDriverSasTokenPreExpiredMinutes;

    @Property(propertyName = "dms.driver.pii.azure.is.sas.token.append.get.driver.enabled")
    public boolean dmsDriverPIIAzureIsSASTokenAppendGetDriverEnabled;

    @Property(propertyName = "dms.driver.pii.driver.max.file.upload.size.limit.in.mb")
    @DefaultValue.Int(2)
    public int dmsDriverPIIDriverMaxFileUploadSizeLimitInMB;
}
