package com.walmart.dms.common.spotlight;

import com.walmart.dms.common.enums.SpotLightPriority;
import com.walmart.dms.common.spotlight.model.DMSApiFailureEvent;
import com.walmart.dms.common.spotlight.model.DMSFailureEvent;
import com.walmart.dms.common.spotlight.model.DMSInfoEvent;
import com.walmart.dms.server.common.error.Error;
import com.walmart.dms.server.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.validation.ConstraintViolationException;

/**
 * It is a helper or utility class exposing miscellaneous spotlight utility methods.
 *
 * @author a0d02yr
 */
@Component
@Slf4j
public class SpotLightHelper {

    @Autowired
    private SpotLightService spotLightService;

    @Autowired
    private SpotLightConfig spotLightConfig;

    /**
     * Sends a failure spotlight with given parameters.
     *
     * @param errorMessage the error message
     * @param logMessage   the log message
     * @param errorType    the error type
     * @param priority     the priority of the spotlight
     */
    public void sendFailureSpotlight(final String errorMessage, final String logMessage, final String errorType, final SpotLightPriority priority) {
        final DMSApiFailureEvent request = new DMSApiFailureEvent.Builder()
                .error(errorMessage).log(logMessage)
                .eventId(spotLightConfig.getFailureAlertEventId())
                .type(errorType).priority(priority).build();
        spotLightService.sendEvent(request);
    }

    /**
     * Sends a failure spotlight with given parameters.
     *
     * @param errorMessage the error message
     * @param logMessage   the log message
     * @param errorType    the error type
     * @param priority     the priority of the spotlight
     * @throws BusinessException throws the given exception
     */
    public void sendFailureSpotlightAndThrowException(final String errorMessage, final String logMessage, final String errorType,
                                                      final SpotLightPriority priority, final BusinessException e) throws BusinessException {
        final DMSApiFailureEvent request = new DMSApiFailureEvent.Builder()
                .error(errorMessage).log(logMessage)
                .eventId(spotLightConfig.getFailureAlertEventId())
                .type(errorType).priority(priority).build();
        spotLightService.sendEvent(request);

        throw e;
    }

    /**
     * Sends a failure spotlight with given parameters.
     *
     * @param errorMessage    the error message
     * @param logMessage      the log message
     * @param errorType       the error type
     * @param requestPayload  the request payload
     * @param responsePayload the response payload
     * @param priority        the priority of the spotlight
     */
    public void sendFailureSpotlight(final String errorMessage, final String logMessage, final String errorType, final String requestPayload,
                                     final String responsePayload, final SpotLightPriority priority) {
        final DMSApiFailureEvent request = new DMSApiFailureEvent.Builder()
                .error(errorMessage).log(logMessage)
                .requestPayload(requestPayload).responsePayload(responsePayload)
                .eventId(spotLightConfig.getFailureAlertEventId())
                .type(errorType).priority(priority).build();
        spotLightService.sendEvent(request);
    }

    public void sendSpotlight(String errorMsg, String eventMessage, String errorType, Exception e, Error error, SpotLightPriority spotLightPriority) {

        String logMessage = errorMsg + (StringUtils.isEmpty(eventMessage) ? (" Event message: " + eventMessage) : "");
        if (e == null) {
            log.error(logMessage);
        } else {
            log.error(logMessage, e);
        }
        final String exMessage = e != null ? (" Error: " + e.getMessage()) : "";
        DMSFailureEvent request = new DMSFailureEvent.Builder().error((error != null) ? error.getDescription() : (logMessage + exMessage))
                .log((error != null) ? logMessage : "").eventId(spotLightConfig.getFailureAlertEventId()).type(errorType).priority(spotLightPriority).build();
        spotLightService.sendEvent(request);
    }

    public void sendSpotlight(String errorMsg, String eventMessage, String errorType, SpotLightPriority spotLightPriority) {
        sendSpotlight(errorMsg, eventMessage, errorType, null, null, spotLightPriority);
    }

    public void sendSpotlightAndThrowException(String errorMsg, String eventMessage, String errorType, Exception e,
                                               Error error, SpotLightPriority spotLightPriority) throws BusinessException {
        sendSpotlight(errorMsg, eventMessage, errorType, e, error, spotLightPriority);
        throw new BusinessException(e);
    }

    public void sendSpotlightAndThrowException(String errorMsg, String eventMessage, String errorType, Error error, SpotLightPriority spotLightPriority) throws BusinessException {
        sendSpotlight(errorMsg, eventMessage, errorType, null, error, spotLightPriority);
        throw new BusinessException(error);
    }

    public void sendSpotlightAndThrowException(String errorMsg, String eventMessage, String errorType, SpotLightPriority spotLightPriority) throws BusinessException {
        sendSpotlight(errorMsg, eventMessage, errorType, null, null, spotLightPriority);
        throw new BusinessException(errorMsg);
    }

    public void sendSpotlightAndThrowException(String errorMsg, String eventMessage, String errorType, Exception e, SpotLightPriority spotLightPriority) throws BusinessException {
        if(e instanceof ConstraintViolationException) {
            // These are race conditions which are handled by unique constraint violation in DB. No Spotlight required for these cases.
            throw new BusinessException(e);
        }
        sendSpotlight(errorMsg, eventMessage, errorType, e, null, spotLightPriority);
        throw new BusinessException(e);
    }

    /**
     * Sends an info spotlight.
     *
     * @param infoMessage the information message
     * @param shortDesc   the short description of the event
     * @param eventType   the event type
     * @param eventId     the event id
     */
    public void sendInfoSpotlight(final String infoMessage, final String shortDesc, final String eventType, final String eventId) {
        final DMSInfoEvent event = new DMSInfoEvent.Builder().info(infoMessage).eventId(eventId).shortDesc(shortDesc).type(eventType).build();
        spotLightService.sendEvent(event);
    }
}
