package com.walmart.dms.common.exception;

import java.util.ArrayList;
import java.util.List;

import com.walmart.dms.common.error.ErrorCode;
import com.walmart.dms.server.common.exception.PlatformException;

public class InvalidRequestException extends PlatformException {

	/**
	 * class version id for serialization
	 */
	private static final long serialVersionUID = 1L;

	private List<ErrorCode> errorCodes = new ArrayList<ErrorCode>();

	public InvalidRequestException(ErrorCode errorCode, String message) {
		super(message);
		this.errorCodes.add(errorCode);
	}

	public InvalidRequestException(List<ErrorCode> errorCodes, String message) {
		super(message);
		this.errorCodes = errorCodes;
	}

	/**
	 * @return
	 */
	public ErrorCode getCode() {
		return this.errorCodes == null ? null : this.errorCodes.get(0);
	}

	/**
	 * @return the errorCodes
	 */
	public List<ErrorCode> getCodes() {
		return errorCodes;
	}

}