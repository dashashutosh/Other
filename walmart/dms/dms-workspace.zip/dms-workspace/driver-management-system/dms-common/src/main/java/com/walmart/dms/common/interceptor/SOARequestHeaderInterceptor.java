package com.walmart.dms.common.interceptor;

import com.walmart.dms.common.utils.SignatureGenerator;
import io.strati.libs.commons.lang3.StringUtils;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

public class SOARequestHeaderInterceptor implements Interceptor {

	private String consumerId;
	private String env;
	private String version;
	private String tenantId;
	private String vertiacalId;
	private String privateKey;
	private String privateKeyVersion;
	private String serviceName;

	private Map<String, String> headers;

	public SOARequestHeaderInterceptor(Map<String, String> headers) {
		this.headers = headers;
	}

	public SOARequestHeaderInterceptor(Map<String, String> headers, String consumerId,String privateKey, String privateKeyVersion) {
		this.headers = headers;
		this.consumerId=consumerId;
		this.privateKey = privateKey;
		this.privateKeyVersion = privateKeyVersion;
	}

	public SOARequestHeaderInterceptor(String env, String version, String consumerId, String tenantId,
			String vertiacalId) {
		this.consumerId = consumerId;
		this.version = version;
		this.env = env;
		this.tenantId = tenantId;
		this.vertiacalId = vertiacalId;

	}

	public SOARequestHeaderInterceptor(String env, String version, String consumerId, String tenantId,
			String vertiacalId, String privateKey, String privateKeyVersion) {
		this.consumerId = consumerId;
		this.version = version;
		this.env = env;
		this.tenantId = tenantId;
		this.vertiacalId = vertiacalId;
		this.privateKey = privateKey;
		this.privateKeyVersion = privateKeyVersion;
	}

	public SOARequestHeaderInterceptor(String env, String version, String consumerId, String tenantId,
									   String vertiacalId, String privateKey, String privateKeyVersion, String serviceName) {
		this.consumerId = consumerId;
		this.version = version;
		this.env = env;
		this.tenantId = tenantId;
		this.vertiacalId = vertiacalId;
		this.privateKey = privateKey;
		this.privateKeyVersion = privateKeyVersion;
		this.serviceName = serviceName;
	}

	@Override
	public Response intercept(Interceptor.Chain chain) throws IOException {
		Request original = chain.request();
		// Request customization: add request headers
		Request.Builder requestBuilder = original.newBuilder();
		if (this.headers == null) {
			requestBuilder
			.header("WM_SVC.VERSION", this.version)
			.header("WM_SVC.ENV", this.env)
			.header("WM_SVC.NAME", this.serviceName != null ? this.serviceName : "lastmile-dms")
			.header("WM_CONSUMER.ID", getConsumerId())
			.header("WM_CONSUMER.TENANT_ID", this.tenantId)
			.header("WM_CONSUMER.VERTICAL_ID", this.vertiacalId)
			.header("WM_QOS.CORRELATION_ID", UUID.randomUUID().toString());

		} else {
			requestBuilder.headers(Headers.of(headers));

			for (final String headerName : original.headers().names()) {
				requestBuilder.header(headerName, original.headers().get(headerName));
			}
		}
		if (!StringUtils.isBlank(this.privateKey)) {
			String timeStamp=Long.toString(System.currentTimeMillis());
			SignatureGenerator signatureGenerator = new SignatureGenerator(this.privateKeyVersion, this.consumerId,
					privateKey, timeStamp);
			String authSignature = signatureGenerator.generateSignature();
			requestBuilder.header("WM_SEC.AUTH_SIGNATURE", authSignature)
			.header("WM_SEC.TIMESTAMP", timeStamp)
			.header("WM_CONSUMER.INTIMESTAMP", timeStamp)
			.header("WM_SEC.KEY_VERSION", this.privateKeyVersion);
		}
		Request request = requestBuilder.build();
		return chain.proceed(request);
	}

	public String getConsumerId() {
		return consumerId;
	}

}
