package com.walmart.dms.common.filter;

import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.utils.Utils;
import com.walmart.dms.server.common.error.Status;
import com.walmart.dms.server.common.service.ServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Priority;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
import java.util.Set;

/**
 * @author j0p060t
 */
//@Priority(1)
//@Provider
public class HeaderValidationFilter {/* implements ContainerRequestFilter {

    @Autowired
    CommonConfig commonConfig;

    *//**
     * Cross verify API Request has mandatory headers or not and reject request for invalid headers
     * @param requestContext
     *//*
    @Override
    public void filter(final ContainerRequestContext requestContext){
            String countryCode = requestContext.getHeaderString(Constant.COUNTRY_CODE_HEADER_KEY);
            String verticalId = requestContext.getHeaderString(Constant.VERTICAL_ID_HEADER_KEY);
            String tenantId = requestContext.getHeaderString(Constant.TENANT_ID_HEADER_KEY);
            String requestURI = requestContext.getUriInfo().getPath();
            boolean  verifyCountryCode = commonConfig.getDmsCountryCodeEnabledAPI().stream().anyMatch(api -> requestURI.contains(api));
            if(verticalId == null || verticalId.isEmpty() || tenantId == null || tenantId.isEmpty()) {
                requestContext.abortWith(Response.status(Response.Status.BAD_REQUEST).entity(errorResponse(Constant.VERTICAL_TENANT_ERROR)).build());
            }
            if (verifyCountryCode) {
                if (countryCode == null || countryCode.isEmpty()) {
                    requestContext.abortWith(Response.status(Response.Status.BAD_REQUEST).entity(errorResponse(Constant.COUNTRY_CODE_ERROR)).build());
                } else if(!verifyCountryCodeValue(countryCode)) {
                    requestContext.abortWith(Response.status(Response.Status.BAD_REQUEST).entity(errorResponse(Constant.INVALID_COUNTRY_CODE)).build());
                }
            }
    }

    *//**
     * Returns appropraite error message for requst abortion
     * @param errorMessage
     * @return serviceResponse
     *//*
    private ServiceResponse<String> errorResponse(String errorMessage) {
        final ServiceResponse<String> response = new ServiceResponse<>();
        response.setErrors(Utils.getErrorList(Integer.valueOf(Status.BAD_REQUEST.getCode()), errorMessage));
        response.setStatus(Status.BAD_REQUEST);
        return response;
    }

    *//**
     * Verfiy's country code is valid value or not
     * @param countryCode
     * @return boolean value
     *//*
    private boolean verifyCountryCodeValue(String countryCode) {
        Set<String> ccmCountryCode = commonConfig.getDmsEnabledCountryCode();
        return ccmCountryCode.contains(countryCode);
    }*/
}
