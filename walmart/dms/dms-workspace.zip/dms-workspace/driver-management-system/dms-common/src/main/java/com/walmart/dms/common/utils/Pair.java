package com.walmart.dms.common.utils;

/**
 * A pair of two elements.
 *
 * @author a0d02yr
 */
public final class Pair<A, B> {
    private final A firstElement;
    private final B secondElement;

    /**
     * Creates and returns a new instance of Pair from the given first and second elements.
     *
     * @param firstElement  the first element
     * @param secondElement the second element
     */
    public Pair(final A firstElement, final B secondElement) {
        this.firstElement = firstElement;
        this.secondElement = secondElement;
    }

    /**
     * Creates a new instance of Pair from the given first and second elements.
     *
     * @param firstElement  the first element
     * @param secondElement the second element
     * @param <A>           the first element type
     * @param <B>           the second element type
     * @return a new instance of Pair
     */
    public static <A, B> Pair<A, B> with(final A firstElement, final B secondElement) {
        return new Pair<>(firstElement, secondElement);
    }

    /**
     * Creates a new instance of Pair from the given array. Array has to have exactly two elements.
     *
     * @param array the array to be converted to a pair
     * @param <X>   the array component type
     * @return a new instance of Pair
     */
    public static <X> Pair<X, X> fromArray(final X[] array) {
        if (array == null) {
            throw new IllegalArgumentException("Array cannot be null");
        }
        if (array.length != 2) {
            throw new IllegalArgumentException("Array must have exactly 2 elements in order to create a Pair. Size is " + array.length);
        }
        return new Pair<>(array[0], array[1]);
    }

    /**
     * Gets the first element.
     *
     * @return the first element
     */
    public A getFirstElement() {
        return this.firstElement;
    }

    /**
     * Gets the second element.
     *
     * @return the second element
     */
    public B getSecondElement() {
        return this.secondElement;
    }
}
