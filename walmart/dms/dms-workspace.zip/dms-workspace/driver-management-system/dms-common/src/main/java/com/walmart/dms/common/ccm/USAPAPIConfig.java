package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

/**
 * @author s0p05dz on April 08. 2021
 *
 */
@Data
@Configuration(configName = "usapApiConfig")
public class USAPAPIConfig {

    @Property(propertyName = "usap.api.host.url")
    public String hostUrl;

    @Property(propertyName = "usap.api.log.level")
    public String logLevel;

    @Property(propertyName ="usap.api.api.header")
    public String apiHeaders;

    @Property(propertyName ="usap.api.read.timeout.sec")
    public Integer readTimeOutInSec = 5;

    @Property(propertyName ="usap.api.connect.timeout.sec")
    public Integer connectTimeOutInSec = 5;

    @Property(propertyName = "usap.api.max.retry.count")
    public int maxRetryCount;

}
