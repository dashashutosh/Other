package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Configuration(configName = "dataLakeConfig")
@Data
public class DataLakeConfig {

    @Property(propertyName = "dataLake.projectId")
    private String projectId;

    @Property(propertyName = "dataLake.badge.table")
    private String badgeTable;

    @Property(propertyName = "dataLake.badge.level")
    private String badgeLevel;

    @Property(propertyName = "dataLake.badge.batchSize")
    private int batchSize;

    @Property(propertyName = "dataLake.badge.thread.pool")
    private int threadPoolSize;

    @Property(propertyName = "dataLake.auth.credentials")
    private String authCredentials;

    @Property(propertyName = "dataLake.job.retry.delay.sec")
    private long jobRetryDelay;

    @Property(propertyName = "dataLake.job.timeout.min")
    private long jobTimeout;
}
