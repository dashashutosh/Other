/**
 *
 */
package com.walmart.dms.common.filter;

import java.io.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import javax.annotation.Priority;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.MultivaluedMap;

import com.google.gson.Gson;
import com.walmart.dms.common.ccm.DMSEventsConfig;
import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.helper.PublisherHelper;
import com.walmart.dms.common.kafka.event.DMSReportingEvent;
import com.walmart.dms.common.kafka.event.DMSReportingEventHeader;
import com.walmart.dms.common.kafka.producers.DMSReportingEventsProducer;
import com.walmart.dms.common.utils.LogUtil;
import com.walmart.dms.common.utils.MaskingUtils;
import io.strati.libs.logging.log4j2.message.StringFormatterMessageFactory;
import org.apache.commons.lang.StringUtils;
import org.glassfish.jersey.message.internal.ReaderWriter;
import org.slf4j.MDC;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author s0k00tl
 */
@Slf4j
@SuppressFBWarnings
@Component
@Priority(500)
public class RRLogFilter implements ContainerRequestFilter, ContainerResponseFilter {

    @Autowired
    private LogUtil logUtil;

    @Autowired
    private MaskingUtils maskingUtils;

    @Autowired
    private CommonConfig commonConfig;

    @Autowired
    private PublisherHelper publisherHelper;

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {

        final String requestId = UUID.randomUUID().toString();
        MDC.put("requestId", requestId);

        final StringBuilder strBdr = new StringBuilder();
        final List<Object> arguments = new ArrayList<>();

        strBdr.append("Request: Method: %s, Path: %s");
        arguments.add(requestContext.getMethod());
        arguments.add(requestContext.getUriInfo().getPath());

        final String headers = logUtil.getLogPayload(getHeaders(requestContext));

        List<String> basePaths = commonConfig.getDmsRRLogFilterRestrictHeaderLogForApi();
        String requestPath = requestContext.getUriInfo().getPath();
        // Check if the request path starts with any of the base paths
        boolean isApiHeaderRestricted = basePaths.stream()
                .anyMatch(basePath -> requestPath.startsWith(basePath));

        if(!isApiHeaderRestricted){
            if (StringUtils.isNotBlank(headers)) {
                strBdr.append(", Headers: %s");
                arguments.add(headers);
            }
        }
        String requestPayload = getEntityBody(requestContext);
        String payload = null;

        if(!commonConfig.getDmsRRLogFilterRestrictedApi().contains(requestContext.getUriInfo().getPath())){
            if (!requestContext.getMethod().equals("GET")) {
                String maskedPayload =  maskingUtils.maskPiiWithJsonPath(requestPayload);
                payload = logUtil.getLogPayload(maskedPayload);
            }
            else {
                payload = logUtil.getLogPayload(requestPayload);
            }
        }

        if (StringUtils.isNotBlank(payload)) {
            strBdr.append(", Payload: %s");
            arguments.add(payload);
        }


        if(commonConfig.dmsIdVerificationDataPublishEnabled && requestContext.getUriInfo().getPath().equalsIgnoreCase(commonConfig.dmsIdVerificationApiV2)) {
            if(commonConfig.dmsIdVerificationApiV2AsyncEnabled) {
                long beforeAsyncCall = System.currentTimeMillis();
                publisherHelper.publishIdVerificationData(requestPayload);
                long afterAsyncCall = System.currentTimeMillis();
                long executionTime = afterAsyncCall - beforeAsyncCall;
                log.info(LogUtil.buildJsonLog(
                        "[filter] Async Call time",
                        com.walmart.dms.common.utils.Pair.with("async_produce_call_time", executionTime))
                );
            } else {
                publisherHelper.publishPersonaData(requestPayload);
            }

        }
        log.info(StringFormatterMessageFactory.INSTANCE.newMessage(strBdr.toString(), arguments.toArray()).getFormattedMessage());
    }

    private String getHeaders(ContainerRequestContext requestContext) {
        MultivaluedMap<String, String> reqHeaders = requestContext.getHeaders();
        final StringBuilder b = new StringBuilder();
        if(reqHeaders == null || reqHeaders.isEmpty() || reqHeaders.size() == 0) {
            b.append("\n");
        } else {
            b.append("{").append("\n");
            reqHeaders.forEach((k,v)->b.append(k+":"+v).append("\n"));
            b.append("}").append("\n");
        }
        return b.toString();
    }

    private String getEntityBody(ContainerRequestContext requestContext) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        InputStream in = requestContext.getEntityStream();

        final StringBuilder b = new StringBuilder();
        try {
            ReaderWriter.writeTo(in, out);

            byte[] requestEntity = out.toByteArray();
            if (requestEntity.length == 0) {
                b.append("\n");
            } else {
                b.append(new String(requestEntity)).append("\n");
            }
            requestContext.setEntityStream(new ByteArrayInputStream(requestEntity));

        } catch (IOException ex) {
            // Do Nothing.
        }
        return b.toString();
    }

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
            throws IOException {
        final StringBuilder strBdr = new StringBuilder();
        final List<Object> arguments = new ArrayList<>();

        try {
            strBdr.append("Response Status Code: %s");
            arguments.add(responseContext.getStatusInfo().getStatusCode());
            strBdr.append(", Payload: %s");
            if(!commonConfig.getDmsRRLogFilterRestrictedApi().contains(requestContext.getUriInfo().getPath())) {
                if(commonConfig.isEnableDMSDriverResponseRRLogFilter()) {
                    arguments.add(logUtil.getLogPayload(responseContext.getEntity()));
                }
            }
            else {
                arguments.add("");
            }
            log.info(StringFormatterMessageFactory.INSTANCE.newMessage(strBdr.toString(), arguments.toArray()).getFormattedMessage());
        } catch (Exception e) {
            log.error("Error: ", e);
        } finally {
            MDC.remove("requestId");
        }
    }
}