package com.walmart.dms.common.enums;

/**
 * @author n0a008p on Mar 13, 2018
 * @author sdhaka on Mar 23 ,2018
 *
 */
public enum PaymentProvider {
	PAYONEER("PAYONEER"),
	DDI("DDI"),
	NONE("NONE");

	private final String value;

	PaymentProvider(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static PaymentProvider find(final String type) {
		for (final PaymentProvider provider : PaymentProvider.values()) {
			if (provider.getValue().equalsIgnoreCase(type)) {
				return provider;
			}
		}
		return null;

	}
}
