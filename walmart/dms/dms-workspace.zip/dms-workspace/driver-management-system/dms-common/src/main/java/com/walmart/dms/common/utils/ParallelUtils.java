package com.walmart.dms.common.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public final class ParallelUtils {

    private ParallelUtils() {

    }

    private static <T> CompletableFuture<List<T>> getResponseFromFutures(List<CompletableFuture<T>> executionFutures) {
        CompletableFuture<Void> waitForData = CompletableFuture
                .allOf(executionFutures.toArray(new CompletableFuture<?>[executionFutures.size()]));

        return waitForData.thenApply(data -> executionFutures.stream().map(CompletableFuture::join)
                .collect(Collectors.toList()));
    }

    public static <T> List<T> executeInParallel(List<Supplier<T>> supplierList, Executor executor)
            throws ExecutionException, InterruptedException {
        List<CompletableFuture<T>> futuresList = new ArrayList<>();
        for (Supplier<T> tSupplier : supplierList) {
            CompletableFuture<T> fResult = CompletableFuture.supplyAsync(tSupplier, executor);
            futuresList.add(fResult);
        }
        CompletableFuture<List<T>> combinedFutures = getResponseFromFutures(futuresList);
        return combinedFutures.get();
    }

}
