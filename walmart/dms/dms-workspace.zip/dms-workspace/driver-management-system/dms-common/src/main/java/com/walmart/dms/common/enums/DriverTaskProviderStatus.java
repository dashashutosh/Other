package com.walmart.dms.common.enums;

import java.util.Arrays;

public enum DriverTaskProviderStatus {
    OPT_IN, OPT_OUT, NOT_NOW, KNOW_MORE;
    
    public static DriverTaskProviderStatus getByName(String name) {
        return Arrays.asList(DriverTaskProviderStatus.values()).stream().filter(n -> n.name().equals(name)).findFirst()
                .orElse(null);
    }
}
