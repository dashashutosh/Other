package com.walmart.dms.common.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.dms.common.ccm.*;
import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.config.DmsDeleteDriverAccountsConfig;
import com.walmart.dms.common.config.DriverCpraConfig;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.error.ErrorMapper;
import com.walmart.dms.common.exception.ExceptionHandler;
import com.walmart.dms.common.kafka.configs.DSEPEventConfig;
import com.walmart.dms.common.kafka.configs.MyMetricsEventConfig;
import com.walmart.dms.common.kafka.configs.DMSKafkaConfig;
import com.walmart.dms.common.utils.LogUtil;
import com.walmart.dms.common.utils.Pair;
import com.walmart.dms.common.utils.Utils;
import io.strati.StratiServiceProvider;
import io.strati.configuration.ConfigType;
import io.strati.configuration.ConfigurationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.client.HttpComponentsAsyncClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;
import com.walmart.dms.common.config.ArgusConfig;
import java.util.concurrent.Executor;

@Configuration
@Slf4j
public class CommonConfiguration {



    @Autowired
    @Lazy
    private ElasticSearchConfig elasticSearchConfig;


    @Bean
    public ErrorMapper errorMapper() {
        return new ErrorMapper();
    }

//    @Bean
//    public ObjectMapper jacksonObjectMapper() {
//        return new ObjectMapper();
//    }

    @Bean
    public ObjectMapper objectMapper() {
        return Utils.getMapper();
    }

    @Bean
    public MethodValidationPostProcessor methodValidationPostProcessor() {
        return new MethodValidationPostProcessor();
    }

    @Bean
    public ExceptionHandler exceptionHandler() {
        return new ExceptionHandler(errorMapper());
    }

    @Bean
    public ConfigurationService configurationService() {
        return StratiServiceProvider.getInstance().getConfigurationService().get();
    }

    @Bean
    public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() {
        PoolingHttpClientConnectionManager result = new PoolingHttpClientConnectionManager();
        result.setMaxTotal(50);
        return result;
    }

    @Bean
    public RequestConfig requestConfig() {
        RequestConfig result = RequestConfig.custom()
                .setConnectionRequestTimeout(elasticSearchConfig.getElasticEsAsyncRestTimeoutInSec() * 1000)
                .setConnectTimeout(elasticSearchConfig.getElasticEsAsyncRestTimeoutInSec() * 1000)
                .setSocketTimeout(elasticSearchConfig.getElasticEsAsyncRestTimeoutInSec() * 1000)
                .build();
        return result;
    }

    @Bean
    public CloseableHttpClient httpClient(PoolingHttpClientConnectionManager poolingHttpClientConnectionManager, RequestConfig requestConfig) {
        CloseableHttpClient result = HttpClientBuilder
                .create()
                .setConnectionManager(poolingHttpClientConnectionManager)
                .setDefaultRequestConfig(requestConfig)
                .build();
        return result;
    }

    @Bean
    public RestTemplate restTemplate(HttpClient httpClient) {
        /*RestTemplate restTemplate = new RestTemplate();
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
        factory.setConnectionRequestTimeout(10 * 1000);
        factory.setReadTimeout(10 * 1000);

        factory.setHttpClient(httpClient);
        restTemplate.setRequestFactory(factory);
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(objectMapper);
        restTemplate.getMessageConverters().add(converter);
        return restTemplate;*/

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);
        return new RestTemplate(requestFactory);
    }

    @Bean(name = "asyncRestTemplateEs")
    public AsyncRestTemplate asyncRestTemplate(ObjectMapper objectMapper) {
        AsyncRestTemplate restTemplate = new AsyncRestTemplate();
        HttpComponentsAsyncClientHttpRequestFactory factory = new HttpComponentsAsyncClientHttpRequestFactory();
        factory.setConnectionRequestTimeout(elasticSearchConfig.getElasticEsAsyncRestTimeoutInSec() * 1000);
        factory.setReadTimeout(elasticSearchConfig.getElasticEsAsyncRestTimeoutInSec() * 1000);

        restTemplate.setAsyncRequestFactory(factory);

        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(objectMapper);
        restTemplate.getMessageConverters().add(converter);
        return restTemplate;
    }


    @Bean
    public ElasticSearchConfig elasticSearchConfig() {
        ElasticSearchConfig config = configurationService().getConfiguration(ElasticSearchConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public ErrorRetryConfig errorRetryConfig() {
        ErrorRetryConfig config = configurationService().getConfiguration(ErrorRetryConfig.class, ConfigType.SIMPLE);
        return config;
    }

    //TODO: Check if below method is used anywhere in the code
    @Bean
    public DMSEventsConfig dmsEventsConfig() {
        DMSEventsConfig config = configurationService().getConfiguration(DMSEventsConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public CommonConfig dmsCommonConfig() {
        CommonConfig config = configurationService().getConfiguration(CommonConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DriverAcceptanceConfig driverAcceptanceConfig() {
        DriverAcceptanceConfig config = configurationService().getConfiguration(DriverAcceptanceConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DriverRankingConfig driverRankingConfig() {
        DriverRankingConfig config = configurationService().getConfiguration(DriverRankingConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public ArgusConfig argusConfig() {
        ArgusConfig config = configurationService().getConfiguration(ArgusConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public ConfigSystemAPIConfig configSystemAPIConfig() {
        ConfigSystemAPIConfig config = configurationService().getConfiguration(ConfigSystemAPIConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public USAPAPIConfig usapapiConfig() {
        USAPAPIConfig config = configurationService().getConfiguration(USAPAPIConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DriverSuggestionConfig driverSuggestionConfig() {
        final DriverSuggestionConfig config = configurationService().getConfiguration(DriverSuggestionConfig.class,
                ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DMSKafkaConfig dmsKafkaConfig() {
        final DMSKafkaConfig config = configurationService().getConfiguration(DMSKafkaConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public MyMetricsEventConfig myMetricsEventConfig() {
        final MyMetricsEventConfig config = configurationService().getConfiguration(MyMetricsEventConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DSEPEventConfig dsepEventConfig() {
        final DSEPEventConfig config = configurationService().getConfiguration(DSEPEventConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public CoreHrAPIConfig coreHrAPIConfig() {
        final CoreHrAPIConfig config = configurationService().getConfiguration(CoreHrAPIConfig.class, ConfigType.SIMPLE);
        return config;
    }


    @Bean
    public WFMScheduleAPIConfig mwfScheduleAPIConfig() {
        final WFMScheduleAPIConfig config = configurationService().getConfiguration(WFMScheduleAPIConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public InHomeExecutorThreadPoolConfig inHomeExecutorThreadPoolConfig() {
        final InHomeExecutorThreadPoolConfig config = configurationService().getConfiguration(InHomeExecutorThreadPoolConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DataLakeConfig dataLakeConfig() {
        final DataLakeConfig config = configurationService().getConfiguration(DataLakeConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DriverCpraConfig driverCpraConfig() {
        final DriverCpraConfig config = configurationService().getConfiguration(DriverCpraConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DmsDeleteDriverAccountsConfig dmsDeleteDriverAccountsConfig() {
        final DmsDeleteDriverAccountsConfig config = configurationService().getConfiguration(DmsDeleteDriverAccountsConfig.class, ConfigType.SIMPLE);
        return config;
    }
    @Bean(value = "infoSecExecutor")
    public Executor getAsyncExecutor(CommonConfig commonConfig) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(commonConfig.getDmsInfoSecExecutorCorePoolSize());
        executor.setMaxPoolSize(commonConfig.getDmsInfoSecExecutorMaxPoolSize());
        executor.setQueueCapacity(commonConfig.getDmsInfoSecExecutorQueueCapacity());
        executor.setThreadNamePrefix(commonConfig.getDmsInfoSecExecutorThreadNamePrefix());
        return executor;
    }
    @Bean
    public SignatureConfig signatureConfig() {
        final SignatureConfig config = configurationService().getConfiguration(SignatureConfig.class, ConfigType.SIMPLE);
        return config;
    }
    @Bean
    public QuartzConfig quartzConfig() {
        final QuartzConfig config = configurationService().getConfiguration(QuartzConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public DriverDeactivatePauseConfig driverDeactivationConfig() {
        DriverDeactivatePauseConfig config = configurationService().getConfiguration(DriverDeactivatePauseConfig.class, ConfigType.SIMPLE);
        return config;
    }

    @Bean
    public ApiAuthConfig apiAuthConfig(){
        return configurationService().getConfiguration(ApiAuthConfig.class, ConfigType.SIMPLE);
    }

    @Bean
    public AzureBlobConfig azureBlobHelperConfig(){
        return configurationService().getConfiguration(AzureBlobConfig.class, ConfigType.SIMPLE);
    }

    @Bean
    public PIIBizConfig piiBizConfig(){
        return configurationService().getConfiguration(PIIBizConfig.class, ConfigType.SIMPLE);
    }

    @Bean
    public DmsElasticSearchConfig dmsElasticSearchConfig(){
        return configurationService().getConfiguration(DmsElasticSearchConfig.class, ConfigType.SIMPLE);
    }
}
