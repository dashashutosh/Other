package com.walmart.dms.common.dto;

import io.strati.libs.jackson.annotation.JsonInclude;
import io.strati.libs.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
public class InfoSecLogFilterDTO {
    @JsonProperty("time_utc")
    private String timeUtc;
    @JsonProperty("ProductName")
    private String productName;
    @JsonProperty("RequestMethod")
    private String requestMethod;
    @JsonProperty("RequestPath")
    private String requestPath;
    @JsonProperty("RequestPayload")
    private String requestPayload;
    @JsonProperty("RequestHeaders")
    private String requestHeaders;
    @JsonProperty("HTTPResponseCode")
    private String httpResponseCode;
    @JsonProperty("ResponsePayload")
    private String responsePayload;
    @JsonProperty("VendorName")
    private String vendorName;
    @JsonProperty("EventType")
    private String eventType;
}