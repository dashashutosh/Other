package com.walmart.dms.common.utils;

import com.google.gson.reflect.TypeToken;
import com.walmart.dms.common.ccm.VerificationBizConfig;
import com.walmart.dms.common.enums.DriverType;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import javax.annotation.PostConstruct;
import java.lang.reflect.Type;
import java.util.*;

import static com.walmart.dms.common.constant.Constant.FEATURE_ENABLED_FOR_ALL_MARKETS;

@Slf4j
@Component
public class VerificationUtils {

    @Autowired
    private VerificationBizConfig verificationBizConfig;

    private Map<String, Map<String, List<String>>> driverIdVerificationTenantMarketMap;

    private final Random random = new Random();

    public static final int MIN = 1;
    public static final int MAX = 11;

    @PostConstruct
    public void init() {

        String tempConfig = null;
        Type type = new TypeToken<HashMap<String, HashMap<String, List<String>>>>() {
        }.getType();

        try {
            tempConfig = verificationBizConfig.getDmsDriverIdVerificationTenantMarketMap();
            if (StringUtils.isNotBlank(tempConfig)) {
                driverIdVerificationTenantMarketMap = JsonWrapper.fromJson(tempConfig, type);
            }
        } catch (Exception e) {
            log.error("Error while initializing idVerificationTenantMarketMap" + e);
        }
    }

    @SuppressFBWarnings
    public boolean checkIfIDVerificationEnabledForMarket(String market, UUID driverUUID, DriverType driverType, String tenantId) {

        if (!verificationBizConfig.isDmsDriverIdVerificationEnabled() ||
                ObjectUtils.isEmpty(driverIdVerificationTenantMarketMap) ||
                ObjectUtils.isEmpty(driverIdVerificationTenantMarketMap.get(tenantId)) ||
                driverIdVerificationTenantMarketMap.get(tenantId).isEmpty() ||
                !driverIdVerificationTenantMarketMap.get(tenantId).containsKey(driverType.toString())) {
            return false;
        }

        List<String> enabledMarkets = driverIdVerificationTenantMarketMap.get(tenantId).get(driverType.toString());

        if (enabledMarkets.contains(FEATURE_ENABLED_FOR_ALL_MARKETS) ||
                enabledMarkets.contains(market)) {
            return true;
        }

        if(verificationBizConfig.getDmsDriverIdVerificationPartialEnabledMarkets().contains(market)) {
            int idVerificationProbability = Math.abs(driverUUID.hashCode())%10;
            if(idVerificationProbability < verificationBizConfig.getDmsDriverIdVerificationPartialRolloutPercent()) {
                return true;
            }
        }
        return false;
    }

    public boolean checkLoginBasedIdVerificationEnabled(String market) {
        if(verificationBizConfig.getDmsDriverLoginIdVerificationRolloutPercent() >= 10) {
            return true;
        }

        if(verificationBizConfig.getDmsDriverLoginIdVerificationEnabledMarkets().contains(FEATURE_ENABLED_FOR_ALL_MARKETS) ||
                verificationBizConfig.getDmsDriverLoginIdVerificationEnabledMarkets().contains(market)) {

            int loginVerificationProbability = random.nextInt(MAX-MIN)+MIN;
            log.info("Login Verification Probability: {}, rollOutPercentage: {}", loginVerificationProbability,
                    verificationBizConfig.getDmsDriverLoginIdVerificationRolloutPercent());

            return loginVerificationProbability <= verificationBizConfig.getDmsDriverLoginIdVerificationRolloutPercent();
        }
        return false;
    }
}
