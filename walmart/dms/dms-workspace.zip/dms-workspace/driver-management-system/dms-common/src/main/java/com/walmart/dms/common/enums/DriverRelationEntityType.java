package com.walmart.dms.common.enums;

public enum DriverRelationEntityType {
    STORE;
}
