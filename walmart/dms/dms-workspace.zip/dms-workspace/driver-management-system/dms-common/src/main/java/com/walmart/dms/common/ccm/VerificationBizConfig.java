package com.walmart.dms.common.ccm;

import com.walmart.dms.common.enums.DriverOfflineReason;
import com.walmart.dms.common.enums.DriverType;
import com.walmart.dms.common.enums.VerificationStatus;
import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;
import lombok.Data;

import java.util.List;
import java.util.Set;

/**
 * Created by a0s0od1
 */
@Configuration(configName = "verificationBizConfig")
@Data
public class VerificationBizConfig {

    @Property(propertyName = "dms.driver.id.verification.enabled.markets", delimiter = "#;#")
    public Set<String> dmsDriverIdVerificationEnabledMarkets;

    @Property(propertyName = "dms.driver.id.verification.enabled.driverType", delimiter = ",")
    public Set<DriverType> dmsDriverIdVerificationEnabledDriverType;

    @Property(propertyName = "dms.driver.id.verification.passed.flow.status", delimiter = ",")
    public Set<VerificationStatus> dmsDriverIdVerificationPassedFlowStatus;

    @Property(propertyName = "dms.driver.id.verification.failed.flow.status", delimiter = ",")
    public Set<VerificationStatus> dmsDriverIdVerificationFailedFlowStatus;

    @Property(propertyName = "dms.driver.id.verification.pending.flow.status", delimiter = ",")
    public Set<VerificationStatus> dmsDriverIdVerificationPendingFlowStatus;

    @Property(propertyName = "dms.driver.id.verification.random.probability")
    public int dmsDriverIdVerificationRandomProbability;

    @Property(propertyName = "dms.driver.id.verification.repetition.days")
    public int dmsDriverIdVerificationRepetitionDays;

    @Property(propertyName = "dms.driver.id.verification.window.days")
    public int dmsDriverIdVerificationLastVerificationWindowInDays;

    @Property(propertyName = "dms.driver.id.verification.cron.poll.duration.mins")
    public int dmsDriverIdVerificationCronPollDurationInMin;

    @Property(propertyName = "dms.driver.id.verification.polling.enabled")
    public boolean dmsDriverIdVerificationPollEnabled;

    @Property(propertyName = "dms.driver.id.verification.enable.quartz.job")
    public boolean enableQuartzDriverVerificationCheckJob = false;

    @Property(propertyName = "dms.driver.id.verification.on.trip.enable.quartz.job")
    public boolean enableQuartzDriverVerificationOnTripCheckJob = true;

    @Property(propertyName = "dms.driver.id.verification.job.cron")
    public String dmsVerificationCheckJobCron;

    @Property(propertyName = "verification.host.url")
    private String verificationHostUrl;

    @Property(propertyName = "verification.log.level")
    private String verificationLogLevel;

    @Property(propertyName = "verification.read.timeout.sec")
    private int verificationReadTimeOutInSec;

    @Property(propertyName = "verification.connect.timeout.sec")
    private int verificationConnectTimeOutInSec;

    @Property(propertyName = "verification.max.retry.count")
    private int verificationMaxRetryCount;

    @Property(propertyName = "verification.vendor.app.version")
    private String verificationVendorAppVersion;

    @Property(propertyName = "verification.vendor.sys.proxy.host")
    private String verificationVendorSysProxyHost;

    @Property(propertyName = "verification.vendor.sys.proxy.port")
    private int verificationVendorSysProxyPort;

    @Property(propertyName = "verification.report.mail.list")
    private String verificationReportMailList;

    @Property(propertyName = "verification.app.old.version.support.enabled")
    private boolean verificationAppOldVersionSupportEnabled;

    @Property(propertyName = "verification.reset.driver.schedule.enabled")
    private boolean verificationResetDriverScheduleEnabled;

    @Property(propertyName = "verification.es.logging.enabled")
    private boolean verificationESLoggingEnabled;

    @Property(propertyName = "verification.app.submit.enabled")
    private boolean verificationAppSubmitEnabled;

    @Property(propertyName = "dms.driver.id.verification.async.enabled")
    private boolean dmsDriverIdVerificationAsyncEnabled;

    @Property(propertyName = "dms.driver.id.verification.enabled")
    private boolean dmsDriverIdVerificationEnabled;

    @Property(propertyName = "dms.driver.id.verification.partial.enabled.markets", delimiter = "#;#")
    public Set<String> dmsDriverIdVerificationPartialEnabledMarkets;

    @Property(propertyName = "dms.driver.id.verification.partial.rollout.percentage")
    public Integer dmsDriverIdVerificationPartialRolloutPercent;

    @Property(propertyName = "dms.driver.id.verification.redact.enable.quartz.job")
    public boolean enableQuartzDriverRedactionJob = false;

    @Property(propertyName = "dms.driver.id.verification.redact.job.cron")
    public String dmsDriverIdVerificationRedactJobCron;

    @Property(propertyName = "dms.driver.id.verification.redact.cron.poll.duration.begin.day")
    public int dmsDriverIdVerificationRedactCronPollDurationBeginDay;

    @Property(propertyName = "dms.driver.id.verification.redact.cron.poll.duration.end.day")
    public int dmsDriverIdVerificationRedactCronPollDurationEndDay;

    @Property(propertyName = "new.consent.doc.version")
    private String newConsentDocVersion;

    @Property(propertyName = "new.consent.doc.version.enabled")
    private boolean newConsentDocVersionEnabled;

    @Property(propertyName = "dms.driver.id.verification.redact.new.doc.version.enabled")
    public boolean dmsDriverIdVerificationRedactionNewDocVersionEnabled;

    @Property(propertyName = "dms.driver.id.verification.redact.new.doc.version.cron.poll.duration.begin.day")
    public int dmsDriverIdVerificationRedactNewDocVersionCronPollDurationBeginDay;

    @Property(propertyName = "dms.driver.id.verification.redact.new.doc.version.cron.poll.duration.end.day")
    public int dmsDriverIdVerificationRedactNewDocVersionCronPollDurationEndDay;

    @Property(propertyName = "dms.driver.id.verification.redact.report.mail.list")
    public String dmsDriverIdVerificationRedactReportMailList;

    @Property(propertyName = "dms.driver.id.verification.redact.async.enabled")
    private boolean dmsDriverIdVerificationRedactAsyncEnabled;

    @Property(propertyName = "dms.driver.id.verification.high.risk.markets", delimiter = "#;#")
    public Set<String> dmsDriverIdVerificationHighRiskMarkets;

    @Property(propertyName = "dms.driver.id.verification.onboarding.template.id")
    private String dmsDriverIdVerificationOnboardingTemplateId;

    @Property(propertyName = "dms.driver.id.verification.repetition.days.high.risk.markets")
    public int dmsDriverIdVerificationRepetitionDaysHighRiskMarkets;

    @Property(propertyName = "dms.driver.id.verification.reverification.template.id")
    private String dmsDriverIdVerificationReverificationTemplateId;

    @Property(propertyName = "dms.driver.id.verification.tenant.market.map")
    private String dmsDriverIdVerificationTenantMarketMap;

    @Property(propertyName = "dms.driver.id.verification.driver.offline.reason", delimiter = ",")
    public Set<DriverOfflineReason> dmsDriverIdVerificationDriverOfflineReason;

    @Property(propertyName = "dms.async.thread.pool.threads.count.create.safety.incident.api")
    private int dmsAsyncThreadPoolThreadsCountCreateSafetyIncidentApi;

    @Property(propertyName = "dms.driver.id.verification.decline.safety.incident.enabled")
    public boolean dmsDriverIdVerificationDeclineSafetyIncidentEnabled=true;

    @Property(propertyName = "dms.driver.id.verification.safety.incident.async.enabled")
    public boolean dmsDriverIdVerificationSafetyIncidentAsyncEnabled=true;

    @Property(propertyName = "dms.driver.driver.licence.verification.template.id")
    private String dmsDriverDriverLicenceVerificationTemplateId;

    @Property(propertyName = "dms.driver.on.begin.trip.id.verification.template.id")
    private String dmsDriverOnBeginTripIdVerificationTemplateId;

    @Property(propertyName = "dms.driver.on.end.trip.id.verification.template.id")
    private String dmsDriverOnEndTripIdVerificationTemplateId;

    @Property(propertyName = "dms.driver.id.verification.on.trip.cron.poll.duration.mins")
    public int dmsDriverIdVerificationOnTripCronPollDurationInMin;

    @Property(propertyName = "dms.driver.on.trip.id.verification.job.cron")
    public String dmsOnTripVerificationCheckJobCron;
  
    @Property(propertyName = "dms.driver.license.expiring.job.cron")
    public String dmsDriverLicenseExpiringJobCron;

    @Property(propertyName = "dms.driver.on.begin.trip.id.verification.not.allowed.status")
    private Set<VerificationStatus> dmsDriverOnBeginTripIDVerificationNotAllowedStatus;

    @Property(propertyName = "dms.driver.booster.offer.allowed.status.to.be.stored")
    private Set<DriverOfflineReason> dmsDriverBoosterOfferAllowedStatusToBeStored;

    @Property(propertyName = "dms.driver.login.id.verification.enabled.markets", delimiter = "#;#")
    public Set<String> dmsDriverLoginIdVerificationEnabledMarkets;

    @Property(propertyName = "dms.driver.login.id.verification.rollout.percentage")
    public Integer dmsDriverLoginIdVerificationRolloutPercent;

    @Property(propertyName = "dms.driver.id.verification.processing.disabled.types")
    public Set<String> dmsDriverIdVerificationProcessingDisabledTypes;

    @Property(propertyName = "dms.driver.id.verification.deactivation.for.graph.tags", delimiter = "#;#")
    public Set<String> dmsDriverIdVerificationDeactivationForGraphTags;

    @Property(propertyName = "dms.driver.id.verification.on.end.trip.expired.persona.deactivation.enabled")
    public boolean dmsDriverIdVerificationOnEndTripExpiredPersonaDeactivationEnabled;

    @Property(propertyName = "dms.driver.id.verification.on.end.trip.expired.cron.deactivation.enabled")
    public boolean dmsDriverIdVerificationOnEndTripExpiredCronDeactivationEnabled;

    @Property(propertyName = "dms.driver.id.verification.on.end.trip.expired.logout.deactivation.enabled")
    public boolean dmsDriverIdVerificationOnEndTripExpiredLogoutDeactivationEnabled;

    @Property(propertyName = "dms.driver.license.expiring.reminder.days")
    private Set<Integer> dmsDriverLicenseExpiringReminderDays;

    @Property(propertyName = "dms.driver.driving.license.expiration.enabled.driverType", delimiter = ",")
    public Set<DriverType> dmsDriverDrivingLicenseExpirationEnabledDriverType;

    @Property(propertyName = "dms.driver.persona.account.status.update.enabled")
    public boolean dmsDriverPersonaAccountStatusUpdateEnabled;
    @Property(propertyName = "dms.driver.license.expiration.enabled.markets")
    public Set<String> dmsDriverLicenseExpirationEnabledMarkets;

    @Property(propertyName = "dms.driver.id.verification.persona.flow.status", delimiter = ",")
    @DefaultValue.Set({})
    public Set<VerificationStatus> dmsDriverIdVerificationPersonaFlowStatus;

    @Property(propertyName = "dms.driver.deactivation.fraud.codes", delimiter = ",")
    @DefaultValue.Set({})
    public Set<String> dmsDriverDeactivationFraudCodes;
}
