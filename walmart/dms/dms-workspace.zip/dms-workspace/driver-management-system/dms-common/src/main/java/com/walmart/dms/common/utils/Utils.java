package com.walmart.dms.common.utils;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.walmart.dms.common.error.ErrorCode;
import com.walmart.dms.server.common.error.Error;
import com.walmart.dms.server.common.error.ErrorCategory;
import com.walmart.dms.server.common.error.ErrorSeverity;

import io.strati.libs.commons.collections.CollectionUtils;

import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Utils {
	private Utils() {
	}

	private static ObjectMapper notNullMapper = new ObjectMapper();
	private static ObjectMapper mapper = new ObjectMapper();
	static {
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		mapper.registerModule(new JavaTimeModule());

		notNullMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		notNullMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		notNullMapper.setSerializationInclusion(Include.NON_NULL);
		notNullMapper.setSerializationInclusion(Include.NON_EMPTY);
		notNullMapper.registerModule(new JavaTimeModule());
	}

	public static ObjectMapper getMapper() {
		return mapper;
	}

	public static ObjectMapper getNotNullMapper() {
		return notNullMapper;
	}

	public static Set<String> splitToSet(String input, String delimeter) {
		Set<String> set = null;

		if (StringUtils.isNotEmpty(input) && StringUtils.isNotEmpty(delimeter)) {
			set = new HashSet<String>();
			String[] values = null;
			try {
				values = input.split(delimeter);
			} catch (Exception e) {
				throw e;
			}

			for (String value : values) {
				if (StringUtils.isNotEmpty(value)) {
					set.add(value.trim());
				}
			}
		}
		return set;
	}

	public static String nullToEmpty(String text) {
		return text == null ? "" : text;
	}

	public static Error fetchErrorObject(ErrorCode errorCode,String message){
		Error error = new Error();
		error.setCategory(ErrorCategory.REQUEST);
		error.setCode(errorCode.getErrorCode());
		error.setField("REQUEST");
		error.setInfo(message);
		error.setSeverity(ErrorSeverity.ERROR);
		return error;
	}

	public static List<Error> getErrorList(final Integer status, final String message) {
		final Error error = new Error();
		error.setCode(status.toString());
		error.setDescription(message);
		error.setSeverity(ErrorSeverity.ERROR);
		error.setCategory(ErrorCategory.REQUEST);
		return Arrays.asList(error);
	}
	
	/**
	 * Merge Parent and Child sets to get a new ordered set without replacing any element in the parent set.
	 * Resultant Set will have parent list on top.
	 * @param parent
	 * @param child
	 * @return
	 */
	public static LinkedHashSet<String> mergeAndGetOrderedSet(final List<String> parent, final Set<String> child) {
		if(CollectionUtils.isEmpty(parent) && CollectionUtils.isEmpty(child)) {
			return new LinkedHashSet<>();
		} else if(CollectionUtils.isEmpty(parent)) {
			return new LinkedHashSet<>(child);
		} else if(CollectionUtils.isEmpty(child)) {
			return new LinkedHashSet<>(parent);
		}
		
		LinkedHashSet<String> mergedOrderedSet = new LinkedHashSet<>(parent);
		mergedOrderedSet.addAll(child);
		return mergedOrderedSet;
	}
}
