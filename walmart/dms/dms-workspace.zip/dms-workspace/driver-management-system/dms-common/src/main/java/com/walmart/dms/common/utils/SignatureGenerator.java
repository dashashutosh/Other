package com.walmart.dms.common.utils;

import java.io.ObjectStreamException;
import java.security.KeyRep;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class SignatureGenerator {

	private String privateKeyVersion;

	private String consumerId;

	private String privateKey;
	
	private String timestamp;

	public SignatureGenerator(String privateKeyVersion, String consumerId, String privateKey,String timestamp) {
		this.privateKeyVersion = privateKeyVersion;
		this.consumerId = consumerId;
		this.privateKey = privateKey;
		this.timestamp = timestamp;
	}

	@SuppressFBWarnings(value="REC_CATCH_EXCEPTION")
	public String generateSignature() {

		String signatureString = null;
		try {
			String canonicalizeString = canonicalize()[1];

			Signature signatureInstance = Signature.getInstance("SHA256WithRSA");

			ServiceKeyRep keyRep = new ServiceKeyRep(KeyRep.Type.PRIVATE, "RSA", "PKCS#8",Base64.getDecoder().decode(getPrivateKey()));

			PrivateKey resolvedPrivateKey = (PrivateKey) keyRep.readResolve();

			signatureInstance.initSign(resolvedPrivateKey);

			byte[] bytesToSign = canonicalizeString.getBytes("UTF-8");
			signatureInstance.update(bytesToSign);
			byte[] signatureBytes = signatureInstance.sign();

			signatureString = Base64.getEncoder().encodeToString(signatureBytes);

		} catch (Exception ex) {
			log.error("Exception occured while generating signature ", ex);
		}

		return signatureString;
	}

	private String[] canonicalize() {

		Map<String, String> headersToSignMap = new HashMap<>();
		headersToSignMap.put("WM_CONSUMER.ID", getConsumerId());
		headersToSignMap.put("WM_CONSUMER.INTIMESTAMP", getTimestamp());
		headersToSignMap.put("WM_SEC.KEY_VERSION", getPrivateKeyVersion());

		StringBuilder canonicalizedStrBuffer = new StringBuilder();
		StringBuilder parameterNamesBuffer = new StringBuilder();
		Set<String> keySet = headersToSignMap.keySet();

		// Create sorted key set to enforce order on the key names
		SortedSet<String> sortedKeySet = new TreeSet<String>(keySet);
		for (String key : sortedKeySet) {
			Object val = headersToSignMap.get(key);
			parameterNamesBuffer.append(key.trim()).append(";");
			canonicalizedStrBuffer.append(val.toString().trim()).append("\n");
		}
		return new String[] { parameterNamesBuffer.toString(), canonicalizedStrBuffer.toString() };
	}

	static class ServiceKeyRep extends KeyRep {
		private static final long serialVersionUID = -7213340660431987616L;

		public ServiceKeyRep(Type type, String algorithm, String format, byte[] encoded) {
			super(type, algorithm, format, encoded);
		}
		@Override
		protected Object readResolve() throws ObjectStreamException {
			return super.readResolve();
		}
	}

}
