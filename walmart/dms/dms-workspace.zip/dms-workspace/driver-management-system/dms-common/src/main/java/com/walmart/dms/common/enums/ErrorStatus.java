package com.walmart.dms.common.enums;

/**
 * @author n0k008c
 *
 */
public enum ErrorStatus {

    QUEUED, PROCESSED, FAILED
}