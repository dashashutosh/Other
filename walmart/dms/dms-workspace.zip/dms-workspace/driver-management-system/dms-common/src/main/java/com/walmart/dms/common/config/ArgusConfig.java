package com.walmart.dms.common.config;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import java.util.List;
import lombok.Data;

@Configuration(configName = "argusConfig")
@Data
public class ArgusConfig {

  @Property(propertyName = "dms.argus.enabled.source", delimiter = ",")
  private List<String> argusEnabledSource;

  @Property(propertyName = "dms.argus.enabled.uri", delimiter = ",")
  private List<String> argusEnabledURI;

  @Property(propertyName = "dms.argus.rolled.out.markets", delimiter = ",")
  private List<String> argusRolledOutMarkets;

  @Property(propertyName = "dms.argus.rolled.out.uris", delimiter = ",")
  private List<String> argusRolledOutURIs;

  @Property(propertyName = "dms.argus.empty.response.whitelist.uris", delimiter = ",")
  private List<String> argusEmptyResponseWhitelistURIs;

  @Property(propertyName = "dms.argus.service.name")
  private String serviceName;

  @Property(propertyName = "dms.argus.call.enabled")
  private boolean argusCallEnabled = false;

}