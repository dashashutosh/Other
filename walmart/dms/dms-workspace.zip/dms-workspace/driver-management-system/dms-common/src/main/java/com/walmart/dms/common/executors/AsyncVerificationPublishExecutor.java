package com.walmart.dms.common.executors;

import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.utils.LogUtil;
import com.walmart.dms.common.utils.Pair;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@Configuration
@Slf4j
public class AsyncVerificationPublishExecutor {

    @Bean
    public Executor executorAsyncVerificationPublish(CommonConfig commonConfig) {
        log.info(LogUtil.buildJsonLog("Async Thread Executor initiated for publishing Id VerificationV2 payload with threads count", Pair.with(Constant.COUNT, commonConfig.getDmsAsyncThreadPoolThreadsCountIdVerificationApiV2())));
        return Executors.newFixedThreadPool(commonConfig.getDmsAsyncThreadPoolThreadsCountIdVerificationApiV2());
    }
}
