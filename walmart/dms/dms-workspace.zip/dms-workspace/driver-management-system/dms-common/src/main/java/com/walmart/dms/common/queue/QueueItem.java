package com.walmart.dms.common.queue;

public abstract class QueueItem {

	public abstract int getUniqueKey();

}
