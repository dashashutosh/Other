package com.walmart.dms.common.config;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;
import lombok.Data;

import java.util.List;

@Configuration(configName = "dmsDeleteDriverAccountsConfig")

@Data
public class DmsDeleteDriverAccountsConfig {

    @Property(propertyName = "enable.quartz.dms.delete.driver.accounts.job")
    private boolean enableDeleteDmsDriverAccountsJob = false;

    @Property(propertyName = "dms.delete.driver.account.request.before.months.count")
    @DefaultValue.Int(3)
    private Integer dmsDeleteDriverAccountRequestBeforeMonthsCount;

    @Property(propertyName = "dms.delete.driver.account.user.program.uuid")
    private String dmsDeleteDriverAccountDriverProgramUUID;

    @Property(propertyName = "dms.delete.driver.account.user.driver.type")
    private List<String> dmsDeleteDriverAccountDriverTypeList;

    @Property(propertyName = "dms.delete.driver.account.fetch.page.size")
    @DefaultValue.Int(500)
    private int dmsDeleteDriverAccountFetchPageSize;

    @Property(propertyName = "dms.delete.driver.account.driver.email.list", delimiter=",")
    private List<String> dmsDeleteDriverAccountEmailList;

    @Property(propertyName = "dms.delete.driver.accounts.job.cron.expression")
    private String dmsDeleteDriverAccountsJobCronExpression;
}
