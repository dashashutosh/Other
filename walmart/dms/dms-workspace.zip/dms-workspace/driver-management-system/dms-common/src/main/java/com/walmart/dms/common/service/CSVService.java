package com.walmart.dms.common.service;

import com.walmart.dms.common.error.ErrorCode;
import com.walmart.dms.common.error.ErrorMessageConstant;
import com.walmart.dms.common.exception.InvalidRequestException;
import com.walmart.dms.common.model.bulk.DriverBulkRequestDTO;
import java.time.LocalDate;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Class used to parse the csv file to Java objects.
 */
@Slf4j
@Service
public class CSVService {

    public static final int FIRST_NAME= 0;
    public static final int LAST_NAME= 1;
    public static final int EMAIL= 2;
    public static final int MOBILE= 3;
    public static final int ASSOCIATED_STORE_ID= 4;
    public static final int MARKET_NAME= 5;
    public static final int DOB= 6;
    public static final int DRIVER_LICENSE_NUMBER= 7;
    public static final int DRIVER_LICENSE_EXPIRY= 8;
    public static final int ADDRESS_LINE1= 9;
    public static final int ADDRESS_LINE2= 10;
    public static final int CITY= 11;
    public static final int STATE= 12;
    public static final int ZIP_CODE= 13;
    public static final int COUNTRY= 14;
    public static final int VEHICLE_COMPANY= 15;
    public static final int VEHICLE_MODEL= 16;
    public static final int VEHICLE_COLOR= 17;
    public static final int VEHICLE_YEAR= 18;
    public static final int VEHICLE_REGISTRATION= 19;
    public static final int TYPE= 20;
    public static final int ACTION = 21;

    /**
     * Method to parse the CSV file InputStream to DriverBulkRequestDTO objects
     * @param inputStream
     * @return list of DriverBulkRequestDTO
     * @throws InvalidRequestException
     */
    @SuppressFBWarnings("REC_CATCH_EXCEPTION")
    public List<DriverBulkRequestDTO> parseDriverManagementCSV(InputStream inputStream) throws InvalidRequestException {
        log.info("parseDriverManagementCSV: Parsing Bulk Driver CSV");
        List<DriverBulkRequestDTO> records = new ArrayList<>();
        if (inputStream == null) {
            String message = MessageFormat.format(ErrorMessageConstant.EXCEPTION_MESSAGE, "parseDriverManagementCSV: Bulk Driver CSV is null or empty");
            log.error(message);
            throw new InvalidRequestException(ErrorCode.BIZ_INVALID_RESOURCE, "Bulk Driver CSV is null or empty");
        }
        StringBuilder csvBuilder =  new StringBuilder();
        try (Reader reader = new BufferedReader(new InputStreamReader
                (inputStream, Charset.forName(StandardCharsets.UTF_8.name())))) {
            int c = 0;
            while ((c = reader.read()) != -1) {
                csvBuilder.append((char) c);
            }
        } catch (IOException e) {
            String message = MessageFormat.format(ErrorMessageConstant.EXCEPTION_MESSAGE, "parseDriverManagementCSV: Bulk Driver CSV cannot be parsed");
            log.error(message);
            throw new InvalidRequestException(ErrorCode.BIZ_INVALID_RESOURCE, "Bulk Driver CSV cannot be parsed");
        }
        try {
            String csv = csvBuilder.toString();
            String[] lines = csv.split("\n");

            for (int i = 1; i < lines.length; i++) {
                String line = StringUtils.trim(lines[i]);
                String[] cols = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                for (int j = 0; j < cols.length; j++) {
                    cols[j] = cols[j].replace("\"","").trim();
                }

                    DriverBulkRequestDTO recordDetails = DriverBulkRequestDTO.builder().firstName(cols[FIRST_NAME])
                            .lastName(cols[LAST_NAME]).email(cols[EMAIL]).mobile(cols[MOBILE])
                            .associatedStoreId(cols[ASSOCIATED_STORE_ID]).marketName(cols[MARKET_NAME])
                            .dob(tryParse(cols[DOB])).driverLicenseNo(cols[DRIVER_LICENSE_NUMBER])
                            .driverLicenseExpiry(tryParse(cols[DRIVER_LICENSE_EXPIRY])).addressLine1(cols[ADDRESS_LINE1])
                            .addressLine2(cols[ADDRESS_LINE2]).city(cols[CITY]).state(cols[STATE]).zipCode(cols[ZIP_CODE])
                            .country(cols[COUNTRY]).vehicleCompany(cols[VEHICLE_COMPANY]).vehicleModel(cols[VEHICLE_MODEL])
                            .vehicleColor(cols[VEHICLE_COLOR]).vehicleYear(cols[VEHICLE_YEAR]).vehicleRegistration(cols[VEHICLE_REGISTRATION])
                            .driverType(cols[TYPE]).action(cols[ACTION]).build();
                    records.add(recordDetails);

            }
        }catch(Exception ex){
            throw new InvalidRequestException(ErrorCode.BIZ_INVALID_RESOURCE,"Bulk Driver CSV cannot be parsed");
        }

        return records;
    }

    private LocalDate tryParse(String date) {
        try {
            return LocalDate.parse(date);
        } catch (Exception e) {
            return null;
        }
    }
}
