package com.walmart.dms.common.enums;

public enum DriverAvailabilityStatus {
    ONLINE, OFFLINE
}
