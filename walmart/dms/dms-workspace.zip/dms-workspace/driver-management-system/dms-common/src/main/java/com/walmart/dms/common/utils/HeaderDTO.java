package com.walmart.dms.common.utils;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class HeaderDTO implements Serializable {

	private static final long serialVersionUID = 5297180767374579365L;
	
	public HeaderDTO(String tenantId, String verticalId) {
	    this.tenantId = tenantId;
	    this.verticalId = verticalId;
	}

	@NotNull
	private String tenantId;

	@NotNull
	private String verticalId;

	private String correlationId;

	private String timeZone;

	private String countryCode;

	private String clientId;

	private String client;

	@JsonSetter("CLIENT")
	public void setClientCaps(String client) {
		this.client = client;
	}

	@JsonSetter("client")
	public void setClient(String client) {
		this.client = client;
	}

	private String realmId;

	private String loginId;

	private String deviceModel;

	private String deviceOS;

	private String deviceOSVersion;

	private String deviceId;

	private String installedAppVersion;

	private String consumerId;

	private String ipAddress;

	private String consumerSource;

	private String ip;

	private String locale;

	private String lat;

	private String log;

	private String latLongRange;

	private String localeId;

	private String driverUUID;

	private String consumerIP;

	private String country;

	private String userAgent;

	private String onboardedTime;

	private String deviceProfileRefId;

}
