package com.walmart.dms.common.enums;

public enum DDIReportingAPIMode {
    COMPLETED("completed"), SUBMITTED("submitted"),ATTEMPTED("attempted"), PENDING("pending");
    
    private String value;

    public String getValue() {
        return value;
    }
    
    DDIReportingAPIMode(String value){
        this.value = value;
    }

}

