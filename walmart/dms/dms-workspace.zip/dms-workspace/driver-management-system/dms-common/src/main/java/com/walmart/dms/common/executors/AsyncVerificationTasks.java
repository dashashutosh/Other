package com.walmart.dms.common.executors;

import com.walmart.dms.common.helper.PublisherHelper;
import com.walmart.dms.common.utils.LogUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Slf4j
@Component
public class AsyncVerificationTasks {

    @Autowired
    @Lazy
    private PublisherHelper publisherHelper;

    @SneakyThrows
    @Async(value = "executorAsyncVerificationPublish")
    public CompletableFuture<String> createIdVerificationPayloadPublish(final String payload) {
        log.info(LogUtil.buildJsonLog("Publish Id Verification Payload"));
        publisherHelper.publishPersonaData(payload);
        return CompletableFuture.completedFuture("Success");
    }
}