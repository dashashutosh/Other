package com.walmart.dms.common.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.util.HashMap;
import java.util.Map;
/**
 * @author a0s0od1
 */

public enum VerificationDocumentType {

    SELFIE("selfie"), GOVERNMENT_ID("government-id"), DRIVER_LICENCE("driver-license"), PHONE_NUMBER("phone-number"), REVERSE_PHONE_NUMBER("database");

    private String documentType;
    private static final Map<String, VerificationDocumentType> documentTypeMap;

    static {
        documentTypeMap = new HashMap<>();
        for(VerificationDocumentType s : VerificationDocumentType.values()) {
            documentTypeMap.put(s.documentType, s);
        }
    }

    VerificationDocumentType(final String type) {
        this.documentType = type;
    }

    @JsonCreator
    public static VerificationDocumentType getDocumentType(String type){
        String verificationDocumentType = type.replace("verification/","");

        if(!documentTypeMap.containsKey(verificationDocumentType)) {
            throw new IllegalArgumentException();
        }
        return documentTypeMap.get(verificationDocumentType);
    }

    public static VerificationDocumentType getVerification(String type){
        String verificationDocumentType = type.replace("verification/","");

        if(!documentTypeMap.containsKey(verificationDocumentType)) {
            return null;
        }
        return documentTypeMap.get(verificationDocumentType);
    }

    public static String getDocumentType(VerificationDocumentType type) {
        return type.documentType;
    }
}
