package com.walmart.dms.common.exception;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import com.walmart.dms.server.common.error.Error;
import com.walmart.dms.common.error.ErrorCode;
import com.walmart.dms.server.common.error.AbstractExceptionHandler;
import com.walmart.dms.server.common.error.ApplicationLayer;
import com.walmart.dms.server.common.error.IErrorMapper;
import com.walmart.dms.server.common.exception.BusinessException;
import com.walmart.dms.server.common.exception.DataAccessException;

import com.walmart.dms.server.common.exception.ValidationException;
import ma.glasnost.orika.MappingException;

public class ExceptionHandler extends AbstractExceptionHandler {

	public static final String EXCEPTION_MESSAGE = "An exception has occurred : {0}";
	public static final String MAPPING_EXCEPTION_MESSAGE = "A mapping exception has occurred : {0}";

	public ExceptionHandler(IErrorMapper errorMapper) {
		super(errorMapper);
	}

	@Override
	public void handleBusinessException(Exception ex) throws BusinessException {
		if (ex instanceof DataAccessException) {
			throw new BusinessException(ex);
		} else if (ex instanceof BusinessException) {
			throw (BusinessException) ex;
		} else if (ex instanceof MappingException) {
			String error = MessageFormat.format(MAPPING_EXCEPTION_MESSAGE, ex.getMessage());
			handleBusinessException(ErrorCode.BIZ_MAPPING_ERROR.getErrorCode(), error, ex);
		} else if (ex instanceof IntegrationException) {
			IntegrationException exception = (IntegrationException) ex;
			throw new BusinessException(exception.getErrors(), ex.getMessage());
		} else if (ex instanceof InvalidRequestException) {
			InvalidRequestException exception = (InvalidRequestException) ex;
			List<ErrorCode> errorCodes = exception.getCodes();
			List<Error> errors = new ArrayList<Error>();
			for (ErrorCode errorCode : errorCodes) {
				Error error = errorMapper.getError(ApplicationLayer.BUSINESS_LAYER, errorCode.getErrorCode());
				error.setDescription(ex.getMessage());
				setErrorInfo(error, exception);
				errors.add(error);
			}
			throw new BusinessException(errors);
		}
		else if (ex instanceof ValidationException)
		{
			ValidationException exception = (ValidationException) ex;
			Error error = exception.getError();
			throw new BusinessException(error);
		}
		else {
			String error = MessageFormat.format(EXCEPTION_MESSAGE, ex.toString());
			handleBusinessException(ErrorCode.BIZ_UNEXPECTED_ERROR.getErrorCode(), error, ex);
		}
	}

}
