package com.walmart.dms.common.enums;

public enum RecurringPattern {
	WEEKLY;

}
