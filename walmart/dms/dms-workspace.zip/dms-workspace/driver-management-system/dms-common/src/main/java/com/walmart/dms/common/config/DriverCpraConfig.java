package com.walmart.dms.common.config;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;
import lombok.Data;

import java.util.List;

@Configuration(configName = "dmsCpraConfig")

@Data
public class DriverCpraConfig {

    @Property(propertyName = "enable.quartz.driver.cpra.schedule.job")
    private boolean enableQuartzDriverCpraScheduleJob = false;

    @Property(propertyName = "dms.driver.user.updated.days")
    private String dmsUpdatedDays;

    @Property(propertyName = "dms.driver.user.program.uuid")
    private String dmsProgramUUID;

    @Property(propertyName = "dms.driver.user.driver.type")
    private String dmsDriverType;

    @Property(propertyName = "dms.driver.fetch.page.size")
    @DefaultValue.Int(500)
    private int dmsDriverFetchPageSize;

    @Property(propertyName = "driverSuggestion.delete.driver.email.list", delimiter=",")
    private List<String> driverSuggestionDeleteDriverEmailList;

    @Property(propertyName = "dms.cpra.job.cron.expression")
    private String dmsCpraJobCronExpression;
}
