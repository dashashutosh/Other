package com.walmart.dms.common.utils;

import io.strati.security.common.AuthenticationContext;
import io.strati.security.dto.*;

import java.util.Locale;

/**
 * A utility class for IAM related operations.
 *
 * @author a0d02yr
 */
public class IAMUtil {
    private IAMUtil() {
    }

    /**
     * Gets an object of PrincipalDTO to create an IAM account.
     *
     * @param realmId  the realm id
     * @param loginId  the login id
     * @param password the password
     * @param emailId  the email id
     * @return an object of UpdatePrincipalDTO
     */
    public static PrincipalDTO getPrincipalDTO(final String realmId, final String loginId,
                                               final String password, final String emailId) {
        final PrincipalDTO principalDTO = new PrincipalDTO();
        principalDTO.setRealmId(realmId);
        principalDTO.setLoginUID(loginId);
        /** TODO: With version upgrade of strati-af-security-iam-api, "password" is required to be passed as char[].
         *  Version upgrade is being done to fix log4j security vulnerability issue. */
        principalDTO.setPassword(password.toCharArray());
        principalDTO.setEmail(emailId);
        return principalDTO;
    }

    /**
     * Gets an object of UpdatePrincipalDTO to update email id in IAM account.
     *
     * @param realmId    the realm id
     * @param loginId    the login id
     * @param newLoginId the new login id
     * @param emailId    the email id
     * @return an object of UpdatePrincipalDTO
     */
    public static UpdatePrincipalDTO getEmailUpdatePrincipalDTO(final String realmId, final String loginId,
                                                                final String newLoginId, final String emailId) {
        final UpdatePrincipalDTO emailUpdatePrincipalDTO = new UpdatePrincipalDTO();
        emailUpdatePrincipalDTO.setRealmId(realmId);
        emailUpdatePrincipalDTO.setLoginUID(loginId);
        emailUpdatePrincipalDTO.setNewLoginUID(newLoginId);
        emailUpdatePrincipalDTO.setEmail(emailId);
        return emailUpdatePrincipalDTO;
    }

    /**
     * Gets an object of UpdatePrincipalDTO to update login id in IAM account.
     *
     * @param realmId    the realm id
     * @param loginId    the login id
     * @param newLoginId the new login id
     * @return an object of UpdatePrincipalDTO
     */
    public static UpdatePrincipalDTO getLoginIdUpdatePrincipalDTO(final String realmId, final String loginId, final String newLoginId) {
        final UpdatePrincipalDTO loginIdUpdatePrincipalDTO = new UpdatePrincipalDTO();
        loginIdUpdatePrincipalDTO.setRealmId(realmId);
        loginIdUpdatePrincipalDTO.setLoginUID(loginId);
        loginIdUpdatePrincipalDTO.setNewLoginUID(newLoginId);
        return loginIdUpdatePrincipalDTO;
    }

    public static OTPCodeReqDTO prepareOTPCodeReqDTO(final String realmId,final  String loginId) {
        final OTPCodeReqDTO otpCodeReqDTO = new OTPCodeReqDTO();
        otpCodeReqDTO.setRealmId(realmId);
        otpCodeReqDTO.setLoginId(loginId);
        return otpCodeReqDTO;
    }

    public static OTPCodeValidationReqDTO prepareOTPCodeValidationReqDTO(final String realmId, final String loginId, final String otpCode, final Boolean deleteOtpRecordOnSuccess){
        final OTPCodeValidationReqDTO otpCodeValidationReqDTO = new OTPCodeValidationReqDTO();
        otpCodeValidationReqDTO.setRealmId(realmId);
        otpCodeValidationReqDTO.setLoginId(loginId);
        otpCodeValidationReqDTO.setOtpCode(otpCode);
        otpCodeValidationReqDTO.setDeleteOtpRecordOnSuccess(deleteOtpRecordOnSuccess);
        return otpCodeValidationReqDTO;
    }

    public static AuthenticationContext getAuthContextDTO(final String loginId, final String password,
                                                          final String realmId, final String tenantId) {
        final AuthenticationContext authenticationContext = new AuthenticationContext();
        authenticationContext.setRealmId(realmId);
        authenticationContext.setTenantId(tenantId);
        authenticationContext.setUserId(loginId);
        authenticationContext.setPassword(password.toCharArray());
        return authenticationContext;
    }

    public static ChangeLoginPasswordDTO getChangeLoginPasswordDTO(final String oldPassword, final String newPassword,
                                                                   final String realmId, final String loginId) {
        final ChangeLoginPasswordDTO changeLoginPasswordDTO = new ChangeLoginPasswordDTO();
        changeLoginPasswordDTO.setChanged(false);
        changeLoginPasswordDTO.setLoginId(loginId.trim().toLowerCase(Locale.ENGLISH));
        changeLoginPasswordDTO.setNewPassword(newPassword.toCharArray());
        changeLoginPasswordDTO.setOldPassword(oldPassword.toCharArray());
        changeLoginPasswordDTO.setRealmId(realmId);
        return changeLoginPasswordDTO;
    }
}
