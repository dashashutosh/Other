package com.walmart.dms.common.utils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.fasterxml.jackson.core.type.TypeReference;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

@Slf4j

public final class JsonUtil {

	private JsonUtil() {
	}

	public static String toJson(Object obj) {
		try {
			return Utils.getMapper().writeValueAsString(obj);
		} catch (Exception e) {
		}
		return null;
	}

	public static String toJsonWithNotNullMapper(Object obj) {
		try {
			return Utils.getNotNullMapper().writeValueAsString(obj);
		} catch (Exception e) {
		}
		return null;
	}

	public static JsonObject findObjectInJsonArray(JsonArray jsonArray, String key, String value) {

		if (jsonArray == null) {
			return null;
		}

		for (JsonElement jsonElement : jsonArray) {

			if (jsonElement.getAsJsonObject().get(key).getAsString().equals(value)) {
				return jsonElement.getAsJsonObject();
			}
		}

		return null;
	}

	@SuppressFBWarnings("REC_CATCH_EXCEPTION")
	public static <T> T fromJson(String json, TypeReference<T> typeReference) {
		try {
			return Utils.getMapper().readValue(json, typeReference);
		} catch (final Exception e) {
			log.error("JsonUtil.fromJson: Error occurred: ", e);
		}
		return null;
	}

	public static Object toObject(String inputString, Class classType) throws JsonParseException, JsonMappingException, IOException {
		final Object resultObject = Utils.getMapper().readValue(inputString, classType);
		return resultObject;
	}

	public static ObjectMapper objectMapper() {
		return new ObjectMapper();
	}

}
