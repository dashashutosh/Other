package com.walmart.dms.common;

public class Base62Coder {
    private Base62Coder() {
    }

    /**
     * the alphabet for the short URL
     */
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int BASE = ALPHABET.length();

    /**
     * Encode a long integer to base 62 system
     *
     * @param num
     *            Long integer
     * @return String representation of base 62
     */
    public static String encode(long num) {
        StringBuilder sb = new StringBuilder();

        while (num > 0) {
            sb.append(ALPHABET.charAt((int) (num % BASE)));
            num /= BASE;
        }

        return sb.reverse().toString();
    }
}
