package com.walmart.dms.common.mapper;

import java.time.ZoneId;

import ma.glasnost.orika.converter.BidirectionalConverter;
import ma.glasnost.orika.metadata.Type;

/**
 * Created by n0a008p on 14/02/18.
 */
public class TimeZoneStringConverter extends BidirectionalConverter<String, ZoneId> {

	@Override
	public ZoneId convertTo(String zoneId, Type<ZoneId> destinationType) {
		return zoneId != null ? ZoneId.of(zoneId) : null;
	}

	@Override
	public String convertFrom(ZoneId source, Type<String> destinationType) {
		return source != null ? source.toString() : null;

	}

}
