package com.walmart.dms.common.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum PermissionType {
    READ ("read_"),
    ACTIONS ("action_");

    public final String policyPrefix;
}
