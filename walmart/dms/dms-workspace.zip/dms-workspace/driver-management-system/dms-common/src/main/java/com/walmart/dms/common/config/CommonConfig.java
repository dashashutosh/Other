package com.walmart.dms.common.config;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;

import java.util.List;
import java.util.Set;

import lombok.Data;

@Configuration(configName = "commonConfig")
@Data
public class CommonConfig {

    @Property(propertyName = "dms.generate.random.password")
    public boolean generateRandomPassword;

    @Property(propertyName = "dms.default.password")
    public String defaultPassword;

    @Property(propertyName = "dms.default.password.by.type")
    public String defaultPasswordByType;

    @Property(propertyName = "dms.generate.spotlight.for.api.list")
    public String generateSpotLightForApiList;

    @Property(propertyName = "enable.kafka.consumers")
    private boolean enableKafkaConsumers = true;

    @Property(propertyName = "daas.default.vertical.id")
    private String daasDefaultVerticalId;

    @Property(propertyName = "enable.error.retry.kafka.consumer")
    private boolean enableErrorRetryKafkaConsumer = true;

    @Property(propertyName = "enable.arm.kafka.consumers")
    private boolean enableArmKafkaConsumers = false;

    @Property(propertyName = "enable.oms.kafka.consumers")
    private boolean enableOmsKafkaConsumers = false;

    @Property(propertyName = "enable.daas.kafka.consumers")
    private boolean enableDaasKafkaConsumers = false;

    @Property(propertyName = "enable.driver.offer.es.write")
    private boolean enableDriverOfferEsWrite = false;

    @Property(propertyName = "enable.dms.reporting.event.db.live.syncup.kafka.consumers")
    private boolean enableDmsReportingEventKafkaConsumers = false;

    @Property(propertyName = "dms.reporting.event.db.live.syncup.names")
    private String dmsReportingEventNames = "";

    @Property(propertyName = "dms.reporting.event.db.live.syncup.bootstrap.servers")
    private String dmsReportingEventBootStrapServers = "";

    @Property(propertyName = "dms.reporting.event.db.live.syncup.consumer.group.name")
    private String dmsReportingEventConsumerGroupName = "";

    @Property(propertyName = "dms.reporting.event.db.live.syncup.consumer.config")
    private String dmsReportingEventConsumerConfig = "";


    @Property(propertyName = "enable.scheduling.kafka.producers")
    private boolean enableSchedulingKafkaProducers = false;

    @Property(propertyName = "enable.dms.reporting.driver.onboarding.events.kafka.producers")
    private boolean enableDmsReportingDriverOnboardingEventsKafkaProducers = false;

    @Property(propertyName = "enable.dms.reporting.driver.scheduling.events.kafka.producers")
    private boolean enableDmsReportingDriverSchedulingEventsKafkaProducers = false;

    @Property(propertyName = "enable.dms.reporting.driver.payment.events.kafka.producers")
    private boolean enableDmsReportingDriverPaymentEventsKafkaProducers = false;

    @Property(propertyName = "enable.quartz.DDIWMDriverDataReconciliation")
    private boolean enableQuartzDDIDriverReconciliation = false;

    @Property(propertyName = "enable.quartz.DDIPayoutStatusCheckJob")
    private boolean enableQuartzDDIPayoutStatusCheckJob = false;

    @Property(propertyName = "enable.quartz.DailyIncentivePaymentReportJob")
    private boolean enableQuartzDailyIncentivePaymentReportJob = false;

    @Property(propertyName = "enable.quartz.WeeklyIncentivePaymentReportJob")
    private boolean enableQuartzWeeklyIncentivePaymentReportJob = false;

    @Property(propertyName = "enable.quartz.MonthlyTippingFailureReportJob")
    private boolean enableQuartzMonthlyTippingFailureReportJob = false;

    @Property(propertyName = "enable.quartz.DriverPaymentCheckForDeliveredOrderJob")
    private boolean enableQuartzDriverPaymentCheckForDeliveredOrderJob = false;

    @Property(propertyName = "enable.quartz.DriverWeeklyPaymentReconciliationJob")
    private boolean enableQuartzDriverWeeklyPaymentReconciliationJob = false;

    @Property(propertyName = "enable.quartz.WeeklyTippingFailureReportJob")
    private boolean enableQuartzWeeklyTippingFailureReportJob = false;

    @Property(propertyName = "enable.quartz.ErrorRetryJob")
    private boolean enableQuartzErrorRetryJob = false;

    @Property(propertyName = "enable.quartz.DriverDeactivationJob")
    private boolean enableQuartzDriverDeactivationJob = false;

    @Property(propertyName = "enable.quartz.DriverCalenderCreationMonitoringJob")
    private boolean enableQuartzDriverCalenderCreationMonitoringJob = false;

    @Property(propertyName = "enable.quartz.DataPurgingJob")
    private boolean enableQuartzDataPurgingJob = true;

    @Property(propertyName = "enable.quartz.NewDriverSuggestionJob")
    private boolean enableQuartzNewDriverSuggestionJob = false;

    @Property(propertyName = "enable.quartz.SparkClusterHealthMonitoringJob")
    private boolean enableQuartzSparkClusterHealthMonitoringJob = false;

    @Property(propertyName = "enable.quartz.DriverDeactivationAndZoneMovementJob")
    private boolean enableQuartzDriverDeactivationAndZoneMovementJob = false;

    @Property(propertyName = "enable.quartz.DriverStoreScheduleCheckJob")
    private boolean enableQuartzDriverStoreScheduleCheckJob = false;

    @Property(propertyName = "enable.quartz.DriverCalendarCleanUpJob")
    private boolean enableQuartzDriverCalendarCleanUpJob = false;

    @Property(propertyName = "enable.quartz.DriverCalenderMonitoringJob")
    private boolean enableQuartzDriverCalenderMonitoringJob = false;

    @Property(propertyName = "enable.quartz.DriverDocumentESCheckJob")
    private boolean enableQuartzDriverDocumentESCheckJob = false;

    @Property(propertyName = "enable.dms.error.retry.kafka.producers")
    private boolean enableDmsErrorRetryKafkaProducers = false;

    @Property(propertyName = "enable.dms.error.retry.kafka.consumers")
    private boolean enableDmsErrorRetryKafkaConsumers = false;

    @Property(propertyName = "dms.countryCode.enabled.api", delimiter = ",")
    private Set<String> dmsCountryCodeEnabledAPI;

    @Property(propertyName = "dms.enabled.countryCode", delimiter = ",")
    private Set<String> dmsEnabledCountryCode;

    @Property(propertyName = "enable.dms.reporting.driver.booster.offer")
    private boolean enableDmsReportingDriverBoosterOffer;

    @Property(propertyName = "enable.dms.reporting.driver.risk.score")
    private boolean enableDmsReportingDriverRiskScore;

    @Property(propertyName = "enable.dms.stress.test.abort.kafka.consumer")
    private boolean enableDMSStressTestAbortKafkaConsumer = true;

    @Property(propertyName = "dms.stress.test.abort.kafka.lmde.event.flag.name")
    private String dmsStressTestAbortKafkaLMDEEventFlagName;

    @Property(propertyName = "dms.filter.dispatcher.events")
    private String dmsFilterDispatcherEvents;

    @Property(propertyName = "enable.daas.store.update.kafka.consumers")
    private boolean enableDaasStoreUpdateKafkaConsumers = false;

    @Property(propertyName = "dms.is.log.truncation.enabled")
    @DefaultValue.Boolean(false)
    private boolean isLogTruncationEnabled;

    @Property(propertyName = "dms.log.truncation.max.char.length")
    @DefaultValue.Int(20000)
    private int logTruncationMaxCharLength;

    @Property(propertyName = "dms.onboarding.es.update")
    private boolean enableDmsOnboardingESUpdate;

    @Property(propertyName = "enable.pickup.point.config.kafka.consumers")
    private boolean enablePickupPointConfigKafkaConsumers = false;

    @Property(propertyName = "enable.dispatcher.trip.kafka.consumers")
    private boolean enableDispatcherTripKafkaConsumers = false;

    @Property(propertyName = "enable.driver.trip.streaming.kafka.consumers")
    private boolean enableDriverTripStreamingKafkaConsumers = false;

    @Property(propertyName = "enable.driver.batching.preference.update.kafka.producer")
    @DefaultValue.Boolean(false)
    private boolean enableDriverBatchingPreferenceUpdateKafkaProducer;

    @Property(propertyName = "dms.is.driver.es.check.enabled")
    @DefaultValue.Boolean(false)
    private boolean isDriverEsCheckEnabled;

    @Property(propertyName = "dms.driver.fetch.page.size")
    @DefaultValue.Int(500)
    private int dmsDriverFetchPageSize;

    @Property(propertyName = "lmde.events.stress.test.enabled")
    private boolean lmdeEventsStressTestEnabled;

    @Property(propertyName = "enable.driver.legal.doc.status.kafka.producer")
    @DefaultValue.Boolean(false)
    private boolean enableDriverLegalDocStatusKafkaProducer;

    @Property(propertyName = "enable.quartz.inhome.driver.daily.store.schedule")
    private boolean enableQuartzInHomeDriverDailyStoreSchedule = false;

    @Property(propertyName = "inHome.driver.job.code")
    private String inHomeJobCode;

    @Property(propertyName = "enable.driver.deletion.kafka.producer")
    private boolean enableDriverDeletionKafkaProducer;

    @Property(propertyName = "enable.inhome.driver.onboarding.new.flow")
    private boolean enableInHomeDriverOnBoardingNewFlow;

    @Property(propertyName = "enable.driver.hc.doc.kafka.producer")
    @DefaultValue.Boolean(false)
    private boolean enableDriverHCDocKafkaProducer;

    @Property(propertyName = "driver.health.care.document.reject.reason.action")
    private String hcDocumentReasonConfigAction;

    @Property(propertyName = "enable.driver.deletion.requested.kafka.producer")
    private boolean enableDriverDeletionRequestedKafkaProducer;

    @Property(propertyName = "dms.stress-test.enabled.markets", delimiter="#;#")
    private Set<String> dmsStressTestEnabledMarkets;

    @Property(propertyName = "default.stress-test.password")
    public String defaultStressTestPassword;

    @Property(propertyName = "enable.quartz.inhome.driver.badge.job")
    private boolean enableQuartzInHomeDriverBadgeJob = false;

    @Property(propertyName = "dms.is.authority.check.enabled")
    @DefaultValue.Boolean(false)
    private boolean isAuthorityCheckEnabled;

    @Property(propertyName = "dms.realm.ids.for.auth.check", delimiter = ",")
    private List<String> realmIdsForAuthCheck;

    @Property(propertyName = "dms.inhome.headshot.enabled.markets", delimiter="#;#")
    private Set<String> dmsInhomeHeadshotEnabledMarkets;

    @Property(propertyName = "enable.driver.login.details.kafka.producer")
    private boolean enableDriverLoginDetailsKafkaProducer;

    @Property(propertyName = "enable.driver.logout.details.kafka.producer")
    private boolean enableDriverLogoutDetailsKafkaProducer;

    @Property(propertyName = "enable.driver.reset.password.details.kafka.producer")
    private boolean enableDriverResetPasswordDetailsKafkaProducer;

    @Property(propertyName = "enable.driver.device.status.kafka.producer")
    private boolean enableDriverDeviceStatusKafkaProducer;

    @Property(propertyName = "enable.event.for.stress.test.driver")
    private boolean enableEventForStressTestDriver;

    @Property(propertyName = "dms.driver.document.status.acceptance.proof.update.enabled")
    @DefaultValue.Boolean(false)
    private boolean dmsDriverDocumentStatusAcceptanceProofUpdateEnabled;

    @Property(propertyName = "dms.default.login.password")
    private String dmsDefaultLoginPassword;

    @Property(propertyName = "trip.executor.service.check.enabled")
    private boolean isTripExecutorServiceCheckEnabled;

    @Property(propertyName = "dms.realm.ids.allowed.for.driver.update", delimiter = ",")
    private List<String> realmIdsAllowedForDriverUpdate;

    @Property(propertyName = "dms.realm.ids.from.spark.app", delimiter = ",")
    private List<String> dmsRealmIdsFromSparkApp;

    @Property(propertyName = "dms.allowed.fields.for.spark.app", delimiter = "#;#")
    private Set<String> dmsAllowedFieldsForSparkApp;

    @Property(propertyName = "dms.driver.types.to.disable.driver.drop.trips.check", delimiter = ",")
    private Set<String> driverTypesToDisableDriverDropTripsCheck;

    @Property(propertyName = "dms.driver.booster.offer.tenant.id.check.enabled")
    private boolean isDriverBoosterOfferTenantIdCheckEnabled;

    @Property(propertyName = "enable.driver.status.update.request.kafka.producer")
    private boolean enableDriverStatusUpdateRequestKafkaProducer;

    @Property(propertyName = "dms.driver.risk.score.source", delimiter = "#;#")
    public Set<String> dmsDriverRiskScoreSource;


    @Property(propertyName = "enable.dms.infoSec.logging")
    private boolean enableInfoSecLogging;

    @Property(propertyName = "dms.infoSec.executor.core.pool.size")
    private int dmsInfoSecExecutorCorePoolSize;

    @Property(propertyName = "dms.infoSec.executor.max.pool.size")
    private int dmsInfoSecExecutorMaxPoolSize;

    @Property(propertyName = "dms.infoSec.executor.queue.capacity")
    private int dmsInfoSecExecutorQueueCapacity;

    @Property(propertyName = "dms.infoSec.executor.thread.name.prefix")
    private String dmsInfoSecExecutorThreadNamePrefix;

    @Property(propertyName = "dms.api.should.not.filter", delimiter = ",")
    public Set<String> dmsAPIShouldNotFilter;

    @Property(propertyName = "enable.dms.driver.risk.score.consumer")
    private boolean enableDMSDriverRiskScoreConsumer;

    @Property(propertyName = "enable.dms.driver.risk.score.real.time.consumer")
    private boolean enableDMSDriverRiskScoreRealTimeConsumer;

    @Property(propertyName = "dms.driver.risk.score.consumer.enabled.markets", delimiter = "#;#")
    public Set<String> dmsDriverRiskScoreConsumerEnabledMarkets;

    @Property(propertyName = "dms.driver.risk.score.custom.zone.enabled.markets", delimiter = "#;#")
    public Set<String> dmsDriverRiskScoreCustomZoneEnabledMarkets;

    @Property(propertyName = "dms.driver.risk.score.default.zone.enabled.markets", delimiter = "#;#")
    public Set<String> dmsDriverRiskScoreDefaultZoneEnabledMarkets;

    @Property(propertyName = "dms.driver.forced.offline.id.verification.duration")
    private int dmsDriverForcedOfflineIDVerificationDuration;

    @Property(propertyName = "dms.driver.forced.offline.tou.violation.duration")
    private int dmsDriverForcedOfflineTOUViolationDuration;

    @Property(propertyName = "dms.realm.ids.enabled.for.auth.check")
    public Set<String> dmsRealmIds;

    @Property(propertyName = "enable.dms.driver.masking.RRLogFilter")
    private boolean enableDMSDriverMaskingRRLogFilter;

    @Property(propertyName = "enable.dms.driver.Response.RRLogFilter")
    private boolean enableDMSDriverResponseRRLogFilter;

    @Property(propertyName = "dms.masking.rrLogFilter.filter.fields", delimiter = ",")
    private List<String> dmsMaskingRRLogFilterFields;

    @Property(propertyName = "dms.rrLogFilter.restricted.api", delimiter = ",")
    private List<String> dmsRRLogFilterRestrictedApi;

    @Property(propertyName ="dms.api.private.key")
    public String dmsApiPrivateKey;

    @Property(propertyName ="dms.api.private.key.version")
    public String dmsApiPrivateKeyVersion;

    @Property(propertyName ="dms.api.consumer.id")
    public String dmsApiConsumerId;

    @Property(propertyName = "dms.driver.risk.score.consumer.action.map")
    private String dmsDriverRiskScoreConsumerActionMap;

    @Property(propertyName = "dms.id.verification.data.publish.enabled")
    public boolean dmsIdVerificationDataPublishEnabled;

    @Property(propertyName = "is.mps.enable")
    public boolean isMPSEnabled;

    @Property(propertyName = "dms.mps.max.retry.count")
    public int  maxRetryCountMps;

    @Property(propertyName = "dms.id.verification.api.v2")
    public String dmsIdVerificationApiV2;

    @Property(propertyName = "dms.async.thread.pool.threads.count.id.verification.api.v2")
    private int dmsAsyncThreadPoolThreadsCountIdVerificationApiV2;

    @Property(propertyName = "dms.id.verification.api.v2.async.enabled")
    public boolean dmsIdVerificationApiV2AsyncEnabled;

    @Property(propertyName = "dms.driver.signed.tou.email.enabled.market", delimiter = "#;#")
    public Set<String> dmsDriverSignedTOUEmailEnabledMarket;

    @Property(propertyName = "dms.driver.signed.tou.doc.deeplink")
    public String dmsDriverSignedTOUDocDeepLink;

    @Property(propertyName = "dms.upcoming.legaldoc.version")
    public String dmsUpcomingLegalDocVersion;

    @Property(propertyName = "dms.snp.in.app.notification.markets.enable", delimiter = ",")
    private List<String> dmsSNPInAppNotificationMarketsEnabled;

    @Property(propertyName = "dms.id.verification.es.data.ingestion.enabled")
    private boolean dmsIdVerificationESDataIngestionEnabled;

    @Property(propertyName = "enable.driver.doc.updated.kafka.producer")
    @DefaultValue.Boolean(false)
    private boolean enableDriverDocUpdatedKafkaProducer;

    @Property(propertyName = "dms.driver.risk.score.zone.category.action.map")
    public String dmsDriverRiskZoneCategoryActionMap;

    @Property(propertyName = "dms.rrLogFilter.restrict.header.log.for.api", delimiter = ",")
    private List<String> dmsRRLogFilterRestrictHeaderLogForApi;
}
