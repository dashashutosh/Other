package com.walmart.dms.common.deserializers;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.walmart.dms.common.enums.UserRole;

import java.io.IOException;
import java.time.ZonedDateTime;

public class UserRoleJsonDeserializer extends JsonDeserializer<UserRole> {
    @Override
    public UserRole deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        return UserRole.fromText(p.getText());
    }
}
