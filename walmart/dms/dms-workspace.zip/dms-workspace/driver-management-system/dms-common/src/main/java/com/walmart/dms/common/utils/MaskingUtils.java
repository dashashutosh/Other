package com.walmart.dms.common.utils;

import com.walmart.dms.common.config.CommonConfig;
import io.strati.libs.jackson.core.JsonProcessingException;
import io.strati.libs.jackson.databind.JsonNode;
import io.strati.libs.jackson.databind.ObjectMapper;
import io.strati.libs.jackson.databind.node.ArrayNode;
import io.strati.libs.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


@Slf4j
@Component
public class MaskingUtils {

    @Autowired
    private CommonConfig commonConfig;

    ObjectMapper mapper = new ObjectMapper();

    // Mask specific fields directly using JSONPath
    public String maskPiiWithJsonPath(String jsonPayload) {

        try {
            if (!commonConfig.isEnableDMSDriverMaskingRRLogFilter()) {
                return jsonPayload;
            }
            if (isValidJson(jsonPayload)) {
                JsonNode rootNode = mapper.readTree(jsonPayload);
                List<String> attributesToMask = commonConfig.getDmsMaskingRRLogFilterFields();
                maskJsonNode(rootNode, attributesToMask);
                return mapper.writeValueAsString(rootNode);
            }
        } catch (Exception e) {
            log.error("Error: ", e);
        }
        return jsonPayload;
    }

    // Helper method to check if a string is valid JSON
    private static boolean isValidJson(String json) {
        try {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.readTree(json);
            return true;
        } catch (JsonProcessingException e) {
            log.error("Invalid JSON payload: {}", json);
            return false;
        }
    }


    private static void maskJsonNode(JsonNode node, List<String> attributesToMask) {
        if (node.isObject()) {
            // If the node is an object (JSONObject in JSON), iterate over its fields
            ObjectNode objectNode = (ObjectNode) node;
            for (String attribute : attributesToMask) {
                if (objectNode.has(attribute)) {
                        objectNode.put(attribute, "**********");
                }
            }

            // Recurse into nested objects
            objectNode.fields().forEachRemaining(entry -> maskJsonNode(entry.getValue(), attributesToMask));

        } else if (node.isArray()) {
            // If the node is an array, iterate over its elements
            ArrayNode arrayNode = (ArrayNode) node;
            for (JsonNode arrayItem : arrayNode) {
                maskJsonNode(arrayItem, attributesToMask);
            }
        }
    }

}