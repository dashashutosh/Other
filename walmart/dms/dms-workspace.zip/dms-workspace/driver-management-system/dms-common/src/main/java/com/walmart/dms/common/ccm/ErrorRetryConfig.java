package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

/**
 * @author n0k008c
 */
@Configuration(configName = "errorRetryConfig")
@Data
public class ErrorRetryConfig {

    @Property(propertyName = "dms.error.retry.kafka.cluster")
    public String errorRetryKafkaCluster;

    @Property(propertyName = "dms.processed.error.kafka.topic")
    public String processedErrorKafkaTopic;

    @Property(propertyName = "dms.error.retry.kafka.consumer.groupId")
    public String errorRetryKafkaGroup;

    @Property(propertyName = "dms.error.retry.cron.expression")
    public String errorRetryCronExpression;

    @Property(propertyName = "dms.error.retry.query.size.limit")
    public int errorRetryQuerySizeLimit;

    @Property(propertyName = "dms.error.retry.exponential.base")
    public int errorRetryExponentialBase;
}
