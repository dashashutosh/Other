package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

import java.util.Set;

@Data
@Configuration(configName = "driverDeactivatePauseConfig")
public class DriverDeactivatePauseConfig {
    @Property(propertyName = "driver.deactivate.pause.enabled")
    private boolean isDriverDeactivatePauseEnabled = false;

    @Property(propertyName = "driver.deactivate.pause.start.time")
    public String driverDeactivatePauseStartTime;

    @Property(propertyName = "driver.deactivate.pause.end.time")
    public String driverDeactivatePauseEndTime;

    @Property(propertyName = "driver.deactivate.pause.timezone", delimiter = ",")
    public Set<String> driverDeactivatePauseTimezone;

    @Property(propertyName = "driver.deactivate.paused.jobs.cron.expression")
    public String driverDeqctivatePausedJobCron;
}
