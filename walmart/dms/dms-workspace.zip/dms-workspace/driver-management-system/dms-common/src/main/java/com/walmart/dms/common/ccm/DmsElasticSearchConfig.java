package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;
import lombok.Data;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.List;

@Data
@Configuration(configName = "dmsElasticConfig")
public class DmsElasticSearchConfig {

    @Property(propertyName = "dms.primary.cluster.hosts", delimiter = ",")
    private List<String> esPrimaryHosts;

    @Property(propertyName = "dms.es.primary.cluster.hosts.schema")
    @DefaultValue.String("HTTPS")
    private String connectionSchema;

    @Property(propertyName = "dms.es.connect.timeout.ms")
    @DefaultValue.Int(5000)
    private Integer connectTimeoutMs;

    @Property(propertyName = "dms.es.read.timeout.ms")
    @DefaultValue.Int(5000)
    private Integer readTimeoutMs;

    @Property(propertyName = "dms.es.primary.cluster.username")
    private String dmsEsUsername;

    @Property(propertyName = "dms.es.primary.cluster.accessKey")
    private String dmsESPassword;

    @Property(propertyName = "dms.es.driver.index")
    private String driverIndex;

    @Property(propertyName = "dms.es.driver.search.default.page.size")
    @DefaultValue.Int(10)
    private Integer driverSearchDefaultPageSize;

    @Property(propertyName = "dms.es.driver.search.default.sort.value")
    @DefaultValue.String("firstName")
    private String driverSearchDefaultSortValue;

    @Property(propertyName = "dms.es.api.max.retry.attempts")
    @DefaultValue.Int(3)
    private Integer maxRetryAttempts;

    @Property(propertyName = "dms.secondary.cluster.hosts", delimiter = ",")
    private List<String> esSecondaryHosts;

    @Property(propertyName = "dms.es.secondary.cluster.hosts.schema")
    @DefaultValue.String("HTTPS")
    private String connectionSecondarySchema;

    @Property(propertyName = "dms.es.secondary.cluster.username")
    private String dmsEsDrUsername;

    @Property(propertyName = "dms.es.secondary.cluster.accessKey")
    private String dmsESDrPassword;

    @Property(propertyName = "dms.es.pii.secondary.cluster.enable")
    private Boolean dmsESPIISecondaryClusterEnabled;

    @Property(propertyName = "dms.es.pii.primary.cluster.enable")
    private Boolean dmsESPIIPrimaryClusterEnabled;

}
