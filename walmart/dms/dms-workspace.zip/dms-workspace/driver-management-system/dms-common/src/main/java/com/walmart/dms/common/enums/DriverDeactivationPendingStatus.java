package com.walmart.dms.common.enums;

public enum DriverDeactivationPendingStatus {

    QUEUED, COMPLETED

}
