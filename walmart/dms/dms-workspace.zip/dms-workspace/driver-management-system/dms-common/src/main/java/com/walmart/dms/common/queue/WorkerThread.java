package com.walmart.dms.common.queue;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;

@SuppressWarnings("hiding")
public abstract class WorkerThread<QueueItem> extends Thread {

	private static Logger LOGGER;
	private LinkedBlockingQueue<QueueItem> queue = null;
	protected boolean stopped = false;
	protected boolean exceptionLog = true;

	private boolean lock = false;

	protected WorkerThread() {
		queue = new LinkedBlockingQueue<QueueItem>();
	}

	protected WorkerThread(boolean exceptionLog) {
		this();
		this.exceptionLog = exceptionLog;
	}

	public abstract WorkerThread<QueueItem> getInstance();

	public abstract void process(QueueItem queueItem) throws Exception;

	// return true if accepted else false
	public boolean offer(QueueItem queueItem) {
		boolean offer = queue.offer(queueItem);
		return offer;
	}

	// throws exception if space not available
	public boolean add(QueueItem queueItem) {
		boolean offer = queue.add(queueItem);
		return offer;
	}

	// Blocking call
	public void put(QueueItem queueItem) throws InterruptedException {
		queue.put(queueItem);

	}

	public int size() {
		return queue.size();
	}

	public QueueItem take() throws InterruptedException {
		return queue.take();
	}

	public QueueItem peek() throws InterruptedException {
		return queue.take();
	}

	public QueueItem poll(long timeout, TimeUnit unit) throws InterruptedException {
		return queue.poll(timeout, unit);
	}

	public boolean isStopped() {
		return stopped;
	}

	public void stopWorker() {
		stopped = true;
	}

	@Override
	public void run() {
		while (true) {
			QueueItem item = null;
			try {
				item = queue.take();
				lock = true;
				process(item);
				lock = false;
			} catch (InterruptedException e) {
				lock = false;
				LOGGER.error(e.getMessage(), e);
				break;
			} catch (Exception e) {
				lock = false;
				if (exceptionLog)
					logException(item, e);
			}
		}
	}

	protected void logException(QueueItem item, Exception e) {
		LOGGER.error(e.getMessage(), e);
	}

	public static void setLog(Logger log) {
		WorkerThread.LOGGER = log;
	}

	public boolean isLock() {
		return lock;
	}

}
