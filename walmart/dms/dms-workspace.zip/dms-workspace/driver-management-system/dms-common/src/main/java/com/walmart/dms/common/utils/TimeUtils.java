package com.walmart.dms.common.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import com.google.common.base.Preconditions;
import com.walmart.dms.common.constant.Constant;

/**
 * @author n0a008p
 * @author smahan1
 */
public class TimeUtils {
    private TimeUtils() {
    }

    public static final ZoneId UTC = ZoneId.of("UTC");
    public static final ZoneId PST = ZoneId.of("America/Los_Angeles");
    public static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    public static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final DateTimeFormatter DATE_TIME_WEEK_FORMATTER = DateTimeFormatter.ofPattern("ww");
    private static final DateTimeFormatter DATE_TIME_YEAR_MONTH_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM");

    public static Long getETAfromTime(LocalDateTime estimatedTime) {
        if (estimatedTime == null)
            return null;
        LocalDateTime nowLocal = LocalDateTime.now();
        return Duration.between(nowLocal, estimatedTime).toMinutes();
    }

    public static LocalDateTime getCurrentLocalTimeUTC() {
        return getCurrentTimeUTC().toLocalDateTime();
    }

    /**
     * Get current local date for give zone id.
     *
     * @param shortZoneId e.g. PST, EST, CST, IST, UTC
     * @return
     */
    public static LocalDate getLocalDate(String shortZoneId) {
        ZoneId zoneId = ZoneId.of(ZoneId.SHORT_IDS.get(shortZoneId));
        return LocalDate.now(zoneId);
    }

    public static LocalDate getLocalDate(ZoneId zoneId) {
        return LocalDate.now(zoneId);
    }

    public static ZonedDateTime getZonedDateTime(Instant instant) {
        return ZonedDateTime.ofInstant(instant, ZoneId.of("UTC"));
    }

    public static ZonedDateTime getCurrentTimeUTC() {
        return ZonedDateTime.now(UTC);
    }

    public static LocalDateTime getLocalTimeUTC() {
        return LocalDateTime.now(UTC);
    }

    public static ZonedDateTime convertToUTC(ZonedDateTime time) {
        return time.withZoneSameInstant(UTC);
    }

    public static String getCurrentTime() {
        return getDateInHHMMSS(getCurrentTimeUTC());
    }

    public static String getCurrentDateInYYYYMMDD() {
        return getDateInYYYYMMDD(getCurrentTimeUTC());
    }

    public static String getDateInYYYYMMDD(ZonedDateTime time) {
        Preconditions.checkNotNull(time);
        return DateTimeFormatter.ofPattern("yyyyMMdd").format(time);
    }

    public static String getDateInUTCYYYYMMDD(ZonedDateTime time) {
        ZonedDateTime utcTime = time.withZoneSameInstant(UTC);
        return getDateInYYYYMMDD(utcTime);
    }

    public static String getDateInHHMMSS(ZonedDateTime time) {
        Preconditions.checkNotNull(time);
        return DateTimeFormatter.ofPattern("HHmmss").format(time);
    }

    public static String getDateInUTCHHMMSS(ZonedDateTime time) {
        ZonedDateTime utcTime = time.withZoneSameInstant(UTC);
        return getDateInHHMMSS(utcTime);
    }

    public static long calculateDiffInHours(final ZonedDateTime start, final ZonedDateTime end) {
        long diffInSec = end.toEpochSecond() - start.toEpochSecond();
        return diffInSec / 3600;
    }
    
    public static long calculateDiffInMinutes(final ZonedDateTime start, final ZonedDateTime end) {
        long diffInSec = end.toEpochSecond() - start.toEpochSecond();
        return diffInSec / 60;
    }

    public static String toISOFormatString(ZonedDateTime time) {
        if (time != null) {
            return time.toOffsetDateTime().toString();
        } else
            return null;

    }

    public static ZonedDateTime fromISOFormatString(String time) {
        if (time != null) {
            return ZonedDateTime.parse(time);
        } else
            return null;

    }

    public static LocalDateTime convertESTLocalDateTimeToUTC(String localDateTime) {

        ZoneId oldZone = ZoneId.of(ZoneId.SHORT_IDS.get("EST"));
        ZoneId newZone = ZoneId.of("UTC");

        LocalDateTime oldDateTime = LocalDateTime.parse(localDateTime);
        LocalDateTime newDateTime = oldDateTime.atZone(oldZone).withZoneSameInstant(newZone).toLocalDateTime();
        return newDateTime;

    }
    public static LocalDate atLocalDate(String localDate) {
        LocalDate lclDate = LocalDate.parse(localDate);
        return lclDate;

    }

    public static ZonedDateTime atStartOfDay(ZonedDateTime date, ZoneId zoneId) {
        date = ZonedDateTime.ofInstant(date.toInstant(), zoneId);
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
        return localDateTimeToDate(startOfDay, zoneId.getId());
    }

    public static ZonedDateTime atStartOfDay(ZonedDateTime date) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
        return localDateTimeToDate(startOfDay, date.getZone().getId());
    }

    public static LocalDateTime atLocalStartOfDay(ZonedDateTime date) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
        return startOfDay;
    }

    public static LocalDateTime atLocalEndOfDay(ZonedDateTime date) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime endOfDay = localDateTime.with(LocalTime.MAX);
        return endOfDay;
    }

    public static ZonedDateTime atEndOfDay(ZonedDateTime date) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime endOfDay = localDateTime.with(LocalTime.MAX);
        return localDateTimeToDate(endOfDay, date.getZone().getId());
    }

    public static long atStartOfDayTimestamp(ZonedDateTime date, ZoneId zoneId) {
        return getTimestampForZonedDateTime(atStartOfDay(date, zoneId));
    }

    public static long atEndOfDayTimestamp(ZonedDateTime date) {
        return getTimestampForZonedDateTime(atEndOfDay(date));

    }

    public static long getTimestampForZonedDateTime(ZonedDateTime dateTime) {
        return dateTime.getLong(ChronoField.INSTANT_SECONDS) * 1000;
    }



    public static long getTimestampForTime(LocalTime time) {
        return time.getLong(ChronoField.MILLI_OF_DAY);
    }

    public static long getTimestampFoLocalDate(LocalDate date,ZoneId zoneId) {
        return ((date.atStartOfDay().atZone(zoneId)).toInstant().toEpochMilli());
    }

    private static LocalDateTime dateToLocalDateTime(ZonedDateTime date) {
        return date.toLocalDateTime();
    }

    private static ZonedDateTime localDateTimeToDate(LocalDateTime localDateTime, String zoneId) {
        return ZonedDateTime.from(localDateTime.atZone(ZoneId.of(zoneId)));
    }

    public static ZonedDateTime getZonedDateTimeForZoneId(String timestamp, String zoneId) {
        return ZonedDateTime.ofInstant(Instant.ofEpochMilli(Long.parseUnsignedLong(timestamp)), ZoneId.of(zoneId));
        // ZoneId.of(ZoneId.SHORT_IDS.get(zoneId))
    }
    
    public static ZonedDateTime getZonedDateTimeForZoneId(long timestamp) {
        return ZonedDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.of("UTC"));
    }

    public static boolean isBetween(LocalTime queryTime, LocalTime startTime, LocalTime endTime) {
        return queryTime.equals(startTime) || queryTime.equals(endTime)
                || (queryTime.isAfter(startTime) && queryTime.isBefore(endTime));
    }

    public static String getISOformatFromShortHand(String shortZoneId) {
        return ZoneId.SHORT_IDS.get(shortZoneId);
    }

    public static String getShortHandFromISOformat(String longZoneId) {
        for (Map.Entry<String, String> entry : ZoneId.SHORT_IDS.entrySet()) {
            if (entry.getValue().equals(longZoneId)) {
                return entry.getKey();
            }
        }
        return "";
    }

    /**
     * 
     * @param date
     * @return Date part of ZonedDateTime date in yyyy-MM-dd.
     */
    public static String getStringDate(ZonedDateTime date) {
        return date.toLocalDate().toString();
    }

    public static ZonedDateTime previousDay(ZonedDateTime zonedDateTime) {
        return zonedDateTime.minusDays(1);
    }

    public static String convertZonedDateTimeToString(ZonedDateTime zonedDateTime) {
        return dateTimeFormatter.format(zonedDateTime);
    }

    public static String getDateInYYYYMMDDFormate(ZonedDateTime time) {
        Preconditions.checkNotNull(time);
        return DateTimeFormatter.ofPattern(Constant.YEAR_MONTH_DATE).format(time);
    }

    public static String getLocalDateInYYYYMMDDFormat(LocalDate time) {
        Preconditions.checkNotNull(time);
        return DateTimeFormatter.ofPattern(Constant.YEAR_MONTH_DATE).format(time);
    }

    public static String getDateInYYYYMMDDFormate(ZonedDateTime time, ZoneId zoneId) {
        Preconditions.checkNotNull(time);
        Preconditions.checkNotNull(zoneId);
        return DateTimeFormatter.ofPattern(Constant.YEAR_MONTH_DATE).format(time.withZoneSameInstant(zoneId));
    }

    public static String getDateInHHmmFormate(ZonedDateTime time) {
        Preconditions.checkNotNull(time);
        return DateTimeFormatter.ofPattern("HHmm").format(time);
    }

    public static String getDateInHHmmFormate(ZonedDateTime time, ZoneId zoneId) {
        Preconditions.checkNotNull(time);
        Preconditions.checkNotNull(zoneId);
        return DateTimeFormatter.ofPattern("HHmm").format(time.withZoneSameInstant(zoneId));
    }

    public static String getDateInFormat(ZonedDateTime time, String format) {
        Preconditions.checkNotNull(time);
        return DateTimeFormatter.ofPattern(format).format(time);
    }

    /**
     * Gets the week number for date represented by given zoned date time.
     *
     * @param zonedDateTime the zoned date time
     * @return the week number
     */
    public static String getWeekNumber(final ZonedDateTime zonedDateTime) {
        Preconditions.checkNotNull(zonedDateTime);
        return DATE_TIME_WEEK_FORMATTER.format(zonedDateTime);
    }

    public static String getDateInYearMonthDay() {
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat(Constant.YEAR_MONTH_DATE);
        String strDate = dateFormat.format(date);
        return strDate;
    }

    /**
     * Gets string date in the yyyy-MM format from the date represented by given local date time.
     *
     * @param localDateTime the local date time
     * @return the week number
     */
    public static String getDateInYearMonthFormat(final LocalDateTime localDateTime) {
        Preconditions.checkNotNull(localDateTime);
        return DATE_TIME_YEAR_MONTH_FORMATTER.format(localDateTime);
    }
    
    public static Instant getInstantFromEpochMillis(final Long epochMillis) {
    	return epochMillis != null ? Instant.ofEpochMilli(epochMillis) : null;
    }
}
