package com.walmart.dms.common.enums;

import java.util.Arrays;

public enum DriverSuggestionTemplate {

	ON_DEMAND(new DriverSuggestionFilter[]{DriverSuggestionFilter.ONLINE}, DriverSource.SPARK_NOW),
	SCHEDULED(new DriverSuggestionFilter[]{DriverSuggestionFilter.AVAILABLE}, DriverSource.SCHEDULE),
	HYBRID(new DriverSuggestionFilter[]{DriverSuggestionFilter.AVAILABLE_OR_ONLINE}, DriverSource.SPARK_NOW);

	private DriverSuggestionFilter[] filters;
	private DriverSource source;

	DriverSuggestionTemplate(DriverSuggestionFilter[] filters, DriverSource source) {
		this.filters = filters;
		this.source = source;
	}

	public DriverSource getSource() {
		return source;
	}

	public DriverSuggestionFilter[] getFilters() {
		return Arrays.copyOf(filters, filters.length);
	}
}
