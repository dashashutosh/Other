package com.walmart.dms.common.exception;

import com.walmart.dms.common.error.ErrorCode;

import java.util.ArrayList;
import java.util.List;

public class InvalidMpsRequestException extends Exception {
    private List<ErrorCode> errorCodes = new ArrayList<ErrorCode>();

    public InvalidMpsRequestException(String str) {
        super(str);
    }

    public InvalidMpsRequestException(String str, Throwable cause) {
        super(str, cause);
    }

    public InvalidMpsRequestException(ErrorCode errorCode, String message) {
        super(message);
        this.errorCodes.add(errorCode);
    }

}