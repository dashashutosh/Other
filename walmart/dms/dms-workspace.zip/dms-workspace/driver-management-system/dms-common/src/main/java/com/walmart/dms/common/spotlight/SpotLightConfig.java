package com.walmart.dms.common.spotlight;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;
import lombok.Data;

/**
 * @author n0a008p on Apr 12, 2018
 */
@Configuration(configName = "spotlight")
@Data
public class SpotLightConfig {

    @Property(propertyName = "spotlight.environment")
    public String enviornment;

    @Property(propertyName = "spotlight.url")
    public String url;

    @Property(propertyName = "spotlight.enabled")
    public String enabled;

    @Property(propertyName = "spotlight.alert.threshold")
    @DefaultValue.Int(2)
    public Integer spotlightAlertThreshold;

    @Property(propertyName = "event.dms.info.id")
    public String dmsInfoEventId;

    @Property(propertyName = "event.failedalert.id")
    public String failureAlertEventId;

    @Property(propertyName = "event.onboardingsuccess.id")
    public String onboardingSuccessEventId;

    @Property(propertyName = "event.payment.reconciliation.id")
    public String paymentReconciliationEventId;

    @Property(propertyName = "event.payment.reconciliation.weekly.id")
    public String weeklyPaymentReconciliationEventId;

    @Property(propertyName = "event.store.schedule.outofsync.id")
    public String driverStoreScheduleOutOfSyncEventId;

    @Property(propertyName = "event.spark.job.execution.completion.id")
    private String sparkJobExecutionCompletionEventId;

    @Property(propertyName = "event.dms.management.status.id")
    private String driverManagementEventId;
}
