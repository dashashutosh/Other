package com.walmart.dms.common.ccm;

import com.walmart.dms.common.enums.DriverType;
import com.walmart.dms.common.enums.ReplayEventsTopic;
import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.DefaultValue;
import io.strati.configuration.annotation.Property;
import lombok.Data;

import java.util.List;

@Data
@Configuration(configName = "driverSuggestionConfig")
public class DriverSuggestionConfig {

    @Property(propertyName = "driverSuggestion.log.level")
    public String driverSuggestionLogLevel;
    @Property(propertyName = "driverSuggestion.read.timeout.sec")
    public int driverSuggestionReadTimeOutInSec;
    @Property(propertyName = "driverSuggestion.connect.timeout.sec")
    public int driverSuggestionConnectTimeOutInSec;
    @Property(propertyName = "driverSuggestion.api.header")
    public String driverSuggestionApiHeaders;
    @Property(propertyName = "driverSuggestion.calendar.delete.cron")
    public String driverSuggestionCalendarDeleteCron;
    @Property(propertyName = "driverSuggestion.offer.duplicateEntry.alert.enabled")
    public boolean driverOfferDuplicateEntryAlertEnabled = false;
    @Property(propertyName = "driverCalendar.monitoring.cron")
    public String driverCalendarMonitoringCron;
    @Property(propertyName = "driverCalendar.creation.monitoring.cron")
    public String driverCalendarCreationMonitoringCron;
    @Property(propertyName = "driverCalender.monitoring.enabled.cronJob")
    public boolean driverCalendarMonitoringCronJobEnabled;
    @Property(propertyName = "driverCalender.monitoring.hours.difference")
    public long driverCalederMonitoringHoursDifference;
    @Property(propertyName = "driverCalender.monitoring.driverCount.threshold")
    public long driverCalederMonitoringDriverCountThreshold;
    @Property(propertyName = "driverCalendar.monitoring.tillDay")
    @DefaultValue.Int(7)
    public int driverCalendarTillDay;
    @Property(propertyName = "driverSuggestion.dms.index.suggestion")
    private String dmsDriverSuggestionIndex;
    @Property(propertyName = "driverSuggestion.dms.reindex.data.size")
    @DefaultValue.Int(5)
    private int driverSuggestionReindexDataSize;
    @Property(propertyName = "driverSuggestion.dms.es.write.all.drivers")
    private Boolean driverSuggestionEsWriteAllDrivers = false;
    @Property(propertyName = "driverSuggestion.driver.document.es.check.cron.exp")
    public String driverSuggestionDriverDocumentEsCheckCronExp;
    @Property(propertyName = "driverSuggestion.driver.document.es.replay.enabled")
    public boolean driverSuggestionDriverDocumentEsReplayEnabled;
    @Property(propertyName = "driverSuggestion.mismatch.enabled.driver.types", delimiter=",")
    private List<DriverType> driverSuggestionMismatchEnabledDriverTypes;
    @Property(propertyName = "driverSuggestion.driver.document.es.check.replay.topic")
    public ReplayEventsTopic driverSuggestionDriverDocumentEsCheckReplayTopic;
    @Property(propertyName = "driverSuggestion.mismatch.driver.email.list", delimiter=",")
    private List<String> driverSuggestionMismatchDriverEmailList;
}
