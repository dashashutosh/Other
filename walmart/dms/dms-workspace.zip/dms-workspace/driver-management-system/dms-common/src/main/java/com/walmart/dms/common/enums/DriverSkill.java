package com.walmart.dms.common.enums;

public enum DriverSkill {
    ALCOHOL_DELIVERY,
    INHOME_DELIVERY,
    PHARMACY;
}
