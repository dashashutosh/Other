package com.walmart.dms.common.enums;

public enum DriverType {

    REGULAR, BACKUP, TFORCE, ASSOCIATE, SORTATION, HOMEOFFICE, SPARK_BACKUP, FLEET, DEDICATED_DELIVERY, NTRANSIT
}
