package com.walmart.dms.common.enums;

public enum DynamicPayDisplayCheckpoints {

    DELIVERY("Delivery"), INCENTIVE("Incentive"), TIP("Tip"), OUTSTANDING("Outstanding"), PICKUP("Pickup"),

    SURGE_PRICE("Surge Price"), RETURN("Return"), BASE_PRICE("Base Price"), EXTRA_EFFORT("Extra Effort");

    String value;

    public String getValue() { return value; }

    DynamicPayDisplayCheckpoints(String value) { this.value = value; }

}
