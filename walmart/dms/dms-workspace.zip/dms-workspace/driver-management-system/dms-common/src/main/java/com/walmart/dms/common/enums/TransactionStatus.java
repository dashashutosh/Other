package com.walmart.dms.common.enums;

public enum TransactionStatus {

	MP_WAITING_FOR_REQUEST("Waiting for MP request","Waiting for MP request"),  //for poller if we don't use instant payment
	MP_REQUEST_SENT("MP request sent","MP API request sent successfully"),
	MP_REQUEST_FAILED("MP request failed","MP API request failed"),
	MP_PAYMENT_COMPLETED("Payment completed","Payout has been completed and ready to be sent to the bank/PayPal"),
	MP_PENDING_LOAD("Pending Load","Payout is about to be delivered to the payee"),
	MP_CANCELLED("Cancelled","Payout has been cancelled"),
	MP_PENDING_PAYEE_APPROVAL("Pending Payee Approval","The payout is pending approval by Payoneer’s KYC process"),
	MP_PENDING_APPROVAL("Pending Approval","The payout is pending approval by Payoneer’s KYC process"),
	MP_FUNDED("Funded","Payout has been funded and is pending approval from the bank/PayPal"),
	MP_SETTLING("Settling","An intermediate state that is the time between the payment cancelled and the refund"),
	DDI_REQUEST_SENT("DDI request sent","DDI API request sent successfully"),
	DDI_REQUEST_FAILED("DDI request failed","DDI API request failed"),
	DDI_PAID("Paid","Payout has been funded by DDI"),
	DDI_PENDING("Pending","The payout is pending by DDI"),
	DDI_INPROCESS("InProcess","The payout is in process"),
	DDI_FAILED("Failed","Payout failed in DDI"),
	DDI_UNDEFINED("Undefined", "Undefined status in DDI"),

	SUCCESS("success", "payment sucess"),

	FAILED("failed", "payment failed"),

	PARTIALLY_PAID("patially paid", "patially paid"),

	PAID("paid", "payment paid");
	
	
	private String value;
	
	private String description;
	
	private TransactionStatus(String value,String description) {
		this.value=value;
		this.description=description;
	}
	
	public String getValue() {
		return value;
	}
	
	public String getDescription() {
		return description;
	}
	
	public static TransactionStatus find(String value) {
		for(TransactionStatus transactionStatus : TransactionStatus.values()) {
			if(transactionStatus.getValue().equals(value)) {
				return transactionStatus;
			}
		}
		return null;
	}
}
