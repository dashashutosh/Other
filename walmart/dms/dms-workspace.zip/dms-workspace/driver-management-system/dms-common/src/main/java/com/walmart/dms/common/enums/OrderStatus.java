//package com.walmart.dms.dal.jpa.entity;
package com.walmart.dms.common.enums;

/**
 * @author g0s00pv on 5/16/18
 */
public enum OrderStatus {

    ASSIGNED, CANCELLED, DELIVERED, RETURNED, ENROUTE_TO_PICKUP, CLIENT_CANCELLED, COURIER_REQUESTED, DRIVER_CANCELLED, UNASSIGNED, COMPLETED
}
