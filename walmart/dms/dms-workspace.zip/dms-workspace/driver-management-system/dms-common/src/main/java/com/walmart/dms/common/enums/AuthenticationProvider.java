package com.walmart.dms.common.enums;

/**
 * @author n0a008p on Mar 13, 2018
 *
 */
public enum AuthenticationProvider {
	WALMART_IAM,BRINGG
}
