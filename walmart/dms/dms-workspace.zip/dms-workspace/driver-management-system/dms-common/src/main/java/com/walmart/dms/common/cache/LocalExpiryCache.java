package com.walmart.dms.common.cache;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalCause;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

import com.walmart.dms.common.utils.ThreadUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * @author n0a008p on Feb 15, 2018
 *
 */
@Slf4j
public abstract class LocalExpiryCache<Key, Value> {

	private LoadingCache<Key, Value> cache;

	public LocalExpiryCache(int cacheSize, int cacheExpiryTime, TimeUnit timeUnit) {
		super();
		cache = CacheBuilder.newBuilder().maximumSize(cacheSize).expireAfterAccess(cacheExpiryTime, timeUnit)
				.removalListener(removalListener).build(new CacheLoader<Key, Value>() {
					public Value load(Key key) {
						return null;
					}
				});
		Executors.newScheduledThreadPool(1, ThreadUtil.defaultThreadFactory(LocalExpiryCache.class.getSimpleName()))
				.scheduleAtFixedRate(cleanerTask, 0, 5, TimeUnit.SECONDS);
	}

	private RemovalListener<Key, Value> removalListener = new RemovalListener<Key, Value>() {
		@Override
		public void onRemoval(RemovalNotification<Key, Value> entry) {
			log.info(entry.getKey() + " Removed with value " + entry.getValue() + " Cause:" + entry.getCause());
			if (entry.getCause() == RemovalCause.EXPIRED)
				processExipre(entry.getKey(), entry.getValue());
		}

	};

	final Runnable cleanerTask = new Runnable() {
		public void run() {
			log.info("cleanerTask running");
			cache.cleanUp();
		}
	};

	public void put(Key key, Value value) {
		cache.put(key, value);
	}

	public Value get(Key key) throws ExecutionException {
		Value value = cache.get(key);
		return value;
	}

	public boolean contains(Key key) {
		return cache.getUnchecked(key) != null;
	}

	public void remove(Key key) {
		cache.invalidate(key);
	}

	public abstract void processExipre(Key key, Value value);

}
