package com.walmart.dms.common.enums;

public enum DriverScheduleStatus {
    AVAILABLE, NOT_AVAILABLE, INACTIVE, NOT_SET, ONLINE
}
