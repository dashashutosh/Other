package com.walmart.dms.common.exception;

public class DLQMessageException extends Exception {

    public DLQMessageException(String str) {
        super(str);
    }

    public DLQMessageException(String str, Throwable cause) {
        super(str, cause);
    }
}