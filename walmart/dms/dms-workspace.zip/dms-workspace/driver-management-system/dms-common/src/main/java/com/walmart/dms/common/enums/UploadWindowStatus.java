package com.walmart.dms.common.enums;

/**
 * Author a0s0od1
 */
public enum UploadWindowStatus {
    UPLOAD_WINDOW_OPEN, UPLOAD_WINDOW_CLOSING;
}
