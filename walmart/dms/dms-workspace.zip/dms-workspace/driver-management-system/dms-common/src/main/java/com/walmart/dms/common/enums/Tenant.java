package com.walmart.dms.common.enums;

public enum Tenant {

	US("0", "US"), CA("1", "CANADA"), SAMS_CLUB("2", "SAMS"), ASDA("5", "ASDA"), BRAZIL("6", "BRAZIL"), MEXICO("7", "MEXICO");

	private String tenantId;
	private String tenantStr;

	Tenant(String tenantType, String tenant) {
		this.tenantId = tenantType;
		this.tenantStr = tenant;
	}

	public String getTenantId() {
		return tenantId;
	}

	public static boolean contains(String tenantId) {
		for (Tenant t : Tenant.values()) {
			if (t.tenantId.equals(tenantId)) {
				return true;
			}
		}
		return false;
	}

	public static String getTenantId(String tenant) {
		for (Tenant t : Tenant.values()) {
			if (t.tenantStr.equals(tenant)) {
				return t.tenantId;
			}
		}
		return null;
	}

	public static Tenant getById(String id) {
		for (Tenant tenant : Tenant.values()) {
			if (tenant.getTenantId().equalsIgnoreCase(id)) {
				return tenant;
			}
		}
		return null;
	}
}
