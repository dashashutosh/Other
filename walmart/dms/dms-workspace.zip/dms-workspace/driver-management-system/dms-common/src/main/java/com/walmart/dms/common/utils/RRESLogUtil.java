package com.walmart.dms.common.utils;

import com.walmart.dms.common.elasticsearch.entity.DMSRequestResponseLogESEntity;
import com.walmart.dms.common.requestresponse.InternalRequestLogDTO;
import com.walmart.dms.server.common.error.Status;
import com.walmart.dms.server.common.exception.PlatformException;
import io.strati.security.common.exception.ServiceClientException;

import java.util.UUID;

/**
 * A utility class for request response ES logging related operations.
 *
 * @author a0d02yr
 */
public class RRESLogUtil {
    private RRESLogUtil() {
    }

    /**
     * Updates the request response log ES entity with given details.
     *
     * @param rrLogESEntity  the request response log ES entity
     * @param apiName        the api name
     * @param requestPayload the request payload
     * @param headerDTO      the header DTO
     * @param driverUserId   the driver user id
     * @param driverPayeeId  the driver payee id
     * @return the passed request response log ES entity
     */
    public static DMSRequestResponseLogESEntity updateRRLogESEntity(final DMSRequestResponseLogESEntity rrLogESEntity,
                                                                    final String apiName, final Object requestPayload,
                                                                    final HeaderDTO headerDTO, final String driverUserId,
                                                                    final String driverPayeeId) {
        rrLogESEntity.setApiName(apiName);
        rrLogESEntity.setRequestPayload(requestPayload);
        rrLogESEntity.setRequestHeaders(headerDTO);
        rrLogESEntity.setDriverUserId(driverUserId);
        rrLogESEntity.setDriverPayeeId(driverPayeeId);
        return rrLogESEntity;
    }
    /**
     * Updates the request response log ES entity with given details.
     *
     * @param rrLogESEntity  the request response log ES entity
     * @param apiName        the api name
     * @param requestPayload the request payload
     * @param headerDTO      the header DTO
     * @param driverUUID   the driver UUID
     * @param requestId
     * @return the passed request response log ES entity
     */
    public static DMSRequestResponseLogESEntity updateRRLogESEntity(final DMSRequestResponseLogESEntity rrLogESEntity,
                                                                    final String apiName, final Object requestPayload,
                                                                    final HeaderDTO headerDTO, final UUID driverUUID, final String requestId) {
        rrLogESEntity.setApiName(apiName);
        rrLogESEntity.setRequestPayload(requestPayload);
        rrLogESEntity.setRequestHeaders(headerDTO);
        rrLogESEntity.setDriverUUID(driverUUID);
        rrLogESEntity.setRequestId(requestId);
        return rrLogESEntity;
    }

    /**
     * Updates the request response log ES entity with given details.
     *
     * @param rrLogESEntity    the request response log ES entity
     * @param responsePayload  the response payload
     * @param responseHTTPCode the response HTTP code
     * @return the passed request response log ES entity
     */
    public static DMSRequestResponseLogESEntity updateRRLogESEntity(final DMSRequestResponseLogESEntity rrLogESEntity,
                                                                    final Object responsePayload, final String responseHTTPCode) {
        rrLogESEntity.setResponsePayload(responsePayload);
        rrLogESEntity.setResponseHTTPCode(responseHTTPCode);
        return rrLogESEntity;
    }

    /**
     * Updates the request response log ES entity with given details.
     *
     * @param rrLogESEntity    the request response log ES entity
     * @param responsePayload  the response payload
     * @param responseHTTPCode the response HTTP code
     * @return the passed request response log ES entity
     */
    public static DMSRequestResponseLogESEntity updateRRLogESEntity(final DMSRequestResponseLogESEntity rrLogESEntity,
                                                                    final Object responsePayload, final int responseHTTPCode) {
        return updateRRLogESEntity(rrLogESEntity, responsePayload, String.valueOf(responseHTTPCode));
    }

    /**
     * Updates the request response log ES entity with given details.
     *
     * @param rrLogESEntity the request response log ES entity
     * @param exception     the exception
     * @return the passed request response log ES entity
     */
    public static DMSRequestResponseLogESEntity updateRRLogESEntity(final DMSRequestResponseLogESEntity rrLogESEntity,
                                                                    final Exception exception) {
        rrLogESEntity.setResponseErrorMessage(exception.getMessage());
        rrLogESEntity.setResponseHTTPCode(String.valueOf(getResponseHTTPCode(exception)));
        return rrLogESEntity;
    }

    /**
     * Updates the internal request log DTO with given details.
     *
     * @param requestLogDTO    the internal request log DTO
     * @param responsePayload  the response payload
     * @param responseHTTPCode the response HTTP code
     * @return the passed internal request log DTO
     */
    public static InternalRequestLogDTO updateInternalRequest(final InternalRequestLogDTO requestLogDTO, final Object responsePayload,
                                                              final String responseHTTPCode) {
        requestLogDTO.setResponsePayload(responsePayload);
        requestLogDTO.setResponseHTTPCode(responseHTTPCode);
        return requestLogDTO;
    }

    /**
     * Updates the internal request log DTO with given details.
     *
     * @param requestLogDTO    the internal request log DTO
     * @param responsePayload  the response payload
     * @param responseHTTPCode the response HTTP code
     * @return the passed internal request log DTO
     */
    public static InternalRequestLogDTO updateInternalRequest(final InternalRequestLogDTO requestLogDTO, final Object responsePayload,
                                                              final int responseHTTPCode) {
        return updateInternalRequest(requestLogDTO, responsePayload, String.valueOf(responseHTTPCode));
    }

    /**
     * Updates the internal request log DTO with given details.
     *
     * @param requestLogDTO the internal request log DTO
     * @param exception     the exception
     * @return the passed internal request log DTO
     */
    public static InternalRequestLogDTO updateInternalRequest(final InternalRequestLogDTO requestLogDTO, final Exception exception) {
        requestLogDTO.setResponseErrorMessage(exception.getMessage());
        requestLogDTO.setResponseHTTPCode(String.valueOf(getResponseHTTPCode(exception)));
        return requestLogDTO;
    }

    /**
     * Builds an internal request log DTO with given details.
     *
     * @param requestName  the request name
     * @param requestedBy  the requested by service
     * @param requestedTo  the requested to service
     * @param requestCount the request count
     * @return the internal request log DTO
     */
    public static InternalRequestLogDTO buildInternalRequest(final String requestName, final String requestedBy, final String requestedTo,
                                                             final int requestCount) {
        final InternalRequestLogDTO internalRequestLogDTO = new InternalRequestLogDTO();
        internalRequestLogDTO.setRequestedBy(requestedBy);
        internalRequestLogDTO.setRequestedTo(requestedTo);
        internalRequestLogDTO.setRequestName(requestName);
        internalRequestLogDTO.setRequestCount(requestCount);
        return internalRequestLogDTO;
    }

    /**
     * Updates the internal request log DTO with given details.
     *
     * @param requestLogDTO  the internal request log DTO
     * @param requestPayload the request payload
     * @param requestHeaders the request headers
     * @return the passed internal request log DTO
     */
    public static InternalRequestLogDTO updateInternalRequest(final InternalRequestLogDTO requestLogDTO, final Object requestPayload,
                                                              final Object requestHeaders) {
        requestLogDTO.setRequestPayload(requestPayload);
        requestLogDTO.setRequestHeaders(requestHeaders);
        return requestLogDTO;
    }

    /**
     * Builds an internal request log DTO with given details.
     *
     * @param requestName    the request name
     * @param requestedBy    the requested by service
     * @param requestedTo    the requested to service
     * @param requestCount   the request count
     * @param requestPayload the request payload
     * @param requestHeaders the request headers
     * @return the internal request log DTO
     */
    public static InternalRequestLogDTO buildInternalRequest(final String requestName, final String requestedBy, final String requestedTo,
                                                             final int requestCount, final Object requestPayload, final Object requestHeaders) {
        final InternalRequestLogDTO requestLogDTO = new InternalRequestLogDTO();
        requestLogDTO.setRequestedBy(requestedBy);
        requestLogDTO.setRequestedTo(requestedTo);
        requestLogDTO.setRequestName(requestName);
        requestLogDTO.setRequestCount(requestCount);
        return updateInternalRequest(requestLogDTO, requestPayload, requestHeaders);
    }

    /**
     * Copies the given internal request log DTO and updates with given details.
     *
     * @param requestLogDTO the internal request log DTO to be copied
     * @param requestName   the request name
     * @param requestCount  the request count
     * @return the internal request log DTO
     */
    public static InternalRequestLogDTO copyInternalRequestAndUpdate(final InternalRequestLogDTO requestLogDTO, final String requestName,
                                                                     final int requestCount) {
        final InternalRequestLogDTO newRequestLogDTO = requestLogDTO.copySelf();
        newRequestLogDTO.setRequestName(requestName);
        newRequestLogDTO.setRequestCount(requestCount);
        return newRequestLogDTO;
    }

    /**
     * Gets the response HTTP code. It checks the instance of given exception, applies conditions and based on results,
     * it will return the HTTP code. If none of the conditions are matched then it will return 500 by default.
     *
     * @param exception the exception
     * @return the response HTTP code
     */
    private static int getResponseHTTPCode(final Exception exception) {
        if (exception instanceof PlatformException && 0 != ((PlatformException) exception).getHttpStatusCode()) {
            return ((PlatformException) exception).getHttpStatusCode();
        } else if (exception instanceof ServiceClientException) {
            return ((ServiceClientException) exception).getHttpStatusCode();
        } else {
            return Status.FAIL.getCode();
        }
    }
}
