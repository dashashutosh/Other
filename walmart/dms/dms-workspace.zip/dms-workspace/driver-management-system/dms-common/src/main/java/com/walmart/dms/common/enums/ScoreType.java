package com.walmart.dms.common.enums;

public enum ScoreType {

    RISK_SCORE

}
