package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Data
@Configuration(configName = "configSystemAPIConfig")
public class ConfigSystemAPIConfig {

    @Property(propertyName = "configSystem.host")
    private String host;

    @Property(propertyName = "configSystem.log.level")
    public String logLevel;

    @Property(propertyName = "configSystem.read.timeout.sec")
    public int readTimeOutInSec;

    @Property(propertyName = "configSystem.connect.timeout.sec")
    public int connectTimeOutInSec;

    @Property(propertyName = "configSystem.api.header")
    public String apiHeaders;
}