package com.walmart.dms.common.enums;

/**
 * @author n0k00qi on Nov 4, 2019
 */

public enum LoginType {

    FEDERATED("federated"),
    PASSWORD("password"),
    OTP("otp");
    private String value;

    public String getValue() {
        return value;
    }
    LoginType(String value) {
        this.value = value;
    }

}