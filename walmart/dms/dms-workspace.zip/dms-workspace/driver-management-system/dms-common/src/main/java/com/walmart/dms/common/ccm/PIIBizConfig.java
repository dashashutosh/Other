package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Configuration(configName = "piiBizConfig")
@Data
public class PIIBizConfig {
    @Property(propertyName = "dms.driver.pii.es.mismatch.job.page.size")
    public int dmsDriverPIIESMismatchJobPageSize;

    @Property(propertyName = "dms.driver.pii.back.filling.threads.allocated")
    public int dmsDriverPIIBackFillingThreadsAllocated;

    @Property(propertyName = "dms.driver.pii.es.cron.job.days.to.check")
    public int dmsDriverPIIESCronJobDaysToCheck;

}
