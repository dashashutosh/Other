package com.walmart.dms.common.error;

/**
 * String messages for different types of exception
 *
 */
public class ErrorMessageConstant {

	private ErrorMessageConstant() {

	}

	public static final String EXCEPTION_MESSAGE = "An exception has occurred : {0}";

	public static final String MAPPING_EXCEPTION_MESSAGE = "A mapping exception has occurred : {0}";

	public static final String INVALID_REQUEST = "Invalid Request either null or empty";

	public static final String HEADER_TENANTID_MISSING = "Tenanid Missing in header";

	public static final String KAFKA_EXCEPTION_MESSAGE = "Kafka exception has occurred : {0}";

}
