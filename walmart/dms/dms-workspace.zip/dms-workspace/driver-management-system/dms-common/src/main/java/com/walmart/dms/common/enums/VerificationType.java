package com.walmart.dms.common.enums;

/**
 * @author a0s0od1
 *
 */
public enum VerificationType {

    ID_ONBOARDING, ID_VERIFICATION, ON_BEGIN_TRIP_VERIFICATION, ON_END_TRIP_VERIFICATION, ON_LICENCE_EXPIRED_VERIFICATION;
}