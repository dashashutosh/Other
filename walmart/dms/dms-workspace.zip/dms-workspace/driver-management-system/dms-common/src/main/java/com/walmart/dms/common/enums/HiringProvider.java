package com.walmart.dms.common.enums;

/**
 * @author n0a008p on Mar 9, 2018
 *
 */
public enum HiringProvider {
	
	FOUNTAIN,DDI,NONE
}
