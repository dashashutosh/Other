package com.walmart.dms.common.enums;

/*
 * @author sdhaka
 *
 * Payment Account Status
 */
public enum PaymentAccountStatus {
    ACTIVE("ACTIVE"), INACTIVE("INACTIVE"),NOT_REGISTERED("NOT_REGISTERED");

    private String value;

    public String getValue() {
        return value;
    }

    PaymentAccountStatus(String value) {
        this.value = value;
    }

    public static PaymentAccountStatus find(String type) {
        for (PaymentAccountStatus paymentAccountStatus : PaymentAccountStatus.values()) {
            if (paymentAccountStatus.name().equalsIgnoreCase(type)) {
                return paymentAccountStatus;
            }
        }
        return null;
    }
}
