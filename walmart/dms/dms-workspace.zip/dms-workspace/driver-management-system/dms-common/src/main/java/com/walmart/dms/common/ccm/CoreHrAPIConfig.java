package com.walmart.dms.common.ccm;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Data
@Configuration(configName = "coreHrAPIConfig")
@SuppressFBWarnings(value="NM_CONFUSING")
public class CoreHrAPIConfig {

    @Property(propertyName = "corehr.host.url")
    private String host;

    @Property(propertyName = "corehr.log.level")
    private String logLevel;

    @Property(propertyName = "corehr.read.timeout.sec")
    private int readTimeOutInSec;

    @Property(propertyName = "corehr.connect.timeout.sec")
    private int connectTimeOutInSec;

    @Property(propertyName = "corehr.api.header")
    private String headers;

    @Property(propertyName = "corehr.api.retry.count")
    private int retryCount;

    @Property(propertyName = "corehr.api.username")
    private String username;

    @Property(propertyName = "corehr.api.password")
    private String password;
}
