package com.walmart.dms.common.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.walmart.dms.common.config.CommonConfig;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.TreeMap;

/**
 * Utility class for logging related operations.
 * // TODO: Explore the possibility of implementing a wrapper around org.slf4j.Logger class to log asynchronously in
 *
 * @author a0d02yr
 */
@Component
@Slf4j
public class LogUtil {

    static final String TRUNCATION_SUFFIX = "... [truncated]";

    @Autowired
    private CommonConfig commonConfig;

    @Autowired
    private MaskingUtils maskingUtils;

    /**
     * Gets the log payload.
     *
     * @param originalLogPayload the original payload
     * @return the log payload
     */
    public String getLogPayload(final Object originalLogPayload) {
        if (null == originalLogPayload) {
            return "";
        }
        try {
            // Use Jackson's ObjectMapper to serialize the object into JSON string
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            objectMapper.registerModule(new JavaTimeModule());
            // Convert the response object to a JSON string
            String jsonString = objectMapper.writeValueAsString(originalLogPayload);

            // Mask sensitive fields
            String maskedResponsePayload = maskingUtils.maskPiiWithJsonPath(jsonString);
            return getLogPayload(maskedResponsePayload);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize and mask response payload", e);
            return "";
        }
    }


    /**
     * Gets the log payload.
     *
     * @param originalLogPayload the original payload
     * @return the log payload
     */
    public String getLogPayload(final String originalLogPayload) {
        if (null == originalLogPayload) {
            return "";
        }

        /* Check if the log truncation is enabled */
        if (!commonConfig.isLogTruncationEnabled()) {
            return originalLogPayload;
        }

        /* Check if length of original log payload is <= max character length configured */
        if (originalLogPayload.length() <= commonConfig.getLogTruncationMaxCharLength()) {
            return originalLogPayload;
        }

        /* Truncate the original log payload to a log with max character length configured */
        return originalLogPayload.substring(0, commonConfig.getLogTruncationMaxCharLength()) + TRUNCATION_SUFFIX;
    }

    /**
     * Builds a JSON formatted log string from given parameters.
     *
     * @param logMsg the log message
     * @return a JSON formatted log string
     */
    public static String buildJsonLog(final String logMsg) {
        return buildJsonLog(logMsg, (Pair) null);
    }

    /**
     * Builds a JSON formatted log string from given parameters.
     *
     * @param logObjectsPair the log object pair
     * @return a JSON formatted log string
     */
    public static String buildJsonLog(final Pair<String, Object> logObjectsPair) {
        return buildJsonLog(null, logObjectsPair);
    }

    /**
     * Builds a JSON formatted log string from given parameters.
     *
     * @param logMsg     the log message
     * @param logObjects the log objects
     * @return a JSON formatted log string
     */
    public static String buildJsonLog(final String logMsg, final Pair<String, Object>... logObjects) {
        return JsonUtil.toJsonWithNotNullMapper(new LogDTO(logMsg, logObjects));
    }

    /**
     * Log DTO class for logging messages.
     *
     * @author a0d02yr
     */
    @Data
    static final class LogDTO {

        private String logMsg;
        private Map<String, Object> logObjects;

        /**
         * Creates and returns a new instance of this class initialized with given parameters.
         *
         * @param logMsg     the log message
         * @param logObjects the log objects
         */
        @SafeVarargs
        private LogDTO(final String logMsg, final Pair<String, Object>... logObjects) {
            this.logMsg = logMsg;

            if (Objects.isNull(logObjects) || (0 == logObjects.length)) {
                this.logObjects = Collections.emptyMap();
            } else {
                this.logObjects = new TreeMap<>(String::compareTo);
                for (final Pair<String, Object> pair : logObjects) {
                    if (null == pair) {
                        continue;
                    }
                    this.logObjects.put(pair.getFirstElement(), pair.getSecondElement());
                }
            }
        }

        @Override
        public String toString() {
            return new StringJoiner(", ", LogDTO.class.getSimpleName() + "[", "]")
                    .add("logMsg='" + logMsg + "'")
                    .add("logObjects=" + logObjects)
                    .toString();
        }
    }
}
