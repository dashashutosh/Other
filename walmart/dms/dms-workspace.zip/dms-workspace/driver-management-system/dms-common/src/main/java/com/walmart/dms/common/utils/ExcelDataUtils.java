package com.walmart.dms.common.utils;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

@Component
public class ExcelDataUtils {

    public CellStyle createCommonHeaderStyle(XSSFWorkbook workBook) {

        if (workBook == null){
            return null;
        }
        // Create common header style
        CellStyle headerStyle = workBook.createCellStyle();
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        XSSFFont font = workBook.createFont();
        font.setBold(true);
        font.setFontHeight((short)(11.5 * 20));
        headerStyle.setFont(font);
        return headerStyle;
    }
}
