package com.walmart.dms.common.enums;

public enum Vertical {
	/**
	 * 
	 */
	GM("0", "GM", "GENERAL MERCHANDISE"),
	/**
	 * 
	 */
	PHARMACY("1", "pharmacy", "PHARMACY"),
	/**
	 * 
	 */
	GROCERIES("2", "groceries", "GROCERIES"),
	/**
	 * 
	 */
	TIRES("3", "tires", "TIRES"),
	/**
	 * 
	 */
	PHOTOS("4", "photos", "PHOTO"),
	/**
	 * 
	 */
	DIRECT("5", "Direct", "Direct"),
	/**
	 * 
	 */
	GEORGE("6", "George", "George"),
	/**
	 * 
	 */
	ONE_HOUR_GUARANTEE("8", "1HG", "1-Hour Guarantee"),
	/**
	 * 
	 */
	BUY_IT_NOW("9", "Buy It Now", "Buy It Now"),
	/**
	 * 
	 */
	WMTPAY("10", "Walmart Pay", "Walmart Pay"),
	/**
	 * 
	 */
	EM("11", "EM", "E DELIVERY MERCHANDISE"),
	/**
	 * 
	 */
	SCAN_N_GO("12", "SCAN_N_GO", "Scan And Go");

	private final String verticalId;
	private final String verticalName;
	private final String description;

	/**
	 * 
	 * This is the constructor to initialize Vertical information.
	 * 
	 */
	Vertical(final String verticalId, final String verticalName, final String description) {
		this.verticalId = verticalId;
		this.verticalName = verticalName;
		this.description = description;
	}

	/**
	 * 
	 * Get the verticalId for a particular vertical. If you want to get
	 * verticalId for GENERAL MERCHANDISE then use Vertical.GM.getVerticalId();
	 * 
	 * @return Integer verticalId
	 * 
	 */
	public String getVerticalId() {
		return verticalId;
	}

	/**
	 * 
	 * Get the verticalName for a particular vertical. If you want to get
	 * verticalName for GENERAL MERCHANDISE then use
	 * Vertical.GM.getVerticalName();
	 * 
	 * @return String verticalName
	 * 
	 */
	public String getVerticalName() {
		return verticalName;
	}

	/**
	 * 
	 * Get the vertical description for a particular vertical. If you want to
	 * get verticalDescription for GENERAL MERCHANDISE then use
	 * Vertical.GM.getDescription();
	 * 
	 * @return String description
	 * 
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * 
	 */
	public static boolean contains(String verticalId) {
		for (Vertical v : Vertical.values()) {
			if (v.verticalId.equals(verticalId)) {
				return true;
			}
		}
		return false;
	}

	public static Vertical getById(String id) {
		for (Vertical vertical : Vertical.values()) {
			if (vertical.getVerticalId().equalsIgnoreCase(id)) {
				return vertical;
			}
		}
		return null;
	}
}
