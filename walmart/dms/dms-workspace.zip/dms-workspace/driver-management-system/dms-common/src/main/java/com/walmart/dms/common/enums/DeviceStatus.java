package com.walmart.dms.common.enums;

/**
 * Created by s0v035d on 11/09/23.
 */
public enum DeviceStatus {
    BLOCKED, UNBLOCKED
}
