package com.walmart.dms.common.enums;

public enum DriverSuggestionMode {
	MANUAL_ASSIGNMENT,AUTO_DISPATCH,UNKNOWN;

	public static DriverSuggestionMode findDriverSuggestionModeValue(final String driverSuggestionMode) {

		for (DriverSuggestionMode driverSuggestionModeType : DriverSuggestionMode.values()) {
			if (driverSuggestionModeType.name().equals(driverSuggestionMode)) {
				DriverSuggestionMode driverSuggestionModeValue = DriverSuggestionMode.valueOf(driverSuggestionMode);
				return driverSuggestionModeValue;
			}
		}
		return DriverSuggestionMode.UNKNOWN;
	}

}
