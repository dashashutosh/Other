package com.walmart.dms.common.enums;

/*
 * @author n0k008c
 *
 * Payment Driver Contract Type
 */
public enum DriverContractType {

    FREELANCER("freelancer"),
    ASSOCIATE("associate"),
    CONTRACTED_FLEET("contractedFleet");

    private String value;

    public String getValue() {
        return value;
    }

    DriverContractType(String value) {
        this.value = value;
    }

    public static DriverContractType find(String type) {
        for (DriverContractType contractType : DriverContractType.values()) {
            if (contractType.name().equalsIgnoreCase(type)) {
                return contractType;
            }
        }
        return null;
    }

}
