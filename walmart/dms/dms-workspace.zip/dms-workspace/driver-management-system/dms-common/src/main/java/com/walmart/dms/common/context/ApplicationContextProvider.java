package com.walmart.dms.common.context;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

/**
 * Created by n0a008p on 08/03/18.
 */
@Component
public class ApplicationContextProvider implements ApplicationContextAware {

	private ApplicationContext applicationContext;

	@SuppressFBWarnings(value="ST_WRITE_TO_STATIC_FROM_INSTANCE_METHOD")
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		applicationContext = context;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}
}
