package com.walmart.dms.common.enums;

public enum OrgType {
    SORTATION, FLEET, NTRANSIT, DEDICATED_DELIVERY
}
