package com.walmart.dms.common.enums;

public enum ScoreCategory {

    GREEN, YELLOW, AMBER, RED

}
