package com.walmart.dms.common.enums;

/*
 * 
 * @author n0k008c
 * 
 */
public enum TransactionType {

    GUARNTEED_PAYMENT("1"), BONUS_PAYMENT("2"), MISSING_ORDER_PAYMENT("3"), POST_DELIVERY_PAYMENT("4"),
    ORDER_PAYMENT("5"), BLOCK_PAYMENT("6"), TIP_PAYMENT("7");

    private String transactionTypeId;

    TransactionType(String transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
    }

    public String getTransactionTypeId() {
        return transactionTypeId;
    }

    public static boolean contains(String transactionTypeId) {
        for (TransactionType t : TransactionType.values()) {
            if (t.transactionTypeId.equals(transactionTypeId)) {
                return true;
            }
        }
        return false;
    }

    public static TransactionType getById(String id) {
        for (TransactionType t : TransactionType.values()) {
            if (t.getTransactionTypeId().equalsIgnoreCase(id)) {
                return t;
            }
        }
        return null;
    }

}
