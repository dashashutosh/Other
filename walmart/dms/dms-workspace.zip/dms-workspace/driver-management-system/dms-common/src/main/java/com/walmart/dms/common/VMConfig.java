package com.walmart.dms.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.walmart.dms.common.enums.Tenant;
import io.strati.libs.commons.lang.StringUtils;

public class VMConfig {
    private VMConfig() {
    }

    private static String runOnEnv = System.getProperty("com.walmart.platform.config.runOnEnv");
    private static List<String> tenantIdList = new ArrayList<>();

//    public static boolean isPiiCronEnabled(){
//        return System.getProperty("com.walmart.platform.config.is.pii.cron.enabled").equalsIgnoreCase("true");
//    }

    public static boolean isNonPiiCronAndKafkaConsumersEnabled(){
        return System.getProperty("com.walmart.platform.config.is.non.pii.cron.and.kafka.enabled").equalsIgnoreCase("true");
    }

    static {
        if (!StringUtils.isEmpty(System.getProperty("runtime.context.dms.tenants"))) {
            tenantIdList = Arrays.asList(System.getProperty("runtime.context.dms.tenants").split(","));
        }else {
            tenantIdList = Arrays.asList(Tenant.US.getTenantId());
        }
        
        tenantIdList=Collections.unmodifiableList(tenantIdList);
        
    }

    // get First TenantId or 0(US) for default
    public static String getTenantId() {
        return tenantIdList.get(0);
    }

    // get all tenantIds specified in VM Arguments
    public static List<String> getSpecifiedTenantIds() {
        return tenantIdList;
    }

    /*
     * check if the input tenantId matches with any of the TenantIds maintained in
     * VMArguments
     */
    public static boolean checkIfTenantIdMatch(String id) {
        if (StringUtils.isEmpty(id)) {
            return false;
        }

        for (String tId : tenantIdList) {
            if (tId.equals(id)) {
                return true;
            }
        }
        return false;
    }

    public static String getRunOnEnv() {
        if (runOnEnv == null) {
            runOnEnv = "local"; // default value
        }
        return runOnEnv;
    }
}