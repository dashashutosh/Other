package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Configuration(configName = "inHomeExecutorThreadPoolConfig")
@Data
public class InHomeExecutorThreadPoolConfig {

    @Property(propertyName = "inhome.scheduler.thread.pool.tpThreadCount")
    private int tpThreadCount;

    @Property(propertyName = "inhome.scheduler.thread.pool.tpQueueSize")
    private int tpQueueSize;

    @Property(propertyName = "inhome.scheduler.thread.pool.tpNamePrefix")
    private String tpNamePrefix;

    @Property(propertyName = "inhome.scheduler.job.batch.size")
    private int batchSize;
}
