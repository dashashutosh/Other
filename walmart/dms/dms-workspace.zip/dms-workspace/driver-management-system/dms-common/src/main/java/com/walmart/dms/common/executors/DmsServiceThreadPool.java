package com.walmart.dms.common.executors;

import java.util.concurrent.Executor;

public interface DmsServiceThreadPool {
    Executor getThreadPool();
}
