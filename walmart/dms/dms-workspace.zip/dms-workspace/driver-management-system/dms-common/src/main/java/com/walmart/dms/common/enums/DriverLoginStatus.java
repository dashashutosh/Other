package com.walmart.dms.common.enums;

public enum DriverLoginStatus {
    NONE, CHANGE_PASSWORD
}
