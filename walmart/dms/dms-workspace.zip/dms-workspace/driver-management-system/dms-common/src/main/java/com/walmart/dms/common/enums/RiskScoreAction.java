package com.walmart.dms.common.enums;

public enum RiskScoreAction {
    NO_ACTION,
    DEACTIVATE_ACTION,
    SUSPEND_ACTION
}
