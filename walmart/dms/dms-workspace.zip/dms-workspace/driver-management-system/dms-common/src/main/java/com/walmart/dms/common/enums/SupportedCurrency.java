package com.walmart.dms.common.enums;

public enum SupportedCurrency {
	USD;
}
