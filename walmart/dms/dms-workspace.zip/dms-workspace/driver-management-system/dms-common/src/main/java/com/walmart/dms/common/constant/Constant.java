package com.walmart.dms.common.constant;


import com.walmart.dms.common.enums.DriverProgram;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

/**
 * @author n0a008p on Feb 15, 2018
 */
public class Constant {
    private Constant () {

    }
    public static final DriverProgram DEFAULT_DRIVER_PROGRAM = DriverProgram.SWIFT;

    public static final String TENANT_ID_HEADER_KEY = "WM_CONSUMER.TENANT_ID";
    public static final String VERTICAL_ID_HEADER_KEY = "WM_CONSUMER.VERTICAL_ID";
    public static final String CLIENT = "CLIENT";
    public static final String TIMEZONE_HEADER_KEY = "x-timeZone";
    public static final String TENANT_SYS_PROPERTY = "tenantId";
    public static final String COMMA_SEPARATOR = ",";

    public static final String DEFAULT_PASSWORD_MEXICO = "Walmart1";


    public static final String APP_NAME = System.getProperty("runtime.context.appName");

    public static final int STACK_TRACE_MAX_CHARS = 3000;
    public static final int ERROR_MESSAGE_MAX_CHARS = 255;
    public static final int ERROR_PAYLOAD_MAX_CHARS = 10000;
    public static final String ERROR_RETRY_TRIGGER_NAME = "ERROR_RETRY_TRIGGER_NAME";
    public static final String ERROR_RETRY_TRIGGER_GRP = "ERROR_RETRY_TRIGGER_GRP";
    public static final String ERROR_RETRY_JOB_NAME = "ERROR_RETRY_JOB_NAME";
    public static final String ERROR_RETRY_JOB_GRP = "ERROR_RETRY_JOB_GRP";
    public static final String ALL = "ALL";
    public static final String ARGUS_FILTER_REQUEST = "ARGUS_FILTER_REQUEST";
    public static final String ARGUS_TOTAL_REQUEST = "ARGUS_TOTAL_REQUEST";
    public static final String ARGUS_REQUEST_MARKED_INVALID = "ARGUS_REQUEST_MARKED_INVALID";
    public static final String ARGUS_API_COUNT = "ARGUS_API_COUNT";
    public static final String ARGUS_REQUEST_MARKED_VALID = "ARGUS_REQUEST_MARKED_VALID";
    public static final String ARGUS_NULL_RESPONSE = "ARGUS_NULL_RESPONSE";

    public static final String ARGUS_VALID_RESPONSE = "ARGUS_VALID_RESPONSE";

    public static final String ARGUS_INVALID_RESPONSE = "ARGUS_INVALID_RESPONSE";
    public static final String INSTALLED_APP ="installed_app";
    public static final String REQUEST_URI ="REQUEST_URI";
    public static final String ERROR = "ERROR_DETAILS";
    public static final String DRIVER_COMPANY_UNKNOWN = "UNKNOWN";
    public static final String DRIVER_COMPANY_DDI = "DDI";
    public static final String DRIVER_COMPANY_WALMART = "WALMART";

    public static final String DMS_EVENT_PRODUCER_NAME = "DMS";
    public static final String DMS_REPORTING_EVENT_DRIVER_FEEDBACK = "DRIVER_FEEDBACK";
    public static final String DMS_REPORTING_EVENT_DRIVER_ORDER_PAYMENT = "DRIVER_PAYMENT";
    public static final String DMS_REPORTING_EVENT_DRIVER_TIP_PAYMENT = "DRIVER_TIP_PAYMENT";

    public static final String DRIVER_ZONE_MIGRATION_EVENT = "DRIVER_ZONE_MIGRATION_EVENT";
    public static final String DRIVER_ZONE_MIGRATION_EVENT_FAILURE = "DRIVER_ZONE_MIGRATION_EVENT_FAILURE";
    public static final String DRIVER_OFFER_DETAIL_EVENT_NAME = "DRIVER_OFFER_DETAIL_EVENT";
    public static final String DRIVER_OFFER_KAFKA_PUSH_ERROR = "DRIVER_OFFER_KAFKA_PUSH_ERROR";

    public static final String TENANT_ID = "tenantId";
    public static final String VERTICAL_ID = "verticalId";
    public static final String ORDER_ID = "orderId";
    public static final String WM_VERTICAL_ID = "WM_VERTICAL_ID";
    public static final String X_TENANT_ID = "x-tenantId";
    public static final String WM_TENANT_ID = "WM_TENANT_ID";
    public static final String TIMESTAMP = "timestamp";
    public static final String EVENT_NAME = "eventName";
    public static final String PRODUCER_NAME = "producerName";


    public static final String DMS_REPORTING_DRIVER_PAYMENT_TRANSACTION_EVENT = "DMS_DRIVER_PAYMENT_TRANSACTION_EVENT";
    public static final String DMS_REPORTING_DRIVER_PAYMENT_TRIP_EVENT = "DMS_DRIVER_PAYMENT_TRIP_EVENT";
    public static final String DMS_REPORTING_DRIVER_STORE_RATE_CARD_EVENT = "DMS_DRIVER_STORE_RATE_CARD_EVENT";
    public static final String DMS_REPORTING_EVENT_REASON_CODE_CONFIG = "DMS_REASON_CODE_CONFIG_EVENT";

    public static final String EMAIL_ID ="emailId";
    public static final String GSCOPE = "GSCOPE";
    public static final String JSON_CONTENT_TYPE_HEADER = HttpHeaders.CONTENT_TYPE + ": "
            + MediaType.APPLICATION_JSON_VALUE;
    public static final String JSON_ACCEPT_HEADER = HttpHeaders.ACCEPT + ": " + MediaType.APPLICATION_JSON_VALUE;
    public static final String NO_CACHE_CONTROL_HEADER = HttpHeaders.CACHE_CONTROL + ": no-cache";
    public static final String GSCOPE_REFERER_HEADER = HttpHeaders.REFERER + ": https://gscope.walmartlabs.com";

    public static final String COUNTRY_CODE_HEADER_KEY = "countryCode";
    public static final String COUNTRY_CODE_ERROR = "Invalid Header: countryCode is mandatory";
    public static final String VERTICAL_TENANT_ERROR = "Invalid Header: TenantId and VerticalId in mandatory";
    public static final String INVALID_COUNTRY_CODE = "Invalid country code in header";
    public static final String INVALID_DRIVER_USER_ID = "Invalid Driver User Id";
    public static final String CLIENT_ID_HEADER_KEY = "CLIENT_ID" ;

    public static final String FEATURE_ENABLED_FOR_ALL_MARKETS = "ALL_MARKETS";
    public static final String FEATURE_ENABLED_FOR_ALL_STORES = "ALL_STORES";

    public static final String DELIVERY_STATUS = "deliveryStatus";
    public static final String TASK_CANCELLED = "TASK_CANCELLED";
    public static final int SLOT_END_TIME_DELTA = 1;

    public static final String STORE_ZONE_MIGRATION_EVENT = "STORE_ZONE_MIGRATION_EVENT";

    public static final String CORRELATION_ID_HEADER_KEY = "WM_QOS.CORRELATION_ID";
    public static final String CREATE_DRIVER = "CREATE_DRIVER";
    public static final String SEPARATOR = "-";
    public static final String VERIFICATION_TYPE = "verificationType";
    public static final String IAM_ACCOUNT_CREATION = "IAM_ACCOUNT_CREATION";
    public static final String DRIVER_PAY = "DRIVER_PAY";
    public static final String DRIVER_ID_VERIFICATION_ONBOARDING = "DRIVER_ID_VERIFICATION_ONBOARDING";
    public static final String DRIVER_ID_VERIFICATION_STATUS = "DRIVER_ID_VERIFICATION_STATUS";
    public static final String DRIVER_ID_REVERIFICATION = "DRIVER_ID_REVERIFICATION";

    public static final String DEFAULT_MULTICAST_TYPE_STR = "ALL";

    public static final String DMS_SERVICE = "DMS_SERVICE";
    public static final String SHARED_ACCOUNT_DEACTIVATE_REASON_CODE = "DMS104";
    public static final String DMS_DB = "DMS_DB";
    public static final String IAM_SERVICE = "IAM_SERVICE";

    public static final String DMS_DB_UPDATE_DRIVER = "DMS_DB_UPDATE_DRIVER";
    public static final String UPDATE_DRIVER_WEBHOOK_API_NAME = "UPDATE_DRIVER_WEBHOOK";
    public static final String UPDATE_DRIVER_ADDRESS_WEBHOOK_API_NAME = "UPDATE_DRIVER_ADDRESS_WEBHOOK";
    public static final String UPDATE_DRIVER_INTERNAL_API_NAME = "UPDATE_DRIVER_INTERNAL";
    public static final String IAM_ACCOUNT_UPDATE_EMAIL_ID_AND_LOGIN_ID = "IAM_ACCOUNT_UPDATE_EMAIL_ID_AND_LOGIN_ID";
    public static final String IAM_ACCOUNT_REVERT_LOGIN_ID = "IAM_ACCOUNT_REVERT_LOGIN_ID";
    public static final String IAM_ACCOUNT_REVERT_EMAIL_ID_AND_LOGIN_ID = "IAM_ACCOUNT_REVERT_EMAIL_ID_AND_LOGIN_ID";
    public static final String UPDATE_DRIVER_ID_VERIFICATION_STATUS_WEBHOOK = "UPDATE_DRIVER_ID_VERIFICATION_STATUS_WEBHOOK";
    public static final String UPDATE_DRIVER_ID_VERIFICATION_STATUS_DB = "UPDATE_DRIVER_ID_VERIFICATION_STATUS_DB";
    public static final String DRIVER_ID_VERIFICATION_STATUS_UPDATE = "DRIVER_ID_VERIFICATION_STATUS_UPDATE";
    public static final String UPDATE_DRIVER_ID_VERIFICATION_STATUS_WEBHOOK_V2 = "UPDATE_DRIVER_ID_VERIFICATION_STATUS_WEBHOOK_V2";

    public static final String DRIVER_REFERRAL_JOINED_EVENT = "DRIVER_REFERRAL_JOINED";
    public static final int DRIVER_REFERRAL_POSTFIX_LENGTH = 6;

    public static final String TIME_0_FROM = "t_0_from"; // slot start time e.g. 10:00am
    public static final String TIME_0_TO = "t_0_to"; // slot end time e.g. 11:00am
    public static final String TIME_60_FROM = "t_60_from"; // 60 min before slot start time e.g. 09:00am
    public static final String TIME_60_TO = "t_60_to"; // slot start time e.g. 10:00am
    public static final String TIME_120_FROM = "t_120_from"; // 120 min before slot start time e.g. 08:00am
    public static final String TIME_120_TO = "t_120_to"; // 60 min before slot start time e.g. 09:00am
    public static final String DAILY_FROM = "daily_from"; // prediction day 00:00
    public static final String DAILY_TO = "daily_to"; // prediction day + 1, 00:00
    public static final String TIME_0 = "t_0";
    public static final String TIME_60 = "t_60";
    public static final String TIME_120 = "t_120";
    public static final String DAILY = "daily";

    public static final String PUBLISHED = "PUBLISHED";
    public static final String ACCEPTED = "ACCEPTED";
    public static final String EXPIRED = "EXPIRED";
    public static final String REJECTED = "REJECTED";
    public static final String DROPPED = "DROPPED";
    public static final String ROUND_ROBIN = "ROUND_ROBIN";
    public static final String BROADCAST = "BROADCAST";
    public static final String BROADCAST_WITH_SURGE = "BROADCAST_WITH_SURGE";

    public static final String USER_ID = "userId";
    public static final String EMAIL = "email";
    public static final String ACTIVE = "active";
    public static final String ONLINE = "online";
    public static final String END_TIME = "onlineEndTimeEpoch";
    public static final String BATCHING_PREFERENCE = "batchingPreference";

    public static final String DRIVER_ID = "driverId";
    public static final String DRIVER = "driver";
    public static final String STORE_ID = "storeId";
    public static final String STORE = "store";
    public static final String OFFERS = "offers";
    public static final String TRIP_START_TIME_EPOCH = "tripStartTimeEpoch";
    public static final String OFFER_TYPE_AGGREGATION = "offerTypeAggregation";
    public static final String OFFER_TYPE = "offerType";
    public static final String OFFER_STATUS_AGGREGATION = "offerStatusAggregation";
    public static final String OFFER_STATUS = "offerStatus";
    public static final String MARKET_NAME = "marketName";
    public static final String BLOCKED_STORES = "blockedStores";
    public static final String CONFIGURATION = "Configuration";
    public static final double DEFAULT_DRIVER_RATING = 4.75;
    public static final String SKILL_TYPE = "skillType";
    public static final String DRIVER_UUID = "driverUUID";
    public static final String DRIVER_USER_ID = "driverUserId";
    public static final String DRIVER_TYPE = "driverType";
    public static final String REQUEST_ID = "requestId";

    public static final String DMS_REPORTING_LEGAL_DOCUMENT_STATUS = "DRIVER_LEGAL_DOC_STATUS";
    public static final String DMS_DRIVER_HC_INSURANCE_UPLOADED_EVENT = "DRIVER_HC_INSURANCE_UPLOADED";
    public static final String DMS_DRIVER_HC_INSURANCE_VALIDATED_EVENT = "DRIVER_HC_INSURANCE_VALIDATED";
    public static final String DMS_DRIVER_VERIFICATION_STATUS_EVENT = "DRIVER_VERIFICATION_STATUS";
    public static final String EVENT_HEADER = "Event Header";
    public static final String EVENT_MESSAGE = "Event Message";
    public static final String NOTIFICATION_PATH = "PUSH";
    public static final String RESPONSE = "response";
    public static final String NOTIFICATION_DEEP_LINK = "DEEP_LINK";
    public static final String HEALTH_CARE_SUBSIDY = "HealthCare Subsidy";
    public static final String SNP_PRIORITY = "TRANSACTIONAL";
    public static final String SNP_NOTIFICATION_REQUEST = "SNP notification request";
    public static final String SNP_NOTIFICATION_RESPONSE = "SNP notification response";

    public static final String REQUEST_PAYLOAD = "requestPayload";
    public static final String RESPONSE_PAYLOAD = "responsePayload";

    public static final String REALM_ID_HEADER_KEY = "x-realmId";
    public static final String LOGIN_ID_HEADER_KEY = "x-loginId" ;
    public static final String DUMMY_LOGIN_ID = "${X-loginId}" ;
    public static final String DUMMY_REALM_ID = "${X-realmId}";
    public static final String DUMMY_DEVICE_PROFILE_REF_ID = "${DEVICE_PROFILE_REF_ID}";

    public static final String INVALID_RESPONSE_FROM_VENDOR = "Either Record not found OR Invalid payload response from Vendor";
    public static final String INACTIVE_STUCK_DRIVER = "The Driver is inactive, thus marking the inquiry as expired";
    public static final String EMPTY_RESPONSE_FROM_VENDOR = "Empty response from Vendor";
    public static final String VERIFICATION_STILL_IN_CREATED_STAGE = "Verification of this driver was still in CREATED or SUBMITTED stage";
    public static final String DMS_DRIVER_LOGIN_EVENT = "DRIVER_LOGIN_DETAILS";
    public static final String DMS_DRIVER_LOGOUT_EVENT = "DRIVER_LOGOUT_DETAILS";
    public static final String DMS_DRIVER_RESET_PASSWORD_EVENT = "DRIVER_PASSWORD_RESET";

    public static final String DEVICE_MODEL = "DEVICE_MODEL";
    public static final String DEVICE_OS = "DEVICE_OS";
    public static final String DEVICE_OS_VERSION = "DEVICE_OS_VERSION";
    public static final String DEVICE_ID = "WM_DEVICE_ID";
    public static final String INSTALLED_APP_VERSION="INSTALLED_APP_VERSION";
    public static final String DEVICE_IP_ADDRESS="DEVICE_IP_ADDRESS";
    public static final String DEVICE_LOCALE="DEVICE_LOCALE";
    public static final String DEVICE_LATITUDE="DEVICE_LATITUDE";
    public static final String DEVICE_LONGITUDE="DEVICE_LONGITUDE";
    public static final String DEVICE_LAT_LONG_RANGE="DEVICE_LAT_LONG_RANGE";


    public static final String DEVICE_PROFILE_REF_ID="DEVICE_PROFILE_REF_ID";

    public static final String WM_LOCALE_ID="WM_LOCALE_ID";
    public static final String WM_DRIVER_UUID = "WM_DRIVER_UUID";
    public static final String WM_CONSUMER_IP = "WM_CONSUMER.IP";
    public static final String WM_COUNTRY = "WM_COUNTRY";
    public static final String USER_AGENT = "User-Agent";

    public static final String DUMMY_MARKET = "DUMMY_MARKET";
    public static final String DUMMY_DEVICE_ID = "${WM_DEVICE_ID}";
    public static final String DUMMY_DEVICE_MODEL = "${DEVICE_MODEL}";
    public static final String DUMMY_DEVICE_OS = "${DEVICE_OS}";
    public static final String DUMMY_DEVICE_OS_VERSION = "${DEVICE_OS_VERSION}";

    public static final int FUN_FACT_CHAR_LIMIT = 255;

    public static final String CONTRACT_TYPE_NTRANSIT = "NTRANSIT";
    public static final String DRIVER_ACCESS_SUFFIX = "1234";
    public static final String DRIVER_ACCESS_TEMP = "Walmart1234";

    public static final String EXCEPTION_MESSAGE = "Exception Message";
    public static final String SUCCESS_EVENT = "SUCCESS";

    public static final String NOTIFICATION = "NOTIFICATION";
    public static final String HEALTHCARE_API_TAG ="HEALTHCARE_API";
    public static final String ID_VERIFICATION_API_TAG ="ID_VERIFICATION_API";
    public static final String CATEGORY = "Persona";
    public static final String SAFETY_INCIDENT_USER_NAME = "dms-service";
    public static final String SAFETY_INCIDENT_CUSTOMER_TYPE = "Driver";
    public static final String SAFETY_INCIDENT_TENANT = "WALMART_US";
    public static final String SAFETY_INCIDENT_CONTEXT = "GM";
    public static final String SAFETY_INCIDENT_SOURCE = "DISPATCHER";
    public static final String SAFETY_INCIDENT_CHANNEL = "WEB";
    public static final String SAFETY_INCIDENT_LANGUAGE = "ENGLISH";
    public static final String SAFETY_INCIDENT_TYPE = "NON_CRITICAL_NON_CLAIM";
    public static final String SAFETY_INCIDENT_CLIENT_ID = "all";
    public static final String SAFETY_INCIDENT_REPROTED_BY = "dms-service";
    public static final String SAFETY_INCIDENT_REPROTED_SYSTEM = "dms-service";
    public static final String COUNT = "COUNT";
    public static final String SAFETY_INCIDENT_RESOLVED_STATUS = "RESOLVED";
    public static final String ADD_DOCUMENT_STATUS = "AddDocumentStatus";
    public static final String ADD_DOCUMENT_STATUS_V1 = "AddDocumentStatusV1";
    public static final String REQUEST_HEADER_CONSUMER_ID = "WM_CONSUMER.ID";
    public static final String DRIVER_UPDATE_STATUS_ENTITY = "DriverUpdateStatusEntity";
    public static final String REQUEST_HEADER_CONSUMER_IP_ADDRESS = "WM_CONSUMER.IP";
    public static final String REQUEST_HEADER_CONSUMER_SOURCE = "WM_CONSUMER.SOURCE";
    public static final String DMS_DRIVER_UPDATE_REQUEST_STATUS = "DRIVER_UPDATE_REQUEST_STATUS";

    public static final String DRIVER_LICENSE_SNP_NOTIFICATION_TITLE = "Spark Driver";
    public static final String DRIVING_LICENSE_SNP_API_TAG = "ON_LICENCE_EXPIRED_VERIFICATION";


    public static final String DMS = "DMS";
    public static final String VENDOR_NAME = "Walmart";
    public static final String EVENT_TYPE = "EventType";
    public static final String LOGIN = "LOGIN";
    public static final String LOG_OUT = "LOG_OUT";
    public static final String RESET_PASSWORD_USING_CODE = "RESET_PASSWORD_USING_CODE";
    public static final String CHANGE_LOGIN_PASSWORD = "CHANGE_LOGIN_PASSWORD";
    public static final String INVALIDATE_MULTIPLE_SESSION = "INVALIDATE_MULTIPLE_SESSION";
    public static final String GENERATE_LOGIN_OTP = "GENERATE_LOGIN_OTP";
    public static final String VALIDATE_LOGIN_OTP = "VALIDATE_LOGIN_OTP";
    public static final String GENERATE_RESET_OTP = "GENERATE_RESET_OTP";
    public static final String GENERATE_NEW_PASSWORD = "GENERATE_NEW_PASSWORD";
    public static final String UPDATE_DRIVER = "UPDATE_DRIVER";
    public static final String UPDATE_DRIVER_ADDRESS = "UPDATE_DRIVER_ADDRESS";
    public static final String ADD_STORE = "ADD_STORE";
    public static final String GET_STORE = "GET_STORE";
    public static final String NEW_STORE_ONBOARDING = "NEW_STORE_ONBOARDING";
    public static final String GET_STORES_IN_AREA_BY_STORE_ID = "GET_STORES_IN_AREA_BY_STORE_ID";
    public static final String UPDATE_ID_VERIFICATION_STATUS = "UPDATE_ID_VERIFICATION_STATUS";
    public static final String UPDATE_DRIVER_ID_VERIFICATION_STATUS_V2 = "UPDATE_DRIVER_ID_VERIFICATION_STATUS_V2";
    public static final String PROCESS_EVENT = "PROCESS_EVENT";
    public static final String SAVE_BOOSTER_OFFER_SCHEDULE = "SAVE_BOOSTER_OFFER_SCHEDULE";
    public static final String GET_BOOSTER_OFFER_SCHEDULE = "GET_BOOSTER_OFFER_SCHEDULE";
    public static final String GET_BOOSTER_OFFER_SCHEDULE_AUDIT = "GET_BOOSTER_OFFER_SCHEDULE_AUDIT";
    public static final String SPARK_DRIVER = "Spark Driver";
    public static final String DMS_ON_TRIP_VERIFICATION ="DMS_ON_TRIP_VERIFICATION";
    public static final String ON_TRIP_EXPIRATION_REASON_CODE = "DMS9003";
    public static final String DRIVER_EXISTS_WITH_SAME_SCAC_CODE = "Driver already exists with scac code";
    public static final String DRIVER_EXISTS_IN_INACTIVE_STATE = "Driver exists in Inactive State";
    public static final String CARRIER_ALREADY_EXISTS_WITH_SCAC_CODE = "Carrier already exists with scac code";
    public static final String SCAC_CODE_IS_EMPTY_OR_NULL = "scacCode is empty/null";
    public static final String REFRESH_TOKEN = "REFRESH_TOKEN";
    public static final String DRIVER_DEACTIVATION_ID_VERIFICATION = "1046";
    public static final String DRIVER_DEACTIVATION_GRAPH_TAG = "3006";
    public static final String DRIVER_DEACTIVATION_ID_ONBOARDING = "1045";
    public static final String IDENTITY_CHECK_FAILURE_INITIAL = "Identity check failure (Initial verification)";
    public static final String IDENTITY_CHECK_FAILURE_RE_VERIFICATION = "Identity check failure (Re-verification)";
    public static final String IDENTITY_CHECK_FAILURE_ON_TRIP_VERIFICATION = "Identity check failure (On-trip verification)";

    public static final String HOME_OFFICE = "homeoffice";
    public static final String DRIVER_PAYMENT = "400.007";
    public static final String CREATED_TIME = "createdTime";
    public static final String PROGRAM_NOT_FOUND = "Program not found";
    public static final String  PROGRAM_NOT_FOUND_FOR_PROGRAM = "Program not found for program:{}, header:{}";
    public static final String END = "--> END ";
    public static final String BYTE_BODY = "-byte body)";
    public static final String YEAR_MONTH_DATE= "yyyy-MM-dd";
    public static final String DMS_DDI_SERVICE = "dms_DDIService";
    public static final String DISPATCHER_IS_NOT_REACHABLE = "Dispatcher is not reachable";
    public static final String AND_PROGRAM = "and program : ";
    public static final String ID = ", id: ";
    public static final String SUCCESS = "SUCCESS";
    public static final String PKCS = "PKCS#8";
    public static final String DRIVER_ONBOARDING_API_IMPL = "DriverOnboardingAPIImpl";
    public static final String DRIVER_ONBOARDING_API_IMPL_CREATE_DRIVER = "DriverOnboardingAPIImpl_createDriver";
    public static final String DRIVER_ONBOARDING_API_IMPL_GET_REFERRAL_DETAILS_BY_DRIVER_ID = "DriverOnboardingAPIImpl_getReferralDetailsByDriverId";
    public static final String DRIVER_ONBOARDING_API_IMPL_UPDATE_DRIVER_REFERRER_ID = "DriverOnboardingAPIImpl_updateDriverReferrerId";
    public static final String ONBOARDING_WEBHOOK_API_IMPL_CREATE_DRIVER = "OnboardingWebhookAPIImpl_createDriver";
    public static final String ONBOARDING_WEBHOOK_API_IMPL = "OnboardingWebhookAPIImpl";
    public static final String DRIVER_ONBOARDING_API_IMPL_UPDATE_DRIVER_ADDRESS = "OnboardingWebhookAPIImpl_updateDriverAddress";
    public static final String ID_VERIFICATION_MANAGEMENT_API_IMPL_UPDATE_DRIVER_ID_VERIFICATION_STATUS = "IdVerificationManagementAPIImpl_updateDriverIdVerificationStatus";
    public static final String REQUEST = "Request";
    public static final String ID_VERIFICATION_WEBHOOK_API_IMPL_UPDATE_ID_VERIFICATION_STATUS = "IdVerificationWebhookAPIImpl_updateIdVerificationStatus";

    public static final String DMS_ESQ_QUERY_HELPER = "dms_ESQueryHelper";
    public static final String UNEXPECTED_VALUE = "Unexpected value: ";
    public static final String ASSOCIATED_STORE_CONVERTER = "AssociatedStoreConverter";
    public static final String  ASSOCIATED_STORES = "associatedStores";
    public static final String VEHILE_DRIVING_LICENSE_STATE = "vehicle.drivingLicenseState";
    public static final String VEHICLE_MAKE = "vehicle.make";
    public static final String VEHICLE_MODEL = "vehicle.model";
    public static final String VEHICLE_LICENSE_PLATE = "vehicle.licensePlate";
    public static final String VEHICLE_TYPE = "vehicle.type";
    public static final String ID_USER_ID = "id.userId";
    public static final String VEHICLE_COLORS = "vehicle.color";
    public static final String VEHICLE_MANUFACTURE_YEAR = "vehicle.manufactureYear";
    public static final String VEHICLE_IMAGE_URL = "vehicle.imageUrl";
    public static final String IS_ACTIVE = "isActive";
    public static final String ADDRESS_ADDRESS_LINE1 = "address.addressLine1";
    public static final String ADDRESS_ADDRESS_LINE12 = "address.addressLine2";
    public static final String ADDRESS_CITY = "address.city";
    public static final String ADDRESS_STATE = "address.state";
    public static final String ADDRESS_ZIP_CODE = "address.zipCode";
    public static final String ADDRESS_COUNTRY = "address.country";
    public static final String VEHICLE_INSURANCE_NO = "vehicle.insuranceNo";
    public static final String VEHICLE_INSURANCE_PROVIDER = "vehicle.insuranceProvider";
    public static final String VEHICLE_INSURANCE_EXPIRY = "vehicle.insuranceExpiry";
    public static final String CATEGORIES =  "categories";
    public static final String ORG_CATEGORIES =  "orgCategories";
    public static final String MOBILE = "mobile";
    public static final String VEHICLE_DRIVING_LICENSE_NO = "vehicle.drivingLicenseNo";
    public static final String CITY_OF_INTEREST = "cityOfInterest";
    public static final String CONTACT_EMAIL = "contact.email";
    public static final String CONTACT_NUMBER = "contact.phoneNumber";
    public static final String DATE_OF_BIRTH =  "dateOfBirth";
    public static final String FIRST_NAMES = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String STATUS = "status";
    public static final String UPDATED_TIME = "updatedTime";
    public static final String REASONS_CODE = "reasonCode";
    public static final String UPDATEDS_BY = "updatedBy";
    public static final String PAYMENT_REGISTRATION_ID = "paymentRegistrationId";
    public static final String REASONS_CODE_CONFIG_ENTITY_REASON_CODE ="reasonCodeConfigEntity.reasonCode";
    public static final String PHONES = "phone";
    public static final String LOCATIONS = "locations";
    public static final String PROGRAM_ID = "programId";
    public static final String RELATION_ENTITY_ID = "relationEntityId";
    public static final String RELATION_ENTITY_TYPE = "relationEntityType";
    public static final String TASK_PROVIDER = "taskProvider";
    public static final String TOKEN = "token";
    public static final String TIP_ELIGIBLE_MAPPER = "TipEligibleMapper";
    public static final String PROGRAM_PROGRAM_ID = "program.programId";
    public static final String ASSOCIATED_TASK_PROVIDERS = "associatedTaskProviders";
    public static final String IS_TIP_ELIGIBLE = "isTipEligible";
    public static final String ON_BOARDED_DATE = "onBoardedDate";
    public static final String ADDRESS = "address";
    public static final String ADDRESSES = "addresses[0]";
    public static final String VEHICLE = "vehicle";
    public static final String VEHICLES = "vehicles[0]";
    public static final String DRIVER_BOOSTER_OFFER_SCHEDULE_API_IMPL_SAVE = "DriverBoosterOfferScheduleAPIImpl_saveBoosterOfferSchedule";
    public static final String DRIVER_BOOSTER_OFFER_SCHEDULE_API_IMPL = "DriverBoosterOfferScheduleAPIImpl";
    public static final String DRIVER_BOOSTER_OFFER_SCHEDULE_API_IMPL_GET = "DriverBoosterOfferScheduleAPIImpl_getBoosterOfferSchedule";
    public static final String DRIVER_BOOSTER_OFFER_SCHEDULE_API_IMPL_GET_BOOSTER =  "DriverBoosterOfferScheduleAPIImpl_getBoosterOfferScheduleAudit";
    public static final String ERROR_WHILE_CLOSING_THE_TIME = "Error while closing the timer: {}";
    public static final String DRIVERS = "Driver ";
    public static final String IN_HOME_DRIVE_SCHEDULE_JOB_FAILED = "IN_HOME_DRIVE_SCHEDULE_JOB_FAILED";
    public static final String DRIVER_SUGGESTION_API = "DRIVER_SUGGESTION_API";
    public static final String DMS_DRIVER_AVAILABILITY_API_IMPL = "dms_DriverAvailabilityAPIImpl";
    public static final String DELIVERY_BLOCK = "deliveryBlock";
    public static final String TRIP_ID = "tripId";
    public static final String DRIVER_ASSIGNMENT_TYPE = "driverAssignmentType";
    public static final String RUNTIME_CONTEXT_ENVIRONMENT = "runtime.context.environment";
    public static final String HEADER_TENANT_ID = "WM_TENANT_ID";
    public static  final String DRIVER_ENTITIES = "driverEntities";
    public static  final String DRIVER_ENTITY = "driverEntity";
    public static  final String DRIVER_CURRENT_LOCAL_TIME = "currentLocalTime";
    public static  final String DRIVER_DEACTIVATE_PENDING_STATUS = "driverDeactivatePendingStatus";

    public static final String UPDATE_DRIVER_EXTENSION_INFO = "UPDATE_DRIVER_EXTENSION_INFO";
    public static final String  PRINCIPAL_LOGIN_ID = "principal.loginId";
    public static final String DRIVER_AUTH_API_IMPL_CHANGE_LOGIN_PASSWORD = "DriverAuthAPIImpl_changeLoginPassword";
    public static final String DRIVER_AUTH_API_IMPL = "DriverAuthAPIImpl";
    public static final String DRIVER_AUTH_API_IMPL_RESET_PASSWORD_USING_CODE = "DriverAuthAPIImpl_resetPasswordUsingCode";
    public static final String MESSAGE = "message";
    public static final String DRIVER_AUTH_API_IMPL_GENERATE_LOGIN_OTP = "DriverAuthAPIImpl_generateLoginOTP";
    public static final String DRIVER_AUTH_API_IMPL_INVALIDATE_MULTIPLE_SESSION = "DriverAuthAPIImpl_invalidateMultipleSession";
    public static final String DRIVER_AUTH_API_IMPL_VALIDATE_LOGIN_OTP = "DriverAuthAPIImpl_validateLoginOTP";
    public static final String DRIVER_AUTH_API_IMPL_LOGIN_DRIVER = "DriverAuthAPIImpl_loginDriver";
    public static final String DRIVER_AUTH_API_IMPL_GENERATE_RESET_OTP = "DriverAuthAPIImpl_generateResetOTP";
    public static final String DRIVER_AUTH_API_IMPL_LOGOUT_DRIVER = "DriverAuthAPIImpl_logoutDriver";
    public static final String DRIVER_REDACTION_JOB_REQUEST_DTO = "driverRedactionJobRequestDTO";
    public static final String DRIVER_STUCK_LIST = "driverStuckList";
    public static final String DRIVER_VERIFICATION_JOB_REQUEST_DTO = "driverVerificationJobRequestDTO";
    public static final String ERROR_WHILE_CHECKING_DRIVER_ONBOARDING_VERIFICATION = "Error while checking driver onboarding verification";
    public static final String CHECKING_DRIVER_ONBOARDING_VERIFICATION = "Checking driver onboarding verification";
    public static final String TRIP_EXECUTOR_SERVICE_IS_NOT_REACHABLE = "Trip Executor Service is not reachable";
    public static final String PERSONA_SOURCE = "Persona";
    public static final String UNDATED_STRIKE = "add";


    public static final int DRIVER_TEMP_PASSWORD_LENGTH = 6;
    public static final String FILE_SEPARATOR = "/";
    public static final String EXTENSION_INDICATOR = ".";
    public static final String SAS_TOKEN_SEPARATOR = "?";
    public static final String DRIVER_PII_DTO = "DRIVER_PII_DTO";
    public static final String DOCUMENT_URL = "DOCUMENT_URL";
    public static final String NOT_ADDED_FILE_TYPE = "NA";
    public static final String AZURE_BLOB_UPLOAD_REQUEST = "AZURE_BLOB_UPLOAD_REQUEST";
    public static final String ASCENDING = "ASC";
    public static final String DMS_PERSONA_DATA_REPORTING_EVENT = "DMS_PERSONA_DATA_REPORTING_EVENT";
    public static final String DRIVER_VERIFICATION_INFO = "DRIVER_VERIFICATION_INFO";
    public static final String IAM_INVALID_USER_ERROR_CODE = "1052";
    public static final String IAM_NEW_PASSWORD_SAME_AS_PREVIOUS_PASSWORD_ERROR_CODE = "1015";
    public static final String IAM_PASSWORD_CHANGED_TOO_FREQUENTLY_ERROR_CODE = "1013";
    public static final String IAM_PASSWORD_DO_NOT_MATCH_ERROR_CODE = "1014";
    public static final String IAM_DRIVER_LOCKED_ERROR_CODE = "1016";
    public static final String IAM_PASSWORD_SAME_AS_ID_ERROR_CODE = "1021";
    public static final String IAM_PASSWORD_CHANGED_AFTER_TOKEN_EXPIRED_ERROR_CODE = "1095";




    public static final String STR_LIST_CONVERTER = "StringListConverter";

    public static final String PAGE_NUMBER = "pageNumber";
    public static final String TOTAL = "total";
    public final static String DEACTIVATION_BASED_ON_GRAPH_TAG = "DMS3001";
    public static final String DMS_DRIVER_DOCUMENT_UPDATED = "DRIVER_DOCUMENT_UPDATED";
    public static final String DRIVER_DOCUMENT_TYPE = "DRIVER_DOCUMENT_TYPE";



}
