package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Configuration(configName = "signatureConfig")
@Data
public class SignatureConfig {
    @Property(propertyName = "security.encrypt.decrypt.password")
    private String securityEncryptDecryptPassword;

    @Property(propertyName = "security.encrypt.decrypt.salt")
    private String securityEncryptDecryptSalt;

    @Property(propertyName = "security.encrypt.decrypt.algorithm")
    private String securityEncryptDecryptAlgorithm;

    @Property(propertyName="dms.signature.generator.public.key")
    private String dmsSignatureGeneratorPublicKey;

    @Property(propertyName="dms.signature.generator.private.key")
    private String dmsSignatureGeneratorPrivateKey;

    @Property(propertyName="new.dms.signature.generator.public.key")
    private String newDmsSignatureGeneratorPublicKey;

    @Property(propertyName="new.dms.signature.generator.private.key")
    private String newDmsSignatureGeneratorPrivateKey;

    @Property(propertyName="security.deterministic.encrypt.decrypt.password")
    private String securityDeterministicEncryptDecryptPassword;

    @Property(propertyName="security.deterministic.encrypt.decrypt.salt")
    private String securityDeterministicEncryptDecryptSalt;

    @Property(propertyName="security.deterministic.encrypt.decrypt.algorithm")
    private String securityDeterministicEncryptDecryptAlgorithm;

    @Property(propertyName="dms.security.encrypt.decrypt.password")
    private String dmsSecurityEncryptDecryptPassword;

    @Property(propertyName="dms.security.encrypt.decrypt.salt")
    private String dmsSecurityEncryptDecryptSalt;

    @Property(propertyName="dms.security.encrypt.decrypt.algorithm")
    private String dmsSecurityEncryptDecryptAlgorithm;

    @Property(propertyName="bringg.signature.generator.public.key")
    private String bringgSignatureGeneratorPublicKey;

    @Property(propertyName="bringg.signature.generator.private.key")
    private String bringgSignatureGeneratorPrivateKey;

    @Property(propertyName="ddi.signature.generator.public.key")
    private String ddiSignatureGeneratorPublicKey;

    @Property(propertyName="ddi.signature.generator.private.key")
    private String ddiSignatureGeneratorPrivateKey;

}