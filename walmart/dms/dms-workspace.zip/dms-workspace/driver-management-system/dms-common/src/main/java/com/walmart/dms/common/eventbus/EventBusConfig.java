package com.walmart.dms.common.eventbus;

import com.google.common.eventbus.AsyncEventBus;
import com.walmart.dms.common.utils.ThreadUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executors;

/**
 * @author g0s00pv on 8/1/18
 */
@Configuration
@Slf4j
public class EventBusConfig {
    
    @Bean
    public AsyncEventBus eventBus() {
        // TODO: take thread pool from ccm
        AsyncEventBus eventBus = new AsyncEventBus("cspAsyncEventBus",
                Executors.newFixedThreadPool(5, ThreadUtil.defaultThreadFactory(EventBusConfig.class.getSimpleName())));
        log.info("Initialized DMS-AsyncEventBus with threadPool size: {}", 5);
        return eventBus;
    }
}
