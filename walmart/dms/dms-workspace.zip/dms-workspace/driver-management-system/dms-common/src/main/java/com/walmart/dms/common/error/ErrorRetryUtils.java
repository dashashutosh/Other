package com.walmart.dms.common.error;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.enums.ErrorType;
import com.walmart.dms.server.common.error.ExceptionUtil;

import io.strati.libs.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;

/**
 * @author n0k008c
 *
 */
@Slf4j
@Component
public class ErrorRetryUtils {
    
    public ErrorRetryDTO getErrorRetryDTO(final String eventName, final String payload, final String errorMsg,
            final ErrorType errorType, Exception e, int maxRetryCount, String tenant, String vertical) {

        ErrorRetryDTO errorRetryDTO = new ErrorRetryDTO();
        errorRetryDTO.setErrorId(UUID.randomUUID().toString());
        errorRetryDTO.setEventName(eventName);
        errorRetryDTO.setPayload(payload);
        errorRetryDTO.setTenantId(tenant);
        errorRetryDTO.setVerticalId(vertical);
        errorRetryDTO.setErrorType(errorType.name());
        
        String errMsg = errorMsg;
        if (StringUtils.isEmpty(errMsg) && (e != null)) {
            errMsg = e.getMessage();
        }
        if (errMsg != null) {
           errorRetryDTO.setErrorMessage(errMsg.substring(0, Math.min(errMsg.length(), Constant.ERROR_MESSAGE_MAX_CHARS)));
        }
        errorRetryDTO.setMaxRetryCount(maxRetryCount);
        
        if (e != null) {
            String stackTrace = ExceptionUtil.getStackTraceString(e);
            errorRetryDTO.setErrorStackTrace(stackTrace.substring(0, Math.min(stackTrace.length(), Constant.STACK_TRACE_MAX_CHARS)));
        }
        try {
            errorRetryDTO.setComputeIP(InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e1) {
            log.error("Error in getting IP address", e1);
        }

        return errorRetryDTO;
    }
}
