package com.walmart.dms.common.filter;

import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.error.ErrorMessageConstant;
import com.walmart.dms.common.logger.InfoSecLogger;
import com.walmart.dms.common.utils.LogUtil;
import com.walmart.dms.common.utils.MaskingUtils;
import com.walmart.dms.common.utils.Pair;
import io.strati.libs.commons.lang3.StringUtils;
import io.strati.security.jaxrs.ws.rs.HttpMethod;
import javax.annotation.Priority;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.List;

@Slf4j
@Component
@Priority(500)
public class InfoSecLogFilter extends OncePerRequestFilter {

    @Autowired
    private InfoSecLogger infoSecLogger;

    @Autowired
    private CommonConfig commonConfig;

    @Autowired
    private MaskingUtils maskingUtils;

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) {


        ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(httpServletRequest);
        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(httpServletResponse);

        try {
            filterChain.doFilter(requestWrapper, responseWrapper);
            if (commonConfig.isEnableInfoSecLogging()) {
                String requestBody = getStringValue(requestWrapper.getContentAsByteArray(),
                        httpServletRequest.getCharacterEncoding()).replace("\n", "");
                log.info(LogUtil.buildJsonLog("API path in infosec filter",  Pair.with(com.walmart.dms.common.constant.Constant.REQUEST_PAYLOAD, httpServletRequest.getPathInfo())));
                if (!httpServletRequest.getMethod().equals(HttpMethod.GET) && !StringUtils.isEmpty(requestBody)) {
                    String maskedRequestPayload = maskingUtils.maskPiiWithJsonPath(requestBody);
                    requestBody = maskedRequestPayload;
                }
                String responseBody = getStringValue(responseWrapper.getContentAsByteArray(),
                        httpServletResponse.getCharacterEncoding());
                String maskedResponseBody = maskingUtils.maskPiiWithJsonPath(responseBody);

                infoSecLogger.publishLog(httpServletRequest.getMethod(), httpServletRequest.getPathInfo(),
                        getHeaders(httpServletRequest), requestBody,
                        String.valueOf(httpServletResponse.getStatus()),
                        maskedResponseBody,
                        httpServletResponse.getHeader(Constant.EVENT_TYPE));
                log.info("InfoSecLogFilter - doFilterInternal - InfoSec LogEvent sent.");
            }
            responseWrapper.copyBodyToResponse();
        } catch (IOException | ServletException ex) {
            String message = MessageFormat.format(ErrorMessageConstant.EXCEPTION_MESSAGE, ex.getMessage());
            log.error(message);
        } catch (Exception ex) {
            String message = MessageFormat.format(ErrorMessageConstant.EXCEPTION_MESSAGE, ex.getMessage());
            log.error(message);
        }
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        AntPathMatcher antPathMatcher = new AntPathMatcher();
        String url = request.getRequestURI();
        return commonConfig.dmsAPIShouldNotFilter.stream().anyMatch(urlShouldNotFilter -> antPathMatcher.match(urlShouldNotFilter, url));
    }

    private String getStringValue(byte[] contentAsByteArray, String characterEncoding) {
        try {
            return new String(contentAsByteArray, 0, contentAsByteArray.length, characterEncoding);
        } catch (UnsupportedEncodingException e) {
            log.error(e.getMessage());
        }
        return "";
    }

    private String getHeaders(HttpServletRequest httpServletRequest) {
        Enumeration<String> reqHeaderNames = httpServletRequest.getHeaderNames();
        final StringBuilder b = new StringBuilder();

        List<String> basePaths = commonConfig.getDmsRRLogFilterRestrictHeaderLogForApi();
        String requestPath = httpServletRequest.getPathInfo();
        // Check if the request path starts with any of the base paths
        boolean isApiHeaderRestricted = basePaths.stream()
                .anyMatch(basePath -> requestPath.startsWith(basePath));

        if(!isApiHeaderRestricted){
            if (null != reqHeaderNames) {
                b.append("{");
                String headerName;
                while (reqHeaderNames.hasMoreElements()) {
                    headerName = reqHeaderNames.nextElement();
                    if(headerName.equalsIgnoreCase("WM_SEC.AUTH_SIGNATURE")){
                        continue;
                    }
                    b.append(headerName + ":" + httpServletRequest.getHeader(headerName)).append(";");
                }
                b.append("}");
            }
        }
        return b.toString();
    }
}