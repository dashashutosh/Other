package com.walmart.dms.common.exception;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.google.gson.JsonObject;
import com.walmart.dms.common.ccm.ElasticSearchConfig;
import com.walmart.dms.common.model.onboarding.OnboardingESPayloadDTO;
import com.walmart.dms.common.model.onboarding.OnboardingRequestPayload;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.elasticsearch.entity.DriverOnboardingFailureESEntity;
import com.walmart.dms.common.eventbus.publisher.EventBusPublisher;
import com.walmart.dms.common.service.AbstractServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.config.ConfigFactory;
import com.walmart.dms.common.spotlight.SpotLightConfig;
import com.walmart.dms.common.spotlight.SpotLightService;
import com.walmart.dms.server.common.error.Error;
import com.walmart.dms.server.common.error.Status;
import com.walmart.dms.server.common.service.ServiceResponse;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;


/**
 * @author n0a008p on Feb 23, 2018
 *
 */
@Slf4j
@Provider
public class ValidationExceptionMapper implements ExceptionMapper<javax.validation.ValidationException> {

    @Autowired
    private SpotLightService spotLightService;

    @Autowired
    private SpotLightConfig spotLightConfig;

    @Autowired
    private ConfigFactory configFactory;

    @Autowired
    private ElasticSearchConfig esConfig;

    @Autowired
    private EventBusPublisher eventBusPublisher;

    private Set<String> generateSpotLightForApi = new HashSet<String>();

    private boolean isEnableDmsOnboardingESUpdate;

    Gson gsonObj = new Gson();

    @PostConstruct
    public void preCompute() {
        CommonConfig commonConfig = configFactory.config(CommonConfig.class);
        StringTokenizer tokenizer = new StringTokenizer(commonConfig.generateSpotLightForApiList, ",");
        while (tokenizer.hasMoreTokens()) {
            generateSpotLightForApi.add(tokenizer.nextToken());
        }
    }

	@SuppressWarnings("unchecked")
	@SuppressFBWarnings(value="BC_UNCONFIRMED_CAST")
	@Override
	public Response toResponse(javax.validation.ValidationException e) {
		final StringBuilder strBuilder = new StringBuilder();
		
		for (ConstraintViolation<?> cv : ((ConstraintViolationException) e).getConstraintViolations()) {
            strBuilder.append(cv.getMessage() + ",");
            Object requestDTO = cv.getLeafBean();
            String jsonRequestDTO = gsonObj.toJson(requestDTO);

            log.error("Validation failed for {} as {}", cv.getRootBeanClass().getName(), cv.getMessage());

            if (generateSpotLightForApi.contains(cv.getRootBeanClass().getName()) && AbstractServiceImpl.class.isAssignableFrom(cv.getRootBeanClass())) {
                /* Check if the root bean class is descendant of AbstractServiceImpl */
                final String tenantIdHeader = ((AbstractServiceImpl) cv.getRootBean()).getRequestHeader(Constant.TENANT_ID_HEADER_KEY);
                final String tenantId = tenantIdHeader == null ? "" : tenantIdHeader;

                    /* TODO: Currently generateSpotLightForApi contains only one API which is OnboardingWebhookAPIImpl,
                        so saving onboarding failure in ES. If new APIs are added to the list, modify the flow accordingly */
                saveOnboardingFailuresInES(jsonRequestDTO, cv.getMessage(), tenantId);
            }
        }

        @SuppressWarnings("rawtypes")
        ServiceResponse result = new ServiceResponse();
        result.setStatus(Status.BAD_REQUEST);
        ArrayList<Error> errors = new ArrayList<>();
        Error error = new Error("400", "", strBuilder.subSequence(0, strBuilder.length() - 1).toString(), "");
        errors.add(error);
        result.setErrors(errors);
        return Response.status(Response.Status.BAD_REQUEST.getStatusCode()).type(MediaType.APPLICATION_JSON)
                .entity(result).build();
    }

    /**
     * Saves the onboarding failures in ES.
     *
     * @param jsonRequestDTO the json request DTO
     * @param errorMsg       the error message
     * @param tenantId       the tenant id
     */
    public void saveOnboardingFailuresInES(final String jsonRequestDTO, final String errorMsg, final String tenantId) {
        DriverOnboardingFailureESEntity esEntity = gsonObj.fromJson(jsonRequestDTO, DriverOnboardingFailureESEntity.class);
        esEntity.setErrorPayload(errorMsg + " " + jsonRequestDTO);
        esEntity.setDateTime(ZonedDateTime.now(ZoneOffset.UTC));
        esEntity.setTenantId(tenantId);
        eventBusPublisher.publishDriverOnboardingFailureEvent(esEntity);
        CommonConfig commonConfig= configFactory.config(CommonConfig.class);
        if(commonConfig.isEnableDmsOnboardingESUpdate())
            storeOnBoardingFailuresinNewES(jsonRequestDTO, errorMsg);
    }

    /**
     * Driver Onboarding - Enhanced Logging
     * Prepare OnboardingESPayloadDTO and publish to ES
     * @param jsonRequest
     * @param errorMsg
     */
    public void storeOnBoardingFailuresinNewES(String jsonRequest, String errorMsg) {
        try {
            OnboardingESPayloadDTO onboardingESPayloadDTO = new OnboardingESPayloadDTO();
            onboardingESPayloadDTO.setRequestPayload(createOnboardingRequestPayloadFromJson(jsonRequest));
            if (onboardingESPayloadDTO.getRequestPayload().getDriverUserId() != null)
                onboardingESPayloadDTO.setDriverId(onboardingESPayloadDTO.getRequestPayload().getDriverUserId());
            onboardingESPayloadDTO.setApiType(Constant.CREATE_DRIVER);
            onboardingESPayloadDTO.setDateTime(ZonedDateTime.now());
            onboardingESPayloadDTO.setHttpCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            onboardingESPayloadDTO.setId(onboardingESPayloadDTO.generateId());
            onboardingESPayloadDTO.setOnboardingErrorApiName(Constant.CREATE_DRIVER);
            onboardingESPayloadDTO.setOnboardingErrorMessage(errorMsg);
            onboardingESPayloadDTO.setOnboardingHttpErrorCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            log.info("Publishing onboardingESPayloadDTO to ES from storeOnBoardingFailuresinNewES in ValidationExceptionMapper");
            eventBusPublisher.publishOnboardingEvent(onboardingESPayloadDTO);
        }
        catch (Exception e)
        {
            log.info("Error processing storeOnBoardingFailuresinNewES with exception {}", e);
        }

    }

    private OnboardingRequestPayload createOnboardingRequestPayloadFromJson(String jsonRequestDTO) {
        OnboardingRequestPayload onboardingRequestPayload  = new OnboardingRequestPayload();
        try {
            JsonObject jsonRequestObject = gsonObj.fromJson(jsonRequestDTO, JsonObject.class);
            if(jsonRequestObject.get("id")!= null)
                onboardingRequestPayload.setDriverUserId(jsonRequestObject.get("id").getAsString());
            if(jsonRequestObject.get("firstName")!= null)
                onboardingRequestPayload.setFirstName(jsonRequestObject.get("firstName").getAsString());
            if(jsonRequestObject.get("lastName")!= null)
                onboardingRequestPayload.setLastName(jsonRequestObject.get("lastName").getAsString());
            if(jsonRequestObject.get("email")!= null)
                onboardingRequestPayload.setEmail(jsonRequestObject.get("email").getAsString());
            if(jsonRequestObject.get("phone")!= null)
                onboardingRequestPayload.setMobile(jsonRequestObject.get("phone").getAsString());
            if(jsonRequestObject.get("city")!= null)
                onboardingRequestPayload.setCityOfInterest(jsonRequestObject.get("city").getAsString());
            if(jsonRequestObject.get("marketName")!= null)
                onboardingRequestPayload.setMarketName(jsonRequestObject.get("marketName").getAsString());
        }
        catch (Exception e)
        {
            log.info("Error setting driverId from requestDTO to OnboardingRequestPayload :{}", e);
        }
        return onboardingRequestPayload;
    }

}

