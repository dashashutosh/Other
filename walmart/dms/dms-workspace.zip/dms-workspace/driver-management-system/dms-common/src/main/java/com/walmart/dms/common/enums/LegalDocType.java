package com.walmart.dms.common.enums;

/**
 *This enum is for all types of Legal Document
 *
 * @author s0g03ta
 */
public enum LegalDocType {
    TNC, NDA, PR, CONSENT //Terms N Condition, Non Disclosure Agreement, Privacy Review
}
