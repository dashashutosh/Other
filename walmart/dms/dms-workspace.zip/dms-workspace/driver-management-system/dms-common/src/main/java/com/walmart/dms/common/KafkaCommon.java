package com.walmart.dms.common;

public class KafkaCommon {
    private KafkaCommon() {
    }

    public static final String HEADER = "header";
    public static final String PAYLOAD = "payload";

    public static String constructKafkaGroupId(String groupId) {
        return (groupId + "_" + VMConfig.getRunOnEnv() + "_" + VMConfig.getTenantId());
    }
}
