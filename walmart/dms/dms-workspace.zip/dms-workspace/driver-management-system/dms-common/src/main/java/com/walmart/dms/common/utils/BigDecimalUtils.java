package com.walmart.dms.common.utils;

import java.math.BigDecimal;
import java.math.MathContext;

/**
 * Use this class to perform Arithmetic operation on Double
 *
 * @author n0k008c
 */
public class BigDecimalUtils {
    private BigDecimalUtils() {
    }

    public static BigDecimal add(Double a, Double b) {
        return (new BigDecimal(a.toString())).add(new BigDecimal(b.toString()));
    }

    public static BigDecimal add(Double a, Double b, MathContext mc) {
        return (new BigDecimal(a.toString())).add(new BigDecimal(b.toString()), mc);
    }

    public static BigDecimal subtract(Double a, Double b) {
        return (new BigDecimal(a.toString())).subtract(new BigDecimal(b.toString()));
    }

    public static BigDecimal subtract(Double a, Double b, MathContext mc) {
        return (new BigDecimal(a.toString())).subtract(new BigDecimal(b.toString()), mc);
    }

    public static BigDecimal multiply(Double a, Double b) {
        return (new BigDecimal(a.toString())).multiply(new BigDecimal(b.toString()));
    }

    public static BigDecimal multiply(Double a, Double b, MathContext mc) {
        return (new BigDecimal(a.toString())).multiply(new BigDecimal(b.toString()), mc);
    }

    public static BigDecimal divide(Double a, Double b) {
        return (new BigDecimal(a.toString())).divide(new BigDecimal(b.toString()));
    }

    public static BigDecimal divide(Double a, Double b, MathContext mc) {
        return (new BigDecimal(a.toString())).divide(new BigDecimal(b.toString()), mc);
    }
}
