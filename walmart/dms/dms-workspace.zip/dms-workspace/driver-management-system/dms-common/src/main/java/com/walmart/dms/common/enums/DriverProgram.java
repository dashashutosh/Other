package com.walmart.dms.common.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum DriverProgram {

	SWIFT("101"), BRINGG("102");

	private static final long serialVersionUID = 5297180767374579365L;

	private String programId;

	private DriverProgram(String programId) {
		this.programId = programId;
	}

	@JsonCreator
	public String getProgramId() {
		return programId;
	}

	public static DriverProgram getById(String id) {
		for (DriverProgram program : DriverProgram.values()) {
			if (program.getProgramId().equalsIgnoreCase(id)) {
				return program;
			}
		}
		return null;
	}

}
