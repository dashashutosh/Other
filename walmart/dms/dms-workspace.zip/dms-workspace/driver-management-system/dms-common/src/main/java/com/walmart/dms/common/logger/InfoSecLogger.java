package com.walmart.dms.common.logger;

import com.walmart.dms.common.config.CommonConfig;
import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.dto.InfoSecLogFilterDTO;
import com.walmart.dms.common.spotlight.SpotLightConfig;
import com.walmart.dms.common.spotlight.SpotLightService;
import com.walmart.dms.common.spotlight.model.DMSFailureEvent;
import com.walmart.dms.common.utils.JsonUtil;
import io.strati.libs.commons.lang3.StringUtils;
import io.strati.security.jaxrs.ws.rs.HttpMethod;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import static java.time.LocalDateTime.now;

@Slf4j
@Component
public class InfoSecLogger {
    private static org.slf4j.Logger infoSecLoggers = org.slf4j.LoggerFactory.getLogger("InfoSecAudit");



    @Autowired
    private SpotLightConfig spotLightConfig;

    @Autowired
    private SpotLightService spotLightService;

    @Autowired
    private CommonConfig commonConfig;

    @Async("infoSecExecutor")
    public void publishLog(String method, String path, String headers, String requestPayload, String status, String payload, String eventType) {

        String jsonLogEvent = null;
        InfoSecLogFilterDTO infoSecLogFilterDTO = InfoSecLogFilterDTO.builder()
                .timeUtc(ZonedDateTime.of(now(), ZoneOffset.UTC).toString())
                .productName(Constant.DMS)
                .requestMethod(method)
                .requestPath(path)
                .requestHeaders(headers)
                .httpResponseCode(status)
                .responsePayload(payload)
                .vendorName(Constant.VENDOR_NAME)
                .eventType(eventType).build();
        if (!method.equals(HttpMethod.GET) && !StringUtils.isEmpty(requestPayload)) {
            infoSecLogFilterDTO.setRequestPayload(requestPayload);
        }
        try {

            jsonLogEvent = JsonUtil.toJson(infoSecLogFilterDTO).replace("\\\"", "\"");
            infoSecLoggers.info(jsonLogEvent);
            log.info("InfoSecLogger payload verification " + jsonLogEvent);
            log.info("InfoSecLogger - publishLog - Logevent posted successfully by Thread " + Thread.currentThread().getName());

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            DMSFailureEvent request = new DMSFailureEvent.Builder()
                    .error("Error while sending log to infosec" + jsonLogEvent)
                    .log(ex.getMessage()).eventId(spotLightConfig.getFailureAlertEventId())
                    .type("INFOSEC_LOGGING").build();
            spotLightService.sendEvent(request);
        }
    }
}