/**
 * 
 */
package com.walmart.dms.common.service;

import java.util.Arrays;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;

import com.walmart.dms.common.error.ErrorCode;
import com.walmart.dms.common.error.ErrorMapper;
import com.walmart.dms.server.common.error.ApplicationLayer;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.dms.common.constant.Constant;
import com.walmart.dms.common.enums.DriverProgram;
import com.walmart.dms.common.enums.Tenant;
import com.walmart.dms.common.enums.Vertical;
import com.walmart.dms.common.exception.ExceptionHandler;
import com.walmart.dms.common.utils.HeaderDTO;
import com.walmart.dms.server.common.error.Error;
import com.walmart.dms.server.common.exception.BusinessException;
import com.walmart.dms.server.common.service.ServiceResponseBuilder;


/**
 * @author s0k00tl
 *
 */
public abstract class AbstractServiceImpl {

    protected ServiceResponseBuilder serviceResponseBuilder = new ServiceResponseBuilder();

    @Autowired
    protected ExceptionHandler exceptionHandler;

    @Context
    protected HttpHeaders headers;

    @Autowired
    private ErrorMapper errorMapper;

    @Context
    protected HttpServletResponse httpServletResponse;

    protected HeaderDTO getHeaderDTO(HttpHeaders headers) throws BusinessException {
        if (headers != null && headers.getRequestHeader(Constant.TENANT_ID_HEADER_KEY) != null
                && (headers.getRequestHeader(Constant.VERTICAL_ID_HEADER_KEY) != null)) {
            return prepareHeaders(headers);
        }else {
            throw new BusinessException("Invalid header");
        }
    }

    protected HeaderDTO getDDIHeaderDTO() throws BusinessException {
        HeaderDTO headerDTO = new HeaderDTO(Tenant.US.getTenantId(), Vertical.GROCERIES.getVerticalId());
        if (headers != null && headers.getRequestHeader(Constant.CORRELATION_ID_HEADER_KEY) != null) {
            headerDTO.setCorrelationId(headers.getRequestHeader(Constant.CORRELATION_ID_HEADER_KEY).get(0));
        }
        return headerDTO;

    }
	protected HeaderDTO getDDIHeaderDTO(Set<String> tenantBasedTenantIds) throws BusinessException {
        Tenant tenant = getTenantBasedTenantIds(tenantBasedTenantIds);
        HeaderDTO headerDTO = new HeaderDTO(tenant.getTenantId(), Vertical.GROCERIES.getVerticalId());
		if (headers != null && headers.getRequestHeader(Constant.CORRELATION_ID_HEADER_KEY) != null) {
			headerDTO.setCorrelationId(headers.getRequestHeader(Constant.CORRELATION_ID_HEADER_KEY).get(0));
		}
		return headerDTO;

	}

    private Tenant getTenantBasedTenantIds(Set<String> tenantBasedTenantIds) {
        Tenant tenant = Tenant.US;
        if (headers != null && headers.getRequestHeader(Constant.TENANT_ID_HEADER_KEY) != null) {
            String tenantId = headers.getRequestHeader(Constant.TENANT_ID_HEADER_KEY).get(0);
            if (tenantBasedTenantIds != null && tenantBasedTenantIds.contains(tenantId)) {
                return Tenant.getById(tenantId);
            }
        }
        return tenant;
    }

    protected HeaderDTO getPersonaHeaderDTO() throws BusinessException {
        HeaderDTO headerDTO = new HeaderDTO(Tenant.US.getTenantId(), Vertical.GROCERIES.getVerticalId());
        if(headers != null){
            if (headers.getRequestHeader(Constant.CORRELATION_ID_HEADER_KEY) != null) {
                headerDTO.setCorrelationId(headers.getRequestHeader(Constant.CORRELATION_ID_HEADER_KEY).get(0));
            }
            if(headers.getRequestHeader(Constant.CLIENT) == null) {
                throw new BusinessException(errorMapper.getError(ApplicationLayer.CLIENT_LAYER, ErrorCode.SERVICE_INVALID_HEADERS.getErrorCode()), null);
            }
            headerDTO.setClient(headers.getRequestHeader(Constant.CLIENT).get(0));
            return headerDTO;
        } else {
            throw new BusinessException("Invalid header");
        }
    }

    protected DriverProgram getProgram(String programId) throws BusinessException {
        Error error = new Error("400", "programId", "Invalid ProgramId", "Values in" + Arrays.toString(DriverProgram.values()));
        if (programId != null) {
            DriverProgram driverProgram = DriverProgram.getById(programId);
            if (driverProgram == null) {
                throw new BusinessException(error, 400);
            }
            return driverProgram;
        } else {
            throw new BusinessException(error, 400);
        }
    }

    protected ServiceResponseBuilder getServiceResponseBuilder() {
        return serviceResponseBuilder;
    }

    /**
     * Gets the request header for given header key. In case of multiple header values, value at zeroth index will be
     * returned.
     *
     * @param headerKey the header key
     * @return the header value if header is present, null otherwise
     */
    public String getRequestHeader(final String headerKey) {
        if (null == headers || null == headers.getRequestHeader(headerKey)) {
            return null;
        }

        return headers.getRequestHeader(headerKey).get(0);
    }
    public HeaderDTO prepareHeaders(HttpHeaders headers) {
        String tenantId = headers.getRequestHeader(Constant.TENANT_ID_HEADER_KEY).get(0);
        String verticalId = headers.getRequestHeader(Constant.VERTICAL_ID_HEADER_KEY).get(0);
        HeaderDTO headerDTO = new HeaderDTO(tenantId, verticalId);
        // adding correlationId also to headers
        if(headers.getRequestHeader(Constant.CORRELATION_ID_HEADER_KEY)!=null)
            headerDTO.setCorrelationId(headers.getRequestHeader(Constant.CORRELATION_ID_HEADER_KEY).get(0));

        if(headers.getRequestHeader(Constant.CLIENT) != null) {
            headerDTO.setClient(headers.getRequestHeader(Constant.CLIENT).get(0));
        }

        if(headers.getHeaderString(Constant.REALM_ID_HEADER_KEY) !=null && !headers.getRequestHeader(Constant.REALM_ID_HEADER_KEY).get(0).equalsIgnoreCase(Constant.DUMMY_REALM_ID)) {
            String realmId = headers.getRequestHeader(Constant.REALM_ID_HEADER_KEY).get(0);
            headerDTO.setRealmId(realmId);
        }
        if(headers.getHeaderString(Constant.LOGIN_ID_HEADER_KEY) !=null && !headers.getRequestHeader(Constant.LOGIN_ID_HEADER_KEY).get(0).equalsIgnoreCase(Constant.DUMMY_LOGIN_ID)) {
            String loginId = headers.getRequestHeader(Constant.LOGIN_ID_HEADER_KEY).get(0);
            headerDTO.setLoginId(loginId);
        }
        if(headers.getHeaderString(Constant.DEVICE_MODEL) !=null && !headers.getRequestHeader(Constant.DEVICE_MODEL).get(0).equalsIgnoreCase(Constant.DUMMY_DEVICE_MODEL)) {
            String deviceModel = headers.getRequestHeader(Constant.DEVICE_MODEL).get(0);
            headerDTO.setDeviceModel(deviceModel);
        }
        if(headers.getHeaderString(Constant.DEVICE_OS) !=null && !headers.getRequestHeader(Constant.DEVICE_OS).get(0).equalsIgnoreCase(Constant.DUMMY_DEVICE_OS)) {
            String deviceOS = headers.getRequestHeader(Constant.DEVICE_OS).get(0);
            headerDTO.setDeviceOS(deviceOS);
        }
        if(headers.getHeaderString(Constant.DEVICE_OS_VERSION) !=null && !headers.getRequestHeader(Constant.DEVICE_OS_VERSION).get(0).equalsIgnoreCase(Constant.DUMMY_DEVICE_OS_VERSION)) {
            String deviceOSVersion = headers.getRequestHeader(Constant.DEVICE_OS_VERSION).get(0);
            headerDTO.setDeviceOSVersion(deviceOSVersion);
        }
        if(headers.getHeaderString(Constant.DEVICE_ID) !=null && !headers.getRequestHeader(Constant.DEVICE_ID).get(0).equalsIgnoreCase(Constant.DUMMY_DEVICE_ID)) {
            String deviceId = headers.getRequestHeader(Constant.DEVICE_ID).get(0);
            headerDTO.setDeviceId(deviceId);
        }
        if(headers.getHeaderString(Constant.INSTALLED_APP_VERSION) != null){
            String installedAppVersion = headers.getRequestHeader(Constant.INSTALLED_APP_VERSION).get(0);
            headerDTO.setInstalledAppVersion(installedAppVersion);
        }
        if(headers.getHeaderString(Constant.WM_LOCALE_ID) != null){
            String locale_id = headers.getRequestHeader(Constant.WM_LOCALE_ID).get(0);
            headerDTO.setLocaleId(locale_id);
        }
        if(headers.getHeaderString(Constant.WM_DRIVER_UUID) != null){
            String driver_uuid = headers.getRequestHeader(Constant.WM_DRIVER_UUID).get(0);
            headerDTO.setDriverUUID(driver_uuid);
        }
        if(headers.getHeaderString(Constant.WM_CONSUMER_IP) != null){
            String consumer_ip = headers.getRequestHeader(Constant.WM_CONSUMER_IP).get(0);
            headerDTO.setConsumerIP(consumer_ip);
        }
        if(headers.getHeaderString(Constant.WM_COUNTRY) != null){
            String country = headers.getRequestHeader(Constant.WM_COUNTRY).get(0);
            headerDTO.setCountry(country);
        }
        if(headers.getHeaderString(Constant.USER_AGENT) != null){
            String userAgent = headers.getRequestHeader(Constant.USER_AGENT).get(0);
            headerDTO.setUserAgent(userAgent);
        }
        if(headers.getHeaderString(Constant.REQUEST_HEADER_CONSUMER_ID) != null){
            String consumerId = headers.getRequestHeader(Constant.REQUEST_HEADER_CONSUMER_ID).get(0);
            headerDTO.setConsumerId(consumerId);
        }
        if(headers.getHeaderString(Constant.REQUEST_HEADER_CONSUMER_IP_ADDRESS) != null){
            String ipAddress = headers.getRequestHeader(Constant.REQUEST_HEADER_CONSUMER_IP_ADDRESS).get(0);
            headerDTO.setIpAddress(ipAddress);
        }
        if(headers.getHeaderString(Constant.REQUEST_HEADER_CONSUMER_SOURCE) != null){
            String source = headers.getRequestHeader(Constant.REQUEST_HEADER_CONSUMER_SOURCE).get(0);
            headerDTO.setConsumerSource(source);
        }
        if(headers.getHeaderString(Constant.DEVICE_PROFILE_REF_ID) != null && !headers.getRequestHeader(Constant.DEVICE_PROFILE_REF_ID).get(0).equalsIgnoreCase(Constant.DUMMY_DEVICE_PROFILE_REF_ID)){
          String deviceProfileRefId =  headers.getRequestHeader(Constant.DEVICE_PROFILE_REF_ID).get(0);
          headerDTO.setDeviceProfileRefId(deviceProfileRefId);
        }


        return headerDTO;
    }
}
