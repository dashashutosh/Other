package com.walmart.dms.common.requestresponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * Internal request log DTO class.
 *
 * @author a0d02yr
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class InternalRequestLogDTO {

    private String requestedBy;
    private String requestedTo;
    private String requestName;
    private int requestCount;
    private Object requestPayload;
    private Object requestHeaders;
    private Object responsePayload;
    private String responseErrorMessage;
    private String responseHTTPCode;

    /**
     * Gets the copy of current object.
     *
     * @return the copy of current object
     */
    public InternalRequestLogDTO copySelf() {
        final InternalRequestLogDTO internalRequestLogDTO = new InternalRequestLogDTO();
        internalRequestLogDTO.requestedBy = requestedBy;
        internalRequestLogDTO.requestedTo = requestedTo;
        internalRequestLogDTO.requestName = requestName;
        internalRequestLogDTO.requestPayload = requestPayload;
        internalRequestLogDTO.requestHeaders = requestHeaders;
        return internalRequestLogDTO;
    }
}
