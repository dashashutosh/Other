package com.walmart.dms.common.executors;

import lombok.Getter;
import lombok.Setter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Getter
@Setter
public class DmsServiceThreadPoolExecutor implements Executor {

    private int tpThreadCount;
    private int tpQueueSize;
    private String tpNamePrefix;
    private final ThreadPoolTaskExecutor tpExecutor;

    public DmsServiceThreadPoolExecutor(int tpThreadCount, int tpQueueSize, String tpNamePrefix) {
        this.tpThreadCount = tpThreadCount;
        this.tpQueueSize = tpQueueSize;
        this.tpNamePrefix = tpNamePrefix;
        tpExecutor = getThreadPool(tpThreadCount, tpQueueSize, tpNamePrefix);
    }

    private ThreadPoolTaskExecutor getThreadPool(int threadCount, int queueSize, String namePrefix) {
        ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
        threadPoolTaskExecutor.setMaxPoolSize(threadCount);
        threadPoolTaskExecutor.setCorePoolSize(threadCount);
        threadPoolTaskExecutor.setQueueCapacity(queueSize);
        threadPoolTaskExecutor.setThreadNamePrefix(namePrefix);
        threadPoolTaskExecutor.initialize();
        return threadPoolTaskExecutor;
    }

    @Override
    public void execute(final Runnable command) {
        this.tpExecutor.submit(command);
    }

    public void shutDown() {
        this.tpExecutor.shutdown();
    }
}
