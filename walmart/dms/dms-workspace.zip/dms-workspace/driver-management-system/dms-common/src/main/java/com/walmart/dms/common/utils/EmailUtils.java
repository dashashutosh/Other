package com.walmart.dms.common.utils;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.stereotype.Component;

import com.walmart.dms.server.common.exception.BusinessException;

@Component
public class EmailUtils {

    private static final String MAIL_SMTP_PROPERTY = "mail.smtp.host";
    private static final String MAIL_FROM = "dms-support@email.wal-mart.com";
    private static final String SMTP_HOST = "smtp-gw1.homeoffice.wal-mart.com";

    public void sendEmailWithAttachement(String subjectLine, String messageBody,
                                                ByteArrayOutputStream byteArrayOutputStream, List<String> mailToList, String fileName) throws MessagingException {

        Properties properties = System.getProperties();
        properties.setProperty(MAIL_SMTP_PROPERTY, SMTP_HOST);
        Session session = Session.getInstance(properties);

        // creates a new e-mail message
        Message msg = new MimeMessage(session);

        msg.setFrom(new InternetAddress(MAIL_FROM));

        InternetAddress[] addressTo = new InternetAddress[mailToList.size()];
        int counter = 0;
        for (String toAddress : mailToList) {
            addressTo[counter] = new InternetAddress(toAddress);
            counter++;
        }

        msg.setRecipients(Message.RecipientType.TO, addressTo);
        msg.setSubject(subjectLine);
        msg.setSentDate(new Date());

        Multipart multipart = new MimeMultipart();
        BodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setText(messageBody);
        multipart.addBodyPart(messageBodyPart);

        messageBodyPart = new MimeBodyPart();
        DataSource dataSource = new ByteArrayDataSource(byteArrayOutputStream.toByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        messageBodyPart.setDataHandler(new DataHandler(dataSource));
        messageBodyPart.setFileName(fileName);
        multipart.addBodyPart(messageBodyPart);

        msg.setContent(multipart);
        Transport.send(msg);
    }

    public void sendEmail(String subjectLine, String messageBody, List<String> mailToList) throws BusinessException {
        Properties properties = System.getProperties();
        properties.setProperty(MAIL_SMTP_PROPERTY, SMTP_HOST);
        Session session = Session.getDefaultInstance(properties);
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(MAIL_FROM));
            InternetAddress[] addressTo = new InternetAddress[mailToList.size()];
            int counter = 0;
            for (String toAddress : mailToList) {
                addressTo[counter] = new InternetAddress(toAddress);
                counter++;
            }

            message.setRecipients(Message.RecipientType.TO, addressTo);
            message.setSubject(subjectLine);
            message.setText(messageBody);
            Transport.send(message);
        } catch (MessagingException mex) {
            throw new BusinessException("Sending email failed with exception " + mex.getMessage());
        }
    }
}
