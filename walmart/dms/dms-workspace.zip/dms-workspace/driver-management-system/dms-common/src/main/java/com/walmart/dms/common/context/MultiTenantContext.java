package com.walmart.dms.common.context;

import com.walmart.dms.common.VMConfig;

public class MultiTenantContext {
    private MultiTenantContext() {
    }

    private static ThreadLocal<Object> currentTenant = new ThreadLocal<>();

    public static void setCurrentTenant(Object tenant) {
        if(tenant != null) {
            currentTenant.set(tenant);
        } else {
            /*
             * Use US tenant as default.
             */
            currentTenant.set(VMConfig.getTenantId());
        }
    }

    public static Object getCurrentTenant() {
        return currentTenant.get();
    }

    public static void clear() {
        currentTenant.remove();
    }
}
