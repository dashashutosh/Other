package com.walmart.dms.common.enums;

public enum NotificationSubType {

    VERIFICATION_APPROVED, VERIFICATION_DENIED

}