package com.walmart.dms.common.exception;

public class MessageProcessNotEnabledException extends Exception {

    public MessageProcessNotEnabledException(String str) {
        super(str);
    }

    public MessageProcessNotEnabledException(String str, Throwable cause) {
        super(str, cause);
    }
}