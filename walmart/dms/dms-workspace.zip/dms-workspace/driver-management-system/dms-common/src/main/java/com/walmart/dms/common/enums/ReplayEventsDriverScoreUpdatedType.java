package com.walmart.dms.common.enums;

public enum ReplayEventsDriverScoreUpdatedType {

    DRIVER_SCORE_UPDATED, DRIVER_SCORE_UPDATED_REAL_TIME

}
