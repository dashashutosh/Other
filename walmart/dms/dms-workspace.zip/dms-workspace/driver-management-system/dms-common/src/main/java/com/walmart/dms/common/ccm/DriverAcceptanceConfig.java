package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Data
@Configuration(configName = "driverAcceptanceConfig")
public class DriverAcceptanceConfig {

    @Property(propertyName = "driverAcceptance.host")
    private String host;

    @Property(propertyName = "driverAcceptance.log.level")
    public String logLevel;

    @Property(propertyName = "driverAcceptance.read.timeout.sec")
    public int readTimeOutInSec;

    @Property(propertyName = "driverAcceptance.connect.timeout.sec")
    public int connectTimeOutInSec;

    @Property(propertyName = "driverAcceptance.api.header")
    public String apiHeaders;
}
