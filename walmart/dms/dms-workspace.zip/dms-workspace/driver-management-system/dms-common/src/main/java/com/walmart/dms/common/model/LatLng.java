package com.walmart.dms.common.model;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public class LatLng {
    public Double latitude;
    public Double longitude;
}
