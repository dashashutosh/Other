package com.walmart.dms.common.enums;

public enum DriverSource {

    SCHEDULE, SPARK_NOW
}
