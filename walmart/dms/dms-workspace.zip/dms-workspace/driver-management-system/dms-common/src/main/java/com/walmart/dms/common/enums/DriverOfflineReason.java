package com.walmart.dms.common.enums;

import java.util.HashMap;
import java.util.Map;

public enum DriverOfflineReason {
    FORCED_OFFLINE, PROP22_INELIGIBLE, NONE, ELIGIBLE, ELIGIBILITY_CHECK_IN_PROGRESS,
    ID_ONBOARDING_NEEDED, ID_ONBOARDING_IN_PROGRESS, ID_VERIFICATION_NEEDED, ID_VERIFICATION_IN_PROGRESS, ID_VERIFICATION_FAILED, DOCUMENT_EXPIRED, PAYMENT_EXPIRED,
    FORCED_OFFLINE_REPEATED_DROPS,ID_VERIFICATION_IN_REVIEW, FORCED_OFFLINE_ID_VERIFICATION, FORCE_OFFLINE_TOU_VIOLATION, FORCED_OFFLINE_UNDER_REVIEW, DRIVER_LICENCE_EXPIRED;

    private static final Map<String, DriverOfflineReason> reasonMap;

    public static DriverOfflineReason getDriverOfflineReason(String reason) {
        if(!reasonMap.containsKey(reason)) {
            throw new IllegalArgumentException();
        }
        return reasonMap.get(reason);
    }

    static {
        reasonMap = new HashMap<>();
        for(DriverOfflineReason reason : DriverOfflineReason.values()) {
            reasonMap.put(reason.name(), reason);
        }
    }
}