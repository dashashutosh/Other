
package com.walmart.dms.common.enums;

/**
 * @author n0k008c
 *
 */
public enum ErrorType {

    API, KAFKA
}