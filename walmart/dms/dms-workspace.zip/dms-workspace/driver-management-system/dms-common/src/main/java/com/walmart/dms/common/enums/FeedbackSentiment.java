package com.walmart.dms.common.enums;

/**
 * 
 * @author m0m01pg
 *
 */
public enum FeedbackSentiment {
    POSITIVE, NEGATIVE;
}
