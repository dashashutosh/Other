package com.walmart.dms.common.utils;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.spec.KeySpec;
import java.util.Base64;

@Slf4j
@SuppressFBWarnings
public class EncryptDecryptUtil {

    private static final String SALT_KEY = "jKS9GC2m0i51E1PA9";
    private static final String SALT = "a9eX2DHQYWGAZgPQ0EkulZWvaiPuKBBahcYECb4IjEaqziDjzebBMJWDu5bCRpJm34gRvaYbNUiEDXVq0tjVmZ1fIp1m4AujLwCi";
    private static final String KEY_DERIVATION_FUNCTION = "PBKDF2WithHmacSHA256";
    private static final String KEY_ALGORITHM = "AES";
    private static final String CIPHER_ALGORITHM = "AES/GCM/NoPadding";

    private static final int KEY_LENGTH_BYTE = 32;
    private static final int ITERATION_COUNT = 65535;

    static String getPrefix() {
        return "ENC{";
    }
    static String getSuffix() {
        return "}";
    }

    public static String encrypt(String originalValue) {
        if (originalValue == null)
            return originalValue;
        if (isEncrypted(originalValue)) {
            return originalValue;
        } else {
            try {
                SecretKeyFactory factory = SecretKeyFactory.getInstance(KEY_DERIVATION_FUNCTION);
                KeySpec spec = new PBEKeySpec(SALT_KEY.toCharArray(), SALT.getBytes(StandardCharsets.UTF_8), ITERATION_COUNT, KEY_LENGTH_BYTE * 8);
                SecretKey secretKey = factory.generateSecret(spec);
                SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getEncoded(), KEY_ALGORITHM);

                Mac mac = Mac.getInstance("HmacSHA256");
                mac.init(secretKeySpec);
                byte[] iv = mac.doFinal(originalValue.getBytes());
                GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(128, iv);
                Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
                cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, gcmParameterSpec);
                byte[] cipherText = cipher.doFinal(originalValue.getBytes());
                byte[] encryptData = new byte[iv.length+cipherText.length];
                System.arraycopy(iv, 0, encryptData, 0, iv.length);
                System.arraycopy(cipherText, 0, encryptData, iv.length, cipherText.length);
                return getPrefix() + Base64.getEncoder().encodeToString(encryptData) + getSuffix();
            } catch (Exception e) {
                log.error("[EncryptDecryptUtil] [encrypt] Encryption Error:{}", originalValue, e);
            }
            return null;
        }
    }

    public static String decrypt(String encryptedValue) {
        if (encryptedValue == null)
            return encryptedValue;
        if (isEncrypted(encryptedValue)) {
            try {
                encryptedValue = encryptedValue.substring(getPrefix().length(), encryptedValue.length() - getSuffix().length());
                SecretKeyFactory factory = SecretKeyFactory.getInstance(KEY_DERIVATION_FUNCTION);
                KeySpec spec = new PBEKeySpec(SALT_KEY.toCharArray(), SALT.getBytes(StandardCharsets.UTF_8), ITERATION_COUNT, KEY_LENGTH_BYTE * 8);
                SecretKey secretKey = factory.generateSecret(spec);
                SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getEncoded(), KEY_ALGORITHM);

                byte[] encryptedData = Base64.getDecoder().decode(encryptedValue);
                byte[] iv = new byte[KEY_LENGTH_BYTE];
                byte[] ciperText = new byte[encryptedData.length - KEY_LENGTH_BYTE];
                //Extract IV value from encrypted data
                System.arraycopy(encryptedData, 0, iv, 0, KEY_LENGTH_BYTE );

                System.arraycopy(encryptedData, KEY_LENGTH_BYTE, ciperText, 0,encryptedData.length - KEY_LENGTH_BYTE );
                GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(128, iv);
                Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
                cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, gcmParameterSpec);
                return new String(cipher.doFinal(ciperText));
            } catch (Exception e) {
                log.error("[EncryptDecryptUtil] [decrypt] Encryption Error:", e);
            }
            return null;
        } else {
            return encryptedValue;
        }
    }

    private static boolean isEncrypted(String value) {
        return value != null && !value.trim().isEmpty() && value.trim().startsWith(getPrefix()) && value.trim().endsWith(getSuffix());
    }
}
