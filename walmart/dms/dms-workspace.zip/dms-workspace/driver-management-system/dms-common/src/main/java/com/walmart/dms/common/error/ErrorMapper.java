package com.walmart.dms.common.error;

import com.walmart.dms.server.common.error.AbstractErrorMapper;

public class ErrorMapper extends AbstractErrorMapper {

	private static final long serialVersionUID = 1L;

	private static final String REGISTRY_ERRORS = "META-INF/errors.json";
	private static final String REGISTRY_ERROR_BUNDLE = "META-INF/error_bundle";

	@Override
	public void readErrorResource() {
		readErrors(REGISTRY_ERRORS, REGISTRY_ERROR_BUNDLE);
	}

}