package com.walmart.dms.common.utils;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Thread utility class.
 *
 * @author a0d02yr
 */
public class ThreadUtil {
    private ThreadUtil() {
    }

    /**
     * Gets a new instance of default thread factory.
     *
     * @param source the source
     * @return a new instance of default thread factory
     */
    public static ThreadFactory defaultThreadFactory(final String source) {
        return new DefaultThreadFactory(source);
    }

    /**
     * Default Thread Factory class. Class implementation is inspired from class java.util.concurrent.Executors.DefaultThreadFactory.
     *
     * @author a0d02yr
     */
    static class DefaultThreadFactory implements ThreadFactory {
        private static final AtomicInteger poolNumber = new AtomicInteger(1);
        private final AtomicInteger threadNumber = new AtomicInteger(1);
        private final String namePrefix;

        /**
         * Creates and returns a new instance of this class initialized with the given parameters.
         *
         * @param source the source
         */
        DefaultThreadFactory(final String source) {
            namePrefix = source + "-" + poolNumber.getAndIncrement() + "-thread-";
        }

        public Thread newThread(final Runnable r) {
            final Thread t = new Thread(r, namePrefix + threadNumber.getAndIncrement());
            if (t.isDaemon())
                t.setDaemon(false);
            if (t.getPriority() != Thread.NORM_PRIORITY)
                t.setPriority(Thread.NORM_PRIORITY);
            return t;
        }
    }
}
