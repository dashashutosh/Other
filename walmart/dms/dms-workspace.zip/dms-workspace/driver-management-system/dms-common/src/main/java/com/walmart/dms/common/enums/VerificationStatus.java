package com.walmart.dms.common.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.util.HashMap;
import java.util.Map;

/**
 * @author a0s0od1
 *
 */
public enum VerificationStatus {
    CREATED("created", 0), APPROVED("approved", 2), DECLINED("declined", 2), NEEDS_REVIEW("needs_review", 1),
    PASSED("passed", 0), NEEDED("needed", 0), EXPIRED("expired", 1), INITIATED("initiated", 0), CANCELED("canceled", 0),
    SUBMITTED("submitted", 0), FAILED("failed", 0), NONE("none", 0), PROCESSED("processed", 0), ACTIVE("active", 0), PUBLISHED("published", 0),
    IN_PROGRESS("in_progress", 0), COMPLETED("completed", 0), NOT_APPLICABLE("not_applicable", 0), INACTIVE("inactive", 0), DRAFT("draft", 0),
    NEW("new", 0), ERRORED("errored", 0), PENDING("pending", 0), READY("ready", 0), REQUIRES_RETRY("requires_retry", 0), CONFIRMED("confirmed", 0),
    REQUESTED("requested", 0), RESOLVED("resolved", 0), NO_RECORD_FOUND("no_record_found",0);

    private String status;
    private Integer priority;

    private static final Map<String, VerificationStatus> statusMap;
    private static final Map<VerificationStatus, Integer> priorityMap;

    static {
        statusMap = new HashMap<>();
        priorityMap = new HashMap<>();

        for(VerificationStatus s : VerificationStatus.values()) {
            statusMap.put(s.status, s);
            priorityMap.put(s, s.priority);
        }
    }

    VerificationStatus(final String status, final Integer priority) {
        this.status = status;
        this.priority = priority;
    }

    @JsonCreator
    public static VerificationStatus getStatus(String status){
        if(!statusMap.containsKey(status)) {
            throw new IllegalArgumentException();
        }
        return statusMap.get(status);
    }

    public static String getStatus(VerificationStatus status){
        return status.status;
    }

    public static Integer getPriority(VerificationStatus status){
        if(!priorityMap.containsKey(status)) {
            throw new IllegalArgumentException();
        }
        return priorityMap.get(status);
    }

}