package com.walmart.dms.common.ccm;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;
import lombok.Data;

@Data
@Configuration(configName = "wfmScheduleAPIConfig")
public class WFMScheduleAPIConfig {

    @Property(propertyName = "wfm.schedule.host.url")
    private String host;

    @Property(propertyName = "wfm.schedule.log.level")
    private String logLevel;

    @Property(propertyName = "wfm.schedule.read.timeout.sec")
    private int readTimeOutInSec;

    @Property(propertyName = "wfm.schedule.connect.timeout.sec")
    private int connectTimeOutInSec;

    @Property(propertyName = "wfm.schedule.api.header")
    private String headers;

    @Property(propertyName = "wfm.schedule.api.retry.count")
    private int retryCount;
}
