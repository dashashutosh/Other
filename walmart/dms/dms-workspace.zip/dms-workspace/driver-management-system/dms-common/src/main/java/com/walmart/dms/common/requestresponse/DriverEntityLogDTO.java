package com.walmart.dms.common.requestresponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;

/**
 * Driver entity log DTO class.
 *
 * @author a0d02yr
 */
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DriverEntityLogDTO {

    private String driverUserId;
    private String driverEmailId;
}
