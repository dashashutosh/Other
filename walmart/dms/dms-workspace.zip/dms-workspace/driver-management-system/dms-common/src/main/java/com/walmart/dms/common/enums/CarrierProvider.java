package com.walmart.dms.common.enums;

public enum CarrierProvider {
	FLEX,
	BRINGG, ASSOCIATE;
}
