package com.walmart.dms.common.enums;

public enum DriverDocumentStatus {
    UPLOAD_DISABLED, UPLOAD_PENDING, VALIDATION_PENDING, VALIDATED, REJECTED, FAILED, EXPIRED, VALID, EXPIRING_SOON;
}
