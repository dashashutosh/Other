package com.walmart.dms.common.enums;

public enum DeactivationType {

	AUTOMATIC,
	MANUAL,
	MANUAL_SUSPEND,  // Suspend triggered from dispatcher UI
	AUTO_SUSPEND,    // Auto suspend from backend
	DELETED,
	NONE,
	REINSTATE
}
