package com.walmart.dms.common.model;


/**
 * @author s0n00k8 on 08/05/19
 */
public class DriverBasePayload {
}
