package com.walmart.dms.common.helper;

import com.google.gson.reflect.TypeToken;
import com.walmart.dms.common.ccm.ApiAuthConfig;
import com.walmart.dms.common.utils.HeaderDTO;
import com.walmart.dms.common.utils.JsonWrapper;
import com.walmart.dms.server.common.error.Error;
import com.walmart.dms.server.common.exception.BusinessException;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Slf4j
@Component
@SuppressFBWarnings
public class ApiAuthHelper {

    @Autowired
    ApiAuthConfig apiAuthConfig;


    public void validateGetDriverPIIConsumerAuth(HeaderDTO headerDTO) throws BusinessException {
        if(apiAuthConfig.dmsApiConsumerIdAuthCheckEnabled){
            Type type = new TypeToken<HashMap<String, HashSet<String>>>() {}.getType();
            Map<String, Set<String>> apiConsumerIds = JsonWrapper.fromJson(apiAuthConfig.getDriverPIIConsumers, type);
            if(!apiConsumerIds.get(headerDTO.getTenantId()).contains(headerDTO.getConsumerId())){
                Error error = new Error("401", "", "ConsumerId Unauthorized to access","");
                throw new BusinessException(error, 401);
            }
        }
    }

    public void validateSearchDriverPIIConsumerAuth(HeaderDTO headerDTO) throws BusinessException {
        if(apiAuthConfig.dmsApiConsumerIdAuthCheckEnabled){
            Type type = new TypeToken<HashMap<String, HashSet<String>>>() {}.getType();
            Map<String, Set<String>> apiConsumerIds = JsonWrapper.fromJson(apiAuthConfig.searchDriverPIIConsumers, type);
            if(!apiConsumerIds.get(headerDTO.getTenantId()).contains(headerDTO.getConsumerId())){
                Error error = new Error("401", "", "ConsumerId Unauthorized to access","");
                throw new BusinessException(error, 401);
            }
        }
    }

    public void validateUpdateDriverPIIDataConsumerAuth(HeaderDTO headerDTO) throws BusinessException {
        if(apiAuthConfig.dmsApiConsumerIdAuthCheckEnabled){
            Type type = new TypeToken<HashMap<String, HashSet<String>>>() {}.getType();
            Map<String, Set<String>> apiConsumerIds = JsonWrapper.fromJson(apiAuthConfig.editDriverPIIDataConsumers, type);
            if(!apiConsumerIds.get(headerDTO.getTenantId()).contains(headerDTO.getConsumerId())){
                Error error = new Error("401", "", "ConsumerId Unauthorized to access","");
                throw new BusinessException(error, 401);
            }
        }
    }

    public void validateGetDriverAuditPIIConsumerAuth(HeaderDTO headerDTO) throws BusinessException {
        if(apiAuthConfig.dmsApiConsumerIdAuthCheckEnabled){
            Type type = new TypeToken<HashMap<String, HashSet<String>>>() {}.getType();
            Map<String, Set<String>> apiConsumerIds = JsonWrapper.fromJson(apiAuthConfig.getDriverPIIAuditDetailsConsumers, type);
            if(!apiConsumerIds.get(headerDTO.getTenantId()).contains(headerDTO.getConsumerId())){
                Error error = new Error("401", "", "ConsumerId Unauthorized to access","");
                throw new BusinessException(error, 401);
            }
        }
    }
}
