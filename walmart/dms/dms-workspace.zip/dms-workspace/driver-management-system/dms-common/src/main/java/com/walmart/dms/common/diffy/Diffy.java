package com.walmart.dms.common.diffy;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.walmart.dms.common.annotations.DiffInclude;
import com.walmart.dms.common.diffy.model.Diff;
import com.walmart.dms.common.diffy.model.ValueChange;

@Component
public class Diffy {

    public Diff compare(Object left, Object right) throws IllegalAccessException, InvocationTargetException, IntrospectionException {
        Diff diff = new Diff();
        if(left == null || right == null) {
            throw new UnsupportedOperationException("null is not allowed for left and right");
        }
        
        Class<?> leftClazz = left.getClass();
        Class<?> rightClazz = right.getClass();
        if(leftClazz != rightClazz) {
            throw new UnsupportedOperationException("both left and right should be of same type");
        }
        boolean hasChange = false;
        List<ValueChange> changes = new ArrayList<>();
        for(Field field : leftClazz.getDeclaredFields()) {
            if(field.isAnnotationPresent(DiffInclude.class)) {
                PropertyDescriptor pd = new PropertyDescriptor(field.getName(), leftClazz);
                Object leftFieldValue = pd.getReadMethod().invoke(left);
                Object rightFieldValue = pd.getReadMethod().invoke(right);
                if(leftFieldValue == null && rightFieldValue == null) {
                    continue;
                } else if((leftFieldValue == null || rightFieldValue == null)
                        || (!leftFieldValue.equals(rightFieldValue))) {
                    hasChange = true;
                    ValueChange change = createValueChange(field, leftFieldValue, rightFieldValue);
                    changes.add(change);
                }
            }
        }
        diff.setHasChange(hasChange);
        diff.setChanges(changes);
        return diff;
    }
    
    private ValueChange createValueChange(Field field, Object leftFieldValue, Object rightFieldValue) {
        ValueChange change = new ValueChange();
        Annotation annotation = field.getAnnotation(DiffInclude.class);
        DiffInclude annotationObj = (DiffInclude) annotation;
        if(StringUtils.isEmpty(annotationObj.name())) {
            change.setPropertyName(field.getName());
        } else {
            change.setPropertyName(annotationObj.name());
        }
        change.setLeft(leftFieldValue);
        change.setRight(rightFieldValue);
        
        return change;
    }
}
