package com.walmart.dms.common.enums;

public enum DriverNotification {
    SMS, EMAIL;
}
