package com.walmart.dms.common.enums;

public enum DriverAccountStatusPersona {
  DEACTIVATED("DRIVER: DEACTIVATED"),
  ACTIVE("DRIVER: ACTIVE"),
  DEACTIVATED_FRAUD("DRIVER: DEACTIVATED FRAUD");

  private final String value;

  DriverAccountStatusPersona(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}