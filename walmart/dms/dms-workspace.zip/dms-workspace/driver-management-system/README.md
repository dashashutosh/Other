# driver-management-system
Driver Management System contains all Last mile delivery drivers related Services such as Onboarding, Scheduling,


To trigger pipeline, just toggle the below flag: flag=true

Steps to Start Service:

1) mvn clean package -DskipTests
2) sh dms-service/stop.sh
3) sh dms-service/start_local.sh

Swagger URL:
http://localhost:8080/swagger-ui/index.html#

# Sonarqube Code Coverage: <br>
[![Quality gate](https://sonar.looper.prod.walmartlabs.com/api/project_badges/quality_gate?project=com.walmart.lms.dms%3Adriver-management-system)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system) <br>
[![Coverage](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=coverage)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system) <br>
[![ncloc](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=ncloc)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system)
[![bugs](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=bugs)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system)
[![vulnerabilities](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=vulnerabilities)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system) <br>
[![sqale_index](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=sqale_index)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system)
[![Code Smells](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=code_smells)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system)
[![duplicated_lines_density](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=duplicated_lines_density)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system) <br>
[![sqale_rating](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=sqale_rating)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system)
[![reliability_rating](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=reliability_rating)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system)
[![security_rating](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=com.walmart.lms.dms%3Adriver-management-system&metric=security_rating)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=com.walmart.lms.dms%3Adriver-management-system)
Collapse



