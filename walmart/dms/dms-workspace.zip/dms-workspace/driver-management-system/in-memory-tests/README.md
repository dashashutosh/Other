### IN-MEMORY Automation Guide.

# Pre-Requisites
- Docker Desktop on MAC (latest version)
- JAVA 1.8 or higher

# How to run the test cases on local

Please refer to the Makefile present inside the in-memory-tests folder. The test execution flow is determined by this file.

- navigate to `/in-memory-tests/` folder
```shell script
cd /path/to/folder/in-memory-tests
```
- run the following command to execute the in-memory tests
```shell script
make in-memory
```
The above command will perform the following steps :

- Checks version of all required tools, if not present should error out
- Builds the app code and in-memory tests using `mvn clean install`
- Builds the later Docker containers for app code and test code.
- Creates a local docker network for testing
- Starts Zookeeper, kafka, mssqldb followed by the app container and test container.

# How to run the test cases from local against any environment: dev, stg, etc

- navigate to `/in-memory-tests/` folder
```shell script
cd /path/to/folder/in-memory-tests
```
- run the following command to execute the in-memory tests
```shell script
make test-url url="http://dmsapi.stg.walmart.com/"
```

# Making changes to the containers configurations

All runtime configuration for the local in-memory automation setup is defined in the 
**docker-compose.yml** which is placed in root of `/in-memory-tests/` folder.

**NOTE** 
- Do not update the variable configurations defined for infrastructure components like
kafka, zookeeper  etc. Only edit app related configurations if necessary.

## Changing Runtime Configurations

### Update Environment variable for app container.

#### Step1
Open the `docker-compose.yml` file located in  `in-memory-tests` folder.

#### Step2
Navigate to `services.dmsservicelocal.environment` , here you can update 
any additional `JAVA_OPTS` which may be needed for the application.

```yaml
  driver-management-system:
    build:
      context: .././
      dockerfile: ./Dockerfile
    container_name: driver-management-system
    ports:
      - "8080:8080"
    environment:
      - JAVA_OPTS=-Xmx3g -Xms3g
        -javaagent:/opt/app/org.jacoco.agent-runtime.jar=address=0.0.0.0,port=36320,output=tcpserver
        -Dserver.port=8080
        -Duser.timezone=UTC
        -Diam.env=qa
        -Diam.clientConsumerId=9366f341-b796-47e9-8571-f00044c980ad
        -Dserver.port=8080 -Duser.timezone=UTC
        -Dcom.walmart.platform.config.runOnEnv=in-memory-local
        -Druntime.context.appName=dms-service
        -Druntime.context.environment=in-memory-local
        -Druntime.context.environmentType=in-memory-local
        -Druntime.context.appName=dms-service
        -Druntime.context.appVersion=0.0.2-SNAPSHOT
        -Druntime.context.system.property.override.enabled=true
        -Dscm.server.access.enabled=true
        -Dscm.snapshot.enabled=true
        -Druntime.context.dms.tenants=0
        -Druntime.context.oneops.env.name=in-memory-local
        -Dcom.walmart.platform.txnmarking.file.path=/dev/null
        -Dcom.walmart.platform.metrics.file.path=/dev/null
        -Dcom.walmart.platform.metrics.file.format=V3JsonMetrics
    volumes:
      - /$PWD/secrets:/secrets
    healthcheck:
      test: curl --fail -s http://localhost:8080/env || exit 1
      interval: 60s
      timeout: 10s
      retries: 3
    networks:
      - app-tier

```
**NOTE** 
- Do not modify other configurations

# CCM scopes created for in-memory
- For local testing, there is a new CCM scope created with the name in-memory-local. All local kafka configs are modified under this ccm scope
- On WCNP pipeline, in-memory-wcnp CCM scope will be used and the kafka configs are modified accordingly.

# How to update the test cases
You can modify existing test cases or add new test cases either in the same class or creating new class. 

- If you create new class, make sure to add the classpath to testng.xml located at `/in-memory-tests/test-suites/testng.xml` to run the test cases similiar to this:
`<class name="com.walmartlabs.services.sparkIncentivePlatform.inmemory.tests.SIPhealthCheckApi"/>`
You can add any number of classes on need basis.

Make the required changes and rerun `make in-memory` command

# Variables referred in the test cases for host details from kitt.yml
- ENV DMS_SERVICE_BASE_URL
- ENV TESTNG_XML="for dev env this value should be testng_dev.xml, for in-memory env it shoudl be testng.xml and for stg env it should be testng_stg.xml"
- rp.launch

# How to update the api payload used to hit the endpoints

- Navigate to `/in-memory-tests/src/tests/resources/test_data/environment_name/`
- update the payload as necessary and rerun `make in-memory` command

# Reporting Dashboard 
We use Report Portal as the reporting dashboard. As part of the in-memory setup, we create a new project for each application
The config attributes for report portal are located at `/in-memory-tests/src/main/resources/reportportal.properties`

**NOTE** 
- Please do not modify these configurations under reportportal.properties file

- URL:
  `http://sct-inmemory-reports.walmart.com/ui/`
- Login Credentials:

  `Username/Password: dms/inmemory`
  
#Further Code Changes in Detail
Please refer to this confluence page to go through the code changes as part of the in-memory automation framework

`https://confluence.walmart.com/pages/viewpage.action?spaceKey=LABS&title=WCNP+Related+Changes+For+In-memory+Automation`