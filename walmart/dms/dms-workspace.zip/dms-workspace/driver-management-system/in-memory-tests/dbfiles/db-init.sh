#!/bin/sh

#wait for the SQL Server to come up
sleep 10s
echo "running set up script-------1"

chmod +x /usr/src/app/*
#chmod +x /usr/src/app/usap_batch.sql
#chmod +x /usr/src/app/usap_quartz.sql

/opt/mssql-tools/bin/sqlcmd -S localhost -U SA -P Welcome123 -i /usr/src/app/MSSQL_DDL_NEW_DMS0909.sql &&
/opt/mssql-tools/bin/sqlcmd -S localhost -U SA -P Welcome123 -i /usr/src/app/MSSQL_DDL_NEW_QUARTZ.sql

sleep 10s
echo "DB is available now"