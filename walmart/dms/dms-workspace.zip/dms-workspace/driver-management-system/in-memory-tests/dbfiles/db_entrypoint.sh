#!/bin/bash

chmod +x /usr/src/app/db-init.sh
/opt/mssql/bin/sqlservr --accept-eula & /usr/src/app/db-init.sh & sleep infinity & wait
