/* eslint-disable no-console */
const {
  exec
} = require('child_process');
const lintProcess = () => {
  const command = 'cd ../../../../; node_modules/.bin/eslint src/client/pages/stride-ui-trip-management --fix';
  console.log(`executing lint command: ${command}`);
  exec('cd ../../../../; node_modules/.bin/eslint src/client/pages/stride-ui-trip-management', (error, stdout, stderr) => {
    if (stdout.length === 0 && stdout.length === 0 && error === null) console.log('lint successful');
    if (stdout.length > 0) console.log(`stdout: ${stdout}`);
    if (stderr.length > 0) console.log(`stderr: ${stderr}`);
    if (error !== null) console.log(`exec error: ${error}`);
  });
};
lintProcess();