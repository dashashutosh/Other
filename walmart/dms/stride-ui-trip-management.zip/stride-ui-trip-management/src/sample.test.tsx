import { Utilities } from '@gscope-mfe/app-bridge';
import { Loader as _Loader } from '@gscope-mfe/common-components';
import { render, screen } from '@testing-library/react';

const Loader = _Loader.default;

describe('yo suite', () => {
    it('some test', async () => {
        const environments = await Utilities.convertMapToList({});
        expect(environments).toStrictEqual([]);
    });
    it('some test1', () => {
        const { debug } = render(<Loader show={true} />);
        // screen.getByRole('progressbar')
        debug();
        expect(screen.getByRole('progressbar')).toBeInTheDocument();
    });
});
