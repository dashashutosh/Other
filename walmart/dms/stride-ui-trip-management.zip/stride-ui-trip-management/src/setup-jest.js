// eslint-disable-next-line @typescript-eslint/no-var-requires
global.crypto = require('crypto').webcrypto;
