import PhaseTypesEnum from './utils/enums/PhaseTypesEnum';
import { groupByList } from './component/trip-management-summary/US/DataModelsUS.js';
export const planTableHeadCellsUS = (trans, cmsConfig, groupBy) => [
    {
        id: 'planId',
        label: 'planColumns.planId',
        sortField: cmsConfig?.sortFields?.PLAN_ID,
    },
    {
        id: 'tags',
        label: 'planColumns.tags',
    },
    {
        id: 'planEntity',
        label: 'planColumns.planType',
        sortField: cmsConfig?.sortFields?.PLAN_TYPE ? cmsConfig?.sortFields?.PLAN_TYPE : undefined,
    },
    {
        id: 'originId',
        label: 'planColumns.origin',
        sortField:
            groupBy === groupByList[1].id
                ? cmsConfig?.sortFields?.LOAD_ORIGIN_LOCATION_ID
                : cmsConfig?.sortFields?.ORIGIN_LOCATION_ID,
    },
    { id: 'comments', label: 'planColumns.comments' },
    {
        id: 'distance',
        label: trans('planColumns.distance'),
        uom: cmsConfig?.UOM?.distance,
        sortField: cmsConfig?.sortFields?.DISTANCE ? cmsConfig?.sortFields?.DISTANCE : undefined,
    },
    {
        id: 'destinationId',
        label: 'planColumns.drayFinalDestination',
        sortField:
            groupBy === groupByList[1].id
                ? cmsConfig?.sortFields?.LOAD_DESTINATION_LOCATION_ID
                : cmsConfig?.sortFields?.DESTINATION_LOCATION_ID,
    },
    {
        id: 'priDestinationId',
        label: 'planColumns.priDestination',
        sortField: cmsConfig?.sortFields?.PRIMARY_DESTINATION_LOCATION_ID,
    },
    { id: 'dwellDays', label: 'planColumns.dwellDays' },
    {
        id: 'priority',
        label: 'planColumns.priority',
    },
    {
        id: 'plannedStart',
        label: 'planColumns.drayPlannedStart',
        sortField: cmsConfig?.sortFields?.PLANNED_START,
    },
    {
        id: 'actualStart',
        label: 'planColumns.drayActualStart',
        sortField: cmsConfig?.sortFields?.ACTUAL_START ? cmsConfig?.sortFields?.ACTUAL_START : undefined,
    },
    {
        id: 'plannedEnd',
        label: 'planColumns.plannedEnd',
        sortField: cmsConfig?.sortFields?.PLANNED_END ? cmsConfig?.sortFields?.PLANNED_END : undefined,
    },
    {
        id: 'actualEndDate',
        label: 'planColumns.actualEndDate',
    },
    {
        id: 'EndDateEstimated',
        label: 'planColumns.EndDateEstimated',
    },
    // { id: 'sequence', label: 'planColumns.sequence' },
    {
        id: 'duration',
        label: 'planColumns.duration',
        uom: cmsConfig?.UOM?.duration,
        sortField: cmsConfig?.sortFields?.DURATION ? cmsConfig?.sortFields?.DURATION : undefined,
    },
    {
        id: 'nextStop',
        label: 'planColumns.nextStop',
        sortField: cmsConfig?.sortFields?.NEXT_STOP ? cmsConfig?.sortFields?.NEXT_STOP : undefined,
    },
    {
        id: 'noOfStopsRemaining',
        label: 'planColumns.noOfStopsRemaining',
        sortField: cmsConfig?.sortFields?.NEXT_STOP_REMAINING ? cmsConfig?.sortFields?.NEXT_STOP_REMAINING : undefined,
    },
    {
        id: 'billsByTime',
        label: 'planColumns.billsByTime',
        sortField: cmsConfig?.sortFields?.BILLS_BY_TIME ? cmsConfig?.sortFields?.BILLS_BY_TIME : undefined,
    },
    {
        id: 'pickupStops',
        label: 'planColumns.pickupStops',
        sortField: cmsConfig?.sortFields?.PICKUP_STOPS ? cmsConfig?.sortFields?.PICKUP_STOPS : undefined,
    },
    {
        id: 'deliveryStops',
        label: 'planColumns.deliveryStops',
        sortField: cmsConfig?.sortFields?.DELIVERY_STOPS ? cmsConfig?.sortFields?.DELIVERY_STOPS : undefined,
    },
    {
        id: 'planStatusLabel',
        label: 'planColumns.status',
    },
    {
        id: 'planStatusMultiLabel',
        label: 'planColumns.multiStatus',
    },
    {
        id: 'actions',
        label: 'planColumns.actions',
    },
];
export const commonColumnHeaders = (cmsConfig) => [
    {
        id: 'carrierId',
        label: 'planColumns.carrier',
        sortField: cmsConfig?.sortFields?.CARRIER_ID ? cmsConfig?.sortFields?.CARRIER_ID : undefined,
    },
    {
        id: 'serviceTerritory',
        label: 'planColumns.serviceTerritory',
        sortField: cmsConfig?.sortFields?.SERVICE_TERRITORY ? cmsConfig?.sortFields?.SERVICE_TERRITORY : undefined,
    },

    { id: 'tripServiceTerritory', label: 'planColumns.tripServiceTerritory' },
    { id: 'planningServiceTerritory', label: 'planColumns.planningServiceTerritory' },
    {
        id: 'trailerId',
        label: 'planColumns.drayEquipmentID',
        sortField: cmsConfig?.sortFields?.TRAILER_ID ? cmsConfig?.sortFields?.TRAILER_ID : undefined,
    },
    {
        id: 'driverId',
        label: 'planColumns.driverId',
        sortField: cmsConfig?.sortFields?.DRIVER_ID ? cmsConfig?.sortFields?.DRIVER_ID : undefined,
    },
];
export const excludedColumnsForPlanning = [
    'actualEndDate',
    'EndDateEstimated',
    'carrierId',
    'serviceTerritory',
    'tripServiceTerritory',
    'planningServiceTerritory',
    'driverId',
    'billsByTime',
    'actualStart',
    'nextStop',
    'noOfStopsRemaining',
    'planStatusMultiLabel',
];

export const toteExchangeMustShip = 'TOTE_EXCHANGE_MUST_SHIP';

export const excludedColumnsForProcessing = [
    'actualEndDate',
    'EndDateEstimated',
    'actualStart',
    'nextStop',
    'noOfStopsRemaining',
    'planStatusLabel',
];
export const excludedColumnsForReadyToStart = [
    'actualEndDate',
    'EndDateEstimated',
    'actualStart',
    'nextStop',
    'noOfStopsRemaining',
    'planStatusMultiLabel',
];
export const excludedColumnsForIntransit = ['dwellDays', 'actualEndDate', 'planStatusMultiLabel'];
export const excludedColumnsForDelivered = [
    'dwellDays',
    'nextStop',
    'EndDateEstimated',
    'noOfStopsRemaining',
    'planStatusMultiLabel',
];

export const priDestinationColumnId = 'priDestinationId';
export const comments = 'comments';
export const dwellDaysColumnId = 'dwellDays';
export const tripServiceTerritoryColumnId = 'tripServiceTerritory';
export const planningServiceTerritoryColumnId = 'planningServiceTerritory';
export const serviceTerritoryColumnId = 'serviceTerritory';
export const tagsId = 'tags';

export const timeHorizonLabels = (trans) => ({
    thLabel: trans('timeHorizon.label.scopeLabel'),
    buttonCancel: trans('timeHorizon.button.cancel'),
    buttonConfirm: trans('timeHorizon.button.confirm'),
    customTime: trans('timeHorizon.label.timeframe'),
    modalTitle: trans('timeHorizon.label.title'),
    horizon: trans('timehorizon.label.horizon'),
    uom: trans('timehorizon.label.uom'),
    customValidation: trans('timehorizon.custom.validation'),
});
export const regexPast = /Past: (\d+) days/i;
export const regexFuture = /Future: (\d+) days/i;
export const optionsDateTransform = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
};
export const USER_PREF_PAGE_NAME = 'us_tripManagementUserTimeHorizons';
export const timeHorizonData = [
    {
        id: '1',
        value: '6',
        hrValue: 6,
    },
    {
        id: '2',
        value: '12',
        hrValue: 12,
    },
    {
        id: '3',
        value: '24',
        hrValue: 24,
    },
    {
        id: '4',
        value: '48',
        hrValue: 48,
    },
    {
        id: '5',
        value: '72',
        hrValue: 72,
    },
    {
        id: '0',
        value: 'Custom',
        hrValue: 0,
    },
];
export const defaultTimeHorizon = 48;
export const planSearchHeadersUS = [
    'planId',
    'hazmat',
    'hazmatAbbr',
    'printed',
    'printedAbbr',
    'planEntity',
    'originId',
    'comments',
    'originName',
    'destinationId',
    'destinationName',
    'dwellDays',
    'priDestinationId',
    'priDestinationType',
    'priDestinationCity',
    'priDestinationProvince',
    'distance',
    'originType',
    'destinationType',
    'duration',
    'carrierId',
    'serviceTerritory',
    'tripServiceTerritory',
    'planningServiceTerritory',
    'billsByTime',
    'trailerId',
    'driverName',
    'driverId',
    'originCity',
    'destinationCity',
    'noOfPickupStops',
    'noOfDropoffStops',
    'nextStop',
    'planType',
    'departureTs',
    'originProvince',
    'destinationProvince',
    'actualTs',
    'endDatePlanned',
    'priority',
    'routeNumber',
];
export const pinnableColumns = ['planId', 'tags', 'planEntity', 'planStatusMultiLabel', 'planStatusLabel', 'actions'];
export const dreyIntroducedColumns = [
    {
        columnName: 'trailerId',
        index: [PhaseTypesEnum.PLANNING.index],
    },
    {
        columnName: 'actions',
        index: [
            PhaseTypesEnum.PLANNING.index,
            PhaseTypesEnum.PROCESSING.index,
            PhaseTypesEnum.DISPATCH_PENDING.index,
            PhaseTypesEnum.DELIVERED.index,
        ],
    },
    {
        columnName: 'plannedEnd',
        index: [
            PhaseTypesEnum.PLANNING.index,
            PhaseTypesEnum.PROCESSING.index,
            PhaseTypesEnum.DISPATCH_PENDING.index,
            PhaseTypesEnum.IN_TRANSIT.index,
            PhaseTypesEnum.DELIVERED.index,
        ],
    },
    {
        columnName: 'plannedStart',
        index: [PhaseTypesEnum.IN_TRANSIT.index, PhaseTypesEnum.DELIVERED.index],
    },
    {
        columnName: 'EndDateEstimated',
        index: [PhaseTypesEnum.IN_TRANSIT.index],
    },
    {
        columnName: 'actualEndDate',
        index: [PhaseTypesEnum.DELIVERED.index],
    },
    {
        columnName: 'priority',
        index: [
            PhaseTypesEnum.PLANNING.index,
            PhaseTypesEnum.PROCESSING.index,
            PhaseTypesEnum.DISPATCH_PENDING.index,
            PhaseTypesEnum.IN_TRANSIT.index,
            PhaseTypesEnum.DELIVERED.index,
        ],
    },
    {
        columnName: 'comments',
        index: [
            PhaseTypesEnum.PLANNING.index,
            PhaseTypesEnum.PROCESSING.index,
            PhaseTypesEnum.DISPATCH_PENDING.index,
            PhaseTypesEnum.IN_TRANSIT.index,
            PhaseTypesEnum.DELIVERED.index,
        ],
    },
];
export const toastTimerUS = 4000;
export const regexNumComma = new RegExp(/^[0-9]*([,\t\n][0-9]+)*$/);
export const timeHorizonDateFormat = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
export const defaultMaxTimeHorizonHours = 192;
export const DATE_FNS_DATE_TIME_FORMAT = 'dd MMM, yyyy, hh:mm aaa';
export const timeZone = 'America/New_York';
export const DATE_FNS_FORMAT = 'dd MMM, yyyy; HH:mm';
export const GlobalSearchOption = [
    {
        id: '1',
        value: 'global.search.placeholder.option.load',
    },
    {
        id: '2',
        value: 'global.search.placeholder.option.trip',
    },
];
export const ExceptionFilters = [
    {
        id: 1,
        code: 'PICKUP_96_HOURS_AWAY',
        abbr: 'exception.planned.pickup.96.hours.away',
        description: 'exception.planned.pickup.96.hours.away',
        type: 'warning',
        phases: ['2'],
    },
    {
        id: 2,
        code: 'PICKUP_IN_PAST',
        abbr: 'exception.planned.pickup.in.past.date',
        description: 'exception.planned.pickup.in.past.date',
        type: 'error',
        phases: ['2'],
    },
    {
        id: 3,
        code: 'PICKUP_GREATER_THAN_24_HOURS_IN_PAST',
        abbr: 'exception.planned.pickup.less.than.24.hours.in.past',
        description: 'exception.planned.pickup.less.than.24.hours.in.past',
        type: 'warning',
        phases: ['3'],
    },
    {
        id: 4,
        code: 'PICKUP_GREATER_THAN_72_HOURS_IN_PAST',
        abbr: 'planned.pickup.less.than.72.hours.in.past',
        description: 'planned.pickup.less.than.72.hours.in.past',
        type: 'error',
        phases: ['3'],
    },
    {
        id: 5,
        code: 'TOTE_EXCHANGE_MUST_SHIP',
        abbr: 'exception.must.ship',
        description: 'exception.must.ship',
        type: 'warning',
        phases: ['2'],
        label: 'label.view.plans',
    },
];
