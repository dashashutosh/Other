import React, { Suspense } from 'react';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { Router, Switch, Route, Link } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import {
    MaterialUiCore,
    MaterialUiPickers,
    MomentUtils,
    // @ts-ignore
} from '@gscope-mfe/common-libs';
// @ts-ignore
import { gscopeTheme, Loader } from '@gscope-mfe/common-components';
// @ts-ignore
import { AppUtils } from '@gscope-mfe/app-bridge';

import useLoadSupportedLangs from './hooks/useLoadSupportedLangs';

import '@walmart/living-design-sc-ui/src/www/styles.css';
import '@walmart/stride-ui-commons/dist/es/style.css';

const TripManagementSummary = React.lazy(() => import('./component/trip-management-summary'));
const AssignTrip = React.lazy(() => import('./component/assign-trip'));

const history = createBrowserHistory();
const { MuiPickersUtilsProvider } = MaterialUiPickers;
const { ThemeProvider } = MaterialUiCore;
const { default: LoaderComponent } = Loader;

export default function Root() {
    const { currentMarket } = AppUtils.get();
    useLoadSupportedLangs(currentMarket);

    return (
        <div id="single-spa-application:@stride-mfe/trip-management">
            <Suspense fallback={<LoaderComponent show />}>
                <MuiPickersUtilsProvider utils={MomentUtils}>
                    <ThemeProvider theme={gscopeTheme}>
                        <Router history={history}>
                            <Switch>
                                <Route path="/mfe/stride/tripmanagement" exact>
                                    <TripManagementSummary />
                                </Route>

                                <Route path="/mfe/stride/tripmanagement/assign-trip" exact>
                                    <AssignTrip />
                                </Route>
                            </Switch>
                        </Router>
                    </ThemeProvider>
                </MuiPickersUtilsProvider>
            </Suspense>
        </div>
    );
}
