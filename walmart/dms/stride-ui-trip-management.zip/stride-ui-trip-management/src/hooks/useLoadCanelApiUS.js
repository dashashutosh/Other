import { useCallback, useEffect } from 'react';
import { UIPlanTypeEnum, withdrawTender } from '@walmart/stride-ui-commons';
import { BASE_URL } from '../../Constants';
import axios from '../axios';
import { AppUtils } from '@gscope-mfe/app-bridge';
const useLoadCanelApiUS = (setterFns) => {
    const { loading, currentMarket, setloading, prefLang, userInfo } = AppUtils.get();
    const { setsFetchPlanError, setsIsSuccess } = setterFns;
    const APIParams = {
        axios,
        currentMarket,
        language: prefLang.current,
        userId: userInfo.loggedInUserName,
        hostname: window.location.hostname,
        userName: userInfo.displayName,
        timeout: 30000,
        usUsTenant: true,
        // TODO: check if it is needed
        usUsTenantFlag: true,
        baseUrl: BASE_URL,
    };
    const withdrawTenderServiceCCM = {
        ccmServiceName: 'stride-ui-trip-management-withdrawTender',
        ccmRouteName: 'withdrawTender',
    };
    const { callAPI: withdrawTenderAPI, ...withdrawTenderResponse } = withdrawTender({
        ...APIParams,
        ...withdrawTenderServiceCCM,
        planType: UIPlanTypeEnum.LOAD,
    });
    useEffect(() => {
        const isLoading = withdrawTenderResponse.loading;
        if (loading) {
            if (!isLoading) {
                setloading(false);
            }
        } else if (isLoading) {
            setloading(true);
        }
    }, [withdrawTenderResponse.loading]);
    const handlePlanAction = useCallback(
        (params) => {
            withdrawTenderAPI(
                params,
                () => {
                    setsIsSuccess('msg.cancelTenderSuccess');
                },
                (err) => {
                    setsFetchPlanError(err?.errors[0]?.description);
                },
            );
        },
        [withdrawTenderAPI],
    );
    return {
        handlePlanAction,
        APIParams,
    };
};
export default useLoadCanelApiUS;
