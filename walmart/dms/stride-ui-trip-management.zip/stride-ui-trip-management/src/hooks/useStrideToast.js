import { useCallback } from 'react';
import { useToast as usLDToast } from '@walmart/living-design-sc-ui';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { stTripToast } from '../utils/StyleUtils';
import { toastTimer } from '../Constants';

const { makeStyles } = MaterialUiCore;

const useToastStyles = makeStyles({
    stTripToast,
});

const useStrideToast = () => {
    const ldToast = usLDToast();
    const classes = useToastStyles();

    const toast = useCallback((props) => {
        ldToast({
            delay: toastTimer,
            className: classes.stTripToast,
            ...props,
        });
    }, []);

    return toast;
};

export default useStrideToast;
