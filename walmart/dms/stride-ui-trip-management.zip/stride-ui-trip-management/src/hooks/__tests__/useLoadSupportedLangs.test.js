import { renderHook } from '@testing-library/react-hooks';

import { useLoadSupportedLanguages } from '@walmart/stride-ui-commons';
import useLoadSupportedLangs from '../useLoadSupportedLangs';

// import { loadI18n } from '../../../../components/common/LocalizeLang';
import { LocalizeLang } from '@gscope-mfe/common-components';

import enData from '../../lang/en.json';
import esData from '../../lang/es.json';

// jest.mock('../../../../components/common/LocalizeLang/index.js', () => ({
//     loadI18n: jest.fn().mockImplementation(() => {}),
// }));
const { loadI18n } = LocalizeLang.default;
jest.mock('@walmart/stride-ui-commons', () => ({
    useLoadSupportedLanguages: jest.fn().mockImplementationOnce(() => {}),
}));

const languageDataMap = {
    en: enData,
    es: esData,
};

describe('useLoadSupportedLangs', () => {
    it('should call useLoadSupportedLanguages', () => {
        renderHook(() => useLoadSupportedLangs('us'));
        expect(useLoadSupportedLanguages).toHaveBeenCalledWith({ market: 'us', loadI18n, languageDataMap });
    });
});
