import { useEffect } from 'react';
import { useLoadSupportedLanguages } from '@walmart/stride-ui-commons';
import TripSharedService from '../service/TripSharedService';
import enData from '../lang/en.json';
import esData from '../lang/es.json';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { loadI18n } = LocalizeLang.default;
const languageDataMap = {
    en: enData,
    es: esData,
};
const useLoadSupportedLangs = (market) => {
    const trans = useLoadSupportedLanguages({
        market,
        loadI18n,
        languageDataMap,
    });
    useEffect(() => {
        TripSharedService.setTrans(trans);
    }, [trans]);
    return trans;
};
export default useLoadSupportedLangs;
