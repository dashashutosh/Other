import { useCallback, useEffect, useMemo } from 'react';
import {
    useAPI,
    approveLoadOrTrip,
    cancelLoad,
    downloadDisptachDocuments,
    LoadActionsEnum,
    TripActionsEnum,
    updateTimeline,
    UIPlanTypeEnum,
} from '@walmart/stride-ui-commons';
import {
    formatApproveTripRequest,
    formatForceToDeleverTripRequest,
} from '../component/trip-management-summary/US/DataModelsUS';
import { TripAPI } from '../service/TripAPI';
import { BASE_URL } from '../Constants';
import axios from '../axios';
import { AppUtils } from '@gscope-mfe/app-bridge';

const usePlanActionsApiUS = (planIds) => {
    const { loading, currentMarket, setloading, prefLang, userInfo } = AppUtils.get();

    const APIParams = {
        axios,
        currentMarket,
        language: prefLang.current,
        userId: userInfo.loggedInUserName,
        hostname: window.location.hostname,
        userName: userInfo.displayName,
        timeout: 30000,
        baseUrl: BASE_URL,
    };

    const TripApi = useMemo(
        () => TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName),
        [currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName],
    );
    const cancelTripServiceCCM = {
        ccmServiceName: 'stride-ui-trip-management-cancelTrip',
        ccmRouteName: 'cancelTrip',
    };

    const cancelRelayTripServiceCCM = {
        ccmServiceName: 'stride-ui-trip-management-cancelRelayTrip',
        ccmRouteName: 'cancelRelayTrip',
    };

    // Todo: Needs to check in next releases
    const DownloadDispatchDocAndLabelAPI = () => {
        const getDownloadResponse = (req) =>
            Promise.all([
                downloadDisptachDocuments(APIParams).getDispatchDocument(req),
                downloadDisptachDocuments(APIParams).getDispatchLabel(req),
            ]);
        return {
            getDownloadResponse,
        };
    };
    const { callAPI: planApproveCallApi, ...planApproveResponse } = approveLoadOrTrip(APIParams);
    const { callAPI: loadCancelCallApi, ...loadCancelResponse } = cancelLoad(APIParams);

    const { callAPI: tripCancelCallApi, ...tripCancelResponse } = cancelLoad({
        ...APIParams,
        ...cancelTripServiceCCM,
        planType: UIPlanTypeEnum.TRIP,
    });

    const { callAPI: relayTripCancelCallApi, ...relayTripCancelResponse } = cancelLoad({
        ...APIParams,
        ...cancelRelayTripServiceCCM,
        planType: UIPlanTypeEnum.TRIP,
    });

    const { callAPI: generateTripSheetCallApi, ...generateTripSheetResponse } = useAPI(
        DownloadDispatchDocAndLabelAPI().getDownloadResponse,
    );
    const { callAPI: updateTrackingPlanApi, ...updateTrackingPlanResponse } = useAPI(TripApi.updateTrackingPlan);
    const { callAPI: updateTimelineApi, ...updateTimelineResponse } = updateTimeline(APIParams);
    useEffect(() => {
        const isLoading =
            planApproveResponse.loading ||
            loadCancelResponse.loading ||
            tripCancelResponse.loading ||
            relayTripCancelResponse.loading ||
            updateTrackingPlanResponse.loading ||
            generateTripSheetResponse.loading ||
            updateTimelineResponse.loading;

        if (loading) {
            if (!isLoading) {
                setloading(false);
            }
        } else if (isLoading) {
            setloading(true);
        }
    }, [
        planApproveResponse.loading,
        loadCancelResponse.loading,
        tripCancelResponse.loading,
        relayTripCancelResponse.loading,
        generateTripSheetResponse.loading,
        updateTrackingPlanResponse.loading,
        updateTimelineResponse.loading,
    ]);

    const handleTripAction = useCallback(
        (action, params, successCb, failureCb) => {
            switch (action) {
                case TripActionsEnum.CANCEL.name:
                    tripCancelCallApi(
                        { planIds, params },
                        (res) => {
                            if (
                                res?.tripDetails?.payload?.length &&
                                res?.tripDetails?.payload[0] &&
                                res?.planDetails?.payload?.length &&
                                res?.planDetails?.payload[0]
                            ) {
                                if (successCb) successCb();
                            }
                        },
                        (err) => {
                            if (failureCb) failureCb(err);
                        },
                    );
                    break;
                case TripActionsEnum.CANCEL_RELAY.name:
                    relayTripCancelCallApi(
                        { planIds, params },
                        (res) => {
                            if (res) {
                                if (successCb) successCb();
                            }
                        },
                        (err) => {
                            if (failureCb) failureCb(err);
                        },
                    );
                    break;
                default:
                    break;
            }
        },
        [tripCancelCallApi, relayTripCancelCallApi],
    );

    const handlePlanAction = useCallback(
        (action, params, successCb, failureCb) => {
            switch (action) {
                case LoadActionsEnum.APPROVE.name:
                    planApproveCallApi(
                        formatApproveTripRequest(params),
                        (res) => {
                            if (successCb) successCb(res);
                        },
                        (err) => {
                            if (failureCb) failureCb(err);
                        },
                    );
                    break;

                case LoadActionsEnum.CANCEL.name:
                    loadCancelCallApi(
                        { planIds, params },
                        (res) => {
                            if (res?.payload?.length && res?.payload[0]) {
                                if (successCb) successCb();
                            }
                        },
                        (err) => {
                            if (failureCb) failureCb(err);
                        },
                    );
                    break;

                case TripActionsEnum.GENERATE_TRIP_SHEET.name:
                    generateTripSheetCallApi(
                        {
                            planId: params,
                        },
                        (res) => {
                            if (successCb) successCb(res);
                        },
                        (err) => {
                            if (failureCb) failureCb(err);
                        },
                    );
                    break;
                case TripActionsEnum.FORCE_TO_DELIVERED.name:
                    updateTrackingPlanApi(
                        formatForceToDeleverTripRequest(params),
                        (res) => {
                            if (res) {
                                if (successCb) successCb(res);
                            }
                        },
                        (err) => {
                            if (failureCb) failureCb(err);
                        },
                    );
                    break;
                case LoadActionsEnum.UPDATE_TIMELINE.name:
                    updateTimelineApi(
                        params,
                        (res) => {
                            if (res) {
                                if (successCb) successCb(res);
                            }
                        },
                        (err) => {
                            if (failureCb) failureCb(err);
                        },
                    );
                    break;
                default:
                    break;
            }
        },
        [planApproveCallApi, loadCancelCallApi],
    );

    return {
        handleTripAction,
        handlePlanAction,
    };
};

export default usePlanActionsApiUS;
