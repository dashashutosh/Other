import { MarketCodeEnum, getEnvironment } from '@walmart/stride-ui-commons';
import PlanStatusEnum from './utils/PlanStatusEnum';
import enData from './lang/en.json';
import esData from './lang/es.json';
export const pageStaticDataRequest = {
    data_elements: ['carriers'],
};

export const MODULE_NAME = 'stride-ui-trip-management';
export const USER_PREF_PAGE_TIME_HORIZON = 'tripManagementTimeHorizonV2';
export const USER_PREF_PROFILE = 'strideTripManagementProfile';
export const USER_PREF_PAGE_NAME = 'strideTripManagementProfile';
export const USER_PREF_FAV_BG_KEY = 'tripManagementProfileSelected';
export const STRIDE_UI_TM_PROFILE_LINK_MFE = '/mfe/stride/trip-management-profile';
export const STRIDE_UI_TM_PROFILE_LINK_NON_MFE = '/stride/trip-management-profile';
export const USER_PREF_NAME_V2 = 'strideTripManagementProfileV2';
export const defaultDeliveredDays = '2';
export const defaultTimeout = 30000;
export const EMPTY_ITEM_NAME = 'Unnamed Item';
export const timeHorizonDateFormat = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
export const optionsDateTransform = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
};
export const planTableHeadCells = [
    {
        id: 'planId',
        label: 'planColumns.planId',
    },
    {
        id: 'planEntity',
        label: 'planColumns.planType',
        sortField: 'PLAN_TYPE',
    },
    {
        id: 'originId',
        label: 'planColumns.origin',
        sortField: 'PLAN_ORIGIN_LOCATION_ID',
    },
    {
        id: 'distance',
        label: 'planColumns.distance',
    },
    {
        id: 'destinationId',
        label: 'planColumns.destination',
        sortField: 'PLAN_DESTINATION_LOCATION_ID',
    },
    {
        id: 'noOfStops',
        label: 'planColumns.noOfStopsInTransit',
    },
    {
        id: 'laneId',
        label: 'planColumns.laneId',
    },
    {
        id: 'rate',
        label: 'planColumns.rate',
    },
    { id: 'mode', label: 'planColumns.mode', sortField: 'MODE' },
    {
        id: 'carrierId',
        label: 'planColumns.carrier',
        sortField: 'PLAN_CARRIER_ID',
    },
    {
        id: 'carrierStatus',
        label: 'planColumns.carrierStatus',
    },
    {
        id: 'equipmentType',
        label: 'planColumns.equipmentType',
    },
    {
        id: 'equipmentId',
        label: 'planColumns.equipmentId',
    },
    {
        id: 'driver',
        label: 'planColumns.driver',
    },
    {
        id: 'cases',
        label: 'planColumns.cases',
    },
    {
        id: 'pallets',
        label: 'planColumns.pallets',
    },
    {
        id: 'cube',
        label: 'planColumns.cube',
    },
    {
        id: 'weight',
        label: 'planColumns.weight',
    },
    {
        id: 'departureTs',
        label: 'planColumns.departureDateTime',
    },
    {
        id: 'arrivalTs',
        label: 'planColumns.arrivalDateTime',
    },
    {
        id: 'createdTs',
        label: 'planColumns.createdDateTime',
        sortField: 'PLAN_CREATED_TIME',
    },
    {
        id: 'planStatusLabel',
        label: 'planColumns.planStatus',
        sortField: 'PLAN_STATUS',
    },
];
export const excludedColumnsForPlanning = [
    'laneId',
    'rate',
    'carrierId',
    'carrierStatus',
    'equipmentId',
    'driver',
    'mode',
];
export const excludeColumnsForTrip = [...excludedColumnsForPlanning, 'planEntity'];
export const excludedColumnsForProcessing = ['laneId', 'rate'];
export const planSearchHeaders = [
    'planId',
    'loadType',
    'originId',
    'originName',
    'destinationId',
    'destinationName',
    'distance',
    'noOfStops',
    'equipmentLength',
    'protectionLevel',
    'cases',
    'pallets',
    'cube',
    'weight',
    'departureTs',
    'arrivalTs',
    'createdTs',
    'planStatusLabel',
    'carrierId',
    'carrierStatus',
    'equipmentId',
    'equipmentType',
    'driverName',
    'driverId',
    'laneId',
    'rate',
    'rateType',
    'planEntity',
    'originCity',
    'destinationCity',
    'transitDetailMode',
    'carrier',
    'weight',
    'noOfPickupStops',
    'noOfDropoffStops',
    'serviceType',
    'class',
    'loadMode',
    'loadServiceLevel',
    'tempControl',
    'hazmat',
    'timeLeftToRespond',
    'carrierLeft',
    'equipmentIdReq',
    'enrouteMilestone',
    'nextStop',
    'noOfStopsLeft',
    'loadLevelType',
    'referenceLoadType',
];
export const UOMHeaders = [
    'planColumns.cases',
    'planColumns.pallets',
    'planColumns.cube',
    'planColumns.weight',
    'planColumns.distance',
];
export const toastTimer = 2000;
export const trailerAssignmentTypes = [
    {
        id: 0,
        value: 'singleTrailer',
        label: 'label.singleTrailer',
    },
    {
        id: 1,
        value: 'onLoadCount',
        label: 'label.onLoadCount',
    },
];
export const colors = {
    white: '#fff',
    labelGrey: '#74767c',
};
export const connectLoads = [
    {
        id: 'BOB',
        value: 'label.bobtail',
    },
    {
        id: 'DHD',
        value: 'label.deadhead',
    },
];
export const camCountries = [
    MarketCodeEnum.COSTA_RICA.name.toLowerCase(),
    MarketCodeEnum.NICARAGUA.name.toLowerCase(),
    MarketCodeEnum.HONDURAS.name.toLowerCase(),
    MarketCodeEnum.GUATEMALA.name.toLowerCase(),
    MarketCodeEnum.EL_SALVADOR.name.toLowerCase(),
    MarketCodeEnum.MEXICO.name.toLowerCase(),
    MarketCodeEnum.MEXICO_MARKET_PLACE.name.toLowerCase(),
];
export const loadTypeSTR = 'STR';
export const equipmentTypesSeg = [
    {
        id: 0,
        value: 'trailerTractor',
        label: 'workloadAssignment.label.trailerTractor',
    },
    {
        id: 1,
        value: 'truck',
        label: 'workloadAssignment.label.truck',
        equipment: [],
    },
];
export const EquipmentTypeEnum = {
    TRACTOR: 'TRACTOR',
    TRUCK: 'TRUCK',
    TRAILER: 'TRAILER',
};
export const assignManuallyLabels = {
    modalTitle: 'Assignment details',
    carrier: 'Carrier',
    infoCarrier: '“Select carrier” shows all the carriers dedicated to the lane eligible on the selected trip',
    equipmentType: 'Equipment type',
    driver: 'Driver',
    trailerTractor: 'Trailer & tractor',
    truck: 'Truck',
    carrierAssignDriver: 'Carrier to assign driver',
    titleTrailerDetails: 'Trailer details',
    trailerAssignment: 'Trailer assignment',
    trailer: 'Trailer',
    load: 'Load',
    originLocation: 'Origin location',
    destinationLocation: 'Destination location',
    buttonCancel: 'Cancel',
    buttonAssignManually: 'Assign manually',
    singleTrailer: 'Single trailer',
    onLoadCount: 'Based on load count',
    tractor: 'Tractor',
    containerId: 'Container ID',
};
export const getPageStaticDataRequest = (market) => {
    let dataElements = [];
    switch (market) {
        case 'ca':
            dataElements = [
                'carriers',
                'carrier_codes',
                'mdm_location_types',
                'transit_class',
                'modes',
                'service_levels',
                'master_equipment_types',
                'protection_levels',
                'equipment_type_configs',
                'time_zones_juris',
            ];
            break;
        case MarketCodeEnum.US.code:
            dataElements = ['mdm_location_types', 'countries', 'states', 'time_zones_juris', 'wm_weeks'];
            break;
        case MarketCodeEnum.USTRX.code:
            dataElements = ['mdm_location_types', 'countries', 'states', 'time_zones_juris'];
            break;
        case MarketCodeEnum.MEXICO.code:
        case MarketCodeEnum.MEXICO_MARKET_PLACE.code:
            dataElements = [
                'carriers',
                'carrier_codes',
                'mdm_location_types',
                'modes',
                'service_levels',
                'master_equipment_types',
                'protection_levels',
                'equipment_type_configs',
                'time_zones_juris',
                'locations',
            ];
            break;
        default:
            dataElements = [
                'carriers',
                'carrier_codes',
                'mdm_location_types',
                // 'transit_class',
                'modes',
                'service_levels',
                'master_equipment_types',
                'protection_levels',
                'equipment_type_configs',
                'time_zones_juris',
            ];
            break;
    }
    return {
        data_elements: dataElements,
    };
};

export const resouceAssignStatusENUM = {
    RESOURCE_ASSINGED: 'RESOURCES_ASSIGNED',
    RESOURCE_UNASSINED: 'RESOURCES_UNASSIGNED',
    RESOURCE_ASSIGN_IN_PROGRESS: 'RESOURCES_ASSIGN_IN_PROGRESS',
};
export const ERROR_CONTAINER_ID = 'stride-trip-management-error-container';
export const WALMART_CARRIER_ID = '76042014';
export const MDM_LOCATION_TYPES = {
    STORE: 'STORE',
    DECON: 'DCN',
    HUB: 'HUB',
};
export const autoTenderPBLabels = {
    title1: 'pb.autoTender.title1',
    title2: 'pb.title2',
    cancelText: 'pb.autoTender.cancelBtn',
    progressInfoText: 'pb.autoTender.info',
};
export const dispatchPBLabels = {
    title1: 'pb.dispatch.title1',
    title2: 'pb.title2',
    cancelText: 'pb.dispatch.cancelBtn',
    progressInfoText: 'pb.dispatch.info',
};
export const deliveredPBLabels = {
    title1: 'pb.delivered.title1',
    title2: 'pb.title2',
    cancelText: 'pb.delivered.cancelBtn',
    progressInfoText: 'pb.delivered.info',
};
export const downloadPBLabels = {
    title1: 'pb.download.title1',
    title2: 'pb.title2',
    cancelText: 'pb.download.cancelBtn',
    progressInfoText: 'pb.download.info',
};
export const autoCarrierPBLabels = {
    title1: 'pb.autoCarrier.title1',
    title2: 'pb.title2',
    cancelText: 'pb.autoCarrier.cancelBtn',
    progressInfoText: 'pb.autoCarrier.info',
};
export const withdrawTenderPBLabels = {
    title1: 'pb.withdrawTender.title1',
    title2: 'pb.title2',
    cancelText: 'pb.withdrawTender.cancelBtn',
    progressInfoText: 'pb.withdrawTender.info',
};
export const companyName = 'Walmart';
export const planTableHeadCellsCA = [
    {
        id: 'planId',
        label: 'planColumns.planId',
    },
    {
        id: 'planEntity',
        label: 'planColumns.planType',
        sortField: 'PLAN_TYPE',
    },
    {
        id: 'originId',
        label: 'planColumns.originId',
        sortField: 'PLAN_ORIGIN_LOCATION_ID',
    },
    {
        id: 'originCity',
        label: 'planColumns.originCity',
        sortField: 'PLAN_ORIGIN_CITY',
    },
    {
        id: 'destinationId',
        label: 'planColumns.destinationId',
        sortField: 'PLAN_DESTINATION_LOCATION_ID',
    },
    {
        id: 'destinationCity',
        label: 'planColumns.destinationCity',
        sortField: 'PLAN_DESTINATION_CITY',
    },
    {
        id: 'departureTs',
        label: 'planColumns.departure',
        sortField: 'PLAN_DEPARTURE_TS',
    },
    {
        id: 'actDeparture',
        label: 'planColumns.actDeparture',
        sortField: 'PLAN_ACTUAL_DEPARTURE',
    },
    {
        id: 'arrivalTs',
        label: 'planColumns.arrival',
        sortField: 'PLAN_ARRIVAL_TS',
    },
    {
        id: 'carrier',
        label: 'planColumns.carrier',
        sortField: 'PLAN_CARRIER_ID',
    },
    {
        id: 'pallets',
        label: 'planColumns.palletsPositions',
        sortField: 'PLAN_AGGREGATES_TOTAL_PALLETS_MEASUREMENT_VALUE',
    },
    {
        id: 'weight',
        label: 'planColumns.weight',
        sortField: 'PLAN_AGGREGATES_TOTAL_WEIGHT_MEASUREMENT_VALUE',
    },
    {
        id: 'noOfPickupStops',
        label: 'planColumns.noOfPickupStops',
        sortField: 'PLAN_NO_OF_PICKUP_STOPS',
    },
    {
        id: 'noOfDropoffStops',
        label: 'planColumns.noOfDropoffStops',
        sortField: 'PLAN_NO_OF_DROPOFF_STOPS',
    },
    {
        id: 'loadType',
        label: 'planColumns.loadType',
        sortField: 'PLAN_LOADTYPE',
    },
    {
        id: 'serviceType',
        label: 'planColumns.serviceType',
        sortField: 'PLAN_SERVICETYPE',
    },
    {
        id: 'class',
        label: 'planColumns.class',
        sortField: 'PLAN_CLASS',
    },
    {
        id: 'loadMode',
        label: 'planColumns.mode',
        sortField: 'PLAN_MODE',
    },
    {
        id: 'serviceLevel',
        label: 'planColumns.serviceLevel',
        sortField: 'PLAN_SERVICE_LEVEL',
    },
    {
        id: 'tempControl',
        label: 'planColumns.tempControl',
        sortField: 'PLAN_TEMP_CONTROL',
    },
    {
        id: 'hazmat',
        label: 'planColumns.hazmat',
        sortField: 'PLAN_HAZMAT',
    },
    {
        id: 'timeLeft',
        label: 'planColumns.timeLeft',
        sortField: 'PLAN_TIMELEFT',
    },
    {
        id: 'carriersLeft',
        label: 'planColumns.carriersLeft',
        sortField: 'PLAN_CARRIER_LEFT',
    },
    {
        id: 'equipmentConfigId',
        label: 'planColumns.equipmentConfigId',
        sortField: 'PLAN_EQP_CONFIG_ID',
    },
    {
        id: 'enrouteMilestone',
        label: 'planColumns.enrouteMilestone',
        sortField: 'PLAN_ENROUTE_MILESTONE',
    },
    {
        id: 'nextStop',
        label: 'planColumns.nextStop',
        sortField: 'PLAN_NEXT_STOP',
    },
    {
        id: 'noOfStopsLeft',
        label: 'planColumns.noOfStopsLeft',
        sortField: 'PLAN_NO_STOPS_LEFT',
    },
    {
        id: 'planStatusLabel',
        label: 'planColumns.status',
        sortField: 'PLAN_STATUS',
    },
];
export const excludedColumnsForPlanningCA = [
    'carrier',
    'serviceType',
    'timeLeft',
    'carriersLeft',
    'enrouteMilestone',
    'nextStop',
    'noOfStopsLeft',
    'inTransitStatus',
    'actDeparture',
];
export const excludedColumnsForProcessingCA = [
    'planEntity',
    'class',
    'loadMode',
    'serviceLevel',
    'equipmentConfigId',
    'pallets',
    'weight',
    'enrouteMilestone',
    'nextStop',
    'noOfStopsLeft',
    'inTransitStatus',
    'actDeparture',
];
export const excludedColumnsForReadyToStartCA = [
    'planEntity',
    'class',
    'loadMode',
    'serviceLevel',
    'equipmentConfigId',
    'pallets',
    'weight',
    'serviceType',
    'timeLeft',
    'carriersLeft',
    'inTransitStatus',
    'actDeparture',
    'noOfPickupStops',
    'noOfDropoffStops',
    'tempControl',
    'hazmat',
    'enrouteMilestone',
    'nextStop',
    'noOfStopsLeft',
];
export const excludedColumnsForInTransit = [
    'planEntity',
    'class',
    'loadMode',
    'serviceLevel',
    'equipmentConfigId',
    'pallets',
    'weight',
    'serviceType',
    'timeLeft',
    'carriersLeft',
    'noOfPickupStops',
    'noOfDropoffStops',
    'tempControl',
    'hazmat',
    'departureTs',
];
export const plankeyRegex = new RegExp(/^[0-9]*([ ,\t\n][0-9]+)*$/);
export const regexAlphaNumComma = new RegExp(/^[0-9a-zA-z]*([,\t\n][0-9a-zA-z]+)*$/);
export const FILTER_TYPES = {
    DATE_TYPE: 'dateType',
    PERIOD_TYPE: 'periodType',
    PLAN_TYPE: 'planType',
    STATUS: 'status',
    ORIGIN_TYPE: 'originType',
    ORIGIN_CITY: 'originCity',
    ORIGIN_PROVINCE: 'originProvince',
    ORIGIN_POSTAL_CODE: 'originPostalCode',
    ORIGIN_COUNTRY: 'originCountry',
    DESTINATION_TYPE: 'destinationType',
    DESTINATION_CITY: 'destinationCity',
    DESTINATION_PROVINCE: 'destinationProvince',
    DESTINATION_POSTAL_CODE: 'destinationPostalCode',
    DESTINATION_COUNTRY: 'destinationCountry',
    LOAD_OWNER: 'loadOwner',
    PRIORITY: 'priority',
    TEMPERATURE_CONTROL: 'temperatureControl',
    HAZMAT: 'hazmat',
    EQUIPMENT_CONFIGURATION_ID: 'equipmentConfigurationId',
    EQUIPMENT_ID: 'equipmentId',
    IBOB: 'ibob',
    PROGRAM: 'program',
    CHANNEL: 'channel',
    LOAD_ID: 'loadId',
    TO_ID: 'toId',
    SERVICE_CLASS: 'serviceClass',
    SERVICE_MODE: 'mode',
    SERVICE_LEVEL: 'serviceLevel',
    SERVICE_TYPE: 'serviceType',
    CARRIER_ID: 'carrierId',
    SCAC_CODE: 'scacCode',
};
export const ALLOWED_FILTERS = {
    ca: [
        FILTER_TYPES.DATE_TYPE,
        FILTER_TYPES.PERIOD_TYPE,
        FILTER_TYPES.STATUS,
        FILTER_TYPES.ORIGIN_TYPE,
        FILTER_TYPES.ORIGIN_CITY,
        FILTER_TYPES.ORIGIN_PROVINCE,
        FILTER_TYPES.ORIGIN_POSTAL_CODE,
        FILTER_TYPES.ORIGIN_COUNTRY,
        FILTER_TYPES.DESTINATION_TYPE,
        FILTER_TYPES.DESTINATION_CITY,
        FILTER_TYPES.DESTINATION_PROVINCE,
        FILTER_TYPES.DESTINATION_POSTAL_CODE,
        FILTER_TYPES.DESTINATION_COUNTRY,
        FILTER_TYPES.LOAD_OWNER,
        FILTER_TYPES.PRIORITY,
        FILTER_TYPES.TEMPERATURE_CONTROL,
        FILTER_TYPES.HAZMAT,
        FILTER_TYPES.EQUIPMENT_CONFIGURATION_ID,
        FILTER_TYPES.EQUIPMENT_ID,
        FILTER_TYPES.IBOB,
        FILTER_TYPES.PROGRAM,
        FILTER_TYPES.CHANNEL,
        FILTER_TYPES.SERVICE_CLASS,
        FILTER_TYPES.SERVICE_MODE,
        FILTER_TYPES.SERVICE_LEVEL,
        FILTER_TYPES.SERVICE_TYPE,
        FILTER_TYPES.CARRIER_ID,
        FILTER_TYPES.SCAC_CODE,
        FILTER_TYPES.LOAD_ID,
        FILTER_TYPES.TO_ID,
    ],
    cl: [
        FILTER_TYPES.DATE_TYPE,
        FILTER_TYPES.PERIOD_TYPE,
        FILTER_TYPES.PLAN_TYPE,
        FILTER_TYPES.STATUS,
        FILTER_TYPES.ORIGIN_TYPE,
        FILTER_TYPES.ORIGIN_CITY,
        FILTER_TYPES.ORIGIN_PROVINCE,
        FILTER_TYPES.ORIGIN_POSTAL_CODE,
        FILTER_TYPES.ORIGIN_COUNTRY,
        FILTER_TYPES.DESTINATION_TYPE,
        FILTER_TYPES.DESTINATION_CITY,
        FILTER_TYPES.DESTINATION_PROVINCE,
        FILTER_TYPES.DESTINATION_POSTAL_CODE,
        FILTER_TYPES.DESTINATION_COUNTRY,
        FILTER_TYPES.LOAD_OWNER,
        FILTER_TYPES.PRIORITY,
        FILTER_TYPES.TEMPERATURE_CONTROL,
        FILTER_TYPES.HAZMAT,
        FILTER_TYPES.EQUIPMENT_CONFIGURATION_ID,
        FILTER_TYPES.EQUIPMENT_ID,
        FILTER_TYPES.IBOB,
        FILTER_TYPES.PROGRAM,
        FILTER_TYPES.CHANNEL,
        FILTER_TYPES.SERVICE_CLASS,
        FILTER_TYPES.SERVICE_MODE,
        FILTER_TYPES.SERVICE_LEVEL,
        FILTER_TYPES.SERVICE_TYPE,
        FILTER_TYPES.CARRIER_ID,
        FILTER_TYPES.SCAC_CODE,
    ],
    gt: [
        FILTER_TYPES.DATE_TYPE,
        FILTER_TYPES.PERIOD_TYPE,
        FILTER_TYPES.PLAN_TYPE,
        FILTER_TYPES.STATUS,
        FILTER_TYPES.ORIGIN_TYPE,
        FILTER_TYPES.ORIGIN_CITY,
        FILTER_TYPES.ORIGIN_PROVINCE,
        FILTER_TYPES.ORIGIN_POSTAL_CODE,
        FILTER_TYPES.ORIGIN_COUNTRY,
        FILTER_TYPES.DESTINATION_TYPE,
        FILTER_TYPES.DESTINATION_CITY,
        FILTER_TYPES.DESTINATION_PROVINCE,
        FILTER_TYPES.DESTINATION_POSTAL_CODE,
        FILTER_TYPES.DESTINATION_COUNTRY,
        FILTER_TYPES.LOAD_OWNER,
        FILTER_TYPES.PRIORITY,
        FILTER_TYPES.TEMPERATURE_CONTROL,
        FILTER_TYPES.HAZMAT,
        FILTER_TYPES.EQUIPMENT_CONFIGURATION_ID,
        FILTER_TYPES.EQUIPMENT_ID,
        FILTER_TYPES.IBOB,
        FILTER_TYPES.PROGRAM,
        FILTER_TYPES.CHANNEL,
        FILTER_TYPES.SERVICE_CLASS,
        FILTER_TYPES.SERVICE_MODE,
        FILTER_TYPES.SERVICE_LEVEL,
        FILTER_TYPES.SERVICE_TYPE,
        FILTER_TYPES.CARRIER_ID,
        FILTER_TYPES.SCAC_CODE,
    ],
    cr: [
        FILTER_TYPES.DATE_TYPE,
        FILTER_TYPES.PERIOD_TYPE,
        FILTER_TYPES.PLAN_TYPE,
        FILTER_TYPES.STATUS,
        FILTER_TYPES.ORIGIN_TYPE,
        FILTER_TYPES.ORIGIN_CITY,
        FILTER_TYPES.ORIGIN_PROVINCE,
        FILTER_TYPES.ORIGIN_POSTAL_CODE,
        FILTER_TYPES.ORIGIN_COUNTRY,
        FILTER_TYPES.DESTINATION_TYPE,
        FILTER_TYPES.DESTINATION_CITY,
        FILTER_TYPES.DESTINATION_PROVINCE,
        FILTER_TYPES.DESTINATION_POSTAL_CODE,
        FILTER_TYPES.DESTINATION_COUNTRY,
        FILTER_TYPES.LOAD_OWNER,
        FILTER_TYPES.PRIORITY,
        FILTER_TYPES.TEMPERATURE_CONTROL,
        FILTER_TYPES.HAZMAT,
        FILTER_TYPES.EQUIPMENT_CONFIGURATION_ID,
        FILTER_TYPES.EQUIPMENT_ID,
        FILTER_TYPES.IBOB,
        FILTER_TYPES.PROGRAM,
        FILTER_TYPES.CHANNEL,
        FILTER_TYPES.SERVICE_CLASS,
        FILTER_TYPES.SERVICE_MODE,
        FILTER_TYPES.SERVICE_LEVEL,
        FILTER_TYPES.SERVICE_TYPE,
        FILTER_TYPES.CARRIER_ID,
        FILTER_TYPES.SCAC_CODE,
    ],
    sv: [
        FILTER_TYPES.DATE_TYPE,
        FILTER_TYPES.PERIOD_TYPE,
        FILTER_TYPES.PLAN_TYPE,
        FILTER_TYPES.STATUS,
        FILTER_TYPES.ORIGIN_TYPE,
        FILTER_TYPES.ORIGIN_CITY,
        FILTER_TYPES.ORIGIN_PROVINCE,
        FILTER_TYPES.ORIGIN_POSTAL_CODE,
        FILTER_TYPES.ORIGIN_COUNTRY,
        FILTER_TYPES.DESTINATION_TYPE,
        FILTER_TYPES.DESTINATION_CITY,
        FILTER_TYPES.DESTINATION_PROVINCE,
        FILTER_TYPES.DESTINATION_POSTAL_CODE,
        FILTER_TYPES.DESTINATION_COUNTRY,
        FILTER_TYPES.LOAD_OWNER,
        FILTER_TYPES.PRIORITY,
        FILTER_TYPES.TEMPERATURE_CONTROL,
        FILTER_TYPES.HAZMAT,
        FILTER_TYPES.EQUIPMENT_CONFIGURATION_ID,
        FILTER_TYPES.EQUIPMENT_ID,
        FILTER_TYPES.IBOB,
        FILTER_TYPES.PROGRAM,
        FILTER_TYPES.CHANNEL,
        FILTER_TYPES.SERVICE_CLASS,
        FILTER_TYPES.SERVICE_MODE,
        FILTER_TYPES.SERVICE_LEVEL,
        FILTER_TYPES.SERVICE_TYPE,
        FILTER_TYPES.CARRIER_ID,
        FILTER_TYPES.SCAC_CODE,
    ],
};
export const phasesForAggsEnum = {
    PLANNING: 'planning',
    PROCESSING: 'processing',
    DISPATCH_PENDING: 'dispatchPending',
    READY_TO_START: 'readyToStart',
    IN_TRANSIT: 'inTransit',
    DELIVERED: 'delivered',
    ADDITIONAL_FILTER: 'additionalFilter',
};
export const languageDataMap = {
    en: enData,
    es: esData,
};
export const BASE_URL = '/api/gateway/v4';
export const CONST_FILTER_PROCESSING_DEFAULT_STATUS = [
    {
        planType: 'LOAD_PLAN_TYPE',
        status: PlanStatusEnum.PLANNED.name,
    },
    {
        planType: 'LOAD_PLAN_TYPE',
        status: PlanStatusEnum.TENDERED.name,
    },
    {
        planType: 'LOAD_PLAN_TYPE',
        status: PlanStatusEnum.TENDER_REJECTED.name,
    },
    {
        planType: 'LOAD_PLAN_TYPE',
        status: PlanStatusEnum.TENDER_TIMEOUT.name,
    },
    {
        planType: 'LOAD_PLAN_TYPE',
        status: PlanStatusEnum.NEED_ATTENTION.name,
    },
    {
        planType: 'LOAD_PLAN_TYPE',
        status: PlanStatusEnum.TENDER_CANCELED.name,
    },
];
const hostPath = () =>
    getEnvironment({
        hostname: window.location.hostname,
    });
export const SERVICE_ACTION_TYPE = {
    CANCEL_TENDER: {
        ACTION: `${hostPath()}.ltm.bulkCancelTender.enus`,
        SERVICE: 'stride',
    },
    BULK_MARK_SERVICE_FAILURE: {
        ACTION: `${hostPath()}.ltm.bulkMarkServiceFailure.enus`,
        SERVICE: 'stride',
    },
    MARK_UNMARK_PRINTED: {
        ACTION: `${hostPath()}.ltm.bulkMarkUnmarkPrinted.enus`,
        SERVICE: 'stride',
    },
    MARK_UNMARK_HAZMAT: {
        ACTION: `${hostPath()}.ltm.bulkMarkUnmarkHazmat.enus`,
        SERVICE: 'stride',
    },
};

export const INTERMEDIATE_LOCATION_TYPE = {
    HUB: {
        desc: 'Hub',
        code: 'HUB',
    },
    DECON: {
        desc: 'Decon',
        code: 'DCN',
    },
};

export const SORT_MODE = {
    ASC: 'ASC',
    DSC: 'DSC',
};

export const HYPHEN = '-';

export const TRIP_MODE = {
    DBL: 'DBL',
};

export const HUB_DEC_LOAD_TYPES = ['HUBSTR', 'DECSTR'];

export const HUB_DEC_RETURN_LOAD_TYPES = ['PLT', 'RTN', 'DHD', 'BOB'];

export const DOUBLE_TRAILER_EQUIPMENT_REGEX = {
    REGEX_MX: '^[TA][R][RS][F]\\d{2}$',
    REGEX_CL: '^[D].*',
};

export const camMarkets = ['gt', 'cr', 'sv'];

export const TABLE_ACTIONS_ENUM = {
    ASSIGN_CARRIER_AUTO: { name: 'ASSIGN_CARRIER_AUTO', desc: 'button.assignManually' },
    TENDER_AUTO: { name: 'TENDER_AUTO', desc: 'button.tenderTrip' },
    APPROVE_LOAD: { name: 'APPROVE_LOAD', desc: 'button.approveLoad' },
    FORCE_LOAD_TO_DELIVERED: { name: 'FORCE_LOAD_TO_DELIVERED', desc: 'button.forceLoadToDelivered' },
    WITHDRAW_TENDER: { name: 'WITHDRAW_TENDER', desc: 'button.withdrawTender' },
    CANCEL_LOAD: { name: 'CANCEL_LOAD', desc: 'button.cancelLoad' },
    ADD_MULTI_COMMENT: { name: 'ADD_MULTI_COMMENT', desc: 'button.addCommentToLoads' },
};

export const commentEntities = [
    {
        id: 'All',
        value: 'All',
        disabled: false,
    },
    {
        id: 'General',
        value: 'General',
        disabled: false,
    },
    {
        id: 'Carrier',
        value: 'Carrier',
        disabled: false,
    },
];

export const SHORTENED_EXTENDED_DATE_TIME = 'D MMMM, YYYY h:mm a';

export const COMMENT_VALIDATION = {
    DEFAULT: ['invalid-characters'],
};
