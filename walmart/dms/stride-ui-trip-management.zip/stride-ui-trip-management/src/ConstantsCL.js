import TripSharedService from './service/TripSharedService';
export const planTableHeadCellsCL = () => [
    {
        id: 'planId',
        label: 'planColumns.planId',
    },
    {
        id: 'planEntity',
        label: 'planColumns.planType',
        sortField: 'PLAN_TYPE',
    },
    TripSharedService.getFeatureFlags()?.showRegionAndMerchandiseDetails && {
        id: 'merchandiseType',
        label: 'planColumns.merchandiseType',
        sortField: 'PLAN_MERCHANDISE_TYPE',
    },
    {
        id: 'originId',
        label: 'planColumns.origin',
        sortField: 'PLAN_ORIGIN_LOCATION_ID',
    },
    {
        id: 'distance',
        label: 'planColumns.distance',
    },
    {
        id: 'destinationId',
        label: 'planColumns.destination',
        sortField: 'PLAN_DESTINATION_LOCATION_ID',
    },
    {
        id: 'noOfStops',
        label: 'planColumns.noOfStopsInTransit',
    },
    {
        id: 'laneId',
        label: 'planColumns.laneId',
    },
    {
        id: 'rate',
        label: 'planColumns.rate',
    },
    {
        id: 'carrierId',
        label: 'planColumns.carrier',
        sortField: 'PLAN_CARRIER_ID',
    },
    {
        id: 'carrierStatus',
        label: 'planColumns.carrierStatus',
    },
    {
        id: 'equipmentType',
        label: 'planColumns.equipmentType',
    },
    {
        id: 'equipmentId',
        label: 'planColumns.equipmentId',
    },
    {
        id: 'driver',
        label: 'planColumns.driver',
    },
    {
        id: 'cases',
        label: 'planColumns.cases',
    },
    {
        id: 'pallets',
        label: 'planColumns.pallets',
    },
    {
        id: 'cube',
        label: 'planColumns.cube',
    },
    {
        id: 'weight',
        label: 'planColumns.weight',
    },
    {
        id: 'departureTs',
        label: 'planColumns.departureDateTime',
    },
    {
        id: 'arrivalTs',
        label: 'planColumns.arrivalDateTime',
    },
    {
        id: 'createdTs',
        label: 'planColumns.createdDateTime',
        sortField: 'PLAN_CREATED_TIME',
    },
    {
        id: 'planStatusLabel',
        label: 'planColumns.planStatus',
        sortField: 'PLAN_STATUS',
    },
];
export const planSearchHeadersCL = [
    'planId',
    'planEntity',
    'originId',
    'originName',
    'destinationId',
    'destinationName',
    'distance',
    'originType',
    'destinationType',
    'duration',
    'carrierId',
    'serviceTerritory',
    'billsByTime',
    'trailerId',
    'driverName',
    'driverId',
    'originCity',
    'destinationCity',
    'noOfPickupStops',
    'noOfDropoffStops',
    'nextStop',
    'merchandiseType',
    'originRegion',
    'destinationRegion',
];
