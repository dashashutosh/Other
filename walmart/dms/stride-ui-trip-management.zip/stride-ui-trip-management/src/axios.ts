// @ts-ignore
import { Utilities } from '@gscope-mfe/app-bridge';

const axiosInstance = Utilities.createAxiosInstance();
axiosInstance.CancelToken = Utilities.axiosLib.CancelToken;
axiosInstance.isCancel = Utilities.axiosLib.isCancel;

export default axiosInstance;
