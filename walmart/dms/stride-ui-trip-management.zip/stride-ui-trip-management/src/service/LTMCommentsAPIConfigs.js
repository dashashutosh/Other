import axios from '../axios';

export const getCommentsAPIConfigs = (market, language, userId, userName) => {
    const apiConfigBase = {
        axios: axios,
        userId: userId,
        userName: userName,
        language: language,
        currentMarket: market,
        usUsTenantFlag: true,
    };

    return {
        tripCommentsApiConfigs: {
            add: {
                pApiParams: {
                    ...apiConfigBase,
                    ccmServiceName: 'stride-ui-trip-management-trip-addComments',
                    ccmRouteName: 'addComments',
                },
            },
            update: {
                pApiParams: {
                    ...apiConfigBase,
                    ccmServiceName: 'stride-ui-trip-management-trip-updateComments',
                    ccmRouteName: 'updateComments',
                },
            },
            delete: {
                pApiParams: {
                    ...apiConfigBase,
                    ccmServiceName: 'stride-ui-trip-management-trip-deletecomments',
                    ccmRouteName: 'deletecomments',
                },
            },
        },
        loadCommentsApiConfigs: {
            add: {
                pApiParams: {
                    ...apiConfigBase,
                    ccmServiceName: 'stride-ui-trip-management-addComments',
                    ccmRouteName: 'addComments',
                },
            },
            update: {
                pApiParams: {
                    ...apiConfigBase,
                    ccmServiceName: 'stride-ui-trip-management-updateComments',
                    ccmRouteName: 'updateComments',
                },
            },
            delete: {
                pApiParams: {
                    ...apiConfigBase,
                    ccmServiceName: 'stride-ui-trip-management-deletecomments',
                    ccmRouteName: 'deletecomments',
                },
            },
        },
        getAllCommentsApiConfigs: null,
        addCommentToAll: {
            pApiParams: {
                ...apiConfigBase,
                ccmServiceName: 'stride-ui-trip-management-addCommentToLoads',
                ccmRouteName: 'addCommentToLoads',
            },
        },
    };
};
