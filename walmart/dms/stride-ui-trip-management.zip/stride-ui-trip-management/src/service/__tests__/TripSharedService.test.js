import TripSharedService from '../TripSharedService';

const data = { timeout: '5000' };
const staticData = {
    status: [
        {
            abbr: 'Active',
            desc: 'Active',
        },
    ],
};

describe('TripSharedService', () => {
    it('creates an instance', () => {
        expect(TripSharedService).not.toBeNull();
    });

    it('setConfig', () => {
        TripSharedService.setConfig(data);
        expect(TripSharedService.CMSData).not.toBeNull();
        expect(TripSharedService.CMSData.timeout).toEqual('5000');
    });

    it('getConfig', () => {
        const response = TripSharedService.getConfig();
        expect(response).not.toBeNull();
        expect(response).toEqual(data);
    });

    it('should set and get trip static data', () => {
        TripSharedService.setTripStaticData(staticData);
        expect(TripSharedService.getTripStaticData()).not.toBeNull();
        expect(TripSharedService.getTripStaticData()).toEqual(staticData);
    });

    it('should set and get current language', () => {
        TripSharedService.setCurrentLanguage('es');
        expect(TripSharedService.getCurrentLanguage()).toEqual('es');
    });

    it('should set and get feature flags', () => {
        const featureFlags = { enableShortTimezone: true };
        TripSharedService.setFeatureFlags(featureFlags);

        expect(TripSharedService.getFeatureFlags()).toEqual(featureFlags);
    });

    it('should get and set trans function', () => {
        const mockTrans = jest.fn();
        TripSharedService.setTrans(mockTrans);
        expect(TripSharedService.getTrans()).toBeDefined();
    });
});
