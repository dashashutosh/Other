import { ServiceBase, getTenant } from '@walmart/stride-ui-commons';
import { TripAPI, CommonAPI, PageLoadAPI, DownloadDispatchDocAndLabelAPI, getSplitLoadAPIParams } from '../TripAPI';
import TripSharedService from '../TripSharedService';
import axios from '../../axios';
import { getUsUsTenantFlagValue } from '../../utils/CommonUtils';

jest.mock('@walmart/stride-ui-commons', () => ({
    ...jest.requireActual('@walmart/stride-ui-commons'),
    ServiceBase: jest.fn(),
}));

const tenantHeaderValue = getTenant('us', {
    hostname: 'dev.stride.walmartlabs.com',
    usUsTenant: getUsUsTenantFlagValue('us', false),
});

const tenantHeaderValueCaMdm = getTenant('ca', {
    hostname: 'stg.stride.walmartlabs.com',
    usUsTenant: getUsUsTenantFlagValue('ca', true),
});

const tenantHeaderValueUstrx = getTenant('ustrx', {
    hostname: 'stg.stride.walmartlabs.com',
    usUsTenant: getUsUsTenantFlagValue('ustrx', false),
});

const tenantHeaderValueUstrxMdm = getTenant('ustrx', {
    hostname: 'stg.stride.walmartlabs.com',
    usUsTenant: getUsUsTenantFlagValue('ustrx', true),
});

describe('TripAPI tests', () => {
    it('should not return null', () => {
        expect(TripAPI('us', 'en', 'user', 'test')).not.toBeNull();
    });

    it('should call ServiceBase with appropriate headers', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripAPI('us', 'en', 'user', 'test').getStaticData({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers: {
                'WM_CONSUMER.TENANT_ID': tenantHeaderValue,
                languageCode: 'en-US',
                locale: 'en_US',
                userId: 'user',
                'WM_SVC.TENANT_ID': tenantHeaderValue,
                tenantId: tenantHeaderValue,
                userName: 'test',
            },
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-ui-trip-management-workloadStaticData',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should call ServiceBase with appropriate headers for ustrx mdm call for getStaticData', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripAPI('ustrx', 'en', 'user', 'test').getStaticData({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers: {
                'WM_CONSUMER.TENANT_ID': tenantHeaderValueUstrxMdm,
                languageCode: 'en-US',
                locale: 'en_US',
                userId: 'user',
                'WM_SVC.TENANT_ID': tenantHeaderValueUstrxMdm,
                tenantId: tenantHeaderValueUstrxMdm,
                userName: 'test',
            },
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-ui-trip-management-workloadStaticData',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should call ServiceBase with appropriate headers for ustrx mdm call for fetchCarrierData', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripAPI('ustrx', 'en', 'user', 'test').fetchCarrierData({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers: {
                'WM_CONSUMER.TENANT_ID': tenantHeaderValueUstrxMdm,
                languageCode: 'en-US',
                locale: 'en_US',
                userId: 'user',
                'WM_SVC.TENANT_ID': tenantHeaderValueUstrxMdm,
                tenantId: tenantHeaderValueUstrxMdm,
                userName: 'test',
            },
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-ui-trip-management-fetchCarrierData',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should call ServiceBase with appropriate headers for ustrx mdm call for getMDMLTMStaticData', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripAPI('ustrx', 'en', 'user', 'test').getMDMLTMStaticData({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers: {
                'WM_CONSUMER.TENANT_ID': tenantHeaderValueUstrxMdm,
                languageCode: 'en-US',
                locale: 'en_US',
                userId: 'user',
                'WM_SVC.TENANT_ID': tenantHeaderValueUstrxMdm,
                tenantId: tenantHeaderValueUstrxMdm,
                userName: 'test',
            },
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-ui-trip-management-staticData',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should call ServiceBase with appropriate headers for ca mdm call for getMDMLTMStaticData', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripAPI('ca', 'en', 'user', 'test').getMDMLTMStaticData({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers: {
                'WM_CONSUMER.TENANT_ID': tenantHeaderValueCaMdm,
                languageCode: 'en-CA',
                locale: 'en_CA',
                userId: 'user',
                'WM_SVC.TENANT_ID': tenantHeaderValueCaMdm,
                tenantId: tenantHeaderValueCaMdm,
                userName: 'test',
            },
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-ui-trip-management-staticData',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should call ServiceBase with appropriate headers for ca mdm call for fetchCarrierData', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripAPI('ca', 'en', 'user', 'test').fetchCarrierData({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers: {
                'WM_CONSUMER.TENANT_ID': tenantHeaderValueCaMdm,
                languageCode: 'en-CA',
                locale: 'en_CA',
                userId: 'user',
                'WM_SVC.TENANT_ID': tenantHeaderValueCaMdm,
                tenantId: tenantHeaderValueCaMdm,
                userName: 'test',
            },
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-ui-trip-management-fetchCarrierData',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should call ServiceBase with appropriate headers for ca mdm call for getStaticData', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripAPI('ca', 'en', 'user', 'test').getStaticData({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers: {
                'WM_CONSUMER.TENANT_ID': tenantHeaderValueCaMdm,
                languageCode: 'en-CA',
                locale: 'en_CA',
                userId: 'user',
                'WM_SVC.TENANT_ID': tenantHeaderValueCaMdm,
                tenantId: tenantHeaderValueCaMdm,
                userName: 'test',
            },
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-ui-trip-management-workloadStaticData',
            baseUrl: '/api/gateway/v4',
        });
    });
    it.skip('should set timeout to default value when not present', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig(undefined);
        TripAPI('us', 'en', 'user', 'test').getPlanPreview({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers: {
                'WM_CONSUMER.TENANT_ID': tenantHeaderValue,
                languageCode: 'en-US',
                locale: 'en_US',
                userId: 'user',
                'WM_SVC.TENANT_ID': tenantHeaderValue,
                tenantId: tenantHeaderValue,
                userName: 'test',
            },
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-trip-management',
        });
    });

    it.skip('should return api functions', () => {
        const result = TripAPI('us', 'en', 'user', 'test');
        expect(ServiceBase).toHaveBeenCalled();
        expect(typeof result.getPlanPreview).toBe('function');
        expect(typeof result.getStaticData).toBe('function');
        expect(typeof result.approveStatusChange).toBe('function');
    });

    it('should call post method of service base', () => {
        const header = {
            'WM_CONSUMER.TENANT_ID': tenantHeaderValue,
            languageCode: 'en-US',
            locale: 'en_US',
            userId: 'user',
            'WM_SVC.TENANT_ID': tenantHeaderValue,
            tenantId: tenantHeaderValue,
            userName: 'test',
        };
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        const result = TripAPI('us', 'en', 'user', 'test');
        expect(ServiceBase).toHaveBeenCalled();
        result.approveStatusChange({});
        expect(postMockFunction).toHaveBeenCalled();
        expect(postMockFunction).toHaveBeenCalledWith({ route: ['approveStatusChange'] }, {}, header);
        result.assignTrip({});
        expect(postMockFunction).toHaveBeenCalled();
        expect(postMockFunction).toHaveBeenCalledWith({ route: ['assignTrip'] }, {}, header);
    });

    it('should call post method of service basefor ustrx', () => {
        const header = {
            'WM_CONSUMER.TENANT_ID': tenantHeaderValueUstrx,
            languageCode: 'en-US',
            locale: 'en_US',
            userId: 'user',
            'WM_SVC.TENANT_ID': tenantHeaderValueUstrx,
            tenantId: tenantHeaderValueUstrx,
            userName: 'test',
        };
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        const result = TripAPI('ustrx', 'en', 'user', 'test');
        expect(ServiceBase).toHaveBeenCalled();
        result.approveStatusChange({});
        expect(postMockFunction).toHaveBeenCalled();
        expect(postMockFunction).toHaveBeenCalledWith({ route: ['approveStatusChange'] }, {}, header);
        result.assignTrip({});
        expect(postMockFunction).toHaveBeenCalled();
        expect(postMockFunction).toHaveBeenCalledWith({ route: ['assignTrip'] }, {}, header);
    });
    it('should call createDoubleTrailer service', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        const result = TripAPI('mx', 'en', 'user', 'test');
        expect(ServiceBase).toHaveBeenCalled();
        result.createDoubleTrailerTrip({});
        expect(postMockFunction).toHaveBeenCalledWith({ route: ['createDoubleTrailer'] }, {});
    });
    it('should call withdrawTender service', () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        const result = TripAPI('ca', 'en', 'user', 'test');
        expect(ServiceBase).toHaveBeenCalled();
        result.withdrawTender({
            planId: 10000,
            ct: 'test',
        });
        expect(postMockFunction).toHaveBeenCalledWith(
            {
                query: {
                    planId: 10000,
                },
                route: ['withdrawTender'],
            },
            {},
            {},
            { cancelToken: 'test' },
        );
    });
});

describe('CommonAPI tests', () => {
    it('should not return null', () => {
        expect(CommonAPI('us')).not.toBeNull();
    });

    it('should call ServiceBase with appropriate headers', () => {
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        CommonAPI('us');
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            opt: {
                timeout: 30000,
            },
            serviceType: 'cms',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should set timeout to default value when not present', () => {
        TripSharedService.setConfig(undefined);
        CommonAPI('us');
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            opt: {
                timeout: 30000,
            },
            serviceType: 'cms',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should return getConfig function', () => {
        const result = CommonAPI('us', 'en-US');
        expect(ServiceBase).toHaveBeenCalled();
        expect(typeof result.getConfig).toBe('function');
    });

    it('should call get method of service base for getConfig', () => {
        const getMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            get: getMockFunction,
        });
        const result = CommonAPI('us', 'en-US');
        expect(ServiceBase).toHaveBeenCalled();
        result.getConfig();
        expect(getMockFunction).toHaveBeenCalled();
        expect(getMockFunction).toHaveBeenCalledWith({
            route: ['getConfig'],
            query: { path: '/stride/tripmanagement', market: 'us' },
        });
    });
});

describe('Page load API tests', () => {
    it('should not return null', () => {
        expect(PageLoadAPI('us', 'en-US')).not.toBeNull();
    });

    it('should get failure when both API are failure', (done) => {
        CommonAPI.getConfig = jest.fn().mockReturnValue(
            new Promise(() => {
                throw new Error('error has occurred');
            }),
        );
        TripAPI.getStaticData = jest.fn().mockReturnValue(
            new Promise(() => {
                throw new Error('error has occurred');
            }),
        );
        PageLoadAPI.getPageLoadData = jest
            .fn()
            .mockReturnValue(Promise.all([CommonAPI.getConfig(), TripAPI.getStaticData()]));
        PageLoadAPI.getPageLoadData().catch((error) => {
            expect(error).toBeInstanceOf(Error);
            expect(error).toEqual(new Error('error has occurred'));
            done();
        });
    });

    it('should get failure when one of the API is a failure', (done) => {
        CommonAPI.getConfig = jest.fn().mockReturnValue(
            new Promise((resolve) => {
                setTimeout(() => {
                    resolve({ rowsPerPage: 10, debounceTime: 5 });
                }, 300);
            }),
        );
        TripAPI.getStaticData = jest.fn().mockReturnValue(
            new Promise(() => {
                throw new Error('error has occurred');
            }),
        );
        PageLoadAPI.getPageLoadData = jest
            .fn()
            .mockReturnValue(Promise.all([CommonAPI.getConfig(), TripAPI.getStaticData()]));
        PageLoadAPI.getPageLoadData().catch((error) => {
            expect(error).toBeInstanceOf(Error);
            expect(error).toEqual(new Error('error has occurred'));
            done();
        });
    });
});

describe('Download Dispatch API ', () => {
    it('should call only dispatch document API for GT', async () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripSharedService.setPageLoadSettings({ downloadDispatchLabel: false });
        const result = DownloadDispatchDocAndLabelAPI('gt', 'en-GT', '123', 'test User');
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            opt: {
                timeout: 30000,
            },
            serviceType: 'cms',
            baseUrl: '/api/gateway/v4',
        });
        await result.getDownloadResponse({ planId: 100, payload: {} }).then((res) => {
            expect(typeof res[1]).toBe('boolean');
        });
    });

    it('should call dispatch document and dispatch label API for CL', async () => {
        const postMockFunction = jest.fn().mockReturnValue(() => {});
        ServiceBase.mockReturnValue({
            post: postMockFunction,
        });
        TripSharedService.setConfig({ payload: { custom: { timeout: 30000 } } });
        TripSharedService.setPageLoadSettings({ downloadDispatchLabel: true });
        const result = DownloadDispatchDocAndLabelAPI('cl', 'en-GT', '123', 'test User');
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            opt: {
                timeout: 30000,
            },
            serviceType: 'cms',
            baseUrl: '/api/gateway/v4',
        });
        await result.getDownloadResponse({ planId: 100, payload: {} }).then((res) => {
            expect(typeof res[1]).toBe('function');
        });
    });
});

describe('API params', () => {
    it('should return API params', () => {
        const ApiConfig = getSplitLoadAPIParams('mx', 'en', 'user');
        expect(ApiConfig).not.toBeNull();
        expect(ApiConfig.ccmServiceName).toEqual('stride-ui-trip-management-splitLoad');
        expect(ApiConfig.timeout).toEqual(30000);
    });
});
