export const transformedConfigResponseMock = {
    rowsPerPage: 15,
    debounceTime: 10,
    maxTimeHorizonHours: 192,
    country: {
        currency: ['CLP'],
        id: '44',
        iso2: 'CL',
        iso3: 'CHL',
        name: 'Chile',
    },
    UOM: {
        width: 'M',
    },
    featureFlags: {
        'platform.tripManagement.configs': {
            enableShortTimezone: true,
        },
    },
    paginationSize: 0,
    tabStatus: {},
    planAggsIndex: null,
    sortFields: null,
    defaultOlsenTimezoneId: null,
    durationTimeHorizon: 6,
    bulkSemiColonDeliColumnCount: 97,
    trailerStatusCode: ['WT', 'MT'],
    size: 80,
    entityType: 'TRAILER',
    ymsEvent: 'gate_out_ts',
    trailerLocType: 'DOOR',
    hazmatUpdateAllowedPlanTypes: ['IMP_DRAY', 'IMP_MTDRAY', 'IMP_OCEAN'],
    standardDateTimeFormat: { dateTime: 'dd MMM, yyyy, hh:mm aaa', date: 'dd MMM, yyyy', time: 'hh:mm aaa' },
    WTMSLoadlength: 8,
    WTMSLoadSeries: ['6', '7', '8', '9'],
    WTMSCreatedSourceSystem: '',
    maxRowSelected: 5,
};
export const configResponseMock = {
    payload: {
        custom: {
            rowsPerPage: '15',
            debounceTime: '10',
            durationTimeHorizon: 6,
            country: '{"currency": ["CLP"],"id": "44","iso2": "CL","iso3": "CHL","name": "Chile"}',
            UOM: '{"width":"M"}',
            featureFlags: '{"platform.tripManagement.configs":{"enableShortTimezone":true}}',
            maxTimeHorizonHours: '192',
            bulkSemiColonDeliColumnCount: 97,
            trailerStatusCode: '["WT", "MT"]',
            size: 80,
            entityType: 'TRAILER',
            ymsEvent: 'gate_out_ts',
            trailerLocType: 'DOOR',
            hazmatUpdateAllowedPlanTypes: '["IMP_DRAY", "IMP_MTDRAY", "IMP_OCEAN"]',
            WTMSLoadlength: 8,
            WTMSLoadSeries: '["6", "7", "8", "9"]',
            WTMSCreatedSourceSystem: '',
            maxRowSelected: '5',
        },
    },
};
export const transformedConfigResponseMockCR = {
    rowsPerPage: 15,
    debounceTime: 10,
    maxTimeHorizonHours: 192,
    country: {
        currency: ['CRC'],
        id: '44',
        iso2: 'CR',
        iso3: 'CR',
        name: 'Costa Rica',
    },
    UOM: { width: 'M' },
    featureFlags: { 'platform.tripManagement.configs': { enableShortTimezone: true } },
    paginationSize: 0,
    tabStatus: {},
    planAggsIndex: null,
    sortFields: null,
    defaultOlsenTimezoneId: null,
    durationTimeHorizon: 6,
    bulkSemiColonDeliColumnCount: 97,
    trailerStatusCode: ['WT', 'MT'],
    size: 80,
    entityType: 'TRAILER',
    ymsEvent: 'gate_out_ts',
    trailerLocType: 'DOOR',
};

export const transformedConfigResponseMockSV = {
    rowsPerPage: 15,
    debounceTime: 10,
    maxTimeHorizonHours: 192,
    country: {
        currency: ['USD'],
        id: '66',
        iso2: 'SV',
        iso3: 'SLV',
        name: 'El Salvador',
    },
    UOM: { width: 'M' },
    featureFlags: { 'platform.tripManagement.configs': { enableShortTimezone: true } },
    paginationSize: 0,
    tabStatus: {},
    planAggsIndex: null,
    sortFields: null,
    defaultOlsenTimezoneId: null,
    durationTimeHorizon: 6,
    bulkSemiColonDeliColumnCount: 97,
    trailerStatusCode: ['WT', 'MT'],
    size: 80,
    entityType: 'TRAILER',
    ymsEvent: 'gate_out_ts',
    trailerLocType: 'DOOR',
};

export const transformedConfigResponseMockMKP = {
    ...transformedConfigResponseMockSV,
    country: {
        currency: ['MXN'],
        id: '91',
        iso2: 'MX',
        iso3: 'GTM',
        name: 'Mexico',
    },
};

export const emptyConfigResponseMock = {
    payload: {
        custom: {},
    },
};
export const tripStaticDataMockGT = {
    payload: {
        mdm_static_data: {
            static_data: {
                carriers: [
                    {
                        mdm_carrier_id: 10398,
                        carrier_name: '6821005',
                    },
                    {
                        mdm_carrier_id: 800,
                        carrier_name: '6821005',
                    },
                ],
                carrier_codes: [
                    {
                        carrier_id: '89792722',
                        mdm_carrier_id: 10398,
                    },
                    {
                        carrier_id: '89792722',
                        mdm_carrier_id: 1466,
                    },
                ],
                mdm_location_types: [
                    {
                        id: 16,
                        code: 'ADM',
                        abbr: 'ADM',
                        desc: 'Admin',
                    },
                ],
                modes: [
                    {
                        id: 12,
                        code: 'PCL',
                        abbr: 'PCL',
                        desc: 'Parcel',
                    },
                ],
                service_levels: [
                    {
                        id: 229,
                        code: 'PO',
                        abbr: 'PO',
                        desc: 'Power only',
                    },
                ],
                transit_class: [
                    {
                        id: 4,
                        code: 'RL',
                        abbr: 'RL',
                        desc: 'RAIL',
                    },
                ],
                master_equipment_types: [
                    {
                        id: 8,
                        code: 'TR',
                        abbr: 'TR',
                        desc: 'Trailer',
                    },
                ],
            },
        },
        om_static_data: {
            payload: {
                staticData: {
                    reasonCodes: [
                        {
                            id: 3,
                            code: 'CARRIER',
                            abbr: 'CARRIER',
                            description: 'Carrier',
                        },
                    ],
                    orderStatusReasonCodes: [
                        {
                            id: 1,
                            code: 'CUSTOMS CLEARENCE',
                            abbr: 'CUSTOMS CLEARENCE',
                            description: 'Customs clearence',
                        },
                    ],
                    planStatus: {
                        id: 1,
                        code: 'UNPLANNED',
                        abbr: 'UNPLANNED',
                        description: 'UNPLANNED',
                    },
                    dateType: {
                        id: 1,
                        code: 'CREATED_DATE',
                        abbr: 'Created Date',
                        description: 'Created Date',
                    },
                    exceptionFilterType: [
                        {
                            id: 1,
                            code: 'UNDER_UTILISED_LOAD',
                            abbr: 'Under utilised load',
                            description: 'Under utilised load',
                            phases: ['1'],
                        },
                        {
                            id: 2,
                            code: 'OVER_WEIGHT_LOAD',
                            abbr: 'Over weight load',
                            description: 'Over weight load',
                            phases: ['1'],
                        },
                        {
                            id: 3,
                            code: 'DELIVERY_DATE_AT_RISK',
                            abbr: 'planned ',
                            description: 'planned ',
                            phases: ['1', '2'],
                        },
                        {
                            id: 4,
                            code: 'LOS',
                            abbr: 'los',
                            description: 'los',
                            phases: ['4'],
                        },
                    ],
                },
            },
        },
    },
    status: 'SUCCESS',
};
export const tripStaticDataMock = {
    payload: {
        mdm_static_data: {
            static_data: {
                carriers: [
                    {
                        mdm_carrier_id: 800,
                        carrier_name: '6821005',
                    },
                ],
                carrier_codes: [
                    {
                        carrier_id: '89792722',
                        mdm_carrier_id: 1466,
                    },
                ],
                mdm_location_types: [
                    {
                        id: 16,
                        code: 'ADM',
                        abbr: 'ADM',
                        desc: 'Admin',
                    },
                ],
                modes: [
                    {
                        id: 12,
                        code: 'PCL',
                        abbr: 'PCL',
                        desc: 'Parcel',
                    },
                ],
                service_levels: [
                    {
                        id: 229,
                        code: 'PO',
                        abbr: 'PO',
                        desc: 'Power only',
                    },
                ],
                transit_class: [
                    {
                        id: 4,
                        code: 'RL',
                        abbr: 'RL',
                        desc: 'RAIL',
                    },
                ],
                master_equipment_types: [
                    {
                        id: 8,
                        code: 'TR',
                        abbr: 'TR',
                        desc: 'Trailer',
                    },
                ],
            },
        },
        om_static_data: {
            payload: {
                staticData: {
                    reasonCodes: [
                        {
                            id: 3,
                            code: 'CARRIER',
                            abbr: 'CARRIER',
                            description: 'Carrier',
                        },
                    ],
                    orderStatusReasonCodes: [
                        {
                            id: 1,
                            code: 'CUSTOMS CLEARENCE',
                            abbr: 'CUSTOMS CLEARENCE',
                            description: 'Customs clearence',
                        },
                    ],
                    planStatus: {
                        id: 1,
                        code: 'UNPLANNED',
                        abbr: 'UNPLANNED',
                        description: 'UNPLANNED',
                    },
                    dateType: {
                        id: 1,
                        code: 'CREATED_DATE',
                        abbr: 'Created Date',
                        description: 'Created Date',
                    },
                    exceptionFilterType: [
                        {
                            id: 1,
                            code: 'UNDER_UTILISED_LOAD',
                            abbr: 'Under utilised load',
                            description: 'Under utilised load',
                            phases: ['1'],
                        },
                        {
                            id: 2,
                            code: 'OVER_WEIGHT_LOAD',
                            abbr: 'Over weight load',
                            description: 'Over weight load',
                            phases: ['1'],
                        },
                        {
                            id: 3,
                            code: 'DELIVERY_DATE_AT_RISK',
                            abbr: 'planned ',
                            description: 'planned ',
                            phases: ['1', '2'],
                        },
                        {
                            id: 4,
                            code: 'LOS',
                            abbr: 'los',
                            description: 'los',
                            phases: ['4'],
                        },
                    ],
                },
            },
        },
    },
    status: 'SUCCESS',
};
export const transformedTripStaticData = {
    carrierCodes: [{ carrier_id: '89792722', mdm_carrier_id: 1466 }],
    carriers: [
        {
            id: '800',
            value: '800-6821005',
        },
    ],
    channels: [],
    dateTypes: [
        {
            id: 'CREATED_DATE',
            value: 'Created Date',
        },
        {
            id: 'PLANNED_PICK_UP_DATE',
            value: 'Planned Pick up Date',
        },
        {
            id: 'PLANNED_DUE_DATE',
            value: 'Planned Due Date',
        },
        {
            id: 'ACTUAL_ARRIVAL_DATE',
            value: 'Actual Arrival Date',
        },
        {
            id: 'ACTUAL_DEPARTURE_DATE',
            value: 'Actual Departure Date',
        },
    ],
    equipmentConfigurationIds: [],
    ibobs: undefined,
    loadOwners: [],
    loadTypes: [],
    locationTypes: [
        {
            id: 'ADM',
            value: 'ADM',
            type_id: 16,
        },
    ],
    periodTypes: [],
    planStatus: [
        {
            id: 'TENDER_IN_PROGRESS',
            type: 'PROCESSING',
            value: 'Tender in Progress',
        },
        {
            id: 'TENDER_DECLINED',
            type: 'PROCESSING',
            value: 'Tender Declined',
        },
        {
            id: 'TENDER_EXHAUSTED',
            type: 'PROCESSING',
            value: 'Tender Exhausted',
        },
        {
            id: 'AWAITING_PICKUP',
            type: 'READY_TO_START',
            value: 'Awaiting Pick Up',
        },
        {
            id: 'PICKUP_DELAYED',
            type: 'READY_TO_START',
            value: 'Pick Up Delayed',
        },
        {
            id: 'STARTED',
            type: 'IN_TRANSIT',
            value: 'Started',
        },
        {
            id: 'EARLY',
            type: 'IN_TRANSIT',
            value: 'Early',
        },
        {
            id: 'ONTIME',
            type: 'IN_TRANSIT',
            value: 'On Time',
        },
        {
            id: 'LATE',
            type: 'IN_TRANSIT',
            value: 'Late',
        },
    ],
    planTypes: [
        {
            id: '1',
            value: 'test',
        },
    ],
    priorities: [],
    programmeTypes: [],
    reasonCodes: [
        {
            id: 'CARRIER',
            value: 'Carrier',
        },
    ],
    locations: [],
    orderStatusReasonCodes: [
        {
            id: 'CUSTOMS CLEARENCE',
            value: 'Customs clearence',
        },
    ],
    serviceClasses: [
        {
            id: 'RL',
            value: 'RAIL',
        },
    ],
    serviceLevels: [
        {
            id: 'PO',
            value: 'Power only',
        },
    ],
    serviceModes: [
        {
            id: 'PCL',
            value: 'Parcel',
        },
    ],
    serviceTypes: [],
    shortTimezones: undefined,
    temperatureControls: [],
};
export const contextMock = {
    prefLang: {
        current: 'en',
    },
    currentMarket: 'cl',
    setloading: jest.fn(),
    userInfo: {
        loggedInUserName: 'user',
    },
    setBreadCrumbArr: jest.fn(),
    setHeaderConfig: jest.fn(),
    setBulkUploadConfig: jest.fn(),
    moduleName: 'plan-query',
    headerConfig: {},
    allLangs: [],
    setAllLangs: jest.fn(),
    bulkUploadConfig: {
        bulkActions: {},
        serviceAction: true,
        serviceType: true,
        hasEditPermission: true,
    },
    setsIsSearchFilterModalOpen: false,
};
export const contextMockCA = {
    prefLang: {
        current: 'en',
    },
    currentMarket: 'ca',
    setloading: jest.fn(),
    userInfo: {
        loggedInUserName: 'user',
    },
    setBreadCrumbArr: jest.fn(),
    setHeaderConfig: jest.fn(),
    setBulkUploadConfig: jest.fn(),
    headerConfig: {},
    allLangs: [],
    setAllLangs: jest.fn(),
    bulkUploadConfig: {
        bulkActions: {},
        serviceAction: true,
        serviceType: true,
        hasEditPermission: true,
    },
};
export const contextMockUS = {
    prefLang: {
        current: 'en',
    },
    currentMarket: 'us',
    setloading: jest.fn(),
    userInfo: {
        loggedInUserName: 'user',
    },
    setBreadCrumbArr: jest.fn(),
    setHeaderConfig: jest.fn(),
    setBulkUploadConfig: jest.fn(),
    headerConfig: {},
    allLangs: [],
    setAllLangs: jest.fn(),
    bulkUploadConfig: {
        bulkActions: {},
        serviceAction: true,
        serviceType: true,
        hasEditPermission: true,
    },
};
export const defaultResponse = {
    callAPI: () => {},
    response: undefined,
};
export const pageLoadSuccessMock = {
    callAPI: jest.fn(),
    response: [configResponseMock, tripStaticDataMock],
    loading: false,
    error: {
        status: 500,
    },
};
export const pageLoadErrorMock = {
    callAPI: () => {},
    response: [emptyConfigResponseMock, tripStaticDataMock],
    loading: true,
    error: undefined,
};
export const pageLoadFailureMock = {
    callAPI: () => {},
    response: undefined,
    loading: false,
    error: {
        errors: [
            {
                code: 'OPA-400.001',
                field: null,
                description: 'Check error identifiers for specific details.',
                info: 'At least one of the underlying APIs failed.',
                severity: 'ERROR',
                category: 'REQUEST',
                causes: [],
                errorIdentifiers: {
                    details: {
                        status: 'BAD_REQUEST',
                        httpStatusCode: 400,
                        errors: [
                            {
                                errorCode: 'STRIDE-E004',
                                errorText: 'Bad request',
                                severity: 'ERROR',
                            },
                        ],
                    },
                },
            },
        ],
    },
};
export const staticDataWithoutExcepFilt = {
    status: 'SUCCESS',
    payload: {
        mdm_static_data: {},
        om_static_data: {
            payload: {
                staticData: {
                    exceptionFilterType: null,
                    periodType: [
                        {
                            id: 1,
                            code: 'IN_BETWEEN',
                            abbr: 'In Between',
                            description: 'In Between',
                        },
                    ],
                    owner: [
                        {
                            id: 1,
                            code: 'REQ',
                            abbr: 'Requestor Team',
                            description: 'Requestor Team',
                        },
                    ],
                    priority: [
                        {
                            id: 1,
                            code: 'EXPEDITED',
                            abbr: 'Expedited',
                            description: 'Expedited',
                        },
                    ],
                    ibob: [
                        {
                            id: 1,
                            code: 'OB',
                            abbr: 'Outbound',
                            description: 'Outbound',
                        },
                    ],
                    programmeType: [
                        {
                            id: 1,
                            code: 'COL',
                            abbr: 'COLLECT',
                            description: 'COLLECT',
                        },
                    ],
                    channelType: [
                        {
                            id: 1,
                            code: 'RTL',
                            abbr: 'Retail',
                            description: 'Retail',
                        },
                    ],
                    serviceType: [
                        {
                            id: 1,
                            code: 'DOMESTIC',
                            abbr: 'Domestic',
                            description: 'Domestic',
                        },
                    ],
                },
            },
        },
    },
};
export const staticDataWithoutomStaticData = {
    status: 'SUCCESS',
    payload: {
        mdm_static_data: {},
        om_static_data: {
            payload: {
                staticData: null,
            },
        },
    },
};
export const transformedConfigResponseMockUS = {
    rowsPerPage: 15,
    debounceTime: 500,
    country: {
        currency: ['USD'],
        id: '44',
        iso2: 'CA',
        iso3: 'CA',
        name: 'Canada',
    },
    UOM: {
        width: 'M',
        height: 'M',
        length: 'M',
        weight: 'KG',
        pallet: '',
        volume: 'CU M3',
        distance: 'mi',
        cube: 'M3',
        duration: 'HH:MM',
        currency: 'CLP',
        cases: 'EA',
        transitTime: 'MJ',
    },
    paginationSize: 100,
    tabStatus: {
        planning: ['PLANNED'],
        processingLoad: ['PLANNED', 'TENDERED', 'TENDER_ACCEPTED', 'TENDER_CANCELED'],
        processingLoadDray: ['PLANNED', 'TENDERED', 'TENDER_CANCELED'],
        processingTrip: ['CREATED', 'DRIVER_ASSIGNED'],
        reactToStart: ['DISPATCHED'],
        reactToStartLoad: ['TENDER_ACCEPTED'],
        inTransit: ['IN_TRANSIT'],
        delivered: ['DELIVERED'],
    },
    planAggsIndex: {
        dev: 'sct_stride_dev',
        'qa.stride.walmartlabs.com': 'sct_dev_2',
        stg: 'sct_stride_dev_3',
        pre: '',
        prod: 'sct_stride',
        localhost: 'sct_stride_dev',
    },
    sortFields: {
        PLAN_ID: 'entity_id',
        PLAN_TYPE: null,
        ORIGIN_LOCATION_ID: 'locations_origin_location_id',
        DISTANCE: null,
        DESTINATION_LOCATION_ID: 'locations_destination_location_id',
        PLANNED_START: 'schedule_min_pickup_ts',
        ACTUAL_START: null,
        CREATED_DATE: 'provenance_created_ts',
        DURATION: null,
        NEXT_STOP: null,
        NEXT_STOP_REMAINING: null,
        CARRIER_ID: null,
        SERVICE_TERRITORY: null,
        TRAILER_ID: null,
        DRIVER_ID: null,
        BILLS_BY_TIME: null,
        PICKUP_STOPS: null,
        DELIVERY_STOPS: null,
    },
};
export const featureFlagsMockGT = {
    showSearchFilterForAssignTrip: true,
};
export const featureFlagsMockGTFilteringOn = {
    showSearchFilterForAssignTrip: true,
    roundTripFiltering: true,
};
export const featureFlagsMock = {
    showSearchFilterForAssignTrip: false,
};
export const featureFlagsMockCA = {
    enableShortTimezone: true,
    enableLocationIdFilter: true,
    openDetailsPageInNewTab: true,
    showProfile: true,
    removeEquipmentFromFilter: true,
    showUpdateTimeline: true,
    editStopActivityType: true,
    showTotalCount: true,
    displayPhaseStatusCount: true,
    hideAssignToTripForSTRLoad: true,
    viewMoreRecords: true,
};
