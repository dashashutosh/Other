import {
    validateCmsConfigData,
    transformCmsData,
    errorHandler,
    validateStaticData,
    transformStaticData,
} from '../TripMapper';
import {
    transformedConfigResponseMock,
    configResponseMock,
    tripStaticDataMock,
    transformedTripStaticData,
    tripStaticDataMockGT,
} from './mocks/mocks/TripMapper.mock';

describe('Trip mapper tests', () => {
    describe('validate static data checks', () => {
        it('should check input data has payload or not', () => {
            expect(validateStaticData(undefined)).toEqual(false);
            expect(validateStaticData(null)).toEqual(false);
            expect(validateStaticData({ payload: undefined })).toEqual(false);
            expect(
                validateStaticData({
                    payload: {
                        mdm_static_data: {
                            static_data: {},
                        },
                    },
                }),
            ).toEqual(false);
        });

        it.skip('should return true when the data is valid', () => {
            expect(validateStaticData(tripStaticDataMock)).toEqual(true);
        });
    });

    describe('transform static data checks', () => {
        it.skip('should transform static data successfully', () => {
            expect(transformStaticData(tripStaticDataMock)).toEqual(transformedTripStaticData);
        });

        it('should transform static data successfully when WalmartCarrier ID is present', () => {
            expect(transformStaticData(tripStaticDataMockGT, 'gt', 10398)).toEqual(transformedTripStaticData);
        });

        it('should transform static data successfully when WalmartCarrier ID is not present', () => {
            expect(transformStaticData(tripStaticDataMock, 'gt')).toEqual(transformedTripStaticData);
        });

        it('should return failure when input data is invalid', () => {
            try {
                transformStaticData(undefined);
            } catch (e) {
                expect(e).toEqual(new Error('Invalid static data'));
            }
        });
    });

    describe('transform cms config data checks', () => {
        it('should transom cms config data', () => {
            expect(transformCmsData(configResponseMock)).toEqual(transformedConfigResponseMock);
        });

        it('should return empty value when data is invalid JSON', () => {
            const hazmatConfigResponseMock = {
                ...configResponseMock,
                payload: {
                    ...configResponseMock.payload,
                    custom: {
                        ...configResponseMock.payload.custom,
                        hazmatUpdateAllowedPlanTypes: '["IMP_DRAY",,"IMP_MTDRAY","IMP_OCEAN"]',
                        standardDateTimeFormat:
                            '{ \n  "dateTime": "MM/dd/yyyy HH:mm",\n  "date": "MM/dd/yyyy",\n  "time": "HH:mm"\n}',
                    },
                },
            };
            expect(transformCmsData(hazmatConfigResponseMock).hazmatUpdateAllowedPlanTypes).toEqual([]);
        });

        it('should return empty value when data is null', () => {
            const hazmatConfigResponseMock = {
                ...configResponseMock,
                payload: {
                    ...configResponseMock.payload,
                    custom: {
                        ...configResponseMock.payload.custom,
                        hazmatUpdateAllowedPlanTypes: null,
                    },
                },
            };
            expect(transformCmsData(hazmatConfigResponseMock).hazmatUpdateAllowedPlanTypes).toEqual([]);
        });

        it('should return value when data is empty', () => {
            const hazmatConfigResponseMock = {
                ...configResponseMock,
                payload: {
                    ...configResponseMock.payload,
                    custom: {
                        ...configResponseMock.payload.custom,
                        hazmatUpdateAllowedPlanTypes: [],
                    },
                },
            };
            expect(transformCmsData(hazmatConfigResponseMock).hazmatUpdateAllowedPlanTypes).toEqual([]);
        });

        it('should return value when data is undefined', () => {
            const hazmatConfigResponseMock = {
                ...configResponseMock,
                payload: {
                    ...configResponseMock.payload,
                    custom: {
                        ...configResponseMock.payload.custom,
                        hazmatUpdateAllowedPlanTypes: undefined,
                    },
                },
            };
            expect(transformCmsData(hazmatConfigResponseMock).hazmatUpdateAllowedPlanTypes).toEqual([]);
        });

        it('should return failure when input data is invalid', () => {
            try {
                transformCmsData(undefined);
            } catch (e) {
                expect(e).toEqual(new Error('Invalid CMS config data'));
            }
        });
    });

    describe('validate cms config data', () => {
        it('should return true when data is valid', () => {
            expect(validateCmsConfigData(configResponseMock)).toEqual(true);
        });

        it('should return false when data is invalid', () => {
            expect(validateCmsConfigData(undefined)).toEqual(false);
            expect(validateCmsConfigData(null)).toEqual(false);
            expect(
                validateCmsConfigData({
                    payload: null,
                }),
            ).toEqual(false);
            expect(
                validateCmsConfigData({
                    payload: {
                        custom: {
                            rowsPerPage: '4',
                        },
                    },
                }),
            ).toEqual(false);
            expect(
                validateCmsConfigData({
                    payload: {
                        custom: {
                            rowsPerPage: 4,
                            debounceTime: 15,
                        },
                    },
                }),
            ).toEqual(false);
        });
    });

    describe('error handler', () => {
        it('should return error if defined', () => {
            expect(errorHandler({ errors: ['test'] })).toEqual({ errors: ['test'] });
            expect(errorHandler({})).toEqual({ key: 'pageError.summary.noService' });
            expect(errorHandler()).toEqual({ key: 'pageError.summary.noService' });
        });
    });
});
