import {
    isNullOrUndefined,
    getUniqueValuesSorted,
    descendingComparator,
    MarketCodeEnum,
    getUniqueObjectValuesSorted,
} from '@walmart/stride-ui-commons';
import { DATE_FNS_DATE_TIME_FORMAT } from '../ConstantsUS';
export function validateStaticData(mdmResponseData, market) {
    if (!mdmResponseData) return false;
    if (market === MarketCodeEnum.US.code || market === MarketCodeEnum.USTRX.code) {
        return [mdmResponseData.mdm_location_types, mdmResponseData.countries, mdmResponseData.states].every(
            Array.isArray,
        );
    }
    return [
        mdmResponseData.mdm_location_types,
        // mdmResponseData.transit_class,
        mdmResponseData.modes,
        mdmResponseData.service_levels,
        mdmResponseData.master_equipment_types,
    ].every(Array.isArray);
}
export function transformStaticData(serviceResponse, market, walmartCarrierID) {
    const mdmResponseData = serviceResponse?.payload?.mdm_static_data?.static_data;
    if (walmartCarrierID) {
        const carrierDetailsGT = mdmResponseData?.carriers.filter(
            (carrier) => carrier.mdm_carrier_id !== walmartCarrierID,
        );
        const carrierCodesGT = mdmResponseData?.carrier_codes.filter(
            (carrier) => carrier.mdm_carrier_id !== walmartCarrierID,
        );
        mdmResponseData.carriers = carrierDetailsGT;
        mdmResponseData.carrier_codes = carrierCodesGT;
    }
    const omStaticData = serviceResponse?.payload?.om_static_data?.payload?.staticData;
    if (!validateStaticData(mdmResponseData, market)) throw new Error('Invalid static data');
    return {
        carrierCodes: getUniqueObjectValuesSorted(mdmResponseData?.carrier_codes, 'carrier_id'),
        carriers: getUniqueValuesSorted(
            mdmResponseData.carriers?.map((carrier) =>
                // eslint-disable-next-line prefer-template
                ({
                    id: carrier.mdm_carrier_id.toString(),
                    value: carrier.mdm_carrier_id + '-' + carrier.carrier_name,
                }),
            ),
        ),
        locationTypes: getUniqueValuesSorted(
            mdmResponseData.mdm_location_types?.map((type) => ({
                id: type?.code,
                value: type?.abbr,
                type_id: type?.id,
            })),
        ),
        serviceTypes: getUniqueValuesSorted(
            omStaticData?.serviceType?.map((type) => ({
                id: type.code,
                value: type.description,
            })),
        ),
        serviceClasses: getUniqueValuesSorted(
            mdmResponseData.transit_class?.map((type) => ({
                id: type.code,
                value: type.desc,
            })),
        ),
        serviceModes: getUniqueValuesSorted(
            mdmResponseData.modes?.map((mode) => ({
                id: mode.code,
                value: mode.desc,
            })),
        ),
        serviceLevels: getUniqueValuesSorted(
            mdmResponseData.service_levels?.map((level) => ({
                id: level.code,
                value: level.desc,
            })),
        ),
        programmeTypes: getUniqueValuesSorted(
            omStaticData?.programmeType
                ?.map((type) => ({
                    id: type.code,
                    value: type.abbr,
                }))
                .sort((a, b) => -descendingComparator(a, b, 'value')),
        ),
        temperatureControls: getUniqueValuesSorted(
            mdmResponseData?.protection_levels
                ?.map((type) => ({
                    id: type.code,
                    value: type.desc,
                }))
                .sort((a, b) => -descendingComparator(a, b, 'value')),
        ),
        loadOwners: getUniqueValuesSorted(
            omStaticData?.owner
                ?.map((owner) => ({
                    id: owner.code,
                    value: owner.description,
                }))
                .sort((a, b) => -descendingComparator(a, b, 'value')),
        ),
        priorities: getUniqueValuesSorted(
            omStaticData?.priority
                ?.map((type) => ({
                    id: type.code,
                    value: type.description,
                }))
                .sort((a, b) => -descendingComparator(a, b, 'value')),
        ),
        ibobs: omStaticData?.ibob
            ?.map((type) => ({
                id: type.code,
                value: type.description,
            }))
            .sort((a, b) => -descendingComparator(a, b, 'value')),
        channels: getUniqueValuesSorted(
            omStaticData?.channelType
                ?.map((type) => ({
                    id: type.code,
                    value: type.description,
                }))
                .sort((a, b) => -descendingComparator(a, b, 'value')),
        ),
        // TODO: remove the below values once the static data API is ready
        planTypes: [
            {
                id: '1',
                value: 'test',
            },
        ],
        planStatus: [
            {
                id: 'TENDER_IN_PROGRESS',
                value: 'Tender in Progress',
                type: 'PROCESSING',
            },
            {
                id: 'TENDER_DECLINED',
                value: 'Tender Declined',
                type: 'PROCESSING',
            },
            {
                id: 'TENDER_EXHAUSTED',
                value: 'Tender Exhausted',
                type: 'PROCESSING',
            },
            {
                id: 'AWAITING_PICKUP',
                value: 'Awaiting Pick Up',
                type: 'READY_TO_START',
            },
            {
                id: 'PICKUP_DELAYED',
                value: 'Pick Up Delayed',
                type: 'READY_TO_START',
            },
            {
                id: 'STARTED',
                value: 'Started',
                type: 'IN_TRANSIT',
            },
            {
                id: 'EARLY',
                value: 'Early',
                type: 'IN_TRANSIT',
            },
            {
                id: 'ONTIME',
                value: 'On Time',
                type: 'IN_TRANSIT',
            },
            {
                id: 'LATE',
                value: 'Late',
                type: 'IN_TRANSIT',
            },
        ],
        equipmentConfigurationIds: getUniqueValuesSorted(
            mdmResponseData?.equipment_type_configs
                ?.map((type) => ({
                    id: type?.equipment_type_config_code,
                    value: type?.equipment_type_config_code || '',
                }))
                .sort((a, b) => -descendingComparator(a, b, 'value')),
        ),
        // dateTypes: omStaticData?.dateType?.map((dateType) => ({
        //   id: dateType.code,
        //   value: dateType.abbr,
        // })) || [],
        dateTypes: [
            {
                id: 'CREATED_DATE',
                value: 'Created Date',
            },
            {
                id: 'PLANNED_PICK_UP_DATE',
                value: 'Planned Pick up Date',
            },
            {
                id: 'PLANNED_DUE_DATE',
                value: 'Planned Due Date',
            },
            {
                id: 'ACTUAL_ARRIVAL_DATE',
                value: 'Actual Arrival Date',
            },
            {
                id: 'ACTUAL_DEPARTURE_DATE',
                value: 'Actual Departure Date',
            },
        ],
        periodTypes:
            omStaticData?.periodType?.map((periodType) => ({
                id: periodType.code,
                value: periodType.abbr,
            })) || [],
        reasonCodes: getUniqueValuesSorted(
            omStaticData?.reasonCodes?.map((code) => ({
                id: code.code,
                value: code.description,
            })),
        ),
        loadTypes: getUniqueValuesSorted(
            omStaticData?.loadTypes?.map((loadType) => ({
                id: loadType.code,
                value: loadType.description,
            })) || [],
        ),
        orderStatusReasonCodes: getUniqueValuesSorted(
            omStaticData?.orderStatusReasonCodes?.map((loadType) => ({
                id: loadType.code,
                value: loadType.description,
            })) || [],
        ),
        shortTimezones: mdmResponseData?.time_zones_juris,
        serviceFailureList: omStaticData?.serviceFailureType?.map((e) => {
            const dataObj = {
                value: e?.abbr,
                id: String(e?.id),
            };
            return dataObj;
        }),
        locations: getUniqueValuesSorted(
            mdmResponseData?.locations?.map((location) => ({
                id: location?.location_id?.toString(),
                value: location?.location_name,
                type_id: location?.location_type_id,
            })),
        ),
        walmartWeeks: mdmResponseData?.wm_weeks,
    };
}
function isJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}
export function validateCmsConfigData(cmsConfigData) {
    if (!cmsConfigData || !cmsConfigData.payload || !cmsConfigData.payload.custom) return false;
    if (
        isNullOrUndefined(cmsConfigData.payload.custom.rowsPerPage) ||
        typeof cmsConfigData.payload.custom.rowsPerPage !== 'string'
    )
        return false;
    if (
        isNullOrUndefined(cmsConfigData.payload.custom.debounceTime) ||
        typeof cmsConfigData.payload.custom.debounceTime !== 'string'
    )
        return false;
    if (
        isNullOrUndefined(cmsConfigData.payload.custom.country) ||
        typeof cmsConfigData.payload.custom.country !== 'string' ||
        !isJsonString(cmsConfigData.payload.custom.country)
    )
        return false;
    if (isNullOrUndefined(cmsConfigData.payload.custom.UOM) || typeof cmsConfigData.payload.custom.UOM !== 'string')
        return false;
    if (
        isNullOrUndefined(cmsConfigData.payload.custom.featureFlags) ||
        typeof cmsConfigData.payload.custom.featureFlags !== 'string'
    )
        return false;
    return true;
}
export function transformCmsData(cmsConfigData) {
    if (!validateCmsConfigData(cmsConfigData)) throw new Error('Invalid CMS config data');
    return {
        rowsPerPage: parseInt(cmsConfigData.payload.custom.rowsPerPage, 10),
        maxRowSelected: parseInt(cmsConfigData?.payload?.custom?.maxRowSelected || 0, 10),
        durationTimeHorizon: parseInt(cmsConfigData.payload.custom.durationTimeHorizon, 10),
        debounceTime: parseInt(cmsConfigData.payload.custom.debounceTime, 10),
        maxTimeHorizonHours: parseInt(cmsConfigData.payload.custom.maxTimeHorizonHours, 10),
        country: JSON.parse(cmsConfigData.payload.custom.country),
        UOM: JSON.parse(cmsConfigData.payload.custom.UOM),
        featureFlags: JSON.parse(cmsConfigData.payload.custom.featureFlags),
        paginationSize: cmsConfigData.payload.custom?.paginationSize
            ? parseInt(cmsConfigData.payload.custom.paginationSize, 10)
            : 0,
        tabStatus: cmsConfigData.payload.custom?.tabStatus ? JSON.parse(cmsConfigData.payload.custom?.tabStatus) : {},
        planAggsIndex: cmsConfigData.payload.custom?.planAggsIndex
            ? JSON.parse(cmsConfigData.payload.custom?.planAggsIndex)
            : null,
        sortFields: cmsConfigData.payload.custom?.sortFields
            ? JSON.parse(cmsConfigData.payload.custom?.sortFields)
            : null,
        defaultOlsenTimezoneId: cmsConfigData.payload.custom?.defaultOlsenTimezoneId
            ? cmsConfigData.payload.custom?.defaultOlsenTimezoneId
            : null,
        bulkSemiColonDeliColumnCount: cmsConfigData.payload.custom?.bulkSemiColonDeliColumnCount
            ? parseInt(cmsConfigData.payload.custom?.bulkSemiColonDeliColumnCount, 10)
            : 95,
        trailerStatusCode: cmsConfigData.payload.custom?.trailerStatusCode
            ? JSON.parse(cmsConfigData.payload.custom?.trailerStatusCode)
            : undefined,
        size: cmsConfigData.payload.custom?.size ? JSON.parse(cmsConfigData.payload.custom?.size) : undefined,
        entityType: cmsConfigData.payload.custom?.entityType ? cmsConfigData.payload.custom?.entityType : undefined,
        ymsEvent: cmsConfigData.payload.custom?.ymsEvent ? cmsConfigData.payload.custom?.ymsEvent : undefined,
        trailerLocType: cmsConfigData.payload.custom?.trailerLocType
            ? cmsConfigData.payload.custom?.trailerLocType
            : undefined,
        hazmatUpdateAllowedPlanTypes:
            cmsConfigData?.payload?.custom?.hazmatUpdateAllowedPlanTypes &&
            isJsonString(cmsConfigData?.payload?.custom?.hazmatUpdateAllowedPlanTypes)
                ? JSON.parse(cmsConfigData?.payload?.custom?.hazmatUpdateAllowedPlanTypes)
                : [],
        standardDateTimeFormat: cmsConfigData?.payload?.custom?.standardDateTimeFormat
            ? JSON.parse(cmsConfigData?.payload?.custom?.standardDateTimeFormat)
            : { dateTime: DATE_FNS_DATE_TIME_FORMAT, date: 'dd MMM, yyyy', time: 'hh:mm aaa' },
        WTMSLoadlength: cmsConfigData.payload.custom?.WTMSLoadlength
            ? parseInt(cmsConfigData.payload.custom.WTMSLoadlength, 10)
            : 0,
        WTMSLoadSeries:
            cmsConfigData?.payload?.custom?.WTMSLoadSeries &&
            isJsonString(cmsConfigData?.payload?.custom?.WTMSLoadSeries)
                ? JSON.parse(cmsConfigData?.payload?.custom?.WTMSLoadSeries)
                : [],
        WTMSCreatedSourceSystem: cmsConfigData?.payload?.custom?.WTMSCreatedSourceSystem
            ? JSON.parse(cmsConfigData?.payload?.custom?.WTMSCreatedSourceSystem)
            : '',
    };
}
export const errorHandler = (error) => {
    if (error?.errors) {
        // backend API failed
        return error;
    }
    // GSCOPE API failed
    return {
        key: 'pageError.summary.noService',
    };
};
export const transformMdmLocationTypes = (mdmLocationsTypes) => {
    const locationAbbrMap = {};
    mdmLocationsTypes.forEach((e) => {
        locationAbbrMap[e.code] = e.abbr;
    });
    return locationAbbrMap;
};
export const getTransformedCarrierList = (tariffList, carrierList) => {
    const carriersInTariffList = new Set();
    const recommendedCarriers = [];
    tariffList.forEach((tariff) => {
        tariff.tariff_details.forEach((tariffDetail) => {
            carriersInTariffList.add(tariffDetail.carrier);
        });
    });
    carrierList.forEach((carrier) => {
        if (
            carrier?.primary_info?.is_active &&
            carriersInTariffList.has(carrier?.carrier_identifiers?.[0].carrier_id)
        ) {
            recommendedCarriers.push({
                id: carrier?.carrier_identifiers?.[0].carrier_id,
                name: carrier?.primary_info?.carrier_name,
                mdm_carrier_id: carrier?.primary_info?.mdm_carrier_id,
                recommended: true,
            });
        }
    });
    return recommendedCarriers;
};
