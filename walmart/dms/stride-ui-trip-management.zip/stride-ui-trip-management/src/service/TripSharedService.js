import { getBulkUploadEnvironment } from '@walmart/stride-ui-commons';
class TripSharedService {
    CMSData;
    currentLanguage;
    tripStaticData;
    permissions;
    environment;
    pageSettings;
    featureFlags;
    trans;
    standardDateTimeFormat;
    setConfig = (data) => {
        this.CMSData = data;
    };
    getConfig = () => this.CMSData;
    setCurrentLanguage = (lang) => {
        this.currentLanguage = lang;
    };
    getCurrentLanguage = () => this.currentLanguage;
    setTripStaticData = (data, language) => {
        this.setCurrentLanguage(language);
        this.tripStaticData = data;
    };
    getTripStaticData = () => this.tripStaticData;
    setUserPermissions = (data) => {
        this.userPermissions = data;
    };
    getUserPermissions = () => this.userPermissions;
    getEnvironment = () => this.environment;
    setEnvironment = (options) => {
        this.environment = getBulkUploadEnvironment(options);
    };
    setPageLoadSettings = (settings) => {
        this.pageSettings = settings;
    };
    getPageLoadSettings = () => this.pageSettings;
    setFeatureFlags = (flags) => {
        this.featureFlags = flags;
    };
    getFeatureFlags = () => this.featureFlags;
    getTrans = () => this.trans;
    setTrans = (trans) => {
        this.trans = trans;
    };
    getStandardDateTimeFormat = () => this.standardDateTimeFormat;
    setStandardDateTimeFormat = (standardDateTimeFormat) => {
        this.standardDateTimeFormat = standardDateTimeFormat;
    };
}
export default new TripSharedService();
