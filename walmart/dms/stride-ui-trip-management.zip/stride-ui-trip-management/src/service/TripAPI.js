import { ServiceBase, getTenant, getLocaleCountry, isMxMkp } from '@walmart/stride-ui-commons';
import TripSharedService from './TripSharedService';
import { BASE_URL, defaultTimeout } from '../Constants';
import axios from '../axios';
import { getUsUsTenantFlagValue } from '../utils/CommonUtils';
export function TripAPI(market, language, userId, userName) {
    const serviceTypeReal = 'stride-ResouceBEAPI';
    const tenantHeaderValue = getTenant(market, {
        hostname: window.location.hostname,
        usUsTenant: getUsUsTenantFlagValue(market, false),
    });

    const tenantIdForMDM = getTenant(market, {
        hostname: window.location.hostname,
        usUsTenant: getUsUsTenantFlagValue(market, true),
    });
    const headers = {
        languageCode: getLocaleCountry(language, market, true),
        locale: getLocaleCountry(language, market, false),
        userId,
        userName,
        'WM_SVC.TENANT_ID': tenantHeaderValue,
        'WM_CONSUMER.TENANT_ID': tenantHeaderValue,
        tenantId: tenantHeaderValue,
    };

    const headerForMDM = {
        languageCode: getLocaleCountry(language, market, true),
        locale: getLocaleCountry(language, market, false),
        userId,
        userName,
        'WM_SVC.TENANT_ID': tenantIdForMDM,
        'WM_CONSUMER.TENANT_ID': tenantIdForMDM,
        tenantId: tenantIdForMDM,
    };
    const addtionalHeaderDetails = {
        ...headers,
        tnt_tenantId: tenantHeaderValue,
        tender_tenantId: tenantHeaderValue,
        responseGroup: 'TRANS.STRIDE_MDM.LOCATION',
    };

    const serviceForMDM = (type) =>
        ServiceBase({
            serviceType: type,
            headers: headerForMDM,
            axios,
            opt: {
                timeout: TripSharedService.getConfig()
                    ? TripSharedService.getConfig().payload.custom.timeout
                    : defaultTimeout,
            },
            baseUrl: BASE_URL,
        });
    const serviceWithAdditionalDetails = (type) =>
        ServiceBase({
            serviceType: type,
            headers: addtionalHeaderDetails,
            axios,
            opt: {
                timeout: TripSharedService.getConfig()
                    ? TripSharedService.getConfig().payload.custom.timeout
                    : defaultTimeout,
            },
            baseUrl: BASE_URL,
        });

    // const cancelTokenSoure = axios.CancelToken.source();
    const service = (type) =>
        ServiceBase({
            serviceType: type,
            headers,
            axios,
            opt: {
                timeout: TripSharedService.getConfig()
                    ? TripSharedService.getConfig().payload.custom.timeout
                    : defaultTimeout,
            },
            baseUrl: BASE_URL,
        });

    // service for Regenerate BOL
    const regernateBolService = (type, planId) =>
        ServiceBase({
            serviceType: type,
            headers: {
                ...headers,
                planId,
            },
            axios,
            opt: {
                timeout: TripSharedService.getConfig()
                    ? TripSharedService.getConfig().payload.custom.timeout
                    : defaultTimeout,
            },
            baseUrl: BASE_URL,
        });

    const getDoubleTrailerDetails = (type) =>
        ServiceBase({
            serviceType: type,
            headers: { ...headers, isDoubleLoad: true },
            axios,
            opt: {
                timeout: TripSharedService.getConfig()
                    ? TripSharedService.getConfig().payload?.custom?.timeout
                    : defaultTimeout,
            },
            baseUrl: BASE_URL,
        });

    // const getStaticData = (data) => service(serviceTypeOrch).post({ route: ['staticData'] }, data);

    // const getPlanPreview =
    // (data) => service(serviceTypeOrch).post({ route: ['planPreview'] }, data, headers);

    const getLTPlanPreview = (data) =>
        service('stride-ui-trip-management-planLTPreview').post(
            {
                route: ['planLTPreview'],
            },
            data,
            headers,
        );
    const planSearchAggregates = ({ cancelToken, ...data }) =>
        service('stride-ui-trip-management-planSearchAggregates').post(
            {
                route: ['planSearchAggregates'],
            },
            data,
            headers,
            {
                cancelToken: cancelToken,
            },
        );
    const getCDPlanPreview = (data) =>
        service('stride-ui-trip-management-planCDPreview').post(
            {
                route: ['planCDPreview'],
            },
            data,
            headers,
        );
    const approveStatusChange = (data) =>
        service('stride-ui-trip-management-approveStatusChange').post(
            {
                route: ['approveStatusChange'],
            },
            data,
            headers,
        );
    const ddStatusChange = (data) =>
        service('stride-ui-trip-management-markInTransitDelivered').post(
            {
                route: ['markInTransitDelivered'],
            },
            data.payload,
            {},
            {
                cancelToken: data.ct,
            },
        );
    const assignTrip = (data) =>
        service('stride-ui-trip-management-assignTrip').post(
            {
                route: ['assignTrip'],
            },
            data,
            headers,
        );
    const getTrips = (data) =>
        service('stride-ui-trip-management-planPreview').post(
            {
                route: ['planPreview'],
            },
            data,
            headers,
        );
    const autoTender = (data) =>
        service('stride-ui-trip-management-autoTender').post(
            {
                route: [`autoTender?planId=${data.payload?.planId}`],
            },
            data.payload,
            {},
            {
                cancelToken: data.ct,
            },
        );
    const getDriverEqup = (data) =>
        service('stride-ui-trip-management-getEquipmentDrivers').post(
            {
                route: ['getEquipmentDrivers'],
            },
            data,
        );
    const validateEquipment = (data) =>
        service('stride-ui-trip-management-validateEquipment').post(
            {
                route: ['validateEquipment'],
            },
            data,
        );
    const validateDriver = (data) =>
        service('stride-ui-trip-management-validateDriver').post(
            {
                route: ['validateDriver'],
            },
            data,
        );
    const fetchCarrierData = (data) =>
        serviceForMDM('stride-ui-trip-management-fetchCarrierData').post(
            {
                route: ['fetchCarrierData'],
            },
            data,
        );
    const fetchStaticData = (data) =>
        serviceForMDM('stride-ui-trip-management-fetchStaticData').post(
            {
                route: ['fetchStaticData'],
            },
            data,
            headers,
        );
    const getStaticData = (data) =>
        serviceForMDM('stride-ui-trip-management-workloadStaticData').post(
            {
                route: ['workloadStaticData'],
            },
            data,
        );
    const approveAssignment = (data) =>
        service('stride-ui-trip-management-approveAssignment').post(
            {
                route: ['approveAssignment'],
            },
            data.payload,
        );
    const updateInTransitPlan = (data) =>
        serviceWithAdditionalDetails('stride-ui-trip-management-updateInTransitPlan').post(
            {
                route: ['updateInTransitPlan'],
            },
            data,
        );
    const updateWorkloadAssignment = (data) =>
        service('stride-ui-trip-management-updateWorkloadAssignment').post(
            {
                route: ['updateWorkloadAssignment'],
                query: {
                    planId: data.planId,
                },
            },
            data.payload,
        );
    const createWorkloadAssignment = (data) =>
        service('stride-ui-trip-management-createWorkloadAssignment').post(
            {
                route: ['createWorkloadAssignment'],
                query: {
                    planId: data.planId,
                },
            },
            data.payload,
        );
    const createResourceAssignment = (data) =>
        service('stride-ui-trip-management-createResourceAssign').post(
            {
                route: ['createResourceAssign'],
            },
            data.payload,
        );
    const updateResourceAssignment = (data) =>
        service('stride-ui-trip-management-updateResourceAssign').post(
            {
                route: ['updateResourceAssign'],
            },
            data.payload,
        );
    const carrierAssign = (data) =>
        service('stride-ui-trip-management-assignCarrier').post(
            {
                route: ['assignCarrier'],
                query: {
                    planId: data.planId,
                },
            },
            data,
        );
    const downloadDispatch = (data) =>
        service(serviceTypeReal).post(
            {
                route: ['getDispatchDocument'],
            },
            data.payload,
            {},
            {
                cancelToken: data.ct,
            },
        );
    const dispatchLabel = (data) =>
        service(serviceTypeReal).post(
            {
                route: ['getDispatchLabel'],
            },
            data.payload,
            {},
            {
                cancelToken: data.ct,
            },
        );
    const getLoadDetails = (data) =>
        serviceWithAdditionalDetails('stride-ui-trip-management-loadDetails').post({
            route: ['loadDetails'],
            query: {
                planId: data,
            },
        });
    const getCarrierList = (data) =>
        service('stride-ui-trip-management-getCarriers').post(
            {
                route: ['getCarriers'],
            },
            data,
        );
    const getMDMLTMStaticData = (data) =>
        serviceForMDM('stride-ui-trip-management-staticData').post(
            {
                route: ['staticData'],
            },
            data,
        );
    const getPlanCounts = (data) =>
        service('stride-ui-trip-management-planCounts').post(
            {
                route: ['planCounts'],
            },
            data,
        );
    const getTripDetails = (data) =>
        service('stride-ui-trip-management-getTripDetails').post({
            route: ['tripDetails'],
            query: {
                planId: data,
            },
        });
    const updateTrackingPlan = (data) =>
        service('stride-ui-trip-management-updateTrackingPlan').post(
            {
                route: ['updateTrackingPlan'],
            },
            data,
        );
    const regernateBolLoad = (data) =>
        regernateBolService('stride-ui-trip-management-regenrateBOL', data.planId).post({
            route: ['regenrateBOL'],
            data: {},
        });
    const getAllLoadsDetail = (data) =>
        serviceWithAdditionalDetails('stride-ui-trip-management-getLoadDetails').post({
            route: ['loadDetails'],
            query: {
                planId: data,
            },
        });
    const createDoubleTrailerTrip = (data) =>
        getDoubleTrailerDetails('stride-ui-trip-management-createDoubleTrailer').post(
            { route: ['createDoubleTrailer'] },
            data,
        );
    const withdrawTender = (data) =>
        service('stride-ui-trip-management-withdrawTender').post(
            {
                route: ['withdrawTender'],
                query: {
                    planId: data.planId,
                },
            },
            {},
            {},
            {
                cancelToken: data.ct,
            },
        );
    return {
        getStaticData,
        getLTPlanPreview,
        planSearchAggregates,
        getCDPlanPreview,
        approveStatusChange,
        assignTrip,
        getDriverEqup,
        getTrips,
        createWorkloadAssignment,
        ddStatusChange,
        autoTender,
        validateEquipment,
        validateDriver,
        fetchCarrierData,
        updateWorkloadAssignment,
        approveAssignment,
        createResourceAssignment,
        updateResourceAssignment,
        carrierAssign,
        downloadDispatch,
        dispatchLabel,
        getCarrierList,
        fetchStaticData,
        getLoadDetails,
        updateInTransitPlan,
        getMDMLTMStaticData,
        getPlanCounts,
        getTripDetails,
        updateTrackingPlan,
        regernateBolLoad,
        getAllLoadsDetail,
        createDoubleTrailerTrip,
        withdrawTender,
    };
}
export function CommonAPI(market) {
    const configService = ServiceBase({
        serviceType: 'cms',
        axios,
        opt: {
            timeout: TripSharedService.getConfig()
                ? TripSharedService.getConfig().payload.custom.timeout
                : defaultTimeout,
        },
        baseUrl: BASE_URL,
    });
    const getConfig = () =>
        configService.get({
            route: ['getConfig'],
            query: {
                path: `${isMxMkp(market) ? '/mfe' : ''}/stride/tripmanagement`,
                market,
            },
        });
    return {
        getConfig,
    };
}
export function PageLoadAPI(market, language, userId, userName) {
    const getPageLoadData = (staticDataRequest) =>
        Promise.all([
            CommonAPI(market).getConfig(),
            TripAPI(market, language, userId, userName).getMDMLTMStaticData(staticDataRequest),
        ]);
    return {
        getPageLoadData,
    };
}
export function DownloadDispatchDocAndLabelAPI(market, language, userId, userName) {
    const pageLoadSetting = TripSharedService.getPageLoadSettings();
    const getDownloadResponse = (req) =>
        Promise.all([
            TripAPI(market, language, userId, userName).downloadDispatch(req),
            pageLoadSetting?.downloadDispatchLabel && TripAPI(market, language, userId, userName).dispatchLabel(req),
        ]);
    return {
        getDownloadResponse,
    };
}

export const getAutoEntityAPIParams = (currentMarket, lang, userInfo) => {
    const apiConfig = {
        axios,
        language: lang,
        timeout: defaultTimeout,
        userId: userInfo.loggedInUserName,
        userName: userInfo.displayName,
        currentMarket,
        usUsTenantFlag: true,
        baseUrl: BASE_URL,
    };

    if (TripSharedService.getFeatureFlags()?.enableExternalUser) {
        apiConfig.ccmServiceName = 'stride-ui-external-trip-management-mdmAutoComplete';
        apiConfig.ccmRouteName = 'mdmAutoComplete';
    }

    return apiConfig;
};

export const getAPIParams = (currentMarket, lang, userInfo) => {
    const apiConfig = {
        axios,
        language: lang,
        timeout: defaultTimeout,
        userId: userInfo.loggedInUserName,
        userName: userInfo.displayName,
        currentMarket,
        usUsTenantFlag: true,
        baseUrl: BASE_URL,
    };

    return apiConfig;
};

export const getSplitLoadAPIParams = (market, prefLang, userInfo) => {
    const tenant = getTenant(market, { hostname: window.location.hostname, usUsTenant: true });
    const headers = {
        languageCode: `${prefLang}-${market?.toUpperCase()}`,
        locale: `${prefLang}-${market?.toUpperCase()}`,
        userId: userInfo?.loggedInUserName,
        'WM_SVC.TENANT_ID': tenant,
        tenantId: tenant,
    };
    return {
        axios,
        timeout: defaultTimeout,
        ccmServiceName: 'stride-ui-trip-management-splitLoad',
        ccmRouteName: 'splitLoad',
        baseUrl: BASE_URL,
        headers,
        restAPIMethod: 'post',
    };
};

export const getEditDriverETDAPIParams = (currentMarket, lang, userInfo) => {
    const headers = {
        languageCode: `${lang}-${currentMarket?.toUpperCase()}`,
        'user-market': currentMarket?.toUpperCase(),
    };
    const apiConfig = {
        axios,
        language: lang,
        timeout: defaultTimeout,
        userId: userInfo.loggedInUserName,
        userName: userInfo.displayName,
        currentMarket,
        usUsTenantFlag: true,
        baseUrl: BASE_URL,
        ccmServiceNameGetDriver: 'stride-ui-trip-management-getDriverETD',
        ccmRouteNameGetDriver: 'getDriverETD',
        ccmServiceNameUpdateDriverETD: 'stride-ui-trip-management-updateDriverETD',
        ccmRouteNameUpdateDriverETD: 'updateDriverETD',
        ccmServiceNameOnHoldDriverETD: 'stride-ui-trip-management-onHoldDriverETD',
        ccmRouteNameOnHoldDriverETD: 'onHoldDriverETD',
        restAPIMethod: 'post',
        headers,
    };

    return apiConfig;
};

export const tripDetailsHeaders = (currentMarket, lang, userInfo, hostname, usUsTenantFlag) => {
    // const tenantId = getTenantId(currentMarket, hostname, usUsTenantFlag);
    const tenantId = getTenant(currentMarket, {
        hostname,
        usUsTenant: getUsUsTenantFlagValue(currentMarket, usUsTenantFlag),
    });
    const headers = {
        languageCode: getLocaleCountry(lang, currentMarket, true),
        userId: userInfo.loggedInUserName,
        userName: userInfo.displayName,
        locale: getLocaleCountry(lang, currentMarket, false),
        'WM_SVC.TENANT_ID': tenantId,
        tnt_tenantId: tenantId,
        tenantId,
        tender_tenantId: tenantId,
        responseGroup: 'TRANS.STRIDE_MDM.LOCATION',
    };
    return headers;
};

export const planAdditionalHeaders = {
    responseGroup: 'TRANS.STRIDE_MDM.LOCATION',
};

export const getTripDetailsAPIParamsWithQueryParam = (params) => {
    const { currentMarket, lang, userInfo, hostname, usUsTenantFlag, planId } = params;
    return {
        axios,
        timeout: TripSharedService.getConfig() ? TripSharedService.getConfig().payload.custom.timeout : defaultTimeout,
        ccmServiceName: 'stride-ui-trip-management-getTripDetails',
        ccmRouteName: 'tripDetails',
        baseUrl: BASE_URL,
        currentMarket,
        headers: tripDetailsHeaders(currentMarket, lang, userInfo, hostname, usUsTenantFlag),
        additionalHeaders: planAdditionalHeaders,
        queryAndPathParams: {
            planId,
        },
    };
};

export const getLoadDetailsAPIParamsWithQueryParam = (params) => {
    const { currentMarket, lang, userInfo, hostname, usUsTenantFlag, planId } = params;
    return {
        axios,
        timeout: TripSharedService.getConfig() ? TripSharedService.getConfig().payload.custom.timeout : defaultTimeout,
        ccmServiceName: 'stride-ui-trip-management-getLoadDetails',
        ccmRouteName: 'loadDetails',
        baseUrl: BASE_URL,
        currentMarket,
        additionalHeaders: planAdditionalHeaders,
        headers: tripDetailsHeaders(currentMarket, lang, userInfo, hostname, usUsTenantFlag),
        queryAndPathParams: {
            planId,
        },
    };
};

export const getLosStaticDataAPIParams = (currentMarket, lang, userInfo, hostname, usUsTenantFlag, featureFlags) => {
    const tenantId = getTenant(currentMarket, {
        hostname,
        usUsTenant: getUsUsTenantFlagValue(currentMarket, usUsTenantFlag),
    });
    return {
        axios,
        timeout: TripSharedService.getConfig() ? TripSharedService.getConfig().payload.custom.timeout : defaultTimeout,
        ccmServiceName: featureFlags?.losStaticDataV2
            ? 'stride-ui-trip-management-fetchStaticDataV2'
            : 'stride-ui-trip-management-fetchStaticData',
        ccmRouteName: 'fetchStaticData',
        baseUrl: BASE_URL,
        headers: {
            languageCode: getLocaleCountry(lang, currentMarket, true),
            userId: userInfo?.loggedInUserName,
            userName: userInfo?.displayName,
            locale: getLocaleCountry(lang, currentMarket, false),
            'WM_SVC.TENANT_ID': tenantId,
            'WM_CONSUMER.TENANT_ID': tenantId,
            tenantId,
            'Accept-Language': lang,
        },
    };
};

export const getLocationDetailsApiParams = (currentMarket, lang, userInfo, hostname, usUsTenantFlag) => {
    const tenantId = getTenant(currentMarket, {
        hostname,
        usUsTenant: getUsUsTenantFlagValue(currentMarket, usUsTenantFlag),
    });
    return {
        axios,
        timeout: TripSharedService.getConfig() ? TripSharedService.getConfig().payload.custom.timeout : defaultTimeout,
        ccmServiceName: 'stride-ui-trip-management-fetchLocationDeliveryWindow',
        ccmRouteName: 'fetchLocationDeliveryWindow',
        baseUrl: BASE_URL,
        headers: {
            'WM_SVC.TENANT_ID': tenantId,
            userId: userInfo?.loggedInUserName,
            userName: userInfo?.displayName,
            tenantId,
            languageCode: getLocaleCountry(lang, currentMarket, true),
            responseGroup: 'deliverySchedules',
        },
    };
};

export const getEditTrailerIdsApiParams = (currentMarket, lang, userInfo, hostname, usUsTenantFlag) => {
    const tenantId = getTenant(currentMarket, {
        hostname,
        usUsTenant: getUsUsTenantFlagValue(currentMarket, usUsTenantFlag),
    });
    return {
        axios,
        timeout: TripSharedService.getConfig() ? TripSharedService.getConfig().payload.custom.timeout : defaultTimeout,
        ccmServiceName: 'stride-ui-trip-management-editTrailerIds',
        ccmRouteName: 'editTrailerIds',
        baseUrl: BASE_URL,
        headers: {
            userId: userInfo?.loggedInUserName,
            userName: userInfo?.displayName,
            tenantId,
            languageCode: getLocaleCountry(lang, currentMarket, true),
        },
    };
};

export const getUpdateTimelineApiParams = (currentMarket, lang, userInfo, hostname, usUsTenantFlag) => {
    const tenantId = getTenant(currentMarket, {
        hostname,
        usUsTenant: getUsUsTenantFlagValue(currentMarket, usUsTenantFlag),
    });
    return {
        axios,
        timeout: TripSharedService.getConfig() ? TripSharedService.getConfig().payload.custom.timeout : defaultTimeout,
        ccmServiceName: 'stride-ui-trip-management-updateTrackingPlan',
        ccmRouteName: 'updateTrackingPlan',
        baseUrl: BASE_URL,
        headers: {
            userId: userInfo?.loggedInUserName,
            userName: userInfo?.displayName,
            tenantId,
            tnt_tenantId: tenantId,
            'WM_SVC.TENANT_ID': tenantId,
            languageCode: getLocaleCountry(lang, currentMarket, true),
        },
    };
};

export const getMultiLocationDetailsApiParams = (currentMarket, lang, userInfo, usUsTenantFlag) => ({
    axios,
    ccmServiceName: 'stride-ui-trip-management-fetchMultiLocations',
    ccmRouteName: 'fetchMultiLocations',
    baseUrl: BASE_URL,
    userId: userInfo?.loggedInUserName,
    language: lang,
    currentMarket,
    usUsTenantFlag,
});

export const getDmaasPrintTripSheetApiParams = (currentMarket, lang, userInfo, hostname, usUsTenantFlag) => {
    const tenantId = 'WALMART_US';
    // TODO: this would be added in UI orchestrator in future
    const system = 'STRIDE_UI_ORCHESTRATOR';
    return {
        axios,
        ccmServiceName: 'stride-ui-trip-management-printTripSheet',
        ccmRouteName: 'printTripSheet',
        baseUrl: BASE_URL,
        userId: userInfo?.loggedInUserName,
        language: lang,
        currentMarket,
        usUsTenantFlag,
        tenantId,
        system,
        additionalHeaders: {
            WM_TENANT: tenantId,
            WM_SYSTEM: system,
        },
    };
};

export const getCancelLoadParams = (params) => {
    const { currentMarket, lang, userInfo, hostname, usUsTenantFlag } = params;
    return {
        axios,
        ccmServiceName: 'stride-ui-trip-management-cancelLoadMulti',
        ccmRouteName: 'cancelLoadMulti',
        userId: userInfo?.loggedInUserName,
        language: lang,
        currentMarket,
        baseUrl: BASE_URL,
        additionalHeaders: {
            ...tripDetailsHeaders(currentMarket, lang, userInfo, hostname, usUsTenantFlag),
            ...planAdditionalHeaders,
        },
    };
};
