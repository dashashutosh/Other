export default class TripUiWorkloadPhaseEnum {
    static PLANNING = new TripUiWorkloadPhaseEnum('PLANNING', 0, 'trip.workflow.phase.planning');
    static PROCESSING = new TripUiWorkloadPhaseEnum('PROCESSING', 1, 'trip.workflow.phase.processing');
    static DISPATCH = new TripUiWorkloadPhaseEnum('DISPATCH', 2, 'trip.workflow.phase.dispatch');
    static IN_TRANSIT = new TripUiWorkloadPhaseEnum('IN_TRANSIT', 3, 'trip.workflow.phase.in.transit');
    static DELIVERED = new TripUiWorkloadPhaseEnum('DELIVERED', 4, 'trip.workflow.phase.delivered');
    static POST_PROCESSING = new TripUiWorkloadPhaseEnum('POST_PROCESSING', 5, 'trip.workflow.phase.post.processing');
    static COMPLETED = new TripUiWorkloadPhaseEnum('COMPLETED', 6, 'trip.workflow.phase.completed');
    static CANCELLED = new TripUiWorkloadPhaseEnum('CANCELLED', 7, 'trip.workflow.phase.cancelled');
    constructor(name, index, desc) {
        this.name = name;
        this.index = index;
        this.desc = desc;
        Object.freeze(this);
    }
}
