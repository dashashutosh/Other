export default class LoadUIStatusEnum {
    static UNPLANNED = new LoadUIStatusEnum('UNPLANNED', 0, 'load.status.unplanned');
    static PLANNED = new LoadUIStatusEnum('PLANNED', 1, 'load.status.planned');
    static WORKLOAD_ASSIGNMENT = new LoadUIStatusEnum('WORKLOAD_ASSIGNMENT', 2, 'load.status.workload.assignment');
    static AWAITING_FINALIZATION = new LoadUIStatusEnum(
        'AWAITING_FINALIZATION',
        3,
        'load.status.awaiting.finalization',
    );
    static READY_FOR_DISPATCH = new LoadUIStatusEnum('READY_FOR_DISPATCH', 4, 'load.status.ready.for.dispatch');
    static IN_TRANSIT = new LoadUIStatusEnum('IN_TRANSIT', 5, 'load.status.in.transit');
    static DELIVERED = new LoadUIStatusEnum('DELIVERED', 6, 'load.status.delivered');
    static POST_PROCESSING = new LoadUIStatusEnum('POST_PROCESSING', 7, 'load.status.post.processing');
    static COMPLETED = new LoadUIStatusEnum('COMPLETED', 8, 'load.status.completed');
    static CANCELLED = new LoadUIStatusEnum('CANCELLED', 9, 'load.status.cancelled');

    // For CA
    static PENDING_APPROVAL_LOAD = new LoadUIStatusEnum('PENDING_APPROVAL', 10, 'load.status.pending.approval');
    static TENDER_IN_PROGRESS = new LoadUIStatusEnum('TENDER_IN_PROGRESS', 10, 'load.status.tenderProgress');
    static TENDERS_EXHAUSTED = new LoadUIStatusEnum('TENDERS_EXHAUSTED', 11, 'load.status.tenderExhausted');
    static TENDER_CANCELLED = new LoadUIStatusEnum('TENDER_CANCELLED', 12, 'plan.status.tender.cancel');
    static PICKUP_DELAYED = new LoadUIStatusEnum('NOT_STARTED_AT_RISK', 13, 'plan.status.not.started.at.risk');
    static AWAITING_PICKUP = new LoadUIStatusEnum('NOT_STARTED_ON_TIME', 14, 'plan.status.not.started.on.time');
    static NEEDS_ATTENTION = new LoadUIStatusEnum('NEEDS_ATTENTION', 15, 'load.status.tenderExhausted');
    static IN_TRANSIT_STARTED = new LoadUIStatusEnum('IN_TRANSIT_STARTED', 16, 'plan.status.in.transit.started');
    static IN_TRANSIT_EARLY = new LoadUIStatusEnum('IN_TRANSIT_EARLY', 17, 'plan.status.in.transit.early');
    static IN_TRANSIT_ON_TIME = new LoadUIStatusEnum('IN_TRANSIT_ON_TIME', 18, 'plan.status.in.transit.on.time');
    static IN_TRANSIT_LATE = new LoadUIStatusEnum('IN_TRANSIT_LATE', 19, 'plan.status.in.transit.late');
    constructor(name, index, desc) {
        this.name = name;
        this.index = index;
        this.desc = desc;
        Object.freeze(this);
    }
}
