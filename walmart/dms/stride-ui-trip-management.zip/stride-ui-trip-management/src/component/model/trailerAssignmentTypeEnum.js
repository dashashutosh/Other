export default class TrailerAssignmentTypeEnum {
    static SINGLE_TRAILER = new TrailerAssignmentTypeEnum('SINGLE_TRAILER', 0, 'label.singleTrailer');
    static BASED_ON_LOAD_COUNT = new TrailerAssignmentTypeEnum('BASED_ON_LOAD_COUNT', 1, 'label.onLoadCount');
    constructor(name, index, desc) {
        this.name = name;
        this.index = index;
        this.desc = desc;
        Object.freeze(this);
    }
}
