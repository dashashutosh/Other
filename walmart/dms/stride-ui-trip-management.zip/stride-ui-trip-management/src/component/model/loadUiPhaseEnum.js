export default class LoadUiPhaseEnum {
    static UNPLANNED = new LoadUiPhaseEnum('UNPLANNED', 0, 'load.phase.planning');
    static PROCESSING = new LoadUiPhaseEnum('PROCESSING', 1, 'load.phase.processing');
    static DISPATCH = new LoadUiPhaseEnum('DISPATCH', 2, 'load.phase.dispatch');
    static IN_TRANSIT = new LoadUiPhaseEnum('IN_TRANSIT', 3, 'load.phase.in.transit');
    static DELIVERED = new LoadUiPhaseEnum('DELIVERED', 4, 'load.phase.delivered');
    static POST_PROCESSING = new LoadUiPhaseEnum('POST_PROCESSING', 5, 'load.phase.post.processing');
    static COMPLETED = new LoadUiPhaseEnum('COMPLETED', 6, 'load.phase.completed');
    static CANCELLED = new LoadUiPhaseEnum('CANCELLED', 7, 'load.phase.cancelled');
    constructor(name, index, desc) {
        this.name = name;
        this.index = index;
        this.desc = desc;
        Object.freeze(this);
    }
}
