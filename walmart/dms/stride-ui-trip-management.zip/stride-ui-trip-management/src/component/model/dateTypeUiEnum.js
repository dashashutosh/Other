export default class DateTypeUiEnum {
    static PLANNED_START_DATE = new DateTypeUiEnum('PLANNED_START_DATE', 'type.date.start');
    static PLANNED_END_DATE = new DateTypeUiEnum('PLANNED_END_DATE', 'type.date.end');
    constructor(name, desc) {
        this.name = name;
        this.desc = desc;
        Object.freeze(this);
    }
}
