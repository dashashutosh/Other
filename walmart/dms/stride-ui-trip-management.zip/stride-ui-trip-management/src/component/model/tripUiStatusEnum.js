export default class TripUIStatusEnum {
    static PENDING_APPROVAL = new TripUIStatusEnum('PENDING_APPROVAL', 0, 'trip.status.pending.approval');
    static WORKLOAD_ASSIGNMENT = new TripUIStatusEnum('WORKLOAD_ASSIGNMENT', 1, 'trip.status.workload.assignment');
    static AWAITING_FINALIZATION = new TripUIStatusEnum(
        'AWAITING_FINALIZATION',
        2,
        'trip.status.awaiting.finalization',
    );
    static READY_FOR_DISPATCH = new TripUIStatusEnum('READY_FOR_DISPATCH', 3, 'trip.status.ready.for.dispatch');
    static IN_TRANSIT = new TripUIStatusEnum('IN_TRANSIT', 4, 'trip.status.in.transit');
    static DELIVERED = new TripUIStatusEnum('DELIVERED', 5, 'trip.status.delivered');
    static POST_PROCESSING = new TripUIStatusEnum('POST_PROCESSING', 6, 'trip.status.post.processing');
    static COMPLETED = new TripUIStatusEnum('COMPLETED', 7, 'trip.status.completed');
    static CANCELLED = new TripUIStatusEnum('CANCELLED', 8, 'trip.status.cancelled');
    constructor(name, index, desc) {
        this.name = name;
        this.index = index;
        this.desc = desc;
        Object.freeze(this);
    }
}
