export default class TimehorizonUiPhaseEnum {
    static PAST = new TimehorizonUiPhaseEnum('PAST', 0, 'Past: All days');
    static FUTURE = new TimehorizonUiPhaseEnum('FUTURE', 1, 'Future: All days');
    constructor(name, index, desc) {
        this.name = name;
        this.index = index;
        this.desc = desc;
        Object.freeze(this);
    }
}
