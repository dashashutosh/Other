export default class TripUiTenderPhaseEnum {
    static OPEN_REQEUSTS = new TripUiTenderPhaseEnum('OPEN_REQEUSTS', 0, 'tender.phase.open.requests');
    static ASSIGN_DRIVER = new TripUiTenderPhaseEnum('ASSIGN_DRIVER', 1, 'tender.phase.assign.driver');
    static ACCEPTED_TRIPS = new TripUiTenderPhaseEnum('ACCEPTED_TRIPS', 2, 'tender.phase.accepted.trips');
    static NO_PHASE = new TripUiTenderPhaseEnum('NO_PHASE', 3, 'tender.phase.no.phase');
    constructor(name, index, desc) {
        this.name = name;
        this.index = index;
        this.desc = desc;
        Object.freeze(this);
    }
}
