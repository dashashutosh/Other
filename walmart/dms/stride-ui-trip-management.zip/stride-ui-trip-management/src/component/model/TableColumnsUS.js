import { useMemo } from 'react';
import clsx from 'clsx';
import { ArrowRightIcon, Badge, Button } from '@walmart/living-design-sc-ui';
import {
    PlanStatus,
    LOCATION_TYPE_ICON_MAP,
    BEPlanCategoryEnum,
    OperationalFlagEnum,
    getLocationTypeToIconMap,
    OperationalFlagStatus,
    calculateTimeDiff,
    TripActionsEnum,
    UIStatusEnum,
    ActionMenu,
    CommentPopoverTrigger,
    LoadActionsEnum,
    PlanDetailsMapper,
} from '@walmart/stride-ui-commons';
import { isAfter, isEqual } from 'date-fns';

import { enableRowExpansion } from '../trip-management-summary/US/DataModelsUS';
import { getActionDesc } from '../../utils/ui-mappers/US/TripDetailsMapper';

/** @typedef {import('@tanstack/react-table').ColumnDef<any>} ColumnDef */

/**
 *
 * @param {import('@tanstack/react-table').HeaderContext}} param
 * @returns
 */
const renderHeaderCellContent = ({ table, column }) => {
    const { trans } = table.options.meta;

    return trans(column.columnDef.meta.label);
};

/**
 *
 * @param {import('@tanstack/react-table').HeaderContext}} param
 * @returns
 */
const renderHeaderCellContentWithUOM = ({ table, column }) => {
    const { trans, cmsConfig, classes } = table.options.meta;
    const uomValue = cmsConfig?.UOM?.[column.columnDef.meta.uomKey];

    return (
        <div>
            <div>{trans(column.columnDef.meta.label)}</div>
            {uomValue ? <div className={classes.headerCellUOM}>({uomValue})</div> : null}
        </div>
    );
};

const getActionsDesc = (action, sCheckedPlans, trans) => {
    if (action?.name === TripActionsEnum.MARK_UNMARK_PRINTED.name) {
        return trans(getActionDesc(sCheckedPlans, action));
    } else if (action?.name === LoadActionsEnum.MARK_UNMARK_HAZMAT.name) {
        return trans(PlanDetailsMapper.getHazmatActionDesc(sCheckedPlans, action));
    } else {
        return trans(action.desc);
    }
};

const TableColumnsUS = {
    /** @type {ColumnDef} */
    PLAN_ID: {
        id: 'PLAN_ID',
        size: 120,
        accessorKey: 'planId',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.planId',
        },
        cell: ({ getValue, table, row }) => {
            const { navigateToDetailsPage } = table.options.meta;

            return row?.original?.uiStatus?.name === UIStatusEnum.WTMS_LOAD.name ? (
                getValue()
            ) : (
                <Button
                    variant="text-only"
                    className="p-0"
                    size="small"
                    onClick={() => navigateToDetailsPage(row.original)}
                >
                    {getValue()}
                </Button>
            );
        },
    },

    /** @type {ColumnDef} */
    TAGS: {
        id: 'TAGS',
        size: 100,
        accessorKey: 'hazmat',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.tags',
        },
        cell: ({ row, table }) => {
            const { trans } = table.options.meta;
            const isSubRow = row.depth > 0;
            const rowData = row.original;

            // eslint-disable-next-line react-hooks/rules-of-hooks
            const OperationalFlags = useMemo(() => {
                const OperationalFlagsList = [];
                if (rowData.hazmat === trans(OperationalFlagEnum.HAZMAT.name)) {
                    OperationalFlagsList.push(OperationalFlagEnum.HAZMAT);
                }
                if (rowData.printed === trans(OperationalFlagEnum.PRINTED.name)) {
                    OperationalFlagsList.push(OperationalFlagEnum.PRINTED);
                }
                if (rowData?.onHold?.onHold) {
                    OperationalFlagsList.push(OperationalFlagEnum.HOLD(rowData?.onHold?.holdReason));
                }
                return OperationalFlagsList;
            }, [rowData.hazmat, trans]);

            return (
                <>
                    {isSubRow ? (
                        <div>
                            <OperationalFlagStatus pOperationalFlags={OperationalFlags} />
                        </div>
                    ) : (
                        ''
                    )}
                    {rowData.isTrip && rowData.planType !== BEPlanCategoryEnum.IM?.code ? (
                        <div>
                            <OperationalFlagStatus pOperationalFlags={OperationalFlags} />
                        </div>
                    ) : (
                        <>
                            {!isSubRow && (
                                <div>
                                    <OperationalFlagStatus pOperationalFlags={OperationalFlags} />
                                </div>
                            )}
                        </>
                    )}
                </>
            );
        },
    },

    /** @type {ColumnDef} */
    PLAN_TYPE: {
        id: 'PLAN_TYPE',
        size: 160,
        accessorKey: 'planEntity',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.planType',
        },
        cell: ({ row, table }) => {
            const isSubRow = row.depth > 0;
            const { original: rowData } = row;
            const { queryState } = table.options.meta;

            return (
                <>
                    {isSubRow ? <div>{`${rowData.planEntity} - ${rowData.planType}`}</div> : ''}
                    {rowData.isTrip ? (
                        <span className="d-flex align-items-center gap-1">
                            {`${rowData.planEntity} - ${rowData.planType}`}

                            {enableRowExpansion(rowData, queryState) && (
                                <div className="ml-3">
                                    <Badge count={rowData.loadCount} variant="neutral" />
                                </div>
                            )}
                        </span>
                    ) : (
                        <>{!isSubRow && <div>{`${rowData.planEntity} - ${rowData.planType}`}</div>}</>
                    )}
                </>
            );
        },
    },

    /** @type {ColumnDef} */
    CARRIER_ID: {
        id: 'CARRIER_ID',
        size: 90,
        accessorKey: 'carrierId',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.carrier',
        },
    },

    /** @type {ColumnDef} */
    SERVICE_TERRITORY: {
        id: 'SERVICE_TERRITORY',
        size: 135,
        accessorKey: 'serviceTerritory',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.serviceTerritory',
        },
    },

    /** @type {ColumnDef} */
    TRIP_SERVICE_TERRITORY: {
        id: 'TRIP_SERVICE_TERRITORY',
        size: 160,
        accessorKey: 'tripServiceTerritory',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.tripServiceTerritory',
        },
    },

    /** @type {ColumnDef} */
    PLAN_SERVICE_TERRITORY: {
        id: 'PLAN_SERVICE_TERRITORY',
        size: 190,
        accessorKey: 'planningServiceTerritory',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.planningServiceTerritory',
        },
    },

    /** @type {ColumnDef} */
    TRAILER_ID: {
        id: 'TRAILER_ID',
        size: 160,
        accessorKey: 'trailerId',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.drayEquipmentID',
        },
        cell: ({ row }) => {
            const { original: rowData } = row;

            if (rowData.isTrip && rowData.planType !== BEPlanCategoryEnum.IM?.code) {
                return (
                    <span className="d-flex">
                        {`${rowData.trailerIdOfFirstLoadForTrip}`}
                        {rowData.trailerCountForTrip > 1 && (
                            <div className="ml-1">
                                <Badge count={`+${rowData.trailerCountForTrip - 1}`} variant="neutral" />
                            </div>
                        )}
                    </span>
                );
            }
            return rowData.trailerId;
        },
    },

    /** @type {ColumnDef} */
    DRIVER_ID: {
        id: 'DRIVER_ID',
        size: 200,
        accessorKey: 'driverId',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.driverId',
        },
        cell: ({ row, table }) => {
            const { original: rowData } = row;
            const { driverIdClickHandler } = table.options.meta;

            return rowData.isTrip ? (
                <>
                    {rowData.driverId !== '--' ? (
                        <>
                            <Button
                                id="lms-table-click"
                                size="small"
                                variant="text-only"
                                className="p-0"
                                onClick={() => driverIdClickHandler(rowData.driverId)}
                            >
                                {rowData.driverId}
                            </Button>
                            <div>{rowData.driverName}</div>
                        </>
                    ) : (
                        <div>{rowData.driverId}</div>
                    )}
                </>
            ) : (
                <div>{rowData.driverId}</div>
            );
        },
    },

    /** @type {ColumnDef} */
    ORIGIN_LOCATION_ID: {
        id: 'ORIGIN_LOCATION_ID',
        size: 240,
        accessorKey: 'originId',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.origin',
        },
        cell: ({ row, table }) => {
            const { original: _rowData } = row;
            // eslint-disable-next-line no-shadow
            const { navigateToLocationDetailsPage, classes, mdmLocationTypes } = table.options.meta;

            return (
                <div className="d-flex align-items-center">
                    <img
                        className={classes.imgOpacity}
                        src={LOCATION_TYPE_ICON_MAP[getLocationTypeToIconMap(_rowData.originType)]}
                        alt={`${_rowData.originType} icon`}
                    />
                    <div className="st-ui-ml-2">
                        <Button
                            id="lls-origin-click"
                            size="small"
                            variant="text-only"
                            className={clsx('p-0', classes.locationColumnButton)}
                            onClick={() => navigateToLocationDetailsPage(_rowData.originId, _rowData.originType)}
                        >
                            {`${mdmLocationTypes[_rowData.originType] || ''} - ${_rowData.originId} - ${
                                _rowData.originName
                            }`}
                        </Button>
                        <div className={classes.secondaryText}>
                            {`${_rowData.originCity},  ${_rowData.originProvince}`}
                        </div>
                    </div>
                </div>
            );
        },
    },

    /** @type {ColumnDef} */
    COMMENTS: {
        id: 'COMMENTS',
        size: 120,
        accessorKey: 'latestComment',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.comments',
        },
        cell: ({ row, table }) => {
            const { original: rowData } = row;
            const { userInfo, prefLang, onViewAllComments } = table.options.meta;

            return (
                <div className="d-flex flex-column align-items-center">
                    <CommentPopoverTrigger
                        pComment={rowData?.latestComment}
                        pUserInfo={userInfo}
                        pCurrentLang={prefLang?.current}
                        pSelectedPlan={rowData}
                        pOnViewAll={onViewAllComments}
                    />
                </div>
            );
        },
    },

    /** @type {ColumnDef} */
    DISTANCE: {
        id: 'DISTANCE',
        size: 120,
        accessorKey: 'distance',
        header: renderHeaderCellContentWithUOM,
        meta: {
            label: 'planColumns.distance',
            uomKey: 'distance',
        },
        cell: ({ row }) => {
            const { original: rowData } = row;

            return (
                <div className="d-flex flex-column align-items-center">
                    <ArrowRightIcon size="medium" />
                    <span style={{ fontSize: 14 }}>{rowData.distance}</span>
                </div>
            );
        },
    },

    /** @type {ColumnDef} */
    DESTINATION_LOCATION_ID: {
        id: 'DESTINATION_LOCATION_ID',
        size: 240,
        accessorKey: 'destinationId',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.drayFinalDestination',
        },
        cell: ({ row, table }) => {
            const { original: _rowData } = row;
            // eslint-disable-next-line no-shadow
            const { navigateToLocationDetailsPage, classes, mdmLocationTypes } = table.options.meta;

            return (
                <div className="d-flex align-items-center">
                    <img
                        className={classes.imgOpacity}
                        src={LOCATION_TYPE_ICON_MAP[getLocationTypeToIconMap(_rowData.destinationType)]}
                        alt={`${_rowData.destinationType} icon`}
                    />
                    <div className="st-ui-ml-2">
                        <Button
                            id="lls-destination-click"
                            size="small"
                            variant="text-only"
                            className={clsx('p-0', classes.locationColumnButton)}
                            onClick={() =>
                                navigateToLocationDetailsPage(_rowData.destinationId, _rowData.destinationType)
                            }
                        >
                            {`${mdmLocationTypes[_rowData.destinationType] || ''} - ${_rowData.destinationId} - ${
                                _rowData.destinationName
                            }`}
                        </Button>
                        <div className={classes.secondaryText}>
                            {`${_rowData.destinationCity},  ${_rowData.destinationProvince}`}
                        </div>
                    </div>
                </div>
            );
        },
    },

    /** @type {ColumnDef} */
    PRIMARY_DESTINATION_LOCATION_ID: {
        id: 'PRIMARY_DESTINATION_LOCATION_ID',
        size: 240,
        accessorKey: 'priDestinationId',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.priDestination',
        },
        cell: ({ row, table }) => {
            const { original: _rowData } = row;
            const { navigateToLocationDetailsPage, classes, mdmLocationTypes } = table.options.meta;

            return (
                <>
                    {_rowData.isTrip && _rowData.planType !== BEPlanCategoryEnum.IM?.code ? (
                        <div className="d-flex align-items-center">
                            {_rowData?.priDestinationId ? (
                                <div>
                                    <Button
                                        id="lls-priDestination-click"
                                        size="small"
                                        variant="text-only"
                                        className={clsx('p-0', classes.locationColumnButton)}
                                        onClick={() =>
                                            navigateToLocationDetailsPage(
                                                _rowData.priDestinationId,
                                                _rowData.priDestinationType,
                                            )
                                        }
                                    >
                                        {`${mdmLocationTypes[_rowData.priDestinationType] || ''} - ${
                                            _rowData.priDestinationId
                                        }`}
                                    </Button>
                                    <div className={classes.secondaryText}>
                                        {`${_rowData.priDestinationCity}, ${_rowData.priDestinationProvince}`}
                                    </div>
                                </div>
                            ) : (
                                '--'
                            )}
                        </div>
                    ) : (
                        '--'
                    )}
                </>
            );
        },
    },

    DWELL_DAYS: {
        id: 'DWELL_DAYS',
        size: 84,
        accessorKey: 'dwellDays',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.dwellDays',
        },
    },

    /** @type {ColumnDef} */
    PRIORITY: {
        id: 'PRIORITY',
        size: 80,
        accessorKey: 'priority',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.priority',
        },
    },

    /** @type {ColumnDef} */
    PLANNED_START: {
        id: 'PLANNED_START',
        size: 280,
        accessorKey: 'departureTs',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.drayPlannedStart',
        },
    },

    /** @type {ColumnDef} */
    PLANNED_END: {
        id: 'PLANNED_END',
        size: 280,
        accessorKey: 'endDatePlanned',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.plannedEnd',
        },
    },

    /** @type {ColumnDef} */
    PRIMARY_DESTINATION_PLANNED_END: {
        id: 'PRIMARY_DESTINATION_PLANNED_END',
        size: 280,
        accessorKey: 'primaryDestinationEndDatePlanned',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.primaryDestinationPlannedEnd',
        },
    },

    /** @type {ColumnDef} */
    ACTUAL_START: {
        id: 'ACTUAL_START',
        size: 280,
        accessorKey: 'actualTs',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.drayActualStart',
        },
        cell: ({ row, table }) => {
            const { original: rowData } = row;
            const { classes } = table.options.meta;

            return (
                <>
                    {rowData.actualTs}{' '}
                    {!isEqual(new Date(rowData.plannedStartTime), new Date(rowData.actualStartTime)) && (
                        <div
                            // eslint-disable-next-line max-len
                            className={
                                isAfter(new Date(rowData.plannedStartTime), new Date(rowData.actualStartTime))
                                    ? classes.timeEarly
                                    : classes.timeDelay
                            }
                            data-testid="differenceStartTime-cell"
                        >
                            {calculateTimeDiff(rowData.plannedStartTime, rowData.actualStartTime)?.time}
                        </div>
                    )}
                </>
            );
        },
    },

    /** @type {ColumnDef} */
    ESTIMATED_END: {
        id: 'ESTIMATED_END',
        size: 280,
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.EndDateEstimated',
        },
        cell: () => '---',
    },

    /** @type {ColumnDef} */
    ACTUAL_END: {
        id: 'ACTUAL_END',
        size: 280,
        header: renderHeaderCellContent,
        cell: () => '---',
        meta: {
            label: 'planColumns.actualEndDate',
        },
    },

    /** @type {ColumnDef} */
    DURATION: {
        id: 'DURATION',
        size: 100,
        accessorKey: 'duration',
        header: renderHeaderCellContentWithUOM,
        meta: {
            label: 'planColumns.duration',
            uomKey: 'duration',
        },
    },

    /** @type {ColumnDef} */
    NEXT_STOP: {
        id: 'NEXT_STOP',
        size: 240,
        accessorKey: 'nextStopType',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.nextStop',
        },
        cell: ({ row, table }) => {
            const rowData = row.original;
            const { classes, mdmLocationTypes, navigateToLocationDetailsPage } = table.options.meta;
            return (
                <div className="d-flex align-items-center">
                    {rowData.nextStopType && (
                        <img
                            className={classes.imgOpacity}
                            src={LOCATION_TYPE_ICON_MAP[getLocationTypeToIconMap(rowData.nextStopType)]}
                            alt={`${rowData.nextStopType} icon`}
                        />
                    )}
                    <div className="st-ui-ml-2">
                        {rowData.nextStopType && rowData.nextStopId && (
                            <Button
                                id="lls-destination-click"
                                size="small"
                                variant="text-only"
                                className={clsx('p-0', classes.locationColumnButton)}
                                onClick={() => navigateToLocationDetailsPage(rowData.nextStopId, rowData.nextStopType)}
                                data-testid="next-stop-type_stopId_name"
                            >
                                {`${mdmLocationTypes[rowData.nextStopType] || ''} - ${rowData.nextStopId} - ${
                                    rowData.nextStopName
                                }`}
                            </Button>
                        )}
                        <div className={classes.secondaryText} data-testid="next-stop-city_province">
                            {rowData.nextStopCity && rowData.nextStopProvince
                                ? `${rowData.nextStopCity}, ${rowData.nextStopProvince}`
                                : rowData.nextStopCity || rowData.nextStopProvince}
                        </div>
                    </div>
                </div>
            );
        },
    },

    /** @type {ColumnDef} */
    BILLS_BY_TIME: {
        id: 'BILLS_BY_TIME',
        size: 280,
        accessorKey: 'billsByTime',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.billsByTime',
        },
    },

    /** @type {ColumnDef} */
    PICKUP_STOPS: {
        id: 'PICKUP_STOPS',
        size: 120,
        accessorKey: 'noOfPickupStops',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.pickupStops',
        },
    },

    /** @type {ColumnDef} */
    DELIVERY_STOPS: {
        id: 'DELIVERY_STOPS',
        size: 120,
        accessorKey: 'noOfDropoffStops',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.deliveryStops',
        },
    },

    /** @type {ColumnDef} */
    NUMBER_OF_STOPS_REMAINING: {
        id: 'NUMBER_OF_STOPS_REMAINING',
        size: 200,
        accessorKey: 'numberOfStopsRemaining',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.noOfStopsRemaining',
        },
    },

    /** @type {ColumnDef} */
    MUST_DEPART_TIME: {
        id: 'MUST_DEPART_TIME',
        size: 200,
        accessorKey: 'mustDepartTime',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.mustDepartTime',
        },
    },

    /** @type {ColumnDef} */
    STATUS: {
        id: 'STATUS',
        size: 140,
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.status',
        },
        cell: ({ row, table }) => {
            const { original: _rowData } = row;
            const { trans } = table.options.meta;

            // eslint-disable-next-line react-hooks/rules-of-hooks
            const planStatusProps = useMemo(
                () => ({
                    ..._rowData.statusObj,
                    trans,
                    pickupTimeAtOrigin: _rowData?.pickupTimeAtOrigin,
                }),
                [],
            );

            return <PlanStatus {...planStatusProps} />;
        },
    },

    /** @type {ColumnDef} */
    ROUTE_NUMBER: {
        id: 'ROUTE_NUMBER',
        size: 120,
        accessorKey: 'routeNumber',
        meta: {
            label: 'planColumns.routeNumber',
        },
        header: renderHeaderCellContent,
        cell: ({ row }) => {
            const rowData = row?.original;
            return <>{rowData?.routeNumber}</>;
        },
    },

    /** @type {ColumnDef} */
    ACTIONS: {
        id: 'ACTIONS',
        size: 95,
        accessorKey: 'actions',
        header: renderHeaderCellContent,
        meta: {
            label: 'planColumns.actions',
        },
        cell: ({ row, table }) => {
            const rowData = row.original;
            const { trans, checkedRows, handleActionItemClick, handleActionOpen, handleActionClose } =
                table.options.meta;

            const actions = rowData?.actions?.map((action) => ({
                ...action,
                desc: getActionsDesc(action, [rowData], trans),
            }));

            return (
                <div className="mt-n2">
                    <ActionMenu
                        pActions={actions}
                        pOnClose={() => {
                            handleActionClose(false);
                        }}
                        pOnActionItemClick={handleActionItemClick}
                        pOnActionTriggerClick={() => handleActionOpen(rowData)}
                        pBtnLabel="..."
                        pBtnVariant="text-only"
                        pIsDisable={checkedRows?.length > 0}
                    />
                </div>
            );
        },
    },
};

export default TableColumnsUS;
