export default class TripUiCarrierStatusEnum {
    static ASSIGNED = new TripUiCarrierStatusEnum('Assigned');
    static TENDER_IN_PROGRESS = new TripUiCarrierStatusEnum('Tender in progress');
    static UNASSIGNED = new TripUiCarrierStatusEnum('Unassigned');
    static SELECTED = new TripUiCarrierStatusEnum('Selected');
    static NEEDS_ATTENTION = new TripUiCarrierStatusEnum('Needs attention');
    constructor(name) {
        this.name = name;
        Object.freeze(this);
    }
}
