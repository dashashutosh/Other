import React, { useMemo } from 'react';
import { PermissionFallBack } from '@walmart/stride-ui-commons';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;

export default function PermAccessFallBack() {
    const trans = localizeLang();

    const labels = useMemo(
        () => ({
            authorizationMsg: trans('module.permAccessErrorMsg'),
        }),
        [trans],
    );
    return <PermissionFallBack pLabels={labels} />;
}
