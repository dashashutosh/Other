import React from 'react';
import { render, screen } from '@testing-library/react';
import LoadInfo from '../LoadInfo';
import AssignTripState from './mocks/AssignTripState.mock.json';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import TripSharedService from '../../../service/TripSharedService';

beforeEach(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('LoadInfo Component', () => {
    it('should display load information correctly', () => {
        const sLoadInfo = AssignTripState;
        const wrapper = render(<LoadInfo pLoadInfo={sLoadInfo} />);
        const loadInfoSection = wrapper.getByTestId('loadInfo');
        expect(loadInfoSection).toBeDefined();
        expect(screen.getByTestId('loadPlanIdInfo').textContent).toBe('Load - 50001927');
        expect(screen.getByTestId('loadType').textContent).toBe('BKH');
        expect(screen.getByTestId('origin').textContent).toBe('11159');
        expect(screen.getByTestId('destination').textContent).toBe('7012');
        expect(screen.getByTestId('startTs').textContent).toBe('27 Jul, 2022, 12:00 am');
        expect(screen.getByTestId('equipmentRequirements').textContent).toBe('S30, I, 12');
    });
    describe('reference load type', () => {
        it('should display load type if displayLoadTypeFromReference flag is disabled', () => {
            const loadInfo = { ...AssignTripState, loadType: 'STR', referenceLoadType: 'HUBSTR' };
            const wrapper = render(<LoadInfo pLoadInfo={loadInfo} />);
            const loadInfoSection = wrapper.getByTestId('loadInfo');
            expect(loadInfoSection).toBeDefined();
            expect(screen.getByTestId('loadType').textContent).toBe('STR');
        });
        it('should display reference load type if displayLoadTypeFromReference flag is enabled', () => {
            TripSharedService.setFeatureFlags({ displayLoadTypeFromReference: true });
            const loadInfo = { ...AssignTripState, loadType: 'STR', referenceLoadType: 'HUBSTR' };
            const wrapper = render(<LoadInfo pLoadInfo={loadInfo} />);
            const loadInfoSection = wrapper.getByTestId('loadInfo');
            expect(loadInfoSection).toBeDefined();
            expect(screen.getByTestId('loadType').textContent).toBe('HUBSTR');
        });
    });
});
