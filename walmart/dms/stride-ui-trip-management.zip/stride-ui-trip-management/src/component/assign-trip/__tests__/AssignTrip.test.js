import React from 'react';
import Adapter from '@wojtekmaj/enzyme-adapter-react-17';
import Enzyme, { shallow, mount } from 'enzyme';
import { act } from 'react-dom/test-utils';
import { useAPI } from '@walmart/stride-ui-commons';
import { useLocation } from 'react-router-dom';
import { render, fireEvent, screen } from '../../../utils/test-utils';
import AssignTrip from '../AssignTrip';
import { AppUtils } from '@gscope-mfe/app-bridge';
import {
    contextMock,
    configResponseMock,
    defaultResponse,
    tripStaticDataMock,
} from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import TripSharedService from '../../../service/TripSharedService';
import {
    plansPreviewMock,
    plansPreviewMockForCL,
    requestPayload,
} from '../../trip-management-summary/__tests__/mocks/TripManagementSummary.mock';
import CreateTripConfirmModal from '../../trip-management-summary/CreateTripConfirmModal';
import AssignTripState from './mocks/AssignTripState.mock.json';

Enzyme.configure({ adapter: new Adapter() });

const mockHistoryPush = jest.fn();
const mockBackPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn().mockReturnValue({
        search: undefined,
        state: {},
    }),
    useHistory: () => ({
        push: mockHistoryPush,
        goBack: mockBackPush,
    }),
}));

const spy = jest.spyOn(AppUtils, 'get');

sessionStorage.setItem('ngStorage-permissionData', { permissions: ['cl.stride.tripLoadManagement:EDIT_TRIP'] });

const userPermMock = JSON.stringify({
    // TODO: need to change to order permissions.
    permissions: ['us.stride.location:LocationsSummary_Edit', 'us.stride.location:LocationsSummary_Read'],
    markets: ['ca', 'us', 'cl'],
});

const mock = (fn) => {
    if (fn.name === 'getPlanPreview') {
        return plansPreviewMock;
    }
    if (fn.name === 'getLTPlanPreview') {
        return plansPreviewMockForCL;
    }
    return defaultResponse;
};
jest.mock('@walmart/stride-ui-commons', () => ({
    ...jest.requireActual('@walmart/stride-ui-commons'),
    useAPI: jest.fn(),
}));
useAPI.mockImplementation((fn) => mock(fn));

describe('Assign trip', () => {
    let headerConfig;
    beforeAll(() => {
        contextMock.setHeaderConfig.mockImplementation((data) => {
            headerConfig = data;
        });
        const localStorageGetItem = jest.fn((arg) => {
            if (arg === 'ngStorage-permissionData') {
                return userPermMock;
            }
        });
        Object.defineProperty(global, 'localStorage', {
            value: {
                getItem: localStorageGetItem,
                setItem: () => {},
            },
            writable: true,
        });
        spy.mockImplementation(() => contextMock);
        TripSharedService.setConfig(configResponseMock);
        TripSharedService.setTripStaticData(tripStaticDataMock);
    });

    it('should render without crashing', () => {
        const wrapper = render(<AssignTrip />);
        expect(wrapper).toBeDefined();
    });

    it('should redirect user to previous screen on click of Cancel button', () => {
        const wrapper = render(<AssignTrip />);
        const cancelButton = wrapper.getByTestId('cancelBtn');
        fireEvent.click(cancelButton);
        expect(mockBackPush).toHaveBeenCalled();
    });

    it('assign to trip button should be disabled initially', () => {
        const wrapper = render(<AssignTrip />);
        const assignToTripBtn = wrapper.getByTestId('assignToTrip');
        expect(assignToTripBtn.disabled).toBeTruthy();
    });

    it('should show page load setting after initial rendering', () => {
        contextMock.currentMarket = 'gt';
        spy.mockImplementation(() => contextMock);
        render(<AssignTrip />);
        expect(TripSharedService.getPageLoadSettings()).toBeDefined();
    });

    it('should show page load setting after initial rendering', () => {
        contextMock.currentMarket = 'cr';
        spy.mockImplementation(() => contextMock);
        render(<AssignTrip />);
        expect(TripSharedService.getPageLoadSettings()).toBeDefined();
    });

    it('should show page load setting after initial rendering', () => {
        contextMock.currentMarket = 'sv';
        spy.mockImplementation(() => contextMock);
        render(<AssignTrip />);
        expect(TripSharedService.getPageLoadSettings()).toBeDefined();
    });

    it('should show page load setting after initial rendering', () => {
        contextMock.currentMarket = 'mx_mkp';
        spy.mockImplementation(() => contextMock);
        render(<AssignTrip />);
        expect(TripSharedService.getPageLoadSettings()).toBeDefined();
    });

    it('should display load information correctly', () => {
        const sLoadInfo = AssignTripState;
        useLocation.mockReturnValue({
            state: {
                ...sLoadInfo,
            },
        });
        const wrapper = render(<AssignTrip />);
        const loadInfoSection = wrapper.getByTestId('loadInfo');
        expect(loadInfoSection).toBeDefined();
        expect(screen.getByTestId('loadPlanIdInfo').textContent).toBe('Load - 50001927');
        expect(screen.getByTestId('loadType').textContent).toBe('BKH');
        expect(screen.getByTestId('origin').textContent).toBe('11159');
        expect(screen.getByTestId('destination').textContent).toBe('7012');
        expect(screen.getByTestId('startTs').textContent).toBe('27 Jul, 2022, 12:00 am');
        expect(screen.getByTestId('equipmentRequirements').textContent).toBe('S30, I, 12');
    });

    it.skip('should open confirm trip assignment modal on assign trip click', () => {
        const wrapper = mount(<AssignTrip />);
        const Header = () => <>{headerConfig.children}</>;
        const headerWrapper = shallow(<Header />);
        expect(headerWrapper.find('[data-testid="assignToTrip"]')).toHaveLength(1);
        act(() => {
            headerWrapper.find('[data-testid="assignToTrip"]').simulate('click');
        });
        wrapper.update();
        expect(wrapper.find(CreateTripConfirmModal).prop('pIsOpen')).toEqual(true);
    });

    it.skip('should close confirm trip assignment modal on pOnClose', () => {
        const wrapper = mount(<AssignTrip />);
        const Header = () => <>{headerConfig.children}</>;
        const headerWrapper = shallow(<Header />);
        expect(headerWrapper.find('[data-testid="assignToTrip"]')).toHaveLength(1);
        act(() => {
            headerWrapper.find('[data-testid="assignToTrip"]').simulate('click');
        });
        wrapper.update();
        expect(wrapper.find(CreateTripConfirmModal).prop('pIsOpen')).toEqual(true);
        act(() => {
            wrapper.find(CreateTripConfirmModal).prop('pOnClose')();
        });
        wrapper.update();
        expect(wrapper.find(CreateTripConfirmModal)).toHaveLength(0);
    });

    describe('Assign trip - trip details', () => {
        const config = {
            ...configResponseMock,
            payload: {
                ...configResponseMock.payload,
                custom: {
                    ...configResponseMock.payload.custom,
                    rowsPerPage: '3',
                },
            },
        };
        const requestPayloadForPage2 = {
            ...requestPayload,
            payload: {
                ...requestPayload.payload,
                page: 2,
            },
        };
        beforeEach(() => {
            const context = {
                ...contextMock,
                currentMarket: 'cl',
            };
            spy.mockImplementation(() => context);
            TripSharedService.setConfig(config);
        });

        // TODO: Fix this test after MFE migration
        it.skip('should not call PlanLTPreview API when showPaginationInAssignTrip is set to false ', async () => {
            TripSharedService.setFeatureFlags({ showPaginationInAssignTrip: false });
            const wrapper = render(<AssignTrip />);
            expect(wrapper).toBeDefined();
            const nextButton = await wrapper.findByTestId('ld-sc-ui-table-next-page');
            expect(nextButton).toBeDefined();
            fireEvent.click(nextButton);
            expect(plansPreviewMockForCL.callAPI).toHaveBeenCalledWith(requestPayload, expect.any(Function));
            fireEvent.click(nextButton);
            expect(plansPreviewMockForCL.callAPI).not.toHaveBeenCalledWith(
                requestPayloadForPage2,
                expect.any(Function),
            );
        });

        it('should call PlanLTPreview API when showPaginationInAssignTrip is set to true ', async () => {
            TripSharedService.setFeatureFlags({ showPaginationInAssignTrip: true });
            const wrapper = render(<AssignTrip />);
            expect(wrapper).toBeDefined();
            const nextButton = await wrapper.findByTestId('ld-sc-ui-table-next-page');
            expect(nextButton).toBeDefined();
            fireEvent.click(nextButton);
            expect(plansPreviewMockForCL.callAPI).toHaveBeenCalledWith(requestPayloadForPage2, expect.any(Function));
            fireEvent.click(nextButton);
        });
    });
    describe('double load assign tests', () => {
        const config = {
            ...configResponseMock,
            payload: {
                ...configResponseMock.payload,
                custom: {
                    ...configResponseMock.payload.custom,
                    rowsPerPage: '10',
                },
            },
        };
        beforeEach(() => {
            const context = {
                ...contextMock,
                currentMarket: 'mx',
            };
            spy.mockImplementation(() => context);
            TripSharedService.setConfig(config);
            TripSharedService.setFeatureFlags({
                showPaginationInAssignTrip: true,
                showAssignTripForDoubleTrailer: true,
            });
            useLocation.mockReturnValue({
                state: {
                    filteredPlans: [AssignTripState, { ...AssignTripState, planId: '50029832' }],
                    isDoubleAssign: true,
                },
            });
        });
        it('should display two load information if it is double assignment', () => {
            const wrapper = render(<AssignTrip />);
            const loadInfoSection = wrapper.getAllByTestId('loadInfo');
            expect(loadInfoSection.length).toEqual(2);
            expect(screen.getByText('Load - 50001927')).toBeDefined();
            expect(screen.getByText('Load - 50029832')).toBeDefined();
        });
        it('should display one load information if it is not double assignment', () => {
            TripSharedService.setFeatureFlags({
                showPaginationInAssignTrip: true,
                showAssignTripForDoubleTrailer: false,
            });
            useLocation.mockReturnValue({
                state: {
                    ...AssignTripState,
                },
            });
            const wrapper = render(<AssignTrip />);
            const loadInfoSection = wrapper.getAllByTestId('loadInfo');
            expect(loadInfoSection.length).toEqual(1);
            expect(screen.getByText('Load - 50001927')).toBeDefined();
        });
    });

    describe('MX HUBSTR DECSTR assign tests', () => {
        const config = {
            ...configResponseMock,
            payload: {
                ...configResponseMock.payload,
                custom: {
                    ...configResponseMock.payload.custom,
                    rowsPerPage: '10',
                },
            },
        };
        beforeEach(() => {
            const context = {
                ...contextMock,
                currentMarket: 'mx',
            };
            spy.mockImplementation(() => context);
            TripSharedService.setConfig(config);
            useLocation.mockReturnValue({
                state: {
                    ...AssignTripState,
                    sIsHubstrOrDecstrReturnLoadSuccess: true,
                },
            });
        });
        it('should assign return load to HUBSTR DECSTR Tirp', () => {
            TripSharedService.setFeatureFlags({
                displayDCChargeLoc: true,
            });
            const wrapper = render(<AssignTrip />);
            const loadInfoSection = wrapper.getAllByTestId('loadInfo');
            expect(loadInfoSection.length).toEqual(1);
            expect(screen.getByText('Load - 50001927')).toBeDefined();
        });
    });
});
