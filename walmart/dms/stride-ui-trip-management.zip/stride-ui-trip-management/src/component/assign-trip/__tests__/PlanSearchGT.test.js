import React from 'react';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { render, fireEvent, screen } from '../../../utils/test-utils';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import PlanSearchGT from '../PlanSearchGT';

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});
const sSearchFormValue = { planId: '' };

describe('PlanSearch GT', () => {
    it('should render without crashing', () => {
        const wrapper = render(
            <PlanSearchGT
                pIsOpen
                pOnClose={() => {}}
                pOnFilter={() => {}}
                pSearchFormValue={sSearchFormValue}
                pSetSSearchFormValue={() => {}}
            />,
        );

        expect(wrapper).toBeDefined();
        expect(wrapper.getByTestId('planId')).toBeDefined();
    });
    it('should close the modal on close button click', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchGT
                pIsOpen
                pOnClose={mockFn}
                pOnFilter={() => {}}
                pSearchFormValue={sSearchFormValue}
                pSetSSearchFormValue={() => {}}
            />,
        );

        const closeBtn = wrapper.queryByTestId('ld-sc-ui-button-modal-close');
        expect(closeBtn).toBeDefined();
        fireEvent.click(closeBtn);
        expect(mockFn).toBeCalled();
    });

    // TODO: Fix this test after MFE migration
    it.skip('should close the modal on apply filter button click', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchGT
                pIsOpen
                pOnClose={mockFn}
                pOnFilter={() => {}}
                pSearchFormValue={sSearchFormValue}
                pSetSSearchFormValue={() => {}}
            />,
        );

        const originId = wrapper.queryByTestId('planId');
        fireEvent.change(originId, { target: { value: '123456' } });
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
        expect(mockFn).toBeCalled();
    });

    // TODO: Fix this test after MFE migration
    it.skip('should invoke pOnFilter function on click of apply filter ', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchGT
                pIsOpen
                pOnClose={() => {}}
                pOnFilter={mockFn}
                pSearchFormValue={sSearchFormValue}
                pSetSSearchFormValue={() => {}}
            />,
        );

        const originId = wrapper.queryByTestId('planId');
        fireEvent.change(originId, { target: { value: '123456' } });

        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
        expect(mockFn).toBeCalled();
    });

    it('should disable the apply filter button when form is empty ', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchGT
                pIsOpen
                pOnClose={() => {}}
                pOnFilter={mockFn}
                pSearchFormValue={sSearchFormValue}
                pSetSSearchFormValue={() => {}}
            />,
        );
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn.disabled).toBeTruthy();
    });

    it('should disable the apply filter when form values are invalid', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchGT
                pIsOpen
                pOnClose={() => {}}
                pOnFilter={mockFn}
                pSearchFormValue={sSearchFormValue}
                pSetSSearchFormValue={() => {}}
            />,
        );
        const planId = wrapper.queryByTestId('planId');
        fireEvent.change(planId, { target: { value: 'safdsf' } });
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn.disabled).toBeTruthy();
    });

    // TODO: Fix this test after MFE migration
    it.skip('should retain previous search values user flow', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchGT
                pIsOpen
                pOnClose={() => {}}
                pOnFilter={mockFn}
                pSearchFormValue={sSearchFormValue}
                pSetSSearchFormValue={() => {}}
            />,
        );
        const planId = wrapper.queryByTestId('planId');
        fireEvent.change(planId, { target: { value: '123456' } });
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        fireEvent.click(confirmBtn);
        expect(planId.value).toBe('123456');
        const clearButton = wrapper.queryByTestId('clearAllFilters');
        fireEvent.click(clearButton);
        // const planId1 = screen.getByTestId('planId');
        expect(planId.value).toBe('');
    });
});
