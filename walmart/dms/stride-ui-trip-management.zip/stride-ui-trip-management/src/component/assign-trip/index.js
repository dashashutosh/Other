import AssignTrip from './AssignTrip';
export default AssignTrip;
