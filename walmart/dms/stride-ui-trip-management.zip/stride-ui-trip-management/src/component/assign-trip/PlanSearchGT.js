import React, { useState, useEffect } from 'react';
import {
    Typography,
    TextInput,
    Button,
    RemoveIcon,
    ModalFooter,
    ModalHeader,
    DrawerComponent,
} from '@walmart/living-design-sc-ui';
import PropTypes from 'prop-types';
import { plankeyRegex } from '../../Constants';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { Grid } = MaterialUiCore,
    { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const styles = makeStyles({
    drawer: {
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        maxWidth: '75vw',
    },
    selectFieldWidth: {
        minWidth: '100% !important',
    },
    searchBtn: {
        width: '10rem',
        justifyContent: 'center',
    },
    searchWrapper: {
        '& .ld-sc-ui-scope': {
            padding: 0,
        },
        '& .ld-sc-ui-scope .ld-sc-ui-select .ld-sc-ui-select-label': {
            padding: 0,
        },
    },
});

/**
 *
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
const PlanSearchGT = (props) => {
    const { pIsOpen, pOnClose, pOnFilter, pSearchFormValue, pSetSSearchFormValue } = props;
    const trans = localizeLang();
    const classes = styles();
    const [sFilterCount, setsFilterCount] = useState(0);
    const [sFormValue, setSFormValue] = useState(pSearchFormValue);
    const [sIsFormValid, setsIsFormValid] = useState(true);
    const onValueChange = (field, value) => {
        setSFormValue((formValue) => ({
            ...formValue,
            [field]: value,
        }));
    };
    const isSearchDisabled = () => !sIsFormValid || !sFilterCount;
    const validateForm = () => {
        let formValid = true;
        if (sFormValue && sFormValue.planId && !sFormValue.planId.match(plankeyRegex)) {
            formValid = false;
        }
        setsIsFormValid(formValid);
    };
    const onSearch = () => {
        pSetSSearchFormValue(sFormValue);
        pOnFilter(sFormValue);
        pOnClose();
    };
    useEffect(() => {
        let appliedFilters = 0;
        Object.entries(sFormValue).forEach(([key, value]) => {
            if (key !== 'dateType') {
                if (Array.isArray(value)) {
                    if (value.length) {
                        appliedFilters += 1;
                    }
                } else if (value) {
                    appliedFilters += 1;
                }
            }
        });
        if (sFilterCount !== appliedFilters) {
            setsFilterCount(appliedFilters);
        }
        validateForm();
    }, [sFormValue]);
    const handleClose = () => pOnClose(false);
    const onClearFilter = () => {
        setSFormValue({
            planId: '',
        });
        pSetSSearchFormValue({
            planId: '',
        });
    };
    return (
        <>
            <DrawerComponent open={pIsOpen} position="right" className={classes.drawer} handleClose={handleClose}>
                <ModalHeader onClose={handleClose}>{trans('title.filter')}</ModalHeader>
                <div className="overflow-auto st-ui-px-4 st-ui-py-6">
                    <Grid container spacing={4} className={classes.searchWrapper}>
                        <Grid item xs={2}>
                            <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                {trans('subTitle.plan')}
                            </Typography>
                        </Grid>
                        <Grid container item spacing={4}>
                            <Grid item xs={9}>
                                <TextInput
                                    id="planId"
                                    key="planId"
                                    label={trans('label.planId')}
                                    className="w-100"
                                    value={sFormValue.planId}
                                    onChange={(e) => onValueChange('planId', e.target.value)}
                                    endIcon={sFormValue.planId && <RemoveIcon size="small" />}
                                    endIconClick={() => onValueChange('planId', '')}
                                    helperText={
                                        sFormValue.planId.match(plankeyRegex) ? trans('multiInputHelperText') : ''
                                    }
                                    variant={sFormValue.planId.match(plankeyRegex) ? 'default' : 'error'}
                                    errorText={sFormValue.planId.match(plankeyRegex) ? '' : trans('loadIdError')}
                                    data-testid="planId"
                                />
                            </Grid>
                        </Grid>
                    </Grid>
                </div>
                <ModalFooter>
                    <Button
                        onClick={() => {
                            onClearFilter();
                        }}
                        variant="text-only"
                        data-testid="clearAllFilters"
                    >
                        {trans('button.clearAllFilters')}
                    </Button>
                    <Button
                        onClick={() => {
                            onSearch();
                        }}
                        variant="primary"
                        disabled={isSearchDisabled()}
                        data-testid="confirmBtn"
                    >
                        {trans('button.applyFilter')}
                    </Button>
                </ModalFooter>
            </DrawerComponent>
        </>
    );
};
const propTypes = {
    pIsOpen: PropTypes.bool.isRequired,
    pOnClose: PropTypes.func.isRequired,
    pOnFilter: PropTypes.func.isRequired,
    pSearchFormValue: PropTypes.shape({
        planId: PropTypes.string.isRequired,
    }).isRequired,
    pSetSSearchFormValue: PropTypes.func.isRequired,
};
PlanSearchGT.propTypes = propTypes;
export default PlanSearchGT;
