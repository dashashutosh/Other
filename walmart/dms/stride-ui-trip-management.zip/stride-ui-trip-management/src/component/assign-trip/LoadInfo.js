import React from 'react';
import PropTypes from 'prop-types';
import { Typography, Divider, Card, CardContent, DataLabel } from '@walmart/living-design-sc-ui';
import { colors } from '../../Constants';
import enData from '../../lang/en.json';
import esData from '../../lang/es.json';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import TripSharedService from '../../service/TripSharedService';
const { Grid, makeStyles } = MaterialUiCore,
    { loadI18n } = LocalizeLang.default;
const useStyles = makeStyles(() => ({
    stLoadCard: {
        '& .ld-sc-ui-data-key-large': {
            color: colors.labelGrey,
        },
        '& .ld-sc-ui-data-wrapper': {
            textAlign: 'left',
            width: '100%',
        },
        '& .ld-sc-ui-segment-group-label': {
            textAlign: 'left',
        },
    },
}));
function LoadInfo(props) {
    const classes = useStyles();
    const trans = loadI18n([
        ['en', enData],
        ['es', esData],
    ]);
    const { pLoadInfo } = props;
    const featureFlags = TripSharedService.getFeatureFlags();
    return (
        <Card elevation="3" className={`${classes.stLoadCard} m-3`} data-testid="loadInfo">
            <div className="d-flex justify-content-between align-items-baseline">
                <Typography variant="h6" align="left" className="font-weight-bold p-3" data-testid="loadPlanIdInfo">
                    {`${trans('label.load')} - ${pLoadInfo?.planId}`}
                </Typography>
            </div>
            <Divider />
            <CardContent className="my-0 mx-0 p-3 w-100">
                <Grid container spacing={3}>
                    <Grid item xs={2}>
                        <DataLabel
                            keyName={trans('label.loadType')}
                            value={
                                featureFlags?.displayLoadTypeFromReference
                                    ? pLoadInfo?.referenceLoadType
                                    : pLoadInfo?.loadType
                            }
                            size="large"
                            data-testid="loadType"
                        />
                    </Grid>
                    <Grid item xs={2}>
                        <DataLabel
                            keyName={trans('planColumns.origin')}
                            value={pLoadInfo?.originId}
                            size="large"
                            data-testid="origin"
                        />
                    </Grid>
                    <Grid item xs={2}>
                        <DataLabel
                            keyName={trans('planColumns.destination')}
                            value={pLoadInfo?.destinationId}
                            size="large"
                            data-testid="destination"
                        />
                    </Grid>
                    <Grid item xs={3}>
                        <DataLabel
                            keyName={trans('planColumns.departureDateTime')}
                            value={pLoadInfo?.departureTs}
                            size="large"
                            data-testid="startTs"
                        />
                    </Grid>
                    <Grid item xs={3}>
                        <DataLabel
                            keyName={trans('label.equipmentRequirements')}
                            value={`${pLoadInfo?.equipmentCode}, ${pLoadInfo?.protectionLevel}, ${pLoadInfo?.equipmentLength}`}
                            size="large"
                            data-testid="equipmentRequirements"
                        />
                    </Grid>
                </Grid>
            </CardContent>
        </Card>
    );
}
const propTypes = {
    pLoadInfo: PropTypes.shape({
        planId: PropTypes.string.isRequired,
        loadType: PropTypes.string.isRequired,
        referenceLoadType: PropTypes.string.isRequired,
        originId: PropTypes.string.isRequired,
        destinationId: PropTypes.string.isRequired,
        departureTs: PropTypes.string.isRequired,
        equipmentCode: PropTypes.string.isRequired,
        protectionLevel: PropTypes.string.isRequired,
        equipmentLength: PropTypes.string.isRequired,
    }).isRequired,
};
LoadInfo.propTypes = propTypes;
export default LoadInfo;
