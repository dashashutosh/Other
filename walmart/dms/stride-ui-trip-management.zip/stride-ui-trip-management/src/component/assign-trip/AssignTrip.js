import React, { useEffect, useMemo, useState } from 'react';
import { Button, Alert, Toast } from '@walmart/living-design-sc-ui';
import {
    useAPI,
    transformPreviewResponseToUIModel,
    isNullOrUndefined,
    PageHeader,
    getFeatureFlagsConfig,
    MarketCodeEnum,
    ErrorBoundary,
} from '@walmart/stride-ui-commons';
import { useLocation, useHistory } from 'react-router-dom';
import enData from '../../lang/en.json';
import esData from '../../lang/es.json';
import { connectLoads, toastTimer, getPageStaticDataRequest, TRIP_MODE } from '../../Constants';
import PhaseTypesEnum from '../../utils/enums/PhaseTypesEnum';
import PlanTable from '../trip-management-summary/PlanTable';
import CreateTripConfirmModal from '../trip-management-summary/CreateTripConfirmModal';
import { TripAPI, PageLoadAPI } from '../../service/TripAPI';
import TripSharedService from '../../service/TripSharedService';
import {
    transformPlanPreviewData,
    searchLTReqPayloadForAvailableTrips,
    formatAssignTripReq,
    getSelectedTripInfo,
    getEquipmentAndTransitDetailsOfTrip,
    searchPayloadForFilterGT,
} from '../trip-management-summary/DataModels';
import { transformCmsData, transformStaticData } from '../../service/TripMapper';
import { formatTripErrors, isHubstrOrDecstrTripLoad } from '../../utils/CommonUtils';
import { stTripToast } from '../../utils/StyleUtils';
import LoadUIStatusEnum from '../model/loadUiStatusEnum';
import { canEditTrip } from '../../utils/PermissionsUtils';
import { getMarketSettings, defaultMarketSettings } from '../../utils/MarketSettings';
import PlanSearchGT from './PlanSearchGT';
import LoadInfo from './LoadInfo';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import {
    LocalizeLang,
    MarketSelector as _MarketSelector,
    LanguageSelector as _LanguageSelector,
} from '@gscope-mfe/common-components';
import { AppUtils } from '@gscope-mfe/app-bridge';
const { makeStyles } = MaterialUiCore,
    { loadI18n, localizeCommonLang } = LocalizeLang.default,
    MarketSelector = _MarketSelector.default,
    LanguageSelector = _LanguageSelector.default;
const useStyles = makeStyles(() => ({
    stTripToast,
}));
const DEFAULT_INITIATOR_PATH = '/mfe/stride/tripmanagement';
let selectedTripId = null;
let tripConfirmModalData = null;
export function AssignTrip() {
    const classes = useStyles();
    const commonTrans = localizeCommonLang();
    const { state } = useLocation();
    const history = useHistory();
    const trans = loadI18n([
        ['en', enData],
        ['es', esData],
    ]);
    const {
        // eslint-disable-next-line no-unused-vars
        setBreadCrumbArr,
        prefLang,
        currentMarket,
        userInfo,
        loading,
        setloading,
    } = AppUtils.get();
    const [sEnableSave, setsEnableSave] = useState(false);
    const [sLoadInfo, setsLoadInfo] = useState({});
    const [sIsAssignTripModalOpen, setsIsAssignTripModalOpen] = useState(false);
    const [sTripList, setsTripList] = useState([]);
    const [sCmsConfig, setsCmsConfig] = useState();
    const [sIsDataInvalid, setsIsDataInvalid] = useState(false);
    const [sShowErrors, setsShowErrors] = useState(false);
    const [sIsLocationDiff, setsIsLocationDiff] = useState(false);
    const [sIsAssignSuccess, setsIsAssignSuccess] = useState(false);
    const [sPerm, setsPerm] = useState({});
    const [sPageNumber, setSPageNumber] = useState(1);
    const [pFetchedTripCount, setPFetchedTripCount] = useState(null);
    const [sIsSearchFilterModalOpen, setsIsSearchFilterModalOpen] = useState(false);
    const [sSearchFormValue, setSSearchFormValue] = useState({
        planId: '',
    });
    const [sIsDoubleAssign, setsIsDoubleAssign] = useState(false);
    const [sIsHubstrOrDecstrReturnLoadSuccess, setsIsHubstrOrDecstrReturnLoadSuccess] = useState(false);
    const featureFlags = TripSharedService.getFeatureFlags();
    const pageLoadSetting = TripSharedService.getPageLoadSettings();
    const tripAPI = TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName);
    const { callAPI: assignTrip, ...assignTripResponse } = useAPI(tripAPI.assignTrip);
    const { callAPI: fetchLTPlans, ...planLTResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getLTPlanPreview,
    );
    const { callAPI: fetchPageLoadData, ...pageLoadDataResponse } = useAPI(
        PageLoadAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getPageLoadData,
    );
    const { initiatorPath, loadInfoFromLocationState } = useMemo(() => {
        const { initiatorPath: initiatorPathValue, tripConfig, tripStaticData, ...rest } = state || {};
        if (tripConfig) TripSharedService.setConfig(tripConfig);
        if (tripStaticData) TripSharedService.setTripStaticData(tripStaticData);
        return {
            initiatorPath: initiatorPathValue,
            loadInfoFromLocationState: rest,
        };
    }, [state]);
    const getPageLoadData = () => {
        fetchPageLoadData(getPageStaticDataRequest(currentMarket));
    };
    const setFeatureFlagData = (flags) => {
        const parseFeatureFlags = JSON.parse(flags);
        const tripFeatureFlags = getFeatureFlagsConfig(
            {
                hostname: window.location.hostname,
            },
            {
                cmsConfig: {
                    featureFlags: parseFeatureFlags,
                },
                marketConfig: getMarketSettings(currentMarket),
                defaultConfig: defaultMarketSettings,
            },
        );
        TripSharedService.setFeatureFlags(tripFeatureFlags);
    };
    const setConfigData = (configData) => {
        try {
            const { rowsPerPage, debounceTime, country, UOM, defaultOlsenTimezoneId } = transformCmsData(configData);
            setsCmsConfig({
                rowsPerPage,
                debounceTime,
                country,
                UOM,
                defaultOlsenTimezoneId,
            });
        } catch (e) {
            setsIsDataInvalid(true);
        }
    };
    const isDoubleTrailerModeFiltered = (trip) => {
        if (featureFlags?.showAssignTripForDoubleTrailer) {
            const tripMode = trip?.transitDetailMode || trip?.mode;
            if (loadInfoFromLocationState?.isDoubleAssign) {
                return trans('mode.Double') === tripMode || tripMode === TRIP_MODE.DBL;
            }
            return trans('mode.Double') !== tripMode && tripMode !== TRIP_MODE.DBL;
        }
        return true;
    };

    useEffect(() => {
        try {
            if (pageLoadDataResponse.response && pageLoadDataResponse.response.length === 2) {
                setFeatureFlagData(pageLoadDataResponse?.response[0]?.payload?.custom?.featureFlags);
                TripSharedService.setConfig(pageLoadDataResponse?.response[0]);
                setConfigData(pageLoadDataResponse?.response[0]);
                TripSharedService.setTripStaticData(
                    transformStaticData(pageLoadDataResponse?.response[1], currentMarket),
                );
            }
        } catch (e) {
            setsIsDataInvalid(true);
        }
    }, [pageLoadDataResponse.response]);
    useEffect(() => {
        if (isNullOrUndefined(pageLoadSetting)) {
            const marketSettings = getMarketSettings(currentMarket);
            TripSharedService.setPageLoadSettings(marketSettings);
        }
    }, [currentMarket]);
    const goToInitiatorPage = () => {
        history.push(initiatorPath || DEFAULT_INITIATOR_PATH);
    };
    const goToInitiatorPageHubDec = () => {
        if (initiatorPath) {
            initiatorPath.state = {
                sIsHubstrOrDecstrReturnLoadSuccess: sIsHubstrOrDecstrReturnLoadSuccess || false,
            };
        }
        history.push(initiatorPath || DEFAULT_INITIATOR_PATH);
    };
    const fetchLTPlansWithPayload = (payload, type) => {
        fetchLTPlans(payload, (newCoreRes) => {
            const coreRes = {
                ...newCoreRes,
                payload: newCoreRes?.payload?.map((plan) => plan?.planResponse),
            };
            const { carrierList, dispatchList } = newCoreRes?.payload?.reduce(
                (groupedData, data) => {
                    if (data.cstResponse) {
                        groupedData.carrierList.push({
                            ...data.cstResponse,
                            planStatus: data?.planResponse?.planStatus,
                        });
                    }
                    if (data.dispatchResponse) {
                        groupedData.dispatchList.push({
                            ...data.dispatchResponse,
                            planStatus: data?.planResponse?.planStatus,
                        });
                    }
                    return groupedData;
                },
                {
                    carrierList: [],
                    dispatchList: [],
                },
            );
            setPFetchedTripCount(coreRes?.payload?.length);
            const combinedResponse = {
                tripManagementSearch: coreRes,
            };
            const optionFlags = {
                showCreateTripForDoubleTrailer: featureFlags?.showCreateTripForDoubleTrailer,
            };
            const tData = transformPreviewResponseToUIModel(
                combinedResponse?.tripManagementSearch.payload,
                carrierList,
                dispatchList,
                [],
                optionFlags,
            );
            const pStaticData = TripSharedService.getTripStaticData();
            const configData = {
                market: currentMarket,
                staticData: pStaticData,
                featureFlags,
                config: sCmsConfig,
            };
            const transformedList = tData.map((plan) => transformPlanPreviewData(plan, trans, configData));
            const filteredList = transformedList.filter(
                (trip) =>
                    trip.planType !== 'LOAD' &&
                    trip.planWorkflowStatusObj?.name !== LoadUIStatusEnum.DELIVERED.name &&
                    trip.planWorkflowStatusObj?.name !== LoadUIStatusEnum.CANCELLED.name &&
                    trip.planWorkflowStatusObj?.name !== LoadUIStatusEnum.COMPLETED.name &&
                    isDoubleTrailerModeFiltered(trip),
            );
            if (
                (currentMarket === MarketCodeEnum.GUATEMALA.name.toLowerCase() ||
                    currentMarket === MarketCodeEnum.MEXICO.name.toLowerCase() ||
                    currentMarket === MarketCodeEnum.MEXICO_MARKET_PLACE.name.toLowerCase() ||
                    currentMarket === MarketCodeEnum.COSTA_RICA.name.toLowerCase() ||
                    currentMarket === MarketCodeEnum.EL_SALVADOR.name.toLowerCase() ||
                    featureFlags?.showPaginationInAssignTrip) &&
                type !== 'fromSearch'
            ) {
                setsTripList([...sTripList, ...filteredList]);
            } else {
                setsTripList(filteredList);
            }
        });
    };
    const getTrips = (assignTripPages) => {
        fetchLTPlansWithPayload(searchLTReqPayloadForAvailableTrips(assignTripPages || sPageNumber));
    };
    const handlePageChange = (page) => {
        setSPageNumber(page);
        getTrips(page);
    };
    useEffect(() => {
        getTrips();
    }, [sCmsConfig]);
    const onSaveSuccess = () => {
        setsIsAssignSuccess(true);
    };
    const onAssignTrip = (data) => {
        const TransitAndEquipmentDetail = featureFlags?.includeTransitEquipmentInLoad
            ? getEquipmentAndTransitDetailsOfTrip(selectedTripId, planLTResponse?.response?.payload)
            : null;
        const tripData = getSelectedTripInfo(selectedTripId, sTripList);
        const configItems = {
            cmsConfig: sCmsConfig,
            currentMarket,
            featureFlags,
        };
        const tripAndLoadInfo = {
            tripData,
            sLoadInfo,
            selectedTripId,
        };
        const connectionLoadInfo = {
            formData: data,
            TransitAndEquipmentDetail,
        };
        const assignTripReq = formatAssignTripReq(tripAndLoadInfo, configItems, connectionLoadInfo, sIsDoubleAssign);
        assignTrip(assignTripReq, onSaveSuccess);
    };
    useEffect(() => {
        if (sIsAssignTripModalOpen) {
            const tripData = getSelectedTripInfo(selectedTripId, sTripList);
            const finalDestLocId = tripData?.destinationId;
            const loadOrgin =
                sIsDoubleAssign && featureFlags?.showAssignTripForDoubleTrailer
                    ? sLoadInfo?.filteredPlans?.[0]?.originId
                    : sLoadInfo?.originId;
            if (finalDestLocId?.toString() === loadOrgin?.toString()) {
                setsIsLocationDiff(false);
                const configItems = {
                    cmsConfig: sCmsConfig,
                    currentMarket,
                    featureFlags,
                };
                const tripAndLoadInfo = {
                    tripData,
                    sLoadInfo,
                    selectedTripId,
                };
                const connectionLoadInfo = {
                    formData: null,
                    TransitAndEquipmentDetail: null,
                };
                const req = formatAssignTripReq(tripAndLoadInfo, configItems, connectionLoadInfo, sIsDoubleAssign);
                if (featureFlags?.displayDCChargeLoc) {
                    setsIsHubstrOrDecstrReturnLoadSuccess(isHubstrOrDecstrTripLoad(tripAndLoadInfo));
                }
                assignTrip(req, onSaveSuccess);
            } else {
                setsIsLocationDiff(true);
            }
        }
    }, [sIsAssignTripModalOpen]);
    const onAssignTripModalClose = () => {
        setsIsAssignTripModalOpen(false);
        setsShowErrors(false);
    };
    const validateRequest = (data) => {
        if (!data.connectLoad || !data.distance || !data.transitTime) {
            return true;
        }
        return false;
    };
    const onAssignTripSubmit = (isAssign, data) => {
        tripConfirmModalData = data;
        if (isAssign) {
            const isNotValidForm = validateRequest(data);
            setsShowErrors(isNotValidForm);
            if (!isNotValidForm) {
                onAssignTrip(data);
                setsIsAssignTripModalOpen(false);
                setsShowErrors(false);
            }
        }
    };
    const onTripSelection = (tripId) => {
        if (tripId) {
            setsEnableSave(true);
            selectedTripId = tripId;
        } else setsEnableSave(false);
    };
    const getErrorText = (data) => {
        const error = formatTripErrors(data);
        return error?.key ? trans(error?.key) : error;
    };
    const onCancel = () => {
        history.goBack();
    };
    const getHeaderChildren = () => (
        <>
            <Button variant="text-only" data-testid="cancelBtn" onClick={onCancel}>
                {trans('button.cancel')}
            </Button>
            <Button
                variant="primary"
                data-testid="assignToTrip"
                onClick={() => {
                    setsIsAssignTripModalOpen(true);
                }}
                disabled={!sEnableSave}
            >
                {trans('button.assignToTrip')}
            </Button>
        </>
    );
    const setPageLoadData = () => {
        setConfigData(TripSharedService.getConfig());
    };
    useEffect(() => {
        setBreadCrumbArr([]);
        if (prefLang.current) {
            if (isNullOrUndefined(TripSharedService.getUserPermissions())) {
                const userPerm = JSON.parse(localStorage.getItem('ngStorage-permissionData'));
                TripSharedService.setUserPermissions(userPerm?.permissions);
            }
            setsPerm({
                canEditTrip: canEditTrip(TripSharedService.getUserPermissions(), currentMarket),
            });
            getPageLoadData();
            const lang = TripSharedService.getCurrentLanguage();
            if (lang && lang !== prefLang.current) {
                // TODO: fix me after gscope open issue resolves
                // https://gecgithub01.walmart.com/gscope-platform/aura-fe/issues/325
                setTimeout(() => {
                    goToInitiatorPage();
                }, 1000);
            }
            if (loadInfoFromLocationState && TripSharedService.getConfig()) {
                setPageLoadData();
                setsLoadInfo(loadInfoFromLocationState);
                setsIsDoubleAssign(loadInfoFromLocationState?.isDoubleAssign);
                getTrips();
            } else
                setTimeout(() => {
                    goToInitiatorPage();
                }, 1000);
        }
    }, [prefLang.current]);
    useEffect(() => {
        if (!loading && (planLTResponse.loading || assignTripResponse.loading)) setloading(true);
        else setloading(false);
    }, [planLTResponse.loading, assignTripResponse.loading]);
    useEffect(() => {
        if (sIsAssignSuccess && assignTripResponse.error?.errors?.length) {
            setsIsAssignSuccess(false);
        } else if (sIsAssignSuccess && assignTripResponse.error?.errors?.length === 0) {
            setTimeout(() => {
                if (sIsHubstrOrDecstrReturnLoadSuccess) {
                    goToInitiatorPageHubDec();
                } else {
                    goToInitiatorPage();
                }
            }, 1000);
        }
    }, [sIsAssignSuccess, sIsHubstrOrDecstrReturnLoadSuccess]);
    const onSearchFilterModalClose = () => {
        setsIsSearchFilterModalOpen(false);
    };
    const onPlanSearchGT = (data) => {
        const payload = {};
        if (data?.planId) {
            const planIds = data.planId.split(',').map((id) => parseInt(id, 10));
            if (planIds.length > 0) {
                payload.planIds = planIds;
            }
        }
        fetchLTPlansWithPayload(searchPayloadForFilterGT(payload.planIds), 'fromSearch');
    };
    const getPlanSearch = () => {
        if (
            currentMarket === MarketCodeEnum.GUATEMALA.name.toLowerCase() ||
            currentMarket === MarketCodeEnum.MEXICO.name.toLowerCase() ||
            currentMarket === MarketCodeEnum.MEXICO_MARKET_PLACE.name.toLowerCase() ||
            currentMarket === MarketCodeEnum.COSTA_RICA.name.toLowerCase() ||
            currentMarket === MarketCodeEnum.EL_SALVADOR.name.toLowerCase()
        ) {
            return (
                <PlanSearchGT
                    pIsOpen={sIsSearchFilterModalOpen}
                    pOnClose={onSearchFilterModalClose}
                    pOnFilter={onPlanSearchGT}
                    pSearchFormValue={sSearchFormValue}
                    pSetSSearchFormValue={setSSearchFormValue}
                />
            );
        }
    };
    return (
        <>
            <PageHeader
                pOnBackClick={history.goBack}
                pTitle={trans('title.assignTrip')}
                LanguageSelectorComponent={LanguageSelector}
                MarketSelectorComponent={MarketSelector}
                useAppContextHook={AppUtils.get}
                pCommonTrans={commonTrans}
            >
                <PageHeader.Content placement="right">{getHeaderChildren()}</PageHeader.Content>
            </PageHeader>
            {sIsAssignSuccess && assignTripResponse.error?.errors?.length === 0 && (
                <Toast
                    text={trans('msg.loadAssignSuccess')}
                    variant="positive"
                    onClose={() => {
                        setsIsAssignSuccess(false);
                    }}
                    delay={toastTimer}
                    className={classes.stTripToast}
                />
            )}
            {sIsAssignSuccess && assignTripResponse.error && assignTripResponse.error?.errors?.length && (
                <Alert
                    variant="error"
                    action={() => {
                        onAssignTripSubmit(true, tripConfirmModalData);
                    }}
                    actionText={trans('button.retry')}
                >
                    {getErrorText(assignTripResponse.error)}
                </Alert>
            )}
            {!sIsAssignSuccess && assignTripResponse.error && (
                <Alert
                    variant="error"
                    action={() => {
                        onAssignTripSubmit(true, tripConfirmModalData);
                    }}
                    actionText={trans('button.retry')}
                >
                    {getErrorText(assignTripResponse.error)}
                </Alert>
            )}
            {planLTResponse.error && !planLTResponse.response && (
                <Alert
                    data-testid="tripErrorAlert"
                    variant="error"
                    action={getTrips}
                    actionText={trans('button.retry')}
                >
                    {getErrorText(planLTResponse.error)}
                </Alert>
            )}
            {pageLoadDataResponse.error && (
                <Alert
                    variant="error"
                    data-testid="pageLoadFailAlert"
                    action={getPageLoadData}
                    actionText={trans('button.retry')}
                >
                    {trans('API.error.getConfigGetStaticData')}
                </Alert>
            )}
            {!sIsDataInvalid && sCmsConfig && (
                <>
                    {featureFlags?.showAssignTripForDoubleTrailer && sIsDoubleAssign ? (
                        sLoadInfo?.filteredPlans?.map((loadInfo) => (
                            <LoadInfo key={loadInfo?.planId} pLoadInfo={loadInfo} />
                        ))
                    ) : (
                        <LoadInfo pLoadInfo={sLoadInfo} />
                    )}
                    <PlanTable
                        pTabIndex={PhaseTypesEnum.PLANNING.index}
                        pConfig={sCmsConfig}
                        pPlanList={sTripList}
                        pIsAssignTrip
                        pOnTripSelection={onTripSelection}
                        pUserPerm={sPerm}
                        pPageChange={handlePageChange}
                        pPageNumber={sPageNumber}
                        pFetchedTripCount={pFetchedTripCount}
                        pSetsIsSearchFilterModalOpen={setsIsSearchFilterModalOpen}
                        pFeatureFlagsData={featureFlags}
                    />
                    {sIsAssignTripModalOpen && sIsLocationDiff && (
                        <CreateTripConfirmModal
                            pIsOpen={sIsAssignTripModalOpen}
                            pOnClose={onAssignTripModalClose}
                            pIsAssignTrip
                            pConnectLoads={connectLoads.map((type) => ({
                                ...type,
                                value: trans(type.value),
                            }))}
                            pOnSubmit={onAssignTripSubmit}
                            pShowErrors={sShowErrors}
                        />
                    )}
                    {sIsSearchFilterModalOpen && getPlanSearch()}
                </>
            )}
        </>
    );
}
export default () => {
    const trans = loadI18n([
        ['en', enData],
        ['es', esData],
    ]);
    return (
        <ErrorBoundary
            pPageTitle={trans('title.assignTrip')}
            pUseAppContextHook={AppUtils.get}
            pDefaultErrorTitle={trans('msg.defaultError')}
        >
            <AssignTrip />
        </ErrorBoundary>
    );
};
