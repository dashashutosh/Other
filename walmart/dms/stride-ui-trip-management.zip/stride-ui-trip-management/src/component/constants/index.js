export const DefaultPage = 1;
export const PlanStatusListForAvailableTrips = [
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'CREATED',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'ASSIGNED',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'TENDERED',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'TENDER_ACCEPTED',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'TENDER_REJECTED',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'TENDER_CANCELED',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'TENDER_TIMEOUT',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'NEED_ATTENTION',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'READY_FOR_DISPATCH',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'DISPATCHED',
    },
    {
        planType: 'TRIP_PLAN_TYPE',
        status: 'IN_TRANSIT',
    },
];
