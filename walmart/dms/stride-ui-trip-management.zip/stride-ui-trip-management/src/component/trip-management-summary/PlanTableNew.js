import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
    TableContainer,
    Table,
    TableHead,
    TableWrapper,
    TableRow,
    TableCell,
    TableBody,
    TableHeader,
    TableHeaderLHS,
    TextInput,
    SearchIcon,
    TableHeaderRHS,
    Typography,
    TableActionHeader,
    Button,
    CloseIcon,
    Toast,
    Alert,
    FilterIcon,
    CaretDownIcon,
} from '@walmart/living-design-sc-ui';
import clsx from 'clsx';
import {
    stableSort,
    getComparator,
    getDateComparator,
    getStrToIntComparator,
    MarketCodeEnum,
    useAPI,
    TableSortLabel,
    TableFooter,
    AccordianWithChildElement,
    IntermediateDestination,
    openPageInNewTab,
    autoFormatBillOfLadingAssignment,
    ActionMenu,
    ReasonCodePickerModal,
} from '@walmart/stride-ui-commons';
import PropTypes, { number, string, bool } from 'prop-types';
import { useHistory } from 'react-router-dom';
import { createPortal } from 'react-dom';
import {
    planTableHeadCells as planTableCommonHeadCells,
    planSearchHeaders as planSearchCommonHeaders,
    connectLoads,
    toastTimer,
    ERROR_CONTAINER_ID,
    TABLE_ACTIONS_ENUM,
} from '../../Constants';
import { planTableHeadCellsCL, planSearchHeadersCL } from '../../ConstantsCL';
import PhaseTypesEnum from '../../utils/enums/PhaseTypesEnum';
import LoadUIStatusEnum from '../model/loadUiStatusEnum';
import PlanTableRow from './PlanTableRow';
import CreateTripConfirmModal from './CreateTripConfirmModal';
import { stTripToast } from '../../utils/StyleUtils';
import {
    transformLoads,
    formatCreateTripReq,
    getCarrierResourceAssignRequest,
    getCarrierAssignRequest,
    getResourceAssignRequest,
    getColumnsToExport,
    parseResourceAssignRequest,
    formatResponseForTableData,
    transformLoadsToEditTailer,
    getTransformedPlansList,
    getFilteredRows,
    getPaginatedRows,
    getFilteredColumnHeaders,
    getFilteredColumnHeadersCA,
    getSelectedRowsText,
    displayConfirmButton,
    getTrailerAssignSeg,
    displayHeaderLabel,
    getFooterLabels,
    displayAssignToTripButton,
    getEquipmentTypeSeg,
    getCountData,
    getTripsWithChargeLocValidation,
    transformLoadsToUpdateDestination,
    displayUpdateDestinationButton,
    getLocationIdsList,
    getSelectedPlanDetails,
    formatDoubleTrailerTripReq,
    displayDoubleTrailerButton,
} from './DataModels';
import { TripAPI, getSplitLoadAPIParams } from '../../service/TripAPI';
import TripUIStatusEnum from '../model/tripUiStatusEnum';
import WorkloadAssignmentModal from './WorkloadAssignmentModal';
import { getFormattedTripError, isChile, isCAM, getTableActions } from '../../utils/CommonUtils';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../utils/actions/PlanTableQueryActions';
import { getPlanTableSearchRequestPayload } from '../../utils/ui-mappers/PlanSearchMappers';
import { QueryStateType } from '../../utils/types/PlanSearchTypes';
import TripSharedService from '../../service/TripSharedService';
// import PlanCAData from '../../service/WorkflowDummyData.json';
import PlanExport from './PlanExport';
import getEnhancedRows from '../../utils/getEnhancedRows';
import ExceptionFilterChips from './ExceptionFilterChips';
import TableFilterChips from './TableFilterChips';
import EditTrailerModal from './US/EditTrailerModal';
import CreateDoubleTrailerModal from './CreateDoubleTrailerModal';

// for local testing
// import { transformCAPreviewResponseToUIModel } from '../model/PlanSearchPreviewMapper';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { Utilities, AppUtils } from '@gscope-mfe/app-bridge';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default,
    { debounce } = Utilities;
const useStyles = makeStyles(() => ({
    stTripToast,
    lhsHeaderAction: {
        alignItems: 'center',
    },
    lhsHeader: {
        display: 'flex',
        flexDirection: 'column',
    },
    rhsHeader: {
        flex: '0 !important',
    },
    lhsInnerRow: {
        display: 'flex',
    },
    lhsInner: {
        flexDirection: 'column',
        alignSelf: 'baseline',
    },
    stTtContainer: {
        maxWidth: 'calc(100vw - 7em)',
        display: 'flex',
        flexDirection: 'column',
        '& $table': {
            borderCollapse: 'separate',
            whiteSpace: 'nowrap',
        },
    },
    tableWrapper: {
        flexGrow: 1,
        '&.ld-sc-ui-table-wrapper': {
            maxHeight: 'unset',
        },
        '&.MuiTableContainer-root': {
            overflowX: 'unset',
        },
    },
    table: {
        '& .ld-sc-ui-checkbox-label': {
            paddingLeft: 1,
        },
    },
    stickyColumn: {
        position: 'sticky',
        backgroundColor: '#fafafa !important',
        '&:not(td)': {
            zIndex: '3 !important',
        },
    },
    stickyColumnCheckbox: {
        left: 0,
        minWidth: 90,
    },
    stickyColumnPlanId: {
        left: '90px !important',
        width: 100,
        // borderRight: '1px solid #ccc',
    },

    stickyColumnPlanEntity: {
        left: '190px !important',
        width: 100,
        // borderRight: '1px solid #ccc',
    },

    stickyColumnPlanStatus: {
        right: 0,
    },
    onlyLimitSelect: {
        color: '#74767c',
    },
    stickyColumnPlanTypeNoCheckbox: {
        left: '100px !important',
        width: 100,
    },
    stickyColumnPlanIdNoCheckBox: {
        left: 0,
        width: 100,
    },
    searchHeader: {
        zIndex: '1 !important',
    },
    searchHeaderStyle: {
        padding: '1rem .5rem 0rem 1rem !important',
    },
    tableHeader: {
        padding: '0 !important',
    },
    filterBoxHidden: {
        display: 'none',
    },
    filterBox: {
        display: 'block',
    },
    tableHeaderWrap: {
        '& th.MuiTableCell-head': {
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            height: '50px !important',
            padding: '6px 12px',
        },
    },
    footerWrap: {
        padding: '0.3rem 1rem 1rem 1rem !important',
        height: '78px',
    },
    singleLineStyle: {
        whiteSpace: 'nowrap',
    },
    tableActionStyle: {
        padding: '.75rem .75rem 0.75rem 1rem !important',
    },
    errorAlert: {
        position: 'absolute',
        bottom: '1rem',
        right: '1rem',
        zIndex: '10',
        '& .ld-sc-ui-alert': {
            minWidth: 'calc(100% - 1em)',
            display: 'flex',
            alignItems: 'center',
            borderRadius: '8px',
        },
    },
}));
let selectedCarriersList = [];
export default function PlanTable(props) {
    const {
        pTabIndex,
        pConfig,
        pOnTripApprove,
        pIsAssignTrip,
        pOnTripSelection,
        pStaticData,
        pOnTripDispatch,
        pCreateTripReq,
        pOnTripTender,
        pOnLoadMarkAsDelivered,
        pOnReprintDoc,
        pOnTripDelivered,
        pUserPerm,
        pIsActive,
        pIsLoading,
        mdmLocationTypes,
        pSetsIsSearchFilterModalOpen,
        pPhaseCounts,
        queryState,
        dispatch,
        pOnCarrierAssign,
        pOnViewAllComments,
        pOnWithdrawTender,
        pCancelLoad,
    } = props;
    const classes = useStyles();
    const trans = localizeLang();
    const history = useHistory();
    const { currentMarket, prefLang, userInfo, setloading, loading } = AppUtils.get();
    const [sHeaderCells, setsHeaderCells] = useState([]);
    const [sSearch, setsSearch] = useState('');
    const [sFilteredRows, setsFilteredRows] = useState([]);
    const [sCheckedRows, setsCheckedRows] = useState([]);
    const [sOrder] = useState('desc');
    const [sOrderBy] = useState('createdTs');
    const [sIsTripSelected, setsIsTripSelected] = useState(false);
    const [sIsConfirmTripModalOpen, setsIsConfirmTripModalOpen] = useState(false);
    const [sProcessTripStatus, setsProcessTripStatus] = useState('');
    const [sIsManualAssignModalOpen, setsIsManualAssignModalOpen] = useState(false);
    const [sLoadsToAssignManually, setsLoadsToAssignManually] = useState([]);
    const [sLoadsToAssignTrailer, setsLoadsToAssignTrailer] = useState([]);
    const [sLoadsToUpdateDestination, setsLoadsToUpdateDestination] = useState([]);
    const [sError, setsError] = useState('');
    const [sWorkLoadEditData, setsWorkLoadEditData] = useState();
    const [sIsWorkloadSuccess, setsIsWorkloadSuccess] = useState(false);
    const [sIsResourceApprovedSuccess, setsIsResourceApprovedSuccess] = useState(false);
    const [sPlanList, setsPlanList] = useState([]);
    const fetchedPlanListRef = useRef([]);
    const [sPageNumber, setsPageNumber] = useState(1);
    const [sFetchPlanError, setsFetchPlanError] = useState('');
    const [sExceptionCount, setsExceptionCount] = useState(0);
    const [sFilterCount, setsFilterCount] = useState(0);
    const [sPlanAggregateCount, setsPlanAggregateCount] = useState(0);
    const [sIsAssignTrailerModalOpen, setsIsAssignTrailerModalOpen] = useState(false);
    const [sIsSuccess, setsIsSuccess] = useState(false);
    const [sIsUpdateDestModalOpen, setsIsUpdateDestModalOpen] = useState(false);
    const [sUpdateDestinationSuccessMsg, setsUpdateDestinationSuccessMsg] = useState(null);
    const [sSplitLoadAPILoading, setsSplitLoadAPILoading] = useState(false);
    const [sIsCreateDoubleTrailerModalOpen, setsIsCreateDoubleTrailerModalOpen] = useState(false);
    const [sCreateDoubleTrailerError, setsCreateDoubleTrailerError] = useState([]);
    const [sDoubleTrailerSuccess, setsDoubleTrailerSuccess] = useState(false);
    const [sDoubleTrailerPlanId, setsDoubleTrailerPlanId] = useState('');
    const [sShowCancelConfirmationModal, setsShowCancelConfirmationModal] = useState(false);

    const pageLoadSettings = TripSharedService.getPageLoadSettings();
    const featureFlags = TripSharedService.getFeatureFlags();
    const { callAPI: createWorkloadAssignment, ...createWorkloadAssignmentResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .createWorkloadAssignment,
    );
    const { callAPI: updateWorkloadAssignment, ...updateWorkloadAssignmentResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .updateWorkloadAssignment,
    );
    const { callAPI: createResourceAssignment, ...createResourceResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .createResourceAssignment,
    );
    const { callAPI: updateResourceAssignment, ...updateResourceResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .updateResourceAssignment,
    );
    const { callAPI: carrierAssign, ...carrierAssignResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).carrierAssign,
    );
    const { callAPI: approveAssignment, ...approveAssignmentResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).approveAssignment,
    );
    const { callAPI: fetchLTPlansWithAgg, ...planLTResponseWithAgg } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).planSearchAggregates,
    );
    const { callAPI: fetchLTPlans, ...planLTResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getLTPlanPreview,
    );
    const { callAPI: createDoubleTrailer, ...createDoubleTrailerTripResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .createDoubleTrailerTrip,
    );

    const debouncedFn = useCallback(
        debounce((callback) => {
            callback();
        }, 100),
        [],
    );
    const columnsToExport = useMemo(
        () => getColumnsToExport(currentMarket.toUpperCase(), pTabIndex, trans, pConfig?.UOM),
        [currentMarket],
    );

    const apiParamsForSplitLoadAPI = useMemo(
        () => getSplitLoadAPIParams(currentMarket, prefLang?.current, userInfo),
        [currentMarket, prefLang?.current, userInfo],
    );

    // const filterDataByPhase = (data) =>{
    //    switch(pTabIndex){
    //       case 0 :
    //         return setsPlanList();
    //    }
    // }

    const getPlansAPI = (req) => {
        if (currentMarket === MarketCodeEnum.CANADA.code || featureFlags?.displayPhaseStatusCount) {
            if (req?.selectedStatus) delete req.selectedStatus;
            fetchLTPlansWithAgg(
                req,
                (res) => {
                    const { phaseStatusCounts, planResponseList } = res;
                    const tData = formatResponseForTableData(planResponseList, pageLoadSettings, featureFlags);
                    setsPlanList(tData);
                    pPhaseCounts(phaseStatusCounts?.payload);
                    setsPlanAggregateCount(planResponseList?.header?.headerAttributes?.PlanAggregateCount || 0);
                },
                (e) => {
                    setsFetchPlanError(e);
                },
            );
        } else {
            fetchLTPlans(
                req,
                (res) => {
                    const tData = formatResponseForTableData(res, pageLoadSettings, featureFlags);
                    setsPlanList(tData);
                    setsPlanAggregateCount(res?.header?.headerAttributes?.PlanAggregateCount || 0);
                },
                (e) => {
                    setsFetchPlanError(e);
                },
            );
        }
    };
    const getPlans = () => {
        setsFetchPlanError('');
        if (pIsActive) {
            const request = getPlanTableSearchRequestPayload(queryState, currentMarket, pConfig, featureFlags);
            // TODO: pass sort data
            getPlansAPI(request);
        }
    };
    const actionSuccessCb = () => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_PAGE_NUMBER,
            market: currentMarket,
        });
    };

    useEffect(() => {
        if (sUpdateDestinationSuccessMsg?.newLoadId && featureFlags?.enableHubDeconDestinations) {
            setsIsUpdateDestModalOpen(false);
            openPageInNewTab(`/mfe/stride/planquery/tripdetails?planId=${sUpdateDestinationSuccessMsg?.newLoadId}`);
            actionSuccessCb();
        }
    }, [sUpdateDestinationSuccessMsg]);

    const setExceptionType = useCallback((exceptionType) => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_EXCEPTION_TYPE,
            exceptionType,
        });
    }, []);
    useEffect(() => {
        debouncedFn(() => {
            getPlans();
        });
    }, [queryState]);
    useEffect(() => {
        // reset the data in memory when page number becomes 1
        if (queryState.page === 1) {
            fetchedPlanListRef.current = [];
            setsPageNumber(1);
        }
    }, [queryState]);
    const handleTableSearch = useCallback(
        (value) => {
            debouncedFn(() => {
                setsSearch(value);
                setsPageNumber(1);
            });
        },
        [debouncedFn],
    );
    const handleSortChange = (field) => {
        if (field === queryState.sortField) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_SORT_DIRECTION,
            });
        } else {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_SORT_FIELD,
                sortField: field,
                sortMode: 'DESC',
            });
        }
    };
    const transformedPlansList = useMemo(() => {
        fetchedPlanListRef.current = [...fetchedPlanListRef.current, ...sPlanList];
        return getTransformedPlansList(
            pTabIndex,
            fetchedPlanListRef.current,
            pStaticData,
            pConfig,
            currentMarket,
            featureFlags,
            pageLoadSettings,
            trans,
        );
    }, [sPlanList]);
    const [sEnhancedRowsList, setsEnhancedRowsList] = useState([]);
    useEffect(() => {
        let intervalId = null;
        if (pTabIndex === 1 && pageLoadSettings?.showCAColumns) {
            setsEnhancedRowsList(transformedPlansList);
            intervalId = setInterval(() => {
                setsEnhancedRowsList((_sEnhancedRowsList) => getEnhancedRows(_sEnhancedRowsList));
            }, 1000);
        } else {
            setsEnhancedRowsList(transformedPlansList);
        }
        return () => {
            clearInterval(intervalId);
        };
    }, [transformedPlansList]);
    useEffect(() => {
        if (!pIsActive) {
            fetchedPlanListRef.current = [];
        }
    }, [pIsActive]);
    const { planTableHeadCells, planSearchHeaders } = useMemo(() => {
        if (featureFlags?.showRegionAndMerchandiseDetails) {
            return {
                planTableHeadCells: planTableHeadCellsCL(),
                planSearchHeaders: planSearchHeadersCL,
            };
        }
        return {
            planTableHeadCells: planTableCommonHeadCells,
            planSearchHeaders: planSearchCommonHeaders,
        };
    }, [currentMarket]);
    const filteredRows = useMemo(
        () => getFilteredRows(sSearch, sEnhancedRowsList, planSearchHeaders),
        [sEnhancedRowsList, sSearch],
    );
    const paginatedData = useMemo(
        () => getPaginatedRows(filteredRows, sPageNumber, pConfig),
        [filteredRows, sPageNumber, pConfig],
    );
    const footerLabels = useMemo(() => getFooterLabels(trans), [trans]);
    const countData = useMemo(
        () => getCountData(sSearch, sPlanAggregateCount, filteredRows.length, featureFlags),
        [sSearch, sPlanAggregateCount, filteredRows],
    );
    const reasonCodePickerModalTranslations = useMemo(
        () => ({
            selectReason: trans('actions.label.selectReasonCodeForCancellation'),
            enterComment: trans('actions.label.additionalComments'),
            cancelBtn: trans('action.cancel'),
            primaryActionBtn: trans('action.cancelLoad'),
        }),
        [trans],
    );
    const tableHeaderActions = useMemo(() => {
        if (pUserPerm.canEditTrip) {
            return getTableActions(sProcessTripStatus, pConfig?.maxRowSelected, sCheckedRows, pTabIndex);
        }
        return [];
    }, [sProcessTripStatus, pConfig?.maxRowSelected, sCheckedRows]);

    const handleTableActionsMenuItemClick = (event) => {
        const actionCode = event.currentTarget.dataset.code;

        switch (actionCode) {
            case TABLE_ACTIONS_ENUM.APPROVE_LOAD.name:
                pOnTripApprove(sCheckedRows, actionSuccessCb);
                break;
            case TABLE_ACTIONS_ENUM.ASSIGN_CARRIER_AUTO.name:
                handleEditAssignment();
                break;
            case TABLE_ACTIONS_ENUM.TENDER_AUTO.name:
                pOnTripTender(sCheckedRows, actionSuccessCb);
                break;
            case TABLE_ACTIONS_ENUM.FORCE_LOAD_TO_DELIVERED.name:
                pOnLoadMarkAsDelivered(sCheckedRows);
                break;
            case TABLE_ACTIONS_ENUM.ADD_MULTI_COMMENT.name:
                pOnViewAllComments(transformedPlansList?.filter((plan) => sCheckedRows?.includes(plan?.planId)));
                break;
            case TABLE_ACTIONS_ENUM.WITHDRAW_TENDER.name:
                pOnWithdrawTender(sCheckedRows, actionSuccessCb);
                break;
            case TABLE_ACTIONS_ENUM.CANCEL_LOAD.name:
                setsShowCancelConfirmationModal(true);
                break;
            default:
                break;
        }
    };
    useEffect(() => {
        if (
            sPageNumber * pConfig.rowsPerPage >= filteredRows.length &&
            filteredRows.length > 0 &&
            filteredRows.length > pConfig.rowsPerPage
        ) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.INCREMENT_PAGE_NUMBER,
            });
        }
    }, [sPageNumber, pConfig]);
    const onClearAll = () => {
        setsCheckedRows([]);
    };
    const onConfirmTripModalClose = () => {
        setsIsConfirmTripModalOpen(false);
    };
    const onManualAssignModalClose = () => {
        setsIsManualAssignModalOpen(false);
    };
    const getSelectedLoadInfo = () => transformedPlansList.filter((plan) => sCheckedRows.includes(plan.planId))[0];

    const getSelectedDoubleInfo = () => {
        const filteredPlans = transformedPlansList?.filter((plan) => sCheckedRows?.includes(plan.planId));
        if (filteredPlans?.[0]?.planId !== sCheckedRows?.[0]) {
            filteredPlans.reverse();
        }
        return { filteredPlans, isDoubleAssign: true };
    };

    const openCloseDoubleTrailerModal = () => {
        setsIsCreateDoubleTrailerModalOpen(!sIsCreateDoubleTrailerModalOpen);
    };

    useEffect(() => {
        if (pageLoadSettings?.showCLColumns) {
            setsHeaderCells(getFilteredColumnHeaders(pTabIndex, planTableHeadCells, pIsAssignTrip, featureFlags));
        } else if (pageLoadSettings?.showCAColumns) {
            setsHeaderCells(getFilteredColumnHeadersCA(pTabIndex));
        }
    }, [pTabIndex]);
    useEffect(() => {
        if (sSearch) {
            setsSearch('');
        }
        if (sCheckedRows.length) {
            setsCheckedRows([]);
        }
    }, [transformedPlansList, queryState?.activeTabIndex]);
    useEffect(() => {
        if (
            (pTabIndex === PhaseTypesEnum.PROCESSING.index || pTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) &&
            sCheckedRows.length
        ) {
            setsLoadsToAssignManually(transformLoads(getSelectedLoadInfo().plans));
            setsLoadsToAssignTrailer(transformLoadsToEditTailer(getSelectedLoadInfo().plans));
        }
        if (pTabIndex === PhaseTypesEnum.PROCESSING.index && sCheckedRows.length) {
            selectedCarriersList = transformedPlansList
                ?.filter((plan) => sCheckedRows?.includes(plan.planId))
                ?.map((fPlan) => fPlan.carrierId);
        }
        if (
            pTabIndex === PhaseTypesEnum.PROCESSING.index &&
            sCheckedRows?.length &&
            featureFlags?.enableHubDeconDestinations
        ) {
            setsLoadsToUpdateDestination(transformLoadsToUpdateDestination(getSelectedLoadInfo()?.plans));
        }
    }, [sCheckedRows]);
    useEffect(() => {
        if (sOrder && sOrderBy && sFilteredRows.length) {
            if (sOrderBy === 'createdTs' || sOrderBy === 'departureTs' || sOrderBy === 'arrivalTs') {
                setsFilteredRows(
                    stableSort(sFilteredRows, getDateComparator(sOrder, sOrderBy, 'd MMM, yyyy, h:mm aaa')),
                );
            } else if (
                sOrderBy === 'distance' ||
                sOrderBy === 'planId' ||
                sOrderBy === 'originId' ||
                sOrderBy === 'destinationId' ||
                sOrderBy === 'cases' ||
                sOrderBy === 'pallets' ||
                sOrderBy === 'cube' ||
                sOrderBy === 'weight' ||
                sOrderBy === 'mode'
            ) {
                setsFilteredRows(stableSort(sFilteredRows, getStrToIntComparator(sOrder, sOrderBy)));
            } else {
                setsFilteredRows(stableSort(sFilteredRows, getComparator(sOrder, sOrderBy)));
            }
        }
    }, [sOrder, sOrderBy]);
    useEffect(() => {
        let isTrip = false;
        let tripStatus = '';
        if (transformedPlansList?.length && sCheckedRows?.length) {
            isTrip = transformedPlansList.filter((plan) => plan.planId === sCheckedRows[0])[0].isTrip;
            tripStatus = transformedPlansList.filter((plan) => plan.planId === sCheckedRows[0])[0].planStatus;
        }
        setsIsTripSelected(isTrip);
        setsProcessTripStatus(tripStatus);
        if (pIsAssignTrip) pOnTripSelection(sCheckedRows[0]);
    }, [sCheckedRows]);
    useEffect(() => {
        const isLoading =
            updateWorkloadAssignmentResponse.loading ||
            approveAssignmentResponse.loading ||
            createWorkloadAssignmentResponse.loading ||
            createResourceResponse.loading ||
            updateResourceResponse.loading ||
            carrierAssignResponse.loading ||
            planLTResponse.loading ||
            planLTResponseWithAgg.loading ||
            createDoubleTrailerTripResponse.loading ||
            sSplitLoadAPILoading ||
            pIsLoading;
        if (loading) {
            if (!isLoading) {
                setloading(false);
            }
        } else if (isLoading) {
            setloading(true);
        }
    }, [
        updateWorkloadAssignmentResponse.loading,
        approveAssignmentResponse.loading,
        createWorkloadAssignmentResponse.loading,
        createResourceResponse.loading,
        updateResourceResponse.loading,
        carrierAssignResponse.loading,
        planLTResponse.loading,
        planLTResponseWithAgg.loading,
        createDoubleTrailerTripResponse.loading,
        sSplitLoadAPILoading,
        pIsLoading,
    ]);
    const handleAssignTrailer = () => {
        setsIsAssignTrailerModalOpen(!sIsAssignTrailerModalOpen);
    };
    const handleEditTrailerSuccess = () => {
        setsIsSuccess(true);
    };
    const handleEditAssignment = () => {
        const planObj = transformedPlansList.find((plan) => plan.planId === sCheckedRows[0]);
        let autoPopoulateData = {};
        if (pageLoadSettings?.showCLColumns) {
            autoPopoulateData = {
                carrier: planObj.carrierId,
                equipmentType: planObj.carrierId ? getEquipmentTypeSeg(planObj.equipmentType, trans) : '',
                driver: planObj.driverId,
                tractor: planObj.equipmentId,
                truck: planObj.equipmentId,
                ...getTrailerAssignSeg(planObj.plans, trans),
                ...(featureFlags?.enableBillOfLading && {
                    billOfLading: autoFormatBillOfLadingAssignment(planObj),
                }),
                ...(featureFlags?.enableNewEquipmentTypes && {
                    cargo: planObj?.equipmentId,
                    car: planObj?.equipmentId,
                }),
            };
        } else if (pageLoadSettings?.showCAColumns) {
            autoPopoulateData = {
                carrier: planObj.carrierId,
                loadIds: sCheckedRows,
            };
        }
        setsWorkLoadEditData(autoPopoulateData);
    };
    useEffect(() => {
        if (sWorkLoadEditData) {
            setsIsManualAssignModalOpen(true);
        }
    }, [sWorkLoadEditData]);
    const onAssignTrip = () => {
        history.push({
            pathname: '/mfe/stride/tripmanagement/assign-trip',
            state:
                sCheckedRows?.length > 1 && featureFlags?.showAssignTripForDoubleTrailer
                    ? getSelectedDoubleInfo()
                    : getSelectedLoadInfo(),
        });
    };
    const getPlanningActions = () => {
        if (pUserPerm.canEditTrip) {
            if (pageLoadSettings?.showCLColumns) {
                return sIsTripSelected ? (
                    <Button
                        disabled={sCheckedRows.length > 15}
                        data-testid="approveTrip"
                        variant="primary"
                        size="small"
                        onClick={() => {
                            pOnTripApprove(sCheckedRows, actionSuccessCb);
                        }}
                    >
                        {trans('button.approveTrip')}
                    </Button>
                ) : (
                    <div className="d-flex">
                        {displayAssignToTripButton(sCheckedRows, transformedPlansList, featureFlags) && (
                            <Button
                                data-testid="assignToTrip"
                                variant="secondary"
                                size="small"
                                className="mr-3"
                                onClick={onAssignTrip}
                            >
                                {trans('button.assignToTrip')}
                            </Button>
                        )}
                        <Button
                            disabled={sCheckedRows.length > 15}
                            data-testid="createTrip"
                            variant="primary"
                            size="small"
                            onClick={() => {
                                setsIsConfirmTripModalOpen(true);
                            }}
                        >
                            {sCheckedRows.length === 1
                                ? trans('button.createNewTrip')
                                : `${trans('label.create')} ${sCheckedRows.length} ${trans('label.trips')}`}
                        </Button>
                    </div>
                );
            }
            if (pageLoadSettings?.showCAColumns) {
                return (
                    <Button
                        data-testid="approveLoad"
                        variant="primary"
                        size="small"
                        onClick={() => {
                            pOnTripApprove(sCheckedRows, actionSuccessCb);
                        }}
                    >
                        {trans('button.approveLoad')}
                    </Button>
                );
            }
        }
    };
    const handleApproveAssignment = (planId) => {
        const payload = {
            planId,
            status: 'RESOURCES_ASSIGN_APPROVED',
        };
        approveAssignment(
            {
                planId,
                payload,
            },
            () => {
                setsIsResourceApprovedSuccess(true);
                actionSuccessCb();
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const canShowEditAssignment = () =>
        (sProcessTripStatus?.name === TripUIStatusEnum.AWAITING_FINALIZATION.name || isCAM(currentMarket)) &&
        sCheckedRows.length === 1;
    const getProcessingActions = () => {
        if (pUserPerm?.canEditTrip) {
            if (pageLoadSettings?.showCLColumns) {
                return (
                    <div className="d-flex">
                        {sProcessTripStatus?.name === TripUIStatusEnum.WORKLOAD_ASSIGNMENT.name &&
                            isChile(currentMarket) && (
                                <>
                                    {sCheckedRows.length === 1 && (
                                        <>
                                            <Button
                                                data-testid="assignManually"
                                                variant="secondary"
                                                size="small"
                                                className="mr-3"
                                                onClick={() => {
                                                    handleEditAssignment();
                                                }}
                                            >
                                                {trans('button.assignManually')}
                                            </Button>
                                            {featureFlags?.enableAssignTrailer && (
                                                <Button
                                                    data-testid="assignTrailer"
                                                    variant="secondary"
                                                    size="small"
                                                    className="mr-3"
                                                    onClick={() => {
                                                        handleAssignTrailer();
                                                    }}
                                                >
                                                    {trans('button.assignTrailer')}
                                                </Button>
                                            )}
                                        </>
                                    )}
                                    {!selectedCarriersList?.some((id) => id !== '') && (
                                        <Button
                                            disabled={sCheckedRows.length > 15}
                                            data-testid="tenderTrip"
                                            variant="primary"
                                            size="small"
                                            onClick={() => {
                                                pOnTripTender(sCheckedRows, actionSuccessCb);
                                            }}
                                        >
                                            {trans('button.tenderTrip')}
                                        </Button>
                                    )}
                                </>
                            )}
                        {displayDoubleTrailerButton(paginatedData, sCheckedRows, featureFlags) && (
                            <Button
                                disabled={sCheckedRows.length > 15}
                                data-testid="create-double-trailer-trip"
                                variant="secondary"
                                className="mr-3"
                                size="small"
                                onClick={openCloseDoubleTrailerModal}
                            >
                                {trans('label.createDoubleTrailer')}
                            </Button>
                        )}
                        {displayConfirmButton(sCheckedRows, transformedPlansList) && (
                            <Button
                                disabled={sCheckedRows.length > 15}
                                data-testid="confirm"
                                variant="primary"
                                className="mr-3"
                                size="small"
                                onClick={() => {
                                    handleApproveAssignment(sCheckedRows);
                                }}
                            >
                                {trans('button.confirm')}
                            </Button>
                        )}
                        {sProcessTripStatus?.name === TripUIStatusEnum.WORKLOAD_ASSIGNMENT.name &&
                            featureFlags?.enableHubDeconDestinations &&
                            displayUpdateDestinationButton(sCheckedRows, transformedPlansList) && (
                                <Button
                                    data-testid="updateDestination"
                                    size="small"
                                    variant="secondary"
                                    className="mr-3"
                                    onClick={() => {
                                        setsIsUpdateDestModalOpen(true);
                                    }}
                                >
                                    {trans('button.updateDestination')}
                                </Button>
                            )}
                        {canShowEditAssignment() && (
                            <Button
                                data-testid="editAssignment"
                                variant="secondary"
                                size="small"
                                className="mr-3"
                                onClick={() => {
                                    handleEditAssignment();
                                }}
                            >
                                {trans('button.editAssignment')}
                            </Button>
                        )}
                        {sProcessTripStatus?.name === TripUIStatusEnum.WORKLOAD_ASSIGNMENT.name &&
                            isCAM(currentMarket) && (
                                <Button
                                    data-testid="confirm"
                                    variant="primary"
                                    size="small"
                                    onClick={() => {
                                        handleApproveAssignment(sCheckedRows);
                                    }}
                                >
                                    {trans('button.confirm')}
                                </Button>
                            )}
                    </div>
                );
            }
            if (pageLoadSettings?.showCAColumns) {
                return (
                    <div className="d-flex">
                        {(sProcessTripStatus?.name === LoadUIStatusEnum.TENDERS_EXHAUSTED.name ||
                            sProcessTripStatus?.name === LoadUIStatusEnum.NEEDS_ATTENTION.name ||
                            sProcessTripStatus?.name === LoadUIStatusEnum.TENDER_CANCELLED.name) &&
                            sCheckedRows.length === 1 && (
                                <Button
                                    data-testid="loadAssignManually"
                                    className="mr-3"
                                    variant="secondary"
                                    size="small"
                                    onClick={() => {
                                        handleEditAssignment();
                                    }}
                                >
                                    {trans('button.assignManually')}
                                </Button>
                            )}
                        {sProcessTripStatus?.name === LoadUIStatusEnum.TENDER_CANCELLED.name && (
                            <Button
                                data-testid="tenderLoad"
                                variant="primary"
                                size="small"
                                onClick={() => {
                                    pOnTripTender(sCheckedRows, actionSuccessCb);
                                }}
                            >
                                {trans('button.tenderTrip')}
                            </Button>
                        )}
                    </div>
                );
            }
        }
    };
    const getDispatchPendingActions = () => {
        if (pUserPerm?.canEditTrip) {
            if (pageLoadSettings?.showCLColumns) {
                return (
                    <div className="d-flex">
                        {sCheckedRows.length === 1 && (
                            <Button
                                data-testid="editWorkLoadAssignments"
                                variant="secondary"
                                size="small"
                                className="mr-3"
                                onClick={() => {
                                    handleEditAssignment();
                                }}
                            >
                                {trans('button.editWorkLoadAssignments')}
                            </Button>
                        )}
                        <Button
                            disabled={sCheckedRows.length > 15}
                            data-testid="dispatch"
                            variant="primary"
                            size="small"
                            onClick={() => {
                                pOnTripDispatch(
                                    featureFlags?.validateChargeLocationOnTripDispatch
                                        ? getTripsWithChargeLocValidation(paginatedData, sCheckedRows)
                                        : sCheckedRows,
                                    actionSuccessCb,
                                );
                            }}
                        >
                            {trans('button.dispatch')}
                        </Button>
                    </div>
                );
            }
            if (pageLoadSettings?.showCAColumns) {
                return (
                    <div className="d-flex">
                        {/* {(sProcessTripStatus?.name === LoadUIStatusEnum.AWAITING_PICKUP.name
             || sProcessTripStatus?.name === LoadUIStatusEnum.PICKUP_DELAYED.name) && (
             <><Button data-testid="forceToIntransit" variant="primary" size="small"
             onClick={() => { } }>
                {trans('button.forceToIntransit')}
              </Button>
             )} */}
                        <Button
                            disabled={sCheckedRows.length !== 1}
                            data-testid="forceLoadToDelivered"
                            variant="primary"
                            size="small"
                            onClick={() => {
                                pOnLoadMarkAsDelivered(sCheckedRows);
                            }}
                        >
                            {trans('button.forceLoadToDelivered')}
                        </Button>
                    </div>
                );
            }
        }
    };
    const getInTransitActions = () => {
        if (pUserPerm?.canEditTrip) {
            if (pageLoadSettings?.showCLColumns) {
                return (
                    <div className="d-flex">
                        <Button
                            disabled={sCheckedRows.length > 15}
                            data-testid="reprintDispatchDoc"
                            variant="secondary"
                            size="small"
                            className="mr-3"
                            onClick={() => {
                                pOnReprintDoc(sCheckedRows, actionSuccessCb);
                            }}
                        >
                            {trans('button.reprintDispatchDoc')}
                        </Button>
                        <Button
                            disabled={sCheckedRows.length > 15}
                            data-testid="markAsDelivered"
                            variant="primary"
                            size="small"
                            onClick={() => {
                                pOnTripDelivered(sCheckedRows, actionSuccessCb);
                            }}
                        >
                            {trans('button.markAsDelivered')}
                        </Button>
                    </div>
                );
            }
            if (pageLoadSettings?.showCAColumns) {
                return (
                    <div className="d-flex">
                        <Button
                            disabled={sCheckedRows.length !== 1}
                            data-testid="forceLoadToDelivered"
                            variant="primary"
                            size="small"
                            onClick={() => {
                                pOnLoadMarkAsDelivered(sCheckedRows);
                            }}
                        >
                            {trans('button.forceLoadToDelivered')}
                        </Button>
                    </div>
                );
            }
        }
    };
    const actions = () => {
        if (pTabIndex === PhaseTypesEnum.PLANNING.index) return getPlanningActions();
        if (pTabIndex === PhaseTypesEnum.PROCESSING.index) return getProcessingActions();
        if (pTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) return getDispatchPendingActions();
        if (pTabIndex === PhaseTypesEnum.IN_TRANSIT.index) return getInTransitActions();
    };
    const onCreateTripSubmit = (isAssign, data) => {
        setsIsConfirmTripModalOpen(false);
        pCreateTripReq(formatCreateTripReq(data, sCheckedRows), actionSuccessCb);
    };
    const createWorkloadAssignmentAPI = (req, planId) => {
        createWorkloadAssignment(
            {
                payload: req,
                planId,
            },
            () => {
                actionSuccessCb();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const updateWorkloadAssignmentAPI = (req, planId) => {
        updateWorkloadAssignment(
            {
                payload: req,
                planId,
            },
            () => {
                actionSuccessCb();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const carrierAssignAPI = (req) => {
        carrierAssign(
            req,
            () => {
                actionSuccessCb();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const createResourceAssignmentAPI = (req) => {
        createResourceAssignment(
            req,
            () => {
                actionSuccessCb();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const updateResourceAssignmentAPI = (req) => {
        updateResourceAssignment(
            req,
            () => {
                // pRefreshTableData();
                actionSuccessCb();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const createDoubleTrailerTrip = (data) => {
        createDoubleTrailer(
            formatDoubleTrailerTripReq(data),
            (res) => {
                if (res?.payload?.length > 0) {
                    setsDoubleTrailerPlanId(res?.payload[0]?.doubleLoadTrip);
                    openCloseDoubleTrailerModal();
                    setsDoubleTrailerSuccess(true);
                    actionSuccessCb();
                }
            },
            (err) => {
                if (err?.errors?.length > 0) {
                    setsCreateDoubleTrailerError(err?.errors?.[0]?.errorIdentifiers?.details?.errors);
                    openCloseDoubleTrailerModal();
                }
            },
        );
    };

    const handleWorkloadAssignConfirm = (
        workloadAssignment,
        options,
        isCreateCarrierAndResource,
        isCarrierOnly,
        isResourceAssign,
        isUpdateResource,
        isUpdateCarrier,
    ) => {
        const selectedTripId = sCheckedRows[0];
        const selectedTrip = sPlanList.find((plan) => plan.planId === parseInt(selectedTripId, 10));
        const workloadAssignmentData = {
            ...workloadAssignment,
            autoAccept: pageLoadSettings?.carrierAutoAccept,
            orderedLoads: sLoadsToAssignManually,
        };
        if (pageLoadSettings?.showCLColumns) {
            if (isCreateCarrierAndResource && isCarrierOnly && isResourceAssign) {
                const cwRequest = getCarrierResourceAssignRequest(
                    workloadAssignmentData,
                    options,
                    selectedTripId,
                    userInfo.loggedInUserName,
                    trans,
                    featureFlags,
                );
                const parsedCwRequest = {
                    carrierAssignRequest: cwRequest.carrierAssignRequest,
                    resourceAssignRequest: parseResourceAssignRequest(
                        cwRequest.resourceAssignRequest,
                        selectedTrip,
                        currentMarket,
                    ),
                };
                createWorkloadAssignmentAPI(parsedCwRequest, selectedTripId);
            } else if (isCreateCarrierAndResource && isCarrierOnly && !isResourceAssign) {
                const cReq = getCarrierAssignRequest(
                    workloadAssignmentData,
                    options.carrierInfo,
                    selectedTripId,
                    userInfo.loggedInUserName,
                );
                carrierAssignAPI(cReq);
            } else if (
                !isCreateCarrierAndResource &&
                isCarrierOnly &&
                !isUpdateCarrier &&
                isResourceAssign &&
                !isUpdateResource
            ) {
                const crReq = getResourceAssignRequest(
                    workloadAssignmentData,
                    options.equipmentInfo,
                    options.trailerInfo,
                    selectedTripId,
                    trans,
                    featureFlags,
                );
                createResourceAssignmentAPI(parseResourceAssignRequest(crReq, selectedTrip, currentMarket));
            } else if (
                !isCreateCarrierAndResource &&
                isCarrierOnly &&
                !isUpdateCarrier &&
                isResourceAssign &&
                isUpdateResource
            ) {
                const urReq = getResourceAssignRequest(
                    workloadAssignmentData,
                    options.equipmentInfo,
                    options.trailerInfo,
                    selectedTripId,
                    trans,
                    featureFlags,
                );
                updateResourceAssignmentAPI(parseResourceAssignRequest(urReq, selectedTrip, currentMarket));
            } else if (
                !isCreateCarrierAndResource &&
                isCarrierOnly &&
                isUpdateCarrier &&
                isResourceAssign &&
                isUpdateResource
            ) {
                const uwReq = getCarrierResourceAssignRequest(
                    workloadAssignmentData,
                    options,
                    selectedTripId,
                    userInfo.loggedInUserName,
                    trans,
                    featureFlags,
                );
                const parseduwReq = {
                    carrierAssignRequest: uwReq.carrierAssignRequest,
                    resourceAssignRequest: parseResourceAssignRequest(
                        uwReq.resourceAssignRequest,
                        selectedTrip,
                        currentMarket,
                    ),
                };
                updateWorkloadAssignmentAPI(parseduwReq, selectedTripId);
            } else if (
                !isCreateCarrierAndResource &&
                isCarrierOnly &&
                isUpdateCarrier &&
                isResourceAssign &&
                !isUpdateResource
            ) {
                const cwReq = getCarrierResourceAssignRequest(
                    workloadAssignmentData,
                    options,
                    selectedTripId,
                    userInfo.loggedInUserName,
                    trans,
                    featureFlags,
                );
                const parsedcwReq = {
                    carrierAssignRequest: cwReq.carrierAssignRequest,
                    resourceAssignRequest: parseResourceAssignRequest(
                        cwReq.resourceAssignRequest,
                        selectedTrip,
                        currentMarket,
                    ),
                };
                createWorkloadAssignmentAPI(parsedcwReq, selectedTripId);
            } else if (
                !isCreateCarrierAndResource &&
                isCarrierOnly &&
                isUpdateCarrier &&
                !isResourceAssign &&
                !isUpdateResource
            ) {
                const request = getCarrierAssignRequest(
                    workloadAssignmentData,
                    options.carrierInfo,
                    selectedTripId,
                    userInfo.loggedInUserName,
                );
                carrierAssignAPI(request);
            } else if (
                !isCreateCarrierAndResource &&
                isCarrierOnly &&
                isUpdateCarrier &&
                !isResourceAssign &&
                isUpdateResource
            ) {
                const uWrequest = getCarrierResourceAssignRequest(
                    workloadAssignmentData,
                    options,
                    selectedTripId,
                    userInfo.loggedInUserName,
                    trans,
                    featureFlags,
                );
                const parseduWrequest = {
                    carrierAssignRequest: uWrequest.carrierAssignRequest,
                    resourceAssignRequest: parseResourceAssignRequest(
                        uWrequest.resourceAssignRequest,
                        selectedTrip,
                        currentMarket,
                    ),
                };
                updateWorkloadAssignmentAPI(parseduWrequest, selectedTripId);
            }
        } else if (pageLoadSettings?.showCAColumns) {
            if (featureFlags?.enableMultiLoadAssignment) {
                onManualAssignModalClose();
                pOnCarrierAssign(sCheckedRows, workloadAssignmentData, transformedPlansList, actionSuccessCb);
            } else {
                const request = getCarrierAssignRequest(
                    workloadAssignmentData,
                    options.carrierInfo,
                    selectedTripId,
                    userInfo.loggedInUserName,
                );
                carrierAssignAPI(request);
            }
        }
    };
    const handleCloseCancelModal = useCallback(() => setsShowCancelConfirmationModal(false), []);
    const handleLoadCancelConfirmation = useCallback(
        (reasonInfo) => {
            const reasonCode = `Cancelled : ${reasonInfo?.comment} (reason code : ${reasonInfo?.reasonCode})`;
            pCancelLoad(sCheckedRows, reasonCode, actionSuccessCb);
            handleCloseCancelModal();
        },
        [sCheckedRows, handleCloseCancelModal],
    );
    const header = () => (
        <TableRow key="header" className={featureFlags?.viewMoreRecords ? classes.tableHeaderWrap : ''}>
            {pUserPerm?.canEditTrip && (
                <TableCell
                    className={pUserPerm?.canEditTrip ? clsx(classes.stickyColumn, classes.stickyColumnCheckbox) : null}
                />
            )}
            {sHeaderCells.map((headCell) => (
                <TableCell
                    key={headCell.id}
                    sortDirection={
                        headCell.sortField &&
                        (queryState?.sortField === headCell.sortField ? queryState?.sortMode.toLowerCase() : false)
                    }
                    data-testid={`plan-table-header-${headCell.id}`}
                    className={
                        pUserPerm?.canEditTrip
                            ? clsx({
                                  [classes.stickyColumn]:
                                      headCell.id === 'planId' ||
                                      headCell.id === 'planStatus' ||
                                      headCell.id === 'planStatusLabel' ||
                                      (headCell.id === 'planEntity' && pageLoadSettings?.showCAColumns),
                                  [classes.stickyColumnPlanId]: headCell.id === 'planId',
                                  [classes.stickyColumnPlanStatus]:
                                      headCell.id === 'planStatus' || headCell.id === 'planStatusLabel',
                                  [classes.stickyColumnPlanEntity]:
                                      headCell.id === 'planEntity' && pageLoadSettings?.showCAColumns,
                              })
                            : clsx({
                                  [classes.stickyColumn]:
                                      headCell.id === 'planId' ||
                                      headCell.id === 'planStatus' ||
                                      headCell.id === 'planStatusLabel' ||
                                      (headCell.id === 'planEntity' && pageLoadSettings?.showCAColumns),
                                  [classes.stickyColumnPlanIdNoCheckBox]: headCell.id === 'planId',
                                  [classes.stickyColumnPlanStatus]:
                                      headCell.id === 'planStatus' || headCell.id === 'planStatusLabel',
                                  [classes.stickyColumnPlanTypeNoCheckbox]:
                                      headCell.id === 'planEntity' && pageLoadSettings?.showCAColumns,
                              })
                    }
                >
                    {headCell.sortField ? (
                        <TableSortLabel
                            active={queryState.sortField === headCell.sortField}
                            direction={
                                queryState.sortField === headCell.sortField ? queryState.sortMode.toLowerCase() : 'asc'
                            }
                            onClick={() => handleSortChange(headCell.sortField)}
                        >
                            {displayHeaderLabel(headCell.label, pConfig, transformedPlansList.length, trans)}
                            {headCell.id === 'rate' && pConfig?.country?.currency && (
                                <div>({pConfig.country.currency[0]})</div>
                            )}
                        </TableSortLabel>
                    ) : (
                        <>{trans(headCell.label)}</>
                    )}
                </TableCell>
            ))}
        </TableRow>
    );
    const config = {
        type: 'SingleSelect',
        ownerId: featureFlags?.walmartTrailerOwnerID,
        rowsPerPreview: TripSharedService.getConfig()?.payload?.custom?.rowsPerPreview || undefined,
        trailerStatusCode: pConfig?.trailerStatusCode || undefined,
        size: pConfig?.size || undefined,
        entityType: TripSharedService.getConfig()?.payload?.custom?.entityType || undefined,
        ymsEvent: TripSharedService.getConfig()?.payload?.custom?.ymsEvent || undefined,
        trailerLocType: TripSharedService.getConfig()?.payload?.custom?.trailerLocType || undefined,
    };

    const locationIdLists = useMemo(() => {
        if (featureFlags?.enableHubDeconDestinations) {
            const locationList = getLocationIdsList(pStaticData);
            return locationList;
        }
    }, [pStaticData, featureFlags]);

    return (
        <>
            <div className={classes.errorAlert}>
                {sCreateDoubleTrailerError.length > 0 && (
                    <Alert
                        data-testid="doubleTrailerError"
                        variant="error"
                        onClose={() => setsCreateDoubleTrailerError([])}
                    >
                        {sCreateDoubleTrailerError?.[0]?.description}
                    </Alert>
                )}
                {sError && !sIsWorkloadSuccess && (
                    <Alert
                        variant="error"
                        data-testid="workloadFailAlert"
                        onClose={() => {
                            setsError('');
                        }}
                    >
                        {getFormattedTripError(sError, trans)}
                    </Alert>
                )}
                {approveAssignmentResponse?.error && !sIsResourceApprovedSuccess && (
                    <Alert
                        variant="error"
                        data-testid="resourceApproveFailAlert"
                        onClose={() => {
                            setsError('');
                        }}
                    >
                        {getFormattedTripError(approveAssignmentResponse?.error, trans)}
                    </Alert>
                )}
            </div>

            {sIsSuccess && (
                <Toast
                    text={trans('msg.editTrailerSuccess')}
                    variant="positive"
                    onClose={() => {
                        setsIsSuccess(false);
                    }}
                    delay={toastTimer}
                    className={classes.stTripToast}
                />
            )}
            {sUpdateDestinationSuccessMsg?.newLoadId && featureFlags?.enableHubDeconDestinations && (
                <Toast
                    text={`Trip ${sUpdateDestinationSuccessMsg?.newLoadId}`}
                    subText={trans('msg.splitLoadSuccess')}
                    variant="positive"
                    onClose={() => {
                        setsUpdateDestinationSuccessMsg(null);
                    }}
                    delay={toastTimer}
                    className={classes.stTripToast}
                />
            )}
            {sFetchPlanError
                ? createPortal(
                      <Alert
                          data-testid="invalidPlanPreviewAlert"
                          variant="error"
                          action={() => getPlans()}
                          actionText={trans('button.retry')}
                      >
                          {getFormattedTripError(sFetchPlanError, trans)}
                      </Alert>,
                      document.getElementById(ERROR_CONTAINER_ID),
                  )
                : null}
            {sIsWorkloadSuccess && (
                <Toast
                    text={trans('msg.workloadAssignSuccess')}
                    variant="positive"
                    delay={toastTimer}
                    className={classes.stTripToast}
                    onClose={() => {
                        setsIsWorkloadSuccess(false);
                    }}
                />
            )}

            {sIsResourceApprovedSuccess && (
                <Toast
                    text={trans('msg.resourceAssignApproveSuccess')}
                    variant="positive"
                    delay={toastTimer}
                    className={classes.stTripToast}
                    onClose={() => {
                        setsIsResourceApprovedSuccess(false);
                    }}
                />
            )}
            {sDoubleTrailerSuccess && (
                <Toast
                    text={trans('msg.doubleTrailerPlanId', { tripId: sDoubleTrailerPlanId })}
                    subText={trans('msg.doubleTrailerSuccess')}
                    variant="positive"
                    delay={toastTimer}
                    className={classes.stTripToast}
                    onClose={() => {
                        setsDoubleTrailerSuccess(false);
                    }}
                />
            )}
            <TableContainer className={classes.stTtContainer}>
                <TableHeader className={featureFlags?.viewMoreRecords ? classes.tableHeader : ''}>
                    {currentMarket === 'ca' && !featureFlags?.viewMoreRecords && (
                        <ExceptionFilterChips
                            pActiveTab={queryState.activeTabIndex}
                            pCurrentMarket={currentMarket}
                            pExceptionFilter={queryState.exceptionType}
                            pOnExceptionFilterChange={setExceptionType}
                        />
                    )}
                    {currentMarket === 'ca' && featureFlags?.viewMoreRecords && (
                        <AccordianWithChildElement pRowHeight={50} pCount={sExceptionCount}>
                            <ExceptionFilterChips
                                pActiveTab={queryState.activeTabIndex}
                                pCurrentMarket={currentMarket}
                                pExceptionFilter={queryState.exceptionType}
                                pOnExceptionFilterChange={setExceptionType}
                                pGetExceptionCount={(val) => setsExceptionCount(val)}
                            />
                        </AccordianWithChildElement>
                    )}
                </TableHeader>
                <TableHeader
                    className={clsx({
                        [classes.searchHeader]: featureFlags?.viewMoreRecords,
                        [classes.searchHeaderStyle]: sFilterCount > 0,
                    })}
                >
                    <TableActionHeader
                        show={sCheckedRows.length && !pIsAssignTrip}
                        className={featureFlags?.viewMoreRecords ? classes.tableActionStyle : ''}
                    >
                        <TableHeaderLHS className={classes.lhsHeaderAction}>
                            <Typography>
                                {`${sCheckedRows.length} ${getSelectedRowsText(sIsTripSelected, sCheckedRows, trans)}`}
                            </Typography>
                            <Button
                                data-testid="clearAll"
                                variant="text-only"
                                startIcon={<CloseIcon size="small" />}
                                onClick={onClearAll}
                            >
                                {trans('button.clear')}
                            </Button>
                            {sCheckedRows.length > 15 && (
                                <span className={classes.onlyLimitSelect}>{trans('rows.limit.validation')}</span>
                            )}
                        </TableHeaderLHS>
                        <TableHeaderRHS>
                            {featureFlags?.enableActionMenu ? (
                                <ActionMenu
                                    pActions={tableHeaderActions}
                                    pOnActionItemClick={handleTableActionsMenuItemClick}
                                    pBtnLabel={trans('button.actions')}
                                    pBtnVariant="secondary"
                                    pBtnStartIcon={<CaretDownIcon size="small" />}
                                />
                            ) : (
                                actions()
                            )}
                        </TableHeaderRHS>
                    </TableActionHeader>
                    <TableHeaderLHS className={classes.lhsHeader}>
                        <div className={classes.lhsInnerRow}>
                            <div className={classes.lhsInner}>
                                <TextInput
                                    id="search"
                                    key="search"
                                    value={sSearch}
                                    label={trans('label.search')}
                                    onChange={(e) => handleTableSearch(e.target.value)}
                                    endIcon={<SearchIcon size="small" />}
                                    data-testid="search"
                                />
                            </div>
                            {!featureFlags?.viewMoreRecords && (
                                <div className={`${classes.lhsInner}`}>
                                    <TableFilterChips dispatch={dispatch} queryState={queryState} />
                                </div>
                            )}
                        </div>
                    </TableHeaderLHS>
                    <TableHeaderRHS className={`gap-4 mr-4 ${classes.rhsHeader}`}>
                        {featureFlags?.showTotalCount && (
                            <Typography className={clsx(classes.singleLineStyle)}>
                                {`${sSearch === '' ? sPlanAggregateCount : filteredRows.length} ${trans(
                                    'table.results',
                                )}`}
                            </Typography>
                        )}
                        {pageLoadSettings?.showFilter && (
                            <div data-testid="filter-icon">
                                <FilterIcon
                                    onClick={() => {
                                        pSetsIsSearchFilterModalOpen(true);
                                    }}
                                    size="small"
                                />
                            </div>
                        )}
                        {pageLoadSettings?.showExport && (
                            <div className={classes.slLtDownloadWrapper}>
                                <PlanExport planData={paginatedData} columnsToExport={columnsToExport} />
                            </div>
                        )}
                    </TableHeaderRHS>
                </TableHeader>
                {featureFlags?.viewMoreRecords && (
                    <div
                        className={sFilterCount > 0 ? classes.filterBox : classes.filterBoxHidden}
                        data-testid="filteraccordion"
                    >
                        <AccordianWithChildElement pRowHeight={57} pCount={sFilterCount}>
                            <TableFilterChips
                                dispatch={dispatch}
                                queryState={queryState}
                                showMoreButton={false}
                                pGetFilterChipCount={(val) => {
                                    setsFilterCount(val);
                                }}
                            />
                        </AccordianWithChildElement>
                    </div>
                )}
                <TableWrapper className={classes.tableWrapper}>
                    <Table stickyHeader className={classes.table} data-testid="plan-table">
                        <TableHead>{header()}</TableHead>
                        <TableBody data-testid="plan-table-body">
                            {paginatedData.map((rowData) => (
                                <PlanTableRow
                                    key={rowData.planId}
                                    pRowData={rowData}
                                    classes={classes}
                                    pCheckedRows={sCheckedRows}
                                    pSetCheckedRows={setsCheckedRows}
                                    pTabIndex={pTabIndex}
                                    pIsTripSelected={sIsTripSelected}
                                    pTripStatus={sProcessTripStatus}
                                    pIsAssignTrip={pIsAssignTrip}
                                    pUserPerm={pUserPerm}
                                    mdmLocationTypes={mdmLocationTypes}
                                    pFeatureFlag={featureFlags}
                                />
                            ))}
                        </TableBody>
                    </Table>
                </TableWrapper>
                <TableFooter
                    count={countData}
                    onNextPage={() => {
                        setsPageNumber((_sPageNumber) => _sPageNumber + 1);
                    }}
                    onPrevPage={() => {
                        setsPageNumber((_sPageNumber) => _sPageNumber - 1);
                    }}
                    page={sPageNumber}
                    rowsPerPage={pConfig.rowsPerPage}
                    labels={footerLabels}
                    className={featureFlags?.viewMoreRecords ? classes.footerWrap : ''}
                    showPageCount={featureFlags?.showTotalCount && !featureFlags?.displayPhaseStatusCount}
                />
            </TableContainer>
            {!pIsAssignTrip && (
                <>
                    {sIsConfirmTripModalOpen && (
                        <CreateTripConfirmModal
                            pIsOpen={sIsConfirmTripModalOpen}
                            pOnClose={onConfirmTripModalClose}
                            pConnectLoads={connectLoads.map((type) => ({
                                ...type,
                                value: trans(type.value),
                            }))}
                            pOnSubmit={onCreateTripSubmit}
                        />
                    )}

                    {sIsManualAssignModalOpen && (
                        <WorkloadAssignmentModal
                            pOnClose={onManualAssignModalClose}
                            pOnConfirmAssign={handleWorkloadAssignConfirm}
                            pLoads={sLoadsToAssignManually}
                            pWorkloadData={sWorkLoadEditData}
                            pTrip={transformedPlansList?.find((plan) => plan?.planId === sCheckedRows[0])}
                        />
                    )}

                    {sIsAssignTrailerModalOpen && (
                        <EditTrailerModal
                            pOnClose={handleAssignTrailer}
                            pOnSuccess={handleEditTrailerSuccess}
                            pLoads={sLoadsToAssignTrailer}
                            pActionSuccessCb={actionSuccessCb}
                            pConfig={config}
                            pGetLicensePltNbrfrmYMS={TripSharedService.getFeatureFlags()?.getLicensePltNbrFromYms}
                        />
                    )}

                    {sIsCreateDoubleTrailerModalOpen && (
                        <CreateDoubleTrailerModal
                            pIsOpen={sIsCreateDoubleTrailerModalOpen}
                            pOnClose={openCloseDoubleTrailerModal}
                            pStaticData={pStaticData}
                            pPaginatedData={paginatedData}
                            pCheckedRows={sCheckedRows}
                            pOnCreate={createDoubleTrailerTrip}
                        />
                    )}

                    {sIsUpdateDestModalOpen && featureFlags?.enableHubDeconDestinations && (
                        <IntermediateDestination
                            pIsOpen={sIsUpdateDestModalOpen}
                            pOnClose={setsIsUpdateDestModalOpen}
                            pLocationIds={locationIdLists}
                            pLoads={sLoadsToUpdateDestination}
                            pApiParams={apiParamsForSplitLoadAPI}
                            pSelectedPlan={getSelectedPlanDetails(getSelectedLoadInfo())}
                            pOnAPILoading={(apiLoading) => setsSplitLoadAPILoading(apiLoading)}
                            pOnAPISuccess={(response) => setsUpdateDestinationSuccessMsg(response)}
                            pLanguage={prefLang?.current}
                            pIsDateValidationEnabled={featureFlags?.enableDateValidationInIntermediateDestination}
                        />
                    )}

                    {featureFlags?.enableMultiLoadCancel && (
                        <ReasonCodePickerModal
                            pOpen={sShowCancelConfirmationModal}
                            pTitle={`${trans('action.title.confirmLoadCancel')} ${trans('action.label.load')}`}
                            pModalContentInfo={trans('actions.label.loadCancelInfo')}
                            pReasonCodes={pStaticData?.reasonCodes}
                            pOnConfirm={handleLoadCancelConfirmation}
                            pOnCancel={handleCloseCancelModal}
                            pTranslations={reasonCodePickerModalTranslations}
                        />
                    )}
                </>
            )}
        </>
    );
}
PlanTable.propTypes = {
    pTabIndex: number.isRequired,
    pConfig: PropTypes.shape({
        rowsPerPage: number.isRequired,
        debounceTime: number.isRequired,
        country: PropTypes.shape({
            currency: PropTypes.arrayOf(string).isRequired,
        }).isRequired,
        UOM: PropTypes.object.isRequired,
        trailerStatusCode: PropTypes.arrayOf(string),
        size: PropTypes.number,
    }).isRequired,
    pOnTripApprove: PropTypes.func,
    pIsAssignTrip: bool,
    pOnTripSelection: PropTypes.func,
    pOnTripDispatch: PropTypes.func,
    pOnReprintDoc: PropTypes.func,
    pOnTripDelivered: PropTypes.func,
    pOnLoadMarkAsDelivered: PropTypes.func,
    pCreateTripReq: PropTypes.func,
    pOnTripTender: PropTypes.func,
    pUserPerm: PropTypes.oneOfType([PropTypes.object]),
    pSearchCriteria: PropTypes.shape({
        payload: PropTypes.shape({}),
    }),
    pIsActive: bool,
    pIsLoading: bool,
    mdmLocationTypes: PropTypes.oneOfType([PropTypes.object]),
    pSetsIsSearchFilterModalOpen: PropTypes.func,
    pPhaseCounts: PropTypes.func,
    queryState: QueryStateType.isRequired,
    dispatch: PropTypes.func.isRequired,
    pStaticData: PropTypes.shape({}).isRequired,
    pOnCarrierAssign: PropTypes.func,
    pOnViewAllComments: PropTypes.func,
    pOnWithdrawTender: PropTypes.func,
    pCancelLoad: PropTypes.func,
};
PlanTable.defaultProps = {
    pOnTripApprove: () => {},
    pIsAssignTrip: false,
    pOnTripSelection: () => {},
    pOnTripDispatch: () => {},
    pOnReprintDoc: () => {},
    pOnTripDelivered: () => {},
    pOnLoadMarkAsDelivered: () => {},
    pCreateTripReq: () => {},
    pOnTripTender: () => {},
    pUserPerm: {},
    pSearchCriteria: undefined,
    pIsActive: false,
    pIsLoading: false,
    mdmLocationTypes: {},
    pSetsIsSearchFilterModalOpen: () => {},
    pPhaseCounts: () => {},
    pOnCarrierAssign: () => {},
    pOnViewAllComments: () => {},
    pOnWithdrawTender: () => {},
    pCancelLoad: () => {},
};
