export const contextMock = {
    setBreadCrumbArr: jest.fn(),
    setHeaderConfig: jest.fn(),
    setBulkUploadConfig: jest.fn(),
    prefLang: {
        current: 'en',
    },
    currentMarket: 'us',
    moduleName: 'trip-management',
    setloading: jest.fn(),
    userInfo: {
        loggedInUserName: '123',
    },
    headerConfig: {},
    allLangs: [],
    setAllLangs: jest.fn(),
    bulkUploadConfig: {
        bulkActions: {},
        serviceAction: true,
        serviceType: true,
        hasEditPermission: true,
    },
};
export const REASON_CODES = [
    {
        id: 'CARRIER',
        value: 'Carrier',
    },
    {
        id: 'NO_HAZMAT',
        value: 'Walmart Transportation',
    },
    {
        id: 'DC',
        value: 'DC',
    },
    {
        id: 'STORE',
        value: 'Store',
    },
    {
        id: 'VENDOR_OR_SUPPLIER',
        value: 'Vendor/Supplier',
    },
    {
        id: 'WEATHER_OR_ROUTE',
        value: 'Weather/Route',
    },
];
export const transformedConfigResponseMock = {
    rowsPerPage: 15,
    debounceTime: 10,
    country: {
        currency: ['CLP'],
        id: '44',
        iso2: 'CL',
        iso3: 'CHL',
        name: 'Chile',
    },
    UOM: {
        width: 'M',
    },
};
export const mdmLocationTypesMock = {
    VNDR: 'VNDR',
    DC: 'DC',
    CRLOC: 'CRLOC',
    STORE: 'STORE',
    CP: 'CP',
    BVNDR: 'BVNDR',
    DISP: 'DISP',
};
