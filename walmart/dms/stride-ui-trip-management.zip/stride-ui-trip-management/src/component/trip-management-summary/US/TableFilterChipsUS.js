import React, { memo, useMemo } from 'react';
import PropTypes from 'prop-types';
import { MoreIcon, Chip } from '@walmart/living-design-sc-ui';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import { QueryStateType } from '../../../utils/types/PlanSearchTypes';
// Todo: R2 - review comment - Are these 2 functions the only change between existing component
// and this one? If yes, see if the same component can be reused.
import { tranformFilterCriteriaToChips, updateQueryStateWithChipsData } from './DataModelsUS';

/**
 * // TODO: Revist this entire component logic
 *
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;
const TableFilterChipsUS = ({ queryState, dispatch }) => {
    const trans = localizeLang();
    const chipsData = useMemo(() => tranformFilterCriteriaToChips(queryState.filter), [queryState.filter]);
    const handleChipClose = (val) => {
        const filterData = updateQueryStateWithChipsData(queryState.filter, val);
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_FILTER,
            filter: filterData,
        });
    };
    const displayChips = () => {
        let display = [...chipsData];
        const obj = {
            more: false,
        };
        if (display?.length > 4) {
            obj.more = true;
            display = chipsData?.slice(0, 4);
        }
        obj.display = display.map((chip) => (
            <Chip
                key={`${chip.field}-${chip.value}`}
                className="ml-2 mt-2"
                data-testid={`chip-${chip.field}`}
                showCrossIcon
                onClick={() => handleChipClose(chip)}
                variant="selected"
            >
                {`${trans(chip.label)} : ${chip.value}`}
            </Chip>
        ));
        return obj;
    };
    const chipsDisplay = displayChips();
    return (
        <div className="d-flex flex-wrap">
            {chipsDisplay.display}
            {chipsDisplay.more ? (
                <chip className="ml-2 mt-2" data-testid="moreIcon">
                    <MoreIcon size="medium" />
                </chip>
            ) : (
                ''
            )}
        </div>
    );
};
const propTypes = {
    queryState: QueryStateType.isRequired,
    dispatch: PropTypes.func.isRequired,
};
TableFilterChipsUS.propTypes = propTypes;
export default memo(TableFilterChipsUS);
