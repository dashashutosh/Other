import React, { useState, useEffect, useMemo } from 'react';
import {
    Typography,
    TextInput,
    SingleSelect,
    Button,
    ModalFooter,
    ModalHeader,
    DrawerComponent,
} from '@walmart/living-design-sc-ui';
import { LocationFinder, AutoCompleteEntity } from '@walmart/stride-ui-commons';
import PropTypes from 'prop-types';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import { QueryStateType } from '../../../utils/types/PlanSearchTypes';
import { plankeyRegex } from '../../../Constants';
import PhaseTypesEnum from '../../../utils/enums/PhaseTypesEnum';
import { getLocationLabels, equipmentStaticDataTransformer, getInvalidLocationsBasedonProfile } from './DataModelsUS';
import { getAutoEntityAPIParams } from '../../../service/TripAPI';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { AppUtils } from '@gscope-mfe/app-bridge';
const { Grid } = MaterialUiCore,
    { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const styles = makeStyles({
    drawer: {
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        maxWidth: '65vw',
    },
    selectFieldWidth: {
        minWidth: '100% !important',
    },
    searchBtn: {
        width: '10rem',
        justifyContent: 'center',
    },
    searchWrapper: {
        '& .ld-sc-ui-scope': {
            padding: 0,
        },
        '& .ld-sc-ui-scope .ld-sc-ui-select .ld-sc-ui-select-label': {
            padding: 0,
        },
    },
    locationSubHeading: {
        fontFamily: 'Bogle',
        fontStyle: 'normal',
        fontWeight: '700px',
        fontSize: '14px',
        lineHeight: '20px',
        color: '#74767C',
    },
    divScroll: {
        overflowX: 'hidden',
    },
});

/**
 *
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
const PlanSearchUS = (props) => {
    const { pIsOpen, pOnClose, pStaticData, dispatch, queryState } = props;
    const trans = localizeLang();
    const { currentMarket, prefLang, userInfo } = AppUtils.get();
    const APIParams = getAutoEntityAPIParams(currentMarket, prefLang.current, userInfo);
    const classes = styles();
    const [sFilterCount, setsFilterCount] = useState(0);
    const [sFormValue, setSFormValue] = useState({});
    const [sIsFormValid, setsIsFormValid] = useState(true);
    const [sLocationIdError, setsLocationIdError] = useState({});
    const onValueChange = (field, value) => {
        setsIsFormValid(true);
        if (field === 'originId') {
            setsLocationIdError((prevState) => ({
                ...prevState,
                originIdErr: '',
            }));
        }
        if (field === 'destinationId') {
            setsLocationIdError((prevState) => ({
                ...prevState,
                destinationIdErr: '',
            }));
        }
        setSFormValue((formValue) => ({
            ...formValue,
            [field]: value,
        }));
    };
    const validateLocationsBasedonProfile = () => {
        let isLocationIdsValid = true;
        let invalidOriginLocations;
        let invalidDestinationLocations;
        let originIdErr = '';
        let destinationIdErr = '';
        if (sFormValue && sFormValue?.originId && sFormValue?.originType) {
            invalidOriginLocations = getInvalidLocationsBasedonProfile(
                queryState.profile,
                sFormValue.originId,
                sFormValue.originType,
            );
        }
        if (sFormValue && sFormValue?.destinationId && sFormValue?.destinationType) {
            invalidDestinationLocations = getInvalidLocationsBasedonProfile(
                queryState.profile,
                sFormValue.destinationId,
                sFormValue.destinationType,
            );
        }
        if (invalidOriginLocations?.length) {
            originIdErr += `${sFormValue?.originType} - ${invalidOriginLocations.join(', ')} ${trans(
                'error.profileLocationId',
            )}`;
        }
        if (invalidDestinationLocations?.length) {
            destinationIdErr += `${sFormValue?.destinationType} - ${invalidDestinationLocations.join(', ')} ${trans(
                'error.profileLocationId',
            )}`;
        }
        setsLocationIdError({
            originIdErr,
            destinationIdErr,
        });
        isLocationIdsValid = !(originIdErr?.length || destinationIdErr?.length);
        return isLocationIdsValid;
    };
    const validateForm = () => {
        let formValid = true;
        if (
            (sFormValue?.originId && !sFormValue.originId.match(plankeyRegex)) ||
            (sFormValue?.destinationId && !sFormValue.destinationId.match(plankeyRegex)) ||
            (sFormValue?.carrierId && !sFormValue.carrierId.match(plankeyRegex))
        ) {
            formValid = false;
        }
        setsIsFormValid(formValid);
        return formValid;
    };
    const onSearch = () => {
        if (validateLocationsBasedonProfile()) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_FILTER,
                filter: sFormValue,
            });
            pOnClose();
        }
    };
    useEffect(() => {
        setSFormValue(queryState.filter);
    }, [queryState.filter]);
    useEffect(() => {
        let appliedFilters = 0;
        Object.entries(sFormValue).forEach(([key, value]) => {
            if (key !== 'dateType') {
                if (Array.isArray(value)) {
                    if (value.length) {
                        appliedFilters += 1;
                    }
                } else if (value || value === false) {
                    appliedFilters += 1;
                }
            }
        });
        if (sFilterCount !== appliedFilters) {
            setsFilterCount(appliedFilters);
        }
        validateForm();
    }, [sFormValue]);
    const isSearchDisabled = () =>
        !sIsFormValid || !sFilterCount || sLocationIdError?.originIdErr || sLocationIdError?.destinationIdErr;
    const { originDetails, destinationDetails } = useMemo(
        () => getLocationLabels(trans, pStaticData),
        [trans, pStaticData],
    );
    const onClearFilter = () => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_FILTER,
        });
    };
    const handleClose = () => pOnClose(false);
    return (
        <>
            <DrawerComponent open={pIsOpen} position="right" className={classes.drawer} handleClose={handleClose}>
                <ModalHeader onClose={handleClose}>{trans('title.filter')}</ModalHeader>
                <div className={`${classes.divScroll} st-ui-px-3 st-ui-py-6`}>
                    <Grid container spacing={2} className={classes.searchWrapper}>
                        <Grid item xs={2}>
                            <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                {trans('subTitle.plan')}
                            </Typography>
                        </Grid>
                        <Grid container item spacing={3}>
                            <Grid item xs={3}>
                                <SingleSelect
                                    id="trip-plan-id"
                                    key="planType"
                                    label={trans('label.planType')}
                                    options={pStaticData.planTypes}
                                    className={classes.selectFieldWidth}
                                    value={sFormValue?.planType}
                                    onChange={(_e) => onValueChange('planType', _e.target.getAttribute('value'))}
                                    data-testid="planType"
                                />
                            </Grid>
                        </Grid>
                        <Grid item xs={2}>
                            <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                {trans('subTitle.location')}
                            </Typography>
                        </Grid>
                        <Grid container item spacing={3}>
                            <Grid item xs={2}>
                                <Typography gutterBottom="true" align="left" className={classes.locationSubHeading}>
                                    {trans('subTitle.origin')}
                                </Typography>
                            </Grid>
                        </Grid>
                        <Grid container item>
                            {/* TODO: add autocomplete once Narendra adds it in common component */}
                            <LocationFinder
                                pLocationDetails={originDetails}
                                pFormValue={sFormValue}
                                pOnValueChange={onValueChange}
                                pApiConfig={APIParams}
                                pError={{
                                    locationId: sLocationIdError?.originIdErr,
                                }}
                                pDisablePortal
                            />
                        </Grid>
                        <Grid item xs={2}>
                            <Typography gutterBottom="true" align="left" className={classes.locationSubHeading}>
                                {trans('subTitle.destination')}
                            </Typography>
                        </Grid>
                        <Grid container item>
                            {/* TODO: check autocomplete once it is added in common component */}
                            <LocationFinder
                                pLocationDetails={destinationDetails}
                                pFormValue={sFormValue}
                                pOnValueChange={onValueChange}
                                pApiConfig={APIParams}
                                pError={{
                                    locationId: sLocationIdError?.destinationIdErr,
                                }}
                            />
                        </Grid>
                        {queryState.activeTabIndex !== PhaseTypesEnum.PLANNING.index && (
                            <>
                                <Grid item xs={2}>
                                    <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                        {trans('subTitle.carrier')}
                                    </Typography>
                                </Grid>
                                <Grid container item spacing={2}>
                                    <Grid item xs={6}>
                                        <TextInput
                                            id="trip-carrier-id"
                                            key="carrierId"
                                            label={trans('label.carrierId')}
                                            className="w-100"
                                            value={sFormValue?.carrierId}
                                            onChange={(e) => onValueChange('carrierId', e.target.value)}
                                            helperText={
                                                sFormValue?.carrierId?.match(plankeyRegex)
                                                    ? trans('multiInputHelperText')
                                                    : ''
                                            }
                                            variant={sFormValue?.carrierId?.match(plankeyRegex) ? 'default' : 'error'}
                                            errorText={
                                                sFormValue?.carrierId?.match(plankeyRegex)
                                                    ? ''
                                                    : trans('multiInputError')
                                            }
                                            data-testid="carrierId"
                                        />
                                    </Grid>
                                </Grid>
                                <Grid container item spacing={2}>
                                    <Grid item xs={3}>
                                        <SingleSelect
                                            id="serviceTerritory"
                                            key="serviceTerritory"
                                            label={trans('label.serviceTerritory')}
                                            // options={pStaticData.serviceTerritories}
                                            options={[]}
                                            className={classes.selectFieldWidth}
                                            value={sFormValue?.serviceTerritory}
                                            onChange={(_e) =>
                                                onValueChange('serviceTerritory', _e.target.getAttribute('value'))
                                            }
                                            data-testid="serviceTerritory"
                                        />
                                    </Grid>
                                    <Grid item xs={3}>
                                        <SingleSelect
                                            id="coordinatorBoard"
                                            key="coordinatorBoard"
                                            label={trans('label.coordinatorBoard')}
                                            // options={pStaticData.coordinatorBoards}
                                            options={[]}
                                            className={classes.selectFieldWidth}
                                            value={sFormValue?.coordinatorBoard}
                                            onChange={(_e) =>
                                                onValueChange('coordinatorBoard', _e.target.getAttribute('value'))
                                            }
                                            data-testid="coordinatorBoard"
                                        />
                                    </Grid>
                                    <Grid item xs={3}>
                                        {/* TODO: make this as auto complete once API is ready */}
                                        <TextInput
                                            id="driverId"
                                            key="driverId"
                                            label={trans('label.driverId')}
                                            className="w-100"
                                            value={sFormValue?.driverId}
                                            onChange={(e) => onValueChange('driverId', e.target.value)}
                                            variant={sFormValue?.driverId?.match(plankeyRegex) ? 'default' : 'error'}
                                            errorText={
                                                sFormValue?.driverId?.match(plankeyRegex)
                                                    ? ''
                                                    : trans('multiInputError')
                                            }
                                            data-testid="driverId"
                                        />
                                    </Grid>
                                    <Grid item xs={3}>
                                        <AutoCompleteEntity
                                            label={trans('label.trailerId')}
                                            entity="equipments"
                                            maxSuggestions={20}
                                            onSaveChangesClick={(_value) => onValueChange('trailerId', _value)}
                                            value={sFormValue?.trailerId?.value}
                                            apiConfig={APIParams}
                                            dataTransformer={equipmentStaticDataTransformer}
                                            config={{ disableSaveCancelBtn: true }}
                                        />
                                    </Grid>
                                </Grid>
                            </>
                        )}
                    </Grid>
                </div>
                <ModalFooter>
                    <Button
                        onClick={() => {
                            onClearFilter();
                        }}
                        variant="text-only"
                        data-testid="clearAllFilters"
                    >
                        {trans('advfilter.button.clearAllFilters')}
                    </Button>
                    <Button
                        onClick={() => {
                            onSearch();
                        }}
                        variant="primary"
                        data-testid="confirmBtn"
                        disabled={isSearchDisabled()}
                    >
                        {trans('advfilter.button.applyFilter')}
                    </Button>
                </ModalFooter>
            </DrawerComponent>
        </>
    );
};
const selectOption = PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    value: PropTypes.string.isRequired,
});
const propTypes = {
    pIsOpen: PropTypes.bool.isRequired,
    pOnClose: PropTypes.func.isRequired,
    pStaticData: PropTypes.shape({
        planTypes: PropTypes.arrayOf(selectOption.isRequired),
        states: PropTypes.arrayOf(selectOption.isRequired),
        countries: PropTypes.arrayOf(selectOption.isRequired),
        serviceTerritories: PropTypes.arrayOf(selectOption).isRequired,
        coordinatorBoards: PropTypes.arrayOf(selectOption).isRequired,
    }).isRequired,
    dispatch: PropTypes.func.isRequired,
    queryState: QueryStateType.isRequired,
};
PlanSearchUS.propTypes = propTypes;
export default PlanSearchUS;
