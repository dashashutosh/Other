import React, { useState, useEffect, useMemo } from 'react';
import { FetchUserDetails, getEnvironment } from '@walmart/stride-ui-commons';
import { useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';
import { transformOptionsProfiles } from './DataModelsUS';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import {
    companyName,
    USER_PREF_PROFILE,
    USER_PREF_FAV_BG_KEY,
    STRIDE_UI_TM_PROFILE_LINK_MFE,
    USER_PREF_NAME_V2,
    STRIDE_UI_TM_PROFILE_LINK_NON_MFE,
} from '../../../Constants';
import TripSharedService from '../../../service/TripSharedService';
import CustomList from './CustomList';
import axios from '../../../axios';
import { AppUtils, Utilities } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { setUserPreference } = Utilities,
    { localizeLang } = LocalizeLang.default;
const propTypes = {
    dispatch: PropTypes.func.isRequired,
    pPageStaticData: PropTypes.string.isRequired,
    queryState: {
        profile: PropTypes.objectOf.isRequired,
    }.isRequired,
};

/**
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
const ProfileSelectorV2 = ({ queryState, dispatch, pPageStaticData }) => {
    const history = useHistory();
    const trans = localizeLang();
    const { currentMarket, prefLang, setloading, userInfo } = AppUtils.get();
    const env = getEnvironment({
        hostname: window.location.hostname,
    });
    const USER_PREF_PAGE_NAME = `${currentMarket}_${env}_${USER_PREF_NAME_V2}`;
    const [sProfileData, setsProfileData] = useState(() => []);
    const profile = useMemo(() => {
        if (queryState?.profile) {
            return (
                sProfileData.find((val) => val?.key === queryState.profile?.key) || {
                    id: 1,
                    key: 'default',
                    name: 'Default-LTM',
                    preferences: [],
                }
            );
        }
    }, [queryState?.profile]);
    const onClickManageProfile = () => {
        history.push({
            pathname: TripSharedService.getFeatureFlags()?.hasTMPMigratedToMFE
                ? STRIDE_UI_TM_PROFILE_LINK_MFE
                : STRIDE_UI_TM_PROFILE_LINK_NON_MFE,
        });
    };
    const getUserProfile = () => {
        FetchUserDetails(false, null, null, companyName, currentMarket?.toUpperCase(), axios, prefLang.current)
            .then((res) => {
                if (res?.tripManagementProfile) {
                    if (res.isUpdateRequired) {
                        setsProfileData(res.tripManagementProfile);
                    }
                } else {
                    const payload = {
                        id: 1,
                        key: 'default',
                        name: 'Default-LTM',
                        preferences: [],
                    };
                    dispatch({
                        type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE,
                        profile: payload,
                    });
                }
                setloading(false);
            })
            .catch(() => {
                setloading(false);
            });
    };
    const setUserPref = async (pref) => {
        const payload = {
            pageName: USER_PREF_PROFILE,
            key: USER_PREF_FAV_BG_KEY,
            value: pref,
        };
        await setUserPreference(payload);
    };
    const onSelectProfile = (prof) => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE,
            profile: prof,
        });
        setUserPref(prof);
    };
    useEffect(() => {
        if (prefLang.current) {
            if (pPageStaticData) {
                if (TripSharedService.getFeatureFlags()?.showProfileSelectorV2) {
                    const userPref = JSON.parse(
                        localStorage.getItem(`ngStorage-preferences_${userInfo.loggedInUserName}`),
                    );
                    if (userPref && userPref?.[USER_PREF_PAGE_NAME]) {
                        const tripManagementProfile = [
                            ...(userPref?.[USER_PREF_PAGE_NAME]?.tripManagementProfile || []),
                        ];
                        const profileDef = userPref?.[USER_PREF_PAGE_NAME];
                        const profileSelected = parseInt(profileDef?.defaultTripManagementProfile, 10);
                        if (tripManagementProfile.length === 0) {
                            dispatch({
                                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE,
                                profile: {
                                    key: 1,
                                    name: 'Default-LTM',
                                    preferences: [],
                                },
                            });
                        }
                        const list = transformOptionsProfiles(tripManagementProfile);
                        setsProfileData(list);
                        if (list.some((val) => val.key === profileSelected)) {
                            dispatch({
                                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE,
                                profile: list.find((val) => val.key === profileSelected),
                            });
                        } else if (tripManagementProfile?.[0]) {
                            dispatch({
                                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE,
                                profile: {
                                    ...tripManagementProfile[0],
                                },
                            });
                        }
                    } else {
                        getUserProfile();
                    }
                }
            }
        }
    }, [pPageStaticData, prefLang.current]);
    return (
        <CustomList
            pData={sProfileData}
            pEmptyName={trans('no.profile')}
            pKey={trans('type.config.profile')}
            pSelected={profile}
            pOnSelected={onSelectProfile}
            pText={{
                editText: trans('edit.text'),
                optionsSet: trans('th.basis'),
            }}
            pManagenav={onClickManageProfile}
            pWidth="200"
            pVertical="-20"
            pHorizontal={['40', '145']}
            pDataTestId="profileSelect"
        />
    );
};
ProfileSelectorV2.propTypes = propTypes;
export default ProfileSelectorV2;
