import React, { useState, useEffect, useMemo } from 'react';
import { useAPI, ForceToDelivered, PlanPhaseEnum, LoadActionsEnum } from '@walmart/stride-ui-commons';
import PropTypes from 'prop-types';
import { Toast } from '@walmart/living-design-sc-ui';
import PlanDetailsMapper from '../../../utils/ui-mappers/US/PlanDetailsMapper';
import usePlanActionsApiUS from '../../../hooks/usePlanActionsApiUS';
import { forceLoadToDeliverModalTranslations, getErrorText } from '../../../utils/CommonUtils';
import { TripAPI } from '../../../service/TripAPI';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { formatUpdateTimeLineData } from '../DataModels';
import TripSharedService from '../../../service/TripSharedService';

const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const useStyles = makeStyles({
    toast: {
        '&.ld-sc-ui-toast--snack-bar': {
            position: 'absolute',
            bottom: '1rem',
            right: '1rem',
        },
    },
});
const UpdateTimelineModal = (props) => {
    const { pOpenModal, pPlanId, pOnCloseModal, pStaticData, dispatch, pIsTripSelected } = props;
    const classes = useStyles();
    const { prefLang, currentMarket, userInfo, setloading, loading } = AppUtils.get();
    const trans = localizeLang();
    const [sLoadDetailsResponse, setsLoadDetailsResponse] = useState();
    const [sLosEvent, setsLOSEvents] = useState();
    const [sShowSuccess, setsShowSuccess] = useState(false);
    const [sError, setsError] = useState('');
    const { handlePlanAction } = usePlanActionsApiUS();
    const featureFlags = TripSharedService.getFeatureFlags();

    const TripApi = useMemo(
        () => TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName),
        [currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName],
    );
    const { callAPI: fetchLoadDetails, ...fetchLoadDetailsResponse } = useAPI(TripApi.getAllLoadsDetail);
    const { callAPI: fetchStaticDataAPI, ...fetchStaticDataResponse } = useAPI(TripApi.fetchStaticData);
    useEffect(() => {
        const isLoading = fetchStaticDataResponse.loading || fetchLoadDetailsResponse.loading;
        if (loading) {
            if (!isLoading) {
                setloading(false);
            }
        } else if (isLoading) {
            setloading(true);
        }
    }, [fetchStaticDataResponse.loading, fetchLoadDetailsResponse.loading]);
    useEffect(() => {
        if (fetchLoadDetailsResponse.response?.payload) {
            setsLoadDetailsResponse(fetchLoadDetailsResponse.response.payload);
        }
    }, [fetchLoadDetailsResponse.response]);
    useEffect(() => {
        if (fetchStaticDataResponse.response?.los) {
            setsLOSEvents(fetchStaticDataResponse.response?.los);
        }
    }, [fetchStaticDataResponse.response]);
    useEffect(() => {
        if (fetchStaticDataResponse.error) {
            setsError(fetchStaticDataResponse.error);
        }
        if (fetchLoadDetailsResponse.error) {
            setsError(fetchLoadDetailsResponse.error);
        }
    }, [fetchStaticDataResponse.error, fetchLoadDetailsResponse.error]);
    useEffect(() => {
        if (!pOpenModal) {
            setsLoadDetailsResponse({});
            return;
        }
        fetchStaticDataAPI();
        if (pPlanId) {
            fetchLoadDetails(pPlanId);
        }
    }, [pOpenModal, pPlanId]);
    const loadDetails = useMemo(
        () =>
            sLoadDetailsResponse ? PlanDetailsMapper.getLoadDetails(sLoadDetailsResponse, trans, pStaticData) : null,
        [sLoadDetailsResponse, pStaticData, trans],
    );
    const updateTimelineModalTranslations = useMemo(() => {
        const statusType = loadDetails?.statusUtils?.phase?.name;
        const isSamePhase = statusType === PlanPhaseEnum.IN_TRANSIT.name;
        const forceDeliTrans = forceLoadToDeliverModalTranslations(isSamePhase, trans);
        return forceDeliTrans;
    }, [trans, loadDetails]);
    const markLoadAsDelivered = (response) => {
        setsError('');
        const payload = formatUpdateTimeLineData(pPlanId, response, pIsTripSelected);
        handlePlanAction(
            LoadActionsEnum.UPDATE_TIMELINE.name,
            payload,
            () => {
                setsShowSuccess(true);
                dispatch({
                    type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                    checkedRows: [],
                });
                pOnCloseModal();
            },
            (error) => {
                setsError(error);
            },
        );
    };
    return (
        <>
            {pOpenModal && (
                <ForceToDelivered
                    pIsModalOpen={pOpenModal}
                    pOnCloseModal={pOnCloseModal}
                    pOnConfirmation={markLoadAsDelivered}
                    pModelData={loadDetails?.stopSequence?.stops}
                    pLos={sLosEvent || []}
                    pTranslations={updateTimelineModalTranslations}
                    pError={getErrorText(sError, trans)}
                    pDisableAutoCloseOnConfirm
                    pArrivalDepartureLosToggle={featureFlags?.showArrivalDepartureLosToggle}
                />
            )}

            {sShowSuccess && (
                <Toast
                    className={classes.toast}
                    delay={5000}
                    text={updateTimelineModalTranslations.successMessage}
                    variant="positive"
                    onClose={() => {
                        setsShowSuccess(false);
                    }}
                />
            )}
        </>
    );
};
const propTypes = {
    pOpenModal: PropTypes.bool.isRequired,
    pOnCloseModal: PropTypes.func.isRequired,
    pPlanId: PropTypes.string.isRequired,
    pStaticData: PropTypes.shape({}).isRequired,
    dispatch: PropTypes.func.isRequired,
    pIsTripSelected: PropTypes.bool.isRequired,
};
UpdateTimelineModal.propTypes = propTypes;
export default UpdateTimelineModal;
