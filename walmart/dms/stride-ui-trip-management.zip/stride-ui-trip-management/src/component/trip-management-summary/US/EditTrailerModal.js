import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { EditTrailerID } from '@walmart/stride-ui-commons';
import { BASE_URL } from '../../../Constants';
import axios from '../../../axios';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;
const EditTrailerModal = ({ pOnClose, pOnSuccess, pLoads, pActionSuccessCb, pConfig, pGetLicensePltNbrfrmYMS }) => {
    const { prefLang, userInfo, currentMarket, setloading } = AppUtils.get();
    const trans = localizeLang();
    const labels = useMemo(
        () => ({
            modalTitle: trans('editTrailer.title.modalTitle'),
            trailer: trans('editTrailer.label.trailerId'),
            load: trans('editTrailer.label.load'),
            originLocation: trans('editTrailer.label.originLocation'),
            destinationLocation: trans('editTrailer.label.destinationLocation'),
            buttonCancel: trans('editTrailer.label.buttonCancel'),
            buttonSave: trans('editTrailer.label.buttonSave'),
            trailerWarning: trans('trailerWarning'),
            validationMessage: trans('error.validationMessage'),
            buttonIgnore: trans('editTrailer.label.buttonIgnore'),
            errorMessage: trans('editTrailer.errors'),
        }),
        [prefLang.current],
    );
    const APIParams = {
        axios,
        currentMarket,
        language: prefLang.current,
        userId: userInfo.loggedInUserName,
        hostname: window.location.hostname,
        usUsTenant: true,
        timeout: 5000,
        baseUrl: BASE_URL,
    };
    const handleSuccess = () => {
        pActionSuccessCb();
        pOnSuccess();
        pOnClose();
    };
    return (
        <>
            <EditTrailerID
                pOnClose={pOnClose}
                pOnSuccess={handleSuccess}
                pLabels={labels}
                pLoads={pLoads}
                pApiConfig={APIParams}
                pTrans={trans}
                pSetloading={(e) => {
                    setloading(e);
                }}
                pConfig={pConfig}
                pGetLicensePltNbrfrmYMS={pGetLicensePltNbrfrmYMS}
            />
        </>
    );
};
const propTypes = {
    pOnClose: PropTypes.func.isRequired,
    pOnSuccess: PropTypes.func.isRequired,
    pLoads: PropTypes.arrayOf(PropTypes.shape({})),
    pActionSuccessCb: PropTypes.func.isRequired,
    pConfig: PropTypes.shape({}),
    pGetLicensePltNbrfrmYMS: PropTypes.bool,
};
EditTrailerModal.propTypes = propTypes;
EditTrailerModal.defaultProps = {
    pLoads: [],
    pConfig: {},
    pGetLicensePltNbrfrmYMS: false,
};
export default EditTrailerModal;
