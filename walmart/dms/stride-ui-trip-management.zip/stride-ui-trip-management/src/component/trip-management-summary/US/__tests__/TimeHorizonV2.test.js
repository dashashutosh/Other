import React from 'react';
import { render, screen } from '@testing-library/react';
import TimeHorizonV2 from '../TimeHorizonV2';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../../service/__tests__/mocks/mocks/TripMapper.mock';

beforeAll(() => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMockUS);
});

describe('Time Horizon', () => {
    it('renders correctly as intended', () => {
        render(<TimeHorizonV2 queryState={{ timeHorizon: {} }} />);
        const timehorizon = screen.getByText('type.config.timehorizon');
        expect(timehorizon).toBeDefined();
    });
});
