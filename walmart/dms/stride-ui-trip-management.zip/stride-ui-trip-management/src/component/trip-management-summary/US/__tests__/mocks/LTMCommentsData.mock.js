export const getMockDataForLTMComments = () => {
    const updatedTripCommentText = 'Test TRIP comment - updated';
    const updatedLoadCommentText = 'Test LOAD comment - updated';

    const comments = [
        {
            commentText: 'Test comment',
            commentId: 1,
            commentType: 'GENERAL',
            entityType: 'Trip',
            entityId: 123456,
        },
        {
            commentText: 'Test comment',
            commentId: 1,
            commentType: 'GENERAL',
            entityType: 'Load',
            entityId: 4444,
        },
    ];

    const plans = [
        {
            planId: 123456,
            planEntity: 'TRIP',
            planComments: [{ ...comments[0] }],
            childPlans: [
                {
                    planId: 4444,
                    planEntity: 'LOAD',
                    planComments: [{ ...comments[1] }],
                },
            ],
        },
    ];

    const commentsDrawerOutput = {
        comments: [
            {
                commentText: updatedTripCommentText,
                commentId: 1,
                commentType: 'GENERAL',
                entityType: 'Trip',
                entityId: 123456,
            },
            {
                commentText: updatedLoadCommentText,
                commentId: 1,
                commentType: 'GENERAL',
                entityType: 'Load',
                entityId: 4444,
            },
        ],
    };

    const commentsDrawerInput = {
        pSelectedPlan: {
            planId: 123456,
            planType: 'Trip',
        },
        pLoadIds: [4444],
        pComments: comments,
    };
    return {
        updatedTripCommentText,
        updatedLoadCommentText,
        comments,
        plans,
        commentsDrawerOutput,
        commentsDrawerInput,
    };
};
