/* eslint-disable no-nested-ternary */
import {
    getLocationTypeToIconMap,
    safeDateFormat,
    getHhmmFromMinutes,
    StopSequenceHelpers,
    dateTimeFormatterWithTz,
    getShortTzAbbrFromStaticData,
    planStatusDesc,
    BEPlanCategoryEnum,
    isAssignedToCarrier,
    getDiffDaysISO,
    OperationalFlagEnum,
    EntityTypeEnum,
    safeDateFormatLocalTz,
} from '@walmart/stride-ui-commons';
import moment from 'moment';
import PhaseTypesEnum from '../../../utils/enums/PhaseTypesEnum';
import {
    planTableHeadCellsUS,
    excludedColumnsForPlanning,
    excludedColumnsForReadyToStart,
    excludedColumnsForDelivered,
    optionsDateTransform,
    excludedColumnsForProcessing,
    excludedColumnsForIntransit,
    commonColumnHeaders,
    DATE_FNS_DATE_TIME_FORMAT,
    timeZone,
    timeHorizonDateFormat,
    regexPast,
    regexFuture,
    defaultTimeHorizon,
    priDestinationColumnId,
    dwellDaysColumnId,
    tripServiceTerritoryColumnId,
    planningServiceTerritoryColumnId,
    serviceTerritoryColumnId,
    tagsId,
    comments,
} from '../../../ConstantsUS';
import TimehorizonUiPhaseEnum from '../../model/timehorizonUiType';
import TripSharedService from '../../../service/TripSharedService';
const { getRoundedDistance } = StopSequenceHelpers;
const getTrailerCount = (chPlans) => {
    let count = 0;
    // eslint-disable-next-line no-unused-expressions
    chPlans?.forEach((plan) => {
        if (plan?.trailerId) {
            count += 1;
        }
    });
    return count;
};
const getBillsByTime = (billsByTime, tzCode, olsenTzId) => {
    if (billsByTime) {
        const enableStandardDateTimeFormat = TripSharedService?.getFeatureFlags()?.enableStandardDateTimeFormat;
        const standardDateTimeFormat = TripSharedService.getStandardDateTimeFormat()?.dateTime;
        if (enableStandardDateTimeFormat) {
            return safeDateFormat(billsByTime, standardDateTimeFormat, olsenTzId, tzCode);
        }
        return tzCode && olsenTzId
            ? dateTimeFormatterWithTz(billsByTime, olsenTzId, tzCode)
            : safeDateFormat(billsByTime, DATE_FNS_DATE_TIME_FORMAT);
    }
    return '--';
};
export function getFormattedDt(date, tzCode, olsenTzId) {
    const enableStandardDateTimeFormat = TripSharedService?.getFeatureFlags()?.enableStandardDateTimeFormat;
    const standardDateTimeFormat = TripSharedService.getStandardDateTimeFormat()?.dateTime;
    if (enableStandardDateTimeFormat) {
        return safeDateFormat(date, standardDateTimeFormat, olsenTzId, tzCode);
    }
    return tzCode && olsenTzId
        ? dateTimeFormatterWithTz(date, olsenTzId, tzCode)
        : safeDateFormat(date, DATE_FNS_DATE_TIME_FORMAT);
}

const getLatestComment = (comments, trans) => {
    const comment = comments?.sort((a, b) => {
        return new Date(b?.lastUpdatedTs) - new Date(a?.lastUpdatedTs);
    })?.[0];
    return comment
        ? {
              ...comment,
              commentType: trans(comment?.entityType),
          }
        : undefined;
};

const transformedComments = (comments, planEntity, entityId, trans, timezonesStaticData) => {
    const enableStandardDateTimeFormat = TripSharedService?.getFeatureFlags()?.enableStandardDateTimeFormat;
    const standardDateTimeFormat = TripSharedService.getStandardDateTimeFormat()?.dateTime;

    const getCommentTimeStamp = (date) => {
        if (enableStandardDateTimeFormat) {
            return safeDateFormatLocalTz(date, standardDateTimeFormat, timezonesStaticData);
        }
        return dateTimeFormatterWithTz(date, timeZone);
    };
    return comments?.map((comment) => {
        return {
            ...comment,
            commentByDisplayName: comment?.createdByUserName || comment?.createdByUserId,
            commentTimestamp: getCommentTimeStamp(comment?.createdTs),
            commentBy: comment?.createdByUserId,
            entityType: planEntity,
            tags: [trans(comment?.commentType || '')],
            entityId,
            uniqueId: `${planEntity}-${entityId}-${comment?.commentId}`,
        };
    });
};

const getTripCommentsTransformed = (plan, trans, staticDataTimezones) => {
    return plan?.tripId && !plan.isTrip
        ? transformedComments(plan?.tripComments, trans('label.trip'), plan?.tripId, trans, staticDataTimezones)
        : null;
};

const getPlan = (plan, trans, staticData) => {
    const originOlsenTzId = plan?.originOlsenTimezoneId;
    const originTzCode = getShortTzAbbrFromStaticData(originOlsenTzId, staticData?.shortTimezones);
    const destinationOlsenTzId = plan?.destinationOlsenTimezoneId;
    const destinationTzCode = getShortTzAbbrFromStaticData(destinationOlsenTzId, staticData?.shortTimezones);
    const statusDescObj = planStatusDesc({
        ...plan.statusObj,
        trans,
        tripLtmCoreStatus: plan?.tripLtmCoreStatus,
        driverStatus: plan?.driverStatus,
    });

    const primaryDestinationOlsenTimezoneId = plan?.primaryDestinationOlsenTimezoneId;
    const primaryDestinationTzCode = getShortTzAbbrFromStaticData(
        primaryDestinationOlsenTimezoneId,
        staticData?.shortTimezones,
    );

    return {
        ibob: plan?.ibob,
        onHold: plan?.onHold,
        statusObj: plan.statusObj,
        phase: plan.phase,
        loadLtmCoreStatus: plan.loadLtmCoreStatus,
        carrierStatus: plan.carrierStatus,
        equipmentStatus: plan.equipmentStatus,
        tntStatus: plan.tntStatus,
        uiStatus: plan.uiStatus,
        uiLoadType: plan.uiLoadType,
        uiTripType: plan?.uiTripType,
        editableCards: plan.editableCards,
        editableFields: plan.editableFields,
        statusComments: plan.statusComments,
        actions: plan.actions,
        tripLtmCoreStatus: plan.tripLtmCoreStatus,
        carrierStatusDesc: trans(plan?.carrierStatus?.desc) || statusDescObj?.uiStatusDesc,
        equipmentStatusDesc: trans(plan?.equipmentStatus?.desc),
        driverStatusDesc: trans(plan?.driverStatus?.desc),
        statusDesc: statusDescObj?.statusDesc,
        planType: plan.planType,
        hazmat: plan?.hazmat === true ? trans(OperationalFlagEnum.HAZMAT.name) : '' || '',
        hazmatAbbr:
            plan?.hazmat === true && OperationalFlagEnum?.HAZMAT?.nameAbbr ? trans('plan.flag.hazmat.abbr') : '' || '',
        printed: plan?.printed ? trans(OperationalFlagEnum?.PRINTED?.name) : '' || '',
        printedAbbr:
            plan?.printed && OperationalFlagEnum?.PRINTED?.nameAbbr
                ? trans(OperationalFlagEnum?.PRINTED?.nameAbbr)
                : '' || '',
        planEntity:
            plan.isTrip && plan.planType !== BEPlanCategoryEnum.IM?.code ? trans('label.trip') : trans('label.load'),
        isApproved: plan?.isApproved,
        planId: plan?.planId?.toString() || '',
        isTrip: plan?.isTrip,
        loadCount: plan?.isTrip ? plan.childPlans.length : 0,
        originId: plan?.originId?.toString() || '',
        originName: plan?.originName || '',
        originType: plan?.originType || '',
        originCity: plan?.originCity || '',
        originProvince: plan?.originState || '',
        destinationId: plan?.destinationId?.toString() || '',
        destinationName: plan?.destinationName || '',
        destinationType: plan?.destinationType || '',
        destinationCity: plan?.destinationCity || '',
        destinationProvince: plan?.destinationState || '',
        priDestinationId: plan?.primaryDestinationId?.toString() || '',
        priDestinationName: plan?.primaryDestinationName || '',
        priDestinationType: plan?.primaryDestinationType || '',
        priDestinationCity: plan?.primaryDestinationCity || '',
        priDestinationProvince: plan?.primaryDestinationState || '',
        dwellDays:
            getDiffDaysISO(
                plan?.actualStartTime ? plan?.actualStartTime : new Date().toISOString(),
                plan?.demurrageStartTs ? plan?.demurrageStartTs : '',
            )?.toString() || '--',
        distance: plan?.distanceValue?.toString() ? getRoundedDistance(plan?.distanceValue)?.toString() : '',
        distanceUoM: plan?.distanceUom || '',
        comments: plan?.planComments,
        departureTs: plan?.plannedStartTime
            ? getFormattedDt(plan?.plannedStartTime, originTzCode, originOlsenTzId)
            : '--',
        actualTs: plan?.actualStartTime ? getFormattedDt(plan?.actualStartTime, originTzCode, originOlsenTzId) : '--',
        plannedStartTime: plan?.plannedStartTime,
        actualStartTime: plan?.actualStartTime,
        nextStopId: plan?.nextStop?.nextStopId?.toString() || '',
        nextStopName: plan?.nextStop?.nextStopName || '',
        nextStopType: plan?.nextStop?.nextStopType || '',
        nextStopCity: plan?.nextStop?.nextStopCity || '',
        nextStopProvince: plan?.nextStop?.nextStopState || '',
        planStatus: plan?.planStatus || '',
        numberOfStopsRemaining: plan?.numberOfStopsRemaining?.toString() || '',
        noOfPickupStops: plan?.noOfPickupStops?.toString() || '--',
        noOfDropoffStops: plan?.noOfDeliveryStops?.toString() || '--',
        serviceTerritory: plan?.isTrip ? plan?.serviceTerritory : '-',
        tripServiceTerritory: plan?.tripServiceTerritory || '--',
        planningServiceTerritory:
            !plan?.isTrip || (plan?.isTrip && plan?.planType === BEPlanCategoryEnum.IM?.code)
                ? plan?.planningServiceTerritory || '--'
                : '-',
        driverName: plan?.driverName || '',
        driverId: plan?.isTrip ? plan?.driverId?.toString() || '--' : '-',
        carrierName: plan?.carrierName || '',
        carrierId: isAssignedToCarrier(plan?.carrierStatus?.name) ? plan?.carrierId?.toString() || '--' : '--',
        billsByTime: plan?.isTrip ? getBillsByTime(plan?.billsByTime, originTzCode, originOlsenTzId) : '-',
        duration: plan?.durationValue
            ? getHhmmFromMinutes(plan?.durationValue, {
                  showTwoDigitHrs: true,
              })
            : '00:00',
        trailerId: plan?.trailerId || '--',
        trailerIdOfFirstLoadForTrip:
            plan?.isTrip && plan.childPlans?.[0]?.trailerId ? plan.childPlans?.[0]?.trailerId : '--',
        trailerCountForTrip: plan?.isTrip ? getTrailerCount(plan.childPlans) : '',
        pickupTimeAtOrigin: plan?.pickupTimeAtOrigin,
        endDatePlanned: plan?.endDatePlanned
            ? getFormattedDt(plan?.endDatePlanned, destinationTzCode, destinationOlsenTzId)
            : '--',
        primaryDestinationEndDatePlanned: plan?.primaryDestinationMinDueTs
            ? getFormattedDt(
                  plan?.primaryDestinationMinDueTs,
                  primaryDestinationTzCode,
                  primaryDestinationOlsenTimezoneId,
              )
            : '--',
        priority: !plan?.isTrip ? plan.priority || '--' : '--',
        tripId: plan?.isTrip ? plan?.planId : plan?.tripId,
        loadIds: plan?.childPlans?.map((subPlan) => subPlan?.planId),
        commentsTransformed: transformedComments(
            plan?.planComments,
            plan.isTrip && plan.planType !== BEPlanCategoryEnum.IM?.code ? trans('label.trip') : trans('label.load'),
            plan?.planId,
            trans,
            staticData?.shortTimezones,
        ),
        tripCommentsTransformed: getTripCommentsTransformed(plan, trans, staticData?.shortTimezones),
        mustDepartTime: plan?.maxPickTs ? getFormattedDt(plan?.maxPickTs, originTzCode, originOlsenTzId) : '--',
        routeNumber: plan?.routeNumber || '--',
        isRelayTrip: plan?.isRelayTrip,
    };
};
const getDateSixMonthsAgo = (limit) => {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    const targetMonth = (currentMonth + 12 - (limit || 6)) % 12;
    const targetYear = currentMonth >= (limit || 6) ? currentYear : currentYear - 1;
    const targetDate = new Date(targetYear, targetMonth, 1);
    return targetDate;
};
const getDateSixMonthsFuture = (limit) => {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    const targetMonth = (currentMonth + (limit || 6)) % 12;
    const targetYear = currentMonth <= (limit ? limit - 1 : 5) ? currentYear : currentYear + 1;
    const targetDate = new Date(targetYear, targetMonth, 1);
    return targetDate;
};
export const getDateFromDays = (days) => {
    const today = new Date();
    const pastDate = new Date(today);
    pastDate.setDate(today.getDate() - days);
    const pastTabsTime = moment(new Date(pastDate)).format(timeHorizonDateFormat);
    const futureTabsTime = moment(new Date()).format(timeHorizonDateFormat);
    return [pastTabsTime, futureTabsTime];
};
export const transformDate = (hours, trans, limit) => {
    const currentDateTime = new Date();
    const [startDateStr, endDateStr] = hours.split(' - ');
    const pastTabsTime = startDateStr.includes(TimehorizonUiPhaseEnum.PAST.desc)
        ? moment(new Date(getDateSixMonthsAgo(limit))).format(timeHorizonDateFormat)
        : regexPast.test(startDateStr)
        ? (() => {
              const match = startDateStr.match(regexPast);
              const dayCount = parseInt(match[1], 10);
              return moment(currentDateTime.setDate(currentDateTime.getDate() - dayCount)).format(
                  timeHorizonDateFormat,
              );
          })()
        : moment(new Date(startDateStr)).format(timeHorizonDateFormat);
    const currentDateTimeFuture = new Date();
    const futureTabsTime = endDateStr.includes(TimehorizonUiPhaseEnum.FUTURE.desc)
        ? moment(new Date(getDateSixMonthsFuture(limit))).format(timeHorizonDateFormat)
        : regexFuture.test(endDateStr)
        ? (() => {
              const match = endDateStr.match(regexFuture);
              const dayCount = parseInt(match[1], 10);
              return moment(currentDateTimeFuture.setDate(currentDateTimeFuture.getDate() + dayCount)).format(
                  timeHorizonDateFormat,
              );
          })()
        : moment(new Date(endDateStr)).format(timeHorizonDateFormat);
    return `${new Date(pastTabsTime).toLocaleDateString(trans('type.encoding'), optionsDateTransform)} - ${new Date(
        futureTabsTime,
    ).toLocaleDateString(trans('type.encoding'), optionsDateTransform)}`;
};
export const doesMatchPreferences = (obj, obj2) =>
    obj2.some((item) => item.preferences === obj.preferences || item.name === obj.preferences);
export const transformUSPlanPreviewData = (plan, trans, staticData) => {
    const planDataTransformed = getPlan(plan, trans, staticData);
    const combinedComments = [...(planDataTransformed?.commentsTransformed || [])];
    if (!planDataTransformed?.isTrip) {
        combinedComments.push(...(planDataTransformed?.tripCommentsTransformed || []));
    }
    const plans = plan?.childPlans
        ? plan.childPlans.map((load) => {
              const childPlanTransformed = getPlan(load, trans, staticData);
              return {
                  ...childPlanTransformed,
                  combinedComments: [...(childPlanTransformed?.commentsTransformed || []), ...combinedComments],
                  latestComment: getLatestComment(childPlanTransformed?.commentsTransformed, trans),
              };
          })
        : [];
    plans?.forEach((childPlan) => {
        if (childPlan?.commentsTransformed?.length) {
            combinedComments.push(...childPlan?.commentsTransformed);
        }
    });
    const planUpdated = {
        ...planDataTransformed,
        combinedComments,
        plans,
        latestComment: getLatestComment(
            plan.isTrip ? combinedComments : planDataTransformed?.commentsTransformed,
            trans,
        ),
    };
    return planUpdated;
};
export const transformOptionsTimeHorizon = (horizons, trans, limit) =>
    horizons.map((item) => {
        if (item.timeHorizonType === trans('label.timehorizon.selection')) {
            const dateVal = `${trans('label.basic.past')} ${
                item.pastDays === trans('label.timehorizon.past') ? trans('label.basic.all') : item.pastDays
            } ${trans('label.basic.futureDays')} ${
                item.futureDays === trans('label.timehorizon.future') ? trans('label.basic.all') : item.futureDays
            } ${trans('label.basic.days')}`;
            return {
                name: dateVal,
                preferences: transformDate(dateVal, trans, limit),
            };
        }
        return {
            name: `${new Date(item.startDate).toLocaleDateString(
                trans('type.encoding'),
                optionsDateTransform,
            )} - ${new Date(item.endDate).toLocaleDateString(trans('type.encoding'), optionsDateTransform)}`,
            preferences: '',
        };
    });
export const transformOptionsProfiles = (profiles) =>
    profiles.map((item) => ({
        name: item.name,
        preferences: item.preferences,
        key: item.key,
    }));
export const getFilteredColumnHeadersUS = (tabIndex, trans, cmsConfig, featureFlags, groupBy) => {
    let headerCells = planTableHeadCellsUS(trans, cmsConfig, groupBy);
    let commonHeaderCells = commonColumnHeaders(cmsConfig);
    if (!featureFlags?.showCommentsColumn) {
        headerCells = headerCells.filter((obj) => obj?.id !== comments);
    }
    if (!featureFlags?.showPrimaryDestinationCol) {
        headerCells = headerCells.filter((obj) => obj?.id !== priDestinationColumnId);
    }
    if (!featureFlags?.showDwellDays) {
        headerCells = headerCells.filter((obj) => obj?.id !== dwellDaysColumnId);
    }
    if (!featureFlags?.showServiceTerritory) {
        const columnIds = [tripServiceTerritoryColumnId, planningServiceTerritoryColumnId];
        commonHeaderCells = commonHeaderCells.filter((obj) => !columnIds.includes(obj?.id));
    }
    if (featureFlags?.showServiceTerritory) {
        commonHeaderCells = commonHeaderCells.filter((obj) => obj?.id !== serviceTerritoryColumnId);
    }
    if (!featureFlags?.showTagsCol) {
        headerCells = headerCells.filter((obj) => obj?.id !== tagsId);
    }
    if (tabIndex === PhaseTypesEnum.PLANNING.index) {
        headerCells.splice(3, 0, ...commonHeaderCells);
        return headerCells.filter((header) => !excludedColumnsForPlanning.includes(header.id));
    }
    if (tabIndex === PhaseTypesEnum.PROCESSING.index) {
        headerCells.splice(3, 0, ...commonHeaderCells);
        return headerCells.filter((header) => !excludedColumnsForProcessing.includes(header.id));
    }
    if (tabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) {
        let startIndex = 13;
        if (featureFlags?.showDwellDays) {
            startIndex += 1;
        }
        if (featureFlags?.showTagsCol) {
            startIndex += 1;
        }
        headerCells.splice(startIndex, 0, ...commonHeaderCells);
        return headerCells.filter((header) => !excludedColumnsForReadyToStart.includes(header.id));
    }
    if (tabIndex === PhaseTypesEnum.IN_TRANSIT.index) {
        let startIndex = 16;
        if (featureFlags?.showPrimaryDestinationCol) {
            startIndex += 1;
        }
        if (featureFlags?.showDwellDays) {
            startIndex += 1;
        }
        if (featureFlags?.showTagsCol) {
            startIndex += 1;
        }
        headerCells.splice(startIndex, 0, ...commonHeaderCells);
        return headerCells.filter((header) => !excludedColumnsForIntransit.includes(header.id));
    }
    if (tabIndex === PhaseTypesEnum.DELIVERED.index) {
        let startIndex = 10;
        if (featureFlags?.showPrimaryDestinationCol) {
            startIndex += 1;
        }
        if (featureFlags?.showDwellDays) {
            startIndex += 1;
        }
        if (featureFlags?.showTagsCol) {
            startIndex += 1;
        }
        headerCells.splice(startIndex, 0, ...commonHeaderCells);
        return headerCells.filter((header) => !excludedColumnsForDelivered.includes(header.id));
    }
    return planTableHeadCellsUS;
};
export const transformLoadsToEditTailer = (data) => {
    const loads = data.map((load) => ({
        loadId: load?.planId,
        loadType: load?.ibob,
        originId: load?.originId,
        originValue: load?.originName,
        originType: load?.originType,
        originTypeToIcon: getLocationTypeToIconMap(load?.originType),
        destinationId: load?.destinationId,
        destinationValue: load?.destinationName,
        destinationType: load?.destinationType,
        destinationTypeToIcon: getLocationTypeToIconMap(load?.destinationType),
        trailerId: load?.trailerId !== '--' ? load?.trailerId : '',
    }));
    return loads;
};
export const deliveryPhaseSecText = (queryState, trans) =>
    TripSharedService.getFeatureFlags()?.showTimeHorizonV2
        ? `${trans('label.basic.past')} ${queryState.timeHorizon.dayCount} days`
        : `${trans('timehorizon.label.horizonLast')} ${defaultTimeHorizon} hrs`;

export const formatApproveTripRequest = (tripIds) => ({
    payload: {
        planIds: tripIds,
    },
});
export const formatForceToDeleverTripRequest = (params) => {
    const payload = {
        trackingId: params.trackingId,
        trackingIdType: params.trackingIdType,
    };
    const plans = [];
    params.plans.forEach((sData) => {
        const existing = plans.filter((plan) => plan.planSequenceNumber === sData.planSequenceNumber);
        const transit = {
            actual: sData?.actual,
            reasonCodes: sData?.reasonCodes,
            stopId: sData?.stopId,
            stopSeqNumber: sData?.stopSeqNumber,
            stopType: sData?.stopType,
        };
        if (existing.length) {
            const existingIndex = plans.indexOf(existing[0]);
            plans[existingIndex].transits.push(transit);
        } else {
            plans.push({
                planSequenceNumber: sData.planSequenceNumber,
                trackingId: sData.trackingId,
                trackingIdType: sData.trackingIdType,
                transits: [transit],
            });
        }
    });
    return {
        ...payload,
        plans,
    };
};
export const canAdjustcolumnForCheckbox = (index, drayIntroColumns) => !!drayIntroColumns;
// Todo: for R1 hiding checkboxes as there are no actions to take. Making as false for R1.
// index === PhaseTypesEnum.PLANNING.index
// || index === PhaseTypesEnum.PROCESSING.index
// || index === PhaseTypesEnum.READY_TO_START.index;

export const canAdjustcolumnForActions = (index, drayIntroColumns) => {
    if (drayIntroColumns) return true;
    if (!drayIntroColumns && index === PhaseTypesEnum.IN_TRANSIT.index) return true;
    return false;
};
export const canAdjustcolumnForTags = (tagsIntroColumns) => {
    if (tagsIntroColumns) return true;
    return false;
};
export const tranformFilterCriteriaToChips = (filterData) => {
    const filterChipsArr = [];
    if (filterData) {
        Object.keys(filterData).forEach((property) => {
            if (
                (filterData[property] && !Array.isArray(filterData[property])) ||
                (Array.isArray(filterData[property]) && filterData[property]?.length > 0)
            ) {
                filterChipsArr.push({
                    field: property,
                    value: filterData[property],
                    label: `label.${property}`,
                });
            }
        });
    }
    return filterChipsArr;
};
export const updateQueryStateWithChipsData = (filterData, chip) => {
    if (filterData[chip?.field]) {
        if (Array.isArray(filterData[chip?.field])) {
            return {
                ...filterData,
                [chip?.field]: [],
            };
        }
        return {
            ...filterData,
            [chip?.field]: '',
        };
    }
    return {
        ...filterData,
    };
};

// eslint-disable-next-line no-unused-vars
export const getLocationLabels = (trans, staticData) => {
    // TODO: use staticData for options
    const originDetails = {
        locationType: {
            id: 'originType',
            label: trans('label.locationType'),
            value: 'LT1',
            fieldSize: '3',
            options: [
                {
                    id: 'DC',
                    value: 'DC',
                },
                {
                    id: 'SPLR',
                    value: 'SPLR',
                },
            ],
        },
        locationId: {
            id: 'originId',
            label: trans('label.locationId'),
            value: '',
            fieldSize: '6',
            helperText: trans('multiInputHelperText'),
            plankeyRegex: new RegExp(/^[0-9]*([ ,\t\n][0-9]+)*$/),
            planIdError: trans('multiInputError'),
        },
        locationCity: {
            id: 'originCity',
            label: trans('label.city'),
            value: '',
            fieldSize: '3',
        },
        locationState: {
            id: 'originState',
            label: trans('label.state'),
            value: '',
            fieldSize: '3',
            options: [
                {
                    id: 'S1',
                    value: 'State1',
                },
                {
                    id: 'S2',
                    value: 'State2',
                },
            ],
        },
        locationCounty: {
            id: 'originCountry',
            label: trans('label.country'),
            value: '',
            fieldSize: '3',
            options: [
                {
                    id: 'C1',
                    value: 'County1',
                },
                {
                    id: 'C2',
                    value: 'County2',
                },
            ],
        },
        locationPostalCode: {
            id: 'originZipCode',
            label: trans('label.zipCode'),
            value: '',
            fieldSize: '3',
        },
    };
    const destinationDetails = {
        locationType: {
            id: 'destinationType',
            label: trans('label.locationType'),
            value: '',
            fieldSize: '3',
            options: [
                {
                    id: 'DC',
                    value: 'DC',
                },
                {
                    id: 'SPLR',
                    value: 'SPLR',
                },
            ],
        },
        locationId: {
            id: 'destinationId',
            label: trans('label.locationId'),
            value: '',
            fieldSize: '6',
            helperText: trans('multiInputHelperText'),
            plankeyRegex: new RegExp(/^[0-9]*([ ,\t\n][0-9]+)*$/),
            planIdError: trans('multiInputError'),
        },
        locationCity: {
            id: 'destinationCity',
            label: trans('label.city'),
            value: '',
            fieldSize: '3',
        },
        locationState: {
            id: 'destinationState',
            label: trans('label.state'),
            value: '',
            fieldSize: '3',
            options: [
                {
                    id: 'S1',
                    value: 'State1',
                },
                {
                    id: 'S2',
                    value: 'State2',
                },
            ],
        },
        locationCounty: {
            id: 'destinationCountry',
            label: trans('label.country'),
            value: '',
            fieldSize: '3',
            options: [
                {
                    id: 'C1',
                    value: 'County1',
                },
                {
                    id: 'C2',
                    value: 'County2',
                },
            ],
        },
        locationPostalCode: {
            id: 'destinationZipCode',
            label: trans('label.zipCode'),
            value: '',
            fieldSize: '3',
        },
    };
    return {
        originDetails,
        destinationDetails,
    };
};
export const equipmentStaticDataTransformer = (err, res) => {
    let data = [];
    if (err) {
        return {
            error: 'Error while fetching the data',
        };
    }

    // TODO: filter only trailer data and check the id, value mappings with BE team
    if (res?.static_data?.equipments) {
        data = res.static_data.equipments.map((equipment) => ({
            id: equipment.mdm_equipment_id,
            value: equipment.equipment_id,
        }));
    }
    return {
        data,
    };
};
export const getInvalidLocationsBasedonProfile = (profile, locationId, locationType) => {
    const invalidLocations = [];
    const locationIds = locationId.split(/[ ,]+/);
    if (locationIds?.length) {
        const profileLocationIds = [];
        if (profile?.preferences?.length) {
            profile.preferences.forEach((item) => {
                if (item?.parameter === locationType) {
                    profileLocationIds.push(item?.values[0]?.value);
                }
            });
        }
        locationIds.forEach((id) => {
            if (profileLocationIds?.length && !profileLocationIds.includes(id)) {
                invalidLocations.push(id);
            }
        });
    }
    return invalidLocations;
};
export const planningColumnsToExportUS = (trans, UOM, featureFlags) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    ...(featureFlags?.showTagsCol ? [{ key: 'hazmatAbbr', header: trans('planExportColumn.tags') }] : []),
    {
        key: 'planEntity',
        header: trans('planExportColumn.planEntity'),
    },
    {
        key: 'planType',
        header: trans('planExportColumn.planType'),
    },
    {
        key: 'trailerId',
        header: trans('planExportColumn.drayEquipmentID'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'distance',
        header: `${trans('planExportColumn.distance')} (${UOM?.distance})`,
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    { key: 'priDestinationId', header: trans('planExportColumn.priDestinationId') },
    { key: 'priDestinationType', header: trans('planExportColumn.priDestinationType') },
    { key: 'priDestinationName', header: trans('planExportColumn.priDestinationName') },
    { key: 'priDestinationCity', header: trans('planExportColumn.priDestinationCity') },
    { key: 'priDestinationProvince', header: trans('planExportColumn.priDestinationProvince') },
    ...(featureFlags?.showDwellDays ? [{ key: 'dwellDays', header: trans('planExportColumn.dwellDays') }] : []),
    {
        key: 'priority',
        header: trans('planExportColumn.priority'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumns.drayPlannedStart'),
    },
    {
        key: 'endDatePlanned',
        header: trans('planExportColumns.plannedEnd'),
    },
    {
        key: 'duration',
        header: `${trans('planExportColumn.duration')} (${UOM?.duration})`,
    },
    {
        key: 'noOfPickupStops',
        header: trans('planExportColumn.pickupStops'),
    },
    {
        key: 'noOfDropoffStops',
        header: trans('planExportColumn.deliveryStops'),
    },
    ...(featureFlags?.showRouteNumberColumn
        ? [
              {
                  key: 'routeNumber',
                  header: trans('planColumns.routeNumber'),
              },
          ]
        : []),
    {
        key: 'statusDesc',
        header: trans('planExportColumn.planStatusLabel'),
    },
];
export const processingColumnsToExportUS = (trans, UOM, featureFlags) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    ...(featureFlags?.showTagsCol
        ? [
              { key: 'hazmatAbbr', header: trans('planExportColumn.tags') },
              { key: 'printedAbbr', header: trans('planExportColumn.tags') },
          ]
        : []),
    {
        key: 'planEntity',
        header: trans('planExportColumn.planEntity'),
    },
    {
        key: 'planType',
        header: trans('planExportColumn.planType'),
    },
    {
        key: 'carrierId',
        header: trans('planExportColumn.carrier'),
    },
    ...(!featureFlags?.showServiceTerritory
        ? [{ key: 'serviceTerritory', header: trans('planExportColumn.serviceTerritory') }]
        : []),
    ...(featureFlags?.showServiceTerritory
        ? [
              { key: 'tripServiceTerritory', header: trans('planExportColumn.tripServiceTerritory') },
              { key: 'planningServiceTerritory', header: trans('planExportColumn.planningServiceTerritory') },
          ]
        : []),
    {
        key: 'trailerId',
        header: trans('planExportColumn.drayEquipmentID'),
    },
    {
        key: 'driverId',
        header: trans('planExportColumn.driverId'),
    },
    {
        key: 'driverName',
        header: trans('planExportColumn.driverName'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'distance',
        header: `${trans('planExportColumn.distance')} (${UOM?.distance})`,
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    { key: 'priDestinationId', header: trans('planExportColumn.priDestinationId') },
    { key: 'priDestinationType', header: trans('planExportColumn.priDestinationType') },
    { key: 'priDestinationName', header: trans('planExportColumn.priDestinationName') },
    { key: 'priDestinationCity', header: trans('planExportColumn.priDestinationCity') },
    { key: 'priDestinationProvince', header: trans('planExportColumn.priDestinationProvince') },
    ...(featureFlags?.showDwellDays ? [{ key: 'dwellDays', header: trans('planExportColumn.dwellDays') }] : []),
    {
        key: 'priority',
        header: trans('planExportColumn.priority'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumns.drayPlannedStart'),
    },
    {
        key: 'primaryDestinationEndDatePlanned',
        header: trans('planColumns.primaryDestinationPlannedEnd'),
    },
    {
        key: 'endDatePlanned',
        header: trans('planExportColumns.plannedEnd'),
    },
    {
        key: 'duration',
        header: `${trans('planExportColumn.duration')} (${UOM?.duration})`,
    },
    {
        key: 'billsByTime',
        header: trans('planExportColumn.billsByTime'),
    },
    {
        key: 'noOfPickupStops',
        header: trans('planExportColumn.pickupStops'),
    },
    {
        key: 'noOfDropoffStops',
        header: trans('planExportColumn.deliveryStops'),
    },
    {
        key: 'carrierStatusDesc',
        header: trans('planExportColumn.carrierStatus'),
    },
    {
        key: 'equipmentStatusDesc',
        header: trans('planExportColumn.trailerStatus'),
    },
    {
        key: 'driverStatusDesc',
        header: trans('planExportColumn.driverStatus'),
    },
    ...(featureFlags?.showRouteNumberColumn
        ? [
              {
                  key: 'routeNumber',
                  header: trans('planColumns.routeNumber'),
              },
          ]
        : []),
];
export const readyToStartColumnsToExportUS = (trans, UOM, featureFlags) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    ...(featureFlags?.showTagsCol ? [{ key: 'hazmatAbbr', header: trans('planExportColumn.tags') }] : []),
    {
        key: 'planEntity',
        header: trans('planExportColumn.planEntity'),
    },
    {
        key: 'planType',
        header: trans('planExportColumn.planType'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'distance',
        header: `${trans('planExportColumn.distance')} (${UOM?.distance})`,
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    { key: 'priDestinationId', header: trans('planExportColumn.priDestinationId') },
    { key: 'priDestinationType', header: trans('planExportColumn.priDestinationType') },
    { key: 'priDestinationName', header: trans('planExportColumn.priDestinationName') },
    { key: 'priDestinationCity', header: trans('planExportColumn.priDestinationCity') },
    { key: 'priDestinationProvince', header: trans('planExportColumn.priDestinationProvince') },
    ...(featureFlags?.showDwellDays ? [{ key: 'dwellDays', header: trans('planExportColumn.dwellDays') }] : []),
    {
        key: 'priority',
        header: trans('planExportColumn.priority'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumns.drayPlannedStart'),
    },
    {
        key: 'endDatePlanned',
        header: trans('planExportColumns.plannedEnd'),
    },
    {
        key: 'duration',
        header: `${trans('planExportColumn.duration')} (${UOM?.duration})`,
    },
    {
        key: 'carrierId',
        header: trans('planExportColumn.carrier'),
    },
    ...(!featureFlags?.showServiceTerritory
        ? [{ key: 'serviceTerritory', header: trans('planExportColumn.serviceTerritory') }]
        : []),
    ...(featureFlags?.showServiceTerritory
        ? [
              { key: 'tripServiceTerritory', header: trans('planExportColumn.tripServiceTerritory') },
              { key: 'planningServiceTerritory', header: trans('planExportColumn.planningServiceTerritory') },
          ]
        : []),
    {
        key: 'trailerId',
        header: trans('planExportColumn.drayEquipmentID'),
    },
    {
        key: 'driverId',
        header: trans('planExportColumn.driverId'),
    },
    {
        key: 'driverName',
        header: trans('planExportColumn.driverName'),
    },
    {
        key: 'billsByTime',
        header: trans('planExportColumn.billsByTime'),
    },
    {
        key: 'noOfPickupStops',
        header: trans('planExportColumn.pickupStops'),
    },
    {
        key: 'noOfDropoffStops',
        header: trans('planExportColumn.deliveryStops'),
    },
    ...(featureFlags?.showRouteNumberColumn
        ? [
              {
                  key: 'routeNumber',
                  header: trans('planColumns.routeNumber'),
              },
          ]
        : []),
    {
        key: 'statusDesc',
        header: trans('planExportColumn.planStatusLabel'),
    },
];
export const inTransitColumnsToExportUS = (trans, UOM, featureFlags) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    ...(featureFlags?.showTagsCol ? [{ key: 'hazmatAbbr', header: trans('planExportColumn.tags') }] : []),
    {
        key: 'planEntity',
        header: trans('planExportColumn.planEntity'),
    },
    {
        key: 'planType',
        header: trans('planExportColumn.planType'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'distance',
        header: `${trans('planExportColumn.distance')} (${UOM?.distance})`,
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    { key: 'priDestinationId', header: trans('planExportColumn.priDestinationId') },
    { key: 'priDestinationType', header: trans('planExportColumn.priDestinationType') },
    { key: 'priDestinationName', header: trans('planExportColumn.priDestinationName') },
    { key: 'priDestinationCity', header: trans('planExportColumn.priDestinationCity') },
    { key: 'priDestinationProvince', header: trans('planExportColumn.priDestinationProvince') },
    {
        key: 'priority',
        header: trans('planExportColumn.priority'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumns.drayPlannedStart'),
    },
    {
        key: 'actualTs',
        header: trans('planExportColumn.actualStartTime'),
    },
    {
        key: 'endDatePlanned',
        header: trans('planExportColumns.plannedEnd'),
    },
    {
        key: 'EndDateEstimated',
        header: trans('planExportColumns.EndDateEstimated'),
    },
    {
        key: 'duration',
        header: `${trans('planExportColumn.duration')} (${UOM?.duration})`,
    },
    {
        key: 'nextStopId',
        header: trans('planExportColumn.nextStopId'),
    },
    {
        key: 'nextStopType',
        header: trans('planExportColumn.nextStopType'),
    },
    {
        key: 'nextStopName',
        header: trans('planExportColumn.nextStopName'),
    },
    {
        key: 'nextStopCity',
        header: trans('planExportColumn.nextStopCity'),
    },
    {
        key: 'nextStopProvince',
        header: trans('planExportColumn.nextStopProvince'),
    },
    {
        key: 'numberOfStopsRemaining',
        header: trans('planExportColumn.numberOfStopsRemaining'),
    },
    {
        key: 'carrierId',
        header: trans('planExportColumn.carrier'),
    },
    ...(!featureFlags?.showServiceTerritory
        ? [{ key: 'serviceTerritory', header: trans('planExportColumn.serviceTerritory') }]
        : []),
    ...(featureFlags?.showServiceTerritory
        ? [
              { key: 'tripServiceTerritory', header: trans('planExportColumn.tripServiceTerritory') },
              { key: 'planningServiceTerritory', header: trans('planExportColumn.planningServiceTerritory') },
          ]
        : []),
    {
        key: 'trailerId',
        header: trans('planExportColumn.drayEquipmentID'),
    },
    {
        key: 'driverId',
        header: trans('planExportColumn.driverId'),
    },
    {
        key: 'driverName',
        header: trans('planExportColumn.driverName'),
    },
    {
        key: 'billsByTime',
        header: trans('planExportColumn.billsByTime'),
    },
    {
        key: 'noOfPickupStops',
        header: trans('planExportColumn.pickupStops'),
    },
    {
        key: 'noOfDropoffStops',
        header: trans('planExportColumn.deliveryStops'),
    },
    ...(featureFlags?.showRouteNumberColumn
        ? [
              {
                  key: 'routeNumber',
                  header: trans('planColumns.routeNumber'),
              },
          ]
        : []),
    {
        key: 'statusDesc',
        header: trans('planExportColumn.planStatusLabel'),
    },
];
export const deliveredColumnsToExportUS = (trans, UOM, featureFlags) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    ...(featureFlags?.showTagsCol ? [{ key: 'hazmatAbbr', header: trans('planExportColumn.tags') }] : []),
    {
        key: 'planEntity',
        header: trans('planExportColumn.planEntity'),
    },
    {
        key: 'planType',
        header: trans('planExportColumn.planType'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'distance',
        header: `${trans('planExportColumn.distance')} (${UOM?.distance})`,
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    { key: 'priDestinationId', header: trans('planExportColumn.priDestinationId') },
    { key: 'priDestinationType', header: trans('planExportColumn.priDestinationType') },
    { key: 'priDestinationName', header: trans('planExportColumn.priDestinationName') },
    { key: 'priDestinationCity', header: trans('planExportColumn.priDestinationCity') },
    { key: 'priDestinationProvince', header: trans('planExportColumn.priDestinationProvince') },
    {
        key: 'priority',
        header: trans('planExportColumn.priority'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumns.drayPlannedStart'),
    },
    {
        key: 'actualTs',
        header: trans('planExportColumn.actualStartTime'),
    },
    {
        key: 'endDatePlanned',
        header: trans('planExportColumns.plannedEnd'),
    },
    {
        key: 'actualEndDate',
        header: trans('planExportColumns.actualEndDate'),
    },
    {
        key: 'duration',
        header: `${trans('planExportColumn.duration')} (${UOM?.duration})`,
    },
    {
        key: 'carrierId',
        header: trans('planExportColumn.carrier'),
    },
    ...(!featureFlags?.showServiceTerritory
        ? [{ key: 'serviceTerritory', header: trans('planExportColumn.serviceTerritory') }]
        : []),
    ...(featureFlags?.showServiceTerritory
        ? [
              { key: 'tripServiceTerritory', header: trans('planExportColumn.tripServiceTerritory') },
              { key: 'planningServiceTerritory', header: trans('planExportColumn.planningServiceTerritory') },
          ]
        : []),
    {
        key: 'trailerId',
        header: trans('planExportColumn.drayEquipmentID'),
    },
    {
        key: 'driverId',
        header: trans('planExportColumn.driverId'),
    },
    {
        key: 'driverName',
        header: trans('planExportColumn.driverName'),
    },
    {
        key: 'billsByTime',
        header: trans('planExportColumn.billsByTime'),
    },
    {
        key: 'noOfPickupStops',
        header: trans('planExportColumn.pickupStops'),
    },
    {
        key: 'noOfDropoffStops',
        header: trans('planExportColumn.deliveryStops'),
    },
    ...(featureFlags?.showRouteNumberColumn
        ? [
              {
                  key: 'routeNumber',
                  header: trans('planColumns.routeNumber'),
              },
          ]
        : []),
    {
        key: 'statusDesc',
        header: trans('planExportColumn.planStatusLabel'),
    },
];
export const groupByList = [
    {
        id: 'TRIP',
        value: 'groupby.trips',
    },
    {
        id: 'LOAD',
        value: 'groupby.loads',
    },
    {
        id: 'INTERMODAL',
        value: 'groupby.intermodal',
    },
];
export const enableRowExpansion = (rowData, queryState) => {
    if (queryState.groupBy !== groupByList[2].id && !queryState.globalSearchData) {
        if (rowData.planType === BEPlanCategoryEnum.IM?.code) {
            return false;
        }
        return true;
    }
    if (queryState.groupBy === groupByList[2].id && !queryState.globalSearchData) {
        return true;
    }
    return false;
};

export const TABLE_ACTIONS_ENUM = {
    MANAGE_COLUMNS: { name: 'MANAGE_COLUMNS', desc: 'tableActions.label.manageColumns' },
};

export const getTableActions = (featureFlags, trans) => {
    const actions = [];

    if (featureFlags?.enableManageColumns) {
        const action = TABLE_ACTIONS_ENUM.MANAGE_COLUMNS;
        actions.push({ ...action, desc: trans(action.desc) });
    }

    return actions;
};

export const getPlanListWithUpdatedComments = (originalPlanList, commentsDrawerInput, commentsDrawerOutput) => {
    const planList = [...originalPlanList];
    let planSelected = planList?.find(
        (plan) =>
            plan?.planId === Number(commentsDrawerInput?.pSelectedPlan?.planId) &&
            plan?.planEntity === commentsDrawerInput?.pSelectedPlan?.planType?.toUpperCase(),
    );
    if (!planSelected) {
        planSelected = planList?.find(
            (plan) =>
                plan?.planId === Number(commentsDrawerInput?.pSelectedPlan?.tripId) &&
                plan?.planEntity === EntityTypeEnum.TRIP.desc.toUpperCase(),
        );
    }
    if (planSelected) {
        const comments = commentsDrawerOutput?.comments?.filter(
            (comment) =>
                Number(comment?.entityId) === Number(planSelected?.planId) &&
                planSelected?.planEntity === comment?.entityType?.toUpperCase(),
        );
        planSelected.planComments = comments;

        if (planSelected?.planEntity === EntityTypeEnum.LOAD.desc.toUpperCase()) {
            const tripComments = commentsDrawerOutput?.comments?.filter(
                (comment) =>
                    Number(comment?.entityId) === Number(planSelected?.tripId) &&
                    EntityTypeEnum.TRIP.desc.toUpperCase() === comment?.entityType?.toUpperCase(),
            );
            planSelected.tripComments = tripComments;
        }

        planSelected?.childPlans?.forEach((childPlan) => {
            const childPlanComments = commentsDrawerOutput?.comments?.filter(
                (comment) =>
                    Number(comment?.entityId) === Number(childPlan?.planId) &&
                    childPlan?.planEntity === comment?.entityType?.toUpperCase(),
            );
            if (
                commentsDrawerInput?.pLoadIds?.includes(childPlan?.planId) ||
                Number(commentsDrawerInput?.pSelectedPlan?.planId) === childPlan?.planId
            ) {
                childPlan.planComments = childPlanComments;
            }
        });
    }

    return planList?.map((plan) => (plan?.planId === planSelected?.planId ? planSelected : plan));
};
