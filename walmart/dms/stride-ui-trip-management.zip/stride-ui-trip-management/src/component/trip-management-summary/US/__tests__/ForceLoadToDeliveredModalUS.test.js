import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ForceLoadToDeliveredModalUS from '../ForceLoadToDeliveredModalUS';
import { render } from '../../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { tripDetailsUs } from './mocks/TripDetailsUS.mock';
import { contextMockUS } from '../../../../service/__tests__/mocks/mocks/TripMapper.mock';
import TripSharedService from '../../../../service/TripSharedService';

const spy = jest.spyOn(AppUtils, 'get');

const mockFn = jest.fn();
const staticData = {
    los: [
        {
            id: 1,
        },
    ],
};
const API_GATEWAY_PREFIX = '/api/gateway/v4/stride-ui-trip-management';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX}-tripDetails/tripDetails`, (req, res, ctx) => res(ctx.json(tripDetailsUs))),
    rest.post(`${API_GATEWAY_PREFIX}-fetchStaticData/fetchStaticData`, (req, res, ctx) => res(ctx.json(staticData))),
);

describe('Force Load to Delivered Modal test', () => {
    beforeAll(() => {
        spy.mockImplementation(() => contextMockUS);
        server.listen();
    });

    it('should render without crashing', async () => {
        await TripSharedService.setFeatureFlags({ showUpdateTimeline: true, showArrivalDepartureLosToggle: true });
        const wrapper = render(
            <ForceLoadToDeliveredModalUS
                pOpenModal
                pOnCloseModal={mockFn}
                pPlanId={500000639}
                pSuccess={mockFn}
                pLoading={mockFn}
                pError={mockFn}
                pStaticData={{ planId: 1 }}
            />,
        );
        const container = await wrapper.findByTestId('ld-sc-ui--modal-content');
        expect(container).toBeDefined();
        expect(wrapper.queryAllByText('Update Timeline')).toBeDefined();
        expect(wrapper.queryAllByText('Actual arrival time')).toBeDefined();
        expect(wrapper.queryAllByText('Actual departure time')).toBeDefined();
        expect(wrapper.queryAllByText('Los Event')).toBeDefined();
        expect(wrapper.queryAllByText('Cancel')).toBeDefined();
        expect(wrapper.queryAllByText('Confirm')).toBeDefined();
        expect(wrapper.queryAllByText('Arrival & Departure')).toBeDefined();
    });
});
