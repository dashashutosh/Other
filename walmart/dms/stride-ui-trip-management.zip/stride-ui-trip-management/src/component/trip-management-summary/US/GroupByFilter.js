import React, { useCallback } from 'react';
import PropTypes from 'prop-types';
import { Scope } from '@walmart/living-design-sc-ui';
import { groupByList } from './DataModelsUS';
import { QueryStateType } from '../../../utils/types/PlanSearchTypes';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const styles = makeStyles({
    scope: {
        '& .ld-sc-ui-select.ld-sc-ui-select-default.ld-sc-ui-hover': {
            minWidth: '0px !important',
            marginTop: '6px',
        },
        paddingTop: 7,
    },
});
export function GroupByFilter(props) {
    const { pOnChange, pVariant, queryState } = props;
    const classes = styles();
    const trans = localizeLang();
    const handleOnChange = useCallback((e) => {
        const value = e.target.getAttribute('value');
        pOnChange(value);
    }, []);
    return (
        <div className={classes.scope}>
            <Scope
                label={trans('groupby.label')}
                list={groupByList.map((item) => ({
                    ...item,
                    value: trans(item.value),
                }))}
                onChangeSingleSelectValue={(e) => {
                    handleOnChange(e);
                }}
                scopealign="left-align"
                singleSelectValue={queryState?.groupBy || groupByList[0].id}
                singleSelectVariant={pVariant}
                variant="single-select"
                data-testid="group-by"
            />
        </div>
    );
}
export default GroupByFilter;
GroupByFilter.propTypes = {
    pOnChange: PropTypes.func.isRequired,
    pVariant: PropTypes.string,
    queryState: QueryStateType.isRequired,
};
GroupByFilter.defaultProps = {
    pVariant: 'default',
};
