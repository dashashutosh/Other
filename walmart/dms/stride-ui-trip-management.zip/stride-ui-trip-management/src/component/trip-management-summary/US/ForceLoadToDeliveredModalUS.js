import React, { useState, useEffect, useMemo } from 'react';
import { useAPI, ForceToDelivered, PlanPhaseEnum, TripActionsEnum } from '@walmart/stride-ui-commons';
import PropTypes from 'prop-types';
import { TripAPI } from '../../../service/TripAPI';
import { getTripDetails } from '../../../utils/ui-mappers/US/TripDetailsMapper';
import usePlanActionsApiUS from '../../../hooks/usePlanActionsApiUS';
import TripSharedService from '../../../service/TripSharedService';

/**
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;
const ForceLoadToDeliveredModalUS = ({
    pOpenModal,
    pPlanId,
    pError,
    pOnCloseModal,
    pLoading,
    pSuccess,
    pStaticData,
}) => {
    const { prefLang, currentMarket, userInfo } = AppUtils.get();
    const trans = localizeLang();
    const [sTripDetailsResponse, setsTripDetailsResponse] = useState();
    const [sLosEvent, setsLOSEvents] = useState();
    const { handlePlanAction } = usePlanActionsApiUS();
    const { callAPI: fetchTripDetails, ...fetchTripDetailsResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getTripDetails,
    );
    const { callAPI: fetchStaticDataAPI, ...fetchStaticDataResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).fetchStaticData,
    );
    const featureFlags = TripSharedService.getFeatureFlags();

    useEffect(() => {
        const isLoading = fetchStaticDataResponse.loading || fetchTripDetailsResponse.loading;
        pLoading(isLoading);
    }, [fetchStaticDataResponse.loading, fetchTripDetailsResponse.loading]);
    useEffect(() => {
        if (fetchTripDetailsResponse.response?.payload) {
            setsTripDetailsResponse(fetchTripDetailsResponse.response.payload);
        }
    }, [fetchTripDetailsResponse.response]);
    useEffect(() => {
        if (fetchStaticDataResponse.response?.los) {
            setsLOSEvents(fetchStaticDataResponse.response?.los);
        }
    }, [fetchStaticDataResponse.response]);
    useEffect(() => {
        if (!pOpenModal) {
            return;
        }
        fetchStaticDataAPI();
        if (pPlanId) {
            fetchTripDetails(pPlanId);
        }
    }, [pOpenModal, pPlanId]);
    const tripDetails = useMemo(
        () => (sTripDetailsResponse ? getTripDetails(sTripDetailsResponse, trans, pStaticData) : null),
        [sTripDetailsResponse, pStaticData, trans],
    );
    const forceLoadToDeliverModalTranslations = useMemo(() => {
        const forceDeliTrans = {
            arrivalLabel: trans('forceToDelivered.arrivalTitle'),
            departLabel: trans('forceToDelivered.departTitle'),
            losSelectLabel: trans('forceToDelivered.losSelectTitle'),
            stopLabel: trans('forceToDelivered.stopTitle'),
            arrivalAndDepartureLabel: trans('forceToDelivered.arrivalAndDepartureTitle'),
            losArrivalSelectLabel: trans('forceToDelivered.losArrivalSelectTitle'),
            losDepartureSelectLabel: trans('forceToDelivered.losDepartureSelectTitle'),
            cancelText: trans('forceToDelivered.cancel'),
            confirmText: trans('forceToDelivered.confirm'),
            modalTitle: trans('forceToDelivered.lable'),
            dateNotEmptyValidationMsg: trans('stops.error.dateNotEmptyValidation'),
            dateGreaterThanValidationMsg: trans('stops.error.dateGreaterThanValidation'),
            dateSequenceValidationMsg: trans('stops.error.dateSequenceValidation'),
            noteTripStatusText: trans('forceToDelivered.noteTripStatusTextReadyToStart'),
            noteInTransitStatusText: trans('forceToDelivered.noteInTransitStatusText'),
            noteDeleveredStatusText: trans('forceToDelivered.noteDeleveredStatusText'),
        };
        if (tripDetails?.statusUtils?.phase?.name === PlanPhaseEnum.IN_TRANSIT.name) {
            forceDeliTrans.noteTripStatusText = trans('forceToDelivered.noteTripStatusTextInTransit');
            forceDeliTrans.noteInTransitStatusText = '';
        }
        return forceDeliTrans;
    }, [trans, tripDetails]);
    const markLoadAsDelivered = (response) => {
        const payload = {
            trackingId: pPlanId,
            trackingIdType: 'TRIP',
            plans: response,
        };
        handlePlanAction(
            TripActionsEnum.FORCE_TO_DELIVERED.name,
            payload,
            (res) => pSuccess(res),
            (err) => pError(err),
        );
    };
    return (
        <>
            {pOpenModal && (
                <ForceToDelivered
                    pIsModalOpen={pOpenModal}
                    pOnCloseModal={pOnCloseModal}
                    pOnConfirmation={markLoadAsDelivered}
                    pModelData={tripDetails?.stopSequence?.stops}
                    pLos={sLosEvent || []}
                    pTranslations={forceLoadToDeliverModalTranslations}
                    pArrivalDepartureLosToggle={featureFlags?.showArrivalDepartureLosToggle}
                />
            )}
        </>
    );
};
const propTypes = {
    pOpenModal: PropTypes.bool.isRequired,
    pError: PropTypes.func.isRequired,
    pOnCloseModal: PropTypes.func.isRequired,
    pLoading: PropTypes.func.isRequired,
    pPlanId: PropTypes.string.isRequired,
    pSuccess: PropTypes.func.isRequired,
    pStaticData: PropTypes.shape({}).isRequired,
};
ForceLoadToDeliveredModalUS.propTypes = propTypes;
export default ForceLoadToDeliveredModalUS;
