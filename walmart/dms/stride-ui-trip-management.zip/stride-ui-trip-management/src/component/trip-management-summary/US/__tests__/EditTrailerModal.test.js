import React from 'react';
import axios from 'axios';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { fireEvent, render, screen } from '@testing-library/react';
import { contextMock } from './mocks/USMocks';
import { AppUtils } from '@gscope-mfe/app-bridge';
import EditTrailerModal from '../EditTrailerModal';

const spy = jest.spyOn(AppUtils, 'get');

const userPermMock = JSON.stringify({
    permissions: ['us.stride.ltm-tripManagement:READ', 'us.stride.ltm-tripManagement:WRITE'],
    markets: ['us'],
});

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';
const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}editTrailer/editTrailer`, (req, res, ctx) => res(ctx.json({}))),
);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    spy.mockImplementation(() => contextMock);
    server.listen();
});

afterEach(() => server.resetHandlers());

afterAll(() => server.close());

const API_CONFIG = {
    axios,
    currentMarket: 'us',
    usUsTenant: true,
    language: 'en',
    userId: 'stride',
};

const list = [
    {
        loadId: '50072925',
        originId: '6001',
        originValue: 'EKONO DC',
        originType: 'DC',
        originTypeToIcon: 'dc',
        destinationId: '751',
        destinationValue: 'BA MOSTAZAL',
        destinationType: 'STORE',
        destinationTypeToIcon: 'store',
        trailerId: '',
    },
];

const labels = {
    modalTitle: 'Edit trailer Id',
    trailer: 'Trailer Id',
    load: 'Load',
    originLocation: 'Origin',
    destinationLocation: 'Final destination',
    buttonCancel: 'Cancel',
    buttonSave: 'Save changes',
    errorMessage: 'errors',
    buttonIgnore: 'Ignore & Close',
};

const translations = {
    'edit.trailer.success': 'Updated',
    'edit.trailer.failed': 'Failed',
    'edit.trailer.pending': 'Validation pending',
};

const trans = (key) => translations[key];

describe('Edit trailer Modal', () => {
    it('Should render without crashing', () => {
        const closeFn = jest.fn();
        const handleSuccess = jest.fn();
        render(
            <EditTrailerModal
                pOnClose={closeFn}
                pOnSuccess={handleSuccess}
                pLoads={list}
                pActionSuccessCb={() => {}}
                pLabels={labels}
                pApiConfig={API_CONFIG}
                pTrans={trans}
                pSetloading={() => {}}
                pGetLicensePltNbrfrmYMS
            />,
        );

        expect(screen.getByText('editTrailer.title.modalTitle')).toBeDefined();
    });

    it('change edit trailer id', () => {
        const handleFunction = jest.fn();
        render(
            <EditTrailerModal
                pOnClose={handleFunction}
                pOnSuccess={handleFunction}
                pLoads={list}
                pActionSuccessCb={() => {}}
                pLabels={labels}
                pApiConfig={API_CONFIG}
                pTrans={trans}
                pSetloading={() => {}}
                pGetLicensePltNbrfrmYMS
            />,
        );
        const trailerInput = screen.getByTestId('trailerId');
        expect(trailerInput).toBeDefined();

        fireEvent.change(trailerInput, { target: { value: 'P-' } });
        expect(trailerInput.value).toBe('P-');
        const editTrailerStatus = screen.getByText('edit.trailer.pending');
        expect(editTrailerStatus).toBeDefined();
        const closeButton = screen.getByText('editTrailer.label.buttonCancel');
        fireEvent.click(closeButton);
        expect(handleFunction).toBeCalledTimes(1);
        fireEvent.click(screen.getByTestId('trailerSave'));
        expect(handleFunction).toBeCalledTimes(1);
    });

    it('ask confirmation from user on Ignore & Close button click if trailer update failed', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}editTrailer/editTrailer`, (req, res, ctx) =>
                res(
                    ctx.status(500),
                    ctx.json({
                        error: 'error',
                    }),
                ),
            ),
        );
        const handleFunction = jest.fn();
        render(
            <EditTrailerModal
                pOnClose={handleFunction}
                pOnSuccess={handleFunction}
                pLoads={list}
                pActionSuccessCb={() => {}}
                pLabels={labels}
                pApiConfig={API_CONFIG}
                pTrans={trans}
                pSetloading={() => {}}
                pGetLicensePltNbrfrmYMS
            />,
        );

        const trailerInput = screen.getByTestId('trailerId');
        expect(trailerInput).toBeDefined();
        fireEvent.change(trailerInput, { target: { value: 'P-' } });
        expect(trailerInput.value).toBe('P-');
        fireEvent.click(screen.getByTestId('trailerSave'));
        const editTrailerStatus = screen.getByText('edit.trailer.pending');
        expect(editTrailerStatus).toBeDefined();
        const editTrailerStatusFailed = await screen.findByText('edit.trailer.failed');

        expect(editTrailerStatusFailed).toBeDefined();
        fireEvent.click(screen.getByText('editTrailer.label.buttonIgnore'));
        const confirmBtn = screen.getByText('Yes, ignore & close');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
    });
});
