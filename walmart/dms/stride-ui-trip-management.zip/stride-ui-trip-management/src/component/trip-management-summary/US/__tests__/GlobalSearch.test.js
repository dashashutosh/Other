import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { render, screen, fireEvent } from '../../../../utils/test-utils';
import { contextMock } from './mocks/USMocks';
import TripSharedService from '../../../../service/TripSharedService';
import { planCountsZero } from './mocks/planCounts.mock';
import GlobalSearch from '../GlobalSearch';

const mockPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockPush,
    }),
}));

const API_GATEWAY_PREFIX = '/api/gateway/v4/stride-ui-trip-management';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX}-planCounts/planCounts`, (req, res, ctx) => res(ctx.json(planCountsZero))),
);

const phaseCounts = {
    planning: 0,
    processing: 0,
    dispatchPending: 0,
    readyToStart: 3,
    inTransit: 0,
    delivered: 0,
};

afterEach(() => server.resetHandlers());

afterAll(() => server.close());

beforeAll(() => {
    TripSharedService.setPageLoadSettings({ showUSColumns: true });
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
    server.listen();
});

describe('Global search US', () => {
    it('should render without crashing', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <GlobalSearch
                pPhaseTotal={phaseCounts}
                pSetCardCounts={mockFn}
                dispatch={mockFn}
                queryState={{}}
                pIsGlobalSearchFlow={mockFn}
            />,
        );

        expect(wrapper).toBeDefined();
    });

    it('Global search user flow', () => {
        const mockFn = jest.fn();
        render(
            <GlobalSearch
                pPhaseTotal={phaseCounts}
                pSetCardCounts={mockFn}
                dispatch={mockFn}
                queryState={{}}
                pIsGlobalSearchFlow={mockFn}
            />,
        );

        const gsText = screen.getByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();
        fireEvent.change(gsText, { target: { value: '1,3' } });
        expect(gsText.value).toBe('1,3');

        const searchBtn = screen.getByText('Search');
        expect(searchBtn).toBeDefined();
        fireEvent.click(searchBtn);
    });

    it('validate global search value and show error message', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <GlobalSearch
                pPhaseTotal={phaseCounts}
                pSetCardCounts={mockFn}
                dispatch={mockFn}
                queryState={{}}
                pIsGlobalSearchFlow={mockFn}
            />,
        );

        const gsText = wrapper.getByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();
        fireEvent.change(gsText, { target: { value: 'abc' } });
        expect(gsText.value).toBe('abc');

        const searchBtn = wrapper.getByText('Search');
        expect(searchBtn).toBeDefined();
        fireEvent.click(searchBtn);
        const msg = wrapper.getByText('Only IDs with comma separated allowed.');
        expect(msg).toBeDefined();
    });
    it('Should remove spaces and turn them into commas in Gloabl search', () => {
        const mockFn = jest.fn();
        render(
            <GlobalSearch
                pPhaseTotal={phaseCounts}
                pSetCardCounts={mockFn}
                dispatch={mockFn}
                queryState={{}}
                pIsGlobalSearchFlow={mockFn}
                pFeatureFlag={{ showCommaSeperation: true }}
            />,
        );

        const gsText = screen.getByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();
        fireEvent.change(gsText, { target: { value: '123 321' } });
        expect(gsText.value).toBe('123,321');
    });

    it('Should ignore white spaces in Global search ', () => {
        const mockFn = jest.fn();
        render(
            <GlobalSearch
                pPhaseTotal={phaseCounts}
                pSetCardCounts={mockFn}
                dispatch={mockFn}
                queryState={{}}
                pIsGlobalSearchFlow={mockFn}
                pFeatureFlag={{ showCommaSeperation: false }}
            />,
        );

        const gsText = screen.getByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();
        fireEvent.change(gsText, { target: { value: '122 322' } });
        expect(gsText.value).toBe('122 322');
    });
});
