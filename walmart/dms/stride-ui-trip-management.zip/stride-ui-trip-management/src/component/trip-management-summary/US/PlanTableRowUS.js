import React, { memo, useMemo, useState, useCallback } from 'react';
import {
    ChevronDownIcon,
    TableCell,
    TableRow,
    Checkbox,
    ArrowRightIcon,
    Button,
    Badge,
} from '@walmart/living-design-sc-ui';
import clsx from 'clsx';
import { useHistory } from 'react-router-dom';
import {
    onSelectionChange,
    LOCATION_TYPE_ICON_MAP,
    PlanStatus,
    openPageInNewTab,
    getLocationTypeToIconMap,
    calculateTimeDiff,
    ActionMenu,
    BEPlanCategoryEnum,
    OperationalFlagStatus,
    OperationalFlagEnum,
    TripActionsEnum,
    CommentPopoverTrigger,
    LoadActionsEnum,
    UIStatusEnum,
    PlanDetailsMapper,
} from '@walmart/stride-ui-commons';
import { isAfter, isEqual } from 'date-fns';
import PropTypes, { string, number } from 'prop-types';
import PhaseTypesEnum from '../../../utils/enums/PhaseTypesEnum';
import { enableRowExpansion } from './DataModelsUS';
import {
    stickyColumnPlanIdNoCheckBox,
    stickyColumnPlanTypeNoCheckbox,
    stickyColumnPlanId,
    stickyColumnPlanType,
    stickyColumnCheckbox,
    stickyColumnPlanStatus,
    stickyColumnPlanActions,
    stickyColumnNoCheckbox,
    stickyColumnNoAction,
    stickyColumnTags,
} from '../../../utils/StyleUtils';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { getActionDesc } from '../../../utils/ui-mappers/US/TripDetailsMapper';
import { AppUtils } from '@gscope-mfe/app-bridge';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const useStyles = makeStyles({
    '@keyframes hidden-cells-entry': {
        '0%': {
            opacity: 0.1,
        },
        '100%': {
            opacity: 1,
        },
    },
    mainRow: {
        '& td': {
            backgroundColor: '#fff',
        },
        '&:hover td': {
            backgroundColor: 'inherit',
        },
    },
    mainRowExpanded: {
        '& td': {
            borderBottomColor: 'transparent',
            backgroundColor: '#F1F1F2',
        },
    },
    collapsedRows: {
        '& td': {
            backgroundColor: '#F8F8F8',
            borderBottomColor: 'transparent',
            transformOrigin: 'top center',
            animation: '$hidden-cells-entry 0.5s ease-in',
        },
        '& $stickyColumn': {
            borderRightColor: 'transparent',
            borderLeftColor: 'transparent',
        },
        '& .MuiTableCell-root.MuiTableCell-body': {
            fontWeight: 400,
        },
    },
    collapsedRowFirst: {
        '&$collapsedRows td': {
            '&:nth-child(2)': {
                borderTopLeftRadius: 8,
            },
            '&:nth-last-child(2)': {
                borderTopRightRadius: 8,
            },
        },
    },
    collapsedRowLast: {
        '&$collapsedRows td': {
            '&:nth-child(2)': {
                borderBottomLeftRadius: 8,
            },
            '&:nth-last-child(2)': {
                borderBottomRightRadius: 8,
            },
        },
        '& + $mainRow td': {
            borderTop: '1px solid #e0e0e0',
        },
    },
    stickyColumn: {
        zIndex: 2,
        position: 'sticky',
        backgroundColor: '#fafafa !important',
    },
    stickyColumnPlanTypeNoCheckbox,
    stickyColumnPlanIdNoCheckBox,
    stickyColumnPlanId,
    stickyColumnTags,
    stickyColumnPlanType,
    stickyColumnPlanStatus,
    stickyColumnPlanActions,
    stickyColumnCheckbox,
    stickyColumnNoCheckbox,
    stickyColumnNoAction,
    checkBoxCellContainer: {
        display: 'flex',
        justifyContent: 'space-between',
    },
    chevronIconOpen: {
        transition: 'transform 0.5s ease-in',
        transform: 'rotate(180deg)',
    },
    statusTableCell: {
        '& .ld-sc-ui-status.ld-sc-ui-fixed-width': {
            width: 110,
        },
    },
    distanceCellContent: {
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'column',
        '& > span': {
            fontSize: 14,
        },
    },
    timeDelay: {
        color: '#c40e18',
        textTransform: 'lowercase',
        fontSize: '12px',
    },
    timeEarly: {
        color: '#226c02',
        textTransform: 'lowercase',
        fontSize: '12px',
    },
    planStatus: {
        padding: '4px 8px',
    },
    noWrapColumn: {
        left: 190,
        width: '200px',
        whiteSpace: 'nowrap',
    },
    actionDisabled: {
        pointerEvents: 'none',
        opacity: '0.4',
    },
    secondaryText: {
        opacity: '0.5',
        fontSize: '12px !important',
    },
    imgOpacity: {
        opacity: '0.3',
    },
    mininmumCheckBoxWidth: {
        minWidth: 25,
    },
    tableContentWrap: {
        '& td.MuiTableCell-body': {
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            fontWeight: 400,
            height: '50px !important',
            padding: '6px 12px',
            maxWidth: '24rem',
        },
        '& .MuiTableCell-root.MuiTableCell-body': {
            '& .ld-sc-ui-button': {
                overflow: 'hidden !important',
                textOverflow: 'ellipsis !important',
                display: 'block !important',
                maxWidth: '20rem !important',
                border: 'none !important',
                borderRadius: '0px !important',
            },
        },
    },
});
function PlanTableRowUS({
    pRowData,
    pCheckedRows,
    pTabIndex,
    mdmLocationTypes,
    pActionTrigger,
    pFeatureFlag,
    pSetActionRow,
    pQueryState,
    dispatch,
    pOnViewAllComments,
}) {
    const trans = localizeLang();
    const [sShowCollapsedRows, setsShowCollapsedRows] = useState(false);
    const { prefLang, userInfo } = AppUtils.get();
    const classes = useStyles();
    const history = useHistory();
    const handleMenuClose = useCallback((isActionClicked) => {
        if (!isActionClicked) {
            pSetActionRow([]);
        }
    }, []);

    const planStatusProps = {
        ...pRowData.statusObj,
        trans,
        pickupTimeAtOrigin: pRowData?.pickupTimeAtOrigin,
    };
    const actionsClickHandler = (rowData) => {
        pSetActionRow([rowData.planId]);
    };

    const onViewAllComments = (selectedRowData) => {
        pOnViewAllComments(selectedRowData);
    };

    const handlePlanActionItemClick = useCallback(
        (event) => {
            const actionCode = event.currentTarget.dataset.code;
            pActionTrigger(actionCode);
            // pSetActionRow([]);
            handleMenuClose(true);
        },
        [handleMenuClose, pActionTrigger],
    );
    const planIdClickHandler = (isTrip, planId, planType) => {
        let path = '';
        if (isTrip && planType !== BEPlanCategoryEnum.IM?.code) {
            path = 'tripdetails';
        } else path = 'loaddetails';
        if (pFeatureFlag?.openDetailsPageInNewTab) {
            openPageInNewTab(
                pFeatureFlag.hasPQMigratedToMFE
                    ? `/mfe/stride/planquery/${path}?planId=${planId}`
                    : `/stride/planquery/${path}?planId=${planId}`,
            );
        } else {
            history.push({
                pathname: pFeatureFlag.hasPQMigratedToMFE
                    ? `/mfe/stride/planquery/${path}`
                    : `/stride/planquery/${path}`,
                search: `?planId=${planId}`,
            });
        }
    };
    const locationIdClickHandler = (locationId, locationType) => {
        if (locationId && locationType) {
            window.open(
                pFeatureFlag.hasLocationMigratedToMFE
                    ? `/mfe/stride/location/details?type=${locationType}&id=${locationId}`
                    : `/stride/location/details?type=${locationType}&id=${locationId}`,
            );
        }
    };
    const driverIdClickHandler = (driverId) => {
        if (driverId) {
            window.open(
                pFeatureFlag.hasDriverMigratedToMFE
                    ? `/mfe/stride/driver/summary?id=${driverId}`
                    : `/stride/driver/summary?id=${driverId}`,
            );
        }
    };

    const getTrailerId = (_rowData) => {
        if (_rowData.isTrip && _rowData.planType !== BEPlanCategoryEnum.IM?.code) {
            return (
                <span className="d-flex">
                    {`${_rowData.trailerIdOfFirstLoadForTrip}`}
                    {_rowData.trailerCountForTrip > 1 && (
                        <div className="ml-1">
                            <Badge count={`+${_rowData.trailerCountForTrip - 1}`} variant="neutral" />
                        </div>
                    )}
                </span>
            );
        }
        return _rowData.trailerId;
    };
    const renderSubCommonCells = (_rowData) => (
        <>
            <TableCell type="default" data-testid="carrierId-cell">
                {_rowData.carrierId}
            </TableCell>
            {!pFeatureFlag?.showServiceTerritory && (
                <TableCell type="info" className={clsx(classes.noWrapColumn)} data-testid="serviceTerritory-cell">
                    <div>{_rowData.serviceTerritory}</div>
                </TableCell>
            )}
            {pFeatureFlag?.showServiceTerritory && (
                <>
                    <TableCell
                        type="info"
                        className={clsx(classes.noWrapColumn)}
                        data-testid="trip-serviceTerritory-cell"
                    >
                        <div>{_rowData.tripServiceTerritory}</div>
                    </TableCell>
                    <TableCell
                        type="info"
                        className={clsx(classes.noWrapColumn)}
                        data-testid="planning-serviceTerritory-cell"
                    >
                        <div>{_rowData.planningServiceTerritory}</div>
                    </TableCell>
                </>
            )}
            <TableCell type="info" className={clsx(classes.noWrapColumn)} data-testid="trailerId-cell">
                <div>{getTrailerId(_rowData)}</div>
            </TableCell>
            <TableCell
                type={_rowData.driverId ? 'default' : 'empty'}
                className={clsx(classes.noWrapColumn)}
                data-testid="driverId-cell"
            >
                {_rowData.isTrip ? (
                    <>
                        {_rowData.driverId !== '--' ? (
                            <>
                                <Button
                                    id="lms-table-click"
                                    size="small"
                                    variant="text-only"
                                    onClick={() => driverIdClickHandler(_rowData.driverId)}
                                >
                                    {_rowData.driverId}
                                </Button>
                                <div>{_rowData.driverName}</div>
                            </>
                        ) : (
                            <div>{_rowData.driverId}</div>
                        )}
                    </>
                ) : (
                    <div>{_rowData.driverId}</div>
                )}
            </TableCell>
        </>
    );
    const OperationalFlags = useMemo(() => {
        const OperationalFlagsList = [];
        if (pRowData.hazmat === trans(OperationalFlagEnum.HAZMAT.name)) {
            OperationalFlagsList.push(OperationalFlagEnum.HAZMAT);
        }
        if (pRowData.printed === trans(OperationalFlagEnum.PRINTED.name)) {
            OperationalFlagsList.push(OperationalFlagEnum.PRINTED);
        }
        if (pRowData.onHold?.onHold) {
            OperationalFlagsList.push(OperationalFlagEnum.HOLD(pRowData?.onHold?.holdReason));
        }
        return OperationalFlagsList;
    }, [pRowData?.hazmat, trans, pRowData?.onHold]);
    const renderCommonCellsUS = (_rowData, isInnerRow) => (
        <>
            <TableCell
                type="info"
                className={clsx(classes.stickyColumn, classes.stickyColumnPlanId)}
                data-testid="planId-cell"
            >
                {_rowData?.uiStatus?.name === UIStatusEnum.WTMS_LOAD.name ? (
                    _rowData.planId
                ) : (
                    <Button
                        id="lms-table-click"
                        data-testid="lms-table-click"
                        size="small"
                        variant="text-only"
                        onClick={() => planIdClickHandler(_rowData.isTrip, _rowData.planId, _rowData.planType)}
                    >
                        {_rowData.planId}
                    </Button>
                )}
            </TableCell>
            {pFeatureFlag?.showTagsCol && (
                <TableCell
                    type={isInnerRow ? 'default' : 'info'}
                    className={clsx(classes.stickyColumn, classes.stickyColumnTags)}
                    data-testid="tags-cell"
                >
                    {isInnerRow ? (
                        <div>
                            <OperationalFlagStatus pOperationalFlags={OperationalFlags} />
                        </div>
                    ) : (
                        ''
                    )}
                    {_rowData.isTrip && _rowData.planType !== BEPlanCategoryEnum.IM?.code ? (
                        <div>
                            <>
                                <OperationalFlagStatus pOperationalFlags={OperationalFlags} />
                            </>
                        </div>
                    ) : (
                        <>
                            {!isInnerRow && (
                                <div>
                                    <OperationalFlagStatus pOperationalFlags={OperationalFlags} />
                                </div>
                            )}
                        </>
                    )}
                </TableCell>
            )}
            <TableCell
                type={isInnerRow ? 'default' : 'info'}
                className={clsx(
                    classes.stickyColumn,
                    pFeatureFlag.showTagsCol ? classes.stickyColumnPlanType : classes.stickyColumnTags,
                )}
                data-testid="planType-cell"
            >
                {isInnerRow ? <div>{`${_rowData.planEntity} - ${_rowData.planType}`}</div> : ''}
                {_rowData.isTrip ? (
                    <span className="d-flex align-items-center">
                        {`${_rowData.planEntity} - ${_rowData.planType}`}
                        {enableRowExpansion(_rowData, pQueryState) && (
                            <div className="ml-1">
                                <Badge count={_rowData.loadCount} variant="neutral" />
                            </div>
                        )}
                    </span>
                ) : (
                    <>{!isInnerRow && <div>{`${_rowData.planEntity} - ${_rowData.planType}`}</div>}</>
                )}
            </TableCell>
            {pTabIndex === PhaseTypesEnum.PLANNING.index && (
                <TableCell type="info" className={clsx(classes.noWrapColumn)} data-testid="trailerId-cell">
                    {getTrailerId(_rowData)}
                </TableCell>
            )}
            {pTabIndex === PhaseTypesEnum.PROCESSING.index && renderSubCommonCells(_rowData)}
            <TableCell type="info" className={clsx(classes.noWrapColumn)} data-testid="origin-cell">
                <div className="d-flex align-items-center">
                    <img
                        className={classes.imgOpacity}
                        src={LOCATION_TYPE_ICON_MAP[getLocationTypeToIconMap(_rowData.originType)]}
                        alt={`${_rowData.originType} icon`}
                    />
                    <div className="st-ui-ml-2">
                        <Button
                            id="lls-origin-click"
                            size="small"
                            variant="text-only"
                            onClick={() => locationIdClickHandler(_rowData.originId, _rowData.originType)}
                        >
                            {`${mdmLocationTypes[_rowData.originType] || ''} - ${_rowData.originId} - ${
                                _rowData.originName
                            }`}
                        </Button>
                        <div className={classes.secondaryText}>
                            {`${_rowData.originCity}, ${_rowData.originProvince}`}
                        </div>
                    </div>
                </div>
            </TableCell>
            {pFeatureFlag?.showCommentsColumn && (
                <TableCell type="info" className={clsx(classes.noWrapColumn)} data-testid="comment-cell">
                    <CommentPopoverTrigger
                        pComment={_rowData?.latestComment}
                        pUserInfo={userInfo}
                        pCurrentLang={prefLang?.current}
                        pSelectedPlan={_rowData}
                        pOnViewAll={onViewAllComments}
                    />
                </TableCell>
            )}
            <TableCell data-testid="distance-cell">
                <div className={classes.distanceCellContent}>
                    <ArrowRightIcon size="medium" />
                    <span>{_rowData.distance}</span>
                </div>
            </TableCell>
            <TableCell type="info" className={clsx(classes.noWrapColumn)} data-testid="destination-cell">
                <div className="d-flex align-items-center">
                    <img
                        className={classes.imgOpacity}
                        src={LOCATION_TYPE_ICON_MAP[getLocationTypeToIconMap(_rowData.destinationType)]}
                        alt={`${_rowData.destinationType} icon`}
                    />
                    <div className="st-ui-ml-2">
                        <Button
                            id="lls-destination-click"
                            size="small"
                            variant="text-only"
                            onClick={() => locationIdClickHandler(_rowData.destinationId, _rowData.destinationType)}
                        >
                            {`${mdmLocationTypes[_rowData.destinationType] || ''} - ${_rowData.destinationId} - ${
                                _rowData.destinationName
                            }`}
                        </Button>
                        <div className={classes.secondaryText}>
                            {`${_rowData.destinationCity}, ${_rowData.destinationProvince}`}
                        </div>
                    </div>
                </div>
            </TableCell>
            {pFeatureFlag?.showPrimaryDestinationCol && (
                <TableCell type="info" className={clsx(classes.noWrapColumn)} data-testid="primaryDestination-cell">
                    {_rowData.isTrip && _rowData.planType !== BEPlanCategoryEnum.IM?.code ? (
                        <div className="d-flex align-items-center">
                            {_rowData?.priDestinationId ? (
                                <div>
                                    <Button
                                        id="lls-priDestination-click"
                                        size="small"
                                        variant="text-only"
                                        onClick={() =>
                                            locationIdClickHandler(
                                                _rowData.priDestinationId,
                                                _rowData.priDestinationType,
                                            )
                                        }
                                    >
                                        {`${mdmLocationTypes[_rowData.priDestinationType] || ''} - ${
                                            _rowData.priDestinationId
                                        }`}
                                    </Button>
                                    <div className={classes.secondaryText}>
                                        {`${_rowData.priDestinationCity}, ${_rowData.priDestinationProvince}`}
                                    </div>
                                </div>
                            ) : (
                                '--'
                            )}
                        </div>
                    ) : (
                        '--'
                    )}
                </TableCell>
            )}
            {/* Todo: required this later */}
            {/* <TableCell type="info">
        <CommentIcon
          size="medium"
          align="center"
          className={`${_rowData.comments?.length === 0 ? classes.actionDisabled : ''}`}
          onClick={() => { }}
        />
       </TableCell> */}
            {pFeatureFlag?.showDwellDays &&
                pTabIndex !== PhaseTypesEnum.IN_TRANSIT.index &&
                pTabIndex !== PhaseTypesEnum.DELIVERED.index && (
                    <TableCell type="default" className={clsx(classes.noWrapColumn)} data-testid="dwellDays-cell">
                        {_rowData.dwellDays}
                    </TableCell>
                )}
            <TableCell type="default" className={clsx(classes.noWrapColumn)} data-testid="priority-cell">
                {_rowData.priority}
            </TableCell>
            {pTabIndex !== PhaseTypesEnum.IN_TRANSIT.index && pTabIndex !== PhaseTypesEnum.DELIVERED.index && (
                <TableCell type="default" className={clsx(classes.noWrapColumn)} data-testid="planStartTime-cell">
                    {' '}
                    {_rowData.departureTs}{' '}
                </TableCell>
            )}
            {pTabIndex !== PhaseTypesEnum.DELIVERED.index && pTabIndex !== PhaseTypesEnum.IN_TRANSIT.index && (
                <TableCell type="default" data-testid="endDatePlanned-cell">
                    {_rowData.endDatePlanned}
                </TableCell>
            )}
            {(pTabIndex === PhaseTypesEnum.IN_TRANSIT.index || pTabIndex === PhaseTypesEnum.DELIVERED.index) && (
                <TableCell type="default" data-testid="intrasitStartDatePlanned-cell">
                    {_rowData.departureTs}
                </TableCell>
            )}
            {(pTabIndex === PhaseTypesEnum.IN_TRANSIT.index || pTabIndex === PhaseTypesEnum.DELIVERED.index) && (
                <TableCell type="default" className={clsx(classes.noWrapColumn)} data-testid="actualTs-cell">
                    {' '}
                    {_rowData.actualTs}{' '}
                    {!isEqual(new Date(_rowData.plannedStartTime), new Date(_rowData.actualStartTime)) && (
                        <div
                            // eslint-disable-next-line max-len
                            className={
                                isAfter(new Date(_rowData.plannedStartTime), new Date(_rowData.actualStartTime))
                                    ? classes.timeEarly
                                    : classes.timeDelay
                            }
                            data-testid="differenceStartTime-cell"
                        >
                            {calculateTimeDiff(_rowData.plannedStartTime, _rowData.actualStartTime)?.time}
                        </div>
                    )}
                </TableCell>
            )}
            {/* Todo: required this later */}
            {/* <TableCell
        type="default"
       >
        {_rowData.sequence }
       </TableCell> */}
            {(pTabIndex === PhaseTypesEnum.IN_TRANSIT.index || pTabIndex === PhaseTypesEnum.DELIVERED.index) && (
                <TableCell type="default" data-testid="endDatePlanned-cell">
                    {_rowData.endDatePlanned}
                </TableCell>
            )}
            {pTabIndex === PhaseTypesEnum.IN_TRANSIT.index && (
                <TableCell type="default" data-testid="endDateEstimated-cell">
                    --
                </TableCell>
            )}
            {pTabIndex === PhaseTypesEnum.DELIVERED.index && (
                <TableCell type="default" data-testid="endDateActual-cell">
                    --
                </TableCell>
            )}
            {pTabIndex === PhaseTypesEnum.DELIVERED.index && renderSubCommonCells(_rowData)}
            <TableCell type="default" data-testid="duration-cell">
                {_rowData.duration}
            </TableCell>
            {pTabIndex === PhaseTypesEnum.IN_TRANSIT.index && (
                <>
                    <TableCell type="info" className={clsx(classes.noWrapColumn)} data-testid="next-stop-cell">
                        <div className="d-flex align-items-center">
                            {_rowData.nextStopType && (
                                <img
                                    className={classes.imgOpacity}
                                    src={LOCATION_TYPE_ICON_MAP[getLocationTypeToIconMap(_rowData.nextStopType)]}
                                    alt={`${_rowData.nextStopType} icon`}
                                />
                            )}
                            <div className="st-ui-ml-2">
                                {_rowData.nextStopType && _rowData.nextStopId && (
                                    <Button
                                        id="lls-destination-click"
                                        size="small"
                                        variant="text-only"
                                        onClick={() =>
                                            locationIdClickHandler(_rowData.nextStopId, _rowData.nextStopType)
                                        }
                                        data-testid="next-stop-type_stopId_name"
                                    >
                                        {`${mdmLocationTypes[_rowData.nextStopType] || ''} - ${_rowData.nextStopId} - ${
                                            _rowData.nextStopName
                                        }`}
                                    </Button>
                                )}
                                <div className={classes.secondaryText} data-testid="next-stop-city_province">
                                    {_rowData.nextStopCity && _rowData.nextStopProvince
                                        ? `${_rowData.nextStopCity}, ${_rowData.nextStopProvince}`
                                        : _rowData.nextStopCity || _rowData.nextStopProvince}
                                </div>
                            </div>
                        </div>
                    </TableCell>
                    <TableCell type="default" data-testid="numberOfStopsRemaining-cell">
                        {_rowData.numberOfStopsRemaining}
                    </TableCell>
                </>
            )}
            {pTabIndex === PhaseTypesEnum.READY_TO_START.index && renderSubCommonCells(_rowData)}
            {pTabIndex !== PhaseTypesEnum.PLANNING.index && (
                <>
                    <TableCell
                        data-testid="billsByTime-cell"
                        type={_rowData.billsByTime ? 'default' : 'empty'}
                        className={clsx(classes.noWrapColumn)}
                    >
                        {_rowData.billsByTime}
                    </TableCell>
                </>
            )}
            <TableCell type="default" data-testid="pickupStops-cell">
                {_rowData.noOfPickupStops}
            </TableCell>
            {pTabIndex === PhaseTypesEnum.IN_TRANSIT.index && renderSubCommonCells(_rowData)}
            <TableCell data-testid="deliveryStops-cell" type={_rowData.noOfDropoffStops ? 'default' : 'empty'}>
                {_rowData.noOfDropoffStops}
            </TableCell>
        </>
    );
    const isSelected = useMemo(
        () => pCheckedRows && pCheckedRows?.indexOf(pRowData.planId) !== -1,
        [pCheckedRows, pRowData.planId],
    );
    const rowKey = `${pTabIndex}-${pRowData.planId}`;
    const renderCells = (rowData) => renderCommonCellsUS(rowData);
    const renderNestedCommonsCells = (rowData, isInnerRow) => renderCommonCellsUS(rowData, isInnerRow);
    const getActionsDesc = (action) => {
        if (action?.name === TripActionsEnum.MARK_UNMARK_PRINTED.name) {
            return trans(getActionDesc([pRowData], action));
        } else if (action?.name === LoadActionsEnum.MARK_UNMARK_HAZMAT.name) {
            return trans(PlanDetailsMapper.getHazmatActionDesc([pRowData], action));
        } else {
            return trans(action.desc);
        }
    };
    return (
        <>
            <TableRow
                className={clsx(
                    classes.mainRow,
                    {
                        [classes.mainRowExpanded]: sShowCollapsedRows,
                    },
                    classes.tableContentWrap,
                )}
                data-testid={`dt-tr-${rowKey}`}
            >
                <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnCheckbox)}>
                    <div className={classes.checkBoxCellContainer}>
                        <div className={classes.mininmumCheckBoxWidth}>
                            <Checkbox
                                color="primary"
                                id={`dt-cb-${rowKey}`}
                                name={rowKey}
                                checked={isSelected}
                                onChange={() => {
                                    dispatch({
                                        type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                                        checkedRows: onSelectionChange(pRowData.planId, pCheckedRows || []),
                                    });
                                }}
                                data-testid={`dt-chkbx-${rowKey}`}
                            />
                        </div>
                        {pRowData &&
                            pRowData.plans &&
                            Array.isArray(pRowData.plans) &&
                            enableRowExpansion(pRowData, pQueryState) &&
                            pRowData.plans.length > 0 && (
                                <div data-testid="expandRowIcon">
                                    <ChevronDownIcon
                                        onClick={() =>
                                            setsShowCollapsedRows((_showCollapsedRows) => !_showCollapsedRows)
                                        }
                                        className={clsx({
                                            [classes.chevronIconOpen]: sShowCollapsedRows,
                                        })}
                                    />
                                </div>
                            )}
                    </div>
                </TableCell>
                {renderCells(pRowData)}
                <TableCell
                    className={clsx(classes.stickyColumn, classes.stickyColumnPlanStatus, classes.statusTableCell)}
                    align="left"
                    data-testid="status-cell"
                >
                    <PlanStatus {...planStatusProps} />
                </TableCell>
                {/* // Todo: for R1 actions column only required for intransit tab */}
                <TableCell
                    className={clsx(classes.stickyColumn, classes.stickyColumnPlanActions, classes.statusTableCell)}
                    align="center"
                    data-testid="actions-cell"
                >
                    <ActionMenu
                        pActions={pRowData?.actions?.map((action) => ({
                            ...action,
                            desc: getActionsDesc(action),
                        }))}
                        pOnClose={() => {
                            handleMenuClose(false);
                        }}
                        pOnActionItemClick={handlePlanActionItemClick}
                        pOnActionTriggerClick={() => actionsClickHandler(pRowData)}
                        pBtnLabel="..."
                        pBtnVariant="text-only"
                        pIsDisable={pCheckedRows?.length > 0}
                    />
                </TableCell>
            </TableRow>
            {sShowCollapsedRows && (
                <>
                    {pRowData.plans.map((plan, index) => (
                        <TableRow
                            className={clsx(classes.tableContentWrap, classes.collapsedRows, {
                                [classes.collapsedRowLast]: index === pRowData.plans.length - 1,
                                [classes.collapsedRowFirst]: index === 0,
                            })}
                            key={plan.planId}
                        >
                            <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnCheckbox)} />
                            {renderNestedCommonsCells(plan, true)}
                            <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnPlanStatus)} />
                            <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnPlanStatus)} />
                            <TableCell
                                className={clsx(
                                    classes.stickyColumn,
                                    classes.stickyColumnPlanActions,
                                    classes.statusTableCell,
                                )}
                            />
                        </TableRow>
                    ))}
                </>
            )}
        </>
    );
}
PlanTableRowUS.propTypes = {
    pRowData: PropTypes.object.isRequired,
    pCheckedRows: PropTypes.arrayOf(string).isRequired,
    pTabIndex: number.isRequired,
    mdmLocationTypes: PropTypes.oneOfType([PropTypes.object]),
    pActionTrigger: PropTypes.func.isRequired,
    pSetActionRow: PropTypes.func.isRequired,
    pFeatureFlag: PropTypes.shape({
        openDetailsPageInNewTab: PropTypes.bool,
        showPrimaryDestinationCol: PropTypes.bool,
        showDwellDays: PropTypes.bool,
        showServiceTerritory: PropTypes.bool,
        showTagsCol: PropTypes.bool,
    }),
    pQueryState: PropTypes.shape({}).isRequired,
    dispatch: PropTypes.func.isRequired,
    pOnViewAllComments: PropTypes.func.isRequired,
};
PlanTableRowUS.defaultProps = {
    mdmLocationTypes: {},
    pFeatureFlag: {},
};
export default memo(PlanTableRowUS);
