import TripSharedService from '../../../../service/TripSharedService';
import {
    formatForceToDeleverTripRequest,
    getPlanListWithUpdatedComments,
    transformUSPlanPreviewData,
} from '../DataModelsUS';
import { getMockDataForLTMComments } from './mocks/LTMCommentsData.mock';
import { params, request, transformUSPlanPreviewDataMockResult } from './mocks/requestParamsUS.mock';
import * as transformedPlanMockUS from './mocks/transformedPlanMockUS.json';
import { transformedTrip } from './mocks/transformedTripResponseFromCommons.mock';

describe('formatForceToDeleverTripRequest', () => {
    it('should return formatted request body', () => {
        expect(formatForceToDeleverTripRequest(params)).toEqual(request);
    });
});

TripSharedService?.setFeatureFlags({ enableStandardDateTimeFormat: true });
TripSharedService.setStandardDateTimeFormat({ dateTime: 'MM/dd/yyyy HH:mm' });

describe('transformUSPlanPreviewData', () => {
    // TODO: Fix this test after MFE migration
    it.skip('should test the transformUSPlanPreviewData method with required parameters', () => {
        const mockData = {
            ...transformedPlanMockUS[5],
            childPlans: [],
        };
        expect(transformUSPlanPreviewData(mockData, jest.fn())).toEqual(transformUSPlanPreviewDataMockResult);
        expect(transformUSPlanPreviewData(mockData, jest.fn()).carrierId).toEqual('77775020');
        const tenderCancelledMock = {
            ...mockData,
            carrierStatus: {
                name: 'TENDER_CANCELLED',
            },
        };
        expect(transformUSPlanPreviewData(tenderCancelledMock, jest.fn()).carrierId).toEqual('--');
        const tenderAcceptedMock = {
            ...mockData,
            carrierStatus: {
                name: 'TENDER_ACCEPTED',
            },
        };
        expect(transformUSPlanPreviewData(tenderAcceptedMock, jest.fn()).carrierId).toEqual('77775020');
    });

    it('should return mustDepartTime date value', () => {
        const mockData = {
            ...transformedTrip[0],
            childPlans: [],
        };
        const trans = jest.fn((key) => key);
        const result = transformUSPlanPreviewData(mockData, trans);
        expect(result.mustDepartTime).toEqual('11/01/2021 20:51');
    });

    it('should return mustDepartTime date value as --', () => {
        const mockData = {
            ...transformedTrip[2],
            childPlans: [],
        };
        const trans = jest.fn((key) => key);
        const result = transformUSPlanPreviewData(mockData, trans);
        expect(result.mustDepartTime).toEqual('--');
    });

    it('should return mustDepartTime date value', () => {
        const mockData = {
            ...transformedPlanMockUS[9],
            childPlans: [],
        };
        const trans = jest.fn((key) => key);
        const result = transformUSPlanPreviewData(mockData, trans);
        expect(result.onHold).toEqual({ holdReason: 'hold', onHold: true });
    });
});

describe('transformUSPlanPreviewData LatestComments', () => {
    const staticData = { shortTimezones: {} };
    const trans = jest.fn((key) => key);

    it('should return default values for an empty plan', () => {
        const plan = {};
        const result = transformUSPlanPreviewData(plan, trans, staticData);
        expect(result).toMatchObject({
            latestComment: undefined,
            plans: [],
        });
    });

    it('should set latestComment to null when there are no comments', () => {
        const plan = { planComments: [], childPlans: [] };
        const result = transformUSPlanPreviewData(plan, trans, staticData);
        expect(result.latestComment).toEqual(undefined);
    });

    it('should set latestComment based on the most recent comment', () => {
        const plan = {
            planComments: [
                {
                    lastUpdatedTs: '2023-09-25T12:00:00Z',
                    createdByUserName: 'User1',
                    createdTs: '2023-09-25',
                    commentText: 'Comment 1',
                    commentType: 'type1',
                    commentId: '1',
                    createdByUserId: 'user1',
                },
                {
                    lastUpdatedTs: '2023-09-26T12:00:00Z',
                    createdByUserName: 'User2',
                    createdTs: '2023-09-26',
                    commentText: 'Comment 2',
                    commentType: 'type2',
                    commentId: '2',
                    createdByUserId: 'user2',
                },
            ],
            childPlans: [],
        };
        const result = transformUSPlanPreviewData(plan, trans, staticData);
        expect(result.latestComment).toBeDefined();
        expect(result.latestComment).toEqual(
            expect.objectContaining({
                commentText: 'Comment 2',
                commentByDisplayName: 'User2',
                commentId: '2',
                commentBy: 'user2',
            }),
        );
    });

    it('should process child plans correctly', () => {
        const childPlan = { planComments: [], childPlans: [] };
        const plan = { childPlans: [childPlan] };
        const result = transformUSPlanPreviewData(plan, trans, staticData);
        expect(result.plans).toHaveLength(1);
        expect(result.plans[0].latestComment).toEqual(undefined);
    });

    it('should set latestComment to undefined when planComments is undefined', () => {
        const plan = { childPlans: [] };
        const result = transformUSPlanPreviewData(plan, trans, staticData);
        expect(result.latestComment).toEqual(undefined);
    });

    it('should set latestComment to undefined when planComments is null', () => {
        const plan = { planComments: null, childPlans: [] };
        const result = transformUSPlanPreviewData(plan, trans, staticData);
        expect(result.latestComment).toEqual(undefined);
    });

    it('should return createdByUserName as commentByDisplayName if createdByUserName is available', () => {
        const plan = {
            planComments: [
                {
                    lastUpdatedTs: '2023-09-25T12:00:00Z',
                    createdByUserName: 'Test User',
                    createdTs: '2023-09-25',
                    commentText: 'Comment 1',
                    commentType: 'type1',
                    commentId: '1',
                    createdByUserId: 'user1',
                },
            ],
            childPlans: [],
        };
        const result = transformUSPlanPreviewData(plan, trans, staticData);
        expect(result.latestComment).toBeDefined();
        expect(result.latestComment).toEqual(
            expect.objectContaining({
                commentByDisplayName: 'Test User',
            }),
        );
    });

    it('should return createdByUserId as commentByDisplayName if no createdByUserName is available', () => {
        const plan = {
            planComments: [
                {
                    lastUpdatedTs: '2023-09-25T12:00:00Z',
                    createdByUserName: null,
                    createdTs: '2023-09-25',
                    commentText: 'Comment 1',
                    commentType: 'type1',
                    commentId: '1',
                    createdByUserId: 'user1',
                },
            ],
            childPlans: [],
        };
        const result = transformUSPlanPreviewData(plan, trans, staticData);
        expect(result.latestComment).toBeDefined();
        expect(result.latestComment).toEqual(
            expect.objectContaining({
                commentByDisplayName: 'user1',
            }),
        );
    });
    describe('getPlanListWithUpdatedComments tests', () => {
        const { plans, commentsDrawerInput, commentsDrawerOutput, updatedTripCommentText, updatedLoadCommentText } =
            getMockDataForLTMComments();

        it('Returns updated plan list when the comments drawer returns updated comments', () => {
            const updatedPlans = getPlanListWithUpdatedComments(plans, commentsDrawerInput, commentsDrawerOutput);
            expect(updatedPlans[0].planComments[0].commentText).toBe(updatedTripCommentText);
            expect(updatedPlans[0].childPlans[0].planComments[0].commentText).toBe(updatedLoadCommentText);
        });
    });
});
