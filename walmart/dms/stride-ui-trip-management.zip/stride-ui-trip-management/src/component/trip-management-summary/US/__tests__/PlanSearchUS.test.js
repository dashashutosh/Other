import React from 'react';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { render, fireEvent, screen } from '../../../../utils/test-utils';
import { contextMock } from './mocks/USMocks';
import PlanSearchUS from '../PlanSearchUS';
import TripSharedService from '../../../../service/TripSharedService';
import { initialFilterState, PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../../utils/actions/PlanTableQueryActions';

beforeAll(() => {
    TripSharedService.setPageLoadSettings({ showUSColumns: true });
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});
// Todo: R2 - reveiw comment - Add a test case to cover reset button.
describe('PlanSearch US', () => {
    it('should render without crashing', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 0,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {},
                }}
                dispatch={mockFn}
                pIsOpen
                pOnClose={() => {}}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );

        expect(wrapper).toBeDefined();
        expect(wrapper.queryByTestId('planType')).toBeDefined();
        expect(wrapper.queryByTestId('originType')).toBeDefined();
        expect(wrapper.queryByTestId('originId')).toBeDefined();
        expect(wrapper.queryByTestId('originCity')).toBeDefined();
        expect(wrapper.queryByTestId('originState')).toBeDefined();
        expect(wrapper.queryByTestId('originCountry')).toBeDefined();
        expect(wrapper.queryByTestId('originZipCode')).toBeDefined();
        expect(wrapper.queryByTestId('destinationType')).toBeDefined();
        expect(wrapper.queryByTestId('destinationId')).toBeDefined();
        expect(wrapper.queryByTestId('destinationCity')).toBeDefined();
        expect(wrapper.queryByTestId('destinationState')).toBeDefined();
        expect(wrapper.queryByTestId('destinationCountry')).toBeDefined();
        expect(wrapper.queryByTestId('destinationZipCode')).toBeDefined();
    });
    it('should close the modal on close button click', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 0,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {},
                }}
                dispatch={() => {}}
                pIsOpen
                pOnClose={mockFn}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );

        const closeBtn = wrapper.queryByTestId('ld-sc-ui-button-modal-close');
        expect(closeBtn).toBeDefined();
        fireEvent.click(closeBtn);
        expect(mockFn).toBeCalled();
    });
    it('should close the modal on apply filter button click', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 0,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {},
                }}
                dispatch={() => {}}
                pIsOpen
                pOnClose={mockFn}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );

        const originId = wrapper.queryByTestId('originId');
        fireEvent.change(originId, { target: { value: '123456' } });
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
        expect(mockFn).toBeCalled();
    });
    it('should display carrier section if activeTabindex is 1', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 1,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {},
                }}
                dispatch={() => {}}
                pIsOpen
                pOnClose={mockFn}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );

        expect(wrapper.queryByTestId('carrierId')).toBeDefined();
        expect(wrapper.queryByTestId('serviceTerritory')).toBeDefined();
        expect(wrapper.queryByTestId('coordinatorBoard')).toBeDefined();
        expect(wrapper.queryByTestId('driverId')).toBeDefined();
        expect(wrapper.queryByTestId('trailerId')).toBeDefined();
    });
    it('should invoke dispatch function on click of apply filter ', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 1,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {},
                }}
                dispatch={mockFn}
                pIsOpen
                pOnClose={() => {}}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );

        const originId = wrapper.queryByTestId('originId');
        fireEvent.change(originId, { target: { value: '123456' } });

        const planTypeDropdown = screen.getByTestId('planType');
        expect(planTypeDropdown).toBeDefined();
        fireEvent.click(planTypeDropdown);
        const dropdownMenuItem = screen.getByText('test1');
        fireEvent.click(dropdownMenuItem);

        const carrierId = wrapper.queryByTestId('carrierId');
        fireEvent.change(carrierId, { target: { value: '8907' } });

        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
        expect(mockFn).toHaveBeenCalledWith({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_FILTER,
            filter: {
                ...initialFilterState,
                originId: '123456',
                planType: 'test1',
                carrierId: '8907',
            },
        });
    });
    it('should disable the apply filter button when form is empty ', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 1,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {},
                }}
                dispatch={mockFn}
                pIsOpen
                pOnClose={() => {}}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn.disabled).toBeTruthy();
    });

    it('should disable the apply filter when form values are invalid', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 1,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {},
                }}
                dispatch={mockFn}
                pIsOpen
                pOnClose={() => {}}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );
        const originId = wrapper.queryByTestId('originId');
        fireEvent.change(originId, { target: { value: '123456,' } });
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn.disabled).toBeTruthy();
    });
    it('should validate location ids based on profile for origin Id', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 1,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {
                        preferences: [
                            {
                                parameter: 'DC',
                                values: [
                                    {
                                        field: 'id',
                                        value: '2055',
                                    },
                                ],
                            },
                            {
                                parameter: 'DC',
                                values: [
                                    {
                                        field: 'id',
                                        value: '6097',
                                    },
                                ],
                            },
                        ],
                    },
                }}
                dispatch={mockFn}
                pIsOpen
                pOnClose={() => {}}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );
        const originTypeDropdown = screen.getByTestId('originType');
        expect(originTypeDropdown).toBeDefined();
        fireEvent.click(originTypeDropdown);
        const dropdownMenuItem = screen.getByText('DC');
        fireEvent.click(dropdownMenuItem);

        const originId = wrapper.queryByTestId('originId');
        fireEvent.change(originId, { target: { value: '123456,2055,6097' } });
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
        expect(screen.getByText('DC - 123456 not part of the selected profile')).toBeDefined();
    });
    it('should validate location ids based on profile for destination id', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanSearchUS
                queryState={{
                    activeTabIndex: 1,
                    exceptionType: null,
                    filter: initialFilterState,
                    profile: {
                        preferences: [
                            {
                                parameter: 'DC',
                                values: [
                                    {
                                        field: 'id',
                                        value: '2055',
                                    },
                                ],
                            },
                            {
                                parameter: 'DC',
                                values: [
                                    {
                                        field: 'id',
                                        value: '6097',
                                    },
                                ],
                            },
                        ],
                    },
                }}
                dispatch={mockFn}
                pIsOpen
                pOnClose={() => {}}
                pStaticData={{ planTypes: ['test1', 'test2'] }}
            />,
        );
        const destinationTypeDropdown = screen.getByTestId('destinationType');
        expect(destinationTypeDropdown).toBeDefined();
        fireEvent.click(destinationTypeDropdown);
        const dropdownMenuItem = screen.getByText('DC');
        fireEvent.click(dropdownMenuItem);

        const destinationId = wrapper.queryByTestId('destinationId');
        fireEvent.change(destinationId, { target: { value: '123456,2055,6097' } });
        const confirmBtn = wrapper.queryByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
        expect(screen.getByText('DC - 123456 not part of the selected profile')).toBeDefined();
    });
});
