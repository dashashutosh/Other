import React, { useMemo, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { ReasonCodePickerModal, LoadActionsEnum, TripActionsEnum } from '@walmart/stride-ui-commons';
import { Alert } from '@walmart/living-design-sc-ui';
import { createPortal } from 'react-dom';
import usePlanActionsApiUS from '../../../hooks/usePlanActionsApiUS';
import { ERROR_CONTAINER_ID } from '../../../Constants';
import { getErrorText } from '../../../utils/CommonUtils';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;

function getReasonMessage(reasonInfo) {
    return `Cancelled : ${reasonInfo?.comment} (reason code : ${reasonInfo?.reasonCode})`;
}

const CancelPlan = ({
    pReasonCodes,
    pIsOpen,
    pSetsIsCancelModalOpen,
    pCheckedPlans,
    pSelectedRowDataMap,
    pActionSuccessCb,
    pIsAllTrips,
    pIsAllLoads,
    pOnCancelPlanSuccess,
}) => {
    const trans = localizeLang();
    const [sError, setsError] = useState('');
    const { handlePlanAction, handleTripAction } = usePlanActionsApiUS(pCheckedPlans);
    const reasonCodePickerModalTranslations = useMemo(
        () => ({
            selectReason: trans('actions.label.selectReasonCodeForCancellation'),
            enterComment: trans('actions.label.additionalComments'),
            cancelBtn: trans('action.cancel'),
            primaryActionBtn: trans('action.cancelLoad'),
        }),
        [trans],
    );
    const handleCloseCancelModal = useCallback(() => pSetsIsCancelModalOpen(false), []);
    const handleCancelLoadError = (err) => {
        if (err?.errors?.[0]?.errorIdentifiers) {
            const { details } = err.errors[0].errorIdentifiers;
            setsError(details?.errors);
        } else {
            setsError(err);
        }
        handleCloseCancelModal();
    };
    const handleCancelTripError = (err) => {
        if (err?.errors && err?.errors?.length && err?.errors[0]?.errorIdentifiers) {
            const { details } = err.errors[0].errorIdentifiers;
            if (details?.tripDetails?.errors?.length && details?.tripDetails?.errors[0]?.description) {
                setsError(details?.tripDetails?.errors);
            } else if (details?.planDetails?.errors?.length && details?.planDetails?.errors[0]?.description) {
                setsError(details?.planDetails?.errors);
            } else {
                setsError(details);
            }
        } else {
            setsError(err);
        }
        handleCloseCancelModal();
    };
    const handleCancelRelayTripError = (err) => {
        if (err?.errors && err?.errors?.length && err?.errors[0]?.errorIdentifiers) {
            const { details } = err.errors[0].errorIdentifiers;
            setsError(details?.errors);
        } else {
            setsError(err);
        }
        handleCloseCancelModal();
    };
    const handleCancelLoadSuccess = () => {
        handleCloseCancelModal();
        pOnCancelPlanSuccess(pIsAllTrips ? trans('msg.cancelTripSuccess') : trans('msg.cancelPlanUSSuccess'));
        pActionSuccessCb();
    };
    const handleLoadCancelConfirmation = useCallback(
        (reasonInfo) => {
            const reasonCode = getReasonMessage(reasonInfo);
            handlePlanAction(LoadActionsEnum.CANCEL.name, reasonCode, handleCancelLoadSuccess, handleCancelLoadError);
        },
        [handlePlanAction, handleCloseCancelModal],
    );

    const handleTripCancelConfirmation = useCallback(
        (reasonInfo) => {
            const reason = getReasonMessage(reasonInfo);
            const loadIds = [];
            const relayTrip = [];

            Object.values(pSelectedRowDataMap).forEach((row) => {
                loadIds.push(...row.plans.map((plan) => plan.planId));
                relayTrip.push(row.isRelayTrip);
            });

            const isRelayTrip = relayTrip[0];

            const params = { reason, loadIds };
            const handleError = isRelayTrip ? handleCancelRelayTripError : handleCancelTripError;
            handleTripAction(
                isRelayTrip ? TripActionsEnum.CANCEL_RELAY.name : TripActionsEnum.CANCEL.name,
                params,
                handleCancelLoadSuccess,
                handleError,
            );
        },
        [handleTripAction, pSelectedRowDataMap],
    );

    const getContentLabel = useCallback(() => {
        if (pIsAllLoads) {
            return trans('actions.label.loadCancelInfo');
        }
        if (pIsAllTrips) {
            return trans('actions.label.tripCancelInfo');
        }
        return (
            <ul>
                <li>{trans('actions.label.loadCancelInfo')}</li>
                <li>{trans('actions.label.tripCancelInfo')}</li>
            </ul>
        );
    }, [pIsAllLoads, pIsAllTrips]);
    const getTitleLabel = useCallback(() => {
        if (pIsAllLoads) {
            return `${trans('action.title.confirmLoadCancel')} ${trans('action.label.load')}?`;
        }
        if (pIsAllTrips) {
            return `${trans('action.title.confirmLoadCancel')} ${trans('action.label.trip')}?`;
        }
        return `${trans('action.title.confirmLoadCancel')} ${trans('action.label.plan')}?`;
    }, [pIsAllLoads, pIsAllTrips]);
    return (
        <>
            {sError
                ? createPortal(
                      <Alert
                          variant="error"
                          data-testid="cancelFailAlert"
                          onClose={() => {
                              setsError('');
                          }}
                      >
                          {getErrorText(sError, trans, { concatDesc: true, rawString: false })}
                      </Alert>,
                      document.getElementById(ERROR_CONTAINER_ID),
                  )
                : null}
            {pIsOpen && (
                <ReasonCodePickerModal
                    pOpen={pIsOpen}
                    pTitle={getTitleLabel()}
                    pModalContentInfo={getContentLabel()}
                    pReasonCodes={pReasonCodes}
                    pOnConfirm={pIsAllTrips ? handleTripCancelConfirmation : handleLoadCancelConfirmation}
                    pOnCancel={handleCloseCancelModal}
                    pTranslations={reasonCodePickerModalTranslations}
                />
            )}
        </>
    );
};
const propTypes = {
    pReasonCodes: PropTypes.arrayOf(PropTypes.shape({})),
    pIsOpen: PropTypes.bool.isRequired,
    pSetsIsCancelModalOpen: PropTypes.func.isRequired,
    pCheckedPlans: PropTypes.arrayOf(PropTypes.string).isRequired,
    pSelectedRowDataMap: PropTypes.shape({}).isRequired,
    pActionSuccessCb: PropTypes.func.isRequired,
    pOnCancelPlanSuccess: PropTypes.func.isRequired,
    pIsAllTrips: PropTypes.bool,
    pIsAllLoads: PropTypes.bool,
};
CancelPlan.propTypes = propTypes;
CancelPlan.defaultProps = {
    pReasonCodes: [],
    pIsAllLoads: false,
    pIsAllTrips: false,
};
export default CancelPlan;
