import React, { useMemo, useState } from 'react';
import PropTypes, { string } from 'prop-types';
import { AutoTenderDrawer, ToastAction } from '@walmart/stride-ui-commons';
import { Alert } from '@walmart/living-design-sc-ui';
import { useHistory } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { getAPIParams, getAutoEntityAPIParams } from '../../../service/TripAPI';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { getErrorText } from '../../../utils/CommonUtils';
import { ERROR_CONTAINER_ID } from '../../../Constants';
const { localizeLang } = LocalizeLang.default;

const AutoTender = (props) => {
    const { pOnClose, pActionRow, pListLocationTypes, pPlanIds, pIsOpen, pEnableSplitLoad, pIsODPairSame } = props;
    const history = useHistory();
    const { prefLang, currentMarket, userInfo } = AppUtils.get();
    const trans = localizeLang();
    const [sBulkSuccessMessage, setsBulkSuccessMessage] = useState('');
    const [sError, setsError] = useState('');
    const APIParamsAutoComplete = getAutoEntityAPIParams(currentMarket, prefLang.current, userInfo);
    const APIParams = getAPIParams(currentMarket, prefLang.current, userInfo);
    const labels = useMemo(
        () => ({
            drawerTitle: trans('auto.tender.drawer.title'),
            buttonSave: trans('auto.tender.button'),
            buttonCancel: trans('button.cancel'),
            originLocations: trans('label.origin.locations'),
            plannedPickupdate: trans('label.planned.pickup.date'),
            locationType: trans('label.location.type'),
            locationId: trans('label.location.id'),
            finalDestination: trans('label.final.destination'),
            singleSuccessMessage: trans('auto.tender.single.success.message'),
            bulkSuccessMessage: trans('msg.autoTenderSaveSuccess'),
            bulkUploadLinkText: trans('label.bulk.history'),
            errorMessage: trans('auto.tender.error.message'),
            auto: trans('auto.tender.carrier.assignmet.auto'),
            manual: trans('auto.tender.carrier.assignmet.manual'),
            carrierAssignment: trans('label.carrier.assignment'),
            carrierScac: trans('label.carrier.scac'),
            multiple: trans('label.location.multiple'),
            retry: trans('button.retry'),
            locationApiError: trans('API.error.invalid'),
        }),
        [prefLang.current],
    );
    const onBulkSuccess = () => {
        setsBulkSuccessMessage(`${pPlanIds?.length} ${labels.bulkSuccessMessage}`);
        pOnClose();
    };
    const onSingleSuccess = () => {
        setsSingleSuccess(true);
        pOnClose();
    };
    return (
        <>
            {pIsOpen && (
                <AutoTenderDrawer
                    pLabels={labels}
                    pOnClose={pOnClose}
                    pOnSingleSuccess={onSingleSuccess}
                    pOnBulkSuccess={onBulkSuccess}
                    pOriginLocation={{
                        value: `${pActionRow?.originType} - ${pActionRow?.originId}`,
                        id: pActionRow?.originId || '',
                        locationType: pActionRow?.originType || '',
                    }}
                    pFinalDestination={{
                        value: `${pActionRow?.destinationType} - ${pActionRow?.destinationId}`,
                        id: pActionRow?.destinationId || '',
                        locationType: pActionRow?.destinationType || '',
                    }}
                    pListLocationTypes={pListLocationTypes}
                    pApiConfig={APIParams}
                    pAutoCompleteConfig={APIParamsAutoComplete}
                    pUseAppContext={AppUtils.get}
                    pPlanIds={pPlanIds}
                    pOnError={(error) => setsError(error)}
                    pPickupDates={{
                        originPickupDate: pActionRow?.plannedStartTime,
                    }}
                    pShowSplitLoad={pEnableSplitLoad}
                    pProcessBulk
                    pIsMultiple={!pIsODPairSame && pPlanIds?.length > 1}
                />
            )}

            {sError
                ? createPortal(
                      <Alert
                          data-testid="autoTenderFailureAlert"
                          variant="error"
                          onClose={() => {
                              setsError('');
                          }}
                      >
                          {getErrorText(sError, trans)}
                      </Alert>,
                      document.getElementById(ERROR_CONTAINER_ID),
                  )
                : null}
            {sBulkSuccessMessage && (
                <ToastAction
                    pVariant="positive"
                    pLinkText={labels.bulkUploadLinkText}
                    pText={sBulkSuccessMessage}
                    pOnLinkClick={() => {
                        history.push({ pathname: '/bulkupload/history', state: { bulkUpdateHistory: true } });
                    }}
                    pToastTimer={5000}
                    pOnClose={() => {
                        setsBulkSuccessMessage('');
                    }}
                />
            )}
        </>
    );
};
const propTypes = {
    pOnClose: PropTypes.func.isRequired,
    pActionRow: PropTypes.shape({
        originType: PropTypes.string,
        originId: PropTypes.string,
        destinationType: PropTypes.string,
        destinationId: PropTypes.string,
        planId: PropTypes.string,
        plannedStartTime: PropTypes.string,
    }).isRequired,
    pListLocationTypes: PropTypes.arrayOf(string).isRequired,
    pPlanIds: PropTypes.arrayOf(string).isRequired,
    pIsOpen: PropTypes.bool.isRequired,
    pEnableSplitLoad: PropTypes.bool,
    pIsODPairSame: PropTypes.bool,
};
AutoTender.propTypes = propTypes;
AutoTender.defaultProps = {
    pNumberCheckedPlans: 0,
    pEnableSplitLoad: false,
    pIsODPairSame: false,
};
export default AutoTender;
