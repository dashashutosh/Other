import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { cleanup, fireEvent, render, screen } from '../../../../utils/test-utils';
import { contextMock, transformedConfigResponseMock } from './mocks/USMocks';
import PlanTableUS from '../PlanTableUS';
import staticData from './mocks/MdmLtmStaticData.mock.json';
import TripSharedService from '../../../../service/TripSharedService';
import PlanSearchAggregatesUS from './mocks/PlanSearchAggregrateUS.mock.json';
import PlansWithDeliveredStatusUS, { loadDetails } from './mocks/PlanSearchAggregateDeliveredUS.mock';
import CmsConfig from './mocks/CmsConfig.json';
import { tripStaticDataMock } from '../../../../service/__tests__/mocks/mocks/TripMapper.mock';
import { useAPI } from '@walmart/stride-ui-commons';

const mockPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockPush,
    }),
}));
const API_GATEWAY_PREFIX = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
        res(ctx.json(PlanSearchAggregatesUS)),
    ),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(CmsConfig))),
);
const permissionsMock = {
    canEditTrip: true,
};

jest.mock('@walmart/stride-ui-commons', () => ({
    ...jest.requireActual('@walmart/stride-ui-commons'),
    useAPI: jest.fn(),
}));
jest.setTimeout(15000);
const qs = {
    page: 1,
    sortField: 'PLAN_CREATED_TIME',
    sortMode: 'ASC',
    exceptionType: null,
    filter: {
        fromDate: '',
        tillDate: '',
        after: '',
        before: '',
        on: '',
        dateType: '',
        periodType: '',
        loadType: [],
        planType: '',
        status: [],
        carrierId: '',
        scacCode: '',
    },
    profile: {},
    activeTabIndex: 0,
    globalSearchData: null,
    timeHorizon: 48,
    groupBy: 'TRIP',
};

afterEach(() => {
    server.resetHandlers();
    cleanup();
});

afterAll(() => server.close());

beforeAll(() => {
    TripSharedService.setPageLoadSettings({ showUSColumns: true });
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
    TripSharedService.setTripStaticData(tripStaticDataMock);
    TripSharedService.setFeatureFlags({ showExport: true });
    server.listen();
    useAPI.mockImplementation((fn) => ({
        callAPI: jest.fn(),
    }));
});

describe('Table US', () => {
    it('should render without crashing', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableUS
                queryState={qs}
                pUserPerm={permissionsMock}
                dispatch={mockFn}
                pIsLoading={false}
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pIsActive
                pPhaseCounts={() => {}}
                pStaticData={staticData}
                mdmLocationTypes={{}}
                pSetsIsSearchFilterModalOpen={() => {}}
            />,
        );

        expect(wrapper).toBeDefined();
    });

    it('should render with plan export icon when showExport flag is true', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableUS
                queryState={qs}
                pUserPerm={permissionsMock}
                dispatch={mockFn}
                pIsLoading={false}
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pIsActive
                pPhaseCounts={() => {}}
                pStaticData={staticData}
                mdmLocationTypes={{}}
                pSetsIsSearchFilterModalOpen={() => {}}
            />,
        );
        const downloadIcon = wrapper.getByTestId('plan-export');
        expect(downloadIcon).toBeDefined();
    });

    it('should not render with plan export icon when showExport flag is false', () => {
        const mockFn = jest.fn();
        TripSharedService.setFeatureFlags({ showExport: false });
        const wrapper = render(
            <PlanTableUS
                queryState={qs}
                pUserPerm={permissionsMock}
                dispatch={mockFn}
                pIsLoading={false}
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pIsActive
                pPhaseCounts={() => {}}
                pStaticData={staticData}
                mdmLocationTypes={{}}
                pSetsIsSearchFilterModalOpen={() => {}}
            />,
        );
        const downloadIcon = wrapper.queryByTestId('plan-export');
        expect(downloadIcon).toBeNull();
    });
});

describe('Select checkbox and select all test cases', () => {
    it('should render selectall checkbox', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableUS
                queryState={qs}
                pUserPerm={permissionsMock}
                dispatch={mockFn}
                pIsLoading={false}
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pIsActive
                pPhaseCounts={() => {}}
                pStaticData={staticData}
                mdmLocationTypes={{}}
                pSetsIsSearchFilterModalOpen={() => {}}
            />,
        );
        const selectAll = wrapper.getByTestId('selectAll');
        expect(selectAll).toBeDefined();
    });

    it('should render stop sequence audit', async () => {
        TripSharedService.setFeatureFlags({ showStopSequenceAudit: true });
        useAPI.mockImplementation((fn) => ({
            callAPI: jest.fn().mockImplementation((req, res) => res(PlansWithDeliveredStatusUS)),
        }));
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}getLoadDetails/loadDetails`, (req, res, ctx) => res(ctx.json(loadDetails))),
        );

        render(
            <PlanTableUS
                queryState={qs}
                pUserPerm={permissionsMock}
                dispatch={jest.fn()}
                pIsLoading={false}
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pIsActive
                pPhaseCounts={() => {}}
                pStaticData={staticData}
                mdmLocationTypes={{}}
                pSetsIsSearchFilterModalOpen={() => {}}
                pIsGlobalSearchFlow={jest.fn()}
            />,
        );
        const firstCheckBox = await screen.findByTestId('dt-chkbx-0-22527129');
        fireEvent.click(firstCheckBox);

        const auditButton = await screen.findByText('Audit');
        expect(auditButton).toBeDefined();
        fireEvent.click(auditButton);

        const dialog = await screen.findByRole('dialog');
        const planned = await screen.findByText('Planned');
        const actual = await screen.findByText('Actual');

        expect(dialog).toBeDefined();
        expect(planned).toBeDefined();
        expect(actual).toBeDefined();
    });

    it('should render stop sequence audit when useStopSequenceV2MapperForTripDetails is true', async () => {
        TripSharedService.setFeatureFlags({
            showStopSequenceAudit: true,
            useStopSequenceV2MapperForTripDetails: true,
        });
        useAPI.mockImplementation((fn) => ({
            callAPI: jest.fn().mockImplementation((req, res) => res(PlansWithDeliveredStatusUS)),
        }));
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}getLoadDetails/loadDetails`, (req, res, ctx) => res(ctx.json(loadDetails))),
        );

        render(
            <PlanTableUS
                queryState={qs}
                pUserPerm={permissionsMock}
                dispatch={jest.fn()}
                pIsLoading={false}
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pIsActive
                pPhaseCounts={() => {}}
                pStaticData={staticData}
                mdmLocationTypes={{}}
                pSetsIsSearchFilterModalOpen={() => {}}
                pIsGlobalSearchFlow={jest.fn()}
            />,
        );
        const firstCheckBox = await screen.findByTestId('dt-chkbx-0-22527129');
        fireEvent.click(firstCheckBox);

        const auditButton = await screen.findByText('Audit');
        expect(auditButton).toBeDefined();
        fireEvent.click(auditButton);

        const dialog = await screen.findByRole('dialog');
        const planned = await screen.findByText('Planned');
        const actual = await screen.findByText('Actual');

        expect(dialog).toBeDefined();
        expect(planned).toBeDefined();
        expect(actual).toBeDefined();
    });
});
