import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { InlineAlert } from '@walmart/stride-ui-commons';
import { DataLabel, CaretDownIcon, EditIcon, CheckIcon, CaretUpIcon } from '@walmart/living-design-sc-ui';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
const { Popover, Grid, ListItem, List, ListItemText } = MaterialUiCore,
    { createMuiTheme, ThemeProvider } = MaterialUiCore,
    { makeStyles } = MaterialUiCore;
const useStyles = makeStyles({
    infoCardDataLabel: {
        '& .ld-sc-ui-data-key-standard': {
            color: '#74767c',
        },
        '& div': {
            width: '100px',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
        },
        cursor: 'pointer',
    },
    labelContainer: {
        flexWrap: 'unset !important',
    },
    infoCardDisabled: {
        '& .ld-sc-ui-data-value.ld-sc-ui-data-value-undefined.ld-sc-ui-data-value-standard.ld-sc-ui-data-value-standard':
            {
                color: 'lightgrey !important',
            },
        '& div': {
            width: '100px',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
        },
        pointerEvents: 'none',
        color: 'lightgrey',
        cursor: 'not-allowed',
    },
    customListRoot: {
        display: 'inline-flex',
        margin: '4px 0',
        padding: '0 16px',
    },
    dividerCustom: {
        backgroundColor: '#e3e4e5',
        height: 'auto',
        margin: '4px',
        width: '1px',
    },
    arrowIcon: {
        marginTop: '18px',
        cursor: 'default',
    },
    arrowIconDis: {
        marginTop: '18px',
        cursor: 'default',
        fill: 'lightgrey',
    },
    hyperLink: {
        textDecoration: 'underline',
        cursor: 'pointer',
        paddingLeft: '15px',
    },
    listContainer: {
        maxHeight: '500px',
        borderRadius: '8px',
        overflow: 'hidden',
    },
    list: {
        overflowY: 'auto',
        padding: 0,
    },
    firstfixedRow: {
        fontSize: '14px',
        textAlign: 'center',
        height: '59px',
        borderBottom: '1px solid #E0E0E0',
    },
    lastfixedRow: {
        height: '70px',
    },
    'MuiTypography-body1': {
        fontSize: '16px',
    },
    tfixedRow: {
        height: '70px',
    },
    buttonText: {
        fontSize: '16px',
        paddingLeft: '0.5rem',
    },
    listItem: {
        cursor: 'pointer',
        '&:hover': {
            backgroundColor: '#e6f7ff',
        },
        height: '55px',
    },
    selectedListItem: {
        backgroundColor: '#F0F7FD',
        height: '55px',
    },
    tickIcon: {
        marginLeft: 'auto',
        fill: '#0071DC',
    },
    scrollableList: {
        maxHeight: '325px',
        overflowY: 'auto',
    },
    popoverRoot: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    boldPrimaryText: {
        fontWeight: 'bold',
        fontSize: '16px',
        lineHeight: '22px',
        letterSpacing: '0px',
        textAlign: 'left',
    },
    labelText: {
        marginBottom: '0px',
    },
    primaryText: {
        fontSize: '16px',
    },
    secondaryText: {
        fontSize: '12px',
    },
});
const CustomList = ({
    pData,
    pOnSelected,
    pManagenav,
    pDateType,
    pFirstRow,
    pKey,
    pText,
    pSelected,
    pWidth,
    pVertical,
    pEmptyName,
    pHorizontal,
    pDefault,
    pDataTestId,
    pDisabled,
}) => {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [sPSelected, setsPSelected] = useState(pSelected);
    const [sArrowClick, setsArrowClick] = useState(false);
    const classes = useStyles();
    const theme = createMuiTheme({
        typography: {
            fontFamily: 'Bogle',
        },
    });
    const listContainerWidth = `${pWidth}px`;

    useEffect(() => {
        if (pSelected) {
            setsPSelected(pSelected);
        }
    }, [pSelected]);

    useEffect(() => {
        if (pFirstRow) {
            const targetName = pDefault;
            const index = pData.findIndex((item) => item.name === targetName);
            setsPSelected(pData && pData.length > 0 ? pSelected : pData[index]);
        } else {
            const selected = pData.find((item) => item.key === pSelected?.key);
            setsPSelected(pData && pData.length > 0 ? selected : null);
        }
    }, [pData, pSelected]);
    const handleClick = (event) => {
        if (anchorEl) setAnchorEl(null);
        else setAnchorEl(event.currentTarget);
    };
    const openList = (event) => {
        setsArrowClick(false);
        handleClick(event);
    };
    const openListArrow = (event) => {
        setsArrowClick(true);
        handleClick(event);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    const open = Boolean(anchorEl);
    const onChangeSelection = (item) => {
        pOnSelected(item);
        handleClose();
    };
    return (
        <>
            <ThemeProvider theme={theme}>
                <div className={classes.dividerCustom} />
                <div className={classes.customListRoot}>
                    <Grid container direction="row" alignItems="center" className={classes.labelContainer}>
                        <DataLabel
                            keyName={pKey}
                            value={sPSelected?.name || pEmptyName}
                            size="standard"
                            className={`${
                                pFirstRow && pDisabled ? classes.infoCardDisabled : classes.infoCardDataLabel
                            } pl-0`}
                            data-testid={pDataTestId}
                            handleClick={openList}
                        />
                        <div
                            className={!pDisabled ? classes.arrowIcon : classes.arrowIconDis}
                            data-testid="dropArrow"
                            role="presentation"
                            onClick={!pDisabled ? openListArrow : ''}
                        >
                            {!anchorEl ? <CaretDownIcon size="medium" /> : <CaretUpIcon size="medium" />}
                        </div>
                    </Grid>
                </div>
                <Popover
                    open={open}
                    anchorEl={anchorEl}
                    onClose={handleClose}
                    anchorOrigin={{
                        vertical: 'center',
                        horizontal: 'left',
                    }}
                    transformOrigin={{
                        vertical: parseInt(pVertical, 10),
                        horizontal: sArrowClick ? parseInt(pHorizontal?.[1], 10) : parseInt(pHorizontal?.[0], 10),
                    }}
                    id="proileModal"
                    data-testid="custom-list-popover"
                >
                    <div
                        className={classes.listContainer}
                        style={{
                            width: listContainerWidth,
                        }}
                    >
                        <List name="ItemSelectioOptions" className={classes.list}>
                            {pFirstRow && (
                                <ListItem className={classes.firstfixedRow}>
                                    <InlineAlert
                                        pClassName="w-100"
                                        data-testid="warning"
                                        pVariant="info"
                                        pMessage={
                                            <p className={classes.labelText}>
                                                {pText.optionsSet}
                                                <b>{pDateType}</b>
                                            </p>
                                        }
                                    />
                                </ListItem>
                            )}
                            <div className={classes.scrollableList}>
                                {pData &&
                                    pData.map((e, i) => (
                                        <ListItem
                                            data-testid={`select-item-${i}`}
                                            button
                                            onClick={() => onChangeSelection(e)}
                                            divider
                                            className={
                                                e?.name === sPSelected?.name
                                                    ? classes.selectedListItem
                                                    : classes.listItem
                                            }
                                        >
                                            <ListItemText
                                                className={classes.litext}
                                                primary={
                                                    e?.name === sPSelected?.name ? (
                                                        <span className={classes.boldPrimaryText}>{e.name}</span>
                                                    ) : (
                                                        e.name
                                                    )
                                                }
                                                secondary={pFirstRow ? e.preferences : ''}
                                                primaryTypographyProps={{
                                                    className: classes.primaryText,
                                                }}
                                                secondaryTypographyProps={{
                                                    className: classes.secondaryText,
                                                }}
                                            />
                                            {e?.name === sPSelected?.name && (
                                                <CheckIcon size="small" className={classes.tickIcon} />
                                            )}
                                        </ListItem>
                                    ))}
                            </div>
                            <ListItem className={classes.lastfixedRow} onClick={() => pManagenav()}>
                                <span className={classes.hyperLink} data-testid="edit">
                                    <EditIcon size="small" />
                                    <span className={classes.buttonText}>{pText.editText}</span>
                                </span>
                            </ListItem>
                        </List>
                    </div>
                </Popover>
            </ThemeProvider>
        </>
    );
};
CustomList.propTypes = {
    pData: PropTypes.arrayOf(PropTypes.objectOf).isRequired,
    pOnSelected: PropTypes.func.isRequired,
    pManagenav: PropTypes.func.isRequired,
    pDateType: PropTypes.string.isRequired,
    pFirstRow: PropTypes.bool.isRequired,
    pKey: PropTypes.string.isRequired,
    pSelected: PropTypes.objectOf.isRequired,
    pWidth: PropTypes.number.isRequired,
    pVertical: PropTypes.string.isRequired,
    pHorizontal: PropTypes.string.isRequired,
    pDefault: PropTypes.string.isRequired,
    pDataTestId: PropTypes.string.isRequired,
    pDisabled: PropTypes.bool.isRequired,
    pEmptyName: PropTypes.string.isRequired,
    pText: PropTypes.objectOf.isRequired,
};
export default CustomList;
