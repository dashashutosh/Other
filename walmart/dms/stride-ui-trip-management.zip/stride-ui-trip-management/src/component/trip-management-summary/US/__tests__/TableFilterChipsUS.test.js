import React from 'react';
import { AppUtils } from '@gscope-mfe/app-bridge';
import TableFilterChipsUS from '../TableFilterChipsUS';
import { render, fireEvent } from '../../../../utils/test-utils';
import { contextMock } from './mocks/USMocks';
import TripSharedService from '../../../../service/TripSharedService';
import { initialFilterState, PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../../utils/actions/PlanTableQueryActions';

beforeAll(() => {
    TripSharedService.setPageLoadSettings({ showUSColumns: true });
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('TableFilterChipsUS US', () => {
    it('should render without crashing', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <TableFilterChipsUS
                queryState={{
                    activeTabIndex: 0,
                    filter: {
                        ...initialFilterState,
                        driverId: '456',
                        trailerId: '6898',
                        originType: 'SPLR',
                    },
                }}
                dispatch={mockFn}
            />,
        );

        expect(wrapper.queryByTestId('chip-originType')).toBeDefined();
        expect(wrapper.queryByTestId('chip-trailerId')).toBeDefined();
        expect(wrapper.queryByTestId('chip-driverId')).toBeDefined();
    });

    it('should display more icon', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <TableFilterChipsUS
                queryState={{
                    activeTabIndex: 0,
                    filter: {
                        ...initialFilterState,
                        driverId: '456',
                        trailerId: '6898',
                        originType: 'SPLR',
                        originId: '690017',
                        originCity: 'atlanta',
                        originState: 'GA',
                    },
                }}
                dispatch={mockFn}
            />,
        );
        expect(wrapper.getByTestId('moreIcon')).toBeDefined();
    });

    it('should invoke dispatch function with right parameters on chip click', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <TableFilterChipsUS
                queryState={{
                    activeTabIndex: 0,
                    filter: {
                        ...initialFilterState,
                        driverId: '456',
                        trailerId: '6898',
                        originType: 'SPLR',
                        originId: '690017',
                    },
                }}
                dispatch={mockFn}
            />,
        );
        expect(wrapper.getByTestId('chip-driverId')).toBeDefined();
        const chip = wrapper.getByTestId('chip-driverId').querySelector('svg');
        fireEvent.click(chip.parentElement);
        expect(mockFn).toHaveBeenCalledWith({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_FILTER,
            filter: {
                ...initialFilterState,
                driverId: '',
                trailerId: '6898',
                originType: 'SPLR',
                originId: '690017',
            },
        });
    });

    it('should remove the chip on chip click', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <TableFilterChipsUS
                queryState={{
                    activeTabIndex: 0,
                    filter: {
                        ...initialFilterState,
                        driverId: '456',
                        trailerId: '6898',
                        originType: 'SPLR',
                        originId: '690017',
                    },
                }}
                dispatch={mockFn}
            />,
        );
        expect(wrapper.getByTestId('chip-driverId')).toBeDefined();
        const chip = wrapper.getByTestId('chip-driverId').querySelector('svg');
        fireEvent.click(chip);
        expect(mockFn).toHaveBeenCalledWith({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_FILTER,
            filter: {
                ...initialFilterState,
                trailerId: '6898',
                originType: 'SPLR',
                originId: '690017',
            },
        });
    });
});
