import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import ReviewAndApprove from '../ReviewAndApprove';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from './mocks/USMocks';

const mockPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockPush,
    }),
}));

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('Review And Approve', () => {
    it('should render without crashing', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <ReviewAndApprove
                pIsOpen
                pOnClose={mockFn}
                pActionRow={{
                    originType: '',
                    originId: '',
                    destinationType: '',
                    destinationId: '',
                    planId: '',
                }}
                pListLocationTypes={[]}
                pPlanIds={[]}
                pPickupDates={{
                    originPickupDate: '2/12/2023',
                }}
            />,
        );
        expect(wrapper).toBeDefined();
    });

    it('should check origin location and final destination', () => {
        const mockFn = jest.fn();
        render(
            <ReviewAndApprove
                pIsOpen
                pOnClose={mockFn}
                pActionRow={{
                    originType: 'STORE',
                    originId: '32164',
                    destinationType: 'STORE',
                    destinationId: '789456',
                    planId: '12345',
                }}
                pListLocationTypes={[]}
                pPlanIds={[]}
                pPickupDates={{
                    originPickupDate: '2/12/2023',
                }}
            />,
        );
        const originLocation = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocation).toBeDefined();
        expect(originLocation.value).toBe('STORE - 32164');

        const finalDestination = screen.getByTestId('locationId-destination').querySelector('input');
        expect(finalDestination).toBeDefined();
        expect(finalDestination.value).toBe('STORE - 789456');
    });

    it.skip('should check review & approve button disable with empty fields', () => {
        const mockFn = jest.fn();
        render(
            <ReviewAndApprove
                pIsOpen
                pOnClose={mockFn}
                pActionRow={{
                    originType: 'STORE',
                    originId: '32164',
                    destinationType: 'STORE',
                    destinationId: '789456',
                    planId: '12345',
                }}
                pListLocationTypes={[]}
                pPlanIds={[]}
                pPickupDates={{
                    originPickupDate: '2/12/2023',
                }}
            />,
        );
        const originLocation = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocation).toBeDefined();
        fireEvent.change(originLocation, { target: { value: '' } });
        expect(originLocation.value).toBe('');

        const finalDestination = screen.getByTestId('locationId-destination').querySelector('input');
        expect(finalDestination).toBeDefined();
        fireEvent.change(finalDestination, { target: { value: '' } });
        expect(finalDestination.value).toBe('');

        const originPickupDate = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(originPickupDate).toBeDefined();
        fireEvent.change(originPickupDate, { target: { value: '' } });
        expect(originPickupDate.value).toBe('');
        expect(screen.getByTestId('review-approve-button').getAttribute('disabled')).toBe(null);
    });

    it('should check review & approve button enable with empty fields', () => {
        const mockFn = jest.fn();
        render(
            <ReviewAndApprove
                pIsOpen
                pOnClose={mockFn}
                pActionRow={{
                    originType: 'STORE',
                    originId: '32164',
                    destinationType: 'STORE',
                    destinationId: '789456',
                    planId: '12345',
                }}
                pListLocationTypes={[]}
                pPlanIds={[]}
                pPickupDates={{
                    originPickupDate: '2/12/2023',
                }}
            />,
        );
        const originLocation = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocation).toBeDefined();
        expect(originLocation.value).toBe('STORE - 32164');

        const finalDestination = screen.getByTestId('locationId-destination').querySelector('input');
        expect(finalDestination).toBeDefined();
        expect(finalDestination.value).toBe('STORE - 789456');

        const originPickupDate = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(originPickupDate).toBeDefined();
        fireEvent.change(originPickupDate, { target: { value: '08/05/2023' } });
        expect(originPickupDate.value).toBe('08/05/2023');

        const submitBtn = screen.getByTestId('review-approve-button');
        expect(submitBtn).toBeDefined();
    });
});
