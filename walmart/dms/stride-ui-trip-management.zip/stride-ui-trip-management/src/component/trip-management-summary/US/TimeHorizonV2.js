import React, { useState, useEffect, useMemo } from 'react';
import { FetchUserDetails, getEnvironment } from '@walmart/stride-ui-commons';
import PropTypes from 'prop-types';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import {
    companyName,
    USER_PREF_PAGE_TIME_HORIZON,
    STRIDE_UI_TM_PROFILE_LINK_MFE,
    defaultDeliveredDays,
    STRIDE_UI_TM_PROFILE_LINK_NON_MFE,
} from '../../../Constants';
import TripSharedService from '../../../service/TripSharedService';
import CustomList from './CustomList';
import { doesMatchPreferences, getDateFromDays, transformDate, transformOptionsTimeHorizon } from './DataModelsUS';
import DateTypeUiEnum from '../../model/dateTypeUiEnum';
import axios from '../../../axios';
import { AppUtils, Utilities } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { setUserPreference } = Utilities,
    { localizeLang } = LocalizeLang.default;
const USER_PREF_FAV_BG_KEY = 'tripManagementTHSelected';
const propTypes = {
    dispatch: PropTypes.func.isRequired,
    pPageStaticData: PropTypes.string.isRequired,
    pCmsData: PropTypes.objectOf.isRequired,
    pDisabled: PropTypes.bool.isRequired,
    pHistory: PropTypes.func.isRequired,
    queryState: {
        profile: PropTypes.objectOf.isRequired,
    }.isRequired,
};

/**
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */

const TimeHorizonV2 = ({ dispatch, pPageStaticData, pCmsData, pDisabled, pHistory, queryState }) => {
    const trans = localizeLang();
    const { currentMarket, prefLang, setloading, userInfo } = AppUtils.get();
    const env = getEnvironment({
        hostname: window.location.hostname,
    });
    const USER_PREF_PAGE_NAME = `${currentMarket}_${env}_${USER_PREF_PAGE_TIME_HORIZON}`;
    const sFirstRow = true;
    const [sTHData, setsTHData] = useState(() => []);
    const [sDayCountDel, setsDayCountDel] = useState(defaultDeliveredDays);
    const [sDateType, setsDateType] = useState();

    const timeHorizonValue = useMemo(() => {
        if (queryState?.timeHorizon) {
            return queryState.timeHorizon;
        }
    }, [queryState?.timeHorizon]);
    const onClickManageProfile = () => {
        pHistory.push({
            pathname: TripSharedService.getFeatureFlags()?.hasTMPMigratedToMFE
                ? STRIDE_UI_TM_PROFILE_LINK_MFE
                : STRIDE_UI_TM_PROFILE_LINK_NON_MFE,
        });
    };
    const getUserTH = () => {
        FetchUserDetails(false, null, null, companyName, currentMarket?.toUpperCase(), axios, prefLang.current)
            .then((res) => {
                if (res?.tripManagementProfile) {
                    if (res.isUpdateRequired) {
                        setsTHData(res.tripManagementProfile);
                    }
                } else {
                    const payload = {
                        name: trans('type.timehorizon.default'),
                        preferences: transformDate('Past: All days - Future: All days', trans, pCmsData),
                        dayCount: defaultDeliveredDays,
                        dayCountDel: getDateFromDays(parseInt(sDayCountDel, 10)),
                        dateType: 'PLANNED_START_DATE',
                    };
                    dispatch({
                        type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_TIME_HORIZON,
                        timeHorizon: payload,
                    });
                }
                setloading(false);
            })
            .catch(() => {
                setloading(false);
            });
    };
    const setUserPref = async (pref) => {
        const payload = {
            pageName: USER_PREF_PAGE_NAME,
            key: USER_PREF_FAV_BG_KEY,
            value: pref,
        };
        await setUserPreference(payload);
    };
    const onSelectTH = (timeHorizon) => {
        const payload = {
            ...timeHorizon,
            dayCount: parseInt(sDayCountDel, 10),
            dayCountDel: getDateFromDays(parseInt(sDayCountDel, 10)),
            dateType: sDateType,
        };
        if (pCmsData) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_TIME_HORIZON,
                timeHorizon: payload,
            });
            setUserPref(payload);
        }
    };
    useEffect(() => {
        if (prefLang?.current) {
            const limit = pCmsData;
            if (pPageStaticData && pCmsData) {
                if (TripSharedService?.getFeatureFlags()?.showTimeHorizonV2) {
                    const defTh = {
                        name: `${trans('type.timehorizon.past')} - ${trans('type.timehorizon.future')}`,
                        preferences: transformDate(
                            `${trans('type.timehorizon.past')} - ${trans('type.timehorizon.future')}`,
                            trans,
                            limit,
                        ),
                    };
                    const userPref = JSON.parse(
                        localStorage.getItem(`ngStorage-preferences_${userInfo.loggedInUserName}`),
                    );
                    if (userPref && userPref?.[USER_PREF_PAGE_NAME]) {
                        const tripManagementTH = {
                            ...(userPref?.[USER_PREF_PAGE_NAME]?.tripManagementUserTimeHorizons || {}),
                        };
                        const defaultTH = userPref?.[USER_PREF_PAGE_NAME]?.tripManagementTHSelected;
                        if (limit) {
                            if (tripManagementTH?.timeHorizons?.length !== 0) {
                                const list = transformOptionsTimeHorizon(tripManagementTH?.timeHorizons, trans, limit);
                                const defExistinList = doesMatchPreferences(defaultTH || defTh, list);
                                setsTHData(list);
                                setsDayCountDel(tripManagementTH?.dayCount);
                                setsDateType(tripManagementTH?.dateType);
                                if (tripManagementTH?.timeHorizons?.[0] && !defExistinList) {
                                    const payload = {
                                        ...list?.[0],
                                        dayCount: parseInt(tripManagementTH?.dayCount, 10),
                                        dayCountDel: getDateFromDays(
                                            parseInt(
                                                tripManagementTH?.dayCount
                                                    ? tripManagementTH?.dayCount
                                                    : defaultDeliveredDays,
                                                10,
                                            ),
                                        ),
                                        dateType: tripManagementTH?.dateType,
                                    };
                                    dispatch({
                                        type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_TIME_HORIZON,
                                        timeHorizon: payload,
                                    });
                                } else if (defExistinList) {
                                    const payload = {
                                        ...(defaultTH || defTh),
                                        dayCount: parseInt(tripManagementTH?.dayCount, 10),
                                        dayCountDel: getDateFromDays(
                                            parseInt(
                                                tripManagementTH?.dayCount
                                                    ? tripManagementTH?.dayCount
                                                    : defaultDeliveredDays,
                                                10,
                                            ),
                                        ),
                                        dateType: tripManagementTH?.dateType,
                                    };
                                    dispatch({
                                        type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_TIME_HORIZON,
                                        timeHorizon: payload,
                                    });
                                }
                            } else {
                                getUserTH();
                            }
                        }
                    } else {
                        getUserTH();
                    }
                }
            }
        }
    }, [pPageStaticData, prefLang?.current, pCmsData]);
    return (
        <CustomList
            pData={sTHData}
            pKey={trans('type.config.timehorizon')}
            pEmptyName={trans('type.timehorizon.default')}
            pDefault={trans('type.timehorizon.default')}
            pText={{
                editText: trans('edit.text'),
                optionsSet: trans('th.basis'),
            }}
            pSelected={timeHorizonValue}
            pOnSelected={onSelectTH}
            pManagenav={onClickManageProfile}
            pDateType={
                !sDateType || sDateType === DateTypeUiEnum.PLANNED_START_DATE.name
                    ? trans(DateTypeUiEnum.PLANNED_START_DATE.desc)
                    : trans(DateTypeUiEnum.PLANNED_END_DATE.desc)
            }
            pFirstRow={sFirstRow}
            pWidth="350"
            pVertical="-20"
            pHorizontal={['90', '200']}
            pDataTestId="timeHorizon"
            pDisabled={pDisabled}
        />
    );
};
TimeHorizonV2.propTypes = propTypes;
export default TimeHorizonV2;
