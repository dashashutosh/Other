import React from 'react';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { render } from '../../../../utils/test-utils';
import { contextMock } from './mocks/USMocks';
import TripSharedService from '../../../../service/TripSharedService';
import GroupByFilter from '../GroupByFilter';

const mockPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockPush,
    }),
}));

beforeAll(() => {
    TripSharedService.setPageLoadSettings({ showUSColumns: true });
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('Group by US', () => {
    it('should render without crashing', () => {
        const mockFn = jest.fn();
        const wrapper = render(<GroupByFilter pOnChange={mockFn} pVariant="default" />);

        expect(wrapper).toBeDefined();
    });
});
