export const planCountsZero = {
    phaseStatusCounts: {
        status: 'OK',
        header: {
            headerAttributes: {},
        },
        errors: [],
        payload: {
            planning: [
                {
                    status: 'PLANNED',
                    count: 0,
                },
            ],
            processing: [
                {
                    status: 'NEED_ATTENTION',
                    count: 0,
                },
                {
                    status: 'TENDER_CANCELED',
                    count: 0,
                },
                {
                    status: 'TENDERED',
                    count: 0,
                },
                {
                    status: 'TENDER_REJECTED',
                    count: 0,
                },
                {
                    status: 'PLANNED',
                    count: 0,
                },
            ],
            readyToStart: [
                {
                    status: 'TENDER_ACCEPTED',
                    count: 0,
                },
            ],
            inTransit: [
                {
                    status: 'IN_TRANSIT',
                    count: 0,
                },
            ],
        },
    },
};
export const planCounts = {
    phaseStatusCounts: {
        status: 'OK',
        header: {
            headerAttributes: {},
        },
        errors: [],
        payload: {
            planning: [
                {
                    status: 'PLANNED',
                    count: 0,
                },
            ],
            processing: [
                {
                    status: 'NEED_ATTENTION',
                    count: 3,
                },
                {
                    status: 'TENDER_CANCELED',
                    count: 0,
                },
                {
                    status: 'TENDERED',
                    count: 0,
                },
                {
                    status: 'TENDER_REJECTED',
                    count: 0,
                },
                {
                    status: 'PLANNED',
                    count: 0,
                },
            ],
            readyToStart: [
                {
                    status: 'TENDER_ACCEPTED',
                    count: 0,
                },
            ],
            inTransit: [
                {
                    status: 'IN_TRANSIT',
                    count: 0,
                },
            ],
        },
    },
};
