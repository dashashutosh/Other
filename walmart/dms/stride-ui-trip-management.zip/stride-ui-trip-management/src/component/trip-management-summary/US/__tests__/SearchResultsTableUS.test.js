import PhaseTypesEnum from '../../../../utils/enums/PhaseTypesEnum';
import TableColumnsUS from '../../../model/TableColumnsUS';
import { getColumnDetailsOfPhase } from '../SearchResultsTableUS';
import { groupByList } from '../DataModelsUS';

const trans = (str) => str;

describe('getColumnDetailsOfPhase', () => {
    it('should return proper default value for PLANNING phase', () => {
        const result = getColumnDetailsOfPhase(PhaseTypesEnum.PLANNING.index, {}, {}, trans);
        expect(result.columns.map((col) => col.id)).toEqual([
            TableColumnsUS.PLAN_ID.id,
            TableColumnsUS.PLAN_TYPE.id,
            TableColumnsUS.TRAILER_ID.id,
            TableColumnsUS.ORIGIN_LOCATION_ID.id,
            TableColumnsUS.DISTANCE.id,
            TableColumnsUS.DESTINATION_LOCATION_ID.id,
            TableColumnsUS.PRIORITY.id,
            TableColumnsUS.PLANNED_START.id,
            TableColumnsUS.PLANNED_END.id,
            TableColumnsUS.DURATION.id,
            TableColumnsUS.PICKUP_STOPS.id,
            TableColumnsUS.DELIVERY_STOPS.id,
            TableColumnsUS.STATUS.id,
            TableColumnsUS.ACTIONS.id,
        ]);
    });

    it('should return proper default value for PROCESSING phase', () => {
        const result = getColumnDetailsOfPhase(PhaseTypesEnum.PROCESSING.index, {}, {}, trans);
        expect(result.columns.map((col) => col.id)).toEqual([
            TableColumnsUS.PLAN_ID.id,
            TableColumnsUS.PLAN_TYPE.id,
            TableColumnsUS.CARRIER_ID.id,
            TableColumnsUS.SERVICE_TERRITORY.id,
            TableColumnsUS.TRAILER_ID.id,
            TableColumnsUS.DRIVER_ID.id,
            TableColumnsUS.ORIGIN_LOCATION_ID.id,
            TableColumnsUS.DISTANCE.id,
            TableColumnsUS.DESTINATION_LOCATION_ID.id,
            TableColumnsUS.PRIORITY.id,
            TableColumnsUS.PLANNED_START.id,
            TableColumnsUS.PRIMARY_DESTINATION_PLANNED_END.id,
            TableColumnsUS.PLANNED_END.id,
            TableColumnsUS.DURATION.id,
            TableColumnsUS.BILLS_BY_TIME.id,
            TableColumnsUS.PICKUP_STOPS.id,
            TableColumnsUS.DELIVERY_STOPS.id,
            TableColumnsUS.STATUS.id,
            TableColumnsUS.ACTIONS.id,
        ]);
    });

    it('should return proper default value for READY_TO_START phase', () => {
        const result = getColumnDetailsOfPhase(PhaseTypesEnum.READY_TO_START.index, {}, {}, trans);
        expect(result.columns.map((col) => col.id)).toEqual([
            TableColumnsUS.PLAN_ID.id,
            TableColumnsUS.PLAN_TYPE.id,
            TableColumnsUS.ORIGIN_LOCATION_ID.id,
            TableColumnsUS.DISTANCE.id,
            TableColumnsUS.DESTINATION_LOCATION_ID.id,
            TableColumnsUS.PRIORITY.id,
            TableColumnsUS.PLANNED_START.id,
            TableColumnsUS.PLANNED_END.id,
            TableColumnsUS.DURATION.id,
            TableColumnsUS.CARRIER_ID.id,
            TableColumnsUS.SERVICE_TERRITORY.id,
            TableColumnsUS.TRAILER_ID.id,
            TableColumnsUS.DRIVER_ID.id,
            TableColumnsUS.BILLS_BY_TIME.id,
            TableColumnsUS.PICKUP_STOPS.id,
            TableColumnsUS.DELIVERY_STOPS.id,
            TableColumnsUS.STATUS.id,
            TableColumnsUS.ACTIONS.id,
        ]);
    });

    it('should return proper default value for IN_TRANSIT phase', () => {
        const result = getColumnDetailsOfPhase(PhaseTypesEnum.IN_TRANSIT.index, {}, {}, trans);
        expect(result.columns.map((col) => col.id)).toEqual([
            TableColumnsUS.PLAN_ID.id,
            TableColumnsUS.PLAN_TYPE.id,
            TableColumnsUS.ORIGIN_LOCATION_ID.id,
            TableColumnsUS.DISTANCE.id,
            TableColumnsUS.DESTINATION_LOCATION_ID.id,
            TableColumnsUS.PRIORITY.id,
            TableColumnsUS.PLANNED_START.id,
            TableColumnsUS.ACTUAL_START.id,
            TableColumnsUS.PLANNED_END.id,
            TableColumnsUS.ESTIMATED_END.id,
            TableColumnsUS.DURATION.id,
            TableColumnsUS.NEXT_STOP.id,
            TableColumnsUS.NUMBER_OF_STOPS_REMAINING.id,
            TableColumnsUS.PICKUP_STOPS.id,
            TableColumnsUS.CARRIER_ID.id,
            TableColumnsUS.SERVICE_TERRITORY.id,
            TableColumnsUS.TRAILER_ID.id,
            TableColumnsUS.DRIVER_ID.id,
            TableColumnsUS.DELIVERY_STOPS.id,
            TableColumnsUS.STATUS.id,
            TableColumnsUS.ACTIONS.id,
        ]);
    });

    it('should return proper default value for DELIVERED phase', () => {
        const result = getColumnDetailsOfPhase(PhaseTypesEnum.DELIVERED.index, {}, {}, trans);
        expect(result.columns.map((col) => col.id)).toEqual([
            TableColumnsUS.PLAN_ID.id,
            TableColumnsUS.PLAN_TYPE.id,
            TableColumnsUS.ORIGIN_LOCATION_ID.id,
            TableColumnsUS.DISTANCE.id,
            TableColumnsUS.DESTINATION_LOCATION_ID.id,
            TableColumnsUS.PRIORITY.id,
            TableColumnsUS.PLANNED_START.id,
            TableColumnsUS.ACTUAL_START.id,
            TableColumnsUS.PLANNED_END.id,
            TableColumnsUS.ACTUAL_END.id,
            TableColumnsUS.CARRIER_ID.id,
            TableColumnsUS.SERVICE_TERRITORY.id,
            TableColumnsUS.TRAILER_ID.id,
            TableColumnsUS.DRIVER_ID.id,
            TableColumnsUS.DURATION.id,
            TableColumnsUS.BILLS_BY_TIME.id,
            TableColumnsUS.PICKUP_STOPS.id,
            TableColumnsUS.DELIVERY_STOPS.id,
            TableColumnsUS.STATUS.id,
            TableColumnsUS.ACTIONS.id,
        ]);
    });

    it('should return proper sort value for origin and destination based on groupBY load', () => {
        const cmsConfig = {
            sortFields: {
                LOAD_DESTINATION_LOCATION_ID: 'plan_locations_destination_location_id_v1',
                LOAD_ORIGIN_LOCATION_ID: 'plan_locations_origin_location_id_v1',
            },
        };
        const result = getColumnDetailsOfPhase(PhaseTypesEnum.PLANNING.index, cmsConfig, {}, trans, groupByList[1].id);
        expect(result.columns.map((col) => col.meta.sortField).filter((column) => column)).toEqual([
            'plan_locations_origin_location_id_v1',
            'plan_locations_destination_location_id_v1',
        ]);
    });

    it('should return proper sort value for origin and destination based on groupBY trip', () => {
        const cmsConfig = {
            sortFields: {
                DESTINATION_LOCATION_ID: 'locations_destination_location_id',
                ORIGIN_LOCATION_ID: 'locations_origin_location_id',
            },
        };
        const result = getColumnDetailsOfPhase(PhaseTypesEnum.PLANNING.index, cmsConfig, {}, trans, groupByList[0].id);
        expect(result.columns.map((col) => col.meta.sortField).filter((column) => column)).toEqual([
            'locations_origin_location_id',
            'locations_destination_location_id',
        ]);
    });
});
