import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Toast, Alert, SearchScope } from '@walmart/living-design-sc-ui';
import clsx from 'clsx';
import { useAPI, sanitizeCommaSepTextInput } from '@walmart/stride-ui-commons';
import { createPortal } from 'react-dom';
import { GlobalSearchOption, regexNumComma, toastTimerUS } from '../../../ConstantsUS';
import { stTripToast } from '../../../utils/StyleUtils';
import { TripAPI } from '../../../service/TripAPI';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import { ERROR_CONTAINER_ID } from '../../../Constants';
import { getPlanErrorText } from '../../../utils/CommonUtils';
import { QueryStateType } from '../../../utils/types/PlanSearchTypes';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { AppUtils } from '@gscope-mfe/app-bridge';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const useStyles = makeStyles({
    stTripToast,
    gs: {
        width: 390,
        margin: '0 !important',
    },
    error: {
        borderColor: 'red !important',
    },
    searchScope: {
        width: '550px',
        '& > div > div > div ': {
            padding: '20px 20px 14px !important',
        },
        '& > div > div > div > label': {
            transform: 'translate(-20px,-19px) scale(.70) !important',
        },
    },
});
const GlobalSearch = ({ pPhaseTotal, dispatch, queryState, pIsGlobalSearchFlow, pFeatureFlag }) => {
    const classes = useStyles();
    const trans = localizeLang();
    const [sIsGSValueValid, setsIsGSValueValid] = useState(true);
    const [sGSValue, setsGSValue] = useState('');
    const [sIsGSearch, setsIsGSearch] = useState(false);
    const [sError, setsError] = useState('');
    const { prefLang, currentMarket, userInfo, setloading } = AppUtils.get();
    const { callAPI: planCountsApi, ...planCountsApiResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getPlanCounts,
    );
    const [searchBy, setSearchBy] = useState(GlobalSearchOption[0].id);
    const getSearchOptionPlaceHolder = (data) => ({
        ...data,
        value: trans(data.value),
    });
    useEffect(() => {
        if (planCountsApiResponse.loading) setloading(true);
        else setloading(false);
    }, [planCountsApiResponse.loading]);
    useEffect(() => {
        if (!queryState.globalSearchData) {
            setsGSValue('');
        }
    }, [queryState.globalSearchData]);

    // Todo: R2 - Review comment - Use isEmpty util from commons instead of JSON.stringify
    useEffect(() => {
        if (JSON.stringify(pPhaseTotal) !== '{}' && sGSValue && sIsGSearch) {
            const phase = Object.keys(pPhaseTotal).find((key) => pPhaseTotal[key] > 0);
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.GLOBAL_SEARCH,
                payload: {
                    globalSearch: sGSValue,
                    activeTabIndex: Number(phase) || 0,
                    searchByOption: searchBy,
                    market: currentMarket,
                },
            });
            setsIsGSearch(false);
        }
    }, [pPhaseTotal]);
    const handleSearch = () => {
        if (sGSValue.match(regexNumComma)) {
            pIsGlobalSearchFlow(false); // resetting the flag
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.GLOBAL_SEARCH,
                payload: {
                    globalSearch: sGSValue,
                    activeTabIndex: 0,
                    searchByOption: searchBy,
                    market: currentMarket,
                },
            });
            setsIsGSearch(true);
        } else {
            setsIsGSValueValid(false);
        }
    };

    const handleTextValueChange = (val) => {
        const newVal = sanitizeCommaSepTextInput(val);
        setsGSValue(newVal);
    };

    useEffect(() => {
        const searchParams = new URLSearchParams(window.location.search);
        const queryValue = searchParams.get('launchWithLoadIds');
        const value = window.localStorage.getItem('WMC_LAUNCH_LOAD_IDS');
        let wmcLoadIds = '';
        if (queryValue === 'WMC_LAUNCH_LOAD_IDS' && value) {
            const newValue = JSON.parse(value);
            if (newValue.key === queryValue) {
                wmcLoadIds = newValue?.value?.data || '';
            }
            setsGSValue(wmcLoadIds);
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.GLOBAL_SEARCH,
                payload: {
                    globalSearch: wmcLoadIds,
                    activeTabIndex: 0,
                    searchByOption: searchBy,
                    market: currentMarket,
                },
            });
            window.localStorage.removeItem('WMC_LAUNCH_LOAD_IDS');
            setsIsGSearch(true);
        }
    }, []);
    return (
        <>
            {sError
                ? createPortal(
                      <Alert
                          variant="error"
                          data-testid="cancelFailAlert"
                          onClose={() => {
                              setsError('');
                          }}
                      >
                          {getPlanErrorText(sError, trans)}
                      </Alert>,
                      document.getElementById(ERROR_CONTAINER_ID),
                  )
                : null}
            {!sIsGSValueValid && (
                <Toast
                    text={trans('gs.validate.value')}
                    variant="negative"
                    delay={toastTimerUS}
                    className={classes.stTripToast}
                    onClose={() => {
                        setsIsGSValueValid(true);
                    }}
                />
            )}

            <SearchScope
                className={`${clsx(classes.gs, {
                    [classes.error]: !sIsGSValueValid,
                })} ${classes.searchScope}`}
                getSearchValue={(e) => (pFeatureFlag?.showCommaSeperation ? handleTextValueChange(e) : setsGSValue(e))}
                onClear={() => {
                    setsGSValue('');
                }}
                onSearch={() => {
                    handleSearch();
                }}
                placeholder={trans('global.search.placeholder')}
                searchValue={sGSValue}
                data-testid="globalSearch-tm"
                scope1label="Type"
                scope1list={GlobalSearchOption.map((e) => getSearchOptionPlaceHolder(e))}
                scope1variant="single-select"
                changeScope1Value={(_e) => {
                    setSearchBy(_e.target.getAttribute('value'));
                }}
                scope1Value={searchBy}
                ignoreWhitespace={!pFeatureFlag?.showCommaSeperation}
            />
        </>
    );
};
const propTypes = {
    pPhaseTotal: PropTypes.shape({}).isRequired,
    dispatch: PropTypes.func.isRequired,
    queryState: QueryStateType.isRequired,
    pIsGlobalSearchFlow: PropTypes.func.isRequired,
    pFeatureFlag: PropTypes.shape({
        showCommaSeperation: PropTypes.bool.isRequired,
    }).isRequired,
};
GlobalSearch.propTypes = propTypes;
export default GlobalSearch;
