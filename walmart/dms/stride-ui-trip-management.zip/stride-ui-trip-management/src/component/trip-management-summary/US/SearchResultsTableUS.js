import React, { useEffect, useMemo, useState } from 'react';
import PropTypes from 'prop-types';
import {
    StrideTable,
    MultiSortInfoChips,
    TableColumnManagement,
    useTableColumnManagementValue,
    getStridePreferencesKey,
    BEPlanCategoryEnum,
    openPageInNewTab,
} from '@walmart/stride-ui-commons';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { AppUtils, Utilities, Logger } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { useHistory } from 'react-router-dom';
import clsx from 'clsx';

import TableColumnsUS from '../../model/TableColumnsUS';
import { QueryStateType } from '../../../utils/types/PlanSearchTypes';
import PhaseTypesEnum from '../../../utils/enums/PhaseTypesEnum';
import { MODULE_NAME } from '../../../Constants';
import TripSharedService from '../../../service/TripSharedService';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import { enableRowExpansion, groupByList } from './DataModelsUS';
import { useToast } from '@walmart/living-design-sc-ui';
import { PLAN_ENTITY_ENUM } from '../../../utils/ui-mappers/US/PlanDetailsMapper';

const { setUserPreference, getUserPreferences } = Utilities;
const { localizeLang } = LocalizeLang.default;
const { makeStyles } = MaterialUiCore;

const useStyles = makeStyles({
    root: {
        display: 'flex',
        minHeight: 0,
        flexDirection: 'column',

        '& > div': {
            height: '100%',
        },
    },

    styleResets: {
        // Reset the style added in the body tag
        '-webkit-font-smoothing': 'auto',

        '& label': {
            // Reset the style included in bootstrap 4
            marginBottom: 'unset',
        },
    },

    strideTable: {
        height: '100%',
        fontFamily: 'Bogle',
        textAlign: 'left',
        fontSize: 16,

        '& tbody td .ld-sc-ui-button': {
            overflow: 'hidden !important',
            textOverflow: 'ellipsis !important',
            display: 'block !important',
            border: 'none !important',
            borderRadius: '0px !important',
        },
    },

    locationColumnButton: {
        maxWidth: 'calc(var(--stride-table-cell-size) - 72px) !important',
    },

    timeDelay: {
        color: '#c40e18',
        textTransform: 'lowercase',
        fontSize: '12px',
    },

    timeEarly: {
        color: '#226c02',
        textTransform: 'lowercase',
        fontSize: '12px',
    },

    secondaryText: {
        opacity: '0.5',
        fontSize: '12px !important',
    },

    imgOpacity: {
        opacity: '0.3',
    },

    headerCellUOM: {
        fontWeight: 'normal',
    },

    queryChipsContainer: {
        margin: 16,
    },
});

export const getColumnDetailsOfPhase = (phase, cmsConfig, featureFlags, trans, groupBy) => {
    let columns = [];
    const tableColumManagementValueDefault = {
        columnVisibility: {},
        columnOrder: [],
        columnPinning: {
            left: [TableColumnsUS.PLAN_ID.id, TableColumnsUS.TAGS.id, TableColumnsUS.PLAN_TYPE.id],
            right: [TableColumnsUS.STATUS.id, TableColumnsUS.ACTIONS.id],
        },
    };
    let activeTabId = '';
    let version;

    switch (phase) {
        case PhaseTypesEnum.PLANNING.index:
            version = 1;
            activeTabId = PhaseTypesEnum.PLANNING.fieldBE;
            columns = [
                TableColumnsUS.PLAN_ID,
                featureFlags?.showTagsCol ? TableColumnsUS.TAGS : null,
                TableColumnsUS.PLAN_TYPE,
                TableColumnsUS.TRAILER_ID,
                TableColumnsUS.ORIGIN_LOCATION_ID,
                featureFlags?.showCommentsColumn ? TableColumnsUS.COMMENTS : null,
                TableColumnsUS.DISTANCE,
                TableColumnsUS.DESTINATION_LOCATION_ID,
                featureFlags?.showPrimaryDestinationCol ? TableColumnsUS.PRIMARY_DESTINATION_LOCATION_ID : null,
                featureFlags?.showDwellDays ? TableColumnsUS.DWELL_DAYS : null,
                TableColumnsUS.PRIORITY,
                TableColumnsUS.PLANNED_START,
                TableColumnsUS.PLANNED_END,
                TableColumnsUS.DURATION,
                TableColumnsUS.PICKUP_STOPS,
                TableColumnsUS.DELIVERY_STOPS,
                TableColumnsUS.STATUS,
                featureFlags?.showRouteNumberColumn ? TableColumnsUS.ROUTE_NUMBER : null,
                TableColumnsUS.ACTIONS,
            ];

            break;

        case PhaseTypesEnum.PROCESSING.index:
            version = 1;
            activeTabId = PhaseTypesEnum.PROCESSING.fieldBE;
            columns = [
                TableColumnsUS.PLAN_ID,
                featureFlags?.showTagsCol ? TableColumnsUS.TAGS : null,
                TableColumnsUS.PLAN_TYPE,
                TableColumnsUS.CARRIER_ID,
                ...(featureFlags?.showServiceTerritory
                    ? [TableColumnsUS.TRIP_SERVICE_TERRITORY, TableColumnsUS.PLAN_SERVICE_TERRITORY]
                    : [TableColumnsUS.SERVICE_TERRITORY]),
                TableColumnsUS.TRAILER_ID,
                TableColumnsUS.DRIVER_ID,
                TableColumnsUS.ORIGIN_LOCATION_ID,
                featureFlags?.showCommentsColumn ? TableColumnsUS.COMMENTS : null,
                TableColumnsUS.DISTANCE,
                TableColumnsUS.DESTINATION_LOCATION_ID,
                featureFlags?.showPrimaryDestinationCol ? TableColumnsUS.PRIMARY_DESTINATION_LOCATION_ID : null,
                featureFlags?.showDwellDays ? TableColumnsUS.DWELL_DAYS : null,
                TableColumnsUS.PRIORITY,
                TableColumnsUS.PLANNED_START,
                TableColumnsUS.PRIMARY_DESTINATION_PLANNED_END,
                TableColumnsUS.PLANNED_END,
                TableColumnsUS.DURATION,
                TableColumnsUS.BILLS_BY_TIME,
                TableColumnsUS.PICKUP_STOPS,
                TableColumnsUS.DELIVERY_STOPS,
                TableColumnsUS.STATUS,
                featureFlags?.showRouteNumberColumn ? TableColumnsUS.ROUTE_NUMBER : null,
                TableColumnsUS.ACTIONS,
            ];

            break;

        case PhaseTypesEnum.READY_TO_START.index:
            version = 1;
            activeTabId = PhaseTypesEnum.READY_TO_START.fieldBE;
            columns = [
                TableColumnsUS.PLAN_ID,
                featureFlags?.showTagsCol ? TableColumnsUS.TAGS : null,
                TableColumnsUS.PLAN_TYPE,
                TableColumnsUS.ORIGIN_LOCATION_ID,
                featureFlags?.showCommentsColumn ? TableColumnsUS.COMMENTS : null,
                TableColumnsUS.DISTANCE,
                TableColumnsUS.DESTINATION_LOCATION_ID,
                featureFlags?.showPrimaryDestinationCol ? TableColumnsUS.PRIMARY_DESTINATION_LOCATION_ID : null,
                featureFlags?.showDwellDays ? TableColumnsUS.DWELL_DAYS : null,
                TableColumnsUS.PRIORITY,
                TableColumnsUS.PLANNED_START,
                TableColumnsUS.PLANNED_END,
                TableColumnsUS.DURATION,
                TableColumnsUS.CARRIER_ID,
                ...(featureFlags?.showServiceTerritory
                    ? [TableColumnsUS.TRIP_SERVICE_TERRITORY, TableColumnsUS.PLAN_SERVICE_TERRITORY]
                    : [TableColumnsUS.SERVICE_TERRITORY]),
                TableColumnsUS.TRAILER_ID,
                TableColumnsUS.DRIVER_ID,
                TableColumnsUS.BILLS_BY_TIME,
                TableColumnsUS.PICKUP_STOPS,
                TableColumnsUS.DELIVERY_STOPS,
                featureFlags?.showMustDepartTimeCol ? TableColumnsUS.MUST_DEPART_TIME : null,
                TableColumnsUS.STATUS,
                featureFlags?.showRouteNumberColumn ? TableColumnsUS.ROUTE_NUMBER : null,
                TableColumnsUS.ACTIONS,
            ];

            break;

        case PhaseTypesEnum.IN_TRANSIT.index:
            version = 1;
            activeTabId = PhaseTypesEnum.IN_TRANSIT.fieldBE;
            columns = [
                TableColumnsUS.PLAN_ID,
                featureFlags?.showTagsCol ? TableColumnsUS.TAGS : null,
                TableColumnsUS.PLAN_TYPE,
                TableColumnsUS.ORIGIN_LOCATION_ID,
                featureFlags?.showCommentsColumn ? TableColumnsUS.COMMENTS : null,
                TableColumnsUS.DISTANCE,
                TableColumnsUS.DESTINATION_LOCATION_ID,
                featureFlags?.showPrimaryDestinationCol ? TableColumnsUS.PRIMARY_DESTINATION_LOCATION_ID : null,
                TableColumnsUS.PRIORITY,
                TableColumnsUS.PLANNED_START,
                TableColumnsUS.ACTUAL_START,
                TableColumnsUS.PLANNED_END,
                TableColumnsUS.ESTIMATED_END,
                TableColumnsUS.DURATION,
                TableColumnsUS.NEXT_STOP,
                TableColumnsUS.NUMBER_OF_STOPS_REMAINING,
                TableColumnsUS.PICKUP_STOPS,
                TableColumnsUS.CARRIER_ID,
                ...(featureFlags?.showServiceTerritory
                    ? [TableColumnsUS.TRIP_SERVICE_TERRITORY, TableColumnsUS.PLAN_SERVICE_TERRITORY]
                    : [TableColumnsUS.SERVICE_TERRITORY]),
                TableColumnsUS.TRAILER_ID,
                TableColumnsUS.DRIVER_ID,
                TableColumnsUS.DELIVERY_STOPS,
                TableColumnsUS.STATUS,
                featureFlags?.showRouteNumberColumn ? TableColumnsUS.ROUTE_NUMBER : null,
                TableColumnsUS.ACTIONS,
            ];

            break;

        case PhaseTypesEnum.DELIVERED.index:
            version = 1;
            activeTabId = PhaseTypesEnum.DELIVERED.fieldBE;
            columns = [
                TableColumnsUS.PLAN_ID,
                featureFlags?.showTagsCol ? TableColumnsUS.TAGS : null,
                TableColumnsUS.PLAN_TYPE,
                TableColumnsUS.ORIGIN_LOCATION_ID,
                featureFlags?.showCommentsColumn ? TableColumnsUS.COMMENTS : null,
                TableColumnsUS.DISTANCE,
                TableColumnsUS.DESTINATION_LOCATION_ID,
                featureFlags?.showPrimaryDestinationCol ? TableColumnsUS.PRIMARY_DESTINATION_LOCATION_ID : null,
                TableColumnsUS.PRIORITY,
                TableColumnsUS.PLANNED_START,
                TableColumnsUS.ACTUAL_START,
                TableColumnsUS.PLANNED_END,
                TableColumnsUS.ACTUAL_END,
                TableColumnsUS.CARRIER_ID,
                ...(featureFlags?.showServiceTerritory
                    ? [TableColumnsUS.TRIP_SERVICE_TERRITORY, TableColumnsUS.PLAN_SERVICE_TERRITORY]
                    : [TableColumnsUS.SERVICE_TERRITORY]),
                TableColumnsUS.TRAILER_ID,
                TableColumnsUS.DRIVER_ID,
                TableColumnsUS.DURATION,
                TableColumnsUS.BILLS_BY_TIME,
                TableColumnsUS.PICKUP_STOPS,
                TableColumnsUS.DELIVERY_STOPS,
                TableColumnsUS.STATUS,
                featureFlags?.showRouteNumberColumn ? TableColumnsUS.ROUTE_NUMBER : null,
                TableColumnsUS.ACTIONS,
            ];

            break;
        default:
            break;
    }

    const enhancedColumns = [];
    columns.forEach((column) => {
        if (column) {
            let labelKey = column.meta.label;
            let size = column.size;
            let sortField = cmsConfig?.sortFields?.[column.id];
            switch (column.id) {
                case TableColumnsUS.STATUS.id:
                    if (phase === PhaseTypesEnum.PROCESSING.index) {
                        labelKey = 'planColumns.multiStatus';
                        size = 160;
                    }
                    break;
                case TableColumnsUS.ORIGIN_LOCATION_ID.id:
                    if (groupBy === groupByList?.[1]?.id) {
                        sortField = cmsConfig?.sortFields?.LOAD_ORIGIN_LOCATION_ID;
                    }
                    break;
                case TableColumnsUS.DESTINATION_LOCATION_ID.id:
                    if (groupBy === groupByList?.[1]?.id) {
                        sortField = cmsConfig?.sortFields?.LOAD_DESTINATION_LOCATION_ID;
                    }
                    break;
                default:
                    break;
            }
            enhancedColumns.push({
                ...column,
                size: size,
                meta: {
                    ...column.meta,
                    sortField: sortField,
                    label: trans(labelKey),
                },
                enableSorting: Boolean(sortField),
            });
        }
    });

    tableColumManagementValueDefault.columnOrder = enhancedColumns.map((col) => col.id);

    return { columns: enhancedColumns, tableColumManagementValueDefault, activeTabId, version };
};

const TABLE_COLUMN_MANAGEMENT_OPTIONS = {
    maxPinnableColumnsLeft: 3,
    maxPinnableColumnsRight: 3,
    maxSelectableColumns: 30,
};

const tableSettings = {
    disablePaddingEnd: true,
    maxMultiSortColCount: 3,
};

/**
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 * */
const SearchResultsTableUS = (props) => {
    const classes = useStyles();
    const trans = localizeLang();
    const history = useHistory();
    const toast = useToast();

    const { currentMarket, prefLang, userInfo } = AppUtils.get();

    const {
        data,
        mdmLocationTypes,
        setShowTableColumnManager,
        showTableColumnManager,
        cmsConfig,
        queryState,
        checkedRows,
        // tableSearchText,
        dispatch,
        setActionRow,
        onActionItemClick,
        onViewAllComments,
        onTableColumnManagementLoadingStateChange,
    } = props;

    // const featureFlags = { ...TripSharedService.getFeatureFlags(), enableMultiSortForSearchTable: false };
    const featureFlags = TripSharedService.getFeatureFlags();

    const [expanded, setExpanded] = useState({});

    const { columns, tableColumManagementValueDefault, activeTabId, version } = useMemo(() => {
        return getColumnDetailsOfPhase(queryState?.activeTabIndex, cmsConfig, featureFlags, trans, queryState?.groupBy);
    }, [queryState.activeTabIndex, cmsConfig, trans, queryState?.groupBy]);

    const tableId = useMemo(
        () => getStridePreferencesKey(currentMarket, MODULE_NAME, 'search', 'results-table-' + activeTabId),
        [currentMarket, activeTabId],
    );

    /** @type {import('@tanstack/react-table').TableOptions} */
    const tableOptions = useMemo(
        () => ({
            getSubRows: (row) => row.plans,
            getRowId: (row) => row.planId,
            manualSorting: true,

            // enable row selection only for the parent row
            enableRowSelection: (row) => row.original.plans !== undefined,
            getRowCanExpand: (row) => enableRowExpansion(row.original, queryState) && row.original.plans?.length > 0,
        }),
        [queryState],
    );

    useEffect(() => {
        setExpanded({});
    }, [queryState]);

    const { value, setValue } = useTableColumnManagementValue({
        tableId: tableId,
        version: version,
        options: {
            enrichData: (data) => data,
            setloading: onTableColumnManagementLoadingStateChange,
            setUserPreference,
            getUserPreferences,
        },
    });

    const rowSelection = useMemo(() => {
        const value = {};

        checkedRows.forEach((rowId) => {
            value[rowId] = true;
        });

        return value;
    }, [checkedRows]);

    const handleRowSelectionChange = (updaterFn) => {
        const updatedRowSelectionState = updaterFn(rowSelection);

        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: Object.keys(updatedRowSelectionState),
        });
    };

    const sorting = useMemo(() => {
        const column = columns.find((column) => column.meta.sortField === queryState.sortField);

        return column ? [{ id: column.id, desc: queryState.sortMode === 'DESC' }] : [];
    }, [queryState, columns]);

    const handleSortingChange = (updaterFn) => {
        const updatedSortingState = updaterFn(sorting);
        const lastItemInSorting = updatedSortingState.at(-1);

        const column = columns.find((column) => column.id === lastItemInSorting.id);

        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_SORT,
            sortField: column.meta.sortField,
            sortMode: lastItemInSorting.desc ? 'DESC' : 'ASC',
        });
    };

    const handleMultiSortChange = (updaterFn) => {
        const updatedSortingState = updaterFn(queryState.multiSortFields);

        const multiSortFields = updatedSortingState.map((sortInfo) => {
            const column = columns.find((column) => column.id === sortInfo.id);

            return {
                ...sortInfo,
                label: column.meta.label,
                sortField: column.meta.sortField,
            };
        });

        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.UPDATE_MULTI_SORT,
            multiSortFields: multiSortFields,
        });
    };

    const handleSortingChipDelete = (sorting) => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.UPDATE_MULTI_SORT,
            multiSortFields: sorting,
        });
    };

    const navigateToDetailsPage = ({ isTrip, planId, planType }) => {
        let path = '';
        if (isTrip && planType !== BEPlanCategoryEnum.IM?.code) {
            path = 'tripdetails';
        } else path = 'loaddetails';
        if (featureFlags?.openDetailsPageInNewTab) {
            openPageInNewTab(
                featureFlags.hasPQMigratedToMFE
                    ? `/mfe/stride/planquery/${path}?planId=${planId}`
                    : `/stride/planquery/${path}?planId=${planId}`,
            );
        } else {
            history.push({
                pathname: featureFlags.hasPQMigratedToMFE
                    ? `/mfe/stride/planquery/${path}`
                    : `/stride/planquery/${path}`,
                search: `?planId=${planId}`,
            });
        }
    };

    const navigateToLocationDetailsPage = (locationId, locationType) => {
        if (locationId && locationType) {
            window.open(
                featureFlags.hasLocationMigratedToMFE
                    ? `/mfe/stride/location/details?type=${locationType}&id=${locationId}`
                    : `/stride/location/details?type=${locationType}&id=${locationId}`,
            );
        }
    };

    const handleActionClose = (isActionClicked) => {
        if (!isActionClicked) {
            setActionRow([]);
        }
    };

    const handleActionOpen = (rowData) => {
        setActionRow([rowData.planId]);
    };

    const handleActionItemClick = (event) => {
        const actionCode = event.currentTarget.dataset.code;
        onActionItemClick(actionCode);
        handleActionClose(true);
    };

    // do not render anything if the `value` is `undefined`.
    if (value === undefined) {
        return null;
    }

    // use default value if the `value` is `null`
    const tableColumnManagementValue = value || tableColumManagementValueDefault;

    return (
        <>
            {showTableColumnManager && (
                <TableColumnManagement
                    pOpen
                    pClassName={classes.styleResets}
                    pOptions={TABLE_COLUMN_MANAGEMENT_OPTIONS}
                    pColumns={columns}
                    pValue={tableColumnManagementValue}
                    pCloseDrawer={setShowTableColumnManager}
                    pOnClickApply={(data) => {
                        setValue(data)
                            .then((data) => {
                                // eslint-disable-next-line no-console
                                Logger.success('Columns saved successfully', data);
                                setShowTableColumnManager(false);
                                toast({ text: trans('tableActions.message.save.success'), variant: 'positive' });
                            })
                            .catch(() => {
                                toast({ text: trans('tableActions.message.save.failure'), variant: 'negative' });
                            });
                    }}
                    onClickCancel={() => setShowTableColumnManager(false)}
                    pDataTestId="table-column-management"
                    pCurrentLang={prefLang.current}
                />
            )}

            {featureFlags?.enableMultiSortForSearchTable && queryState?.multiSortFields?.length > 1 ? (
                <div className={classes.queryChipsContainer} data-testid="query-chips-container">
                    <MultiSortInfoChips
                        sorting={queryState.multiSortFields}
                        onSortingChange={handleSortingChipDelete}
                    />
                </div>
            ) : null}

            <div className={clsx(classes.root, classes.styleResets)}>
                {tableColumnManagementValue ? (
                    <StrideTable
                        id="search-result-table-us"
                        columns={columns}
                        className={classes.strideTable}
                        data={data}
                        tableOptions={tableOptions}
                        meta={{
                            classes,
                            trans,
                            cmsConfig,
                            queryState,
                            checkedRows,
                            mdmLocationTypes,
                            setActionRow,
                            handleActionItemClick,
                            handleActionOpen,
                            handleActionClose,
                            navigateToDetailsPage,
                            navigateToLocationDetailsPage,
                            userInfo,
                            prefLang,
                            onViewAllComments,
                        }}
                        tableSettings={tableSettings}
                        columnPinning={tableColumnManagementValue.columnPinning}
                        columnVisibility={tableColumnManagementValue.columnVisibility}
                        columnOrder={tableColumnManagementValue.columnOrder}
                        // enable this when bringing in infinite scrolling
                        // globalFilter={tableSearchText}
                        onRowSelectionChange={handleRowSelectionChange}
                        onSortingChange={
                            featureFlags.enableMultiSortForSearchTable ? handleMultiSortChange : handleSortingChange
                        }
                        sorting={featureFlags.enableMultiSortForSearchTable ? queryState.multiSortFields : sorting}
                        rowSelection={rowSelection}
                        expanded={expanded}
                        onExpandedChange={setExpanded}
                    />
                ) : null}
            </div>
        </>
    );
};

const propTypes = {
    data: PropTypes.arrayOf(PropTypes.shape({})).isRequired,

    mdmLocationTypes: PropTypes.shape({}).isRequired,

    showTableColumnManager: PropTypes.bool.isRequired,

    setShowTableColumnManager: PropTypes.func.isRequired,

    cmsConfig: PropTypes.shape({}).isRequired,

    queryState: QueryStateType.isRequired,

    checkedRows: PropTypes.arrayOf(PropTypes.shape({})).isRequired,

    tableSearchText: PropTypes.string.isRequired,

    dispatch: PropTypes.func.isRequired,

    setActionRow: PropTypes.func.isRequired,

    onActionItemClick: PropTypes.func.isRequired,

    onViewAllComments: PropTypes.func.isRequired,

    onTableColumnManagementLoadingStateChange: PropTypes.func.isRequired,
};

SearchResultsTableUS.propTypes = propTypes;

export default SearchResultsTableUS;
