import React from 'react';
import PropTypes from 'prop-types';
import { ArrowLeftIcon, Button, Typography } from '@walmart/living-design-sc-ui';
import noResultsIcon from '../../../../assets/NoResults.png';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { makeStyles, Grid } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const useStyles = makeStyles({
    body: {
        display: 'flex',
        justifyContent: 'center',
        width: '100%',
    },
    iconStyle: {
        filter: 'grayscale(1)',
    },
    margin: {
        marginTop: 55,
    },
});
const NoResults = ({ pOnBack }) => {
    const classes = useStyles();
    const trans = localizeLang();
    return (
        <div className={`${classes.body} ${classes.margin}`}>
            <Grid container direction="column" spacing={3}>
                <Grid item>
                    <img className={classes.iconStyle} alt="NoResults" src={noResultsIcon} />
                </Grid>
                <Grid item>
                    <Typography variant="h5">{trans('label.gs.noResuls')}</Typography>
                </Grid>
                <Grid item className={classes.body}>
                    <Button
                        data-testid="goBack"
                        variant="secondary"
                        startIcon={<ArrowLeftIcon size="small" />}
                        size="small"
                        onClick={() => {
                            pOnBack();
                        }}
                    >
                        {trans('button.gs.back')}
                    </Button>
                </Grid>
            </Grid>
        </div>
    );
};
const propTypes = {
    pOnBack: PropTypes.func.isRequired,
};
NoResults.propTypes = propTypes;
export default NoResults;
