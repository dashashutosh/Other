import React from 'react';
import { render, screen, fireEvent } from '../../../../utils/test-utils';
import CancelPlan from '../CancelPlan';
import { REASON_CODES, contextMock } from './mocks/USMocks';
import { AppUtils } from '@gscope-mfe/app-bridge';

const spy = jest.spyOn(AppUtils, 'get');

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn().mockReturnValue({
        search: undefined,
    }),
}));

const userPermMock = JSON.stringify({
    permissions: ['us.stride.ltm-tripManagement:READ', 'us.stride.ltm-tripManagement:WRITE'],
    markets: ['us'],
});

beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    spy.mockImplementation(() => contextMock);
    // server.listen();
});

describe('Cancel plan Modal', () => {
    it('Should render without crashing', () => {
        render(
            <CancelPlan
                pIsOpen
                pSetsIsCancelModalOpen={() => {}}
                pReasonCodes={REASON_CODES}
                pCheckedPlans={['101']}
                pActionSuccessCb={() => {}}
                pIsAllTrips={false}
                pIsAllLoads
            />,
        );

        expect(screen.getByText('action.title.confirmLoadCancel action.label.load?')).toBeDefined();
    });

    it('cancel flow', () => {
        const fn = jest.fn();
        render(
            <CancelPlan
                pIsOpen
                pSetsIsCancelModalOpen={fn}
                pReasonCodes={REASON_CODES}
                pCheckedPlans={['101']}
                pActionSuccessCb={() => {}}
                pIsAllTrips={false}
                pIsAllLoads
            />,
        );
        const cancelBtn = screen.getByTestId('cancelBtn');
        expect(cancelBtn).toBeDefined();
        fireEvent.click(cancelBtn);
        expect(fn).toBeCalled();
    });

    it('select reason code', () => {
        const fn = jest.fn();
        render(
            <CancelPlan
                pIsOpen
                pSetsIsCancelModalOpen={fn}
                pReasonCodes={REASON_CODES}
                pCheckedPlans={['101']}
                pActionSuccessCb={fn}
                pIsAllTrips={false}
                pIsAllLoads
            />,
        );
        const reasonSelectDropdown = screen.getByTestId('input-reason');
        fireEvent.click(reasonSelectDropdown);
        const dropdownItem = screen.getByText('Carrier');
        expect(dropdownItem).toBeDefined();
        fireEvent.click(dropdownItem);
        expect(screen.getByDisplayValue('Carrier')).toBeDefined();
    });
});
