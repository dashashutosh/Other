import React from 'react';
import { openPageInNewTab } from '@walmart/stride-ui-commons';
import { AppUtils } from '@gscope-mfe/app-bridge';
import PlanTableRowUS from '../PlanTableRowUS';
import { render, screen, fireEvent } from '../../../../utils/test-utils';
import { contextMock, mdmLocationTypesMock } from './mocks/USMocks';
import transformedPlanMockUS from './mocks/transformedPlanMockUS.json';

const mockPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockPush,
    }),
}));

const permissionsMock = {
    canEditTrip: true,
};

const pFeatureTagsFlags = {
    showTagsCol: true,
};
const pFeatureFlag = {
    showCommentsColumn: true,
};

const qs = {
    page: 1,
    sortField: 'PLAN_CREATED_TIME',
    sortMode: 'ASC',
    exceptionType: null,
    filter: {
        fromDate: '',
        tillDate: '',
        after: '',
        before: '',
        on: '',
        dateType: '',
        periodType: '',
        loadType: [],
        planType: '',
        status: [],
        carrierId: '',
        scacCode: '',
    },
    profile: {},
    activeTabIndex: 0,
    globalSearchData: null,
    timeHorizon: 48,
    groupBy: 'TRIP',
};

beforeAll(() => {
    // TripSharedService.setPageLoadSettings({ showUSColumns: true });
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('Table Row US', () => {
    it('should render without crashing', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[0]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={0}
                pUserPerm={permissionsMock}
                mdmLocationTypes={[]}
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );

        expect(wrapper).toBeDefined();
    });

    it('should set pCheckedRows to empty array', () => {
        let customArr = ['test1', 'test2'];
        const customFn = () => {
            customArr = [];
            return customArr;
        };
        const mockFn = jest.fn(customFn);
        render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[0]}
                pCheckedRows={customArr}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={0}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="PENDING_APPROVAL"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );
        mockFn();
        expect(mockFn).toBeCalled();
        expect(customArr).toHaveLength(0);
    });

    it('should navigate the user to the details page in a new tab', () => {
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[0]}
                pFeatureFlag={{ openDetailsPageInNewTab: true }}
                pQueryState={qs}
            />,
        );
        const mockedOpen = jest.fn();
        const originalOpen = window.open;
        window.open = mockedOpen;
        const page = `http://${window.location.host}/stride/planquery/loaddetails?planId=${transformedPlanMockUS[0].planId}`;
        const loadTripId = wrapper.getByTestId('planId-cell');
        fireEvent.click(loadTripId);
        openPageInNewTab(page);
        expect(mockedOpen).toBeCalled();
        window.open = originalOpen;
    });

    it('should navigate the user to the details page in the same tab when featureflag off', () => {
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[0]}
                pFeatureFlag={{ openDetailsPageInNewTab: false, hasPQMigratedToMFE: true }}
                pQueryState={qs}
            />,
        );
        const loadTripId = wrapper.getByTestId('lms-table-click');
        fireEvent.click(loadTripId);
        expect(mockPush).toHaveBeenCalledWith({
            pathname: '/mfe/stride/planquery/loaddetails',
            search: `?planId=${transformedPlanMockUS[0].planId}`,
        });
    });

    it('Should render Table row data for Load', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[0]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="PENDING_APPROVAL"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );
        const planIdCell = wrapper.getByTestId('planId-cell');
        const planTypeCell = wrapper.getByTestId('planType-cell');
        const distanceCell = wrapper.getByTestId('distance-cell');
        const planStartTimeCell = wrapper.getByTestId('planStartTime-cell');
        const durationCell = wrapper.getByTestId('duration-cell');
        const pickupStopsCell = wrapper.getByTestId('pickupStops-cell');
        const deliveryStopsCell = wrapper.getByTestId('deliveryStops-cell');
        const trailerIDCell = screen.getByTestId('trailerId-cell');
        const destinationIdCell = screen.getByTestId('destination-cell');
        const originIdCell = screen.getByTestId('origin-cell');
        const commentCell = screen.getByTestId('comment-cell');
        const endDatePlanned = screen.getByTestId('endDatePlanned-cell');

        expect(planIdCell.textContent).toBe('30008802');
        expect(planTypeCell.textContent).toBe('Load - ');
        expect(distanceCell.textContent).toBe('70');
        expect(planStartTimeCell.textContent).toBe(' 21 Nov, 2022 ');
        expect(durationCell.textContent).toBe('10:45');
        expect(pickupStopsCell.textContent).toBe('1');
        expect(deliveryStopsCell.textContent).toBe('2');
        expect(trailerIDCell.textContent).toBe('CMAUTESTCONT640');
        expect(destinationIdCell.textContent).toBe('STORE - 751 - destinationName, ');
        expect(originIdCell.textContent).toBe('DC - 6001 - originName, ');
        expect(commentCell.textContent).toContain('GENERAL');
        expect(endDatePlanned.textContent).toBe('14 Oct, 2023 (GMT-4)');
    });
    it('Should render Printed when printed has value for a plan', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[8]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="PENDING_APPROVAL"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureTagsFlags}
                pQueryState={qs}
            />,
        );
        const tags = wrapper.getByTestId('tags-cell');
        expect(tags).toBeDefined();
        expect(tags.textContent).toBe('Pr');
    });

    it('Should not render Print when when printed value is false', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[2]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="PENDING_APPROVAL"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureTagsFlags}
                pQueryState={qs}
            />,
        );
        const tags = wrapper.getByTestId('tags-cell');
        expect(tags.textContent).toBe('');
    });

    it('should not show Operational Status column data cell if feature flag false', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showTagsCol: false }}
                pQueryState={qs}
            />,
        );

        const cell = screen.queryByTestId('tags-cell');
        expect(cell).toBeNull();
    });
    it('Should render Hazmat when showHazmat is true', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[0]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="PENDING_APPROVAL"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureTagsFlags}
                pQueryState={qs}
            />,
        );
        const tags = wrapper.getByTestId('tags-cell');
        expect(tags).toBeDefined();
    });

    it('Should render Not Hazmat when when tags is false', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[1]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="PENDING_APPROVAL"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureTagsFlags}
                pQueryState={qs}
            />,
        );
        const tags = wrapper.getByTestId('tags-cell');
        expect(tags.textContent).toBe('');
    });

    it('Should render -- when when planEntity is Trip ', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[2]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="PENDING_APPROVAL"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureTagsFlags}
                pQueryState={qs}
            />,
        );
        const tags = wrapper.getByTestId('tags-cell');
        expect(tags.textContent).toBe('');
    });

    it('should not show Operational Satus column data cell  if feature flag false', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showTagsCol: false }}
                pQueryState={qs}
            />,
        );

        const cell = screen.queryByTestId('tags-cell');
        expect(cell).toBeNull();
    });

    it('should render without crashing TNT', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[6]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={3}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );

        expect(wrapper).toBeDefined();

        const timeDiffCell = wrapper.getByTestId('differenceStartTime-cell');
        expect(timeDiffCell.textContent).toBe('1 hour');

        const planIdCell = wrapper.getByTestId('numberOfStopsRemaining-cell');
        expect(planIdCell.textContent).toBe('1');

        const nextStopCityCell = wrapper.getByTestId('next-stop-city_province');
        expect(nextStopCityCell.textContent).toBe('SPRING HILL');

        const nextStopNameCell = wrapper.getByTestId('next-stop-type_stopId_name');
        expect(nextStopNameCell.textContent).toBe('VNDR - 9710585 - CLOROX NO REEFER (AEC)');
    });

    it('should render without crashing TNT numberOfStopsRemaining zero', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[7]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={3}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );

        expect(wrapper).toBeDefined();
        const timeDiffCell = wrapper.queryByTestId('differenceStartTime-cell');
        expect(timeDiffCell).toBeNull();

        const planIdCell = wrapper.getByTestId('numberOfStopsRemaining-cell');
        expect(planIdCell.textContent).toBe('0');

        const nextStopCityCell = wrapper.queryByTestId('next-stop-city_province');
        expect(nextStopCityCell.textContent).toBe('');

        const nextStopNameCell = wrapper.queryByTestId('next-stop-type_stopId_name');
        expect(nextStopNameCell).toBeNull();
    });

    it('should test columns in processing tab', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[2]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="AWAITING_CARRIER_ASSIGNMNET"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );
        const planIdCell = screen.getByTestId('planId-cell');
        const planTypeCell = screen.getByTestId('planType-cell');
        const distanceCell = screen.getByTestId('distance-cell');
        const planStartTimeCell = screen.getByTestId('planStartTime-cell');
        const durationCell = screen.getByTestId('duration-cell');
        const pickupStopsCell = screen.getByTestId('pickupStops-cell');
        const deliveryStopsCell = screen.getByTestId('deliveryStops-cell');
        const trailerIDCell = screen.getByTestId('trailerId-cell');
        const destinationIdCell = screen.getByTestId('destination-cell');
        const originIdCell = screen.getByTestId('origin-cell');
        const endDatePlanned = screen.getByTestId('endDatePlanned-cell');
        const carrierIdCell = screen.getByTestId('carrierId-cell');
        const serviceTerritoryCell = screen.getByTestId('serviceTerritory-cell');
        const driverIdcell = screen.getByTestId('driverId-cell');
        const billsByTimecell = screen.getByTestId('billsByTime-cell');

        expect(planIdCell.textContent).toBe('30068925');
        expect(planTypeCell.textContent).toBe('Trip - STR2');
        expect(distanceCell.textContent).toBe('70');
        expect(planStartTimeCell.textContent).toBe(' 21 Nov, 2022, 9:21 pm ');
        expect(durationCell.textContent).toBe('11:45');
        expect(pickupStopsCell.textContent).toBe('1');
        expect(deliveryStopsCell.textContent).toBe('2');
        expect(trailerIDCell.textContent).toBe('trailerIdOfFirstLoadForTrip');
        expect(destinationIdCell.textContent).toBe('STORE - 751 - BA MOSTAZAL, ');
        expect(originIdCell.textContent).toBe('DC - 6001 - EKONO DC, ');
        expect(endDatePlanned.textContent).toBe('14 Oct, 2023 (GMT-4)');
        expect(carrierIdCell.textContent).toBe('');
        expect(serviceTerritoryCell.textContent).toBe('6801');
        expect(driverIdcell.textContent).toBe('');
        expect(billsByTimecell.textContent).toBe('20 Mar, 2022, 9:32 am');
    });

    it('should test all columns in Ready to start tab', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[5]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );
        const planIdCell = screen.getByTestId('planId-cell');
        const planTypeCell = screen.getByTestId('planType-cell');
        const distanceCell = screen.getByTestId('distance-cell');
        const planStartTimeCell = screen.getByTestId('planStartTime-cell');
        const durationCell = screen.getByTestId('duration-cell');
        const pickupStopsCell = screen.getByTestId('pickupStops-cell');
        const deliveryStopsCell = screen.getByTestId('deliveryStops-cell');
        const trailerIDCell = screen.getByTestId('trailerId-cell');
        const destinationIdCell = screen.getByTestId('destination-cell');
        const originIdCell = screen.getByTestId('origin-cell');
        const endDatePlanned = screen.getByTestId('endDatePlanned-cell');
        const carrierIdCell = screen.getByTestId('carrierId-cell');
        const serviceTerritoryCell = screen.getByTestId('serviceTerritory-cell');
        const driverIdcell = screen.getByTestId('driverId-cell');
        const billsByTimecell = screen.getByTestId('billsByTime-cell');

        expect(planIdCell.textContent).toBe('30003577');
        expect(planTypeCell.textContent).toBe('Trip - STR2');
        expect(distanceCell.textContent).toBe('234');
        expect(planStartTimeCell.textContent).toBe(' 7 Jul, 2022, 1:30 am ');
        expect(durationCell.textContent).toBe('11:45');
        expect(pickupStopsCell.textContent).toBe('1');
        expect(deliveryStopsCell.textContent).toBe('1');
        expect(trailerIDCell.textContent).toBe('trailerIdOfFirstLoadForTrip+1');
        expect(destinationIdCell.textContent).toBe('STORE - 997 - SBA Lota ( Arturo Prat), ');
        expect(originIdCell.textContent).toBe('DC - 6010 - CD CHILLAN, ');
        expect(endDatePlanned.textContent).toBe('14 Oct, 2023 (GMT-4)');
        expect(carrierIdCell.textContent).toBe('77775020');
        expect(serviceTerritoryCell.textContent).toBe('6801');
        expect(driverIdcell.textContent).toBe('15492484JOSE ACUÑA');
        expect(billsByTimecell.textContent).toBe('20 Mar, 2022, 9:32 am');
    });

    it('should test all Colums in Intransit tab', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[0]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={3}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="EARLY"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );
        const planIdCell = screen.getByTestId('planId-cell');
        const planTypeCell = screen.getByTestId('planType-cell');
        const distanceCell = screen.getByTestId('distance-cell');
        const durationCell = screen.getByTestId('duration-cell');
        const pickupStopsCell = screen.getByTestId('pickupStops-cell');
        const deliveryStopsCell = screen.getByTestId('deliveryStops-cell');
        const trailerIDCell = screen.getByTestId('trailerId-cell');
        const destinationIdCell = screen.getByTestId('destination-cell');
        const originIdCell = screen.getByTestId('origin-cell');
        const carrierIdCell = screen.getByTestId('carrierId-cell');
        const serviceTerritoryCell = screen.getByTestId('serviceTerritory-cell');
        const driverIdcell = screen.getByTestId('driverId-cell');
        const billsByTimecell = screen.getByTestId('billsByTime-cell');
        const actionsCell = screen.getByTestId('actions-cell');
        const intrasitStartDatePlannedCell = screen.getByTestId('intrasitStartDatePlanned-cell');
        const inTransitEndDatePlannedCell = screen.getByTestId('endDatePlanned-cell');
        const inTransitEndDateEstimatedCell = screen.getByTestId('endDateEstimated-cell');

        expect(planIdCell.textContent).toBe('30008802');
        expect(planTypeCell.textContent).toBe('Load - ');
        expect(distanceCell.textContent).toBe('70');
        expect(durationCell.textContent).toBe('10:45');
        expect(pickupStopsCell.textContent).toBe('1');
        expect(deliveryStopsCell.textContent).toBe('2');
        expect(trailerIDCell.textContent).toBe('CMAUTESTCONT640');
        expect(destinationIdCell.textContent).toBe('STORE - 751 - destinationName, ');
        expect(originIdCell.textContent).toBe('DC - 6001 - originName, ');
        expect(carrierIdCell.textContent).toBe('77775020');
        expect(serviceTerritoryCell.textContent).toBe('6801');
        expect(driverIdcell.textContent).toBe('15492484JOSE ACUÑA');
        expect(billsByTimecell.textContent).toBe('20 Mar, 2022, 9:32 am');
        expect(actionsCell.textContent).toBe('...');
        expect(intrasitStartDatePlannedCell.textContent).toBe('21 Nov, 2022');
        expect(inTransitEndDatePlannedCell.textContent).toBe('14 Oct, 2023 (GMT-4)');
        expect(inTransitEndDateEstimatedCell.textContent).toBe('--');
    });

    it('should test all columns in Delivered tab', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[0]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={4}
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypesMock}
                pTripStatus="EARLY"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );

        const planIdCell = screen.getByTestId('planId-cell');
        const planTypeCell = screen.getByTestId('planType-cell');
        const distanceCell = screen.getByTestId('distance-cell');
        const durationCell = screen.getByTestId('duration-cell');
        const pickupStopsCell = screen.getByTestId('pickupStops-cell');
        const deliveryStopsCell = screen.getByTestId('deliveryStops-cell');
        const trailerIDCell = screen.getByTestId('trailerId-cell');
        const destinationIdCell = screen.getByTestId('destination-cell');
        const originIdCell = screen.getByTestId('origin-cell');
        const carrierIdCell = screen.getByTestId('carrierId-cell');
        const serviceTerritoryCell = screen.getByTestId('serviceTerritory-cell');
        const driverIdcell = screen.getByTestId('driverId-cell');
        const billsByTimecell = screen.getByTestId('billsByTime-cell');
        const deliveredEndDatePlannedCell = screen.getByTestId('endDatePlanned-cell');
        const deliveredEndDateActualCell = screen.getByTestId('endDateActual-cell');
        const checkBox = screen.getByTestId('dt-chkbx-4-30008802');

        expect(planIdCell.textContent).toBe('30008802');
        expect(planTypeCell.textContent).toBe('Load - ');
        expect(distanceCell.textContent).toBe('70');
        expect(durationCell.textContent).toBe('10:45');
        expect(pickupStopsCell.textContent).toBe('1');
        expect(deliveryStopsCell.textContent).toBe('2');
        expect(trailerIDCell.textContent).toBe('CMAUTESTCONT640');
        expect(destinationIdCell.textContent).toBe('STORE - 751 - destinationName, ');
        expect(originIdCell.textContent).toBe('DC - 6001 - originName, ');
        expect(carrierIdCell.textContent).toBe('77775020');
        expect(serviceTerritoryCell.textContent).toBe('6801');
        expect(driverIdcell.textContent).toBe('15492484JOSE ACUÑA');
        expect(billsByTimecell.textContent).toBe('20 Mar, 2022, 9:32 am');
        expect(deliveredEndDatePlannedCell.textContent).toBe('14 Oct, 2023 (GMT-4)');
        expect(deliveredEndDateActualCell.textContent).toBe('--');
        expect(checkBox).toBeDefined();
    });

    it('should test all Columns in planning tab without data', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={0}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="PENDING_APPROVAL"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );

        const planIdCell = screen.getByTestId('planId-cell');
        const planTypeCell = screen.getByTestId('planType-cell');
        const distanceCell = screen.getByTestId('distance-cell');
        const durationCell = screen.getByTestId('duration-cell');
        const pickupStopsCell = screen.getByTestId('pickupStops-cell');
        const deliveryStopsCell = screen.getByTestId('deliveryStops-cell');
        const trailerIDCell = screen.getByTestId('trailerId-cell');
        const endDatePlanned = screen.getByTestId('endDatePlanned-cell');

        expect(endDatePlanned.textContent).toBe('');
        expect(trailerIDCell.textContent).toBe('');
        expect(planIdCell.textContent).toBe('');
        expect(planTypeCell.textContent).toBe('undefined - undefined');
        expect(distanceCell.textContent).toBe('');
        expect(durationCell.textContent).toBe('');
        expect(pickupStopsCell.textContent).toBe('');
        expect(deliveryStopsCell.textContent).toBe('');
    });

    it('should test endDatePlanned in processing tab with out data', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_CARRIER_ASSIGNMNET"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );

        const endDatePlannedCell = screen.getByTestId('endDatePlanned-cell');
        expect(endDatePlannedCell.textContent).toBe('');
    });

    it('should test endDatePlanned in Ready to start tab with out data', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );

        const endDatePlannedCell = screen.getByTestId('endDatePlanned-cell');
        expect(endDatePlannedCell.textContent).toBe('');
    });

    it('should not show Primary destination column data cell  if feature flag false/undefined', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={pFeatureFlag}
                pQueryState={qs}
            />,
        );

        const cell = screen.queryByTestId('primaryDestination-cell');
        expect(cell).toBeNull();
    });

    it('should show Primary destination column data cell  if feature flag true', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showPrimaryDestinationCol: true }}
                pQueryState={qs}
            />,
        );

        const cell = screen.getByTestId('primaryDestination-cell');
        expect(cell).toBeDefined();
    });

    it('should navigate the user to the location details page in a new tab', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={transformedPlanMockUS[6]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showPrimaryDestinationCol: true }}
                pQueryState={qs}
            />,
        );
        const mockedOpen = jest.fn();
        const originalOpen = window.open;
        window.open = mockedOpen;
        const page = `http://${window.location.host}/stride/location/details?type=123&id=STORE`;
        const priDesId = screen.getByTestId('primaryDestination-cell');
        fireEvent.click(priDesId);
        openPageInNewTab(page);
        expect(mockedOpen).toBeCalled();
        window.open = originalOpen;
    });

    it('should show Dwell days column data cell  if feature flag true - planning', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={0}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showDwellDays: true }}
                pQueryState={qs}
            />,
        );

        const cell = screen.getByTestId('dwellDays-cell');
        expect(cell).toBeDefined();
    });
    it('should show Dwell days column data cell  if feature flag true - processing', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showDwellDays: true }}
                pQueryState={qs}
            />,
        );

        const cell = screen.getByTestId('dwellDays-cell');
        expect(cell).toBeDefined();
    });
    it('should show Dwell days column data cell  if feature flag true - Ready to start', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showDwellDays: true }}
                pQueryState={qs}
            />,
        );

        const cell = screen.getByTestId('dwellDays-cell');
        expect(cell).toBeDefined();
    });
    it('should not show Dwell days column data cell  if feature flag true - In transit', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={3}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showDwellDays: true }}
                pQueryState={qs}
            />,
        );

        const cell = screen.queryByTestId('dwellDays-cell');
        expect(cell).toBeNull();
    });
    it('should not show Dwell days column data cell  if feature flag true - Delivered', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={4}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showDwellDays: true }}
                pQueryState={qs}
            />,
        );

        const cell = screen.queryByTestId('dwellDays-cell');
        expect(cell).toBeNull();
    });
    it('should not show Dwell days column data cell  if feature flag false - planning', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={0}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showDwellDays: false }}
                pQueryState={qs}
            />,
        );

        const cell = screen.queryByTestId('dwellDays-cell');
        expect(cell).toBeNull();
    });
    it('should not show Dwell days column data cell  if feature flag false - processing', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showDwellDays: false }}
                pQueryState={qs}
            />,
        );

        const cell = screen.queryByTestId('dwellDays-cell');
        expect(cell).toBeNull();
    });
    it('should not show Dwell days column data cell  if feature flag false - Ready to start', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showDwellDays: false }}
                pQueryState={qs}
            />,
        );

        const cell = screen.queryByTestId('dwellDays-cell');
        expect(cell).toBeNull();
    });

    it('should not show trip and planning service territory column data cell  if feature flag true - planning', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={0}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: true }}
                pQueryState={qs}
            />,
        );

        const tripServiceTerritorycell = screen.queryByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeNull();
        const planninggServiceTerritorycell = screen.queryByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeNull();
    });
    it('should show trip and planning service territory column data cell  if feature flag true - processing', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: true }}
                pQueryState={qs}
            />,
        );

        const tripServiceTerritorycell = screen.getByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeDefined();
        const planninggServiceTerritorycell = screen.getByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeDefined();
    });
    it('should show trip and planning service territory column data cell  if feature flag true - Ready to start', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: true }}
                pQueryState={qs}
            />,
        );

        const tripServiceTerritorycell = screen.getByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeDefined();
        const planninggServiceTerritorycell = screen.getByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeDefined();
    });
    it('should show trip and planning service territory column data cell  if feature flag true - In transit', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={3}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: true }}
                pQueryState={qs}
            />,
        );

        const tripServiceTerritorycell = screen.getByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeDefined();
        const planninggServiceTerritorycell = screen.getByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeDefined();
    });
    it('should show trip and planning service territory column data cell  if feature flag true - Delivered', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={4}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: true }}
                pQueryState={qs}
            />,
        );

        const tripServiceTerritorycell = screen.getByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeDefined();
        const planninggServiceTerritorycell = screen.getByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeDefined();
    });
    it('should not show trip and planning service territory column data cell  if feature flag false - processing', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={1}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: false }}
                pQueryState={qs}
            />,
        );

        const serviceTerritorycell = screen.queryByTestId('serviceTerritory-cell');
        expect(serviceTerritorycell).toBeDefined();
        const tripServiceTerritorycell = screen.queryByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeNull();
        const planninggServiceTerritorycell = screen.queryByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeNull();
    });
    it('should not show trip and planning service territory column data cell  if feature flag false - Ready to start', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={2}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: false }}
                pQueryState={qs}
            />,
        );

        const serviceTerritorycell = screen.queryByTestId('serviceTerritory-cell');
        expect(serviceTerritorycell).toBeDefined();
        const tripServiceTerritorycell = screen.queryByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeNull();
        const planninggServiceTerritorycell = screen.queryByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeNull();
    });
    it('should not show trip and planning service territory column data cell  if feature flag false - In transit', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={3}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: false }}
                pQueryState={qs}
            />,
        );

        const serviceTerritorycell = screen.queryByTestId('serviceTerritory-cell');
        expect(serviceTerritorycell).toBeDefined();
        const tripServiceTerritorycell = screen.queryByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeNull();
        const planninggServiceTerritorycell = screen.queryByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeNull();
    });
    it('should not show trip and planning service territory column data cell  if feature flag false - Delivered', () => {
        const mockFn = jest.fn();
        render(
            <PlanTableRowUS
                pRowData={[]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pSetActionRow={jest.fn()}
                pTabIndex={4}
                pUserPerm={permissionsMock}
                mdmLocationTypes={{}}
                pTripStatus="AWAITING_PICKUP"
                pActionTrigger={() => {}}
                pFeatureFlag={{ showServiceTerritory: false }}
                pQueryState={qs}
            />,
        );

        const serviceTerritorycell = screen.queryByTestId('serviceTerritory-cell');
        expect(serviceTerritorycell).toBeDefined();
        const tripServiceTerritorycell = screen.queryByTestId('trip-serviceTerritory-cell');
        expect(tripServiceTerritorycell).toBeNull();
        const planninggServiceTerritorycell = screen.queryByTestId('planning-serviceTerritory-cell');
        expect(planninggServiceTerritorycell).toBeNull();
    });
});
it('Should render onHold when hold is true', () => {
    const mockFn = jest.fn();
    const wrapper = render(
        <PlanTableRowUS
            pRowData={transformedPlanMockUS[9]}
            pCheckedRows={[]}
            pSetCheckedRows={mockFn}
            pSetActionRow={jest.fn()}
            pTabIndex={1}
            pUserPerm={permissionsMock}
            mdmLocationTypes={mdmLocationTypesMock}
            pTripStatus="PENDING_APPROVAL"
            pActionTrigger={() => {}}
            pFeatureFlag={pFeatureTagsFlags}
            pQueryState={qs}
        />,
    );
    const tags = wrapper.getByTestId('tags-cell');
    expect(tags.textContent).toBe('Oh');
});

it('Should render Not hold when when tags is false', () => {
    const mockFn = jest.fn();
    const rowData = {
        ...transformedPlanMockUS[9],
        hold: {
            onHold: false,
            holdReason: 'hold',
        },
    };
    const wrapper = render(
        <PlanTableRowUS
            pRowData={transformedPlanMockUS[2]}
            pCheckedRows={[]}
            pSetCheckedRows={mockFn}
            pSetActionRow={jest.fn()}
            pTabIndex={1}
            pUserPerm={permissionsMock}
            mdmLocationTypes={mdmLocationTypesMock}
            pTripStatus="PENDING_APPROVAL"
            pActionTrigger={() => {}}
            pFeatureFlag={pFeatureTagsFlags}
            pQueryState={qs}
        />,
    );
    const tags = wrapper.getByTestId('tags-cell');
    expect(tags.textContent).toBe('');
});
