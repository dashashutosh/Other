import React from 'react';
import { render, screen, fireEvent } from '../../../../utils/test-utils';
import NoResults from '../NoResults';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../../service/__tests__/mocks/mocks/TripMapper.mock';

beforeAll(() => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMockUS);
});

describe('No Results', () => {
    it('renders correctly as intended', () => {
        const handleClick = jest.fn();
        render(<NoResults pOnBack={handleClick} />);
        const backBtn = screen.getByTestId('goBack');
        fireEvent.click(backBtn);
        expect(handleClick).toBeCalled();
    });
});
