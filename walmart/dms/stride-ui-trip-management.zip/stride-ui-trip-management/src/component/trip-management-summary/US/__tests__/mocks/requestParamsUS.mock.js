export const params = {
    trackingId: '500000639',
    trackingIdType: 'TRIP',
    plans: [
        {
            actual: {
                arrivalTs: '2023-02-01T11:30:00+0530',
                departureTs: '2023-02-02T11:30:00+0530',
            },
            reasonCodes: [
                {
                    name: 'Late Pickup',
                    description: 'Late Pickup',
                },
            ],
            stopId: 6094,
            stopType: 'DC',
            stopSeqNumber: 1,
            planSequenceNumber: 1,
            trackingId: '1000035639',
            trackingIdType: 'LOAD',
        },
        {
            actual: {
                arrivalTs: '2023-02-17T11:30:00+0530',
                departureTs: '2023-02-24T11:30:00+0530',
            },
            reasonCodes: [
                {
                    name: '',
                    description: '',
                },
            ],
            stopId: 100,
            stopType: 'STORE',
            stopSeqNumber: 2,
            planSequenceNumber: 1,
            trackingId: '1000035639',
            trackingIdType: 'LOAD',
        },
    ],
};
export const request = {
    trackingId: '500000639',
    trackingIdType: 'TRIP',
    plans: [
        {
            planSequenceNumber: 1,
            trackingId: '1000035639',
            trackingIdType: 'LOAD',
            transits: [
                {
                    actual: {
                        arrivalTs: '2023-02-01T11:30:00+0530',
                        departureTs: '2023-02-02T11:30:00+0530',
                    },
                    reasonCodes: [
                        {
                            name: 'Late Pickup',
                            description: 'Late Pickup',
                        },
                    ],
                    stopId: 6094,
                    stopSeqNumber: 1,
                    stopType: 'DC',
                },
                {
                    actual: {
                        arrivalTs: '2023-02-17T11:30:00+0530',
                        departureTs: '2023-02-24T11:30:00+0530',
                    },
                    reasonCodes: [
                        {
                            name: '',
                            description: '',
                        },
                    ],
                    stopId: 100,
                    stopSeqNumber: 2,
                    stopType: 'STORE',
                },
            ],
        },
    ],
};
export const transformUSPlanPreviewDataMockResult = {
    actions: [
        {
            desc: 'trip.action.generate.trip.sheet',
            multipleTrips: false,
            name: 'GENERATE_TRIP_SHEET',
        },
        {
            desc: 'trip.action.edit.trailer.id',
            multipleTrips: false,
            name: 'EDIT_TRAILER_ID',
        },
        {
            desc: 'trip.action.add.reverse.logistics',
            multipleTrips: false,
            name: 'ADD_REVERSE_LOGISTICS',
        },
        {
            desc: 'trip.action.manual.dispatch',
            multipleTrips: false,
            name: 'EDIT_DISPATCH',
        },
        {
            desc: 'trip.action.force.load.in.transit',
            multipleTrips: false,
            name: 'FORCE_TO_IN_TRANSIT',
        },
        {
            desc: 'trip.action.edit',
            multipleTrips: false,
            name: 'EDIT',
        },
        {
            desc: 'trip.action.cancel',
            multipleTrips: false,
            name: 'CANCEL',
        },
    ],
    actualStartTime: undefined,
    actualTs: '--',
    billsByTime: '20 Mar, 2022, 09:32 am (GMT+0)',
    carrierId: '77775020',
    carrierName: 'TRANSPORTES TRANS-CAVALIERI LIMITAD',
    carrierStatus: undefined,
    carrierStatusDesc: '',
    comments: undefined,
    departureTs: '--',
    destinationCity: '',
    destinationId: '997',
    destinationName: 'SBA Lota ( Arturo Prat)',
    destinationProvince: '',
    destinationType: 'STORE',
    priDestinationCity: '',
    priDestinationId: '',
    priDestinationName: '',
    priDestinationProvince: '',
    priDestinationType: '',
    dwellDays: '--',
    distance: '',
    distanceUoM: '',
    driverId: '15492484',
    driverName: 'JOSE ACUÑA',
    driverStatusDesc: undefined,
    duration: '00:00',
    editableCards: [
        {
            name: 'SUMMARY',
        },
        {
            name: 'COMMENTS',
        },
    ],
    editableFields: [
        {
            cards: [
                {
                    name: 'SUMMARY',
                },
            ],
            name: 'TRIP_TYPE',
        },
        {
            cards: [
                {
                    name: 'SUMMARY',
                },
            ],
            name: 'BILLS_BY_TIME',
        },
        {
            cards: [
                {
                    name: 'COMMENTS',
                },
            ],
            name: 'COMMENTS',
        },
    ],
    endDatePlanned: '14 Oct, 2023, 12:00 am (GMT+0)',
    equipmentStatus: undefined,
    equipmentStatusDesc: undefined,
    ibob: undefined,
    isApproved: true,
    isTrip: true,
    loadCount: 0,
    loadLtmCoreStatus: undefined,
    nextStopCity: '',
    nextStopId: '',
    nextStopName: '',
    nextStopProvince: '',
    nextStopType: '',
    noOfDropoffStops: '--',
    noOfPickupStops: '1',
    numberOfStopsRemaining: '',
    originCity: '',
    originId: '6010',
    originName: 'CD CHILLAN',
    originProvince: '',
    originType: 'DC',
    phase: {
        color: 'blue',
        desc: 'plan.phase.ready.to.start',
        index: 400,
        name: 'READY_TO_START',
    },
    pickupTimeAtOrigin: undefined,
    planEntity: undefined,
    hazmat: '',
    hazmatAbbr: '',
    planId: '30003577',
    planStatus: '',
    planType: 'STR',
    plannedStartTime: undefined,
    plans: [],
    printed: '',
    printedAbbr: '',
    priority: '--',
    serviceTerritory: '6801',
    tripServiceTerritory: '1234',
    planningServiceTerritory: '-',
    statusComments: [],
    statusDesc: '--',
    statusObj: undefined,
    tntStatus: undefined,
    trailerCountForTrip: 0,
    trailerId: 'KZFX83',
    trailerIdOfFirstLoadForTrip: '--',
    tripLtmCoreStatus: undefined,
    uiLoadType: undefined,
    uiStatus: {
        color: 'red',
        desc: 'ui.status.delayed.pickup',
        index: 400,
        name: 'DELAYED_PICKUP',
    },
    uiTripType: undefined,
};
