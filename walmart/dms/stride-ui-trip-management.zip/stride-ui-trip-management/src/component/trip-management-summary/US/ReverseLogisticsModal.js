import React, { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
// import { ReverseLogistics } from '@walmart/stride-ui-commons';
import { Alert } from '@walmart/living-design-sc-ui';
import { createPortal } from 'react-dom';
import { getErrorText } from '../../../utils/CommonUtils';
import { ERROR_CONTAINER_ID } from '../../../Constants';
import axios from '../../../axios';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;
const ReverseLogisticsModal = ({
    pActionSuccessCb,
    pLocationTypes,
    pSetsIsModalOpen,
    pCheckedPlans,
    pMapApiKey,
    pLoadTypes,
    pOnRLOGSuccess,
}) => {
    const { prefLang, userInfo, currentMarket } = AppUtils.get();
    const [sError, setsError] = useState('');
    const trans = localizeLang();
    const APIParams = {
        axios,
        currentMarket,
        language: prefLang.current,
        userId: userInfo.loggedInUserName,
        hostname: window.location.hostname,
        usUsTenant: true,
        timeout: 5000,
    };
    const handleCloseModal = useCallback(() => pSetsIsModalOpen(false), []);
    const handleSuccess = useCallback(() => {
        pActionSuccessCb();
        handleCloseModal();
        pOnRLOGSuccess(true);
    }, []);
    const handleFailure = (err) => {
        if (err?.errors[0]?.errorIdentifiers) {
            const { details } = err.errors[0].errorIdentifiers; // Todo: error handling
            setsError(details?.errors?.[0]?.description);
        } else {
            setsError(err);
        }
        handleCloseModal();
    };
    return (
        <>
            {sError
                ? createPortal(
                      // Todo: R2- review comment - This should be Toast right?
                      <Alert
                          variant="error"
                          data-testid="rlogFailAlert"
                          onClose={() => {
                              setsError('');
                          }}
                      >
                          {getErrorText(sError, trans)}
                      </Alert>,
                      document.getElementById(ERROR_CONTAINER_ID),
                  )
                : null}
            {/* <ReverseLogistics
                pMapApiKey={pMapApiKey}
                pLocationTypes={pLocationTypes}
                pApiConfig={APIParams}
                pOnClose={handleCloseModal}
                pOnSuccess={handleSuccess}
                pPlanId={pCheckedPlans[0]}
                pLoadTypes={pLoadTypes}
                pOnFailure={handleFailure}
            /> */}
        </>
    );
};
const LocationTypeObjectShape = PropTypes.shape({
    id: PropTypes.string,
    value: PropTypes.string,
});
const propTypes = {
    pActionSuccessCb: PropTypes.func.isRequired,
    pOnRLOGSuccess: PropTypes.func.isRequired,
    pLocationTypes: PropTypes.arrayOf(LocationTypeObjectShape).isRequired,
    pSetsIsModalOpen: PropTypes.func.isRequired,
    pCheckedPlans: PropTypes.arrayOf(PropTypes.string).isRequired,
    pMapApiKey: PropTypes.string.isRequired,
    pLoadTypes: PropTypes.arrayOf(LocationTypeObjectShape).isRequired,
};
ReverseLogisticsModal.propTypes = propTypes;
export default ReverseLogisticsModal;
