import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import AutoTender from '../AutoTender';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from './mocks/USMocks';

const mockPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockPush,
    }),
}));

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('Auto tender', () => {
    it('should render without crashing', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <AutoTender
                pIsOpen
                pOnClose={mockFn}
                pActionRow={{
                    originType: '',
                    originId: '',
                    destinationType: '',
                    destinationId: '',
                    planId: '',
                }}
                pListLocationTypes={[]}
                pPlanIds={[]}
                pPickupDates={{
                    originPickupDate: '2/12/2023',
                }}
            />,
        );
        expect(wrapper).toBeDefined();
    });

    it('should check origin location and final destination', () => {
        const mockFn = jest.fn();
        render(
            <AutoTender
                pIsOpen
                pOnClose={mockFn}
                pActionRow={{
                    originType: 'STORE',
                    originId: '32164',
                    destinationType: 'STORE',
                    destinationId: '789456',
                    planId: '12345',
                }}
                pListLocationTypes={[]}
                pPlanIds={[]}
                pPickupDates={{
                    originPickupDate: '2/12/2023',
                }}
            />,
        );
        const originLocation = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocation).toBeDefined();
        expect(originLocation.value).toBe('STORE - 32164');

        const finalDestination = screen.getByTestId('locationId-destination').querySelector('input');
        expect(finalDestination).toBeDefined();
        expect(finalDestination.value).toBe('STORE - 789456');
    });

    it('should check auto tender button enable with empty fields', () => {
        const mockFn = jest.fn();
        render(
            <AutoTender
                pIsOpen
                pOnClose={mockFn}
                pActionRow={{
                    originType: 'STORE',
                    originId: '32164',
                    destinationType: 'STORE',
                    destinationId: '789456',
                    planId: '12345',
                }}
                pListLocationTypes={[]}
                pPlanIds={[]}
                pPickupDates={{
                    originPickupDate: '2/12/2023',
                }}
            />,
        );
        const originLocation = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocation).toBeDefined();
        expect(originLocation.value).toBe('STORE - 32164');

        const finalDestination = screen.getByTestId('locationId-destination').querySelector('input');
        expect(finalDestination).toBeDefined();
        expect(finalDestination.value).toBe('STORE - 789456');

        const originPickupDate = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(originPickupDate).toBeDefined();
        fireEvent.change(originPickupDate, { target: { value: '08/05/2023' } });
        expect(originPickupDate.value).toBe('08/05/2023');

        const submitBtn = screen.getByTestId('auto-tender-button');
        expect(submitBtn).toBeDefined();
    });
});
