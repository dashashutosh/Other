import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useHistory } from 'react-router-dom';
import {
    TableContainer,
    Table,
    TableHead,
    TableWrapper,
    TableRow,
    TableCell,
    TableBody,
    TableHeader,
    TableHeaderLHS,
    TextInput,
    SearchIcon,
    TableHeaderRHS,
    Typography,
    TableActionHeader,
    Button,
    CloseIcon,
    Alert,
    Toast,
    FilterIcon,
    Badge,
    Checkbox,
    MoreIcon,
    DrawerComponent,
} from '@walmart/living-design-sc-ui';
import clsx from 'clsx';
import {
    onSearch as onTableSearch,
    useAPI,
    TableSortLabel,
    TableFooter,
    LoadActionsEnum,
    TripActionsEnum,
    ToastAction,
    transformUSPreviewResponseToUIModel,
    ServiceFailureModal,
    isNullOrUndefined,
    getBulkCommonActions,
    RegenerateBOLConfirmModal,
    UpdateTimelineV2,
    StopSequenceAuditModal,
    UIPlanTypeEnum,
    PrintTripSheet,
    ActionMenu,
    LTMComments,
    getUserName,
    PlanDetailsMapper,
    usehazmatBulkUpdateAPI,
    EditDriverDetails,
} from '@walmart/stride-ui-commons';
import PropTypes, { number, string, bool } from 'prop-types';
import { createPortal } from 'react-dom';
import { ERROR_CONTAINER_ID, SERVICE_ACTION_TYPE } from '../../../Constants';
import { planSearchHeadersUS, toastTimerUS, pinnableColumns } from '../../../ConstantsUS';
import {
    stTripToast,
    stickyColumnPlanTypeNoCheckbox,
    stickyColumnPlanIdNoCheckBox,
    stickyColumnPlanId,
    stickyColumnPlanType,
    stickyColumnCheckbox,
    stickyColumnPlanStatus,
    stickyColumnPlanActions,
    stickyColumnNoCheckbox,
    stickyColumnNoAction,
    stickyColumnTags,
} from '../../../utils/StyleUtils';
import {
    TripAPI,
    getAPIParams,
    getTripDetailsAPIParamsWithQueryParam,
    getLosStaticDataAPIParams,
    getLocationDetailsApiParams,
    getEditTrailerIdsApiParams,
    getUpdateTimelineApiParams,
    getLoadDetailsAPIParamsWithQueryParam,
    getMultiLocationDetailsApiParams,
    getDmaasPrintTripSheetApiParams,
    getEditDriverETDAPIParams,
} from '../../../service/TripAPI';
import {
    getPlanErrorText,
    checkPlanODSame,
    getErrorText,
    getCommentsDrawerProps,
    checkPlanOriginSame,
    checkPlanDestinationSame,
} from '../../../utils/CommonUtils';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../../utils/actions/PlanTableQueryActions';
import { getPlanTableSearchRequestPayload } from '../../../utils/ui-mappers/PlanSearchMappers';
import { QueryStateType } from '../../../utils/types/PlanSearchTypes';
import TripSharedService from '../../../service/TripSharedService';
import PlanExport from '../PlanExport';
import ExceptionFilterChips from '../ExceptionFilterChips';
import TableFilterChipsUS from './TableFilterChipsUS';
import { getColumnsToExport } from '../DataModels';
import {
    getFilteredColumnHeadersUS,
    transformUSPlanPreviewData,
    transformLoadsToEditTailer,
    canAdjustcolumnForTags,
    getTableActions,
    TABLE_ACTIONS_ENUM,
    getPlanListWithUpdatedComments,
} from './DataModelsUS';
import { getUserActions } from '../../../utils/PermissionsUtils';
import PlanTableRowUS from './PlanTableRowUS';
import EditTrailerModal from './EditTrailerModal';
import CancelPlan from './CancelPlan';
import ReverseLogisticsModal from './ReverseLogisticsModal';
import ReviewAndApprove from './ReviewAndApprove';
import AutoTender from './AutoTender';
import UpdateTimelineModal from './UpdateTimelineModal';
import UpdateStatusModal from './UpdateStatusModal';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { Utilities, AppUtils } from '@gscope-mfe/app-bridge';
import { getActionDesc } from '../../../utils/ui-mappers/US/TripDetailsMapper';
import featureConfig from '../../../utils/featureConfig';
import useStrideToast from '../../../hooks/useStrideToast';
import SearchResultsTableUS from './SearchResultsTableUS';
import axios from '../../../axios';
import { getCommentsAPIConfigs } from '../../../service/LTMCommentsAPIConfigs';

const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default,
    { debounce } = Utilities;
const useStyles = makeStyles(() => ({
    stTripToast,
    lhsHeaderAction: {
        alignItems: 'center',
    },
    lhsHeader: {
        display: 'flex',
        flexDirection: 'column',
    },
    lhsInnerRow: {
        display: 'flex',
    },
    lhsInner: {
        flexDirection: 'column',
        alignSelf: 'baseline',
    },
    stTtContainer: {
        maxWidth: 'calc(100vw - 8.5em)',
        display: 'flex',
        flexDirection: 'column',
        '& $table': {
            borderCollapse: 'separate',
            whiteSpace: 'nowrap',
        },
    },
    tableWrapper: {
        flexGrow: 1,
        '&.ld-sc-ui-table-wrapper': {
            maxHeight: 'unset',
        },
        '&.MuiTableContainer-root': {
            overflowX: 'unset',
        },
    },
    table: {
        '& .ld-sc-ui-checkbox-label': {
            paddingLeft: 1,
        },
    },
    centerColumn: {
        textAlign: 'center !important',
    },
    stickyColumn: {
        position: 'sticky',
        backgroundColor: '#fafafa !important',
        '&:not(td)': {
            zIndex: '3 !important',
        },
    },
    onlyLimitSelect: {
        color: '#74767c',
    },
    stickyColumnPlanTypeNoCheckbox,
    stickyColumnPlanIdNoCheckBox,
    stickyColumnPlanId,
    stickyColumnTags,
    stickyColumnPlanType,
    stickyColumnPlanStatus,
    stickyColumnPlanActions,
    stickyColumnCheckbox,
    stickyColumnNoCheckbox,
    stickyColumnNoAction,
    tableHeaderRhs: {
        flex: '2 !important',
        gap: '6px',
    },
    tableContentWrap: {
        '& th.MuiTableCell-head': {
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            fontSize: '14px !important',
            fontWeight: 700,
        },
        '& .stc-33': {
            fontSize: '14px !important',
        },
        '& .MuiTableCell-root.MuiTableCell-head': {
            height: '48px !important',
            padding: '12px',
        },
    },
    headerContainer: {
        paddingBottom: '12px !important',
        flexDirection: 'column',
        rowGap: '15px',
        paddingTop: '0px !important',
    },
    sortTableCell: {
        fontSize: '14px !important',
    },
    actionHeader: {
        position: 'unset !important',
    },
    tableHeader: {
        display: 'flex',
        width: '100%',
    },

    tableActionMenuContainer: {
        '& > button': {
            padding: '0px !important',
        },
    },
    commentsDrawerContent: {
        height: '100vh',
        width: '480px',
        overflow: 'hidden',
        '& div[class^="makeStyles-buttonWrapper-"]': {
            width: 'auto !important',
        },
        zIndex: '999',
        '& span[class^="makeStyles-commentText-"]': {
            textAlign: 'left !important',
        },
    },
}));
export default function PlanTableUS(props) {
    const {
        pTabIndex,
        pConfig,
        pIsAssignTrip,
        pOnTripSelection,
        pStaticData,
        pOnPlanApprove,
        pOnLoadMarkAsDelivered,
        pIsLoading,
        mdmLocationTypes,
        pOnTripSheetGenerate,
        pPhaseCounts,
        queryState,
        dispatch,
        pSetsIsSearchFilterModalOpen,
        pOnRLOGSuccess,
        pSearchAPIResultsCount,
        pIsGlobalSearchFlow,
        pCheckedRows,
        pClientPageNumber,
        pTableSearch,
        pShowNavConfirmationModal,
        pUserPerm,
    } = props;
    const classes = useStyles();
    const trans = localizeLang();
    const history = useHistory();
    const toast = useStrideToast();
    const { currentMarket, prefLang, userInfo, setloading, loading, invokeBulkUpdate } = AppUtils.get();
    const [sHeaderCells, setsHeaderCells] = useState([]);
    // const [sFilteredRows, setsFilteredRows] = useState([]);
    const [sActionRow, setsActionRow] = useState([]);
    const [sIsTripSelected, setsIsTripSelected] = useState(false);
    const [sProcessTripStatus, setsProcessTripStatus] = useState('');
    const [sPlanList, setsPlanList] = useState([]);
    const fetchedPlanListRef = useRef([]);
    const cancelTokenRef = useRef(null);

    const [sFetchPlanError, setsFetchPlanError] = useState('');
    const [loadingState, setLoadingState] = useState({ tableColumnManagementPreferences: false });
    // const [sIsAllSameStatus, setsIsAllSameStatus] = useState(false);
    const [sIsAllTrips, setsIsAllTrips] = useState(false);
    const [sIsUpdateStatusOpen, setsIsUpdateStatusOpen] = useState(false);
    const [sIsAllLoads, setsIsAllLoads] = useState(false);
    const [sIsEditTrailerModalOpen, setsIsEditTrailerModalOpen] = useState(false);
    const [sLoadsToEditTrailer, setsLoadsToEditTrailer] = useState([]);
    const [sIsCancelModalOpen, setsIsCancelModalOpen] = useState(false);
    const [sShowRLogModal, setsShowRLogModal] = useState(false);
    const [sShowReviewAndApproveDrawer, setsShowReviewAndApproveDrawer] = useState(false);
    const [sShowUpdateTimelineModal, setsShowUpdateTimelineModal] = useState(false);
    const [sShowPrintTripSheet, setsShowPrintTripSheet] = useState(false);
    const [sShowStopSequenceAuditModal, setsShowStopSequenceAuditModal] = useState(false);
    const [sShowUpdateTimelineV2Modal, setsShowUpdateTimelineV2Modal] = useState(false);
    const [sShowAutoTenderDrawer, setsShowAutoTenderDrawer] = useState(false);
    const [sIsMarkServiceFailureModalOpen, setsIsMarkServiceFailureModalOpen] = useState(false);
    const [sMarkServiceFailureError, setsMarkServiceFailureError] = useState(false);
    const [sIsSuccess, setsIsSuccess] = useState(false);
    const [sSuccessMessage, setsSuccessMessage] = useState(false);
    const [sBulkSuccess, setsBulkSuccess] = useState('');
    const [sBulkHazmatSuccess, setsBulkHazmatSuccess] = useState('');
    const [sCheckedPlans, setsCheckedPlans] = useState([]);
    const [sError, setsError] = useState('');
    const [sPageError, setsPageError] = useState('');
    const featureFlags = TripSharedService.getFeatureFlags();
    const [sIsRegenerateBOLConfirmationModal, setsIsRegenerateBOLConfirmationModal] = useState(false);
    const [cancelTenderError, setCancelTenderError] = useState('');
    const [showTableColumnManager, setShowTableColumnManager] = useState(false);
    const [sIsDrawerOpen, setsIsDrawerOpen] = useState(false);
    const [sCommentsDrawerInput, setsCommentsDrawerInput] = useState(null);
    const [sOpenEditDriverETD, setsOpenEditDriverETD] = useState(false);
    const [sIsEditDriverSuccess, setsIsEditDriverSuccess] = useState(false);

    const commentsApiConfig = useMemo(
        () => getCommentsAPIConfigs(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName),
        [currentMarket, prefLang, userInfo],
    );

    const { callAPI: fetchLTPlansWithAgg, ...planLTResponseWithAgg } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).planSearchAggregates,
    );
    const { invokeHazmatBulkUpdateAPI } = usehazmatBulkUpdateAPI(
        AppUtils.get,
        setsError,
        featureFlags?.enableHazmatPayload,
    );
    const { callAPI: regenerateBolAPI, ...regenerateBolAPIResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).regernateBolLoad,
    );
    const APIParams = getAPIParams(currentMarket, prefLang.current, userInfo);
    const losApiParams = (featureFlags) =>
        getLosStaticDataAPIParams(
            currentMarket,
            prefLang.current,
            userInfo,
            window.location.hostname,
            false,
            featureFlags,
        );

    const deliveryWindowApiParams = getLocationDetailsApiParams(
        currentMarket,
        prefLang.current,
        userInfo,
        window.location.hostname,
        false,
    );

    const trailerIdEditApiParams = getEditTrailerIdsApiParams(
        currentMarket,
        prefLang.current,
        userInfo,
        window.location.hostname,
        false,
    );

    const timelineEditApiParams = getUpdateTimelineApiParams(
        currentMarket,
        prefLang.current,
        userInfo,
        window.location.hostname,
        false,
    );
    const locationDetailsApiParams = getMultiLocationDetailsApiParams(currentMarket, prefLang.current, userInfo, true);

    const printTripSheetApiParams = getDmaasPrintTripSheetApiParams(
        currentMarket,
        prefLang.current,
        userInfo,
        window.location.hostname,
        true,
    );
    const editDriverETDAPIParams = getEditDriverETDAPIParams(currentMarket, prefLang.current, userInfo);
    const debouncedFn = useCallback(
        debounce((callback) => {
            callback();
        }, 100),
        [],
    );
    const columnsToExport = useMemo(
        () => getColumnsToExport(currentMarket.toUpperCase(), pTabIndex, trans, pConfig?.UOM, featureFlags),
        [currentMarket, pTabIndex, featureFlags],
    );
    const userActions = useMemo(() => {
        if (isNullOrUndefined(TripSharedService.getUserPermissions())) {
            const userPerm = JSON.parse(localStorage.getItem('ngStorage-permissionData'));
            TripSharedService.setUserPermissions(userPerm?.permissions);
        }
        return getUserActions(TripSharedService.getUserPermissions(), currentMarket);
    }, [currentMarket]);
    const getPlansAPI = (req) => {
        fetchLTPlansWithAgg(
            req,
            (res) => {
                if (res?.payload) {
                    const tData = transformUSPreviewResponseToUIModel(
                        res?.payload?.data || [],
                        TripSharedService.getFeatureFlags(),
                        userActions,
                        featureConfig(featureFlags, pConfig),
                    );
                    setsPlanList(tData);
                    // if (!queryState.globalSearchData) {
                    pPhaseCounts(res?.payload?.aggregates?.aggregations?.tssAggregate?.buckets);
                    if (queryState.globalSearchData) {
                        pIsGlobalSearchFlow(true);
                    } else {
                        pIsGlobalSearchFlow(false);
                    }
                }
            },
            (e) => {
                setsFetchPlanError(e);
            },
        );
    };
    const getPlans = () => {
        cancelTokenRef.current = axios.CancelToken.source();
        setsFetchPlanError('');

        const request = getPlanTableSearchRequestPayload(queryState, currentMarket, pConfig, featureFlags, pUserPerm);
        // TODO: pass sort data
        getPlansAPI({ ...request, cancelToken: cancelTokenRef.current.token });
    };
    const actionSuccessCb = () => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_PAGE_NUMBER,
            market: currentMarket,
        });
    };
    const setExceptionType = useCallback((exceptionType) => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_EXCEPTION_TYPE,
            exceptionType,
        });
    }, []);
    useEffect(() => {
        // cancel ongoing request before making new request
        cancelTokenRef.current?.cancel();

        debouncedFn(() => {
            getPlans();
        });
    }, [queryState]);
    useEffect(() => {
        // reset the data in memory when page number becomes 1
        if (queryState.page === 1) {
            fetchedPlanListRef.current = [];
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_CLIENT_PAGE_NUMBER,
            });
        }
    }, [queryState]);
    useEffect(() => {
        setsPlanList([]);
    }, [queryState.activeTabIndex, queryState.groupBy]);
    const handleTableSearch = useCallback(
        (value) => {
            debouncedFn(() => {
                dispatch({
                    type: PLAN_TABLE_QUERY_ACTIONS_ENUM.TABLE_SEARCH,
                    value,
                });
                dispatch({
                    type: PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_CLIENT_PAGE_NUMBER,
                });
            });
        },
        [debouncedFn],
    );
    const handleSortChange = (field) => {
        if (field === queryState.sortField) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_SORT_DIRECTION,
            });
        } else {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_SORT_FIELD,
                sortField: field,
                sortMode: 'DESC',
            });
        }
    };
    const handleReviewAndApproveClose = () => {
        setsShowReviewAndApproveDrawer(false);
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
    };
    const handleAutoTenderClose = () => {
        setsShowAutoTenderDrawer(false);
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
        setsActionRow([]);
    };
    const transformedPlansList = useMemo(() => {
        fetchedPlanListRef.current = [...fetchedPlanListRef.current, ...sPlanList];
        return fetchedPlanListRef.current.map((plan) => transformUSPlanPreviewData(plan, trans, pStaticData));
    }, [sPlanList]);

    const filteredRows = useMemo(() => {
        let rows = [];
        if (pTableSearch && transformedPlansList.length) {
            rows = onTableSearch(transformedPlansList, pTableSearch, planSearchHeadersUS);
        } else {
            rows = transformedPlansList;
        }
        return rows;
    }, [transformedPlansList, pTableSearch]);

    const selectedRows = useMemo(() => {
        if (sActionRow?.length > 0) {
            return sActionRow;
        }
        if (pCheckedRows?.length > 0) {
            return pCheckedRows;
        }
        return [];
    }, [pCheckedRows, sActionRow]);
    const tripDetailsApiParams = useMemo(() => {
        const params = getTripDetailsAPIParamsWithQueryParam({
            lang: prefLang?.current,
            hostname: window?.location?.hostname,
            usUsTenantFlag: false,
            planId: selectedRows[0],
            currentMarket,
            userInfo,
        });
        return {
            ...params,
            language: prefLang?.current,
            userId: userInfo.loggedInUserName,
        };
    }, [selectedRows, currentMarket, prefLang.current, userInfo]);
    const paginatedData = useMemo(() => {
        const rows = filteredRows;
        const numOfRows = pConfig?.rowsPerPage;
        if (rows.length > numOfRows) {
            return rows.slice((pClientPageNumber - 1) * numOfRows, (pClientPageNumber - 1) * numOfRows + numOfRows);
        }
        return rows;
    }, [filteredRows, pClientPageNumber, pConfig]);

    const stopSequeceAuditParams = useMemo(() => {
        const selectedPlan = filteredRows?.find((row) => row?.planId === selectedRows[0]);
        const apiDetails = {
            lang: prefLang?.current,
            hostname: window?.location?.hostname,
            usUsTenantFlag: false,
            planId: selectedPlan?.planId,
            currentMarket,
            userInfo,
        };
        return {
            apiParams: selectedPlan?.isTrip
                ? getTripDetailsAPIParamsWithQueryParam(apiDetails)
                : getLoadDetailsAPIParamsWithQueryParam(apiDetails),
            planType: selectedPlan?.isTrip ? UIPlanTypeEnum.TRIP : UIPlanTypeEnum.LOAD,
        };
    }, [filteredRows, selectedRows, currentMarket, prefLang.current, userInfo]);

    useEffect(() => {
        if (
            pClientPageNumber * pConfig?.rowsPerPage >= fetchedPlanListRef.current?.length &&
            fetchedPlanListRef.current?.length > 0 &&
            fetchedPlanListRef.current?.length > pConfig?.rowsPerPage
        ) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.INCREMENT_PAGE_NUMBER,
            });
        }
    }, [pClientPageNumber, pConfig]);
    const onClearAll = () => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
    };
    const selectedRowsText = () =>
        pCheckedRows?.length === 1 ? trans('planTable.planSelected') : trans('planTable.plansSelected');
    const onEditTrailerModalClose = () => {
        setsIsEditTrailerModalOpen(false);
    };
    const onUpdateStatusModalClose = () => {
        setsIsUpdateStatusOpen(false);
    };
    const getSelectedLoadInfo = () => transformedPlansList.filter((plan) => selectedRows.includes(plan.planId))[0];
    const actionableRow = useMemo(() => getSelectedLoadInfo(), [selectedRows]);
    useEffect(() => {
        setsHeaderCells(getFilteredColumnHeadersUS(pTabIndex, trans, pConfig, featureFlags, queryState?.groupBy));
    }, [pTabIndex, featureFlags, queryState?.groupBy]);
    useEffect(() => {
        if (pTableSearch) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.TABLE_SEARCH,
                value: '',
            });
        }
        if (pCheckedRows?.length) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                checkedRows: [],
            });
        }
    }, [transformedPlansList, queryState.activeTabIndex]);
    useEffect(() => {
        if (selectedRows.length) {
            const loadInfo = getSelectedLoadInfo();
            const loads = loadInfo.plans && loadInfo.plans?.length > 0 ? loadInfo.plans : [loadInfo];
            setsLoadsToEditTrailer(transformLoadsToEditTailer(loads));
        }
    }, [selectedRows]);
    useEffect(() => {
        let isTrip = false;
        let tripStatus = '';
        if (transformedPlansList?.length && selectedRows.length) {
            isTrip = transformedPlansList.filter((plan) => plan.planId === selectedRows[0])[0].isTrip;
            tripStatus = transformedPlansList.filter((plan) => plan.planId === selectedRows[0])[0].planStatus;
            const selectedLoadInfo = transformedPlansList.filter((plan) => selectedRows.includes(plan.planId));

            // Todo
            // setsIsAllSameStatus(selectedLoadInfo.every((plan) => (plan.planStatus
            //   === selectedLoadInfo[0].planStatus)));
            setsIsAllTrips(selectedLoadInfo.every((plan) => plan.isTrip === true));
            setsIsAllLoads(selectedLoadInfo.every((plan) => plan.isTrip === false));
        }
        setsIsTripSelected(isTrip);
        setsProcessTripStatus(tripStatus);
        if (pIsAssignTrip) pOnTripSelection(selectedRows[0]);
    }, [selectedRows]);

    const getDriverId = () => {
        return transformedPlansList.filter((plan) => plan?.planId === selectedRows[0])[0]?.driverId;
    };

    useEffect(() => {
        const isLoading =
            planLTResponseWithAgg.loading ||
            loadingState.tableColumnManagementPreferences ||
            regenerateBolAPIResponse.loading ||
            pIsLoading;

        if (loading) {
            if (!isLoading) {
                setloading(false);
            }
        } else if (isLoading) {
            setloading(true);
        }
    }, [planLTResponseWithAgg.loading, loadingState.tableColumnManagementPreferences, pIsLoading]);

    useEffect(() => {
        if (!sIsCancelModalOpen && !sIsEditTrailerModalOpen) {
            setsActionRow([]);
        }
    }, [sIsCancelModalOpen, sIsEditTrailerModalOpen]);
    const goToUpdateLoad = (plans) => {
        if (plans && plans[0]) {
            history.push({
                pathname: TripSharedService.getFeatureFlags()?.hasPQMigratedToMFE
                    ? '/mfe/stride/planquery/updateload'
                    : '/stride/planquery/updateload',
                search: `?planId=${plans[0]}&section=`,
            });
        }
    };
    const bulkCancelTender = () => {
        invokeBulkUpdate({
            serviceAction: SERVICE_ACTION_TYPE.CANCEL_TENDER.ACTION,
            serviceType: SERVICE_ACTION_TYPE.CANCEL_TENDER.SERVICE,
            data: selectedRows.map((e) => ({
                planId: e,
            })),
        })
            .then((reponse) => {
                if (reponse) {
                    setsSuccessMessage('cancel.tender.success.message');
                    dispatch({
                        type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                        checkedRows: [],
                    });
                }
            })
            .catch((error) => {
                setCancelTenderError(error);
            });
    };
    const handleCancelTender = () => {
        bulkCancelTender();
    };
    const bulkPrintStatusPayload = (data, tripIds) => {
        const bulkHandlers = {
            serviceAction: SERVICE_ACTION_TYPE.MARK_UNMARK_PRINTED.ACTION,
            serviceType: SERVICE_ACTION_TYPE.MARK_UNMARK_PRINTED.SERVICE,
        };
        const payload = [];
        tripIds.forEach((tripId, index) => {
            payload.push({
                executionPlanId: tripId,
                isPrinted: !data[index]?.printed,
            });
        });
        return {
            ...bulkHandlers,
            data: payload,
        };
    };

    const bulkPrintSuccess = (rowCount) => {
        setsBulkSuccess(rowCount);
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
    };

    const handlePrintAction = () => {
        const plans = transformedPlansList?.filter((plan) => selectedRows?.includes(plan.planId));
        invokeBulkUpdate(bulkPrintStatusPayload(plans, selectedRows))
            .then((res) => {
                if (res) {
                    bulkPrintSuccess(selectedRows.length);
                }
            })
            .catch((error) => {
                setsError(error || 'actions.label.UpdateFailed');
            });
    };
    const onSaveSuccess = () => {
        setsSuccessMessage('bol.success.response');
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
    };
    const onErrorResponse = () => {
        setsMarkServiceFailureError(true);
    };

    const handleStopSequenceAction = () => {
        setsShowStopSequenceAuditModal(true);
    };

    const bulkHazmatSuccess = (rowCount) => {
        setsBulkHazmatSuccess(rowCount);
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
    };

    const handleActions = useCallback(
        (action) => {
            switch (action) {
                case LoadActionsEnum.REVIEW_AND_APPROVE.name:
                    setsShowReviewAndApproveDrawer(true);
                    break;
                case LoadActionsEnum.AUTO_TENDER.name:
                    setsShowAutoTenderDrawer(true);
                    break;
                case LoadActionsEnum.CANCEL_TENDER.name:
                    handleCancelTender();
                    break;
                case LoadActionsEnum.APPROVE.name:
                    pOnPlanApprove(selectedRows, actionSuccessCb);
                    setsActionRow([]);
                    break;
                case TripActionsEnum.CANCEL.name:
                case LoadActionsEnum.CANCEL.name:
                    setsIsCancelModalOpen(true);
                    break;
                case TripActionsEnum.GENERATE_TRIP_SHEET.name:
                    pOnTripSheetGenerate(selectedRows, actionSuccessCb);
                    setsActionRow([]);
                    break;
                case LoadActionsEnum.EDIT_EQUIPMENT.name:
                case TripActionsEnum.EDIT_TRAILER_ID.name:
                    setsIsEditTrailerModalOpen(true);
                    break;
                case TripActionsEnum.ADD_REVERSE_LOGISTICS.name:
                    setsShowRLogModal(true);
                    break;
                case TripActionsEnum.UPDATE_TIMELINE_TRIP.name:
                    setsShowUpdateTimelineV2Modal(true);
                    break;
                case TripActionsEnum.FORCE_TO_IN_TRANSIT.name:
                case TripActionsEnum.FORCE_TO_DELIVERED.name:
                    pOnLoadMarkAsDelivered(selectedRows);
                    break;
                case LoadActionsEnum.EDIT.name:
                    goToUpdateLoad(selectedRows);
                    break;
                case LoadActionsEnum.MARK_SERVICE_FAILURE.name:
                    setsIsMarkServiceFailureModalOpen(true);
                    break;
                case LoadActionsEnum.UPDATE_TIMELINE.name:
                    setsShowUpdateTimelineModal(true);
                    break;
                case TripActionsEnum.PRINT_TRIP_SHEET.name:
                    setsShowPrintTripSheet(true);
                    break;
                case LoadActionsEnum.REGENERATE_BOL.name:
                    if (featureFlags?.showRBOLModal) {
                        setsIsRegenerateBOLConfirmationModal(true);
                    } else {
                        regenerateBolAPI(
                            {
                                planId: selectedRows[0],
                            },
                            onSaveSuccess,
                            onErrorResponse,
                        );
                    }
                    break;
                case LoadActionsEnum.UPDATE_STATUS.name:
                    setsIsUpdateStatusOpen(true);
                    break;
                case TripActionsEnum.MARK_UNMARK_PRINTED.name:
                    handlePrintAction();
                    setsBulkSuccess('');
                    break;
                case LoadActionsEnum.MARK_UNMARK_HAZMAT.name:
                    const selectedPlans = transformedPlansList?.filter((plan) => selectedRows?.includes(plan.planId));
                    invokeHazmatBulkUpdateAPI(selectedPlans, bulkHazmatSuccess, trans);
                    break;
                case TripActionsEnum.STOP_SEQUENCE_AUDIT.name:
                case LoadActionsEnum.STOP_SEQUENCE_AUDIT.name:
                    handleStopSequenceAction();
                    break;
                case TripActionsEnum.EDIT_DRIVER_ETD.name:
                    setsOpenEditDriverETD(true);
                    break;
                default:
                    break;
            }
        },
        [selectedRows],
    );

    const onEditDriverETDSuccess = (d) => {
        if (d === 'SUCCESS') {
            setsIsEditDriverSuccess(true);
            setsOpenEditDriverETD(false);
            setloading(false);
        }
    };
    const selectedRowDataMap = useMemo(() => {
        // This object contain the planId as the key and the entire row object as the value
        const result = {};
        if (selectedRows.length) {
            selectedRows.forEach((rowId) => {
                result[rowId] = paginatedData.find((row) => row.planId === rowId);
            });
        }

        return result;
    }, [selectedRows, paginatedData]);

    useEffect(() => {
        const plans = transformedPlansList?.filter((plan) => pCheckedRows?.includes(plan.planId));
        setsCheckedPlans(plans);
    }, [transformedPlansList, pCheckedRows]);
    const getCommonActions = useMemo(
        () =>
            getBulkCommonActions({
                plans: transformedPlansList?.filter((plan) => pCheckedRows?.includes(plan.planId)),
                isMultiRow: pCheckedRows?.length > 1,
                isAllLoads: sIsAllLoads,
                isAllTrips: sIsAllTrips,
            }),
        [pCheckedRows, sIsAllLoads, sIsAllTrips, transformedPlansList],
    );
    const onMarkServiceFailureClose = () => {
        setsIsMarkServiceFailureModalOpen(false);
    };
    const bulkPayload = (data) => {
        const { planIds, comment, id } = data;
        const planData = [];
        const bulkHandlers = {
            serviceAction: SERVICE_ACTION_TYPE.BULK_MARK_SERVICE_FAILURE.ACTION,
            serviceType: SERVICE_ACTION_TYPE.BULK_MARK_SERVICE_FAILURE.SERVICE,
        };
        planIds.forEach((planId) => {
            planData.push({
                planId,
                code: id,
                description: comment,
                commentText: comment,
            });
        });
        return {
            ...bulkHandlers,
            data: planData,
        };
    };
    const handleMarkServiceFailureConfirm = (id, comment) => {
        setsIsMarkServiceFailureModalOpen(false);
        const payload = bulkPayload({
            planIds: selectedRows,
            comment,
            id,
        });
        invokeBulkUpdate(payload)
            .finally(() => {
                setsSuccessMessage('mark.service.failure.success.message');
                dispatch({
                    type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                    checkedRows: [],
                });
            })
            .catch(() => {
                setsMarkServiceFailureError(true);
            });
    };

    const getActionsDesc = (action) => {
        if (action?.name === TripActionsEnum.MARK_UNMARK_PRINTED.name) {
            return trans(getActionDesc(sCheckedPlans, action));
        } else if (action?.name === LoadActionsEnum.MARK_UNMARK_HAZMAT.name) {
            return trans(PlanDetailsMapper.getHazmatActionDesc(sCheckedPlans, action));
        } else {
            return trans(action.desc);
        }
    };
    const getPlanActions = () => (
        <>
            {getCommonActions?.map((action) => (
                <Button
                    className="ml-0 mr-0"
                    data-testid={action.name}
                    key={action.name}
                    variant={
                        action.name === LoadActionsEnum.CANCEL.name ||
                        action.name === TripActionsEnum.MARK_UNMARK_PRINTED.name
                            ? 'secondary'
                            : 'primary'
                    }
                    color={action.name === LoadActionsEnum.CANCEL.name ? 'error' : 'default'}
                    size="small"
                    onClick={() => {
                        handleActions(action?.name);
                    }}
                >
                    {getActionsDesc(action)}
                </Button>
            ))}
        </>
    );
    const actions = () => getPlanActions();

    const tableActions = useMemo(() => getTableActions(featureFlags, trans), [featureFlags, trans]);

    const handleEditTrailerSuccess = () => {
        // Todo
        setsIsSuccess(true);
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
    };
    const footerLabels = {
        previous: trans('button.previous'),
        next: trans('button.next'),
    };
    const onSelectAll = (event) => {
        if (event.target.checked) {
            const checkedRows = paginatedData.map((data) => data.planId);
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                checkedRows,
            });
            return;
        }
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
    };

    const showSuccessToast = (message) => {
        toast({ text: message, variant: 'positive' });
    };

    const onUpdateTimelineSuccess = () => {
        setsShowUpdateTimelineV2Modal(false);
        setsSuccessMessage('msg.updateTimelineSuccess');
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
            checkedRows: [],
        });
    };
    const handlePrintTripSheetError = (error) => {
        setsPageError(error);
        setsShowPrintTripSheet(false);
    };

    const handlePrintTripSheetSuccess = () => {
        setsShowPrintTripSheet(false);
    };

    const handleTableActionsMenuItemClick = (event) => {
        const actionCode = event.currentTarget.dataset.code;

        switch (actionCode) {
            case TABLE_ACTIONS_ENUM.MANAGE_COLUMNS.name:
                setShowTableColumnManager(true);
                break;

            default:
                break;
        }
    };

    const onViewAllComments = (planDetails) => {
        setsCommentsDrawerInput(getCommentsDrawerProps(planDetails));
        setsIsDrawerOpen(true);
    };

    const onCommentsDrawerClose = (commentsDrawerOutput) => {
        const existingPlans = [...fetchedPlanListRef.current];
        fetchedPlanListRef.current = [];
        setsPlanList(getPlanListWithUpdatedComments(existingPlans, sCommentsDrawerInput, commentsDrawerOutput));
        setsCommentsDrawerInput(null);
        setsIsDrawerOpen(false);
    };

    const handleTableColumnManagementLoadingStateChange = (isLoading) =>
        setLoadingState((_loadingState) => ({
            ..._loadingState,
            tableColumnManagementPreferences: isLoading,
        }));

    const header = () => (
        <TableRow key="header" className={classes.tableContentWrap}>
            <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnCheckbox)}>
                <Checkbox
                    color="primary"
                    onChange={onSelectAll}
                    data-testid="selectAll"
                    id="selectAll"
                    partial={
                        paginatedData?.length > 0 &&
                        pCheckedRows?.length > 0 &&
                        pCheckedRows?.length < paginatedData?.length
                    }
                    checked={paginatedData?.length > 0 && pCheckedRows?.length === paginatedData?.length}
                />
            </TableCell>
            {sHeaderCells.map((headCell) => {
                const headerLabel = trans(headCell.label) + (headCell.uom ? `(${headCell.uom})` : '');
                return headCell.sortField ? (
                    <TableCell
                        key={headCell.id}
                        sortDirection={
                            queryState.sortField === headCell.sortField ? queryState.sortMode.toLowerCase() : false
                        }
                        data-testid={`plan-table-header-${headCell.id}`}
                        className={clsx({
                            [classes.stickyColumn]: pinnableColumns.includes(headCell.id),
                            [classes.stickyColumnPlanId]: headCell.id === pinnableColumns[0],
                            [classes.stickyColumnPlanStatus]:
                                headCell.id === pinnableColumns[2] || headCell.id === pinnableColumns[4],
                            [classes.stickyColumnTags]:
                                headCell.id === pinnableColumns[2] ||
                                (headCell.id === pinnableColumns[1] &&
                                    canAdjustcolumnForTags(featureFlags.showTagsCol)),
                            [classes.stickyColumnPlanType]:
                                headCell.id === pinnableColumns[2] && canAdjustcolumnForTags(featureFlags.showTagsCol),
                            [classes.stickyColumnPlanActions]: headCell.id === pinnableColumns[5],
                        })}
                    >
                        <TableSortLabel
                            active={queryState.sortField === headCell.sortField}
                            direction={
                                queryState.sortField === headCell.sortField ? queryState.sortMode.toLowerCase() : 'asc'
                            }
                            onClick={() => handleSortChange(headCell.sortField)}
                        >
                            <span className={classes.sortTableCell}>{headerLabel}</span>
                        </TableSortLabel>
                    </TableCell>
                ) : (
                    <TableCell
                        key={headCell.id}
                        className={clsx({
                            [classes.stickyColumn]: pinnableColumns.includes(headCell.id),
                            [classes.stickyColumnPlanId]: headCell.id === pinnableColumns[0],
                            [classes.stickyColumnPlanStatus]:
                                headCell.id === pinnableColumns[2] || headCell.id === pinnableColumns[4],
                            [classes.stickyColumnTags]:
                                headCell.id === pinnableColumns[2] ||
                                (headCell.id === pinnableColumns[1] &&
                                    canAdjustcolumnForTags(featureFlags.showTagsCol)),
                            [classes.stickyColumnPlanType]:
                                headCell.id === pinnableColumns[2] && canAdjustcolumnForTags(featureFlags.showTagsCol),
                            [classes.stickyColumnPlanActions]: headCell.id === pinnableColumns[5],
                        })}
                    >
                        {headerLabel}
                    </TableCell>
                );
            })}
        </TableRow>
    );

    return (
        <>
            {cancelTenderError
                ? createPortal(
                      <Alert
                          data-testid="cancelTenderFailureAlert"
                          variant="error"
                          onClose={() => {
                              setCancelTenderError('');
                          }}
                      >
                          {getErrorText(cancelTenderError, trans)}
                      </Alert>,
                      document.getElementById(ERROR_CONTAINER_ID),
                  )
                : null}
            {sPageError
                ? createPortal(
                      <Alert
                          data-testid="pageError"
                          variant="error"
                          onClose={() => {
                              setsPageError('');
                          }}
                      >
                          {getErrorText(sPageError, trans)}
                      </Alert>,
                      document.getElementById(ERROR_CONTAINER_ID),
                  )
                : null}
            {sSuccessMessage && (
                <Toast
                    text={trans(sSuccessMessage)}
                    variant="positive"
                    className={classes.stTripToast}
                    onClose={() => {
                        setsSuccessMessage('');
                    }}
                    delay={toastTimerUS}
                />
            )}
            {sIsSuccess && (
                <Toast
                    text={trans('msg.editTrailerSuccess')}
                    variant="positive"
                    onClose={() => {
                        setsIsSuccess(false);
                    }}
                    delay={toastTimerUS}
                    className={classes.stTripToast}
                />
            )}
            {sIsEditDriverSuccess && (
                <Toast
                    text={trans('msg.editDriverETDSuccess')}
                    variant="positive"
                    onClose={() => {
                        setsIsEditDriverSuccess(false);
                    }}
                    delay={toastTimerUS}
                    className={classes.stTripToast}
                />
            )}
            {sBulkSuccess && (
                <ToastAction
                    pVariant="positive"
                    pLinkText={trans('actions.label.History')}
                    pText={sBulkSuccess + trans('actions.label.printSuccesfully')}
                    pOnLinkClick={() => {
                        history.push({ pathname: '/bulkupload/history', state: { bulkUpdateHistory: true } });
                    }}
                    pToastTimer={toastTimerUS}
                />
            )}
            {sMarkServiceFailureError && (
                <Toast
                    text={trans('failure.comment.detail')}
                    variant="negative"
                    className={classes.stTripToast}
                    delay={toastTimerUS}
                />
            )}
            {sFetchPlanError
                ? createPortal(
                      <Alert
                          data-testid="invalidPlanPreviewAlert"
                          variant="error"
                          action={() => getPlans()}
                          actionText={trans('button.retry')}
                      >
                          {getPlanErrorText(sFetchPlanError, trans)}
                      </Alert>,
                      document.getElementById(ERROR_CONTAINER_ID),
                  )
                : null}
            <TableContainer className={classes.stTtContainer}>
                {TripSharedService.getFeatureFlags()?.showExceptionChips && !queryState.globalSearchData && (
                    <TableHeader className="">
                        <ExceptionFilterChips
                            pActiveTab={queryState.activeTabIndex}
                            pCurrentMarket={currentMarket}
                            pExceptionFilter={queryState.exceptionType}
                            pOnExceptionFilterChange={setExceptionType}
                            pEnableMustShip={featureFlags?.enableMustShipException}
                        />
                    </TableHeader>
                )}
                <TableHeader className={classes.headerContainer}>
                    <TableActionHeader show={pCheckedRows?.length && !pIsAssignTrip} className={classes.actionHeader}>
                        <TableHeaderLHS className={classes.lhsHeaderAction}>
                            <Typography>
                                <span className="d-flex align-items-center gap-1">
                                    <Badge count={pCheckedRows?.length} variant="neutral" />
                                    {selectedRowsText()}
                                </span>
                            </Typography>
                            <Button
                                data-testid="clearAll"
                                variant="text-only"
                                startIcon={<CloseIcon size="small" />}
                                onClick={onClearAll}
                            >
                                {trans('button.clear')}
                            </Button>
                        </TableHeaderLHS>
                        <TableHeaderRHS className={classes.tableHeaderRhs}>{actions()}</TableHeaderRHS>
                    </TableActionHeader>
                    <div className={classes.tableHeader}>
                        <TableHeaderLHS className={classes.lhsHeader}>
                            <div className={classes.lhsInnerRow}>
                                <div className={classes.lhsInner}>
                                    <TextInput
                                        id="search"
                                        key={`table-search-${pShowNavConfirmationModal}`}
                                        value={pTableSearch}
                                        label={trans('label.us.search')}
                                        onChange={(e) => handleTableSearch(e.target.value)}
                                        endIcon={<SearchIcon size="small" />}
                                        data-testid="search"
                                    />
                                </div>
                                <div className={classes.lhsInner}>
                                    <TableFilterChipsUS dispatch={dispatch} queryState={queryState} />
                                </div>
                            </div>
                        </TableHeaderLHS>
                        <TableHeaderRHS className="gap-4 mr-4">
                            <Typography>
                                {`${pTableSearch ? filteredRows.length : pSearchAPIResultsCount} ${trans(
                                    'planTable.results',
                                )}`}
                            </Typography>
                            {TripSharedService.getFeatureFlags()?.showPlanSearch && (
                                <div>
                                    <FilterIcon
                                        onClick={() => {
                                            pSetsIsSearchFilterModalOpen(true);
                                        }}
                                        size="small"
                                    />
                                </div>
                            )}
                            {TripSharedService.getFeatureFlags()?.showExport && (
                                <div className={classes.slLtDownloadWrapper} data-testid="plan-export">
                                    <PlanExport planData={paginatedData} columnsToExport={columnsToExport} />
                                </div>
                            )}
                            {tableActions.length > 0 ? (
                                <div className={classes.tableActionMenuContainer}>
                                    <ActionMenu
                                        pActions={tableActions}
                                        pOnActionItemClick={handleTableActionsMenuItemClick}
                                        pBtnLabel={
                                            <span data-testid="table-action-menu-trigger">
                                                <MoreIcon size="medium" />
                                            </span>
                                        }
                                        pBtnVariant="text-only"
                                    />
                                </div>
                            ) : null}
                        </TableHeaderRHS>
                    </div>
                </TableHeader>
                {featureFlags?.enableManageColumns ? (
                    <SearchResultsTableUS
                        key={`search-result-table-us-${queryState.activeTabIndex}`}
                        data={paginatedData}
                        showTableColumnManager={showTableColumnManager}
                        setShowTableColumnManager={setShowTableColumnManager}
                        mdmLocationTypes={mdmLocationTypes}
                        queryState={queryState}
                        checkedRows={pCheckedRows}
                        dispatch={dispatch}
                        tableSearchText={pTableSearch}
                        cmsConfig={pConfig}
                        setActionRow={setsActionRow}
                        onActionItemClick={handleActions}
                        onViewAllComments={onViewAllComments}
                        onTableColumnManagementLoadingStateChange={handleTableColumnManagementLoadingStateChange}
                    />
                ) : (
                    <TableWrapper className={classes.tableWrapper}>
                        <Table stickyHeader className={classes.table} data-testid="plan-table">
                            <TableHead>{header()}</TableHead>
                            <TableBody data-testid="plan-table-body">
                                {paginatedData.map((rowData) => (
                                    <PlanTableRowUS
                                        key={rowData.planId}
                                        pRowData={rowData}
                                        classes={classes}
                                        pCheckedRows={pCheckedRows}
                                        pSetActionRow={setsActionRow}
                                        pTabIndex={pTabIndex}
                                        pIsTripSelected={sIsTripSelected}
                                        pTripStatus={sProcessTripStatus}
                                        pIsAssignTrip={pIsAssignTrip}
                                        mdmLocationTypes={mdmLocationTypes}
                                        pActionTrigger={handleActions}
                                        pFeatureFlag={TripSharedService.getFeatureFlags()}
                                        pQueryState={queryState}
                                        dispatch={dispatch}
                                        pOnViewAllComments={onViewAllComments}
                                    />
                                ))}
                            </TableBody>
                        </Table>
                    </TableWrapper>
                )}
                <TableFooter
                    showPageCount
                    count={pTableSearch ? filteredRows.length : pSearchAPIResultsCount}
                    onNextPage={() => {
                        dispatch({
                            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.INCREMENT_CLIENT_PAGE_NUMBER,
                        });
                    }}
                    onPrevPage={() => {
                        dispatch({
                            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.DECREMENT_CLIENT_PAGE_NUMBER,
                        });
                    }}
                    page={pClientPageNumber}
                    rowsPerPage={parseInt(pConfig?.rowsPerPage, 10)}
                    labels={footerLabels}
                />
            </TableContainer>
            {sIsDrawerOpen && sCommentsDrawerInput && (
                <div className={classes.drawer}>
                    <DrawerComponent position="right" open={sIsDrawerOpen} data-testid="comments-sidebar-drawer">
                        <div className={classes.commentsDrawerContent}>
                            <LTMComments
                                pUserInfo={{ ...userInfo, displayName: getUserName() }}
                                pApiConfigs={commentsApiConfig}
                                pOnClose={onCommentsDrawerClose}
                                pIsEditEnabled={true}
                                {...sCommentsDrawerInput}
                            />
                        </div>
                    </DrawerComponent>
                </div>
            )}

            <>
                {sIsEditTrailerModalOpen && (
                    <EditTrailerModal
                        pOnClose={onEditTrailerModalClose}
                        pOnSuccess={handleEditTrailerSuccess}
                        pLoads={sLoadsToEditTrailer}
                        pActionSuccessCb={() => {
                            /* todo: When Success API call */
                        }}
                    />
                )}
                <UpdateStatusModal
                    pIsOpen={sIsUpdateStatusOpen}
                    pOnClose={onUpdateStatusModalClose}
                    pCheckedPlans={selectedRows}
                    pActionSuccessCb={() => {
                        dispatch({
                            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                            checkedRows: [],
                        });
                    }}
                    orderStatusReasonCodes={pStaticData?.orderStatusReasonCodes || []}
                />

                <UpdateTimelineModal
                    pOpenModal={sShowUpdateTimelineModal}
                    pOnCloseModal={() => setsShowUpdateTimelineModal(false)}
                    pPlanId={selectedRows[0]}
                    pStaticData={pStaticData}
                    dispatch={dispatch}
                    pIsTripSelected={sIsTripSelected}
                />
                {sShowUpdateTimelineV2Modal && (
                    <UpdateTimelineV2
                        pOnClose={() => setsShowUpdateTimelineV2Modal(false)}
                        pStaticData={pStaticData}
                        pPlanId={selectedRows[0]}
                        pConfig={featureConfig(featureFlags, pConfig)}
                        pFeatureFlags={featureFlags}
                        pUOM={pConfig?.UOM}
                        pAppContext={AppUtils.get}
                        pCurrentLang={prefLang.current}
                        pTripDetailsApiParams={tripDetailsApiParams}
                        pLosStaticDataApiParams={losApiParams(featureFlags)}
                        pDeliveryWindowApiParams={deliveryWindowApiParams}
                        pEditTrailerIdsApiParams={trailerIdEditApiParams}
                        pUpdateTimelineApiParams={timelineEditApiParams}
                        pOnSuccess={onUpdateTimelineSuccess}
                    />
                )}
                {sShowPrintTripSheet && (
                    <PrintTripSheet
                        pTripId={selectedRows[0]}
                        pTripDetailsApiParams={tripDetailsApiParams}
                        pLocationsFetchApiParams={locationDetailsApiParams}
                        pDmasPrintTripSheetApiParams={printTripSheetApiParams}
                        pStaticData={pStaticData}
                        pOnSuccess={handlePrintTripSheetSuccess}
                        pOnError={handlePrintTripSheetError}
                        pAppContext={AppUtils.get}
                    />
                )}
                {sBulkHazmatSuccess && (
                    <ToastAction
                        pVariant="positive"
                        pLinkText={trans('actions.label.History')}
                        pText={sBulkHazmatSuccess + trans('actions.label.hazmatSuccesfully')}
                        pOnLinkClick={() => {
                            history.push({ pathname: '/bulkupload/history', state: { bulkUpdateHistory: true } });
                        }}
                        pToastTimer={toastTimerUS}
                        pOnClose={() => {
                            setsBulkHazmatSuccess('');
                        }}
                    />
                )}
                <ReviewAndApprove
                    pIsOpen={sShowReviewAndApproveDrawer}
                    pOnClose={handleReviewAndApproveClose}
                    pActionRow={actionableRow}
                    pListLocationTypes={pStaticData?.locationTypes || []}
                    pPlanIds={selectedRows}
                    pEnableSplitLoad={TripSharedService.getFeatureFlags()?.enableSplitLoad}
                    pShowLocationDescription={TripSharedService.getFeatureFlags()?.showLocationDescription}
                    pIsODPairSame={
                        TripSharedService.getFeatureFlags()?.enableMultipleLocationsRA
                            ? true
                            : checkPlanODSame(sCheckedPlans)
                    }
                    pIsMultipleOrigins={
                        TripSharedService.getFeatureFlags()?.enableMultipleLocationsRA &&
                        checkPlanOriginSame(sCheckedPlans)
                    }
                    pIsMultipleDestinations={
                        TripSharedService.getFeatureFlags()?.enableMultipleLocationsRA &&
                        checkPlanDestinationSame(sCheckedPlans)
                    }
                />

                <AutoTender
                    pIsOpen={sShowAutoTenderDrawer}
                    pOnClose={handleAutoTenderClose}
                    pActionRow={actionableRow}
                    pListLocationTypes={pStaticData?.locationTypes || []}
                    pPlanIds={selectedRows}
                    pShowSplitLoad={TripSharedService.getFeatureFlags()?.enableSplitLoad}
                    pIsODPairSame={checkPlanODSame(sCheckedPlans)}
                />

                <CancelPlan
                    pIsOpen={sIsCancelModalOpen}
                    pSetsIsCancelModalOpen={setsIsCancelModalOpen}
                    pReasonCodes={pStaticData?.reasonCodes || []}
                    pCheckedPlans={selectedRows}
                    pSelectedRowDataMap={selectedRowDataMap}
                    pActionSuccessCb={() => {
                        dispatch({
                            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                            checkedRows: [],
                        });
                    }}
                    pOnCancelPlanSuccess={showSuccessToast}
                    pIsAllTrips={sIsAllTrips}
                    pIsAllLoads={sIsAllLoads}
                />
                {sError && (
                    <Toast
                        className={classes.toast}
                        delay={toastTimerUS}
                        text={getErrorText(sError, trans)}
                        variant="negative"
                    />
                )}
                {sIsRegenerateBOLConfirmationModal && (
                    // Regenerate BOL model
                    <RegenerateBOLConfirmModal
                        pOnCloseModal={() => setsIsRegenerateBOLConfirmationModal(false)}
                        pUseAppContext={AppUtils.get}
                        pOnConfirmation={onSaveSuccess}
                        pOnError={onErrorResponse}
                        pApiConfig={APIParams}
                        pPlanId={actionableRow?.planId}
                        pLocationData={{
                            locationType: actionableRow?.destinationType,
                            locationId: actionableRow?.destinationId,
                        }}
                        pCarrierData={pStaticData?.carrierCodes?.find(
                            (carrierCode) => carrierCode?.carrier_id === actionableRow?.carrierId,
                        )}
                    />
                )}
                {sShowRLogModal && (
                    <ReverseLogisticsModal
                        pLocationTypes={pStaticData?.locationTypes || []}
                        pLoadTypes={pStaticData?.loadTypes || []}
                        pSetsIsModalOpen={setsShowRLogModal}
                        pCheckedPlans={selectedRows}
                        pMapApiKey={pConfig?.mapApiKey}
                        pActionSuccessCb={actionSuccessCb}
                        pOnRLOGSuccess={pOnRLOGSuccess}
                    />
                )}
                {sIsMarkServiceFailureModalOpen && (
                    <ServiceFailureModal
                        pIsServiceFailureModalOpen={sIsMarkServiceFailureModalOpen}
                        pServiceFailureOptions={pStaticData?.serviceFailureList}
                        pLabels={{
                            loadIdText: trans('label.selectedLoadID'),
                            serviceFailureText: trans('label.serviceFailure'),
                            commentText: trans('title.comments'),
                            updateButton: trans('button.update'),
                            cancelButton: trans('button.cancel'),
                        }}
                        pPlanId={selectedRows.length ? selectedRows.join() : ''}
                        pFailureDetails={trans('failure.comment.detail')}
                        pCallbacks={{
                            onUpdate: handleMarkServiceFailureConfirm,
                            onCancel: onMarkServiceFailureClose,
                        }}
                    />
                )}
                {sShowStopSequenceAuditModal && (
                    <StopSequenceAuditModal
                        pIsOpen={sShowStopSequenceAuditModal}
                        pUseAppContext={AppUtils.get}
                        pApiParams={stopSequeceAuditParams?.apiParams}
                        pOnClose={() => {
                            setsShowStopSequenceAuditModal(false);
                        }}
                        pTrans={trans}
                        pStaticData={{
                            shortTimezones: pStaticData?.shortTimezones,
                        }}
                        pPlanType={stopSequeceAuditParams?.planType}
                        pTripDetailsMapperProps={{
                            featureFlags: featureFlags,
                        }}
                        pDateTimeFormat={
                            featureFlags?.enableStandardDateTimeFormat
                                ? {
                                      dateF: TripSharedService.getStandardDateTimeFormat()?.date,
                                      timeF: TripSharedService.getStandardDateTimeFormat()?.time,
                                  }
                                : {}
                        }
                    />
                )}
                {sOpenEditDriverETD && (
                    <EditDriverDetails
                        pOnClose={() => {
                            setsOpenEditDriverETD(false);
                        }}
                        pOnSuccess={(d) => {
                            onEditDriverETDSuccess(d);
                        }}
                        pApiConfig={editDriverETDAPIParams}
                        pUseAppContext={AppUtils.get}
                        pDriverId={getDriverId()}
                    />
                )}
            </>
        </>
    );
}
PlanTableUS.propTypes = {
    pTabIndex: number.isRequired,
    pConfig: PropTypes.shape({
        rowsPerPage: number.isRequired,
        debounceTime: number.isRequired,
        mapApiKey: string.isRequired,
        country: PropTypes.shape({
            currency: PropTypes.arrayOf(string).isRequired,
        }).isRequired,
        UOM: PropTypes.object.isRequired,
    }).isRequired,
    pOnPlanApprove: PropTypes.func,
    pOnLoadMarkAsDelivered: PropTypes.func,
    pOnTripSheetGenerate: PropTypes.func,
    pIsAssignTrip: bool,
    pOnTripSelection: PropTypes.func,
    pSearchCriteria: PropTypes.shape({
        payload: PropTypes.shape({}),
    }),
    pIsLoading: bool,
    mdmLocationTypes: PropTypes.oneOfType([PropTypes.object]),
    pPhaseCounts: PropTypes.func,
    queryState: QueryStateType.isRequired,
    dispatch: PropTypes.func.isRequired,
    pStaticData: PropTypes.shape({
        reasonCodes: PropTypes.arrayOf(PropTypes.shape({})),
        locationTypes: PropTypes.arrayOf(PropTypes.shape({})),
        loadTypes: PropTypes.arrayOf(PropTypes.shape({})),
        orderStatusReasonCodes: PropTypes.arrayOf(PropTypes.shape({})),
        serviceFailureList: PropTypes.arrayOf(PropTypes.shape({})),
        carrierCodes: PropTypes.arrayOf(PropTypes.shape({})),
    }).isRequired,
    pSetsIsSearchFilterModalOpen: PropTypes.func,
    pOnRLOGSuccess: PropTypes.func.isRequired,
    pSearchAPIResultsCount: PropTypes.number,
    pIsGlobalSearchFlow: PropTypes.func.isRequired,
    pCheckedRows: PropTypes.arrayOf(string).isRequired,
    pClientPageNumber: PropTypes.number.isRequired,
    pTableSearch: PropTypes.string,
    pShowNavConfirmationModal: PropTypes.bool,
    pUserPerm: PropTypes.shape({
        canAccessNonDrayLoads: PropTypes.bool.isRequired,
    }).isRequired,
};
PlanTableUS.defaultProps = {
    pOnPlanApprove: () => {},
    pOnLoadMarkAsDelivered: () => {},
    pOnTripSheetGenerate: () => {},
    pIsAssignTrip: false,
    pOnTripSelection: () => {},
    pSearchCriteria: undefined,
    pIsLoading: false,
    mdmLocationTypes: {},
    pPhaseCounts: () => {},
    pSetsIsSearchFilterModalOpen: () => {},
    pSearchAPIResultsCount: 0,
    pTableSearch: '',
    pShowNavConfirmationModal: false,
};
