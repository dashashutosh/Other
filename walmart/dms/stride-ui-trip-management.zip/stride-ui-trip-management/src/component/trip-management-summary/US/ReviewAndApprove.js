import React, { useMemo, useState } from 'react';
import PropTypes, { string } from 'prop-types';
import { ReviewAndApproveDrawer, ToastAction } from '@walmart/stride-ui-commons';
import { useHistory } from 'react-router-dom';
import { getAPIParams, getAutoEntityAPIParams } from '../../../service/TripAPI';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;

const ReviewAndApprove = (props) => {
    const {
        pOnClose,
        pActionRow,
        pListLocationTypes,
        pPlanIds,
        pIsOpen,
        pEnableSplitLoad,
        pIsODPairSame,
        pShowLocationDescription,
        pIsMultipleOrigins,
        pIsMultipleDestinations,
    } = props;
    const history = useHistory();
    const { prefLang, currentMarket, userInfo } = AppUtils.get();
    const trans = localizeLang();
    const [sBulkSuccessMessage, setsBulkSuccessMessage] = useState('');
    const APIParamsAutoComplete = getAutoEntityAPIParams(currentMarket, prefLang.current, userInfo);
    const APIParams = getAPIParams(currentMarket, prefLang.current, userInfo);
    const labels = useMemo(
        () => ({
            drawerTitle: trans('review.and.approve.drawer.title'),
            drawerInfo: trans('review.and.approve.drawer.info'),
            buttonSave: trans('load.action.review.and.approve'),
            buttonCancel: trans('button.cancel'),
            originLocations: trans('label.origin.locations'),
            plannedPickupdate: trans('label.planned.pickup.date'),
            locationType: trans('label.location.type'),
            locationId: trans('label.location.id'),
            finalDestination: trans('label.final.destination'),
            splitLoad: trans('label.split.load'),
            singleSuccessMessage: trans('review.approve.single.success.message'),
            bulkSuccessMessage: trans('review.approve.bulk.success.message'),
            bulkUploadLinkText: trans('label.bulk.history'),
            errorMessage: trans('review.approve.error.message'),
            multiple: trans('label.location.multiple'),
            retry: trans('button.retry'),
            invalidResponse: trans('API.error.invalid'),
        }),
        [prefLang.current],
    );
    const onBulkSuccess = () => {
        setsBulkSuccessMessage(`${pPlanIds?.length} ${labels.bulkSuccessMessage}`);
        pOnClose();
    };
    return (
        <>
            {pIsOpen && (
                <ReviewAndApproveDrawer
                    pLabels={labels}
                    pOnClose={pOnClose}
                    pOnBulkSuccess={onBulkSuccess}
                    pOriginLocation={{
                        value: `${pActionRow?.originType} - ${pActionRow?.originId}`,
                        id: `${pActionRow?.originType}-${pActionRow?.originId}` || '',
                        locationType: pActionRow?.originType || '',
                        locationId: pActionRow?.originId || '',
                    }}
                    pFinalDestination={{
                        value: `${pActionRow?.destinationType} - ${pActionRow?.destinationId}`,
                        id: `${pActionRow?.destinationType}-${pActionRow?.destinationId}` || '',
                        locationType: pActionRow?.destinationType || '',
                        locationId: pActionRow?.destinationId || '',
                    }}
                    pListLocationTypes={pListLocationTypes}
                    pApiConfig={APIParams}
                    pAutoCompleteConfig={APIParamsAutoComplete}
                    pUseAppContext={AppUtils.get}
                    pPlanIds={pPlanIds}
                    pPickupDates={{
                        originPickupDate: pActionRow?.plannedStartTime,
                    }}
                    pShowSplitLoad={pEnableSplitLoad}
                    pShowLocationDescription={pShowLocationDescription}
                    pIsMultiple={!pIsODPairSame && pPlanIds?.length > 1}
                    pIsMultipleOrigins={pIsMultipleOrigins}
                    pIsMultipleDestinations={pIsMultipleDestinations}
                    pProcessBulk
                />
            )}

            {sBulkSuccessMessage && (
                <ToastAction
                    pVariant="positive"
                    pLinkText={labels.bulkUploadLinkText}
                    pText={sBulkSuccessMessage}
                    pOnLinkClick={() => {
                        history.push({ pathname: '/mfe/bulkupload/history', state: { bulkUpdateHistory: true } });
                    }}
                    pToastTimer={5000}
                    pOnClose={() => {
                        setsBulkSuccessMessage('');
                    }}
                />
            )}
        </>
    );
};
const propTypes = {
    pOnClose: PropTypes.func.isRequired,
    pActionRow: PropTypes.shape({
        originType: PropTypes.string,
        originId: PropTypes.string,
        destinationType: PropTypes.string,
        destinationId: PropTypes.string,
        planId: PropTypes.string,
        plannedStartTime: PropTypes.string,
    }).isRequired,
    pListLocationTypes: PropTypes.arrayOf(string).isRequired,
    pPlanIds: PropTypes.arrayOf(string).isRequired,
    pIsOpen: PropTypes.bool.isRequired,
    pEnableSplitLoad: PropTypes.bool,
    pIsODPairSame: PropTypes.bool,
    pIsMultipleDestinations: PropTypes.bool,
    pIsMultipleOrigins: PropTypes.bool,
    pShowLocationDescription: PropTypes.bool,
};
ReviewAndApprove.propTypes = propTypes;
ReviewAndApprove.defaultProps = {
    pEnableSplitLoad: false,
    pIsODPairSame: false,
    pShowLocationDescription: false,
    pIsMultipleOrigins: false,
    pIsMultipleDestinations: false,
};
export default ReviewAndApprove;
