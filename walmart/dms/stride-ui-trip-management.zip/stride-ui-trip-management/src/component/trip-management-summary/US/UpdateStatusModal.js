import React, { useMemo, useState, useCallback, useEffect } from 'react';
import PropTypes, { string } from 'prop-types';
import { UpdateStatus, ToastAction } from '@walmart/stride-ui-commons';
import { Toast } from '@walmart/living-design-sc-ui';
import { useHistory } from 'react-router-dom';
import { getAPIParams } from '../../../service/TripAPI';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { AppUtils } from '@gscope-mfe/app-bridge';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const useStyles = makeStyles({
    toast: {
        '&.ld-sc-ui-toast--snack-bar': {
            position: 'absolute',
            bottom: '1rem',
            right: '1rem',
        },
    },
});
const UpdateStatusModal = ({ pIsOpen, pOnClose, pActionSuccessCb, orderStatusReasonCodes, pCheckedPlans }) => {
    const classes = useStyles();
    const history = useHistory();
    const trans = localizeLang();
    const { prefLang, currentMarket, userInfo } = AppUtils.get();
    const [sBulkSuccess, setsBulkSuccess] = useState(false);
    const [sError, setsError] = useState(false);
    const APIParams = getAPIParams(currentMarket, prefLang.current, userInfo);
    const reasonCodePickerModalTranslations = useMemo(
        () => ({
            selectReason: trans('actions.label.selectReasonCodeForUpdateStatus'),
            enterComment: trans('actions.label.additionalComments'),
            cancelBtn: trans('action.cancel'),
            primaryActionBtn: trans('action.label.updateStatusPrimaryActionButton'),
            orderStatusReasonCodes: trans('action.label.updateStatusorderStatusReason'),
            modalTitle: trans('action.label.updateStatusModalTitle'),
            notReady: trans('plan.core.status.not.ready'),
            pendingApproval: trans('plan.status.pending.approval'),
        }),
        [trans],
    );
    useEffect(() => {
        if (pIsOpen) {
            setsBulkSuccess(false);
        }
    }, [pIsOpen]);
    const handleCloseModal = useCallback(() => pOnClose(false), []);
    const onBulkSuccess = () => {
        setsBulkSuccess(true);
        pActionSuccessCb();
    };
    return (
        <>
            {pIsOpen && (
                <UpdateStatus
                    pOpen={pIsOpen}
                    orderStatusReasonCodes={orderStatusReasonCodes}
                    pOnCancel={handleCloseModal}
                    pApiConfig={APIParams}
                    pUseAppContext={AppUtils.get}
                    pOnBulkSuccess={onBulkSuccess}
                    pPlanIds={pCheckedPlans}
                    pTranslations={reasonCodePickerModalTranslations}
                    pOnError={() => setsError(true)}
                />
            )}
            {sError && (
                <Toast
                    className={classes.toast}
                    delay={5000}
                    text={trans('actions.label.UpdateFailed')}
                    variant="negative"
                />
            )}

            {sBulkSuccess && (
                <ToastAction
                    pVariant="positive"
                    pLinkText={trans('actions.label.History')}
                    pText={trans('actions.label.PlanUpdatedSuccesfully')}
                    pOnLinkClick={() => {
                        history.push({
                            pathname: '/mfe/bulkupload/history',
                            state: {
                                bulkUpdateHistory: true,
                            },
                        });
                    }}
                    pToastTimer={5000}
                />
            )}
        </>
    );
};
const propTypes = {
    orderStatusReasonCodes: PropTypes.arrayOf(PropTypes.shape({})),
    pIsOpen: PropTypes.bool.isRequired,
    pOnClose: PropTypes.func.isRequired,
    pCheckedPlans: PropTypes.arrayOf(string).isRequired,
    pActionSuccessCb: PropTypes.func.isRequired,
};
UpdateStatusModal.propTypes = propTypes;
UpdateStatusModal.defaultProps = {
    orderStatusReasonCodes: [],
};
export default UpdateStatusModal;
