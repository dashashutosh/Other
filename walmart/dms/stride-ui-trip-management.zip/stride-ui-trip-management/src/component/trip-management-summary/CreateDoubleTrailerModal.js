import React, { useState, useEffect, useMemo } from 'react';
import PropTypes, { string, bool } from 'prop-types';
import { CreateDoubleTrailer } from '@walmart/stride-ui-commons';

import { getDoubleTrailerLabels, formatDoubleTrailerStopSequence, getDoubleTrailerType } from './DataModels';

import { AppUtils } from '@gscope-mfe/app-bridge';
import TripSharedService from '../../service/TripSharedService';

const CreateDoubleTrailerModal = (props) => {
    const { pIsOpen, pOnClose, pStaticData, pPaginatedData, pCheckedRows, pOnCreate } = props;

    const filteredPlans = useMemo(
        () => pPaginatedData?.filter((plan) => pCheckedRows?.includes(plan?.planId?.toString())),
        [pCheckedRows],
    );
    const featureFlags = TripSharedService.getFeatureFlags();

    const { prefLang } = AppUtils.get();
    const [sStopSequence, setsStopSequence] = useState([]);
    const [sEquipmentTypeList, setsEquipmentTypeList] = useState([]);

    const labels = useMemo(() => getDoubleTrailerLabels(), [prefLang.current]);

    useEffect(() => {
        if (filteredPlans?.length !== 0) {
            setsStopSequence(formatDoubleTrailerStopSequence(filteredPlans));
            setsEquipmentTypeList(getDoubleTrailerType(pStaticData, featureFlags));
        }
    }, []);
    return (
        sStopSequence?.length > 0 &&
        sEquipmentTypeList?.length > 0 && (
            <CreateDoubleTrailer
                pIsOpen={pIsOpen}
                pOnClose={pOnClose}
                pOnCreate={pOnCreate}
                pStopSequence={sStopSequence}
                pTripList={pCheckedRows}
                pEquipmentTypeList={sEquipmentTypeList}
                pLabels={labels}
            />
        )
    );
};

CreateDoubleTrailerModal.propTypes = {
    pIsOpen: bool.isRequired,
    pOnClose: PropTypes.func.isRequired,
    pStaticData: PropTypes.shape({}),
    pPaginatedData: PropTypes.arrayOf(PropTypes.shape({})),
    pCheckedRows: PropTypes.arrayOf(string),
    pOnCreate: PropTypes.func.isRequired,
};

CreateDoubleTrailerModal.defaultProps = {
    pStaticData: {},
    pPaginatedData: [],
    pCheckedRows: [],
};

export default CreateDoubleTrailerModal;
