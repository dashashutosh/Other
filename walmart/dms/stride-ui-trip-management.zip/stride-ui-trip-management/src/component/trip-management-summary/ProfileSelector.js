import React, { useState, useEffect } from 'react';
import { ProfileSelection, FetchUserDetails } from '@walmart/stride-ui-commons';
import { useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../utils/actions/PlanTableQueryActions';
import { STRIDE_UI_TM_PROFILE_LINK_MFE, STRIDE_UI_TM_PROFILE_LINK_NON_MFE, companyName } from '../../Constants';
import TripSharedService from '../../service/TripSharedService';
import axios from '../../axios';
import { AppUtils, Utilities } from '@gscope-mfe/app-bridge';
const { setUserPreference } = Utilities;
const USER_PREF_PAGE_NAME = 'strideTripManagementProfile';
const USER_PREF_FAV_BG_KEY = 'tripManagementProfileSelected';
const propTypes = {
    pFeatureFlag: PropTypes.shape({
        hasTMPMigratedToMFE: PropTypes.bool,
    }),
    queryState: PropTypes.string.isRequired,
    dispatch: PropTypes.func.isRequired,
    pPageStaticData: PropTypes.string.isRequired,
};

/**
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
const ProfileSelector = ({ pFeatureFlag, queryState, dispatch, pPageStaticData }) => {
    const history = useHistory();
    const { currentMarket, prefLang, setloading, userInfo } = AppUtils.get();
    const [sProfileData, setsProfileData] = useState(() => []);
    // eslint-disable-next-line no-unused-vars
    const [sUserProfileError, setsUserProfileError] = useState('');
    const onClickManageProfile = () => {
        history.push({
            pathname: pFeatureFlag?.hasTMPMigratedToMFE
                ? STRIDE_UI_TM_PROFILE_LINK_MFE
                : STRIDE_UI_TM_PROFILE_LINK_NON_MFE,
        });
    };
    const getUserProfile = () => {
        FetchUserDetails(false, null, null, companyName, currentMarket?.toUpperCase(), axios, prefLang.current)
            .then((res) => {
                if (res?.tripManagementProfile) {
                    if (res.isUpdateRequired) {
                        setsProfileData(res.tripManagementProfile);
                    }
                } else {
                    setsProfileData([
                        {
                            id: 'default',
                            key: 'default',
                            name: 'Default-LTM',
                            preferences: [],
                        },
                    ]);
                    setsUserProfileError(res);
                }
                setloading(false);
            })
            .catch(() => {
                setloading(false);
            });
    };
    const setUserPref = async (pref) => {
        const payload = {
            pageName: USER_PREF_PAGE_NAME,
            key: USER_PREF_FAV_BG_KEY,
            value: pref,
        };
        await setUserPreference(payload);
    };
    const onSelectProfile = (profile) => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE,
            profile,
        });
        setUserPref(profile);
    };
    useEffect(() => {
        if (prefLang.current) {
            if (pPageStaticData) {
                // If user comes directly comes to here
                if (TripSharedService.getFeatureFlags()?.showProfile) {
                    const userPref = JSON.parse(
                        localStorage.getItem(`ngStorage-preferences_${userInfo.loggedInUserName}`),
                    );
                    if (userPref && userPref.strideTripManagementProfile) {
                        // If user have stride profile
                        // eslint-disable-next-line max-len
                        const tripManagementProfile = [
                            {
                                id: 'default',
                                key: 'default',
                                name: 'Default-LTM',
                                preferences: [],
                            },
                            ...(userPref?.strideTripManagementProfile?.tripManagementProfile || []),
                        ];
                        // eslint-disable-next-line max-len
                        const profileSelected = userPref?.strideTripManagementProfile?.tripManagementProfileSelected;
                        setsProfileData(tripManagementProfile);
                        if (tripManagementProfile.some((val) => val.key === profileSelected?.key)) {
                            dispatch({
                                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE,
                                profile: profileSelected,
                            });
                        } else if (tripManagementProfile?.[0]) {
                            dispatch({
                                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE,
                                profile: {
                                    ...tripManagementProfile[0],
                                },
                            });
                        }
                    } else {
                        // If user dont have stride profile
                        getUserProfile();
                    }
                }
            }
        }
    }, [pPageStaticData, prefLang.current]);
    return (
        <ProfileSelection
            profileDetails={sProfileData}
            selected={queryState.profile}
            onSelected={onSelectProfile}
            pManagenav={onClickManageProfile}
        />
    );
};
ProfileSelector.propTypes = propTypes;
export default ProfileSelector;
