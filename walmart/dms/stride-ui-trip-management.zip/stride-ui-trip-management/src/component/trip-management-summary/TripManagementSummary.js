import React, { useState, useEffect, useMemo, useRef, useCallback, useReducer } from 'react';
import clsx from 'clsx';
import {
    PageHeader,
    TabCard,
    useAPI,
    LoadActionsEnum,
    TripActionsEnum,
    isNullOrUndefined,
    usePageStateStore,
    WithPermissionHOC,
    getFeatureFlagsConfig,
    MarketCodeEnum,
    ErrorBoundary,
    ConfirmationModal,
    WithRLInfo,
    getUserName,
    LTMCommentsV2,
    useAPIClient,
} from '@walmart/stride-ui-commons';
import { Alert, Toast, ToastProvider, UploadIcon, DrawerComponent } from '@walmart/living-design-sc-ui';
import FileSaver from 'file-saver';
import moment from 'moment-timezone';
import { useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';
import {
    toastTimer,
    getPageStaticDataRequest,
    ERROR_CONTAINER_ID,
    autoTenderPBLabels,
    dispatchPBLabels,
    deliveredPBLabels,
    downloadPBLabels,
    phasesForAggsEnum,
    BASE_URL,
    camMarkets,
    autoCarrierPBLabels,
    COMMENT_VALIDATION,
    withdrawTenderPBLabels,
} from '../../Constants';
import PlanTable from './PlanTableNew';
import { PageLoadAPI, TripAPI, DownloadDispatchDocAndLabelAPI, getCancelLoadParams } from '../../service/TripAPI';
import TripSharedService from '../../service/TripSharedService';
import { transformCmsData, transformMdmLocationTypes, transformStaticData } from '../../service/TripMapper';
import {
    tableStateReducer,
    getInitialTableState,
    PLAN_TABLE_QUERY_ACTIONS_ENUM,
} from '../../utils/actions/PlanTableQueryActions';
import {
    transformApproveTripRequest,
    transformDispatchTripRequest,
    transformDeliveredTripRequest,
    transformTenderRequest,
    getBulkUploadConfig,
    getPlanLabel,
    getFormattedChargeLocError,
    getCarrierAssignRequest,
} from './DataModels';
import { readPermissions, permMarkets } from './Constants';
import { stTripToast } from '../../utils/StyleUtils';
import {
    convertDocObjectBaseToBlob,
    getCommentsConfigurations,
    getCommentsDrawerPropsV2,
    getFormattedTripError,
    getSecondaryTextForTabs,
    InitialSecondayTextForTabs,
    formatCancelTripActionRequest,
    formatErrorListFromResponse,
} from '../../utils/CommonUtils';
import { canEditTrip, canAccessNonDrayLoads, canBulkUploadTender } from '../../utils/PermissionsUtils';
import { getPhaseTabsForCurrentMarket } from '../../utils/ui-mappers/PlanSearchMappers';
import PhaseTypesEnum from '../../utils/enums/PhaseTypesEnum';
import ProgressBarModal from './ProgressBarModal';
import planningIcon from '../../../assets/tab-icon-planning.png';
import processingIcon from '../../../assets/tab-icon-processing.png';
import rToSIcon from '../../../assets/tab-icon-ready-to-start.png';
import intransitIcon from '../../../assets/tab-icon-intransit.png';
import deliveredIcon from '../../../assets/tab-icon-delivered.png';
import PlanSearch from './PlanSearch';
import PlanSearchUS from './US/PlanSearchUS';
import ProfileSelector from './ProfileSelector';
import ForceLoadToDeliveredModal from './ForceLoadToDeliveredModal';
import ForceLoadToDeliveredModalUS from './US/ForceLoadToDeliveredModalUS';
import PermAccessFallBack from '../PermAccessFallBack';
import PlanTableUS from './US/PlanTableUS';
import usePlanActionsApiUS from '../../hooks/usePlanActionsApiUS';
import NoResults from './US/NoResults';
import GlobalSearch from './US/GlobalSearch';
import { defaultMarketSettings, getMarketSettings } from '../../utils/MarketSettings';
import useLoadSupportedLangs from '../../hooks/useLoadSupportedLangs';
import GroupByFilter from './US/GroupByFilter';
import ProfileSelectorV2 from './US/ProfileSelectorV2';
import TimeHorizonV2 from './US/TimeHorizonV2';
import axios from '../../axios';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { AppUtils, Services } from '@gscope-mfe/app-bridge';
import {
    LocalizeLang,
    LanguageSelector as _LanguageSelector,
    BulkUpload as _BulkUpload,
    MarketSelector as _MarketSelector,
} from '@gscope-mfe/common-components';
import { getCommentsAPIConfigs } from '../../service/LTMCommentsAPIConfigs';
import { getCancelLoadAPIParams } from '../../utils/CancelLoadServiceModel';
import { SequenceRequestService } from '../../utils/SequentialRequestService';

const { makeStyles, Tooltip, IconButton } = MaterialUiCore,
    { localizeCommonLang, localizeLang, loadI18n } = LocalizeLang.default,
    LanguageSelector = _LanguageSelector.default,
    BulkUpload = _BulkUpload.default,
    MarketSelector = _MarketSelector.default,
    { bulkUploadHistory } = Services;

const styles = makeStyles({
    stTripToast,
    pageContainer: {
        display: 'flex',
        flexDirection: 'column',
        maxHeight: '100vh',
        '& .ld-sc-ui-alert': {
            marginTop: '-15px',
        },
    },
    pageHeader: {
        flexShrink: 0,
    },
    planTableContainer: {
        flexGrow: 1,
        display: 'flex',
        maxWidth: '96%',
        minHeight: 0, // https://stackoverflow.com/questions/36247140/why-dont-flex-items-shrink-past-content-size
    },

    actionDisabled: {
        pointerEvents: 'none',
        opacity: '0.4',
    },
    errorAlert: {
        '& .ld-sc-ui-alert': {
            marginTop: '-16px',
            width: 'calc(100% - 1.5em)',
        },
    },
    commentsDrawerContent: {
        height: '100vh',
        width: '480px',
        overflow: 'hidden',
        '& div[class^="makeStyles-buttonWrapper-"]': {
            width: 'auto !important',
        },
        zIndex: '999',
        '& span[class^="makeStyles-commentText-"]': {
            textAlign: 'left !important',
        },
    },
    errorAlertMessage: {
        position: 'absolute',
        bottom: '1rem',
        right: '1rem',
        zIndex: '10',
        '& .ld-sc-ui-alert': {
            minWidth: 'calc(100% - 1em)',
            display: 'flex',
            alignItems: 'center',
            borderRadius: '8px',
        },
    },
});
let selectedRowIds = [];

function TripManagementSummary({ errors: pErrors }) {
    // eslint-disable-next-line no-unused-vars
    const history = useHistory();
    const commonTrans = localizeCommonLang();
    const classes = styles();
    const { prefLang, setBreadCrumbArr, currentMarket, userInfo, setBulkUploadConfig } = AppUtils.get();
    const trans = localizeLang();
    const { pageState, setPageState } = usePageStateStore('trip-management-search');
    const [tableState, dispatch] = useReducer(
        tableStateReducer,
        getInitialTableState(pageState?.search, currentMarket),
    );
    const [sIsDataInvalid, setsIsDataInvalid] = useState(false);
    const [sCmsConfig, setsCmsConfig] = useState();
    const [sError, setsError] = useState('');
    const [sIsApproveTripSuccess, setsIsApproveTripSuccess] = useState(false);
    const [sIsDispatchTripSuccess, setsIsDispatchTripSuccess] = useState(false);
    const [sIsDeliveredTripSuccess, setsIsDeliveredTripSuccess] = useState(false);
    const [sIsCreateTripSuccess, setsIsCreateTripSuccess] = useState(false);
    const [sPageStaticData, setsPageStaticData] = useState();
    const [sIsAutoTenderSuccess, setsIsAutoTenderSuccess] = useState(false);
    const [sIsAutoCarrierSuccess, setIsAutoCarrierSuccess] = useState(false);
    const [sPerm, setsPerm] = useState({});
    const [mdmLocationTypes, setMdmLocationTypes] = useState([]);
    const [sProgressValue, setsProgressValue] = useState(0);
    const [sSelectedPlans, setsSelectedPlans] = useState([]);
    const [sSeqErrorList, setsSeqErrorList] = useState([]);
    // eslint-disable-next-line no-unused-vars
    const [sUserProfileError, setsUserProfileError] = useState('');
    const [sPBLabels, setsPBLabels] = useState();
    const [sPlanQueryTabs, setSPlanQueryTabs] = useState([]);
    const [sIsSearchFilterModalOpen, setsIsSearchFilterModalOpen] = useState(false);
    // const [sCarrierList, setsCarrierList] = useState([]);
    const [sShowForceToDeliveredModal, setsShowForceToDeliveredModal] = useState(false);
    const [sSelectedPlanId, setsSelectedPlanId] = useState([]);
    const [sResponseLoading, setsResponseLoading] = useState(false);
    const [sTabsSecondaryTitle, setsTabsSecondaryTitle] = useState(InitialSecondayTextForTabs);
    const [sIsGenerateSuccess, setsIsGenerateSuccess] = useState(false);
    const [sIsPlanStatusToDeliveredSuccess, setIsPlanStatusToDeliveredSuccess] = useState(false);
    const [sIsRLOGSuccess, setsIsRLOGSuccess] = useState(false);
    const [sIsApprovePlanUSSuccess, setsIsApprovePlanUSSuccess] = useState(false);
    const [sCardData, setsCardData] = useState({});
    const [sPhaseTotalCounts, setsPhaseTotalCounts] = useState({});
    const [sEsbTableRowCount, setsEsbTableRowCount] = useState(0);
    const [sIsGlobalSearchFlow, setsIsGlobalSearchFlow] = useState(false);
    const [sErrorMessage, setsErrorMessage] = useState('');
    const [sLoadCancelSuccess, setsLoadCancelSuccess] = useState(false);
    const cancelTokenRef = useRef(null);
    const iconList = [planningIcon, processingIcon, rToSIcon, intransitIcon, deliveredIcon];
    const [sFeatureFlags, setsFeatureFlags] = useState();
    const [sCommentsDrawerOutput, setsCommentsDrawerOutput] = useState(null);
    const [sIsDrawerOpen, setsIsDrawerOpen] = useState(false);
    const selectedPlanDetailsRef = useRef(null);
    const [sIsWithdrawnTenderSuccess, setsIsWithdrawnTenderSuccess] = useState(false);
    const pageLoadSetting = TripSharedService.getPageLoadSettings();
    const { handlePlanAction } = usePlanActionsApiUS();
    const commentsApiConfig = useMemo(
        () => getCommentsAPIConfigs(currentMarket, prefLang?.current, userInfo?.loggedInUserName, getUserName()),
        [currentMarket, prefLang, userInfo],
    );
    const commentValidation = useMemo(() => {
        if (sFeatureFlags?.enableCommentValidation) {
            return COMMENT_VALIDATION.DEFAULT;
        }
        return [];
    }, [sFeatureFlags?.enableCommentValidation]);
    const { callAPI: planCountsApi, ...planCountsApiResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getPlanCounts,
    );

    // const { callAPI: fetchCarrierData, loading: fetchCarrierDataLoading } = useAPI(
    //   TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName,
    //     userInfo.displayName).getCarrierList,
    // );
    const { callAPI: fetchPageLoadData, ...pageLoadDataResponse } = useAPI(
        PageLoadAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getPageLoadData,
    );
    const { callAPI: fetchDispatchDownloadData } = useAPI(
        DownloadDispatchDocAndLabelAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .getDownloadResponse,
    );
    const { callAPI: autoTender } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).autoTender,
    );
    const { callAPI: changeApproveStatus, ...statusApproveResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).approveStatusChange,
    );
    const { callAPI: changeDispatchDeliveredStatus } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).ddStatusChange,
    );
    const { callAPI: assignTrip, ...assignTripResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).assignTrip,
    );
    const { callAPI: carrierAssign } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).carrierAssign,
    );

    const { doSequenceWithdrawTender } = SequenceRequestService(
        {
            setsSelectedPlans,
            setsIsWithdrawnTenderSuccess,
            setsErrorMessage,
            setsSeqErrorList,
            setsProgressValue,
        },
        trans,
        cancelTokenRef,
    );

    const getCancelLoadApiParams = useMemo(
        () =>
            getCancelLoadAPIParams({
                pApiParams: getCancelLoadParams({
                    currentMarket,
                    lang: prefLang?.current,
                    userInfo,
                    hostname: window?.location?.hostname,
                    usUsTenantFlag: false,
                }),
                pTrans: trans,
            }),
        [prefLang?.current, trans, currentMarket],
    );

    const {
        execute: cancelLoad,
        loading: cancelLoadLoading,
        response: cancelLoadResponse,
        error: cancelLoadError,
        resetSession,
    } = useAPIClient(getCancelLoadApiParams);

    useEffect(() => {
        if (sFeatureFlags?.descDateTimeCreated) {
            dispatch({
                type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_ACTIVE_TAB_INDEX,
                activeTabIndex: 0,
                market: currentMarket,
            });
        }
    }, [sFeatureFlags]);
    useEffect(() => {
        setPageState((_pageState) => ({
            ..._pageState,
            search: tableState.queryState.filter,
        }));
    }, [tableState.queryState.filter]);
    const downloadDoc = (tripIds) => {
        cancelTokenRef.current = axios.CancelToken.source();
        const body = {
            payload: {
                planId: tripIds,
            },
            ct: cancelTokenRef.current.token,
        };
        fetchDispatchDownloadData(
            body,
            (res) => {
                try {
                    if (res && res?.length === 2) {
                        const base64BlobDoc = convertDocObjectBaseToBlob(res[0]);
                        FileSaver.saveAs(
                            base64BlobDoc,
                            `${tripIds[0]}_dispatch_${moment().format('MM-DD-YYYY_hh-mm-ss-SSS_A')}.pdf`,
                        );
                        if (pageLoadSetting?.downloadDispatchLabel) {
                            const base64BlobLabel = convertDocObjectBaseToBlob(res[1]);
                            FileSaver.saveAs(
                                base64BlobLabel,
                                `${tripIds[0]}_label_${moment().format('MM-DD-YYYY_hh-mm-ss-SSS_A')}.pdf`,
                            );
                        }
                    }
                } catch (e) {
                    const errorObj = {
                        errMessage: trans('msg.downloadError'),
                        planId: tripIds[0],
                    };
                    setsSeqErrorList((prev) => [...prev, errorObj]);
                }
            },
            () => {
                const errorObj = {
                    errMessage: trans('msg.downloadError'),
                    planId: tripIds[0],
                };
                setsSeqErrorList((prev) => [...prev, errorObj]);
            },
        );
    };
    const doAutoCarrierAssignSeq = (tripIds, data, planList, getPlans, step) => {
        cancelTokenRef.current = axios.CancelToken.source();
        const request = getCarrierAssignRequest(
            data,
            planList?.find((plan) => plan?.planId === tripIds[step]),
            tripIds[step],
            userInfo.loggedInUserName,
        );
        carrierAssign(
            request,
            () => {
                if (tripIds.length > step + 1) doAutoCarrierAssignSeq(tripIds, data, planList, getPlans, step + 1);
                setsProgressValue(step + 1);
                if (tripIds.length === step + 1) {
                    setsSelectedPlans([]);
                    getPlans();
                    setIsAutoCarrierSuccess(true);
                }
            },
            (err) => {
                if (!axios.isCancel(err)) {
                    const errorObj = {
                        errMessage: err?.errors?.[0]?.errorIdentifiers?.details?.payload?.message
                            ? err?.errors?.[0]?.errorIdentifiers?.details?.payload?.message
                            : trans('API.error.invalid'),
                        planId: tripIds[step],
                    };
                    setsErrorMessage(trans('msg.assignCarrier.fail'));
                    setsSeqErrorList((prev) => [...prev, errorObj]);
                    if (tripIds.length > step + 1) doAutoCarrierAssignSeq(tripIds, data, planList, getPlans, step + 1);
                    setsProgressValue(step);
                    if (tripIds.length === step + 1) {
                        setsSelectedPlans([]);
                        getPlans();
                    }
                } else {
                    setsSelectedPlans([]);
                    getPlans();
                }
            },
        );
    };
    const doAutoTenderSeq = (tripIds, getPlans, step) => {
        cancelTokenRef.current = axios.CancelToken.source();
        const body = {
            payload: transformTenderRequest(tripIds[step], userInfo.loggedInUserName),
            ct: cancelTokenRef.current.token,
        };
        autoTender(
            body,
            () => {
                if (tripIds.length > step + 1) doAutoTenderSeq(tripIds, getPlans, step + 1);
                setsProgressValue(step + 1);
                if (tripIds.length === step + 1) {
                    setsSelectedPlans([]);
                    getPlans();
                    setsIsAutoTenderSuccess(true);
                }
            },
            (err) => {
                if (!axios.isCancel(err)) {
                    const errorObj = {
                        errMessage: err?.errors?.[0]?.errorIdentifiers?.details?.payload?.message
                            ? err?.errors?.[0]?.errorIdentifiers?.details?.payload?.message
                            : trans('API.error.invalid'),
                        planId: tripIds[step],
                    };
                    setsErrorMessage(trans('msg.autoTender.fail'));
                    setsSeqErrorList((prev) => [...prev, errorObj]);
                    if (tripIds.length > step + 1) doAutoTenderSeq(tripIds, getPlans, step + 1);
                    setsProgressValue(step + 1);
                    if (tripIds.length === step + 1) {
                        setsSelectedPlans([]);
                        getPlans();
                    }
                } else {
                    setsSelectedPlans([]);
                    getPlans();
                }
            },
        );
    };
    const doDispatchSeq = (tripIds, getPlans, step) => {
        let tripIdToDispatch = tripIds[step];
        let selectedRows = tripIds;
        if (sFeatureFlags?.validateChargeLocationOnTripDispatch) {
            tripIdToDispatch = tripIds?.[step]?.planId;
            selectedRows = tripIds?.map((trip) => trip?.planId);
            if (!tripIds?.[step]?.allLoadsHaveChargeLocAdded) {
                setsSeqErrorList((prev) => [...prev, getFormattedChargeLocError(tripIds?.[step])]);
                if (tripIds?.length > step + 1) doDispatchSeq(tripIds, getPlans, step + 1);
                setsProgressValue(step + 1);
                if (tripIds?.length === step + 1) {
                    setsSelectedPlans([]);
                    getPlans();
                }
                return;
            }
        }
        cancelTokenRef.current = axios.CancelToken.source();
        const body = {
            payload: transformDispatchTripRequest([tripIdToDispatch]),
            ct: cancelTokenRef.current.token,
        };
        changeDispatchDeliveredStatus(
            body,
            () => {
                downloadDoc([tripIdToDispatch], getPlans, true);
                if (tripIds.length > step + 1) doDispatchSeq(tripIds, getPlans, step + 1);
                setsProgressValue(step + 1);
                if (tripIds.length === step + 1) {
                    setsSelectedPlans([]);
                    getPlans();
                    selectedRowIds = selectedRows;
                    setsIsDispatchTripSuccess(true);
                }
            },
            (err) => {
                if (!axios.isCancel(err)) {
                    const errorObj = {
                        errMessage: err?.errors?.[0]?.errorIdentifiers?.details?.[0]?.messages?.[0]?.description
                            ? err?.errors?.[0]?.errorIdentifiers?.details?.[0]?.messages?.[0]?.description
                            : trans('API.error.invalid'),
                        planId: tripIdToDispatch,
                    };
                    setsSeqErrorList((prev) => [...prev, errorObj]);
                    if (tripIds.length > step + 1) doDispatchSeq(tripIds, getPlans, step + 1);
                    setsProgressValue(step + 1);
                    if (tripIds.length === step + 1) {
                        setsSelectedPlans([]);
                        getPlans();
                    }
                } else {
                    setsSelectedPlans([]);
                    getPlans();
                }
            },
        );
    };
    const doDeliveredSeq = (tripIds, getPlans, step) => {
        cancelTokenRef.current = axios.CancelToken.source();
        const body = {
            payload: transformDeliveredTripRequest([tripIds[step]]),
            ct: cancelTokenRef.current.token,
        };
        changeDispatchDeliveredStatus(
            body,
            () => {
                if (tripIds.length > step + 1) doDeliveredSeq(tripIds, getPlans, step + 1);
                setsProgressValue(step + 1);
                if (tripIds.length === step + 1) {
                    setsSelectedPlans([]);
                    getPlans();
                    setsIsDeliveredTripSuccess(true);
                }
            },
            (err) => {
                if (!axios.isCancel(err)) {
                    const errorObj = {
                        errMessage: err?.errors?.[0]?.errorIdentifiers?.details?.[0]?.messages?.[0]?.description
                            ? err?.errors?.[0]?.errorIdentifiers?.details?.[0]?.messages?.[0]?.description
                            : trans('API.error.invalid'),
                        planId: tripIds[step],
                    };
                    setsSeqErrorList((prev) => [...prev, errorObj]);
                    if (tripIds.length > step + 1) doDeliveredSeq(tripIds, getPlans, step + 1);
                    setsProgressValue(step + 1);
                    if (tripIds.length === step + 1) {
                        setsSelectedPlans([]);
                        getPlans();
                    }
                } else {
                    setsSelectedPlans([]);
                    getPlans();
                }
            },
        );
    };
    const doDownloadSeq = (tripIds, getPlans, step) => {
        cancelTokenRef.current = axios.CancelToken.source();
        const body = {
            payload: {
                planId: [tripIds[step]],
            },
            ct: cancelTokenRef.current.token,
        };
        fetchDispatchDownloadData(
            body,
            (res) => {
                try {
                    if (res && res?.length === 2) {
                        const base64BlobDoc = convertDocObjectBaseToBlob(res[0]);
                        FileSaver.saveAs(
                            base64BlobDoc,
                            `${tripIds[step]}_dispatch_${moment().format('MM-DD-YYYY_hh-mm-ss-SSS_A')}.pdf`,
                        );
                        if (pageLoadSetting?.downloadDispatchLabel) {
                            const base64BlobLabel = convertDocObjectBaseToBlob(res[1]);
                            FileSaver.saveAs(
                                base64BlobLabel,
                                `${tripIds[step]}_label_${moment().format('MM-DD-YYYY_hh-mm-ss-SSS_A')}.pdf`,
                            );
                        }
                    }
                } catch (e) {
                    const errorObj = {
                        errMessage: trans('msg.downloadError'),
                        planId: tripIds[step],
                    };
                    setsSeqErrorList((prev) => [...prev, errorObj]);
                }
                if (tripIds.length > step + 1) doDownloadSeq(tripIds, getPlans, step + 1);
                setsProgressValue(step + 1);
                if (tripIds.length === step + 1) {
                    setsSelectedPlans([]);
                    getPlans();
                }
            },
            (err) => {
                if (!axios.isCancel(err)) {
                    const errorObj = {
                        errMessage: trans('msg.downloadError'),
                        planId: tripIds[step],
                    };
                    setsSeqErrorList((prev) => [...prev, errorObj]);
                    if (tripIds.length > step + 1) doDownloadSeq(tripIds, getPlans, step + 1);
                    setsProgressValue(step + 1);
                    if (tripIds.length === step + 1) {
                        setsSelectedPlans([]);
                        getPlans();
                    }
                } else {
                    setsSelectedPlans([]);
                    getPlans();
                }
            },
        );
    };
    const rePrintDoc = (tripIds, getPlans) => {
        setsProgressValue(0);
        setsSeqErrorList([]);
        setsSelectedPlans(tripIds);
        setsPBLabels(downloadPBLabels);
        doDownloadSeq(tripIds, getPlans, 0);
    };
    const onCarrierAssignTrips = (tripIds, data, planList, getPlans) => {
        setsProgressValue(0);
        setsSeqErrorList([]);
        setsErrorMessage('');
        setsSelectedPlans(tripIds);
        doAutoCarrierAssignSeq(tripIds, data, planList, getPlans, 0);
        setsPBLabels(autoCarrierPBLabels);
    };
    const onTenderTrips = (tripIds, getPlans) => {
        setsProgressValue(0);
        setsSeqErrorList([]);
        setsErrorMessage('');
        setsSelectedPlans(tripIds);
        doAutoTenderSeq(tripIds, getPlans, 0);
        setsPBLabels(autoTenderPBLabels);
    };
    const onApproveSuccess = (res, getPlans) => {
        setsIsApproveTripSuccess(true);
        if (res?.errors?.length === 0) {
            getPlans();
        }
    };
    const onTripApprove = (tripIds, getPlans) => {
        changeApproveStatus(
            transformApproveTripRequest(tripIds),
            (res) => {
                onApproveSuccess(res, getPlans);
            },
            (err) => {
                setsError(err);
            },
        );
    };

    const onTripDispatch = (tripIds, getPlans) => {
        setsProgressValue(0);
        setsSeqErrorList([]);
        setsSelectedPlans(
            sFeatureFlags?.validateChargeLocationOnTripDispatch ? tripIds?.map((trip) => trip?.planId) : tripIds,
        );
        doDispatchSeq(tripIds, getPlans, 0);
        setsPBLabels(dispatchPBLabels);
    };
    const onTripDelivered = (tripIds, getPlans) => {
        setsProgressValue(0);
        setsSeqErrorList([]);
        setsSelectedPlans(tripIds);
        doDeliveredSeq(tripIds, getPlans, 0);
        setsPBLabels(deliveredPBLabels);
    };
    const onWithdrawTender = (tripIds, getPlans) => {
        setsProgressValue(0);
        setsSeqErrorList([]);
        setsErrorMessage('');
        setsSelectedPlans(tripIds);
        doSequenceWithdrawTender(tripIds, 0, getPlans);
        setsPBLabels(withdrawTenderPBLabels);
    };
    const onLoadMarkAsDelivered = (tripIds) => {
        setsSelectedPlanId(tripIds?.[0]);
        setsShowForceToDeliveredModal(true);
    };
    const getPageLoadData = () => {
        fetchPageLoadData(getPageStaticDataRequest(currentMarket));
    };
    const setPageLoadData = () => {
        try {
            const {
                rowsPerPage,
                debounceTime,
                country,
                UOM,
                featureFlags: flags,
                paginationSize,
                tabStatus,
                planAggsIndex,
                sortFields,
                defaultOlsenTimezoneId,
                maxTimeHorizonHours,
                durationTimeHorizon,
                bulkSemiColonDeliColumnCount,
                trailerStatusCode,
                size,
                entityType,
                ymsEvent,
                trailerLocType,
                hazmatUpdateAllowedPlanTypes,
                standardDateTimeFormat,
                WTMSLoadlength,
                WTMSLoadSeries,
                WTMSCreatedSourceSystem,
                maxRowSelected,
            } = transformCmsData(TripSharedService.getConfig());
            setsCmsConfig({
                rowsPerPage,
                debounceTime,
                country,
                UOM,
                paginationSize,
                tabStatus,
                planAggsIndex,
                sortFields,
                defaultOlsenTimezoneId,
                maxTimeHorizonHours,
                durationTimeHorizon,
                bulkSemiColonDeliColumnCount,
                trailerStatusCode,
                size,
                entityType,
                ymsEvent,
                trailerLocType,
                hazmatUpdateAllowedPlanTypes,
                standardDateTimeFormat,
                WTMSLoadlength,
                WTMSLoadSeries,
                WTMSCreatedSourceSystem,
                maxRowSelected,
            });
            const tripFeatureFlags = getFeatureFlagsConfig(
                {
                    hostname: window.location.hostname,
                },
                {
                    cmsConfig: {
                        featureFlags: flags,
                    },
                    marketConfig: getMarketSettings(currentMarket),
                    defaultConfig: defaultMarketSettings,
                },
            );
            TripSharedService.setFeatureFlags(tripFeatureFlags);
            setsFeatureFlags(tripFeatureFlags);
            setsPageStaticData(
                transformStaticData(
                    TripSharedService.getTripStaticData(),
                    currentMarket,
                    tripFeatureFlags?.walmartCarrierID,
                ),
            );
            TripSharedService.setStandardDateTimeFormat(standardDateTimeFormat);
        } catch (e) {
            setsIsDataInvalid(true);
        }
    };
    const onSaveSuccess = (res, getPlans) => {
        setsIsCreateTripSuccess(true);
        if (res?.errors?.length === 0) {
            getPlans();
        }
    };
    const createTrips = (data, getPlans) => {
        assignTrip(data, (res) => {
            onSaveSuccess(res, getPlans);
        });
    };

    // /////////////////////////////////////////US actions

    const onGenerateSuccess = (res, getPlans, tripId) => {
        if (res && res?.length === 2) {
            const base64BlobDoc = convertDocObjectBaseToBlob(res[0]);
            FileSaver.saveAs(base64BlobDoc, `${tripId}_dispatch_${moment().format('MM-DD-YYYY_hh-mm-ss-SSS_A')}.pdf`);
            const base64BlobLabel = convertDocObjectBaseToBlob(res[1]);
            FileSaver.saveAs(base64BlobLabel, `${tripId}_label_${moment().format('MM-DD-YYYY_hh-mm-ss-SSS_A')}.pdf`);
        }
        setsIsGenerateSuccess(true);
        getPlans();
    };
    const onUSApproveSuccess = (res, getPlans) => {
        setsIsApprovePlanUSSuccess(true);
        if (res?.errors?.length === 0) {
            getPlans();
        }
    };
    const onUSLoadTripApprove = (planIds, getPlans) => {
        handlePlanAction(
            LoadActionsEnum.APPROVE.name,
            planIds,
            (res) => onUSApproveSuccess(res, getPlans),
            (err) => setsError(err),
        );
    };
    const onTripSheetGenerate = (tripId, getPlans) => {
        handlePlanAction(
            TripActionsEnum.GENERATE_TRIP_SHEET.name,
            tripId,
            (res) => onGenerateSuccess(res, getPlans, tripId),
            (err) => setsError(err),
        );
    };
    // ///////////////////////////////////////////////////////

    const bulkUploadConfiguration = () => {
        const bulkUploadEnvironment = TripSharedService?.getEnvironment();
        const bulkUploadConfig = getBulkUploadConfig(
            bulkUploadEnvironment,
            currentMarket,
            prefLang.current,
            sFeatureFlags,
            sCmsConfig?.bulkSemiColonDeliColumnCount,
        );
        if (
            sPerm?.canEditTrip &&
            (currentMarket === 'cl' ||
                currentMarket === 'mx' ||
                currentMarket === 'mx_mkp' ||
                camMarkets.includes(currentMarket))
        ) {
            setBulkUploadConfig(bulkUploadConfig);
        }
        if (sPerm?.canBulkUploadTender && currentMarket === MarketCodeEnum.US.code) {
            setBulkUploadConfig(bulkUploadConfig);
        }
    };

    const onCommentsDrawerClose = (commentsDrawerOutput) => {
        setsCommentsDrawerOutput(commentsDrawerOutput);
        setsIsDrawerOpen(false);
    };

    const onViewAllComments = (planDetails) => {
        setsSeqErrorList([]);
        setsErrorMessage('');
        selectedPlanDetailsRef.current = planDetails;
        setsIsDrawerOpen(true);
    };

    const commentsDrawerInput = useMemo(() => {
        if (sIsDrawerOpen && selectedPlanDetailsRef.current) {
            const isMultiSelect = selectedPlanDetailsRef.current?.length > 1;
            return {
                ...getCommentsDrawerPropsV2(selectedPlanDetailsRef.current, isMultiSelect, trans),
                pCommentConfigurations: getCommentsConfigurations(sFeatureFlags, isMultiSelect),
            };
        }
        return null;
    }, [sIsDrawerOpen, sFeatureFlags, selectedPlanDetailsRef.current]);

    const cancelLoadAPI = useCallback((checkedRows, reasonCode, cb) => {
        setsSeqErrorList([]);
        setsErrorMessage('');
        cancelLoad({ checkedRows, reasonCode });
        cb();
    }, []);

    useEffect(() => {
        if (cancelLoadResponse?.errorList || cancelLoadError) {
            setsSeqErrorList(cancelLoadResponse?.errorList || cancelLoadError?.errorList);
            setsErrorMessage(cancelLoadResponse?.errorMessage || cancelLoadError?.errorMessage);
            resetSession();
        }
        if (cancelLoadResponse?.isSuccess) {
            setsLoadCancelSuccess(true);
        }
    }, [cancelLoadResponse, cancelLoadError]);

    useEffect(() => {
        setBreadCrumbArr([]);
        if (prefLang.current) {
            const {
                location: { hostname },
            } = window;
            TripSharedService.setEnvironment({
                hostname,
            });
            if (isNullOrUndefined(TripSharedService.getUserPermissions())) {
                const userPerm = JSON.parse(localStorage.getItem('ngStorage-permissionData'));
                TripSharedService.setUserPermissions(userPerm?.permissions);
            }
            const editPermissions = canEditTrip(TripSharedService.getUserPermissions(), currentMarket);
            setsPerm({
                canEditTrip: editPermissions,
                canAccessNonDrayLoads: canAccessNonDrayLoads(TripSharedService.getUserPermissions(), currentMarket),
                canBulkUploadTender: canBulkUploadTender(TripSharedService.getUserPermissions(), currentMarket),
            });
            bulkUploadConfiguration();
            const lang = TripSharedService.getCurrentLanguage();
            if (lang && lang !== prefLang.current) {
                // TODO: fix me after gscope open issue resolves
                // https://gecgithub01.walmart.com/gscope-platform/aura-fe/issues/325
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            }
            // setHeaderConfig({
            //   ...headerConfig,
            //   title: trans('title.tripManagement'),
            // });

            // setsSelectedTab(trans(sPlanQueryTabs[0]));
            if (
                !TripSharedService.getConfig() ||
                !TripSharedService.getTripStaticData() ||
                !TripSharedService.getFeatureFlags() ||
                !TripSharedService.getTripStaticData()?.payload?.mdm_static_data
            ) {
                getPageLoadData();
            } else {
                setMdmLocationTypes(
                    transformMdmLocationTypes(
                        TripSharedService.getTripStaticData()?.payload.mdm_static_data.static_data.mdm_location_types,
                    ),
                );
                setPageLoadData();
            }
            const marketSettings = getMarketSettings(currentMarket);
            TripSharedService.setPageLoadSettings(marketSettings);
            setSPlanQueryTabs(getPhaseTabsForCurrentMarket(currentMarket));
            setsTabsSecondaryTitle(getSecondaryTextForTabs(currentMarket, trans, tableState.queryState));
        }
    }, [prefLang.current]);
    useEffect(() => bulkUploadConfiguration(), [sCmsConfig, sPerm]);
    useEffect(() => {
        try {
            if (pageLoadDataResponse.response && pageLoadDataResponse.response.length === 2) {
                TripSharedService.setConfig(pageLoadDataResponse.response[0]);
                TripSharedService.setTripStaticData(pageLoadDataResponse.response[1], prefLang.current);
                setMdmLocationTypes(
                    transformMdmLocationTypes(
                        pageLoadDataResponse.response[1].payload.mdm_static_data.static_data.mdm_location_types,
                    ),
                );
                setPageLoadData();
            }
        } catch (e) {
            setsIsDataInvalid(true);
        }
    }, [pageLoadDataResponse.response]);
    const isLoading = useMemo(
        () =>
            pageLoadDataResponse.loading ||
            assignTripResponse.loading ||
            statusApproveResponse.loading ||
            sResponseLoading ||
            planCountsApiResponse.loading ||
            cancelLoadLoading,
        [
            pageLoadDataResponse.loading,
            statusApproveResponse.loading,
            assignTripResponse.loading,
            sResponseLoading,
            planCountsApiResponse.loading,
            cancelLoadLoading,
        ],
    );
    const onCreateTripReqChange = (data, getPlans) => {
        createTrips(data, getPlans);
    };
    const onTabCardClick = (e, index) => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_ACTIVE_TAB_INDEX,
            activeTabIndex: index,
            market: currentMarket,
        });
    };
    const handleGroupByChange = (data) => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.GROUP_BY,
            groupBy: data,
        });
    };
    const onSearchFilterModalClose = () => {
        setsIsSearchFilterModalOpen(false);
    };
    const getCountSum = useCallback((list) => (list ? list?.reduce((a, b) => a + b?.count, 0) : 0), []);
    useEffect(() => {
        let count = 0;
        const phaseCountObj = {};
        if (currentMarket === MarketCodeEnum.US.code || currentMarket === MarketCodeEnum.USTRX.code) {
            Object.keys(PhaseTypesEnum).forEach((item) => {
                phaseCountObj[PhaseTypesEnum[item].index] = sCardData[PhaseTypesEnum[item].fieldBE]?.doc_count;
            });
            setsEsbTableRowCount(sCardData[phasesForAggsEnum.ADDITIONAL_FILTER]?.doc_count);
        } else {
            Object.keys(PhaseTypesEnum).forEach((item) => {
                count = getCountSum(sCardData[PhaseTypesEnum[item].fieldBE]);
                phaseCountObj[PhaseTypesEnum[item].index] = count;
            });
        }
        setsPhaseTotalCounts(phaseCountObj);
    }, [sCardData]);
    useEffect(() => {
        setsTabsSecondaryTitle(getSecondaryTextForTabs(currentMarket, trans, tableState.queryState));
    }, [tableState.queryState]);
    const totalCount = useMemo(() => Object.values(sPhaseTotalCounts).reduce((p, c) => p + c, 0), [sPhaseTotalCounts]);
    const renderTabCards = useCallback(
        () => (
            <div
                style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                }}
                className="ml-3"
            >
                {sPlanQueryTabs.map(({ desc: label, index }) => (
                    <div
                        key={index}
                        className={
                            sPhaseTotalCounts[index] === 0 && tableState.queryState.globalSearchData
                                ? classes.actionDisabled
                                : ''
                        }
                    >
                        <TabCard
                            key={label}
                            pIsSelected={index === tableState.queryState.activeTabIndex}
                            pCount={sPhaseTotalCounts[index]}
                            pOnClick={(title) => onTabCardClick(title, index)}
                            pTitle={trans(label)}
                            pIcon={iconList[index]}
                            data-testid={`tabChild${index}`}
                            pExceptionCount={`${sCardData?.[index]?.exceptionCount}${getPlanLabel(
                                sCardData?.[index],
                                trans,
                            )}`}
                            pShowException={sCardData?.[index]?.showException}
                            pSecTitle={sTabsSecondaryTitle[index]}
                        />
                    </div>
                ))}
            </div>
        ),
        [
            sCardData,
            sPlanQueryTabs,
            tableState.queryState.activeTabIndex,
            sPhaseTotalCounts,
            tableState.queryState.globalSearchData,
        ],
    );
    const getModuleTitle = useMemo(() => {
        if (prefLang.current) {
            if (
                (currentMarket === MarketCodeEnum.US.code || currentMarket === MarketCodeEnum.USTRX.code) &&
                tableState.queryState.globalSearchData &&
                sIsGlobalSearchFlow
            ) {
                return `${totalCount} ${trans('title.us.tripManagement.searchResults')}`;
            }
            return trans('title.us.tripManagement');
        }
    }, [
        sFeatureFlags,
        tableState.queryState.globalSearchData,
        sPhaseTotalCounts,
        prefLang.current,
        sIsGlobalSearchFlow,
    ]);
    const getHeaderChildren = () => (
        <>
            {sFeatureFlags?.showGlobalSearch && (
                <GlobalSearch
                    pPhaseTotal={sPhaseTotalCounts}
                    dispatch={dispatch}
                    queryState={tableState.queryState}
                    pIsGlobalSearchFlow={(d) => setsIsGlobalSearchFlow(d)}
                    pFeatureFlag={sFeatureFlags}
                />
            )}
            {!sFeatureFlags?.enableBulkUpload && (
                <Tooltip title={trans('label.bulkHistory')} arrow>
                    <IconButton data-testid="bulkHistoryButton">
                        <UploadIcon
                            size="medium"
                            onClick={() => {
                                window.open('/bulkupload/history');
                            }}
                        />
                    </IconButton>
                </Tooltip>
            )}
        </>
    );
    const getNormalFlow = () => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.GLOBAL_SEARCH,
            payload: {
                globalSearch: null,
                activeTabIndex: 0,
                market: currentMarket,
                searchByOption: tableState.queryState.searchByOption,
            },
        });
    };
    const getPlanSearch = () => {
        if (currentMarket === MarketCodeEnum.US.code || currentMarket === MarketCodeEnum.USTRX.code) {
            return (
                <PlanSearchUS
                    queryState={tableState.queryState}
                    dispatch={dispatch}
                    pIsOpen={sIsSearchFilterModalOpen}
                    pOnClose={onSearchFilterModalClose}
                    pStaticData={sPageStaticData}
                />
            );
        }
        return (
            <PlanSearch
                queryState={tableState.queryState}
                dispatch={dispatch}
                pIsOpen={sIsSearchFilterModalOpen}
                pOnClose={onSearchFilterModalClose}
                pStaticData={sPageStaticData}
            />
        );
    };
    const getNoResultorTableForUS = () => {
        if (tableState.queryState.globalSearchData && totalCount === 0 && sIsGlobalSearchFlow) {
            return <NoResults pOnBack={getNormalFlow} />;
        }
        return (
            <PlanTableUS
                queryState={tableState.queryState}
                dispatch={dispatch}
                pIsLoading={isLoading}
                pTabIndex={tableState.queryState.activeTabIndex}
                pConfig={sCmsConfig}
                pPhaseCounts={(d) => setsCardData(d)}
                pStaticData={sPageStaticData}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={setsIsSearchFilterModalOpen}
                pOnPlanApprove={onUSLoadTripApprove}
                pOnTripSheetGenerate={onTripSheetGenerate}
                pOnRLOGSuccess={setsIsRLOGSuccess}
                pSearchAPIResultsCount={sEsbTableRowCount}
                pOnLoadMarkAsDelivered={onLoadMarkAsDelivered}
                pIsGlobalSearchFlow={(d) => setsIsGlobalSearchFlow(d)}
                pCheckedRows={tableState.checkedRows}
                pClientPageNumber={tableState.pageNumber}
                pTableSearch={tableState.tableSearchText}
                pShowNavConfirmationModal={tableState.showNavConfirmationModal}
                pUserPerm={sPerm}
            />
        );
    };
    const getPlanTable = () => {
        if (currentMarket === MarketCodeEnum.US.code || currentMarket === MarketCodeEnum.USTRX.code) {
            return getNoResultorTableForUS();
        }
        return (
            <>
                {tableState.queryState.activeTabIndex === PhaseTypesEnum.PLANNING.index && (
                    <PlanTable
                        queryState={tableState.queryState}
                        dispatch={dispatch}
                        pIsLoading={isLoading}
                        pTabIndex={PhaseTypesEnum.PLANNING.index}
                        pConfig={sCmsConfig}
                        pOnTripApprove={onTripApprove}
                        pCreateTripReq={onCreateTripReqChange}
                        pIsActive={tableState.queryState.activeTabIndex === PhaseTypesEnum.PLANNING.index}
                        pUserPerm={sPerm}
                        mdmLocationTypes={mdmLocationTypes}
                        pSetsIsSearchFilterModalOpen={setsIsSearchFilterModalOpen}
                        pPhaseCounts={(d) => setsCardData(d)}
                        pStaticData={sPageStaticData}
                        pOnViewAllComments={onViewAllComments}
                        pCancelLoad={cancelLoadAPI}
                    />
                )}
                {tableState.queryState.activeTabIndex === PhaseTypesEnum.PROCESSING.index && (
                    <PlanTable
                        queryState={tableState.queryState}
                        dispatch={dispatch}
                        pIsLoading={isLoading}
                        pTabIndex={PhaseTypesEnum.PROCESSING.index}
                        pConfig={sCmsConfig}
                        pOnTripTender={onTenderTrips}
                        pUserPerm={sPerm}
                        pIsActive={tableState.queryState.activeTabIndex === PhaseTypesEnum.PROCESSING.index}
                        mdmLocationTypes={mdmLocationTypes}
                        pSetsIsSearchFilterModalOpen={setsIsSearchFilterModalOpen}
                        pStaticData={sPageStaticData}
                        pOnCarrierAssign={onCarrierAssignTrips}
                        pOnViewAllComments={onViewAllComments}
                        pCancelLoad={cancelLoadAPI}
                    />
                )}
                {tableState.queryState.activeTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index && (
                    <PlanTable
                        queryState={tableState.queryState}
                        dispatch={dispatch}
                        pIsLoading={isLoading}
                        pTabIndex={PhaseTypesEnum.DISPATCH_PENDING.index}
                        pConfig={sCmsConfig}
                        pOnTripDispatch={onTripDispatch}
                        pOnLoadMarkAsDelivered={onLoadMarkAsDelivered}
                        pUserPerm={sPerm}
                        pIsActive={tableState.queryState.activeTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index}
                        mdmLocationTypes={mdmLocationTypes}
                        pSetsIsSearchFilterModalOpen={setsIsSearchFilterModalOpen}
                        pStaticData={sPageStaticData}
                        pOnViewAllComments={onViewAllComments}
                        pOnWithdrawTender={onWithdrawTender}
                        pCancelLoad={cancelLoadAPI}
                    />
                )}
                {tableState.queryState.activeTabIndex === PhaseTypesEnum.IN_TRANSIT.index && (
                    <PlanTable
                        queryState={tableState.queryState}
                        dispatch={dispatch}
                        pIsLoading={isLoading}
                        pTabIndex={PhaseTypesEnum.IN_TRANSIT.index}
                        pConfig={sCmsConfig}
                        pOnTripDelivered={onTripDelivered}
                        pOnLoadMarkAsDelivered={onLoadMarkAsDelivered}
                        pOnReprintDoc={rePrintDoc}
                        pUserPerm={sPerm}
                        pIsActive={tableState.queryState.activeTabIndex === PhaseTypesEnum.IN_TRANSIT.index}
                        mdmLocationTypes={mdmLocationTypes}
                        pSetsIsSearchFilterModalOpen={setsIsSearchFilterModalOpen}
                        pStaticData={sPageStaticData}
                        pOnViewAllComments={onViewAllComments}
                        pOnWithdrawTender={onWithdrawTender}
                    />
                )}
            </>
        );
    };

    const handleCloseNavigationModal = () => {
        if (tableState.queryState.globalSearchData && !sIsGlobalSearchFlow) {
            setsIsGlobalSearchFlow(true);
        }
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CLOSE_NAVIGATION,
        });
    };
    const handleConfirmNavigationModal = () => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CONTINUE_NAVIGATION,
        });
    };

    return (
        <>
            {pErrors?.error && (
                <div className={classes.errorAlert}>
                    <Alert data-testid="externalAccessAlert" variant="error">
                        {trans('module.permAccessErrorMsg')}
                    </Alert>
                </div>
            )}
            <div className={classes.errorAlertMessage}>
                {sErrorMessage && (
                    <Alert
                        data-testid="errorAlertMessage"
                        variant="error"
                        onClose={() => {
                            setsErrorMessage('');
                        }}
                    >
                        {sErrorMessage}
                    </Alert>
                )}
            </div>
            {!pErrors?.error && (
                <div className={classes.pageContainer}>
                    <PageHeader
                        pOnBackClick={
                            tableState.queryState.globalSearchData && sIsGlobalSearchFlow
                                ? () => {
                                      getNormalFlow();
                                  }
                                : undefined
                        }
                        pTitle={getModuleTitle}
                        pClassName={classes.pageHeader}
                        LanguageSelectorComponent={LanguageSelector}
                        BulkUploadComponent={BulkUpload}
                        MarketSelectorComponent={MarketSelector}
                        useAppContextHook={AppUtils.get}
                        pBulkUploadHistory={bulkUploadHistory}
                        pCommonTrans={commonTrans}
                        pHideProfileButton={!sFeatureFlags?.showProfileButton}
                        pHideBulkUploadIcon={!sFeatureFlags?.enableBulkUpload}
                        pBulkUploadIconPosition="right"
                    >
                        <PageHeader.Content placement="left">
                            {sFeatureFlags?.showProfile &&
                                !sFeatureFlags?.showProfileSelectorV2 &&
                                !tableState.queryState?.globalSearchData && (
                                    <div
                                        className={tableState.queryState.globalSearchData ? classes.actionDisabled : ''}
                                    >
                                        <ProfileSelector
                                            pFeatureFlag={sFeatureFlags}
                                            queryState={tableState.queryState}
                                            dispatch={dispatch}
                                            pPageStaticData={sPageStaticData}
                                        />
                                    </div>
                                )}
                            {sFeatureFlags?.showProfileSelectorV2 && !tableState.queryState?.globalSearchData && (
                                <div className={tableState.queryState.globalSearchData ? classes.actionDisabled : ''}>
                                    <ProfileSelectorV2
                                        queryState={tableState.queryState}
                                        dispatch={dispatch}
                                        pPageStaticData={sPageStaticData}
                                    />
                                </div>
                            )}
                            {sFeatureFlags?.showTimeHorizonV2 && !tableState.queryState?.globalSearchData && (
                                <TimeHorizonV2
                                    queryState={tableState.queryState}
                                    pHistory={history}
                                    dispatch={dispatch}
                                    pPageStaticData={sPageStaticData}
                                    pCmsData={sCmsConfig?.durationTimeHorizon}
                                    pDisabled={
                                        tableState.queryState.globalSearchData ||
                                        (tableState.queryState.activeTabIndex &&
                                            (tableState.queryState.activeTabIndex === PhaseTypesEnum.IN_TRANSIT.index ||
                                                tableState.queryState.activeTabIndex ===
                                                    PhaseTypesEnum.DELIVERED.index))
                                    }
                                />
                            )}
                            {sFeatureFlags?.enableGroupBy && !tableState.queryState?.globalSearchData && (
                                <GroupByFilter
                                    pOnChange={handleGroupByChange}
                                    pVariant={tableState.queryState.globalSearchData ? 'disabled' : 'default'}
                                    queryState={tableState.queryState}
                                />
                            )}
                        </PageHeader.Content>
                        <PageHeader.Content placement="right">{getHeaderChildren()}</PageHeader.Content>
                    </PageHeader>

                    {sIsCreateTripSuccess && assignTripResponse.error?.errors?.length === 0 && (
                        <Toast
                            text={trans('msg.createTripSuccess')}
                            variant="positive"
                            onClose={() => {
                                setsIsCreateTripSuccess(false);
                            }}
                            delay={toastTimer}
                            className={classes.stTripToast}
                        />
                    )}
                    {/* User Profile not found error commented */}
                    {/* {sUserProfileError && (
            <Alert
            variant="error"
            action={getUserProfile}
            actionText={trans('button.retry')}
            >
            {trans('fetchUserProfile.prefNotFound')}
            </Alert>
        )} */}
                    {sIsCreateTripSuccess && assignTripResponse.error && assignTripResponse.error?.errors?.length && (
                        <Alert
                            variant="error"
                            data-testid="assignTripSucessFailAlert"
                            onClose={() => {
                                setsIsCreateTripSuccess(false);
                            }}
                        >
                            {getFormattedTripError(assignTripResponse.error, trans)}
                        </Alert>
                    )}
                    {!sIsCreateTripSuccess && assignTripResponse.error && !assignTripResponse.response && (
                        <Alert
                            variant="error"
                            data-testid="assignTripFailAlert"
                            onClose={() => {
                                setsIsCreateTripSuccess(false);
                            }}
                        >
                            {getFormattedTripError(assignTripResponse.error, trans)}
                        </Alert>
                    )}

                    {sShowForceToDeliveredModal &&
                        currentMarket !== MarketCodeEnum.US.code &&
                        currentMarket !== MarketCodeEnum.USTRX.code && (
                            <ForceLoadToDeliveredModal
                                pOpenModal={sShowForceToDeliveredModal}
                                pOnCloseModal={() => setsShowForceToDeliveredModal(false)}
                                pPlanId={sSelectedPlanId}
                                pError={(error) => setsError(error)}
                                pLoading={(value) => setsResponseLoading(value)}
                                pSuccess={() => {
                                    setIsPlanStatusToDeliveredSuccess(true);
                                    dispatch({
                                        type: PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS,
                                        checkedRows: [],
                                    });
                                }}
                                pStaticData={sPageStaticData}
                            />
                        )}

                    {sShowForceToDeliveredModal &&
                        (currentMarket === MarketCodeEnum.US.code || currentMarket === MarketCodeEnum.USTRX.code) && (
                            <ForceLoadToDeliveredModalUS
                                pOpenModal={sShowForceToDeliveredModal}
                                pOnCloseModal={() => setsShowForceToDeliveredModal(false)}
                                pPlanId={sSelectedPlanId}
                                pError={(error) => setsError(error)}
                                pLoading={(value) => setsResponseLoading(value)}
                                pSuccess={() => {
                                    setIsPlanStatusToDeliveredSuccess(true);
                                }}
                                pStaticData={sPageStaticData}
                            />
                        )}
                    {commentsDrawerInput && (
                        <DrawerComponent position="right" open={sIsDrawerOpen} data-testid="comments-sidebar-drawer">
                            <div className={classes.commentsDrawerContent}>
                                <LTMCommentsV2
                                    pUserInfo={{ ...userInfo, displayName: getUserName() }}
                                    pApiConfigs={commentsApiConfig}
                                    pOnClose={onCommentsDrawerClose}
                                    pIsEditEnabled={true}
                                    {...commentsDrawerInput}
                                    pValidation={commentValidation}
                                />
                            </div>
                        </DrawerComponent>
                    )}

                    {sIsPlanStatusToDeliveredSuccess && (
                        <Toast
                            text={trans('msg.updatedStatusToDelivered')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setIsPlanStatusToDeliveredSuccess(false);
                            }}
                        />
                    )}

                    {pageLoadDataResponse.error && (
                        <Alert
                            variant="error"
                            data-testid="pageLoadFailAlert"
                            action={getPageLoadData}
                            actionText={trans('button.retry')}
                        >
                            {trans('API.error.getConfigGetStaticData')}
                        </Alert>
                    )}

                    {sIsDataInvalid && (
                        <Alert
                            data-testid="pageLoadAlert"
                            variant="error"
                            action={getPageLoadData}
                            actionText={trans('button.retry')}
                        >
                            {trans('pageError.summary.invalidData')}
                        </Alert>
                    )}
                    {sIsApprovePlanUSSuccess && (
                        <Toast
                            text={trans('msg.approvePlanUSSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsIsApprovePlanUSSuccess(false);
                            }}
                        />
                    )}

                    {/* Todo: R2 - Review comment - Needs to check if we can use single toast for this
        and generateTripSuccess */}
                    {sIsRLOGSuccess && (
                        <Toast
                            text={trans('msg.rlogCreationSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsIsRLOGSuccess(false);
                            }}
                        />
                    )}

                    {sIsApproveTripSuccess && statusApproveResponse?.error?.errors?.length === 0 && (
                        <Toast
                            text={trans('msg.approveTripSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsIsApproveTripSuccess(false);
                            }}
                        />
                    )}
                    {sIsApproveTripSuccess &&
                        statusApproveResponse?.error?.errors?.length &&
                        statusApproveResponse?.response?.status === 'FAIL' && (
                            <Alert
                                variant="error"
                                data-testid="statusApproveFailAlert"
                                onClose={() => {
                                    setsIsApproveTripSuccess(false);
                                }}
                            >
                                {getFormattedTripError(statusApproveResponse?.error, trans)}
                            </Alert>
                        )}
                    {sIsDispatchTripSuccess && (
                        <Toast
                            text={`${trans('msg.dispatchTripSuccess1')} ${selectedRowIds?.join(',')} ${trans(
                                'msg.dispatchTripSuccess2',
                            )}`}
                            subText={trans('msg.dispatchTripSuccess3')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsIsDispatchTripSuccess(false);
                            }}
                        />
                    )}
                    {sIsDeliveredTripSuccess && (
                        <Toast
                            text={trans('msg.deliveredTripSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsIsDeliveredTripSuccess(false);
                            }}
                        />
                    )}
                    {sError && (
                        <Alert
                            variant="error"
                            data-testid="stateBasedErrorAlert"
                            onClose={() => {
                                setsError('');
                            }}
                        >
                            {getFormattedTripError(sError, trans)}
                        </Alert>
                    )}
                    {sSeqErrorList.length > 0 && (
                        <Alert
                            variant="error"
                            data-testid="stateBasedErrorAlert"
                            onClose={() => {
                                setsSeqErrorList([]);
                            }}
                        >
                            {getFormattedTripError(sSeqErrorList, trans)}
                        </Alert>
                    )}
                    {sIsAutoTenderSuccess && !sSeqErrorList?.length && (
                        <Toast
                            text={trans('msg.autoTendorSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsIsAutoTenderSuccess(false);
                            }}
                        />
                    )}
                    {sIsAutoCarrierSuccess && !sSeqErrorList?.length && (
                        <Toast
                            text={trans('msg.autoCarrierSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setIsAutoCarrierSuccess(false);
                            }}
                        />
                    )}
                    {sIsWithdrawnTenderSuccess && !sSeqErrorList?.length && (
                        <Toast
                            text={trans('msg.tenderWithdrawnSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsIsWithdrawnTenderSuccess(false);
                            }}
                        />
                    )}
                    {sLoadCancelSuccess && (
                        <Toast
                            text={trans('msg.loadCancelSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsLoadCancelSuccess(false);
                            }}
                        />
                    )}
                    {sIsGenerateSuccess && (
                        <Toast
                            text={trans('msg.generateTripSuccess')}
                            variant="positive"
                            delay={toastTimer}
                            className={classes.stTripToast}
                            onClose={() => {
                                setsIsGenerateSuccess(false);
                            }}
                        />
                    )}
                    <div id={ERROR_CONTAINER_ID} />

                    <ProgressBarModal
                        pIsModalOpen={sSelectedPlans.length}
                        pOnCloseModal={() => {
                            cancelTokenRef.current.cancel();
                        }}
                        pModalTitle1={trans(sPBLabels?.title1)}
                        pModalTitle2={trans(sPBLabels?.title2)}
                        pCancelText={trans(sPBLabels?.cancelText)}
                        pProgressValue={sProgressValue}
                        pTotalLength={sSelectedPlans.length}
                        pProgressInfoText={trans(sPBLabels?.progressInfoText)}
                    />
                    {
                        <ConfirmationModal
                            pIsModalOpen={tableState.showNavConfirmationModal}
                            pOnCloseModal={handleCloseNavigationModal}
                            pOnConfirmation={handleConfirmNavigationModal}
                            pModalTitle={trans('navigationConfirmModal.title')}
                            pModalInfo={trans('navigationConfirmModal.info')}
                            pCancelText={trans('button.cancel')}
                            pConfirmText={trans('button.yesContinue')}
                            pBoldTitle
                        />
                    }
                    {renderTabCards()}

                    {sPageStaticData && !sIsDataInvalid && sCmsConfig && (
                        <>
                            <div
                                className={clsx(classes.planTableContainer, 'mx-4', 'mb-4', 'mt-1')}
                                data-testid="page-content-container"
                            >
                                {getPlanTable()}
                            </div>
                        </>
                    )}
                    {sIsSearchFilterModalOpen && sPageStaticData && getPlanSearch()}
                </div>
            )}
        </>
    );
}

TripManagementSummary.propTypes = {
    errors: PropTypes.shape({ error: PropTypes.string }),
};

TripManagementSummary.defaultProps = {
    errors: {},
};

const supplier = 'location';
const carrierDetailsApiConfig = {
    ccmServiceName: 'stride-carrier',
    ccmRouteName: 'carrierDetails',
};
const supplierSearchApiConfig = {
    ccmServiceName: 'stride-location',
    ccmRouteName: 'locationDetails',
    ccmRouteNameLocationSearch: 'searchLocation',
    locationType: 'BVNDR',
    supplierType: 'SPLR',
};

const ModifiedComponent = WithPermissionHOC(
    WithRLInfo(TripManagementSummary, {
        pUseAppContext: () => AppUtils.get(),
        pSupplier: supplier,
        pAxios: axios,
        pCarrierDetailsApiConfig: carrierDetailsApiConfig,
        pSupplierDetailsApiConfig: supplierSearchApiConfig,
        pLoadI18n: loadI18n,
        pUsUsTenantFlag: true,
        pMultiVendorsSearch: true,
        pValidateInLocalStorage: true,
        pVerify3plUserDetails: true,
        pBaseUrl: BASE_URL,
        pAccessByPermission: true,
        // TODO: need market to be derived, other tenants can use this functionality
        pAllowPermissionsList: [
            'us.stride.ltm-tripManagement:DRAY_EXT_USER',
            'ustrx.stride.ltm-tripManagement:DRAY_EXT_USER',
        ],
    }),
    PermAccessFallBack,
    {
        readPermissions,
    },
    {
        pAppContext: () => AppUtils.get(),
        pPermMarket: permMarkets,
    },
);
export default function ErrorBoundaryWrapper() {
    const { currentMarket } = AppUtils.get();
    const trans = useLoadSupportedLangs(currentMarket);
    return (
        <ErrorBoundary
            pPageTitle={trans('title.us.tripManagement')}
            pUseAppContextHook={AppUtils.get}
            pDefaultErrorTitle={trans('msg.defaultError')}
        >
            <ToastProvider>
                <ModifiedComponent />
            </ToastProvider>
        </ErrorBoundary>
    );
}
