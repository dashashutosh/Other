import React, { memo, useMemo } from 'react';
import PropTypes from 'prop-types';
import { MoreIcon, Chip } from '@walmart/living-design-sc-ui';
import { fromReqPayloadKeyToSearchFilter, searchFilterReqPayloadToChips } from './DataModels';
import { searchFilterReqPayload } from '../../utils/ui-mappers/PlanSearchMappers';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../utils/actions/PlanTableQueryActions';
import { QueryStateType } from '../../utils/types/PlanSearchTypes';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { AppUtils } from '@gscope-mfe/app-bridge';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
/**
 * // TODO: Revist this entire component logic
 *
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */

const useStyles = makeStyles(() => ({
    chipStyle: {
        marginRight: '.5rem !important',
        marginBottom: '0.5rem !important',
    },
}));
const TableFilterChips = ({ queryState, dispatch, showMoreButton, pGetFilterChipCount }) => {
    const trans = localizeLang();
    const { currentMarket } = AppUtils.get();
    const classes = useStyles();
    const searchCriteria = useMemo(
        () => ({
            payload: searchFilterReqPayload(queryState.filter, currentMarket, queryState.activeTabIndex),
        }),
        [queryState.filter],
    );
    const handleChipClose = (val) => {
        const { payload } = searchCriteria;
        if (val.source && val.key && payload && payload[val.source]) {
            if (payload[val.source][val.key]) {
                delete payload[val.source][val.key];
            }
            if (Array.isArray(payload[val.source])) {
                payload[val.source].forEach((k, it) => {
                    if (it[val.key]) {
                        delete payload[val.source][k][val.key];
                    }
                });
            }
        } else if (val.source && payload && payload[val.source]) {
            if (payload[val.source]) {
                delete payload[val.source];
            }
        }
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_FILTER,
            filter: fromReqPayloadKeyToSearchFilter(queryState.filter, val),
        });
    };
    const displayChips = () => {
        const chips = searchFilterReqPayloadToChips(searchCriteria);
        const display =
            chips &&
            chips
                .filter((a) => typeof a?.value === 'boolean' || a?.value?.length > 0)
                .map((val) => (
                    <Chip
                        key={`${val.key}-${val.value}`}
                        className={`${!showMoreButton ? classes.chipStyle : 'ml-2 mt-2'}`}
                        showCrossIcon
                        onClick={() => handleChipClose(val)}
                        variant="selected"
                    >
                        {val.key
                            ? `${trans(`label.${val.source}.${val.key}`)} : ${val.display}`
                            : `${trans(`label.${val.source}`)} : ${val.display}`}
                    </Chip>
                ));
        const obj = {
            more: false,
        };
        if (chips && chips.length > 4 && showMoreButton) {
            obj.display = display.slice(0, 5);
            obj.more = true;
        } else {
            obj.display = display;
        }
        pGetFilterChipCount(display?.length);
        return obj;
    };
    const chipsDisplay = displayChips();
    return (
        <div className="d-flex flex-wrap">
            {chipsDisplay.display}
            {chipsDisplay.more && showMoreButton ? (
                <chip className="ml-2 mt-2">
                    <MoreIcon size="medium" data-testid="moreIcon" />
                </chip>
            ) : (
                ''
            )}
        </div>
    );
};
const propTypes = {
    queryState: QueryStateType.isRequired,
    dispatch: PropTypes.func.isRequired,
    showMoreButton: PropTypes.bool,
    pGetFilterChipCount: PropTypes.func,
};
TableFilterChips.defaultProps = {
    showMoreButton: true,
    pGetFilterChipCount: () => {},
};
TableFilterChips.propTypes = propTypes;
export default memo(TableFilterChips);
