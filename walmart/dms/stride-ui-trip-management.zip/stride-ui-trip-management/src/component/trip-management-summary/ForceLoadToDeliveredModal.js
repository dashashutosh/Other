import React, { useState, useEffect, useMemo } from 'react';
import { useAPI, ForceToDelivered, ForceToDeliveredCA } from '@walmart/stride-ui-commons';
import PropTypes from 'prop-types';
import { TripAPI } from '../../service/TripAPI';
import { getLoadDetailsCA } from '../../utils/ui-mappers/PlanDetailUiModelCA';
import TripSharedService from '../../service/TripSharedService';
import { formatForceToDeleverPlanRequest } from './DataModels';

/**
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;
const ForceLoadToDeliveredModal = ({ pOpenModal, pPlanId, pError, pOnCloseModal, pLoading, pSuccess, pStaticData }) => {
    const { prefLang, currentMarket, userInfo } = AppUtils.get();
    const trans = localizeLang();
    const [sLoadDetailsResponse, setsLoadDetailsResponse] = useState();
    const [sLosEvent, setsLOSEvents] = useState();
    const featureFlags = TripSharedService.getFeatureFlags();
    const { callAPI: fetchLoadDetails, ...fetchLoadDetailsResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getLoadDetails,
    );
    const { callAPI: fetchStaticDataAPI, ...fetchStaticDataResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).fetchStaticData,
    );
    const { callAPI: updateInTransitPlanStatus, ...updateInTransitPlanStatusResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).updateInTransitPlan,
    );
    const { callAPI: updateTrackingPlanApi, ...updateTrackingPlanResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).updateTrackingPlan,
    );
    useEffect(() => {
        const isLoading =
            fetchStaticDataResponse.loading ||
            fetchLoadDetailsResponse.loading ||
            updateInTransitPlanStatusResponse.loading ||
            updateTrackingPlanResponse.loading;
        pLoading(isLoading);
    }, [
        fetchStaticDataResponse.loading,
        fetchLoadDetailsResponse.loading,
        updateInTransitPlanStatusResponse.loading,
        updateTrackingPlanResponse.loading,
    ]);
    useEffect(() => {
        if (fetchLoadDetailsResponse.response?.payload) {
            setsLoadDetailsResponse(fetchLoadDetailsResponse.response.payload);
        }
    }, [fetchLoadDetailsResponse.response]);
    useEffect(() => {
        if (fetchStaticDataResponse.response?.los) {
            setsLOSEvents(fetchStaticDataResponse.response?.los);
        }
    }, [fetchStaticDataResponse.response]);
    useEffect(() => {
        if (!pOpenModal) {
            return;
        }
        fetchStaticDataAPI();
        if (pPlanId) {
            fetchLoadDetails(pPlanId);
        }
    }, [pOpenModal, pPlanId]);
    const forceLoadToDeliverModalTranslations = useMemo(() => {
        if (featureFlags?.showUpdateTimeline) {
            return {
                arrivalLabel: trans('forceToDelivered.arrivalTitle'),
                departLabel: trans('forceToDelivered.departTitle'),
                losSelectLabel: trans('forceToDelivered.losSelectTitle'),
                stopLabel: trans('forceToDelivered.stopTitle'),
                arrivalAndDepartureLabel: trans('forceToDelivered.arrivalAndDepartureTitle'),
                losArrivalSelectLabel: trans('forceToDelivered.losArrivalSelectTitle'),
                losDepartureSelectLabel: trans('forceToDelivered.losDepartureSelectTitle'),
                cancelText: trans('forceToDelivered.cancel'),
                confirmText: trans('forceToDelivered.confirm'),
                modalTitle: trans('forceToDelivered.lable'),
                dateNotEmptyValidationMsg: trans('stops.error.dateNotEmptyValidation'),
                dateGreaterThanValidationMsg: trans('stops.error.dateGreaterThanValidation'),
                dateSequenceValidationMsg: trans('stops.error.dateSequenceValidation'),
                noteTripStatusText: trans('forceToDelivered.noteTripStatusTextReadyToStart'),
                noteInTransitStatusText: trans('forceToDelivered.noteInTransitStatusText'),
                noteDeleveredStatusText: trans('forceToDelivered.noteDeleveredStatusText'),
            };
        }
        return {
            arrivalLabel: trans('forceToDelivered.arrivalTitle'),
            departLabel: trans('forceToDelivered.departTitle'),
            losSelectLabel: trans('forceToDelivered.losSelectTitle'),
            cancelText: trans('forceToDelivered.cancel'),
            confirmText: trans('forceToDelivered.confirm'),
            modalTitle: trans('forceToDelivered.lableCa'),
        };
    }, [trans, featureFlags?.showUpdateTimeline]);
    const loadDetails = useMemo(
        () => (sLoadDetailsResponse ? getLoadDetailsCA(sLoadDetailsResponse, pStaticData, featureFlags) : null),
        [sLoadDetailsResponse, pStaticData, trans],
    );
    const updatePlanStatusToDeliver = (payload) => {
        updateTrackingPlanApi(
            payload,
            () => {
                pSuccess();
            },
            (err) => {
                pError(err);
            },
        );
    };
    const updatePlanStatusToDeliverCa = (payload) => {
        updateInTransitPlanStatus(
            payload,
            () => {
                pSuccess();
            },
            (err) => {
                pError(err);
            },
        );
    };
    const markLoadAsDelivered = (res) => {
        const showUpdateTimeline = featureFlags?.showUpdateTimeline;
        if (showUpdateTimeline) {
            const payload = {
                trackingId: pPlanId,
                trackingIdType: 'LOAD',
                stops: res,
            };
            updatePlanStatusToDeliver(formatForceToDeleverPlanRequest(payload));
        } else {
            const payload = {
                trackingIds: [pPlanId],
                trackingIdType: 'LOAD',
                planStatus: 'DELIVERED',
                transits: res,
            };
            updatePlanStatusToDeliverCa(payload);
        }
    };
    return (
        <>
            {pOpenModal && featureFlags?.showUpdateTimeline ? (
                <ForceToDelivered
                    pIsModalOpen={pOpenModal}
                    pOnCloseModal={pOnCloseModal}
                    pOnConfirmation={markLoadAsDelivered}
                    pModelData={loadDetails?.stopSequence?.stops}
                    pLos={sLosEvent || []}
                    pTranslations={forceLoadToDeliverModalTranslations}
                    pArrivalDepartureLosToggle={featureFlags?.showArrivalDepartureLosToggle}
                />
            ) : (
                <ForceToDeliveredCA
                    pIsModalOpen={pOpenModal}
                    pOnCloseModal={pOnCloseModal}
                    pOnConfirmation={markLoadAsDelivered}
                    pModelData={loadDetails?.stopSequence?.stops}
                    pLos={sLosEvent || []}
                    pTranslations={forceLoadToDeliverModalTranslations}
                />
            )}
        </>
    );
};
const propTypes = {
    pOpenModal: PropTypes.bool.isRequired,
    pError: PropTypes.func.isRequired,
    pOnCloseModal: PropTypes.func.isRequired,
    pLoading: PropTypes.func.isRequired,
    pPlanId: PropTypes.string.isRequired,
    pSuccess: PropTypes.func.isRequired,
    pStaticData: PropTypes.shape({}).isRequired,
};
ForceLoadToDeliveredModal.propTypes = propTypes;
export default ForceLoadToDeliveredModal;
