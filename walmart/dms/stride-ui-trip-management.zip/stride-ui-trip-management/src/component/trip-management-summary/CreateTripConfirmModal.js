import React, { useState, useEffect } from 'react';
import PropTypes, { string } from 'prop-types';
import {
    Button,
    Typography,
    Modal,
    ModalContent,
    ModalFooter,
    SegmentGroup,
    Segment,
    TextInput,
} from '@walmart/living-design-sc-ui';
import { confirmFormInitialState } from './DataModels';
import { connectLoads } from '../../Constants';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { makeStyles, Grid } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const useStyles = makeStyles(() => ({
    modalContent: {
        '& .MuiDialog-paperWidthSm': {
            width: '28rem',
        },
        '& .ld-sc-ui-textinput-wrapper': {
            width: '25rem',
        },
        '& .ld-sc-ui-textinput-wrapper .ld-sc-ui-textinput': {
            width: 'auto',
        },
    },
}));
export default function CreateTripConfirmModal(props) {
    const { pIsOpen, pOnClose, pIsAssignTrip, pConnectLoads, pOnSubmit, pShowErrors } = props;
    const trans = localizeLang();
    const classes = useStyles();
    const [sFormValue, setsFormValue] = useState(confirmFormInitialState);
    const onValueChange = (fieldName, val) => {
        if (fieldName === 'connectLoad') {
            const conLoad = connectLoads.find((item) => trans(item.value) === val).id;
            setsFormValue((form = sFormValue) => ({
                ...form,
                [fieldName]: conLoad,
            }));
        } else {
            setsFormValue((form = sFormValue) => ({
                ...form,
                [fieldName]: val,
            }));
        }
    };
    useEffect(() => {
        setsFormValue(confirmFormInitialState);
    }, []);
    return (
        <>
            <Modal isOpen={pIsOpen} variant="fitContent" className={classes.modalContent}>
                <ModalContent variant="info">
                    <Typography variant="subtitle1" align="left" className="font-weight-bold mb-2">
                        {pIsAssignTrip ? trans('title.confirmAssignTrip') : trans('title.confirmTrip')}
                    </Typography>
                    <Typography color="textSecondary" variant="body1">
                        {pIsAssignTrip ? trans('info.confirmAssignTrip') : trans('info.confirmTrip')}
                    </Typography>
                    {pIsAssignTrip && (
                        <>
                            <Grid container className="my-3" spacing={3}>
                                <Grid item className={pIsAssignTrip ? '' : 'mb-5'}>
                                    <SegmentGroup
                                        data-testid="connectLoads"
                                        label={trans('label.connectLoadBy')}
                                        onClick={(_e) => onValueChange('connectLoad', _e.currentTarget.dataset.name)}
                                    >
                                        {pConnectLoads.map((type) => (
                                            <Segment
                                                data-testid={`load${type.id}`}
                                                key={type.id}
                                                isSelected={sFormValue.connectLoad === type.id}
                                            >
                                                {type.value}
                                            </Segment>
                                        ))}
                                    </SegmentGroup>
                                    {pIsAssignTrip && pShowErrors && !sFormValue.connectLoad && (
                                        <Typography
                                            align="left"
                                            color="error"
                                            gutterBottom
                                            variant="caption"
                                            data-testid="statusError"
                                        >
                                            {trans('error.requiredField')}
                                        </Typography>
                                    )}
                                </Grid>
                            </Grid>
                            <Grid container className="my-3" spacing={3}>
                                <Grid item xs={6}>
                                    <TextInput
                                        id="transitTime"
                                        key="transitTime"
                                        data-testid="transitTime"
                                        label={trans('label.transitTime')}
                                        value={sFormValue.transitTime}
                                        onChange={(e) => onValueChange('transitTime', e.target.value)}
                                        className="mr-3"
                                        errorText={
                                            pShowErrors && !sFormValue.transitTime ? trans('error.requiredField') : ''
                                        }
                                        variant={pShowErrors && !sFormValue.transitTime ? 'error' : 'default'}
                                    />
                                </Grid>
                                <Grid item xs={6}>
                                    <TextInput
                                        id="distance"
                                        key="distance"
                                        data-testid="distance"
                                        label={trans('label.distance')}
                                        value={sFormValue.distance}
                                        onChange={(e) => onValueChange('distance', e.target.value)}
                                        errorText={
                                            pShowErrors && !sFormValue.distance ? trans('error.requiredField') : ''
                                        }
                                        variant={pShowErrors && !sFormValue.distance ? 'error' : 'default'}
                                    />
                                </Grid>
                            </Grid>
                        </>
                    )}
                </ModalContent>
                <ModalFooter>
                    <Button
                        onClick={() => {
                            pOnClose(false);
                        }}
                        variant="text-only"
                        data-testid="cancelBtn"
                    >
                        {trans('button.cancel')}
                    </Button>
                    <Button
                        onClick={() => {
                            pOnSubmit(true, sFormValue);
                        }}
                        variant="primary"
                        data-testid="confirmBtn"
                    >
                        {trans('button.createTrip')}
                    </Button>
                </ModalFooter>
            </Modal>
        </>
    );
}
CreateTripConfirmModal.propTypes = {
    pIsOpen: PropTypes.bool.isRequired,
    pOnClose: PropTypes.func.isRequired,
    pIsAssignTrip: PropTypes.bool,
    pConnectLoads: PropTypes.arrayOf(
        PropTypes.shape({
            id: string,
            value: string,
        }),
    ).isRequired,
    pOnSubmit: PropTypes.func.isRequired,
    pShowErrors: PropTypes.bool,
};
CreateTripConfirmModal.defaultProps = {
    pIsAssignTrip: false,
    pShowErrors: false,
};
