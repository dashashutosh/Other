import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
    Typography,
    Calendar,
    TextInput,
    Scope,
    CalendarRange,
    SingleSelect,
    MultiSelect,
    Button,
    SegmentGroup,
    Segment,
    RemoveIcon,
    ModalFooter,
    ModalHeader,
    DrawerComponent,
} from '@walmart/living-design-sc-ui';
import { InlineAlert, MarketCodeEnum } from '@walmart/stride-ui-commons';
import PropTypes from 'prop-types';
import { PLAN_TABLE_QUERY_ACTIONS_ENUM } from '../../utils/actions/PlanTableQueryActions';
import { shouldDisableLocationFields } from '../../utils/ui-mappers/PlanSearchMappers';
import { QueryStateType } from '../../utils/types/PlanSearchTypes';
import { plankeyRegex, FILTER_TYPES, ALLOWED_FILTERS, regexAlphaNumComma } from '../../Constants';
import PhaseTypesEnum from '../../utils/enums/PhaseTypesEnum';
import TripSharedService from '../../service/TripSharedService';
import { getPlanStatusList, getValidationError } from '../../utils/CommonUtils';
import {
    getAppliedFiltersCount,
    showOriginSection,
    showDestinationSection,
    showLoadSection,
    showServiceSection,
    showCarrierSection,
    showPlanSection,
    hasmatTransLabels,
    isLocationIdDisabled,
} from './DataModels';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { AppUtils } from '@gscope-mfe/app-bridge';
const { Grid } = MaterialUiCore,
    { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const styles = makeStyles({
    drawer: {
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        maxWidth: '75vw',
    },
    selectFieldWidth: {
        minWidth: '100% !important',
    },
    searchBtn: {
        width: '10rem',
        justifyContent: 'center',
    },
    searchWrapper: {
        '& .ld-sc-ui-scope': {
            padding: 0,
        },
        '& .ld-sc-ui-scope .ld-sc-ui-select .ld-sc-ui-select-label': {
            padding: 0,
        },
    },
});

/**
 *
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
const PlanSearch = (props) => {
    const { pIsOpen, pOnClose, pStaticData, dispatch, queryState } = props;
    const trans = localizeLang();
    const { currentMarket, prefLang } = AppUtils.get();
    const classes = styles();
    const [sFilterCount, setsFilterCount] = useState(0);
    const [sFormValue, setSFormValue] = useState({});

    // eslint-disable-next-line no-unused-vars
    const [sIsFormValid, setsIsFormValid] = useState(true);
    const [sStatusList, setsStatusList] = useState([]);
    const [allowedFilters, setAllowedFilters] = useState([]);
    const getStatus = (sType) => {
        setsStatusList(getPlanStatusList(sType, pStaticData?.planStatus));
    };
    const onValueChange = (field, value) => {
        setSFormValue((formValue) => ({
            ...formValue,
            [field]: value,
        }));
    };

    // const onHazmatChange = (e) => {
    //   setsSelectedStatus(e.currentTarget.dataset.name);
    // };

    const validateForm = () => {
        const formValid = true;
        // if (pFormValue && pFormValue.planId && !pFormValue.planId.match(plankeyRegex)) {
        //   formValid = false;
        // }
        setsIsFormValid(formValid);
    };
    const onSearch = () => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_FILTER,
            filter: sFormValue,
        });
        pOnClose();
    };
    const isInvalidDateRange = () => sFormValue.fromDate && !sFormValue.tillDate;
    const setDateRange = (dateRange) => {
        onValueChange('fromDate', dateRange[0]);
        onValueChange('tillDate', dateRange[1]);
    };
    const clearDateRange = () => {
        if (sFormValue.fromDate) onValueChange('fromDate', '');
        if (sFormValue.tillDate) onValueChange('tillDate', '');
    };
    useEffect(() => {
        if (currentMarket) {
            setAllowedFilters(ALLOWED_FILTERS[currentMarket]);
        }
    }, [currentMarket]);
    useEffect(() => {
        setSFormValue(queryState.filter);
    }, [queryState.filter]);
    useEffect(() => {
        const appliedFilters = getAppliedFiltersCount(sFormValue);
        if (sFilterCount !== appliedFilters) {
            setsFilterCount(appliedFilters);
        }
        validateForm();
    }, [sFormValue]);
    useEffect(() => {
        getStatus(queryState.activeTabIndex);
    }, [queryState.activeTabIndex]);

    // const getDateField = () => {
    //   if (pFormValue.periodType === 'AFTER') {
    //     return 'after';
    //   } if (pFormValue.periodType === 'BEFORE') {
    //     return 'before';
    //   }
    //   return 'on';
    // };

    const hazmatList = useMemo(() => hasmatTransLabels(trans), [prefLang.current]);
    const { disableOriginFields, disableDestinationFields } = useMemo(
        () => shouldDisableLocationFields(queryState.profile, currentMarket),
        [queryState.profile],
    );
    const featureFlags = useMemo(() => TripSharedService.getFeatureFlags() || {}, []);
    const disableLocationId = useCallback((location) => isLocationIdDisabled(location, sFormValue), [sFormValue]);
    const onClearFilter = () => {
        dispatch({
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_FILTER,
        });
    };
    const handleClose = () => pOnClose(false);
    return (
        <>
            <DrawerComponent open={pIsOpen} position="right" className={classes.drawer} handleClose={handleClose}>
                <ModalHeader onClose={handleClose}>{trans('title.filter')}</ModalHeader>
                <div className="overflow-auto st-ui-px-4 st-ui-py-6">
                    <Grid container spacing={2} className={classes.searchWrapper}>
                        {disableDestinationFields || disableOriginFields ? (
                            <Grid container item spacing={2}>
                                <InlineAlert
                                    pVariant="warning"
                                    pMessage={trans('error.locationPreferencePresentInProfile')}
                                />
                            </Grid>
                        ) : null}
                        <Grid item xs={2}>
                            <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                {trans('subTitle.dates')}
                            </Typography>
                        </Grid>
                        <Grid container item spacing={2}>
                            {allowedFilters && allowedFilters.includes(FILTER_TYPES.DATE_TYPE) && (
                                <Grid item xs={3}>
                                    <Scope
                                        variant="single-select"
                                        label={trans('label.dateType')}
                                        list={pStaticData.dateTypes}
                                        singleSelectValue={sFormValue.dateType}
                                        onChangeSingleSelectValue={(e) =>
                                            onValueChange('dateType', e.target.getAttribute('value'))
                                        }
                                        data-testid="dateType"
                                    />
                                </Grid>
                            )}
                            {allowedFilters && allowedFilters.includes(FILTER_TYPES.PERIOD_TYPE) && (
                                <Grid item xs={3}>
                                    <Scope
                                        variant="single-select"
                                        label={trans('label.periodType')}
                                        list={pStaticData.periodTypes}
                                        singleSelectValue={sFormValue.periodType}
                                        onChangeSingleSelectValue={(e) =>
                                            onValueChange('periodType', e.target.getAttribute('value'))
                                        }
                                        data-testid="periodType"
                                    />
                                </Grid>
                            )}
                            {allowedFilters && allowedFilters.includes(FILTER_TYPES.DATE_TYPE) && (
                                <Grid item xs={6}>
                                    {sFormValue.periodType === 'IN_BETWEEN' ? (
                                        <CalendarRange
                                            id="date-range"
                                            key="dateRange"
                                            endDateLabel={trans('label.tillDate')}
                                            startDateLabel={trans('label.fromDate')}
                                            endDate={sFormValue.tillDate ? new Date(sFormValue.tillDate) : ''}
                                            startDate={sFormValue.fromDate ? new Date(sFormValue.fromDate) : ''}
                                            onChange={(dateRange) => setDateRange(dateRange)}
                                            variant={isInvalidDateRange() ? 'error' : 'default'}
                                            errorText={isInvalidDateRange() ? trans('dateRangeError') : ''}
                                            onClear={() => clearDateRange()}
                                            className="w-100"
                                            data-testid="dateRange"
                                        />
                                    ) : (
                                        <Calendar
                                            label={trans('label.date')}
                                            onChange={(dateValue) => onValueChange('date', dateValue)}
                                            variant="default"
                                            date={sFormValue.date}
                                            onClear={() => onValueChange('date', '')}
                                            showTimeInput={false}
                                            className="ml-3"
                                            data-testid="date"
                                        />
                                    )}
                                </Grid>
                            )}
                        </Grid>

                        {showPlanSection(allowedFilters) && (
                            <>
                                {allowedFilters && allowedFilters.includes(FILTER_TYPES.PLAN_TYPE) && (
                                    <Grid item xs={2}>
                                        <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                            {trans('subTitle.plan')}
                                        </Typography>
                                    </Grid>
                                )}
                                <Grid container item spacing={3}>
                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.PLAN_TYPE) && (
                                        <Grid item xs={3}>
                                            <SingleSelect
                                                id="trip-plan-id"
                                                key="planType"
                                                label={trans('label.planType')}
                                                options={pStaticData.planTypes}
                                                className={classes.selectFieldWidth}
                                                value={sFormValue.planType}
                                                errorText={
                                                    sFormValue.planType && !sFormValue.status.length
                                                        ? trans('onlyPlanTypeError')
                                                        : undefined
                                                }
                                                onChange={(_e) =>
                                                    onValueChange('planType', _e.target.getAttribute('value'))
                                                }
                                                data-testid="planType"
                                            />
                                        </Grid>
                                    )}
                                    {allowedFilters &&
                                        allowedFilters.includes(FILTER_TYPES.STATUS) &&
                                        queryState.activeTabIndex !== PhaseTypesEnum.DISPATCH_PENDING.index &&
                                        queryState.activeTabIndex !== PhaseTypesEnum.PLANNING.index && (
                                            <Grid item xs={3}>
                                                <MultiSelect
                                                    id="status"
                                                    key="status"
                                                    label={trans('subTitle.status')}
                                                    options={sStatusList}
                                                    values={sFormValue.status}
                                                    onComplete={(_e, values) => onValueChange('status', values)}
                                                    displaySelectAll
                                                    className={classes.selectFieldWidth}
                                                    completeText={trans('button.complete')}
                                                    cancelText={trans('button.cancel')}
                                                    errorText={
                                                        currentMarket === MarketCodeEnum.CANADA.code
                                                            ? ''
                                                            : trans(getValidationError(sFormValue, sFilterCount))
                                                    }
                                                    data-testid="status"
                                                />
                                            </Grid>
                                        )}
                                </Grid>
                            </>
                        )}

                        {showOriginSection(allowedFilters) && (
                            <>
                                <Grid item xs={2}>
                                    <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                        {trans('subTitle.origin')}
                                    </Typography>
                                </Grid>
                                <Grid container item spacing={2}>
                                    {featureFlags?.enableLocationIdFilter && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="originLocId"
                                                key="originLocId"
                                                label={trans('label.locationID')}
                                                className="w-100"
                                                value={sFormValue.originLocId}
                                                onChange={(e) => onValueChange('originLocId', e.target.value)}
                                                data-testid="originLocId"
                                                disabled={disableLocationId('origin') || disableOriginFields}
                                            />
                                        </Grid>
                                    )}
                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.ORIGIN_TYPE) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="originType"
                                                key="originType"
                                                label={trans('label.originType')}
                                                options={pStaticData.locationTypes}
                                                values={sFormValue.originType}
                                                onComplete={(_e, values) => onValueChange('originType', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="originType"
                                                color={
                                                    disableOriginFields || sFormValue.originLocId
                                                        ? 'disabled'
                                                        : 'default'
                                                }
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.ORIGIN_CITY) && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="originCity"
                                                key="originCity"
                                                label={trans('label.city')}
                                                className="w-100"
                                                value={sFormValue.originCity}
                                                onChange={(e) => onValueChange('originCity', e.target.value)}
                                                data-testid="originCity"
                                                disabled={disableOriginFields || sFormValue.originLocId}
                                            />
                                        </Grid>
                                    )}
                                    <Grid item xs={featureFlags?.enableLocationIdFilter ? 3 : 6} />

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.ORIGIN_PROVINCE) && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="originProvince"
                                                key="originProvince"
                                                label={trans('label.province')}
                                                className="w-100"
                                                value={sFormValue.originProvince}
                                                onChange={(e) => onValueChange('originProvince', e.target.value)}
                                                data-testid="originProvince"
                                                disabled={disableOriginFields || sFormValue.originLocId}
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.ORIGIN_POSTAL_CODE) && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="originPostalCode"
                                                key="originPostalCode"
                                                label={trans('label.postalCode')}
                                                className="w-100"
                                                value={sFormValue.originPostalCode}
                                                onChange={(e) => onValueChange('originPostalCode', e.target.value)}
                                                data-testid="originPostalCode"
                                                disabled={disableOriginFields || sFormValue.originLocId}
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.ORIGIN_COUNTRY) && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="originCountry"
                                                key="originCountry"
                                                label={trans('label.country')}
                                                className="w-100"
                                                value={sFormValue.originCountry}
                                                onChange={(e) => onValueChange('originCountry', e.target.value)}
                                                data-testid="originCountry"
                                                disabled={disableOriginFields || sFormValue.originLocId}
                                            />
                                        </Grid>
                                    )}
                                </Grid>
                            </>
                        )}

                        {showDestinationSection(allowedFilters) && (
                            <>
                                <Grid item xs={2}>
                                    <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                        {trans('subTitle.destination')}
                                    </Typography>
                                </Grid>
                                <Grid container item spacing={2}>
                                    {featureFlags?.enableLocationIdFilter && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="destinationLocId"
                                                key="destinationLocId"
                                                label={trans('label.locationID')}
                                                className="w-100"
                                                value={sFormValue.destinationLocId}
                                                onChange={(e) => onValueChange('destinationLocId', e.target.value)}
                                                data-testid="destinationLocId"
                                                disabled={disableLocationId('destination') || disableDestinationFields}
                                            />
                                        </Grid>
                                    )}
                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.DESTINATION_TYPE) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="destinationType"
                                                key="destinationType"
                                                label={trans('label.destinationType')}
                                                options={pStaticData.locationTypes}
                                                values={sFormValue.destinationType}
                                                onComplete={(_e, values) => onValueChange('destinationType', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="destinationType"
                                                color={
                                                    disableDestinationFields || sFormValue.destinationLocId
                                                        ? 'disabled'
                                                        : 'default'
                                                }
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.DESTINATION_CITY) && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="destinationCity"
                                                key="destinationCity"
                                                label={trans('label.city')}
                                                className="w-100"
                                                value={sFormValue.destinationCity}
                                                onChange={(e) => onValueChange('destinationCity', e.target.value)}
                                                data-testid="destinationCity"
                                                disabled={disableDestinationFields || sFormValue.destinationLocId}
                                            />
                                        </Grid>
                                    )}

                                    <Grid item xs={featureFlags?.enableLocationIdFilter ? 3 : 6} />

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.DESTINATION_PROVINCE) && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="destinationProvince"
                                                key="destinationProvince"
                                                label={trans('label.province')}
                                                className="w-100"
                                                value={sFormValue.destinationProvince}
                                                onChange={(e) => onValueChange('destinationProvince', e.target.value)}
                                                data-testid="destinationProvince"
                                                disabled={disableDestinationFields || sFormValue.destinationLocId}
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.DESTINATION_POSTAL_CODE) && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="destinationPostalCode"
                                                key="destinationPostalCode"
                                                label={trans('label.postalCode')}
                                                className="w-100"
                                                value={sFormValue.destinationPostalCode}
                                                onChange={(e) => onValueChange('destinationPostalCode', e.target.value)}
                                                data-testid="destinationPostalCode"
                                                disabled={disableDestinationFields || sFormValue.destinationLocId}
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.DESTINATION_COUNTRY) && (
                                        <Grid item xs={3}>
                                            <TextInput
                                                id="destinationCountry"
                                                key="destinationCountry"
                                                label={trans('label.country')}
                                                className="w-100"
                                                value={sFormValue.destinationCountry}
                                                onChange={(e) => onValueChange('destinationCountry', e.target.value)}
                                                data-testid="destinationCountry"
                                                disabled={disableDestinationFields || sFormValue.destinationLocId}
                                            />
                                        </Grid>
                                    )}
                                </Grid>
                            </>
                        )}

                        {showLoadSection(allowedFilters) && (
                            <>
                                <Grid item xs={2}>
                                    <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                        {trans('subTitle.load')}
                                    </Typography>
                                </Grid>
                                <Grid container item spacing={2}>
                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.LOAD_OWNER) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="loadOwner"
                                                key="loadOwner"
                                                label={trans('label.loadOwner')}
                                                options={pStaticData.loadOwners}
                                                values={sFormValue.loadOwner}
                                                onComplete={(_e, values) => onValueChange('loadOwner', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="loadOwner"
                                            />
                                        </Grid>
                                    )}
                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.PRIORITY) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="priority"
                                                key="priority"
                                                label={trans('label.priority')}
                                                options={pStaticData.priorities}
                                                values={sFormValue.priority}
                                                onComplete={(_e, values) => onValueChange('priority', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="priority"
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.TEMPERATURE_CONTROL) && (
                                        <Grid item xs={3}>
                                            <SingleSelect
                                                id="temperatureControl"
                                                key="temperatureControl"
                                                label={trans('label.temperatureControl')}
                                                options={pStaticData.temperatureControls}
                                                className={classes.selectFieldWidth}
                                                value={sFormValue.temperatureControl}
                                                onChange={(_e) =>
                                                    onValueChange('temperatureControl', _e.target.getAttribute('value'))
                                                }
                                                data-testid="temperatureControl"
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.HAZMAT) && (
                                        <Grid item xs={3}>
                                            <SegmentGroup
                                                data-testid="hazmat"
                                                label={trans('label.hazmat')}
                                                onClick={(e) =>
                                                    onValueChange(
                                                        'hazmat',
                                                        e.currentTarget.dataset.name === hazmatList[0],
                                                    )
                                                }
                                            >
                                                {hazmatList.map((type, index) => (
                                                    <Segment
                                                        key={type}
                                                        isSelected={
                                                            (index === 0 && sFormValue.hazmat === true) ||
                                                            (index === 1 && sFormValue.hazmat === false)
                                                        }
                                                    >
                                                        {type}
                                                    </Segment>
                                                ))}
                                            </SegmentGroup>
                                        </Grid>
                                    )}

                                    {allowedFilters &&
                                        allowedFilters.includes(FILTER_TYPES.EQUIPMENT_CONFIGURATION_ID) && (
                                            <Grid item xs={!featureFlags?.removeEquipmentFromFilter ? 6 : 3}>
                                                <MultiSelect
                                                    id="equipmentConfigurationId"
                                                    key="equipmentConfigurationId"
                                                    label={trans('label.equipmentConfigurationId')}
                                                    options={pStaticData.equipmentConfigurationIds}
                                                    values={sFormValue.equipmentConfigurationId}
                                                    onComplete={(_e, values) =>
                                                        onValueChange('equipmentConfigurationId', values)
                                                    }
                                                    displaySelectAll
                                                    className={classes.selectFieldWidth}
                                                    completeText={trans('button.complete')}
                                                    cancelText={trans('button.cancel')}
                                                    data-testid="equipmentConfigurationId"
                                                />
                                            </Grid>
                                        )}

                                    {allowedFilters &&
                                        allowedFilters.includes(FILTER_TYPES.EQUIPMENT_ID) &&
                                        !featureFlags?.removeEquipmentFromFilter && (
                                            <Grid item xs={6}>
                                                <TextInput
                                                    id="equipmentId"
                                                    key="equipmentId"
                                                    label={trans('label.equipmentId')}
                                                    className="w-100"
                                                    value={sFormValue.equipmentId}
                                                    onChange={(e) => onValueChange('equipmentId', e.target.value)}
                                                    data-testid="equipmentId"
                                                />
                                            </Grid>
                                        )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.IBOB) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="ibob"
                                                key="ibob"
                                                label={trans('label.ibob')}
                                                options={pStaticData.ibobs}
                                                values={sFormValue.ibob}
                                                onComplete={(_e, values) => onValueChange('ibob', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="ibob"
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.PROGRAM) && (
                                        <Grid item xs={3}>
                                            <SingleSelect
                                                id="program"
                                                key="program"
                                                label={trans('label.program')}
                                                options={pStaticData.programmeTypes}
                                                className={classes.selectFieldWidth}
                                                value={sFormValue.program}
                                                onChange={(_e) =>
                                                    onValueChange('program', _e.target.getAttribute('value'))
                                                }
                                                data-testid="program"
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.CHANNEL) && (
                                        <Grid item xs={3}>
                                            <SingleSelect
                                                id="channel"
                                                key="channel"
                                                label={trans('label.channel')}
                                                options={pStaticData.channels}
                                                className={classes.selectFieldWidth}
                                                value={sFormValue.channel}
                                                onChange={(_e) =>
                                                    onValueChange('channel', _e.target.getAttribute('value'))
                                                }
                                                data-testid="channel"
                                            />
                                        </Grid>
                                    )}
                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.LOAD_ID) && (
                                        <Grid item xs={6}>
                                            <TextInput
                                                id="loadId"
                                                key="loadId"
                                                label={trans('label.loadId')}
                                                className="w-100"
                                                value={sFormValue.loadId}
                                                onChange={(e) => onValueChange('loadId', e.target.value)}
                                                endIcon={sFormValue.loadId && <RemoveIcon size="small" />}
                                                endIconClick={() => onValueChange('loadId', '')}
                                                helperText={
                                                    sFormValue.loadId.match(plankeyRegex)
                                                        ? trans('multiInputHelperText')
                                                        : ''
                                                }
                                                variant={sFormValue.loadId.match(plankeyRegex) ? 'default' : 'error'}
                                                errorText={
                                                    sFormValue.loadId.match(plankeyRegex) ? '' : trans('loadIdError')
                                                }
                                                data-testid="loadId"
                                            />
                                        </Grid>
                                    )}
                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.TO_ID) && (
                                        <Grid item xs={6}>
                                            <TextInput
                                                id="toId"
                                                key="toId"
                                                label={trans('label.toId')}
                                                className="w-100"
                                                value={sFormValue.toId}
                                                onChange={(e) => onValueChange('toId', e.target.value)}
                                                endIcon={sFormValue.toId && <RemoveIcon size="small" />}
                                                endIconClick={() => onValueChange('toId', '')}
                                                helperText={
                                                    sFormValue.toId.match(plankeyRegex)
                                                        ? trans('multiInputHelperText')
                                                        : ''
                                                }
                                                variant={sFormValue.toId.match(plankeyRegex) ? 'default' : 'error'}
                                                errorText={
                                                    sFormValue.toId.match(plankeyRegex) ? '' : trans('loadIdError')
                                                }
                                                data-testid="toId"
                                            />
                                        </Grid>
                                    )}
                                </Grid>
                            </>
                        )}

                        {showServiceSection(allowedFilters) && (
                            <>
                                <Grid item xs={2}>
                                    <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                        {trans('subTitle.serviceDetails')}
                                    </Typography>
                                </Grid>
                                <Grid container item spacing={2}>
                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.SERVICE_CLASS) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="serviceClass"
                                                key="serviceClass"
                                                label={trans('label.serviceClass')}
                                                options={pStaticData.serviceClasses}
                                                values={sFormValue.serviceClass}
                                                onComplete={(_e, values) => onValueChange('serviceClass', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="serviceClass"
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.SERVICE_MODE) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="serviceMode"
                                                key="serviceMode"
                                                label={trans('label.serviceMode')}
                                                options={pStaticData.serviceModes}
                                                values={sFormValue.mode}
                                                onComplete={(_e, values) => onValueChange('mode', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="serviceMode"
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.SERVICE_LEVEL) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="serviceLevel"
                                                key="serviceLevel"
                                                label={trans('label.serviceLevel')}
                                                options={pStaticData.serviceLevels}
                                                values={sFormValue.serviceLevel}
                                                onComplete={(_e, values) => onValueChange('serviceLevel', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="serviceLevel"
                                            />
                                        </Grid>
                                    )}

                                    {allowedFilters && allowedFilters.includes(FILTER_TYPES.SERVICE_TYPE) && (
                                        <Grid item xs={3}>
                                            <MultiSelect
                                                id="serviceType"
                                                key="serviceType"
                                                label={trans('label.serviceType')}
                                                options={pStaticData.serviceTypes}
                                                values={sFormValue.serviceType}
                                                onComplete={(_e, values) => onValueChange('serviceType', values)}
                                                displaySelectAll
                                                className={classes.selectFieldWidth}
                                                completeText={trans('button.complete')}
                                                cancelText={trans('button.cancel')}
                                                data-testid="serviceType"
                                            />
                                        </Grid>
                                    )}
                                </Grid>
                            </>
                        )}

                        {showCarrierSection(allowedFilters) &&
                            queryState.activeTabIndex !== PhaseTypesEnum.PLANNING.index && (
                                <>
                                    <Grid item xs={2}>
                                        <Typography gutterBottom="true" align="left" className="font-weight-bold">
                                            {trans('subTitle.carrier')}
                                        </Typography>
                                    </Grid>
                                    <Grid container item spacing={2}>
                                        {allowedFilters && allowedFilters.includes(FILTER_TYPES.CARRIER_ID) && (
                                            <Grid item xs={6}>
                                                <TextInput
                                                    id="trip-carrier-id"
                                                    key="carrierId"
                                                    label={trans('label.carrierId')}
                                                    className="w-100"
                                                    value={sFormValue.carrierId}
                                                    onChange={(e) => onValueChange('carrierId', e.target.value)}
                                                    helperText={
                                                        sFormValue.carrierId.match(plankeyRegex)
                                                            ? trans('multiInputHelperText')
                                                            : ''
                                                    }
                                                    variant={
                                                        sFormValue.carrierId.match(plankeyRegex) ? 'default' : 'error'
                                                    }
                                                    errorText={
                                                        sFormValue.carrierId.match(plankeyRegex)
                                                            ? ''
                                                            : trans('multiInputError')
                                                    }
                                                    data-testid="carrierId"
                                                />
                                            </Grid>
                                        )}
                                        {allowedFilters && allowedFilters.includes(FILTER_TYPES.SCAC_CODE) && (
                                            <Grid item xs={6}>
                                                <TextInput
                                                    id="scacCode"
                                                    key="scacCode"
                                                    label={trans('label.scacCode')}
                                                    className="w-100"
                                                    value={sFormValue.scacCode}
                                                    onChange={(e) => onValueChange('scacCode', e.target.value)}
                                                    helperText={
                                                        sFormValue.scacCode.match(regexAlphaNumComma)
                                                            ? trans('multiInputHelperText')
                                                            : ''
                                                    }
                                                    variant={
                                                        sFormValue.scacCode.match(regexAlphaNumComma)
                                                            ? 'default'
                                                            : 'error'
                                                    }
                                                    errorText={
                                                        sFormValue.scacCode.match(regexAlphaNumComma)
                                                            ? ''
                                                            : trans('multiInputScacError')
                                                    }
                                                    data-testid="scacCode"
                                                />
                                            </Grid>
                                        )}
                                    </Grid>
                                </>
                            )}
                    </Grid>
                </div>
                <ModalFooter>
                    <Button
                        onClick={() => {
                            onClearFilter();
                        }}
                        variant="text-only"
                        data-testid="clearAllFilters"
                    >
                        {trans('button.clearAllFilters')}
                    </Button>
                    <Button
                        onClick={() => {
                            onSearch(true, 1);
                        }}
                        variant="primary"
                        data-testid="confirmBtn"
                    >
                        {trans('button.applyFilter')}
                    </Button>
                </ModalFooter>
            </DrawerComponent>
        </>
    );
};
const selectOption = PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    value: PropTypes.string.isRequired,
});
const propTypes = {
    pIsOpen: PropTypes.bool.isRequired,
    pOnClose: PropTypes.func.isRequired,
    pStaticData: PropTypes.shape({
        locationTypes: PropTypes.arrayOf(selectOption).isRequired,
        carriers: PropTypes.arrayOf(selectOption).isRequired,
        planTypes: PropTypes.arrayOf(selectOption.isRequired),
        planStatus: PropTypes.arrayOf(selectOption).isRequired,
        dateTypes: PropTypes.arrayOf(selectOption).isRequired,
        periodTypes: PropTypes.arrayOf(selectOption).isRequired,
        // locations: PropTypes.arrayOf(selectOption.isRequired),
        // loadOwners: PropTypes.arrayOf(selectOption.isRequired),
        // priorities: PropTypes.arrayOf(selectOption.isRequired),
        // channels: PropTypes.arrayOf(selectOption.isRequired),
        // programs: PropTypes.arrayOf(selectOption.isRequired),
        ibobs: PropTypes.arrayOf(selectOption.isRequired),
        equipmentConfigurationIds: PropTypes.arrayOf(selectOption.isRequired),
        serviceClasses: PropTypes.arrayOf(selectOption.isRequired),
        serviceModes: PropTypes.arrayOf(selectOption.isRequired),
        serviceLevels: PropTypes.arrayOf(selectOption.isRequired),
        serviceTypes: PropTypes.arrayOf(selectOption.isRequired),
        programmeTypes: PropTypes.arrayOf(selectOption.isRequired),
        temperatureControls: PropTypes.arrayOf(selectOption.isRequired),
        loadOwners: PropTypes.arrayOf(selectOption.isRequired),
        priorities: PropTypes.arrayOf(selectOption.isRequired),
        channels: PropTypes.arrayOf(selectOption.isRequired),
    }).isRequired,
    dispatch: PropTypes.func.isRequired,
    queryState: QueryStateType.isRequired,
};
PlanSearch.propTypes = propTypes;
export default PlanSearch;
