import React, { useEffect, useMemo, useState, useRef } from 'react';
import PropTypes, { string } from 'prop-types';
import {
    useAPI,
    WorkloadAssignment,
    CarrierSelectionModal,
    getIsBillOfLadingFieldDisabled,
} from '@walmart/stride-ui-commons';
import { TripAPI } from '../../service/TripAPI';
import {
    processCarriersResponse,
    processDriversResponse,
    processEquipmentsResponse,
    getEquipmentDriverRequestPayload,
    getDriverValidateRequestPayload,
    getTractorTruckValidateRequestPayload,
    getTrailerValidateRequestPayload,
    initialWarnings,
    getReqPayloadCarrierTariff,
    getWorkloadAssignmentLabels,
    getCALabels,
    getTrailerAssignmentTypes,
    getEquipmentTypes,
    getEquipmentsOfSelectedCarrier,
    getWarningMessage,
    getFormattedEquipmentAPIValidationError,
    getTrailerErrorList,
    getModeLabel,
} from './DataModels';
import { TRIP_MODE, getPageStaticDataRequest } from '../../Constants';
import TripSharedService from '../../service/TripSharedService';
import { getTransformedCarrierList } from '../../service/TripMapper';
import { getErrorText } from '../../utils/CommonUtils';
/**
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;
const WorkloadAssignmentModal = ({ pOnClose, pOnConfirmAssign, pLoads, pWorkloadData, pTrip }) => {
    const { currentMarket, prefLang, userInfo, loading, setloading } = AppUtils.get();
    const trans = localizeLang();
    const [sCarriers, setsCarriers] = useState([]);
    const [sDriverList, setsDriverList] = useState({});
    const [sEquipments, setsEquipments] = useState({});
    const [sSelectedCarrier, setsSelectedCarrier] = useState(null);
    const [sCarrierCodes, setsCarrierCodes] = useState([]);
    const [sError, setsError] = useState(false);
    // const [sIsDataInvalid, setsIsDataInvalid] = useState(false);
    const [sSelectedDriver, setsSelectedDriver] = useState(null);
    const [sSelectedEquipment, setsSelectedEquipment] = useState(null);
    const [sSelectedTrailer, setsSelectedTrailer] = useState(null);
    const [sCarrierInfo, setsCarrierInfo] = useState(null);
    const [sEquipmentInfo, setsEquipmentInfo] = useState(null);
    const [sTrailerInfo, setsTrailerInfo] = useState([]);
    const [sWarningMessage, setsWarningMessage] = useState(initialWarnings);
    // const [sLoadInfo, setsLoadInfo] = useState([]);
    // const [sFormData, setsFormData] = useState({});
    const loadTrailerMap = useRef({});
    const [sSelectedEquipmentType, setsSelectedEquipmentType] = useState(null);
    const [sCarrierList, setsCarrierList] = useState([]);
    const featureFlags = TripSharedService.getFeatureFlags();
    const pageLoadSetting = TripSharedService.getPageLoadSettings();
    const { callAPI: fetchCarrierData, loading: fetchCarrierDataLoading } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).getCarrierList,
    );
    const { callAPI: fetchPageLoadData, ...pageLoadDataResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName).getStaticData,
    );
    const { callAPI: getEquipmentDrivers, ...equipmentDriversListResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName).getDriverEqup,
    );
    const { callAPI: fetchValidateSelectedEquipment, ...validateEquipmentResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName).validateEquipment,
    );
    const { callAPI: fetchValidateSelectedTariler, ...validateEquipmentTrailerResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName).validateEquipment,
    );
    const { callAPI: validateSelectedDriver, ...validateDriverResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName).validateDriver,
    );

    // const { callAPI: validateEquipment, ...validateEquipmentResponse } = useAPI(
    //   WorkloadApiInstance.validateEquipment,
    // );

    const labels = useMemo(() => getWorkloadAssignmentLabels(featureFlags, trans), [prefLang.current]);
    const caLabels = useMemo(() => getCALabels(trans), [prefLang.current]);
    const billOfLadingConfigs = useMemo(() => ({
        enableDisplayField: featureFlags?.enableBillOfLading,
        disableInputField: getIsBillOfLadingFieldDisabled(pTrip?.planStatus?.name),
    }));
    const trailerAssignmentTypes = useMemo(() => getTrailerAssignmentTypes(trans), [prefLang.current]);
    const equipmentTypes = useMemo(() => getEquipmentTypes(featureFlags, trans), [prefLang.current]);
    const equipmentsOfSelectedCarrier = useMemo(
        () => getEquipmentsOfSelectedCarrier(sEquipments, sSelectedCarrier, featureFlags?.enableNewEquipmentTypes),
        [sSelectedCarrier, sEquipments, featureFlags?.enableNewEquipmentTypes],
    );
    const warnings = useMemo(() => getWarningMessage(sWarningMessage), [sWarningMessage]);
    const carrierSelectionProps = useMemo(() => {
        const props = {};
        if (featureFlags?.enableMultiLoadAssignment && pWorkloadData?.loadIds?.length > 1) {
            props.pDisabledSelection = {
                [caLabels.recommended]: true,
            };
        }
        return props;
    }, [featureFlags, pWorkloadData]);
    const setResourceValidateWarningMessage = (messages, entity) => {
        let warning = '';
        if (messages?.length > 0) {
            messages.forEach((message) => {
                warning += `${message.description} `;
            });
        }
        setsWarningMessage((prev) => ({
            ...prev,
            [entity]: warning,
        }));
    };
    const handleValidateEquipmentResponse = (res, entity, cb) => {
        const validateResponse = res?.resource_details;
        if (validateResponse?.validResourceAssignment) {
            if (cb) cb(res);
        } else {
            cb(res); // set trailer info even in case of not valid resource
        }

        setResourceValidateWarningMessage(validateResponse?.messages, entity);
    };
    const handleValidateEquipmentError = (error) => {
        setsError(getFormattedEquipmentAPIValidationError(error));
    };
    useEffect(() => {
        // TODO: add other error case scenarios if any
        if (equipmentDriversListResponse.response) {
            setsError('');
            const { response } = equipmentDriversListResponse;
            if (response?.Driver_Info?.payload?.drivers) {
                const driverInfo = response?.Driver_Info?.payload?.drivers;
                setsDriverList((_sDrivers) => ({
                    ..._sDrivers,
                    [sSelectedCarrier]: processDriversResponse(driverInfo),
                }));
            } else {
                setsError(response?.Driver_Info?.errors);
            }
            if (response?.Equipment_info?.equipments && response?.Tariff_Info?.tariffs) {
                const equipmentInfo = response?.Equipment_info?.equipments;
                const tariffInfo = response?.Tariff_Info?.tariffs;
                setsEquipments((_sEquipments) => ({
                    ..._sEquipments,
                    [sSelectedCarrier]: processEquipmentsResponse(
                        equipmentInfo,
                        tariffInfo,
                        currentMarket,
                        featureFlags?.restrictEquipmentCode,
                        pLoads,
                    ),
                }));
            } else if (response?.Equipment_info?.errors) {
                setsError(response?.Equipment_info?.errors);
            } else {
                // TODO: check the error
                setsError(response?.Tariff_Info?.errors);
            }
            if (response?.Carrier_info?.carrier) {
                const carrier = response?.Carrier_info?.carrier;
                setsCarrierInfo(carrier);
            } else {
                setsError(response?.Carrier_info?.errors);
            }
        }
    }, [equipmentDriversListResponse.response]);
    useEffect(() => {
        if (pageLoadDataResponse.response) {
            setsError('');
            const { response } = pageLoadDataResponse;
            if (response && response.payload && response.payload.static_data) {
                setsCarriers(
                    processCarriersResponse(
                        response.payload?.mdm_static_data?.static_data?.carriers,
                        response.payload?.mdm_static_data?.static_data?.carrier_codes,
                    ),
                );
                setsCarrierCodes(response.payload?.mdm_static_data?.static_data.carrier_codes);
            } else {
                setsError(response?.payload?.errors);
            }
        }
    }, [pageLoadDataResponse.response]);
    const setPageLoadData = () => {
        const data = TripSharedService.getTripStaticData();
        setsCarriers(
            processCarriersResponse(
                data.payload?.mdm_static_data?.static_data?.carriers,
                data.payload?.mdm_static_data?.static_data?.carrier_codes,
            ),
        );
        setsCarrierCodes(data.payload?.mdm_static_data?.static_data.carrier_codes);
    };

    // useEffect(() => {
    //   // TODO: set warning message from the BE response
    //   // TODO: handle parallel call orchestrator errors
    //   const { response } = validateEquipmentResponse;
    //   let error = '';
    //   if (response) {
    //     if (response.equipment_details && response.equipment_details.equipment) {
    //       setsEquipmentInfo(response.equipment_details.equipment);
    //     }
    //     if (response.resource_details && response.resource_details.validResourceAssignment
    //       && response.resource_details.messages) {
    //       response.resource_details.messages.forEach((message) => {
    //         error += `${message.description} `;
    //       });
    //       setsError(error);
    //     } else {
    //       // TODO: change this once the BE error response is confirmed
    //       setsError(response?.payload?.errors);
    //     }
    //   }
    // }, [validateEquipmentResponse.response]);

    useEffect(() => {
        if (
            !loading &&
            (equipmentDriversListResponse.loading ||
                pageLoadDataResponse.loading ||
                validateEquipmentResponse.loading ||
                validateDriverResponse.loading ||
                validateEquipmentTrailerResponse.loading ||
                fetchCarrierDataLoading.loading)
        ) {
            setloading(true);
        } else {
            setloading(false);
        }
    }, [
        equipmentDriversListResponse.loading,
        pageLoadDataResponse.loading,
        validateEquipmentResponse.loading,
        validateDriverResponse.loading,
        validateEquipmentTrailerResponse.loading,
        fetchCarrierDataLoading.loading,
    ]);
    const getPageLoadData = () => {
        fetchPageLoadData(getPageStaticDataRequest(currentMarket));
    };
    const getCarrierList = () => {
        const req = getReqPayloadCarrierTariff(pTrip);
        fetchCarrierData(req, (res) => {
            const tariffList = res?.tariff_list_res?.tariffs;
            const carrierList = res?.carrier_list_res;
            setsCarrierList(getTransformedCarrierList(tariffList, carrierList));
        });
    };

    // const getEquipmentType = (equipmentType) => {
    //   if (equipmentType === 'TRACTOR') {
    //     return trans('workloadAssignment.label.trailerTractor');
    //   }
    //   if (equipmentType === 'TRUCK') {
    //     return trans('workloadAssignment.label.truck');
    //   } return '';
    // };

    const [sIsCreateCarrierAndResource, setsIsCreateCarrierAndResource] = useState(false);
    const [sIsUpdateResource, setsIsUpdateResource] = useState(false);
    useEffect(() => {
        if (!TripSharedService.getConfig() || !TripSharedService.getTripStaticData()) {
            getPageLoadData();
        } else {
            setPageLoadData();
        }
        getCarrierList();
        const carrierId = pWorkloadData?.carrier;
        if (carrierId) {
            setsSelectedCarrier(carrierId);
            setsIsCreateCarrierAndResource(false); // edit mode
        } else {
            setsIsCreateCarrierAndResource(true); // create mode
        }

        if (pWorkloadData?.equipmentType === equipmentTypes[0].label) {
            setsSelectedEquipmentType('TRACTOR');
        } else if (pWorkloadData?.equipmentType === 'TRUCK') {
            setsSelectedEquipmentType('TRUCK');
        } else if (pWorkloadData?.equipmentType === 'CARGO') {
            setsSelectedEquipmentType('CARGO');
        } else if (pWorkloadData?.equipmentType === 'CAR') {
            setsSelectedEquipmentType('CAR');
        }
        if (carrierId && (pWorkloadData?.tractor || pWorkloadData.trailer || pWorkloadData.driver)) {
            setsIsCreateCarrierAndResource(false);
            setsIsUpdateResource(true);
        } else if (
            carrierId &&
            !pWorkloadData?.tractor &&
            !pWorkloadData.trailer &&
            !pWorkloadData.driver &&
            pTrip?.isDispatcherTripExist
        ) {
            setsIsCreateCarrierAndResource(false);
            setsIsUpdateResource(true);
        } else if (
            carrierId &&
            !pWorkloadData?.tractor &&
            !pWorkloadData.trailer &&
            !pWorkloadData.driver &&
            !pTrip?.isDispatcherTripExist
        ) {
            setsIsCreateCarrierAndResource(false);
            setsIsUpdateResource(false);
        }
        if (pWorkloadData?.equipmentType === equipmentTypes[0].label) {
            setsSelectedEquipment(pWorkloadData?.tractor);
        } else if (pWorkloadData?.equipmentType === equipmentTypes[1].label) {
            setsSelectedEquipment(pWorkloadData?.truck);
        }
        if (featureFlags?.enableNewEquipmentTypes) {
            if (pWorkloadData?.equipmentType === equipmentTypes[2]?.label) {
                setsSelectedEquipment(pWorkloadData?.cargo);
            } else if (pWorkloadData?.equipmentType === equipmentTypes[3]?.label) {
                setsSelectedEquipment(pWorkloadData?.car);
            }
        }
        if (pWorkloadData?.trailer) {
            const loads = {};
            pLoads.forEach((load) => {
                loads[load.loadId] = pWorkloadData?.trailer;
            });
            loadTrailerMap.current = loads;
            setsSelectedTrailer(pWorkloadData.trailer);
        }
        if (pWorkloadData?.driver) {
            setsSelectedDriver(pWorkloadData?.driver);
        }
        if (pWorkloadData?.loads) {
            Object.keys(pWorkloadData?.loads).forEach((load) => {
                if (!sTrailerInfo[pWorkloadData?.loads[load]]) {
                    const loadTrailer = {
                        [load]: pWorkloadData?.loads[load],
                    };
                    const req = getTrailerValidateRequestPayload(
                        loadTrailer,
                        pWorkloadData?.loads[load],
                        pTrip?.planId,
                        carrierId,
                    );
                    fetchValidateSelectedEquipment(
                        req,
                        (res) =>
                            handleValidateEquipmentResponse(res, 'trailer', () => {
                                const equipment = res?.equipment_details?.equipment;
                                setsTrailerInfo((trailerInfo) => ({
                                    ...trailerInfo,
                                    [pWorkloadData?.loads[load]]: equipment,
                                }));
                            }),
                        handleValidateEquipmentError,
                    );
                }
            });
        }
    }, []);
    useEffect(() => {
        if (sSelectedCarrier && pageLoadSetting?.showCLColumns) {
            setsError('');
            // do not fetch details if already fetched
            if (!sEquipments[sSelectedCarrier] && !sDriverList[sSelectedCarrier]) {
                if (sCarrierCodes.length > 0) {
                    getEquipmentDrivers(
                        getEquipmentDriverRequestPayload(
                            sSelectedCarrier,
                            sCarrierCodes,
                            pTrip.tariffReq,
                            featureFlags,
                        ),
                    );
                }
            }
        }
    }, [sSelectedCarrier, sEquipments, sDriverList, sCarrierCodes]);
    useEffect(() => {
        if (sSelectedDriver) {
            // const req = getDriverValidateRequestPayload(sSelectedDriver, sSelectedEquipment);
            const req = getDriverValidateRequestPayload(sSelectedDriver, pTrip?.planId, sSelectedCarrier);
            validateSelectedDriver(
                req,
                (res) => {
                    if (!res.validresInSuccessourceAssignment) {
                        setResourceValidateWarningMessage(res.messages, 'driver');
                    }
                },
                (err) => {
                    setsError(err);
                },
            );
        }
    }, [sSelectedDriver]);
    useEffect(() => {
        if (sSelectedEquipment) {
            const req = getTractorTruckValidateRequestPayload(
                sSelectedEquipment,
                pTrip?.planId,
                sSelectedEquipmentType,
                sSelectedCarrier,
            );
            const setData = (response) => {
                if (response?.equipment_details && response?.equipment_details?.equipment) {
                    setsEquipmentInfo(response.equipment_details.equipment);
                } else {
                    setsEquipmentInfo(null);
                }
            };
            fetchValidateSelectedEquipment(
                req,
                (res) => handleValidateEquipmentResponse(res, 'equipment', setData),
                handleValidateEquipmentError,
            );
        }
    }, [sSelectedEquipment]);
    useEffect(() => {
        if (sSelectedTrailer) {
            // if (sTrailerInfo[sSelectedTrailer]) {
            //   return;
            // }

            const req = getTrailerValidateRequestPayload(
                loadTrailerMap.current,
                sSelectedTrailer,
                pTrip?.planId,
                sSelectedCarrier,
            );
            const setData = (response) => {
                const equipment = response?.equipment_details?.equipment;
                setsTrailerInfo((trailerInfo) => ({
                    ...trailerInfo,
                    [sSelectedTrailer]: equipment,
                }));
            };
            fetchValidateSelectedEquipment(
                req,
                (res) => handleValidateEquipmentResponse(res, 'trailer', setData),
                handleValidateEquipmentError,
            );
        }
    }, [sSelectedTrailer]);
    const handleCarrierChange = (carrierId) => {
        setsWarningMessage(initialWarnings);
        setsSelectedCarrier(carrierId);
        if (pageLoadSetting?.showCLColumns) {
            setsSelectedDriver(null);
            setsSelectedEquipment(null);
            setsEquipmentInfo(null);
        }
    };
    const handleDriverChange = (driverId) => {
        setsWarningMessage((prev) => ({
            ...prev,
            driver: '',
        }));
        setsSelectedDriver(driverId);
    };
    const handleTractorTruckChange = (value, type) => {
        setsWarningMessage((prev) => ({
            ...prev,
            equipment: '',
        }));
        setsSelectedEquipment(value);
        setsSelectedEquipmentType(type.toUpperCase());
    };
    const validateEqpFetch = (workloadAssignmentData) => {
        const trailerErrorList = getTrailerErrorList(
            workloadAssignmentData,
            {
                equipmentInfo: sEquipmentInfo,
                equipmentTypes,
                equipmentsOfSelectedCarrier,
            },
            {
                trailerAssgnmntTypes: trailerAssignmentTypes,
                trailerInfo: sTrailerInfo,
            },
        );
        if (trailerErrorList.length > 0) {
            let singleEqpMsg = trailerErrorList.join(', ');
            singleEqpMsg = `${singleEqpMsg} ${trans('msg.equipmentFetchError')} ${trans(
                'msg.equipmentFetchErrorGuide',
            )}`;
            setsError([
                {
                    description: singleEqpMsg,
                },
            ]);
        } else {
            setsError('');
        }
        return !(trailerErrorList.length > 0);
    };
    const getAllLoads = (isSingleTrailer, isBasedOnCount, loads, wlLoads) => {
        if (isSingleTrailer || (!isSingleTrailer && !isBasedOnCount)) {
            return loads;
        }
        if (!isSingleTrailer && isBasedOnCount) {
            const bwlLoads = {};
            pLoads.forEach((load) => {
                bwlLoads[load.loadId] = '';
            });
            return {
                ...bwlLoads,
                ...wlLoads,
            };
        }
    };
    const handleConfirmAssign = (workloadAssignmentData) => {
        let isResourceAssignExit = false;
        let isCarrierOnlyExit = false;
        let isUpdateCarrier = false;
        const isSingleTrailer = workloadAssignmentData.trailerAssignmentType === trailerAssignmentTypes[0].label;
        const isBasedOnCount = workloadAssignmentData.trailerAssignmentType === trailerAssignmentTypes[1].label;
        const loads = {};
        pLoads.forEach((load) => {
            loads[load.loadId] = workloadAssignmentData?.trailer;
        });
        const driverName = sDriverList[sSelectedCarrier]?.find(
            (driver) => driver?.id?.toString() === workloadAssignmentData?.driver?.toString(),
        )?.name;
        const carrierName = sCarriers.find((carrier) => carrier.id === workloadAssignmentData.carrier)?.name;
        if (
            (workloadAssignmentData.driver || workloadAssignmentData?.trailer || workloadAssignmentData?.tractor) &&
            workloadAssignmentData.carrier
        ) {
            isResourceAssignExit = true;
            isCarrierOnlyExit = true;
        }
        if (
            !workloadAssignmentData.driver &&
            !workloadAssignmentData?.trailer &&
            !workloadAssignmentData?.tractor &&
            workloadAssignmentData.carrier
        ) {
            isResourceAssignExit = false;
            isCarrierOnlyExit = true;
        }
        if (pWorkloadData.carrier === workloadAssignmentData.carrier) {
            isUpdateCarrier = false;
        } else {
            isUpdateCarrier = true;
        }
        if (
            validateEqpFetch({
                ...workloadAssignmentData,
                loads: isSingleTrailer ? loads : workloadAssignmentData.loads,
            })
        ) {
            // TODO: need to send workload,carrier data to populate assign request payload
            pOnConfirmAssign(
                {
                    ...workloadAssignmentData,
                    driverName,
                    carrierName,
                    loads: getAllLoads(isSingleTrailer, isBasedOnCount, loads, workloadAssignmentData.loads),
                },
                {
                    carrierInfo: sCarrierInfo,
                    equipmentInfo: sEquipmentInfo,
                    trailerInfo: sTrailerInfo,
                },
                sIsCreateCarrierAndResource,
                isCarrierOnlyExit,
                isResourceAssignExit,
                sIsUpdateResource,
                isUpdateCarrier,
            );
        }
    };
    const handleCarrierConfirmAssign = (carrier) => {
        pOnConfirmAssign(
            {
                carrier,
                carrierName: sCarrierList?.find((cr) => cr?.id === carrier)?.name,
            },
            {
                carrierInfo: pTrip,
            },
        );
    };
    // TODO: change this code below (need to optimize)
    const handleTrailerChange = (value, loadId) => {
        setsWarningMessage((prev) => ({
            ...prev,
            trailer: '',
        }));
        if (loadId) {
            // Based on load count
            loadTrailerMap.current = {
                // ...loadTrailerMap.current,
                [loadId]: value,
            };
        } else {
            // single trailer
            const loads = {};
            pLoads.forEach((load) => {
                loads[load.loadId] = value;
            });
            loadTrailerMap.current = loads;
        }
        setsSelectedTrailer(value);
    };
    return (
        <>
            {sCarriers.length > 0 && pageLoadSetting?.showCLColumns ? (
                <WorkloadAssignment
                    pOnClose={pOnClose}
                    pOnConfirmAssign={handleConfirmAssign}
                    labels={labels}
                    pCarriers={sCarriers}
                    pOnCarrierChange={handleCarrierChange}
                    pTrailerAssignmentTypes={trailerAssignmentTypes}
                    pEquipmentTypes={equipmentTypes}
                    pLoads={pLoads}
                    pDrivers={sDriverList[sSelectedCarrier] || []}
                    pTruckEquipment={equipmentsOfSelectedCarrier.truck}
                    pTrailerEquipment={equipmentsOfSelectedCarrier.trailer}
                    pTractorEquipment={equipmentsOfSelectedCarrier.tractor}
                    pCargoVanEquipment={equipmentsOfSelectedCarrier?.cargo}
                    pCarEquipment={equipmentsOfSelectedCarrier?.car}
                    pErrorMessage={sError ? getErrorText(sError, trans) : ''}
                    pOnDriverChange={handleDriverChange}
                    pOnTractorTruckChange={handleTractorTruckChange}
                    pOnTrailerChange={handleTrailerChange}
                    pOnCargoVanChange={handleTractorTruckChange}
                    pOnCarChange={handleTractorTruckChange}
                    pData={pWorkloadData}
                    pWarningMessage={warnings}
                    pEnableDolly={
                        featureFlags?.showCreateTripForDoubleTrailer &&
                        pTrip?.transitDetailMode === getModeLabel(TRIP_MODE.DBL)
                    }
                    pBillOfLadingConfigs={billOfLadingConfigs}
                    pEnableNewEquipmentTypes={featureFlags?.enableNewEquipmentTypes}
                />
            ) : null}
            {pageLoadSetting?.showCAColumns && (
                <CarrierSelectionModal
                    pOnClose={pOnClose}
                    pOptions={sCarrierList}
                    pOnAssign={handleCarrierConfirmAssign}
                    pCarrier={sSelectedCarrier}
                    pOnCarrierChange={handleCarrierChange}
                    pTranslations={caLabels}
                    {...carrierSelectionProps}
                />
            )}
        </>
    );
};
const propTypes = {
    pTrip: PropTypes.objectOf(string).isRequired,
    pOnClose: PropTypes.func.isRequired,
    pOnConfirmAssign: PropTypes.func.isRequired,
    pLoads: PropTypes.arrayOf(PropTypes.shape({})),
    pWorkloadData: PropTypes.shape({
        carrier: PropTypes.string,
        equipmentType: PropTypes.string,
        driver: PropTypes.string,
        tractor: PropTypes.string,
        truck: PropTypes.string,
        cargo: PropTypes.string,
        car: PropTypes.string,
        trailerAssignmentType: PropTypes.string,
        trailer: PropTypes.string,
        loads: PropTypes.objectOf(string),
        equipment: PropTypes.shape({
            plans: PropTypes.arrayOf(),
            equipmentId: PropTypes.string,
            equipmentType: PropTypes.string,
        }),
        loadIds: PropTypes.arrayOf(PropTypes.string),
    }),
};
WorkloadAssignmentModal.propTypes = propTypes;
WorkloadAssignmentModal.defaultProps = {
    pLoads: [],
    pWorkloadData: {},
};
export default WorkloadAssignmentModal;
