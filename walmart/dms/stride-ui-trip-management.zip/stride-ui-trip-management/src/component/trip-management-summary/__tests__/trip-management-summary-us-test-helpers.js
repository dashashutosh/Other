export const TABLE_ID = 'search-result-table-us';

export const SELECT_ALL_CHECKBOX_TEST_ID = TABLE_ID + '-header-checkbox';

export const SEARCH_RESULT_TABLE_HEAD_TEST_ID = TABLE_ID + '-thead';

export const SEARCH_RESULT_TABLE_BODY_TEST_ID = TABLE_ID + '-tbody';

export const getTableCellTestId = (rowId, colId) => `${TABLE_ID}-row-${rowId}-col-${colId}`;

export const getCheckboxTestId = (rowId) => `${TABLE_ID}-row-checkbox-${rowId}`;
