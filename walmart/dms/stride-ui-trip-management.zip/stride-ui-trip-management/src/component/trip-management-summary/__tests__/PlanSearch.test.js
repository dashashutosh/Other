import React from 'react';
import { fireEvent, render, screen } from '../../../utils/test-utils';
import PlanSearch from '../PlanSearch';
import queryState from './mocks/PlanSearchQueryState.mock.json';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMockCA } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import TripSharedService from '../../../service/TripSharedService';
import { staticData } from './mocks/PlanSearchCA.mock';

beforeEach(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMockCA);
    jest.setTimeout(50000);
});

describe('Plan search tests', () => {
    it('should render all filter fields', async () => {
        await TripSharedService.setFeatureFlags({ enableLocationIdFilter: true });
        render(
            <PlanSearch
                pOnClose={() => {}}
                pStaticData={staticData}
                queryState={queryState}
                dispatch={jest.fn()}
                pIsOpen
            />,
        );

        expect(screen.getByTestId('dateType')).toBeDefined();
        expect(screen.getByTestId('periodType')).toBeDefined();
        // TODO: Fix this test after MFE migration
        // expect(screen.getByTestId('date')).toBeDefined();

        expect(screen.getByTestId('originLocId')).toBeDefined();
        expect(screen.getByTestId('originType')).toBeDefined();
        expect(screen.getByTestId('originCity')).toBeDefined();
        expect(screen.getByTestId('originProvince')).toBeDefined();
        expect(screen.getByTestId('originPostalCode')).toBeDefined();
        expect(screen.getByTestId('originCountry')).toBeDefined();

        expect(screen.getByTestId('destinationLocId')).toBeDefined();
        expect(screen.getByTestId('destinationType')).toBeDefined();
        expect(screen.getByTestId('destinationCity')).toBeDefined();
        expect(screen.getByTestId('destinationProvince')).toBeDefined();
        expect(screen.getByTestId('destinationPostalCode')).toBeDefined();
        expect(screen.getByTestId('destinationCountry')).toBeDefined();

        expect(screen.getByTestId('loadOwner')).toBeDefined();
        expect(screen.getByTestId('priority')).toBeDefined();
        expect(screen.getByTestId('temperatureControl')).toBeDefined();
        expect(screen.getByTestId('equipmentConfigurationId')).toBeDefined();
        expect(screen.getByTestId('ibob')).toBeDefined();
        expect(screen.getByTestId('program')).toBeDefined();
        expect(screen.getByTestId('channel')).toBeDefined();
        expect(screen.getByTestId('loadId')).toBeDefined();
        expect(screen.getByTestId('toId')).toBeDefined();

        expect(screen.getByTestId('serviceClass')).toBeDefined();
        expect(screen.getByTestId('serviceMode')).toBeDefined();
        expect(screen.getByTestId('serviceLevel')).toBeDefined();
        expect(screen.getByTestId('serviceType')).toBeDefined();
        // TODO: Fix this test after MFE migration
        // expect(screen.getByTestId('carrierId')).toBeDefined();
        // expect(screen.getByTestId('scacCode')).toBeDefined();
    });

    describe('Show equipment id based on feature flag', () => {
        it('Should not show equipment id, if the feature flag is on', async () => {
            await TripSharedService.setFeatureFlags({ removeEquipmentFromFilter: true });
            render(
                <PlanSearch
                    pOnClose={() => {}}
                    pStaticData={staticData}
                    queryState={queryState}
                    dispatch={jest.fn()}
                    pIsOpen
                />,
            );
            expect(screen.queryByTestId('equipmentId')).toBeNull();
        });

        it('Should show equipment id, if the feature flag is off', async () => {
            await TripSharedService.setFeatureFlags({ removeEquipmentFromFilter: false });

            render(
                <PlanSearch
                    pOnClose={() => {}}
                    pStaticData={staticData}
                    queryState={queryState}
                    dispatch={jest.fn()}
                    pIsOpen
                />,
            );

            expect(screen.getByTestId('equipmentId')).toBeDefined();
        });
    });
    describe('Action buttons', () => {
        it('should show Clear All Filter button', () => {
            render(
                <PlanSearch
                    pOnClose={() => {}}
                    pStaticData={staticData}
                    queryState={queryState}
                    dispatch={jest.fn()}
                    pIsOpen
                />,
            );
            expect(screen.getByTestId('clearAllFilters')).toBeDefined();
        });

        it('should call search function on Apply Filter button click', () => {
            const searchMockFn = jest.fn();
            render(
                <PlanSearch
                    pOnClose={searchMockFn}
                    pStaticData={staticData}
                    queryState={queryState}
                    dispatch={jest.fn()}
                    pIsOpen
                />,
            );
            const destCityElement = screen.getByTestId('destinationCity');
            expect(destCityElement).toBeDefined();
            fireEvent.change(destCityElement, { target: { value: 'MISSISSAUGA' } });
            const filterBtn = screen.getByTestId('confirmBtn');
            fireEvent.click(filterBtn);
            expect(searchMockFn).toHaveBeenCalled();
        });
    });
});
