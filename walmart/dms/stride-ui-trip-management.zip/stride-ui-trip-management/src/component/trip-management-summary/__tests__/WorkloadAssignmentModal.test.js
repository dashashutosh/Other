import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock, contextMockCA } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import { fireEvent, render, screen } from '../../../utils/test-utils';
import WorkloadAssignmentModal from '../WorkloadAssignmentModal';
import {
    workloadDataMock,
    carriersListResponseMock,
    workLoadStaticData,
    workloadDataWithEqTypeCargo,
    workloadDataWithEqTypeCar,
} from './mocks/WorkloadAssignment.mock';
import { LocalizeLang } from '@gscope-mfe/common-components';
import TripSharedService from '../../../service/TripSharedService';

jest.mock('@gscope-mfe/common-components', () => {
    const actualModule = jest.requireActual('@gscope-mfe/common-components');
    return {
        ...actualModule,
        LocalizeLang: {
            default: {
                ...actualModule.LocalizeLang.default,
                localizeLang: jest.fn(),
            },
        },
    };
});

const API_GATEWAY_PREFIX = '/api/gateway/v4/stride-ui-trip-management';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX}-getCarriers/getCarriers`, (req, res, ctx) =>
        res(ctx.json(carriersListResponseMock)),
    ),
    rest.post(`${API_GATEWAY_PREFIX}-workloadStaticData/workloadStaticData`, (req, res, ctx) =>
        res(ctx.json(workLoadStaticData)),
    ),
);

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
    server.listen();
});

jest.mock('@walmart/stride-ui-commons', () => ({
    ...jest.requireActual('@walmart/stride-ui-commons'),
}));

describe('Workload assignment model', () => {
    beforeEach(() => {
        LocalizeLang.default.localizeLang.mockImplementation(() => jest.fn((str) => str));
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMock);
        TripSharedService.setConfig(CmsConfig);
        TripSharedService.setTripStaticData(workLoadStaticData);
        TripSharedService.setPageLoadSettings({ showCLColumns: true });
    });

    it('should render without error', () => {
        const pTrip = { tariffReq: {} };
        expect(
            render(
                <WorkloadAssignmentModal
                    pOnClose={() => {}}
                    pOnConfirmAssign={() => {}}
                    pWorkloadData={workloadDataMock}
                    pTrip={pTrip}
                />,
            ),
        ).toBeDefined();
    });

    describe('Equipment type label change in CL market', () => {
        const pTrip = { tariffReq: {} };
        beforeEach(() => {
            const trans = {
                'workloadAssignment.label.chasis': 'Chasis',
                'workloadAssignment.label.truck': 'Camion',
            };
            LocalizeLang.default.localizeLang.mockImplementation(() => jest.fn((str) => trans[str]));
        });
        it('should show Chasis if the flag is on', () => {
            TripSharedService.setFeatureFlags({ useLabelChasisForTruck: true });
            const wrapper = render(<WorkloadAssignmentModal pWorkloadData={workloadDataMock} pTrip={pTrip} />);
            expect(wrapper.queryAllByText('Chasis')).toBeTruthy();
            expect(wrapper.queryAllByText('Chasis').length).toEqual(1);
            expect(wrapper.queryByText('Camion')).toBeNull();
        });
        it('should show Camion if the flag is off', () => {
            TripSharedService.setFeatureFlags({ useLabelChasisForTruck: false });
            const wrapper = render(<WorkloadAssignmentModal pWorkloadData={workloadDataMock} pTrip={pTrip} />);
            expect(wrapper.queryAllByText('Camion')).toBeTruthy();
            expect(wrapper.queryAllByText('Camion').length).toEqual(1);
            expect(wrapper.queryByText('Chasis')).toBeNull();
        });
    });

    describe('Bill of lading - tests', () => {
        const pTrip = { tariffReq: {} };
        beforeEach(() => {
            const trans = {
                'workloadAssignment.label.billOfLading': 'Bill of Lading',
            };
            LocalizeLang.default.localizeLang.mockImplementation(() => jest.fn((str) => trans[str]));
        });
        it('should show bill of lading if flag is on and user selects trailer and tractor', async () => {
            TripSharedService.setFeatureFlags({ enableBillOfLading: true });
            const wrapper = render(<WorkloadAssignmentModal pWorkloadData={workloadDataMock} pTrip={pTrip} />);
            expect(wrapper).toBeDefined();

            const carrier = await wrapper.findByTestId('carrier');
            expect(carrier).toBeDefined();
            fireEvent.click(carrier);

            const carrierSelection = await wrapper.findByTestId('single-select-simple-option-ANY');
            expect(carrierSelection).toBeDefined();
            fireEvent.click(carrierSelection);

            const equipmentType = await screen.findAllByTestId('ld-sc-ui-segment');
            expect(equipmentType.length).toEqual(2);
            fireEvent.click(equipmentType[0]);

            const billOfLadingField = screen.queryByTestId('billOfLading');
            expect(billOfLadingField).toBeDefined();
        });

        it('should show bill of lading if flag is on and user selects truck', async () => {
            TripSharedService.setFeatureFlags({ enableBillOfLading: true });
            const wrapper = render(<WorkloadAssignmentModal pWorkloadData={workloadDataMock} pTrip={pTrip} />);
            expect(wrapper).toBeDefined();

            const carrier = await wrapper.findByTestId('carrier');
            expect(carrier).toBeDefined();
            fireEvent.click(carrier);

            const carrierSelection = await wrapper.findByTestId('single-select-simple-option-ANY');
            expect(carrierSelection).toBeDefined();
            fireEvent.click(carrierSelection);

            const equipmentType = await screen.findAllByTestId('ld-sc-ui-segment');
            expect(equipmentType.length).toEqual(2);
            fireEvent.click(equipmentType[1]);

            const billOfLadingField = screen.queryByTestId('billOfLading');
            expect(billOfLadingField).toBeDefined();
        });

        it('should not show bill of lading if flag is off and user selects trailer and tractor', async () => {
            TripSharedService.setFeatureFlags({ enableBillOfLading: false });
            const wrapper = render(<WorkloadAssignmentModal pWorkloadData={workloadDataMock} pTrip={pTrip} />);
            expect(wrapper).toBeDefined();

            const carrier = await wrapper.findByTestId('carrier');
            expect(carrier).toBeDefined();
            fireEvent.click(carrier);

            const carrierSelection = await wrapper.findByTestId('single-select-simple-option-ANY');
            expect(carrierSelection).toBeDefined();
            fireEvent.click(carrierSelection);

            const equipmentType = await screen.findAllByTestId('ld-sc-ui-segment');
            expect(equipmentType.length).toEqual(2);
            fireEvent.click(equipmentType[0]);

            const billOfLadingField = screen.queryByTestId('billOfLading');
            expect(billOfLadingField).toBeNull();
        });

        it('should not show bill of lading if flag is off and user selects truck', async () => {
            TripSharedService.setFeatureFlags({ enableBillOfLading: false });
            const wrapper = render(<WorkloadAssignmentModal pWorkloadData={workloadDataMock} pTrip={pTrip} />);
            expect(wrapper).toBeDefined();

            const carrier = await wrapper.findByTestId('carrier');
            expect(carrier).toBeDefined();
            fireEvent.click(carrier);

            const carrierSelection = await wrapper.findByTestId('single-select-simple-option-ANY');
            expect(carrierSelection).toBeDefined();
            fireEvent.click(carrierSelection);

            const equipmentType = await screen.findAllByTestId('ld-sc-ui-segment');
            expect(equipmentType.length).toEqual(2);
            fireEvent.click(equipmentType[1]);

            const billOfLadingField = screen.queryByTestId('billOfLading');
            expect(billOfLadingField).toBeNull();
        });

        it('should allow bill of lading edit if trip is before point of transit', async () => {
            TripSharedService.setFeatureFlags({ enableBillOfLading: true });
            const enabledEditTrip = {
                ...pTrip,
                planStatus: {
                    name: 'READY_FOR_DISPATCH',
                },
            };
            const wrapper = render(
                <WorkloadAssignmentModal pWorkloadData={workloadDataMock} pTrip={enabledEditTrip} />,
            );
            expect(wrapper).toBeDefined();

            const carrier = await wrapper.findByTestId('carrier');
            expect(carrier).toBeDefined();
            fireEvent.click(carrier);

            const carrierSelection = await wrapper.findByTestId('single-select-simple-option-ANY');
            expect(carrierSelection).toBeDefined();
            fireEvent.click(carrierSelection);

            const equipmentType = await screen.findAllByTestId('ld-sc-ui-segment');
            expect(equipmentType.length).toEqual(2);
            fireEvent.click(equipmentType[1]);

            const billOfLadingField = await screen.findByTestId('billOfLading');
            expect(billOfLadingField).toBeDefined();
            expect(billOfLadingField.getAttribute('disabled')).toBeNull();
        });

        it('should not allow bill of lading edit if trip phase is in transit or after', async () => {
            TripSharedService.setFeatureFlags({ enableBillOfLading: true });
            const enabledEditTrip = {
                ...pTrip,
                planStatus: {
                    name: 'IN_TRANSIT',
                },
            };
            const wrapper = render(
                <WorkloadAssignmentModal pWorkloadData={workloadDataMock} pTrip={enabledEditTrip} />,
            );
            expect(wrapper).toBeDefined();

            const carrier = await wrapper.findByTestId('carrier');
            expect(carrier).toBeDefined();
            fireEvent.click(carrier);

            const carrierSelection = await wrapper.findByTestId('single-select-simple-option-ANY');
            expect(carrierSelection).toBeDefined();
            fireEvent.click(carrierSelection);

            const equipmentType = await screen.findAllByTestId('ld-sc-ui-segment');
            expect(equipmentType.length).toEqual(2);
            fireEvent.click(equipmentType[1]);

            const billOfLadingField = await screen.findByTestId('billOfLading');
            expect(billOfLadingField).toBeDefined();
            expect(billOfLadingField.getAttribute('disabled')).toEqual('');
        });
    });

    describe('MX New Equipment Types Cargo & Car', () => {
        const tripSummary = {
            planStatusCode: 'WORKLOAD_ASSIGNMENT',
        };
        beforeEach(() => {
            const trans = {
                'workloadAssignment.label.cargoVan': 'Cargo Van',
                'workloadAssignment.label.car': 'Car',
            };
            LocalizeLang.default.localizeLang.mockImplementation(() => jest.fn((str) => trans[str]));
        });
        it('should show Cargo Van if the flag is on', () => {
            TripSharedService.setFeatureFlags({ enableNewEquipmentTypes: true });
            const wrapper = render(
                <WorkloadAssignmentModal pWorkloadData={workloadDataWithEqTypeCargo} pTrip={tripSummary} />,
            );
            expect(wrapper).toBeDefined();
            expect(wrapper.queryAllByText('Cargo Van')).toBeTruthy();
            expect(wrapper.queryAllByText('Cargo Van').length).toEqual(1);
        });
        it('should show Car if the flag is on', () => {
            TripSharedService.setFeatureFlags({ enableNewEquipmentTypes: true });
            const wrapper = render(
                <WorkloadAssignmentModal pWorkloadData={workloadDataWithEqTypeCar} pTrip={tripSummary} />,
            );
            expect(wrapper).toBeDefined();
            expect(wrapper.queryAllByText('Car')).toBeTruthy();
            expect(wrapper.queryAllByText('Car').length).toEqual(1);
        });
        it('should not show Cargo Van if the flag is off', () => {
            TripSharedService.setFeatureFlags({ enableNewEquipmentTypes: false });
            const wrapper = render(
                <WorkloadAssignmentModal pWorkloadData={workloadDataWithEqTypeCargo} pTrip={tripSummary} />,
            );
            expect(wrapper).toBeDefined();
            expect(wrapper.queryByText('Cargo Van')).toBeNull();
        });
        it('should not show Car if the flag is off', () => {
            TripSharedService.setFeatureFlags({ enableNewEquipmentTypes: false });
            const wrapper = render(
                <WorkloadAssignmentModal pWorkloadData={workloadDataWithEqTypeCar} pTrip={tripSummary} />,
            );
            expect(wrapper).toBeDefined();
            expect(wrapper.queryByText('Car')).toBeNull();
        });
    });
});

describe('Workload assignment model', () => {
    beforeEach(() => {
        LocalizeLang.default.localizeLang.mockImplementation(() =>
            jest.fn((str) => {
                const trans = {
                    'wl.label.recommended': 'Recommended',
                    'wl.label.enterScac': 'Enter SCAC',
                    'wl.label.title': 'Assign Carrier Manually',
                    'wl.label.selectionType': 'Selection type',
                    'wl.label.selectCarrier': 'Select Carrier',
                    'wl.label.selectCarrierHelperText':
                        'Includes all carriers matching the load requirements with an active lane rate',
                    'wl.label.cancel': 'Cancel',
                    'wl.label.assign': 'Assign',
                };
                return trans[str] || str;
            }),
        );
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCA);
        TripSharedService.setConfig(CmsConfig);
        TripSharedService.setTripStaticData(workLoadStaticData);
        TripSharedService.setPageLoadSettings({ showCAColumns: true });
    });

    const renderWorkloadAssignmentModal = (props = {}) =>
        render(
            <WorkloadAssignmentModal
                pOnClose={() => {}}
                pOnConfirmAssign={() => {}}
                pWorkloadData={{
                    ...workloadDataMock,
                }}
                {...props}
            />,
        );

    it('should render with Enter Scac with configurations', () => {
        TripSharedService.setFeatureFlags({ enableMultiLoadAssignment: true });
        renderWorkloadAssignmentModal({
            pWorkloadData: {
                ...workloadDataMock,
                loadIds: ['100', '200'],
            },
        });
        const enterScacField = screen.getByLabelText('Enter SCAC');
        expect(enterScacField).toBeDefined();
    });
});
