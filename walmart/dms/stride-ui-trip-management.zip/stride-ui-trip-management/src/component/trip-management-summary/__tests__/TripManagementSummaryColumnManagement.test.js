import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { AppUtils } from '@gscope-mfe/app-bridge';

import Cookies from 'js-cookie';
import ResizeObserver from 'resize-observer-polyfill';
import '@atlaskit/pragmatic-drag-and-drop-unit-testing/drag-event-polyfill';
import '@atlaskit/pragmatic-drag-and-drop-unit-testing/dom-rect-polyfill';

import { replaceRaf } from 'raf-stub';

import { render, screen, fireEvent, waitFor, within } from '../../../utils/test-utils';
import { API_GATEWAY_PREFIX_NEW, getUpdatedCMSConfig } from '../../../utils/test-helpers';

import TripManagementSummary from '../TripManagementSummary';
import TableColumnsUS from '../../model/TableColumnsUS';

// mock data
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import { userRlInfoMock } from './mocks/TripManagementSummary.mock';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import {
    SEARCH_RESULT_TABLE_BODY_TEST_ID,
    SEARCH_RESULT_TABLE_HEAD_TEST_ID,
} from './trip-management-summary-us-test-helpers';
import TripSharedService from '../../../service/TripSharedService';

replaceRaf();

const GscopePreferencesStore = (function () {
    let pagePreferences = {};

    return {
        getResponse: function () {
            return {
                status: 'OK',
                header: {
                    headerAttributes: {},
                },
                errors: [],
                payload: {
                    userId: 'user',
                    pagePreferences: pagePreferences,
                },
            };
        },

        addPreferences: function (page, preferenceName, preferenceValue) {
            pagePreferences = {
                ...pagePreferences,
                [page]: {
                    ...pagePreferences[page],
                    [preferenceName]: preferenceValue,
                },
            };
        },

        clear: function () {
            pagePreferences = {};
        },
    };
})();

const updatedCMSConfig = getUpdatedCMSConfig(CmsConfigUS, { showTagsCol: true, showCommentsColumn: true });

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(updatedCMSConfig));
        }
        return res(ctx.json(CmsConfig));
    }),
    rest.get('api/gateway/provider-userpref/pref', (req, res, ctx) => {
        return res(ctx.json(GscopePreferencesStore.getResponse()));
    }),
    rest.post('api/gateway/provider-userpref/pref', (req, res, ctx) => {
        const { page, preferenceName, preferenceValue } = JSON.parse(req.body.payload);
        GscopePreferencesStore.addPreferences(page, preferenceName, preferenceValue);
        return res(ctx.status(200));
    }),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));

jest.setTimeout(15000);

beforeAll(() => {
    Cookies.set('loggedInUserName', 'user');
    Cookies.set('loggedIn', 'true');

    const localStorageMock = (function () {
        let store = {};

        return {
            getItem: function (key) {
                return store[key] || null;
            },
            setItem: function (key, value) {
                store[key] = value.toString();
            },
            removeItem: function (key) {
                delete store[key];
            },
            clear: function () {
                store = {};
            },
        };
    })();

    Object.defineProperty(window, 'localStorage', {
        value: localStorageMock,
    });

    localStorage.setItem('ngStorage-permissionData', userPermMock);
    localStorage.setItem('ngStorage-preferences_user', userPreferencesMock);
    localStorage.setItem('ngStorage-rlUserInfo', userRlInfoMock);

    server.listen();

    const contextMockUS = {
        ...contextMock,
        currentMarket: 'us',
        invokeBulkUpdate: jest.fn(() => Promise.resolve({ status: 200 })),
    };
    const appUtilsGetSpy = jest.spyOn(AppUtils, 'get');
    appUtilsGetSpy.mockImplementation(() => contextMockUS);

    global.ResizeObserver = ResizeObserver;
    const spy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    spy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Trip Management Summary - Column management', () => {
    const originalScrollIntoView = HTMLElement.prototype.scrollIntoView;
    beforeAll(() => {
        HTMLElement.prototype.scrollIntoView = jest.fn();
    });

    afterAll(() => {
        HTMLElement.prototype.scrollIntoView = originalScrollIntoView;
    });

    async function reset() {
        // cleanup any pending drags
        fireEvent.dragEnd(window);

        // Cleaning up post-drop fix
        // Waiting for a microtask just incase the microtask queue has not been flushed by jest
        // [Discussion](https://twitter.com/alexandereardon/status/1635059194226446342)
        await 'microtask';
        fireEvent.pointerMove(window);
    }

    function getBubbleOrderedPath(path) {
        const last = path[path.length - 1];
        // will happen if you pass in an empty array
        if (!last) {
            return path;
        }
        // exit condition: no more parents
        if (!last.parentElement) {
            return path;
        }
        // bubble ordered
        return getBubbleOrderedPath([...path, last.parentElement]);
    }

    function setElementFromPointWithPath(path) {
        const originalElementFromPoint = document.elementFromPoint;
        const originalElementsFromPoint = document.elementsFromPoint;

        document.elementsFromPoint = () => path;
        document.elementFromPoint = () => path[0] ?? null;

        return () => {
            document.elementFromPoint = originalElementFromPoint;
            document.elementsFromPoint = originalElementsFromPoint;
        };
    }

    function setElementFromPoint(element) {
        const path = element ? getBubbleOrderedPath([element]) : [];
        return setElementFromPointWithPath(path);
    }

    afterEach(reset);

    it('should work as expected - column visibility and reorder', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const searchResultsTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(searchResultsTableBody.children.length).toBeGreaterThan(0);
        });

        const searchResultsTableHeader = screen.getByTestId(SEARCH_RESULT_TABLE_HEAD_TEST_ID);
        const tableHeaderFirstRow = searchResultsTableHeader.children[0];
        expect(Array.from(tableHeaderFirstRow.children).map((element) => element.dataset.colId)).toEqual([
            'stride-table-checkbox',
            TableColumnsUS.PLAN_ID.id,
            TableColumnsUS.TAGS.id,
            TableColumnsUS.PLAN_TYPE.id,
            TableColumnsUS.TRAILER_ID.id,
            TableColumnsUS.ORIGIN_LOCATION_ID.id,
            TableColumnsUS.COMMENTS.id,
            TableColumnsUS.DISTANCE.id,
            TableColumnsUS.DESTINATION_LOCATION_ID.id,
            TableColumnsUS.PRIORITY.id,
            TableColumnsUS.PLANNED_START.id,
            TableColumnsUS.PLANNED_END.id,
            TableColumnsUS.DURATION.id,
            TableColumnsUS.PICKUP_STOPS.id,
            TableColumnsUS.DELIVERY_STOPS.id,
            TableColumnsUS.STATUS.id,
            TableColumnsUS.ACTIONS.id,
        ]);

        const tableActionMenuTrigger = screen.getByTestId('table-action-menu-trigger');
        fireEvent.click(tableActionMenuTrigger);

        fireEvent.click(screen.getByText('Manage columns'));

        const tableColumnManagement = screen.getByTestId('table-column-management');
        expect(tableColumnManagement).toBeVisible();

        const leftContainer = screen.getByTestId('table-column-management-container-left');
        const rightContainer = screen.getByTestId('table-column-management-container-right');

        expect(within(leftContainer).getByTestId('table-column-management-dnd-item-TAGS')).toBeInTheDocument();
        expect(within(rightContainer).queryByTestId('table-column-management-dnd-item-TAGS')).not.toBeInTheDocument();

        setElementFromPoint(screen.getByTestId('table-column-management-TAGS-handle-btn'));
        fireEvent.dragStart(screen.getByTestId('table-column-management-item-TAGS'));
        requestAnimationFrame.step();

        fireEvent.dragOver(screen.getByTestId('table-column-management-STATUS-handle-btn'));
        fireEvent.drop(screen.getByTestId('table-column-management-STATUS-handle-btn'));

        expect(within(leftContainer).queryByTestId('table-column-management-dnd-item-TAGS')).not.toBeInTheDocument();
        expect(within(rightContainer).getByTestId('table-column-management-dnd-item-TAGS')).toBeInTheDocument();

        // Uncheck priority column
        const priorityCheckbox = screen.getByTestId(
            `table-column-management-item-checkbox-${TableColumnsUS.PRIORITY.id}`,
        );
        fireEvent.click(priorityCheckbox);
        expect(priorityCheckbox).not.toBeChecked();

        // on click of apply button, the failure toast should be shown in case of any failure
        const applyBtn = screen.getByTestId('table-column-management-drawer-apply-btn');
        fireEvent.click(applyBtn);
        await screen.findByText('Table columns ordering and visibility have been saved successfully.');
        expect(tableColumnManagement).not.toBeInTheDocument();

        expect(Array.from(tableHeaderFirstRow.children).map((element) => element.dataset.colId)).toEqual([
            'stride-table-checkbox',
            TableColumnsUS.PLAN_ID.id,
            TableColumnsUS.PLAN_TYPE.id,
            TableColumnsUS.TRAILER_ID.id,
            TableColumnsUS.ORIGIN_LOCATION_ID.id,
            TableColumnsUS.COMMENTS.id,
            TableColumnsUS.DISTANCE.id,
            TableColumnsUS.DESTINATION_LOCATION_ID.id,
            // TableColumnsUS.PRIORITY.id,
            TableColumnsUS.PLANNED_START.id,
            TableColumnsUS.PLANNED_END.id,
            TableColumnsUS.DURATION.id,
            TableColumnsUS.PICKUP_STOPS.id,
            TableColumnsUS.DELIVERY_STOPS.id,
            TableColumnsUS.TAGS.id,
            TableColumnsUS.STATUS.id,
            TableColumnsUS.ACTIONS.id,
        ]);
    });

    // depends upon previous test case which saves the data to GscopePreferencesStore
    it('should use the previously saved column visibility and reorder configs', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const searchResultsTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(searchResultsTableBody.children.length).toBeGreaterThan(0);
        });

        const searchResultsTableHeader = screen.getByTestId(SEARCH_RESULT_TABLE_HEAD_TEST_ID);
        const tableHeaderFirstRow = searchResultsTableHeader.children[0];

        expect(Array.from(tableHeaderFirstRow.children).map((element) => element.dataset.colId)).toEqual([
            'stride-table-checkbox',
            TableColumnsUS.PLAN_ID.id,
            TableColumnsUS.PLAN_TYPE.id,
            TableColumnsUS.TRAILER_ID.id,
            TableColumnsUS.ORIGIN_LOCATION_ID.id,
            TableColumnsUS.COMMENTS.id,
            TableColumnsUS.DISTANCE.id,
            TableColumnsUS.DESTINATION_LOCATION_ID.id,
            // TableColumnsUS.PRIORITY.id,
            TableColumnsUS.PLANNED_START.id,
            TableColumnsUS.PLANNED_END.id,
            TableColumnsUS.DURATION.id,
            TableColumnsUS.PICKUP_STOPS.id,
            TableColumnsUS.DELIVERY_STOPS.id,
            TableColumnsUS.TAGS.id,
            TableColumnsUS.STATUS.id,
            TableColumnsUS.ACTIONS.id,
        ]);
    });

    it('should show error toast when there is any issue in saving the data', async () => {
        GscopePreferencesStore.clear();
        server.use(
            rest.post('api/gateway/provider-userpref/pref', (req, res, ctx) => {
                return res(ctx.status(500));
            }),
        );

        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const searchResultsTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(searchResultsTableBody.children.length).toBeGreaterThan(0);
        });

        const tableActionMenuTrigger = screen.getByTestId('table-action-menu-trigger');
        fireEvent.click(tableActionMenuTrigger);

        fireEvent.click(screen.getByText('Manage columns'));

        const tableColumnManagement = screen.getByTestId('table-column-management');
        expect(tableColumnManagement).toBeVisible();

        // on click of apply button, the failure toast should be shown in case of success
        const applyBtn = screen.getByTestId('table-column-management-drawer-apply-btn');
        fireEvent.click(applyBtn);
        await screen.findByText('Failed to update table columns. Please try again.');
        expect(tableColumnManagement).toBeInTheDocument();
    });

    it('should not show table actions and render existing table when enableManageColumns is not set to true', async () => {
        TripSharedService.setConfig(null);
        const cmfConfigWithoutManageColumns = getUpdatedCMSConfig(updatedCMSConfig, { enableManageColumns: false });
        server.use(
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(cmfConfigWithoutManageColumns))),
        );

        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const searchResultsTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(searchResultsTableBody.children.length).toBeGreaterThan(0);
        });

        expect(screen.queryByTestId('table-action-menu-trigger')).not.toBeInTheDocument();
        expect(screen.queryByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).not.toBeInTheDocument();
    });
});
