export const resourceAssignReqMock = {
    payload: {
        resourceAssignmentStatus: 'RESOURCES_ASSIGNED',
        planId: 30003797,
        carrierId: '1000195825',
        resources: [
            {
                driverId: '875678',
                driverAttributes: [
                    {
                        key: 'name',
                        value: 'Driver Two',
                    },
                ],
            },
        ],
        equipments: [
            {
                equipmentId: 'GT11026',
                equipmentOwner: '1000195825',
                equipmentType: 'TRUCK',
                equipmentAttributes: [
                    {
                        name: 'license_plate_nbr',
                        value: 'ZIP123',
                    },
                    {
                        name: 'trailerAssignmentType',
                        value: '',
                    },
                ],
            },
        ],
        equipmentRequirements: [
            {
                equipmentType: '',
                equipmentAttributes: [],
            },
        ],
        plans: [
            {
                planId: '50002496',
                equipments: [],
                equipmentRequirements: [],
            },
            {
                planId: '50005797',
                equipments: [],
                equipmentRequirements: [],
            },
            {
                planId: '50006797',
                equipments: [],
                equipmentRequirements: [],
            },
        ],
    },
};
export const selectedTripMock = {
    isCarrierTripExist: true,
    isDispatcherTripExist: true,
    planId: 30003797,
    planEntity: 'TRIP',
    planStatus: {
        name: 'READY_FOR_DISPATCH',
        index: 3,
        desc: 'trip.status.ready.for.dispatch',
    },
    planWorkflowPhase: {
        name: 'DISPATCH',
        index: 2,
        desc: 'trip.workflow.phase.dispatch',
    },
    planTenderStatus: {
        name: 'ASSIGNED',
        index: 2,
        desc: 'tender.status.assigned',
    },
    planTenderPhase: {
        name: 'ACCEPTED_TRIPS',
        index: 2,
        desc: 'tender.phase.accepted.trips',
    },
    planCategory: '',
    laneAndRate: {
        laneId: '',
        rate: '',
        rateUOM: '',
        rateType: '',
    },
    origin: {
        locationId: 7406,
        locationType: 'DC',
        locationCity: 'GT',
        locationName: 'CD BARCENAS GT',
    },
    finalDestination: {
        locationId: 7406,
        locationType: 'DC',
        locationCity: 'GT',
        locationName: 'CD BARCENAS GT',
    },
    distance: {
        measurementValue: 72.99,
        unitOfMeasure: 'KM',
    },
    numberOfStops: 6,
    sizes: {
        cases: {
            measurementValue: 29,
            unitOfMeasure: 'EA',
        },
        cube: {
            measurementValue: 533.7205,
            unitOfMeasure: 'CFT',
        },
        pallets: {
            measurementValue: 4,
            unitOfMeasure: 'EA',
        },
        weight: {
            measurementValue: 11.89,
            unitOfMeasure: 'KG',
        },
    },
    carrier: {
        id: '1000195825',
        name: 'TRANSPORTES Y COMERCIAL MIRANDA?S',
        mode: 'TL',
        serviceLevel: 'DED',
        transaction_ts: '2022-09-29T01:00:32.177-05:00',
        updateBy: 'g0k028n',
    },
    schedules: {
        carrierPickupTs: '',
        carrierDueDateTs: '',
        carrierTenderTs: '2022-09-29T01:00:17.754-05:00',
        carrierMustRespondByTs: '2022-09-29T11:00:00.000-05:00',
        plannedCompletionTime: '2022-09-29T06:01:38.572Z',
        tripAcceptedTs: '',
        maxDueTs: '2022-09-30T21:00:00+05:30',
        minPickTs: '2022-09-30T10:00:00Z',
        createdTs: '2022-09-29T05:40:59.409Z',
        disptachTs: '',
    },
    equipmentRequirements: {
        trailerType: '',
        protectionLevel: '',
        length: {
            measurementValue: '',
            unitOfMeasure: '',
        },
    },
    equipment: {
        equipmentId: 'GT11026',
        equipmentType: 'TRUCK',
        tractorLicense: '',
        truckLicense: 'ZIP123',
        masterEquipmentType: '',
        equipmentLicense: 'ZIP123',
        plans: [
            {
                planId: '50002496',
                trailerLicense: '',
            },
            {
                planId: '50005797',
                trailerLicense: '',
            },
            {
                planId: '50006797',
                trailerLicense: '',
            },
        ],
        trailerAssignmentType: '',
    },
    driver: {
        name: 'Driver Two',
        id: '875678',
    },
    audit: {
        userId: 'SIMPLIROUTE_ADAPTER',
        createdByUserId: 'SIMPLIROUTE_ADAPTER',
        createdByUserName: 'SIMPLIROUTE_ADAPTER',
        createdSourceSystem: 'SIMPLIROUTE_ADAPTER',
        createdTs: '2022-09-29T05:40:59.409Z',
        lastUpdatedByUserId: 'g0k028n',
        lastUpdatedByUserName: 'Gaurav Kumar',
        lastUpdatedTs: '2022-09-29T05:55:40.511Z',
    },
    tariffReq: {
        origin: {
            locationId: 7406,
            locationType: 'DC',
            countryCode: 'GT',
            latitude: 14.532,
            longitude: -90.601,
            locationName: 'CD BARCENAS GT',
            addressLine1: 'KM 17 RUTA AL PACIFICO',
            addressLine2: 'KM 17 RUTA AL PACIFICO',
            city: 'GUATEMALA',
            postalCode: '001063',
            olsenTimezoneId: 'America/Guatemala',
        },
        destination: {
            locationId: 96,
            locationType: 'STORE',
            countryCode: 'GT',
            latitude: 14.3325,
            longitude: -91.024444,
            locationName: 'DF SANTA LUCIA',
            addressLine1: '3A AV 4-31, ZONA 1',
            addressLine2: '3A AV 4-31, ZONA 1',
            city: 'ESCUINTLA',
            postalCode: '005002',
            olsenTimezoneId: 'America/Guatemala',
        },
        transitDetail: {
            mode: 'TL',
            serviceLevel: 'DED',
            serviceType: 'DOMESTIC',
        },
        equipment: {
            equipmentCode: 'S10TON',
            length: {
                unitOfMeasure: 'M',
                measurementValue: 18.61,
            },
        },
    },
    childPlans: [
        {
            planId: 50002496,
            planEntity: 'LOAD',
            planStatus: {
                name: 'READY_FOR_DISPATCH',
                index: 4,
                desc: 'load.status.ready.for.dispatch',
            },
            planWorkflowPhase: {
                name: 'PLANNED',
                index: 0,
                desc: 'load.phase.planned',
            },
            planCategory: 'BKH',
            planSequence: 3,
            origin: {
                locationId: 351240,
                locationType: 'VNDR',
                locationCity: 'GT',
                locationName: 'Kimberly Clark Bodega 5',
            },
            finalDestination: {
                locationId: 7406,
                locationType: 'DC',
                locationCity: 'GT',
                locationName: 'CD BARCENAS GT',
            },
            distance: {
                measurementValue: 0,
                unitOfMeasure: 'KM',
            },
            numberOfStops: 2,
            sizes: {
                cases: {
                    measurementValue: 2,
                    unitOfMeasure: 'EA',
                },
                cube: {
                    measurementValue: 4,
                    unitOfMeasure: 'CFT',
                },
                pallets: {
                    measurementValue: 3,
                    unitOfMeasure: 'EA',
                },
                weight: {
                    measurementValue: 1,
                    unitOfMeasure: 'KG',
                },
            },
            carrier: {
                id: '',
                name: '',
                mode: '',
                serviceLevel: '',
            },
            schedules: {
                carrierPickupTs: '',
                carrierDueDateTs: '',
                carrierTenderTs: '',
                carrierMustRespondByTs: '',
                plannedCompletionTime: '',
                tripAcceptedTs: '',
                maxDueTs: '2022-09-30T21:00:00+05:30',
                minPickTs: '2022-09-30T18:00:00+05:30',
                createdTs: '2022-09-29T05:49:46.406Z',
            },
            equipmentRequirements: {
                trailerType: '',
                protectionLevel: 'D',
                length: {
                    measurementValue: 18.61,
                    unitOfMeasure: 'MR',
                },
                equipmentCode: 'S10TON',
            },
            equipment: {
                equipmentId: '',
                equipmentType: '',
                tractorLicense: '',
                truckLicense: '',
                masterEquipmentType: '',
                trailerLicense: '',
            },
            driver: {
                name: '',
                id: '',
            },
            audit: {
                userId: 'g0k028n',
                createdByUserId: 'g0k028n',
                createdByUserName: 'Gaurav Kumar',
                createdSourceSystem: 'g0k028n',
                createdTs: '2022-09-29T05:49:46.406Z',
                lastUpdatedByUserId: 'SIMPLIROUTE_ADAPTER',
                lastUpdatedByUserName: 'SIMPLIROUTE_ADAPTER',
                lastUpdatedTs: '2022-09-29T05:54:08.762Z',
            },
        },
        {
            planId: 50005797,
            planEntity: 'LOAD',
            planStatus: {
                name: 'READY_FOR_DISPATCH',
                index: 4,
                desc: 'load.status.ready.for.dispatch',
            },
            planWorkflowPhase: {
                name: 'PLANNED',
                index: 0,
                desc: 'load.phase.planned',
            },
            planCategory: 'STR',
            planSequence: 1,
            origin: {
                locationId: 7406,
                locationType: 'DC',
                locationCity: 'GT',
                locationName: 'CD BARCENAS GT',
            },
            finalDestination: {
                locationId: 96,
                locationType: 'STORE',
                locationCity: 'GT',
                locationName: 'DF SANTA LUCIA',
            },
            distance: {
                measurementValue: 0,
                unitOfMeasure: 'KM',
            },
            numberOfStops: 2,
            sizes: {
                cases: {
                    measurementValue: 27,
                    unitOfMeasure: 'EA',
                },
                cube: {
                    measurementValue: 529.7205,
                    unitOfMeasure: 'CFT',
                },
                pallets: {
                    measurementValue: 1,
                    unitOfMeasure: 'EA',
                },
                weight: {
                    measurementValue: 10.89,
                    unitOfMeasure: 'KG',
                },
            },
            carrier: {
                id: '',
                name: '',
                mode: '',
                serviceLevel: '',
            },
            schedules: {
                carrierPickupTs: '',
                carrierDueDateTs: '',
                carrierTenderTs: '',
                carrierMustRespondByTs: '',
                plannedCompletionTime: '',
                tripAcceptedTs: '',
                maxDueTs: '2022-09-30T11:18:00Z',
                minPickTs: '2022-09-30T10:00:00Z',
                createdTs: '2022-09-29T05:40:59.285Z',
            },
            equipmentRequirements: {
                trailerType: '',
                protectionLevel: '',
                length: {
                    measurementValue: 18.61,
                    unitOfMeasure: 'M',
                },
                equipmentCode: 'S10TON',
            },
            equipment: {
                equipmentId: '',
                equipmentType: '',
                tractorLicense: '',
                truckLicense: '',
                masterEquipmentType: '',
                trailerLicense: '',
            },
            driver: {
                name: '',
                id: '',
            },
            audit: {
                userId: 'SIMPLIROUTE_ADAPTER',
                createdByUserId: 'SIMPLIROUTE_ADAPTER',
                createdByUserName: 'SIMPLIROUTE_ADAPTER',
                createdSourceSystem: 'SIMPLIROUTE_ADAPTER',
                createdTs: '2022-09-29T05:40:59.285Z',
                lastUpdatedByUserId: 'SIMPLIROUTE_ADAPTER',
                lastUpdatedByUserName: 'SIMPLIROUTE_ADAPTER',
                lastUpdatedTs: '2022-09-29T05:40:59.285Z',
            },
        },
        {
            planId: 50006797,
            planEntity: 'LOAD',
            planStatus: {
                name: 'READY_FOR_DISPATCH',
                index: 4,
                desc: 'load.status.ready.for.dispatch',
            },
            planWorkflowPhase: {
                name: 'PLANNED',
                index: 0,
                desc: 'load.phase.planned',
            },
            planCategory: 'DHD',
            planSequence: 2,
            origin: {
                locationId: 96,
                locationType: 'STORE',
                locationCity: 'GT',
                locationName: '',
            },
            finalDestination: {
                locationId: 351240,
                locationType: 'VNDR',
                locationCity: 'GT',
                locationName: '',
            },
            distance: {
                measurementValue: 0,
                unitOfMeasure: 'KM',
            },
            numberOfStops: 2,
            sizes: {
                cases: {
                    measurementValue: 0,
                    unitOfMeasure: 'EA',
                },
                cube: {
                    measurementValue: 0,
                    unitOfMeasure: 'CR',
                },
                pallets: {
                    measurementValue: 0,
                    unitOfMeasure: 'EA',
                },
                weight: {
                    measurementValue: 0,
                    unitOfMeasure: 'KG',
                },
            },
            carrier: {
                id: '',
                name: '',
                mode: '',
                serviceLevel: '',
            },
            schedules: {
                carrierPickupTs: '',
                carrierDueDateTs: '',
                carrierTenderTs: '',
                carrierMustRespondByTs: '',
                plannedCompletionTime: '',
                tripAcceptedTs: '',
                maxDueTs: '2022-09-30T13:28:00Z',
                minPickTs: '2022-09-30T11:18:00Z',
                createdTs: '2022-09-29T05:54:08.706Z',
            },
            equipmentRequirements: {
                trailerType: '',
                protectionLevel: '',
                length: {
                    measurementValue: '',
                    unitOfMeasure: '',
                },
                equipmentCode: 'S10TON',
            },
            equipment: {
                equipmentId: '',
                equipmentType: '',
                tractorLicense: '',
                truckLicense: '',
                masterEquipmentType: '',
                trailerLicense: '',
            },
            driver: {
                name: '',
                id: '',
            },
            audit: {
                userId: 'SIMPLIROUTE_ADAPTER',
                createdByUserId: 'SIMPLIROUTE_ADAPTER',
                createdByUserName: 'SIMPLIROUTE_ADAPTER',
                createdSourceSystem: 'SIMPLIROUTE_ADAPTER',
                createdTs: '2022-09-29T05:54:08.706Z',
                lastUpdatedByUserId: 'SIMPLIROUTE_ADAPTER',
                lastUpdatedByUserName: 'SIMPLIROUTE_ADAPTER',
                lastUpdatedTs: '2022-09-29T05:54:08.706Z',
            },
        },
    ],
};

export const selectedTripMockWithChargeLoc = {
    ...selectedTripMock,
    childPlans: [
        {
            ...selectedTripMock.childPlans[0],
            chargeLocation: {
                locationId: '657',
            },
        },
    ],
};

export const selectedTripWithUpdateDestionationMock = {
    ...selectedTripMock,
    childPlans: [
        {
            ...selectedTripMock.childPlans[0],
            stops: [
                {
                    stopId: '4964',
                    stopSequenceNumber: 1,
                    sealIdentifiers: ['1'],
                    invoiceIdentifiers: ['1'],
                },
                {
                    stopId: '5090',
                    stopSequenceNumber: 3,
                    sealIdentifiers: ['1'],
                    invoiceIdentifiers: ['1'],
                },
                {
                    stopId: '5132',
                    stopSequenceNumber: 4,
                    sealIdentifiers: ['1'],
                    invoiceIdentifiers: ['1'],
                },
                {
                    stopId: '5162',
                    stopSequenceNumber: 2,
                    sealIdentifiers: ['1'],
                    invoiceIdentifiers: ['1'],
                },
            ],
        },
    ],
};

export const resourceAssignPayloadMock = {
    payload: {
        resourceAssignmentStatus: 'RESOURCES_ASSIGNED',
        planId: 30003797,
        carrierId: '1000195825',
        resources: [
            {
                driverId: '875678',
                driverAttributes: [
                    {
                        key: 'name',
                        value: 'Driver Two',
                    },
                ],
            },
        ],
        equipments: [
            {
                equipmentId: 'GT11026',
                equipmentOwner: '1000195825',
                equipmentType: 'TRUCK',
                equipmentAttributes: [
                    {
                        name: 'license_plate_nbr',
                        value: 'ZIP123',
                    },
                    {
                        name: 'trailerAssignmentType',
                        value: '',
                    },
                ],
            },
        ],
        equipmentRequirements: [
            {
                equipmentType: '',
                equipmentAttributes: [],
            },
        ],
        plans: [
            {
                planId: '50005797',
                equipments: [],
                equipmentRequirements: [],
            },
            {
                planId: '50006797',
                equipments: [],
                equipmentRequirements: [],
            },
            {
                planId: '50002496',
                equipments: [],
                equipmentRequirements: [],
            },
        ],
    },
};
export const loadDetailslsMock = {
    payload: {
        planDetails: {
            status: 'ACCEPTED',
            header: {
                headerAttributes: {},
            },
            errors: [],
            payload: {
                planStatus: 'PLANNED',
                relayIndicator: false,
                isApproved: true,
                stops: [
                    {
                        stopSequenceNumber: 1,
                        stopType: 'DROP',
                        expectedDwellTime: {
                            measurementValue: 90,
                            unitOfMeasure: 'MJ',
                        },
                        stopActivityType: 'PickLoaded',
                        location: {
                            locationId: 1937500,
                            locationType: 'SPLR',
                            countryCode: 'CA',
                            locationName: 'Scarborog',
                        },
                        minExpectedArrivalTs: '2022-10-15T19:51:59.234-06:00',
                        maxExpectedArrivalTs: '2022-10-15T19:51:59.234-06:00',
                        minExpectedDepartureTs: '2022-10-15T19:51:59.234-06:00',
                        maxExpectedDepartureTs: '2022-10-15T19:51:59.234-06:00',
                        driveDistanceToNextStop: {
                            unitOfMeasure: 'KM',
                            measurementValue: 200.0,
                        },
                        driveDurationToNextStop: {
                            unitOfMeasure: 'MJ',
                            measurementValue: 10.0,
                        },
                        units: [
                            {
                                identifiers: {
                                    unitId: 1000002395,
                                },
                            },
                        ],
                    },
                    {
                        stopSequenceNumber: 2,
                        stopType: '7',
                        stopActivityType: 'DropLoaded',
                        location: {
                            locationId: 7087,
                            locationType: 'STORE',
                            countryCode: 'CA',
                            locationName: 'Orangeville',
                        },
                        minExpectedArrivalTs: '2022-10-15T19:51:59.234-06:00',
                        maxExpectedArrivalTs: '2022-10-15T19:51:59.234-06:00',
                        minExpectedDepartureTs: '2022-10-15T19:51:59.234-06:00',
                        maxExpectedDepartureTs: '2022-10-15T19:51:59.234-06:00',
                        driveDistanceToNextStop: {
                            unitOfMeasure: 'KM',
                            measurementValue: 200.0,
                        },
                        driveDurationToNextStop: {
                            unitOfMeasure: 'MJ',
                            measurementValue: 10.0,
                        },
                        units: [
                            {
                                identifiers: {
                                    unitId: 1000002395,
                                },
                            },
                        ],
                    },
                ],
                equipment: {
                    equipmentCode: '876677',
                    equipmentType: 'CN',
                    length: {
                        unitOfMeasure: 'MR',
                        measurementValue: 53,
                    },
                    liftGate: true,
                    axle: 1,
                    temperatureSettings: {
                        zone1: {},
                    },
                },
                units: [
                    {
                        unitDetails: {
                            minTemp: {
                                unitOfMeasure: 'FH',
                                measurementValue: 0,
                            },
                            maxTemp: {
                                unitOfMeasure: 'FH',
                                measurementValue: 4,
                            },
                            hazmatFlag: false,
                            commodity: 'P',
                            protectionLevel: 'HT',
                            loadingDetails: {
                                loadingMethod: 'FLOOR',
                            },
                            totalCases: {
                                unitOfMeasure: 'EA',
                                measurementValue: 2,
                            },
                            totalWeight: {
                                unitOfMeasure: 'KG',
                                measurementValue: 2,
                            },
                            totalCube: {
                                unitOfMeasure: 'CUFT',
                                measurementValue: 2,
                            },
                            totalPallets: {
                                unitOfMeasure: 'PT',
                                measurementValue: 2,
                            },
                            idealTemp: {
                                unitOfMeasure: 'FH',
                                measurementValue: 10,
                            },
                            temperatureToleranceMins: {
                                unitOfMeasure: 'MIN',
                                measurementValue: 60,
                            },
                        },
                        poDetails: [
                            {
                                id: 630019224,
                            },
                        ],
                        schedule: {
                            minPickupTs: '2022-04-10T17:00:00.000+00:00',
                            maxPickupTs: '2022-04-10T17:00:00.000+00:00',
                            minDueTs: '2022-04-10T17:00:00.000+00:00',
                            maxDueTs: '2022-04-10T17:00:00.000+00:00',
                            mabdTs: '2022-04-10T17:00:00.000+00:00',
                            bookingCutOff: '2022-04-08T17:00:00.000+00:00',
                        },
                        identifiers: {
                            clientReferenceUnitId: '630019224_0',
                            groupNumber: 0,
                            deliveryOrderId: 70001395,
                            unitId: 1000002395,
                        },
                        locations: {
                            origin: {
                                locationId: 1937500,
                                locationType: 'SPLR',
                                countryCode: 'CA',
                            },
                            destination: {
                                locationId: 7087,
                                locationType: 'DC',
                                countryCode: 'CA',
                            },
                        },
                        provenance: {
                            createdTs: '2022-01-10T19:31:15.917-06:00',
                            lastUpdatedTs: '2022-01-10T19:31:15.918-06:00',
                            createdByUserId: 'STRIDE_TMS',
                            createdByUserName: 'STRIDE_TMS',
                            lastUpdatedByUserId: 'STRIDE_TMS',
                            lastUpdatedByUserName: 'STRIDE_TMS',
                            createdSourceSystem: 'CS',
                        },
                        unitStatus: 'UNPLANNED',
                    },
                ],
                schedule: {
                    minPickupTs: '2022-10-15T19:51:59.234-06:00',
                    maxPickupTs: '2022-05-18T19:51:59.234-06:00',
                    minDueTs: '2022-10-15T19:51:59.234-06:00',
                    maxDueTs: '2022-10-15T19:51:59.234-06:00',
                },
                planDetails: {
                    channelType: 'Retail',
                    programType: 'Collect',
                    ibob: 'Outbound',
                    isHazmat: true,
                    priority: 'MEDIUM',
                },
                planCategory: 'Store Replenishment',
                identifiers: {
                    tenantId: 'CA_CA',
                    optimiserPlanReferenceId: '1936faa0-c931-11eb-b8bc-0242ac130003',
                    deliveryOrderId: [70001395],
                    planId: 50042395,
                },
                provenance: {
                    createdTs: '2022-01-12T07:43:58.796+00:00',
                    lastUpdatedTs: '2022-01-12T07:43:58.796+00:00',
                    createdByUserId: 'STRIDE_TMS',
                    createdByUserName: 'STRIDE_TMS',
                    lastUpdatedByUserId: 'STRIDE_TMS',
                    lastUpdatedByUserName: 'STRIDE_TMS',
                    createdSourceSystem: 'STRIDE_TMS',
                },
                locations: {
                    origin: {
                        locationId: 1937500,
                        locationType: 'SPLR',
                        countryCode: 'CA',
                        locationName: 'Scarborog',
                    },
                    destination: {
                        locationId: 7087,
                        locationType: 'DC',
                        countryCode: 'CA',
                        locationName: 'Orangeville',
                    },
                },
                planAggregates: {
                    odDistance: {
                        unitOfMeasure: 'KM',
                        measurementValue: 881.3,
                    },
                    orDistance: {
                        unitOfMeasure: 'KM',
                        measurementValue: 537.01,
                    },
                    totalCases: {
                        unitOfMeasure: 'EA',
                        measurementValue: 2,
                    },
                    totalWeight: {
                        unitOfMeasure: 'KG',
                        measurementValue: 2,
                    },
                    totalCube: {
                        unitOfMeasure: 'CR',
                        measurementValue: 2,
                    },
                    totalPallets: {
                        unitOfMeasure: 'EA',
                        measurementValue: 2,
                    },
                    totalDuration: {
                        unitOfMeasure: 'MJ',
                        measurementValue: 20.0,
                    },
                    totalDistance: {
                        unitOfMeasure: 'KM',
                        measurementValue: 400.0,
                    },
                    totalWMSPallets: {
                        unitOfMeasure: 'EA',
                        measurementValue: 0,
                    },
                    totalStops: 2,
                    totalPickUpStops: 1,
                    totalDeliveryStops: 1,
                },
                transitDetail: {
                    mode: 'TL',
                    serviceLevel: 'SGL',
                    protectionLevel: 'P',
                    serviceType: '007600',
                    serviceClass: 'IM',
                },
            },
        },
        tntCore: {
            trackingId: '30004134',
            trackingIdType: 'LOAD',
            parentTrackingId: null,
            parentTrackingIdType: null,
            altTrackingId: '12345',
            altTrackingIdType: 'FOURKITES',
            planStatus: 'ACCEPTED',
            enrouteStatus: null,
            inTransitStatus: 'Early',
            lastUpdateTs: 1598869012000,
            timeElapsedSinceLastPing: null,
            estTransitTime: {
                value: 0,
                unit: 'MIN',
            },
            estTransitDistance: {
                value: 30,
                unit: 'MILE',
            },
            estWaitTime: null,
            actWaitTime: {
                value: 0,
                unit: null,
            },
            stops: [
                {
                    stopId: '6001',
                    stopType: 'DC',
                    activityType: 'PICKUP',
                    stopSeqNumber: 1,
                    status: null,
                    arrivalStatus: null,
                    estTransitTime: {
                        value: 10,
                        unit: 'MIN',
                    },
                    estTransitDistance: {
                        value: 10,
                        unit: 'MILE',
                    },
                    estWaitTime: null,
                    actWaitTime: null,
                    actWaitTimeUnit: null,
                    planned: {
                        arrivalTsBegin: 1639386020000,
                        arrivalTsEnd: 1639386020000,
                        departureTs: 1639386020000,
                        arrivalTsSource: 'STRIDE_CST',
                        departureTsSource: 'STRIDE_CST',
                    },
                    estimated: {
                        arrivalTs: null,
                        departureTs: null,
                        arrivalTsSource: null,
                        departureTsSource: null,
                    },
                    actual: {
                        arrivalTs: 1599017992000,
                        departureTs: 1599017992000,
                        arrivalTsSource: 'PLATFORM',
                        departureTsSource: 'PLATFORM',
                    },
                    stopTimezone: 'Chile/Continental',
                    reasonCodes: [],
                    isActive: true,
                },
                {
                    stopId: '393',
                    stopType: 'DC',
                    activityType: 'DELIVERY',
                    stopSeqNumber: 2,
                    status: null,
                    arrivalStatus: 'Early',
                    estTransitTime: {
                        value: 10,
                        unit: 'MIN',
                    },
                    estTransitDistance: {
                        value: 10,
                        unit: 'MILE',
                    },
                    estWaitTime: null,
                    actWaitTime: null,
                    actWaitTimeUnit: null,
                    planned: {
                        arrivalTsBegin: 1639386020000,
                        arrivalTsEnd: 1639386020000,
                        departureTs: 1639386020000,
                        arrivalTsSource: 'STRIDE_CST',
                        departureTsSource: 'STRIDE_CST',
                    },
                    estimated: {
                        arrivalTs: 1598990752000,
                        departureTs: 1598990752000,
                        arrivalTsSource: 'PLATFORM',
                        departureTsSource: 'PLATFORM',
                    },
                    actual: {
                        arrivalTs: 1599017992000,
                        departureTs: 1599017992000,
                        arrivalTsSource: 'PLATFORM',
                        departureTsSource: 'PLATFORM',
                    },
                    stopTimezone: 'Chile/Continental',
                    reasonCodes: [],
                    isActive: false,
                },
                {
                    stopId: '751',
                    stopType: 'STORE',
                    activityType: 'DELIVERY',
                    stopSeqNumber: 3,
                    status: null,
                    arrivalStatus: 'Early',
                    estTransitTime: {
                        value: 10,
                        unit: 'MIN',
                    },
                    estTransitDistance: {
                        value: 10,
                        unit: 'MILE',
                    },
                    estWaitTime: null,
                    actWaitTime: null,
                    actWaitTimeUnit: null,
                    planned: {
                        arrivalTsBegin: 1639386020000,
                        arrivalTsEnd: 1639386020000,
                        departureTs: 1639386020000,
                        arrivalTsSource: 'STRIDE_CST',
                        departureTsSource: 'STRIDE_CST',
                    },
                    estimated: {
                        arrivalTs: 1599017992000,
                        departureTs: 1599017992000,
                        arrivalTsSource: 'PLATFORM',
                        departureTsSource: 'PLATFORM',
                    },
                    actual: {
                        arrivalTs: 1599017992000,
                        departureTs: 1599017992000,
                        arrivalTsSource: 'PLATFORM',
                        departureTsSource: 'PLATFORM',
                    },
                    stopTimezone: 'Chile/Continental',
                    reasonCodes: [],
                    isActive: false,
                },
            ],
            pos: null,
            units: null,
            currentLocation: null,
        },
        etaDetails: {
            uncrossedLoadStops: [
                {
                    tripId: '26207868',
                    loadId: '30001882',
                    uncrossedStops: [
                        {
                            stopId: '3615',
                            stopType: 'STORE',
                            tripStopSeqNbr: 4,
                            loadStopSeqNbr: 4,
                            eta: 1635932609579,
                            etaSourceSystem: 'PLATFORM',
                            etaType: 'EXECUTION',
                            distanceMetres: 38,
                            driveTimeMinutes: 0,
                            estimatedRoute: null,
                        },
                        {
                            stopId: '3327',
                            stopType: 'STORE',
                            tripStopSeqNbr: 5,
                            loadStopSeqNbr: 5,
                            eta: 1635936038689,
                            etaSourceSystem: 'PLATFORM',
                            etaType: 'EXECUTION',
                            distanceMetres: 4903,
                            driveTimeMinutes: 10,
                            estimatedRoute: null,
                        },
                        {
                            stopId: '5863',
                            stopType: 'STORE',
                            tripStopSeqNbr: 3,
                            loadStopSeqNbr: 3,
                            eta: 1635929534606,
                            etaSourceSystem: 'PLATFORM',
                            etaType: 'EXECUTION',
                            distanceMetres: 111,
                            driveTimeMinutes: 1,
                            estimatedRoute: null,
                        },
                        {
                            stopId: '3430',
                            stopType: 'STORE',
                            tripStopSeqNbr: 2,
                            loadStopSeqNbr: 2,
                            eta: 1635927910906,
                            etaSourceSystem: 'PLATFORM',
                            etaType: 'EXECUTION',
                            distanceMetres: 2403,
                            driveTimeMinutes: 11,
                            estimatedRoute: null,
                        },
                    ],
                    travelMode: 'TRUCK',
                    estimatedRoute: null,
                },
            ],
        },
        trace: {
            loadId: '50000179',
            driverLocHistPolyline: 'yjt|Enak~Pdhs@q_N',
            tracingOutputStopDTOS: [
                {
                    startStopId: '6722201',
                    endStopId: '1451400',
                    driverHistPolyline: 'yjt|Enak~P',
                    hasArrived: true,
                },
                {
                    startStopId: '1451400',
                    endStopId: '6722201',
                    driverHistPolyline: 'sa`{E|`|}P',
                    hasArrived: false,
                },
            ],
        },
        planTenderDetails: {
            planStatus: 'Tender Accepted',
            identifiers: {
                tenantId: 'CL',
                planId: 30069635,
                parentPlanId: null,
                clientReferencePlanId: null,
                clientRequestId: null,
                sequence: null,
                businessId: '30069635',
                partitionKey: null,
            },
            locations: {
                origin: {
                    locationId: 6001,
                    locationType: 'DC',
                    countryCode: 'CL',
                    latitude: null,
                    longitude: null,
                    externalLocationId: null,
                },
                destination: {
                    locationId: 679,
                    locationType: 'STORE',
                    countryCode: 'CL',
                    latitude: null,
                    longitude: null,
                    externalLocationId: null,
                },
            },
            activities: [
                {
                    activityType: '3',
                    activityId: '7975e852-f142-413e-a8e6-b7f9c3dcbbb6',
                    activitySequenceNumber: 1,
                    stopSequenceNumber: 1,
                    activityDuration: null,
                    driveDistance: null,
                    driveDuration: null,
                    location: {
                        locationId: 6001,
                        locationType: 'STORE',
                        countryCode: 'CL',
                        latitude: null,
                        longitude: null,
                        externalLocationId: null,
                    },
                    arrivalTs: null,
                    departureTs: null,
                    planIds: [50089807],
                    equipmentIds: null,
                },
                {
                    activityType: '7',
                    activityId: '69723043-03d9-444b-bdd6-46ac851a4460',
                    activitySequenceNumber: 2,
                    stopSequenceNumber: 2,
                    activityDuration: null,
                    driveDistance: null,
                    driveDuration: null,
                    location: {
                        locationId: 393,
                        locationType: 'STORE',
                        countryCode: 'CL',
                        latitude: null,
                        longitude: null,
                        externalLocationId: null,
                    },
                    arrivalTs: null,
                    departureTs: null,
                    planIds: [50089807],
                    equipmentIds: null,
                },
                {
                    activityType: '7',
                    activityId: '23a642de-2225-4e05-989e-8d3dd71eb837',
                    activitySequenceNumber: 3,
                    stopSequenceNumber: 3,
                    activityDuration: null,
                    driveDistance: null,
                    driveDuration: null,
                    location: {
                        locationId: 679,
                        locationType: 'STORE',
                        countryCode: 'CL',
                        latitude: null,
                        longitude: null,
                        externalLocationId: null,
                    },
                    arrivalTs: null,
                    departureTs: null,
                    planIds: [50089807],
                    equipmentIds: null,
                },
            ],
            plans: [
                {
                    planStatus: 'PLANNED',
                    identifiers: {
                        tenantId: 'CL',
                        planId: 50089807,
                        parentPlanId: 30069635,
                        clientReferencePlanId: null,
                        clientRequestId: null,
                        sequence: null,
                        businessId: null,
                        partitionKey: null,
                    },
                    relayIndicator: false,
                    locations: {
                        origin: {
                            locationId: 6001,
                            locationType: 'DC',
                            countryCode: 'CL',
                            latitude: null,
                            longitude: null,
                            externalLocationId: null,
                        },
                        destination: {
                            locationId: 679,
                            locationType: 'STORE',
                            countryCode: 'CL',
                            latitude: null,
                            longitude: null,
                            externalLocationId: null,
                        },
                    },
                    stops: [
                        {
                            stopSequenceNumber: 1,
                            stopType: '3',
                            location: {
                                locationId: 6001,
                                locationType: 'DC',
                                countryCode: 'CL',
                                latitude: null,
                                longitude: null,
                                externalLocationId: null,
                            },
                            driveDistance: null,
                            driveDuration: null,
                            liveIndicator: null,
                            appointmentTypeCode: null,
                            expectedArrivalStartTs: null,
                            expectedArrivalEndTs: null,
                            expectedDepartureStartTs: null,
                            expectedDepartureEndTs: null,
                            actualArrivalTs: null,
                            actualDepartureTs: null,
                            appointmentBeginTs: null,
                            appointmentEndTs: null,
                        },
                        {
                            stopSequenceNumber: 2,
                            stopType: '7',
                            location: {
                                locationId: 393,
                                locationType: 'STORE',
                                countryCode: 'CL',
                                latitude: null,
                                longitude: null,
                                externalLocationId: null,
                            },
                            driveDistance: null,
                            driveDuration: null,
                            liveIndicator: null,
                            appointmentTypeCode: null,
                            expectedArrivalStartTs: null,
                            expectedArrivalEndTs: null,
                            expectedDepartureStartTs: null,
                            expectedDepartureEndTs: null,
                            actualArrivalTs: null,
                            actualDepartureTs: null,
                            appointmentBeginTs: null,
                            appointmentEndTs: null,
                        },
                        {
                            stopSequenceNumber: 3,
                            stopType: '7',
                            location: {
                                locationId: 679,
                                locationType: 'STORE',
                                countryCode: 'CL',
                                latitude: null,
                                longitude: null,
                                externalLocationId: null,
                            },
                            driveDistance: null,
                            driveDuration: null,
                            liveIndicator: null,
                            appointmentTypeCode: null,
                            expectedArrivalStartTs: null,
                            expectedArrivalEndTs: null,
                            expectedDepartureStartTs: null,
                            expectedDepartureEndTs: null,
                            actualArrivalTs: null,
                            actualDepartureTs: null,
                            appointmentBeginTs: null,
                            appointmentEndTs: null,
                        },
                    ],
                    equipment: {
                        equipmentId: null,
                        equipmentCode: 'DOLLY',
                        equipmentType: 'P',
                        length: {
                            unitOfMeasure: 'MR',
                            measurementValue: 53,
                        },
                        height: null,
                        width: null,
                    },
                    units: [
                        {
                            type: null,
                            provenance: {
                                createdBy: null,
                                lastUpdatedBy: null,
                                createdSourceSystem: 'p0g00ss',
                                lastupdatedSourceSystem: null,
                                updatedBy: null,
                                lastCreatedTs: null,
                                lastUpdatedTs: '2022-01-07T19:07:45.822+05:30',
                            },
                            locations: {
                                origin: {
                                    locationId: 6001,
                                    locationType: 'DC',
                                    countryCode: 'CL',
                                    latitude: null,
                                    longitude: null,
                                    externalLocationId: null,
                                },
                                destination: {
                                    locationId: 393,
                                    locationType: 'STORE',
                                    countryCode: 'CL',
                                    latitude: null,
                                    longitude: null,
                                    externalLocationId: null,
                                },
                            },
                            unitDetails: {
                                productCount: null,
                                minTemp: null,
                                maxTemp: null,
                                isHazmat: false,
                                mode: 'TL',
                                commodity: 'G',
                                protectionLevel: 'P',
                                serviceLevel: 'DEDICATED',
                                loadingMethod: null,
                                totalCases: {
                                    unitOfMeasure: 'EA',
                                    measurementValue: 45,
                                },
                                totalWeight: null,
                                totalVolume: null,
                                totalPallets: null,
                                customerCode: null,
                            },
                            products: null,
                            schedule: null,
                            identifiers: {
                                tenantId: 'CL',
                                unitId: 1000168807,
                                clientReferenceUnitId: null,
                                groupNumber: null,
                                purchaseOrderId: null,
                            },
                            references: null,
                            preferredRailLegCarrier: null,
                        },
                        {
                            type: null,
                            provenance: {
                                createdBy: null,
                                lastUpdatedBy: null,
                                createdSourceSystem: 'p0g00ss',
                                lastupdatedSourceSystem: null,
                                updatedBy: null,
                                lastCreatedTs: null,
                                lastUpdatedTs: '2022-01-07T19:07:45.822+05:30',
                            },
                            locations: {
                                origin: {
                                    locationId: 6001,
                                    locationType: 'DC',
                                    countryCode: 'CL',
                                    latitude: null,
                                    longitude: null,
                                    externalLocationId: null,
                                },
                                destination: {
                                    locationId: 679,
                                    locationType: 'STORE',
                                    countryCode: 'CL',
                                    latitude: null,
                                    longitude: null,
                                    externalLocationId: null,
                                },
                            },
                            unitDetails: {
                                productCount: null,
                                minTemp: null,
                                maxTemp: null,
                                isHazmat: false,
                                mode: 'TL',
                                commodity: 'G',
                                protectionLevel: 'P',
                                serviceLevel: 'DEDICATED',
                                loadingMethod: null,
                                totalCases: {
                                    unitOfMeasure: 'EA',
                                    measurementValue: 45,
                                },
                                totalWeight: null,
                                totalVolume: null,
                                totalPallets: null,
                                customerCode: null,
                            },
                            products: null,
                            schedule: null,
                            identifiers: {
                                tenantId: 'CL',
                                unitId: 1000169807,
                                clientReferenceUnitId: null,
                                groupNumber: null,
                                purchaseOrderId: null,
                            },
                            references: null,
                            preferredRailLegCarrier: null,
                        },
                    ],
                    schedule: {
                        minPickupTs: '2022-10-08T19:51:59.234-06:00',
                        maxPickupTs: '2022-10-08T19:51:59.234-06:00',
                        actualPickupTs: null,
                        minDueTs: '2022-10-12T19:51:59.234-06:00',
                        maxDueTs: '2022-10-12T19:51:59.234-06:00',
                        actualDeliveryTs: null,
                        mustDepartByTs: null,
                        mabdTs: '2022-10-12T19:51:59.234-06:00',
                        cancelTs: null,
                    },
                    provenance: {
                        createdBy: null,
                        lastUpdatedBy: null,
                        createdSourceSystem: 'p0g00ss',
                        lastupdatedSourceSystem: null,
                        updatedBy: null,
                        lastCreatedTs: null,
                        lastUpdatedTs: '2022-01-07T19:07:45.822+05:30',
                    },
                    transitDetail: {
                        mode: 'TL',
                        serviceLevel: 'DEDICATED',
                        protectionLevel: 'P',
                        dispatchOffice: null,
                        commodity: null,
                    },
                    planCategory: 'STR',
                    planAggregates: {
                        totalCases: {
                            unitOfMeasure: 'EA',
                            measurementValue: 90,
                        },
                        totalWeight: {
                            unitOfMeasure: 'KG',
                            measurementValue: 0,
                        },
                        totalVolume: null,
                        totalPallets: {
                            unitOfMeasure: 'EA',
                            measurementValue: 0,
                        },
                    },
                },
            ],
            carrier: [
                {
                    createdBy: 't0k02w6',
                    lastUpdatedBy: 't0k02w6',
                    scac: '',
                    carrierId: '',
                    mode: 'TL',
                    serviceLevel: 'DED',
                    protectionLevel: 'I',
                    status: 'ASSIGNED',
                    assignedTs: '2022-01-07T07:33:41.030-06:00',
                    pickupTs: '2022-10-08T19:51:59.234-06:00',
                    dueTs: '2022-10-12T19:51:59.234-06:00',
                    mustRespondByDateTime: '2022-01-07T07:53:41.261-06:00',
                    transaction_ts: '2022-01-07T07:33:41.261-06:00',
                    carrierName: 'JB Hunt',
                    rate: '99',
                    rateUOM: 'CAD',
                    carrierOrigin: {
                        city: 'Scarborogh',
                        state: 'Toronto',
                    },
                    carrierDestination: {
                        city: 'Orangeville',
                        state: 'Ontario',
                    },
                },
            ],
            schedule: {
                minPickupTs: '2022-10-08T19:51:59.234-06:00',
                maxPickupTs: '2022-10-08T19:51:59.234-06:00',
                actualPickupTs: null,
                minDueTs: '2022-10-12T19:51:59.234-06:00',
                maxDueTs: '2022-10-12T19:51:59.234-06:00',
                actualDeliveryTs: null,
                mustDepartByTs: '2022-10-08T19:51:59.234-06:00',
                mabdTs: '2022-10-12T19:51:59.234-06:00',
                cancelTs: null,
            },
            references: [
                {
                    referenceKey: 'routeNumber',
                    referenceValue: '3113',
                    referenceValueType: 'INTEGER',
                },
            ],
            provenance: {
                createdBy: 'not-provided',
                lastUpdatedBy: 'not-provided',
                createdSourceSystem: 'p0g00ss',
                lastupdatedSourceSystem: 'not-provided',
                updatedBy: null,
                lastCreatedTs: '2022-01-07T13:37:53.839Z',
                lastUpdatedTs: '2022-01-07T13:37:53.839Z',
            },
            flowId: 'readyToBePublish',
            id: '929004070914523136',
            partitionKey: 'CL:807',
            planAggregates: {
                totalCases: {
                    unitOfMeasure: 'EA',
                    measurementValue: 90,
                },
                totalWeight: {
                    unitOfMeasure: 'KG',
                    measurementValue: 0,
                },
                totalVolume: null,
                totalPallets: {
                    unitOfMeasure: 'EA',
                    measurementValue: 0,
                },
            },
            coherenceList: [
                {
                    source: 'STRIDE_TMS',
                    sourceEvent: 'TENDER_CREATE',
                    sourceEventTs: 1641562230560,
                    emittedEvent: 'Created',
                    version: 1641562231086,
                },
                {
                    source: 'STRIDE_TMS',
                    sourceEvent: 'TENDER_CREATE',
                    sourceEventTs: 1641562241509,
                    emittedEvent: 'Created',
                    version: 1641562241762,
                },
                {
                    source: 'STRIDE_TMS',
                    sourceEvent: 'ASSIGN_CARRIER',
                    sourceEventTs: 1641562420471,
                    emittedEvent: 'Assigned',
                    version: 1641562421261,
                },
                {
                    source: 'STRIDE_TMS',
                    sourceEvent: 'TENDER_CREATE',
                    sourceEventTs: 1641562673154,
                    emittedEvent: 'Assigned',
                    version: 1641562673839,
                },
            ],
        },
        planResourceDetails: {
            messages: null,
            resourceAssignmentDTO: {
                planId: 'string',
                planStatus: 'IN_TRANSIT',
                carrierId: '',
                documentType: 'string',
                resourceAssignmentStatus: 'RESOURCES_ASSIGN_IN_PROGRESS',
                resources: [],
                hasWMSFinalized: true,
                planCategory: null,
                planVersion: null,
                plans: [],
                equipments: [
                    {
                        equipmentAttributes: [
                            {
                                name: 'EquipmentConfigurationId',
                                value: '123545',
                            },
                            {
                                name: 'temperatureControl',
                                value: 'Ambient',
                            },
                            {
                                name: 'equipmentLength',
                                value: '54',
                            },
                            {
                                name: 'numberOfAxles',
                                value: 'Tandem',
                            },
                            {
                                name: 'doorType',
                                value: 'Single',
                            },
                            {
                                name: 'equipmentLiftGate',
                                value: 'Yes',
                            },
                        ],
                        equipmentId: '987971',
                        equipmentOwner: 'string',
                        equipmentType: 'string',
                    },
                ],
                provenance: {
                    createdBy: 'string',
                    createdByUserName: 'string',
                    createdSourceSystem: 'string',
                    createdTs: 'string',
                    lastUpdatedBy: 'string',
                    lastUpdatedByName: 'string',
                    lastUpdatedTs: 'string',
                },
                dates: [
                    {
                        dateType: 'RESOURCE_ASSIGNMENT_CREATED_DATE',
                        dateValue: '2022-01-13T04:27:59.478Z',
                    },
                ],
            },
            status: null,
        },
        staticData: {
            status: 'OK',
            header: {
                headerAttributes: {},
            },
            errors: [],
            payload: {
                staticData: {
                    deliveryOrderType: [
                        {
                            id: 1,
                            code: 'INBOUND',
                            abbr: 'Inbound',
                            description: 'Inbound',
                        },
                        {
                            id: 2,
                            code: 'OUTBOUND',
                            abbr: 'Outbound',
                            description: 'Outbound',
                        },
                        {
                            id: 3,
                            code: 'OTHER',
                            abbr: 'Other',
                            description: 'Other',
                        },
                    ],
                    serviceType: [
                        {
                            id: 1,
                            code: 'DOMESTIC',
                            abbr: 'Domestic',
                            description: 'Domestic',
                        },
                        {
                            id: 2,
                            code: 'INTERNATIONAL',
                            abbr: 'International',
                            description: 'International',
                        },
                    ],
                    orderType: [
                        {
                            id: 1,
                            code: 'SPRL',
                            abbr: 'Store Replenishment',
                            description: 'Store Replenishment',
                        },
                        {
                            id: 2,
                            code: 'DRPL',
                            abbr: 'DC Replenishment',
                            description: 'DC Replenishment',
                        },
                        {
                            id: 3,
                            code: 'NWM',
                            abbr: 'Non Walmart Freight',
                            description: 'Non Walmart Freight',
                        },
                        {
                            id: 4,
                            code: 'OTH',
                            abbr: 'Other',
                            description: 'Other',
                        },
                    ],
                    deliveryCPIneligibleReasonCode: [
                        {
                            id: 1,
                            code: 'AUTO',
                            abbr: 'Auto',
                            description: 'Auto',
                        },
                        {
                            id: 2,
                            code: 'Manual',
                            abbr: 'Manual',
                            description: 'Manual',
                        },
                    ],
                    city: [
                        {
                            id: 1,
                            code: 'ALM',
                            abbr: 'Alma',
                            description: 'Alma',
                        },
                    ],
                    postalCode: [
                        {
                            id: 1,
                            code: '1234',
                            abbr: '1234',
                            description: '1234',
                        },
                        {
                            id: 2,
                            code: '134556',
                            abbr: '134556',
                            description: '134556',
                        },
                    ],
                    orderStatus: [
                        {
                            id: 1,
                            code: 'SUB',
                            abbr: 'Submitted',
                            description: 'Submitted',
                        },
                        {
                            id: 2,
                            code: 'REL',
                            abbr: 'Released',
                            description: 'Released',
                        },
                        {
                            id: 3,
                            code: 'CAN',
                            abbr: 'Cancelled',
                            description: 'Cancelled',
                        },
                    ],
                    planStatus: [
                        {
                            id: 1,
                            code: 'UNPLANNED',
                            abbr: 'UNPLANNED',
                            description: 'UNPLANNED',
                        },
                        {
                            id: 2,
                            code: 'PLANNED',
                            abbr: 'PLANNED',
                            description: 'PLANNED',
                        },
                        {
                            id: 3,
                            code: 'CANCELLED',
                            abbr: 'CANCELLED',
                            description: 'CANCELLED',
                        },
                        {
                            id: 4,
                            code: 'CREATED',
                            abbr: 'PENDING APPROVAL',
                            description: 'PENDING APPROVAL',
                        },
                        {
                            id: 5,
                            code: 'WORKLOAD_ASSIGNMENT',
                            abbr: 'WORKLOAD ASSIGNMENT',
                            description: 'WORKLOAD ASSIGNMENT',
                        },
                        {
                            id: 6,
                            code: 'AWAITING_FINALIZATION',
                            abbr: 'AWAITING FINALIZATION',
                            description: 'AWAITING FINALIZATION',
                        },
                        {
                            id: 7,
                            code: 'READY_FOR_DISPATCH',
                            abbr: 'READY FOR DISPATCH',
                            description: 'READY FOR DISPATCH',
                        },
                        {
                            id: 8,
                            code: 'IN_TRANSIT',
                            abbr: 'IN TRANSIT',
                            description: 'IN TRANSIT',
                        },
                        {
                            id: 9,
                            code: 'POST_PROCESSING',
                            abbr: 'POST PROCESSING',
                            description: 'POST PROCESSING',
                        },
                    ],
                    channelType: [
                        {
                            id: 1,
                            code: 'RTL',
                            abbr: 'Retail',
                            description: 'Retail',
                        },
                        {
                            id: 2,
                            code: 'ECOM',
                            abbr: 'eCommerce',
                            description: 'eCommerce',
                        },
                        {
                            id: 3,
                            code: 'IMPT',
                            abbr: 'Imports',
                            description: 'Imports',
                        },
                        {
                            id: 4,
                            code: 'T4H',
                            abbr: 'T4H',
                            description: 'T4H',
                        },
                        {
                            id: 5,
                            code: 'OTH',
                            abbr: 'Other',
                            description: 'Other',
                        },
                    ],
                    doAttributes: [
                        {
                            id: 1,
                            code: 'DC',
                            abbr: 'Distribution Centre',
                            description: 'Distribution Centre',
                        },
                        {
                            id: 2,
                            code: 'CP',
                            abbr: 'Centre Point',
                            description: 'Centre Point',
                        },
                        {
                            id: 3,
                            code: 'ST',
                            abbr: 'Store',
                            description: 'Store',
                        },
                        {
                            id: 4,
                            code: 'ECOM',
                            abbr: 'eCommerce',
                            description: 'eCommerce',
                        },
                        {
                            id: 5,
                            code: 'ECMDC',
                            abbr: 'eCommerce DC',
                            description: 'eCommerce DC',
                        },
                        {
                            id: 6,
                            code: 'COL',
                            abbr: 'Collect',
                            description: 'DSD',
                        },
                        {
                            id: 7,
                            code: 'DRPL',
                            abbr: 'DC Replenishment',
                            description: 'DC Replenishment',
                        },
                        {
                            id: 8,
                            code: 'IB',
                            abbr: 'Inbound',
                            description: 'Inbound',
                        },
                        {
                            id: 9,
                            code: 'IMPT',
                            abbr: 'Imports',
                            description: 'Imports',
                        },
                        {
                            id: 10,
                            code: 'RETL',
                            abbr: 'Retail',
                            description: 'Retail',
                        },
                        {
                            id: 11,
                            code: 'SPLR',
                            abbr: 'Supplier',
                            description: 'Supplier',
                        },
                        {
                            id: 12,
                            code: 'WM',
                            abbr: 'Walmart',
                            description: 'Walmart',
                        },
                        {
                            id: 13,
                            code: 'NWM',
                            abbr: 'Non Walmart Freight',
                            description: 'Non Walmart Freight',
                        },
                        {
                            id: 14,
                            code: 'RDC',
                            abbr: 'Regional DC',
                            description: 'Regional DC',
                        },
                        {
                            id: 15,
                            code: 'SC',
                            abbr: 'SuperCentre',
                            description: 'SuperCentre',
                        },
                        {
                            id: 16,
                            code: 'OTH',
                            abbr: 'Other',
                            description: 'Other',
                        },
                        {
                            id: 17,
                            code: 'REQ',
                            abbr: 'Requestor Team',
                            description: 'Requestor Team',
                        },
                        {
                            id: 18,
                            code: 'WFP',
                            abbr: 'WFP Team',
                            description: 'WFP Team',
                        },
                        {
                            id: 18,
                            code: 'IB_TEAM',
                            abbr: 'Inbound Team',
                            description: 'Inbound Team',
                        },
                    ],
                    reasonCodes: [
                        {
                            id: 1,
                            code: 'DC',
                            abbr: 'DC',
                            description: 'DC',
                        },
                        {
                            id: 2,
                            code: 'STORE',
                            abbr: 'STORE',
                            description: 'Store',
                        },
                        {
                            id: 3,
                            code: 'CARRIER',
                            abbr: 'CARRIER',
                            description: 'Carrier',
                        },
                        {
                            id: 4,
                            code: 'WALMART_TRANSPORTATION',
                            abbr: 'WALMART TRANSPORTATION',
                            description: 'Walmart Transportation',
                        },
                        {
                            id: 5,
                            code: 'WEATHER_ROUTE',
                            abbr: 'WEATHER/ ROUTE',
                            description: 'Weather/ Route',
                        },
                        {
                            id: 6,
                            code: 'PLANNER_DISAPPROVAL',
                            abbr: 'PLANNER DISAPPROVAL',
                            description: 'Planner Disapproval',
                        },
                        {
                            id: 7,
                            code: 'VENDOR_SUPPLIER',
                            abbr: 'VENDOR/ SUPPLIER',
                            description: 'Vendor/ Supplier',
                        },
                        {
                            id: 8,
                            code: 'TONU',
                            abbr: 'TONU',
                            description: 'Truck Order Not Used',
                        },
                    ],
                    dateType: [
                        {
                            id: 1,
                            code: 'CREATED_DATE',
                            abbr: 'Created Date',
                            description: 'Created Date',
                        },
                        {
                            id: 2,
                            code: 'EARLIEST_PICKUP',
                            abbr: 'Earliest Pickup',
                            description: 'Earliest Pickup',
                        },
                        {
                            id: 3,
                            code: 'LATEST_PICKUP',
                            abbr: 'Latest Pickup',
                            description: 'Latest Pickup',
                        },
                        {
                            id: 4,
                            code: 'CURRENT_LATEST_DELIVERY',
                            abbr: 'Current Latest Delivery',
                            description: 'Current Latest Delivery',
                        },
                        {
                            id: 5,
                            code: 'ORIGINAL_LATEST_DELIVERY',
                            abbr: 'Original Latest Delivery',
                            description: 'Original Latest Delivery',
                        },
                        {
                            id: 6,
                            code: 'PO_BOOKING_CUTOFF',
                            abbr: 'PO Booking Date Cutoff',
                            description: 'PO Booking Date Cutoff',
                        },
                        {
                            id: 7,
                            code: 'READY_DATE',
                            abbr: 'Ready Date',
                            description: 'Ready Date',
                        },
                        {
                            id: 8,
                            code: 'PLANNED_DUE_DATE',
                            abbr: 'Planned Due Date',
                            description: 'Planned Due Date',
                        },
                    ],
                    doOrderType: [
                        {
                            id: 1,
                            code: 'STORE_REPLENISHMENT',
                            abbr: 'Store Replenishment',
                            description: 'Store Replenishment',
                        },
                        {
                            id: 2,
                            code: 'DC_REPLENISHMENT',
                            abbr: 'DC Replenishment',
                            description: 'DC Replenishment',
                        },
                        {
                            id: 3,
                            code: 'NON-WALMART_FREIGHT',
                            abbr: 'Non-Walmart Freight',
                            description: 'Non-Walmart Freight',
                        },
                        {
                            id: 4,
                            code: 'FIXTURES',
                            abbr: 'Fixtures',
                            description: 'Fixtures',
                        },
                        {
                            id: 5,
                            code: 'CONSTRUCTION',
                            abbr: 'Construction',
                            description: 'Construction',
                        },
                        {
                            id: 6,
                            code: 'PALLETS',
                            abbr: 'Pallets',
                            description: 'Pallets',
                        },
                        {
                            id: 7,
                            code: 'SORT',
                            abbr: 'SORT',
                            description: 'SORT',
                        },
                        {
                            id: 7,
                            code: 'CLAIMS',
                            abbr: 'Claims',
                            description: 'Claims',
                        },
                        {
                            id: 8,
                            code: 'TOTES',
                            abbr: 'Totes',
                            description: 'Totes',
                        },
                        {
                            id: 9,
                            code: 'BREAK_PACKS',
                            abbr: 'Break Packs',
                            description: 'Break Packs',
                        },
                        {
                            id: 10,
                            code: 'AIR_BAGS',
                            abbr: 'Air Bags',
                            description: 'Air Bags',
                        },
                        {
                            id: 11,
                            code: 'CARDBOARD',
                            abbr: 'Cardboard',
                            description: 'Cardboard',
                        },
                        {
                            id: 12,
                            code: 'STORE_FIXTURES',
                            abbr: 'Store Fixtures',
                            description: 'Store Fixtures',
                        },
                        {
                            id: 13,
                            code: 'GARDEN_CENTRE_RACKS',
                            abbr: 'Garden Centre Racks',
                            description: 'Garden Centre Racks',
                        },
                        {
                            id: 14,
                            code: 'OTHER',
                            abbr: 'Other',
                            description: 'Other',
                        },
                        {
                            id: 15,
                            code: 'REPOSITIONING',
                            abbr: 'Repositioning',
                            description: 'Repositioning',
                        },
                    ],
                    province: [
                        {
                            id: 1,
                            code: 'ALB',
                            abbr: 'Alberta',
                            description: 'Alberta',
                        },
                    ],
                    countryCode: [
                        {
                            id: 1,
                            code: 'CA',
                            abbr: 'CA',
                            description: 'CA',
                        },
                    ],
                    loadPlanningIneligibleReasonCode: [
                        {
                            id: 1,
                            code: 'AUTO',
                            abbr: 'Auto',
                            description: 'Auto',
                        },
                        {
                            id: 2,
                            code: 'Manual',
                            abbr: 'Manual',
                            description: 'Manual',
                        },
                    ],
                    programmeType: [
                        {
                            id: 1,
                            code: 'COL',
                            abbr: 'COLLECT',
                            description: 'COLLECT',
                        },
                        {
                            id: 2,
                            code: 'T4H',
                            abbr: 'T4H',
                            description: 'T4H',
                        },
                        {
                            id: 3,
                            code: 'DSD',
                            abbr: 'DSD',
                            description: 'DSD',
                        },
                        {
                            id: 4,
                            code: 'WCP',
                            abbr: 'WCP',
                            description: 'WCP',
                        },
                        {
                            id: 5,
                            code: 'WFP',
                            abbr: 'WFP',
                            description: 'WFP',
                        },
                    ],
                    ibob: [
                        {
                            id: 1,
                            code: 'OB',
                            abbr: 'Outbound',
                            description: 'Outbound',
                        },
                        {
                            id: 2,
                            code: 'IB',
                            abbr: 'Inbound',
                            description: 'Inbound',
                        },
                        {
                            id: 3,
                            code: 'OTH',
                            abbr: 'Other',
                            description: 'Other',
                        },
                    ],
                    paymentTerms: [
                        {
                            id: 1,
                            code: 'RTL',
                            abbr: 'COLLECT',
                            description: 'COLLECT',
                        },
                        {
                            id: 2,
                            code: 'IMPT',
                            abbr: 'PREPAID',
                            description: 'PREPAID',
                        },
                    ],
                    transportationOrderType: [
                        {
                            id: 1,
                            code: 'STORE',
                            abbr: 'Store',
                            description: 'Store',
                        },
                        {
                            id: 2,
                            code: 'T4H',
                            abbr: 'T4H',
                            description: 'T4H',
                        },
                    ],
                    owner: [
                        {
                            id: 1,
                            code: 'REQ',
                            abbr: 'Requestor Team',
                            description: 'Requestor Team',
                        },
                        {
                            id: 2,
                            code: 'IMPT',
                            abbr: 'Imports',
                            description: 'Imports',
                        },
                        {
                            id: 3,
                            code: 'ECOM',
                            abbr: 'eCommerce',
                            description: 'eCommerce',
                        },
                        {
                            id: 4,
                            code: 'IB',
                            abbr: 'Inbound Team',
                            description: 'Inbound Team',
                        },
                        {
                            id: 5,
                            code: 'WFP',
                            abbr: 'WFP Team',
                            description: 'WFP Team',
                        },
                    ],
                    orderSource: [
                        {
                            id: 1,
                            code: 'CS',
                            abbr: 'Confirm Shipment',
                            description: 'Confirm Shipment',
                        },
                        {
                            id: 2,
                            code: 'STOMP',
                            abbr: 'STOMP',
                            description: 'STOMP',
                        },
                    ],
                    deliveryOrderChannel: [
                        {
                            id: 1,
                            code: 'RETAIL',
                            abbr: 'Retail',
                            description: 'Retail',
                        },
                        {
                            id: 2,
                            code: 'ECOMMERCE',
                            abbr: 'eCommerce',
                            description: 'eCommerce',
                        },
                        {
                            id: 3,
                            code: 'IMPORTS',
                            abbr: 'Imports',
                            description: 'Imports',
                        },
                        {
                            id: 4,
                            code: 'T4H',
                            abbr: 'T4H',
                            description: 'T4H',
                        },
                        {
                            id: 5,
                            code: 'OTHER',
                            abbr: 'Other',
                            description: 'Other',
                        },
                    ],
                    deliveryOrderProgram: [
                        {
                            id: 1,
                            code: 'STORE_REPLENISHMENT',
                            abbr: 'Store Replenishment',
                            description: 'Store Replenishment',
                        },
                        {
                            id: 2,
                            code: 'WFP',
                            abbr: 'WFP',
                            description: 'WFP',
                        },
                        {
                            id: 3,
                            code: 'WCP',
                            abbr: 'WCP',
                            description: 'WCP',
                        },
                        {
                            id: 4,
                            code: 'T4H',
                            abbr: 'T4H',
                            description: 'T4H',
                        },
                        {
                            id: 5,
                            code: 'COLLECT',
                            abbr: 'Collect',
                            description: 'Collect',
                        },
                        {
                            id: 6,
                            code: 'DSD',
                            abbr: 'DSD',
                            description: 'DSD',
                        },
                        {
                            id: 7,
                            code: 'GFNR',
                            abbr: 'GFNR',
                            description: 'GFNR',
                        },
                        {
                            id: 8,
                            code: 'REVERSE',
                            abbr: 'Reverse',
                            description: 'Reverse',
                        },
                        {
                            id: 9,
                            code: 'OTHER',
                            abbr: 'Other',
                            description: 'Other',
                        },
                    ],
                    serviceClass: [
                        {
                            id: 1,
                            code: 'GROUND',
                            abbr: 'Ground',
                            description: 'Ground',
                        },
                        {
                            id: 2,
                            code: 'SHIP',
                            abbr: 'Ship',
                            description: 'Ship',
                        },
                        {
                            id: 3,
                            code: 'AIR',
                            abbr: 'Air',
                            description: 'Air',
                        },
                        {
                            id: 4,
                            code: 'RAIL',
                            abbr: 'Rail',
                            description: 'Rail',
                        },
                    ],
                    priority: [
                        {
                            id: 1,
                            code: 'EXPEDITED',
                            abbr: 'Expedited',
                            description: 'Expedited',
                        },
                        {
                            id: 2,
                            code: 'HIGH',
                            abbr: 'High',
                            description: 'High',
                        },
                        {
                            id: 3,
                            code: 'MEDIUM',
                            abbr: 'Medium',
                            description: 'Medium',
                        },
                        {
                            id: 4,
                            code: 'LOW',
                            abbr: 'Low',
                            description: 'Low',
                        },
                    ],
                    serviceLevel: [
                        {
                            id: 1,
                            code: 'SINGLE',
                            abbr: 'Single',
                            description: 'Single',
                        },
                        {
                            id: 2,
                            code: 'TEAM',
                            abbr: 'Team',
                            description: 'Team',
                        },
                        {
                            id: 3,
                            code: 'POWER_ONLY',
                            abbr: 'Power Only',
                            description: 'Power Only',
                        },
                        {
                            id: 4,
                            code: 'LCV',
                            abbr: 'LCV',
                            description: 'LCV',
                        },
                    ],
                    orderCPIneligibleReasonCode: [
                        {
                            id: 1,
                            code: 'AUTO',
                            abbr: 'Auto',
                            description: 'Auto',
                        },
                        {
                            id: 2,
                            code: 'MAN',
                            abbr: 'Manual',
                            description: 'Manual',
                        },
                    ],
                    deliveryOrderStatus: [
                        {
                            id: 1,
                            code: 'UNPLANNED',
                            abbr: 'UNPLANNED',
                            description: 'UNPLANNED',
                        },
                        {
                            id: 2,
                            code: 'RELEASED',
                            abbr: 'RELEASED',
                            description: 'RELEASED',
                        },
                        {
                            id: 3,
                            code: 'PLANNED',
                            abbr: 'PLANNED',
                            description: 'PLANNED',
                        },
                        {
                            id: 4,
                            code: 'PLANNED_INCOMPLETE',
                            abbr: 'PLANNED_INCOMPLETE',
                            description: 'PLANNED_INCOMPLETE',
                        },
                        {
                            id: 5,
                            code: 'CANCELLED',
                            abbr: 'CANCELLED',
                            description: 'CANCELLED',
                        },
                        {
                            id: 6,
                            code: 'COMPLETE',
                            abbr: 'COMPLETE',
                            description: 'COMPLETE',
                        },
                    ],
                    periodType: [
                        {
                            id: 1,
                            code: 'IN_BETWEEN',
                            abbr: 'In Between',
                            description: 'In Between',
                        },
                        {
                            id: 2,
                            code: 'AFTER',
                            abbr: 'After',
                            description: 'After',
                        },
                        {
                            id: 3,
                            code: 'BEFORE',
                            abbr: 'Before',
                            description: 'Before',
                        },
                        {
                            id: 4,
                            code: 'ON',
                            abbr: 'On',
                            description: 'On',
                        },
                    ],
                    serviceMode: [
                        {
                            id: 1,
                            code: 'TL',
                            abbr: 'TL',
                            description: 'TL',
                        },
                        {
                            id: 2,
                            code: 'LTL',
                            abbr: 'LTL',
                            description: 'LTL',
                        },
                        {
                            id: 3,
                            code: 'PARCEL',
                            abbr: 'Parcel',
                            description: 'Parcel',
                        },
                    ],
                    locationTypeCode: [
                        {
                            id: 1,
                            code: 'BVNDR',
                            abbr: 'BVNDR',
                            description: 'BVNDR',
                        },
                        {
                            id: 2,
                            code: 'SPLR',
                            abbr: 'SPLR',
                            description: 'SPLR',
                        },
                        {
                            id: 3,
                            code: 'DC',
                            abbr: 'DC',
                            description: 'DC',
                        },
                    ],
                    ownerTeam: [
                        {
                            id: 1,
                            code: 'INBOUNDTEAM',
                            abbr: 'Inbound Team',
                            description: 'Inbound Team',
                        },
                        {
                            id: 2,
                            code: 'ECOM',
                            abbr: 'Ecommerce',
                            description: 'Ecommerce',
                        },
                        {
                            id: 3,
                            code: 'Imports',
                            abbr: 'Imports',
                            description: 'Imports',
                        },
                        {
                            id: 4,
                            code: 'REQTEAM',
                            abbr: 'Requestor Team',
                            description: 'Requestor Team',
                        },
                        {
                            id: 5,
                            code: 'WFP',
                            abbr: 'WFP Team',
                            description: 'WFP Team',
                        },
                    ],
                    deliveryLoadingMethod: [
                        {
                            id: 1,
                            code: 'FLOOR',
                            abbr: 'Floor',
                            description: 'Floor',
                        },
                        {
                            id: 2,
                            code: 'PALLET',
                            abbr: 'Pallet',
                            description: 'Pallet',
                        },
                    ],
                },
            },
        },
    },
};
export const loadDetailslsMockTnt = {
    payload: {
        ...loadDetailslsMock.payload,
        tntCore: {
            trackingData: [
                {
                    trackingId: '500002262',
                    trackingIdType: 'LOAD',
                    altTrackingId: '6357803',
                    altTrackingIdType: 'FOURKITES',
                    planStatus: 'IN_TRANSIT',
                    planStatusManualUpdate: false,
                    enrouteStatus: 'Expired',
                    inTransitStatus: 'Early',
                    lastUpdateTs: 1655217919715,
                    timeElapsedSinceLastPing: 397229,
                    estTransitTime: {
                        value: 0,
                        unit: 'MIN',
                    },
                    estTransitDistance: {
                        value: 350,
                        unit: 'MILE',
                    },
                    actWaitTime: {
                        value: 210,
                        unit: 'MIN',
                    },
                    stops: [
                        {
                            stopId: '23352809',
                            stopType: 'SPLR',
                            activityType: 'PICKUP',
                            stopSeqNumber: 1,
                            status: 'DEPARTED',
                            arrivalStatus: 'Early',
                            estTransitTime: {
                                value: 480,
                                unit: 'MIN',
                            },
                            estTransitDistance: {
                                value: 350,
                                unit: 'MILE',
                            },
                            actWaitTime: {
                                value: 210,
                                unit: 'MIN',
                            },
                            planned: {
                                arrivalTsBegin: 1658863800000,
                                arrivalTsEnd: 1658863800000,
                                departureTs: 1658869200000,
                                arrivalTsSource: 'STRIDE_CST',
                                departureTsSource: 'STRIDE_CST',
                            },
                            estimated: {
                                departureTs: 1654583400000,
                                departureTsSource: 'FOURKITES',
                            },
                            actual: {
                                arrivalTs: 1654578000000,
                                departureTs: 1654590600000,
                                arrivalTsSource: 'FOURKITES',
                                departureTsSource: 'FOURKITES',
                            },
                            stopTimezone: 'America/Toronto',
                            stopTimeZoneAbbr: 'EDT',
                            reasonCodes: [],
                            isActive: true,
                        },
                        {
                            stopId: '6002',
                            stopType: 'DC',
                            activityType: 'DELIVERY',
                            stopSeqNumber: 2,
                            arrivalStatus: 'Early',
                            estTransitTime: {
                                value: 0,
                                unit: 'MIN',
                            },
                            estTransitDistance: {
                                value: 0,
                                unit: 'MILE',
                            },
                            planned: {
                                arrivalTsBegin: 1658898000000,
                                arrivalTsEnd: 1658898000000,
                                departureTs: 1658901600000,
                                arrivalTsSource: 'STRIDE_CST',
                                departureTsSource: 'STRIDE_CST',
                            },
                            estimated: {
                                arrivalTs: 1654615729000,
                                departureTs: 1654619329000,
                                arrivalTsSource: 'FOURKITES',
                                departureTsSource: 'FOURKITES',
                            },
                            actual: {},
                            stopTimezone: 'America/Toronto',
                            stopTimeZoneAbbr: 'EDT',
                            reasonCodes: [],
                            isActive: true,
                        },
                    ],
                    currentLocation: {
                        latitude: 45.46977996826172,
                        longitude: -73.72709655761719,
                        recordedTs: '2022-06-07T08:30:00.000+00:00',
                        eventSource: 'FOURKITES',
                        speed: null,
                        additionalAttributes: null,
                    },
                    equipment: {
                        id: null,
                        scac: null,
                    },
                    coherence: [],
                },
            ],
        },
        etaDetails: {
            uncrossedLoadStops: [],
        },
        trace: {
            tracingOutputDTOs: [],
        },
    },
};
export const workloadDataMock = {
    carrier: {
        id: 'ANY',
        name: 'ANY',
    },
    equipment: {
        equipmentType: 'TRUCK',
    },
};
export const workloadDataWithEqTypeCargo = {
    carrier: {
        id: 'ANY',
        name: '',
    },
    equipment: {
        equipmentType: 'CARGO',
        equipmentId: 'testcargo',
    },
};

export const workloadDataWithEqTypeCar = {
    carrier: {
        id: 'ANY',
        name: '',
    },
    equipment: {
        equipmentType: 'CAR',
        equipmentId: 'testcar',
    },
};
export const carriersListResponseMock = {
    callAPI: jest.fn(),
    response: {
        carriers: [
            {
                mdm_carrier_id: '567',
                carrier_name: 'JBHT',
            },
            {
                mdm_carrier_id: '568',
                carrier_name: 'BHT',
            },
        ],
    },
    loading: false,
};
export const defaultResponseMock = {
    callAPI: () => {},
    response: undefined,
};
export const workLoadStaticData = {
    payload: {
        mdm_static_data: {
            static_data: {
                carrier_codes: [
                    {
                        carrier_id: 'ANY',
                        mdm_carrier_id: 0,
                    },
                    {
                        carrier_id: '164146502141',
                        mdm_carrier_id: 12,
                    },
                ],
                carriers: [
                    {
                        mdm_carrier_id: 0,
                        carrier_name: 'ANY',
                    },
                    {
                        mdm_carrier_id: 12,
                        carrier_name: 'Test Carrier',
                    },
                ],
            },
        },
    },
};
export const equipmentAPIErrorMock = {
    errors: [
        {
            errorIdentifiers: {
                details: {
                    resource_details: {
                        status: 'error',
                        messages: [
                            {
                                description: 'Bad Request',
                            },
                        ],
                    },
                },
            },
        },
    ],
};
export const equipmentAPIErrorWithValidResourceAssmnt = {
    errors: [
        {
            errorIdentifiers: {
                details: {
                    resource_details: {
                        validResourceAssignment: {},
                    },
                },
            },
        },
    ],
};
export const equipmentsOfSelectedCarrier = {
    truck: [
        {
            id: 'TRUCK-1',
            value: 'TRUCK-1',
        },
    ],
    tractor: [
        {
            id: 'TRACTOR-1',
            value: 'TRACTOR-1',
        },
    ],
    trailer: [
        {
            id: 'TRAILER-1',
            value: 'TRAILER-1',
        },
    ],
};

export const tripMockWithChildPlanStops = {
    ...selectedTripMock,
    childPlans: [
        {
            ...selectedTripMock.childPlans[0],
            stops: [],
        },
    ],
};

export const tripWithBillOfLadingInLoads = {
    ...selectedTripMock,
    childPlans: [
        {
            ...selectedTripMock.childPlans[0],
            equipment: {
                ...selectedTripMock.childPlans[0].equipment,
                billOfLading: 10000,
            },
        },
        {
            ...selectedTripMock.childPlans[1],
            equipment: {
                ...selectedTripMock.childPlans[1].equipment,
                billOfLading: 20000,
            },
        },
        {
            ...selectedTripMock.childPlans[2],
            equipment: {
                ...selectedTripMock.childPlans[2].equipment,
                billOfLading: 30000,
            },
        },
    ],
};
