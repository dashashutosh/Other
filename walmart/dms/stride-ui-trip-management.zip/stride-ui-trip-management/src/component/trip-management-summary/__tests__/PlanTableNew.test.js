import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { render, screen, fireEvent, wait, waitFor } from '../../../utils/test-utils';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { AppUtils } from '@gscope-mfe/app-bridge';
import {
    configResponseMock,
    contextMock,
    featureFlagsMockCA,
    transformedConfigResponseMock,
    transformedTripStaticData,
    tripStaticDataMock,
    contextMockCA,
} from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

import { PlanLTProcessing, PlanLTTransit } from './mocks/PlanLTPreview.mock';
import {
    assignCarrierMock,
    tripResponseWithSealsAndInvoice,
    tripResponseWithChargeLocations,
    tripWithoutSealAndInvoice,
    tripWithMultipleLoad,
    splitApiResponseMock,
    tripWithCarrierStatus,
    updateDestinationTrans,
    createDoubleTrailerTripResponse,
    validTripsForDoubleTrailer,
    validLoadsForDoubleAssign,
    doubleTrailerTripUpdateDestinationMock,
    tripResponseWithBillOfLading,
} from './mocks/TripManagementSummary.mock';
import { permissionsMock, mdmLocationTypes, queryState, pageLoadSettings } from './mocks/PlanTableNewData.mock';

import PlanSearchAggregatesCA from './mocks/PlanSearchAggregatesCA.mock.json';
import PlanLTPreviewCL from './mocks/PlanLTPreviewCL.mock.json';
import PlanLTPreviewGT from './mocks/PlanLTPreviewGT.mock.json';

import PlanTable from '../PlanTableNew';
import TripSharedService from '../../../service/TripSharedService';
import { carriersListResponseMock, workLoadStaticData } from './mocks/WorkloadAssignment.mock';

const API_GATEWAY_PREFIX = 'api/gateway/v4/stride-ui-trip-management-';

const PlanSearchAggregate = { ...PlanSearchAggregatesCA };
PlanSearchAggregate.planResponseList.header.headerAttributes.PlanAggregateCount = 150;

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
        res(ctx.json(PlanSearchAggregate)),
    ),
    rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        const { status } = JSON.parse(req.body.payload).payload;
        if (tenantId === 'CL') {
            if (status.some((dta) => dta.status === 'NEED_ATTENTION')) {
                return res(ctx.json(PlanLTProcessing));
            }
            if (status.some((dta) => dta.status === 'IN_TRANSIT')) {
                return res(ctx.json(PlanLTTransit));
            }
            return res(ctx.json(PlanLTPreviewCL));
        }
        if (tenantId === 'CAM_GT') {
            if (status.some((dta) => dta.status === 'NEED_ATTENTION')) {
                return res(ctx.json(PlanLTProcessing));
            }
            if (status.some((dta) => dta.status === 'IN_TRANSIT')) {
                return res(ctx.json(PlanLTTransit));
            }
            return res(ctx.json(PlanLTPreviewGT));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX}assignCarrier/assignCarrier`, (req, res, ctx) => res(ctx.json(assignCarrierMock))),
    rest.post(`${API_GATEWAY_PREFIX}splitLoad/splitLoad`, (req, res, ctx) => res(ctx.json(splitApiResponseMock))),
    rest.post(`${API_GATEWAY_PREFIX}createDoubleTrailer/createDoubleTrailer`, (req, res, ctx) =>
        res(ctx.json(createDoubleTrailerTripResponse)),
    ),
    rest.post(`${API_GATEWAY_PREFIX}getCarriers/getCarriers`, (req, res, ctx) =>
        res(ctx.json(carriersListResponseMock)),
    ),
    rest.post(`${API_GATEWAY_PREFIX}workloadStaticData/workloadStaticData`, (req, res, ctx) =>
        res(ctx.json(workLoadStaticData)),
    ),
);

jest.mock('@gscope-mfe/common-components', () => {
    const actualModule = jest.requireActual('@gscope-mfe/common-components');
    return {
        ...actualModule,
        LocalizeLang: {
            default: {
                ...actualModule.LocalizeLang.default,
                localizeLang: jest.fn(),
            },
        },
    };
});
const mockPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockPush,
    }),
}));

afterEach(() => server.resetHandlers());

afterAll(() => server.close());

beforeAll(() => {
    LocalizeLang.default.localizeLang.mockImplementation(() => mockPush);
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
    TripSharedService.setFeatureFlags(featureFlagsMockCA);
    TripSharedService.setPageLoadSettings(pageLoadSettings);
    TripSharedService.setTripStaticData(tripStaticDataMock);
    const trans = jest.fn((a) => a);
    TripSharedService.setTrans(trans);
    jest.setTimeout(50000);
    server.listen();
});

describe('Plan Table New', () => {
    const renderPlanTableNew = (props = {}) =>
        render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
                {...props}
            />,
        );

    const contextMockCA = { ...contextMock, currentMarket: 'ca' };
    beforeEach(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCA);
    });
    it('should render without crashing when Planning Selected', () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pOnTripApprove={mockPush}
                pCreateTripReq={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pPhaseCounts={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );

        expect(wrapper).toBeDefined();
    });
    it('should render without crashing when Processing Selected', () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
    });
    it('should render without crashing when Ready To Start Selected', () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={2}
                pConfig={transformedConfigResponseMock}
                pOnTripDispatch={mockPush}
                pOnLoadMarkAsDelivered={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
    });
    it('should render without crashing when In Transit Selected', () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={3}
                pConfig={transformedConfigResponseMock}
                pOnTripDelivered={mockPush}
                pOnLoadMarkAsDelivered={mockPush}
                pOnReprintDoc={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
    });

    it('should render table with data', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const planTable = wrapper.getByTestId('plan-table');
        expect(planTable).toBeDefined();
        const planTableBody = wrapper.getByTestId('plan-table-body');
        expect(planTableBody).toBeDefined();
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
    });
    it('should able to search for table data', () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const searchField = wrapper.getByTestId('search');
        expect(searchField).toBeDefined();
        fireEvent.change(searchField, { target: { value: '1234' } });
        expect(searchField.value).toEqual('1234');
    });
    it('should have a default sorting column for Planned departure', async () => {
        render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const sortfield = await screen.findByTestId('plan-table-header-departureTs');
        await waitFor(() => {
            expect(sortfield.getAttribute('aria-sort')).toBe('ascending');
        });
    });
    // TODO: Fix this test after MFE migration
    it.skip('should render footer with pagination', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={{ ...transformedConfigResponseMock, rowsPerPage: 50 }}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const planTableFooter = await wrapper.findByTestId('ld-sc-ui--table-footer');
        expect(planTableFooter).toBeDefined();
        expect(await wrapper.findByText('Showing 1 - 50 of 150')).toBeDefined();
        expect(await wrapper.findByTestId('ld-sc-ui-table-next-page')).toBeDefined();
        expect(wrapper.queryByTestId('ld-sc-ui-table-previous-page')).toBeDefined();
    });

    describe('Action menu tests', () => {
        beforeEach(() => {
            jest.clearAllMocks();
            const spy = jest.spyOn(AppUtils, 'get');
            spy.mockImplementation(() => contextMockCA);
            TripSharedService.setFeatureFlags({ enableActionMenu: true });
            TripSharedService.setPageLoadSettings({ showCAColumns: true });
        });

        it('should show action menu and invoke approve load', async () => {
            const onTripApprove = jest.fn();
            renderPlanTableNew({
                pOnTripApprove: onTripApprove,
                pTabIndex: 0,
            });
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });
            fireEvent.click(screen.getByTestId('dt-chkbx-0-50000678'));
            const approveButton = await screen.findByText('button.approveLoad');
            expect(approveButton).toBeDefined();
            fireEvent.click(approveButton);

            expect(onTripApprove).toHaveBeenCalled();
        });

        it('should show action menu and invoke auto tender', async () => {
            const onAutoTender = jest.fn();
            renderPlanTableNew({
                pOnTripTender: onAutoTender,
                pTabIndex: 1,
            });
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });
            fireEvent.click(screen.getByTestId('dt-chkbx-1-50000786'));
            const tenderButton = await screen.findByText('button.tenderTrip');
            expect(tenderButton).toBeDefined();
            fireEvent.click(tenderButton);

            expect(onAutoTender).toHaveBeenCalled();
        });

        it('should show action menu and invoke load marked as delivered', async () => {
            const onLoadDelivered = jest.fn();
            renderPlanTableNew({
                pOnLoadMarkAsDelivered: onLoadDelivered,
                pTabIndex: 2,
            });
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });
            fireEvent.click(screen.getByTestId('dt-chkbx-2-50000786'));
            const forceLoadToDelivered = await screen.findByText('button.forceLoadToDelivered');
            expect(forceLoadToDelivered).toBeDefined();
            fireEvent.click(forceLoadToDelivered);

            expect(onLoadDelivered).toHaveBeenCalled();
        });
    });

    describe('Carrier assignment test', () => {
        const allPlanWithTenderCancelledStatus = {
            ...PlanSearchAggregatesCA,
            planResponseList: {
                ...PlanSearchAggregatesCA.planResponseList,
                payload: PlanSearchAggregatesCA.planResponseList.payload.map((item) => ({
                    ...item,
                    planResponse: {
                        ...item.planResponse,
                        planStatus: 'TENDER_CANCELED',
                    },
                })),
            },
        };

        const onCarrierAssign = jest.fn();

        beforeEach(() => {
            jest.clearAllMocks();
            const spy = jest.spyOn(AppUtils, 'get');
            spy.mockImplementation(() => contextMockCA);
            TripSharedService.setFeatureFlags({ enableActionMenu: true, enableMultiLoadAssignment: true });
            TripSharedService.setPageLoadSettings({ showCAColumns: true });
            server.use(
                rest.post(`${API_GATEWAY_PREFIX}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                    res(ctx.json(allPlanWithTenderCancelledStatus)),
                ),
            );
        });

        it('should show load assign button if multi load is selected and featureFlags are enabled', async () => {
            renderPlanTableNew();
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });

            fireEvent.click(screen.getByTestId('dt-chkbx-1-50000678'));
            fireEvent.click(screen.getByTestId('dt-chkbx-1-50004376'));
            expect(screen.getByText('button.assignManually')).toBeDefined();
        });

        it('should not show load assign button if number of load selected is greater than CMS.maxRowSelected and featureFlags is enabled', async () => {
            renderPlanTableNew();
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });

            fireEvent.click(screen.getByTestId('dt-chkbx-1-50000678'));
            fireEvent.click(screen.getByTestId('dt-chkbx-1-50004376'));
            fireEvent.click(screen.getByTestId('dt-chkbx-1-50000786'));
            fireEvent.click(screen.getByTestId('dt-chkbx-1-50002027'));
            fireEvent.click(screen.getByTestId('dt-chkbx-1-50000857'));
            fireEvent.click(screen.getByTestId('dt-chkbx-1-500002241'));

            expect(screen.queryByText('button.assignManually')).toBeNull();
        });

        it('should not show load assign button if multi load is selected and featureFlags is disabled', async () => {
            TripSharedService.setFeatureFlags({ enableMultiLoadAssignment: false });
            renderPlanTableNew();
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });

            fireEvent.click(screen.getByTestId('dt-chkbx-1-50000678'));
            fireEvent.click(screen.getByTestId('dt-chkbx-1-50004376'));

            expect(screen.queryByText('button.assignManually')).toBeNull();
        });

        it('should invoke pOnCarrierAssign is assignment is multi load', async () => {
            renderPlanTableNew({
                pOnCarrierAssign: onCarrierAssign,
            });
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });

            fireEvent.click(screen.getByTestId('dt-chkbx-1-50000678'));
            fireEvent.click(screen.getByTestId('dt-chkbx-1-50004376'));

            const loadAssignManuallyBtn = screen.getByText('button.assignManually');
            expect(loadAssignManuallyBtn).toBeDefined();
            fireEvent.click(screen.getByText('button.assignManually'));

            const enterCarrierInput = await screen.findByTestId('stride-select-carrier-input');
            expect(enterCarrierInput).toBeDefined();
            fireEvent.change(enterCarrierInput, { target: { value: 'Test' } });

            fireEvent.click(screen.getByText('Assign'));
            expect(onCarrierAssign).toHaveBeenCalled();
        });
    });

    describe('Cancel load test', () => {
        const translation = {
            'action.title.confirmLoadCancel': 'Are you sure you want to cancel the',
            'action.label.load': 'load',
        };
        beforeEach(() => {
            jest.clearAllMocks();
            const spy = jest.spyOn(AppUtils, 'get');
            spy.mockImplementation(() => contextMockCA);
            TripSharedService.setFeatureFlags({ enableActionMenu: true, enableMultiLoadCancel: true });
            TripSharedService.setPageLoadSettings({ showCAColumns: true });
            const trans = jest.fn((a) => translation[a] || a);
            LocalizeLang.default.localizeLang.mockImplementation(() => trans);
        });

        it('should show cancel load button if multi load is selected and featureFlags are enabled', async () => {
            renderPlanTableNew({ pTabIndex: 0 });
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });

            fireEvent.click(screen.getByTestId('dt-chkbx-0-50000678'));
            fireEvent.click(screen.getByTestId('dt-chkbx-0-50004376'));
            expect(screen.getByText('button.cancelLoad')).toBeDefined();
        });

        it('should not show cancel load button if multi load is selected and featureFlags are disabled', async () => {
            TripSharedService.setFeatureFlags({ enableActionMenu: true, enableMultiLoadCancel: false });
            renderPlanTableNew({ pTabIndex: 0 });
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });

            fireEvent.click(screen.getByTestId('dt-chkbx-0-50000678'));
            fireEvent.click(screen.getByTestId('dt-chkbx-0-50004376'));

            expect(screen.queryByText('button.cancelLoad')).toBeNull();
        });

        it('should call pOnCancel when user clicks confirm', async () => {
            TripSharedService.setFeatureFlags({ enableActionMenu: true, enableMultiLoadCancel: true });
            const pCancelLoadMock = jest.fn();
            renderPlanTableNew({ pTabIndex: 0, pCancelLoad: pCancelLoadMock });
            const planTable = screen.getByTestId('plan-table');
            expect(planTable).toBeDefined();
            const planTableBody = screen.getByTestId('plan-table-body');
            expect(planTableBody).toBeDefined();
            await waitFor(() => {
                expect(planTableBody.children.length).toBeGreaterThan(0);
            });

            fireEvent.click(screen.getByTestId('dt-chkbx-0-50000678'));
            fireEvent.click(screen.getByTestId('dt-chkbx-0-50004376'));

            const cancelLoadBtn = screen.getByText('button.cancelLoad');
            fireEvent.click(cancelLoadBtn);
            expect(screen.getByText('Are you sure you want to cancel the load')).toBeDefined();

            const inputReason = screen.getByTestId('input-reason');
            expect(inputReason).toBeDefined();
            fireEvent.click(inputReason);

            fireEvent.click(screen.getByTestId('single-select-simple-option-CARRIER'));

            const confirmBtn = screen.getByTestId('actionBtn');
            expect(confirmBtn).not.toBeDisabled();

            fireEvent.click(confirmBtn);
            expect(pCancelLoadMock).toHaveBeenCalled();
        });
    });
});

describe('Charge location validation on trip dispacth', () => {
    const mockDispatchCallback = jest.fn();
    beforeEach(() => {
        const contextMockMX = { ...contextMock, currentMarket: 'mx' };
        TripSharedService.setPageLoadSettings({ showCLColumns: true });
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockMX);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripResponseWithChargeLocations)),
            ),
        );
        TripSharedService.setFeatureFlags({ validateChargeLocationOnTripDispatch: true });
    });
    it('should call trip dispatch callback with charge location validation info if the flag is on', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={2}
                pOnTripDispatch={mockDispatchCallback}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-2-30000754');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const dispatchButton = await screen.findByTestId('dispatch');
        expect(dispatchButton).toBeDefined();
        fireEvent.click(dispatchButton);
        expect(mockDispatchCallback).toHaveBeenCalledWith(
            [
                {
                    allLoadsHaveChargeLocAdded: true,
                    loadsWithoutChargeLoc: [],
                    planId: '30000754',
                },
            ],
            expect.any(Function),
        );
    });

    it('should call trip dispatch callback without charge location validation info if the flag is off', async () => {
        TripSharedService.setFeatureFlags({ validateChargeLocationOnTripDispatch: false });
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={2}
                pOnTripDispatch={mockDispatchCallback}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-2-30000754');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const dispatchButton = await screen.findByTestId('dispatch');
        expect(dispatchButton).toBeDefined();
        fireEvent.click(dispatchButton);
        expect(mockDispatchCallback).toHaveBeenCalledWith(['30000754'], expect.any(Function));
    });
});
describe('Update Destination test cases', () => {
    const staticData = {
        ...transformedTripStaticData,
        locations: [
            { type_id: 'Hub', id: 'H', value: 'HUB1' },
            { type_id: 'Decon', id: 'DCN', value: 'Decon01' },
        ],
        locationTypes: [{ id: 'DCN', value: 'Decon', type_id: 'Decon' }],
    };
    const { open } = window;
    const config = {
        ...transformedConfigResponseMock,
        rowsPerPage: 1,
    };
    const spy = jest.spyOn(AppUtils, 'get');
    beforeEach(() => {
        delete window.open;
        window.open = jest.fn();
        const contextMockMX = { ...contextMock, currentMarket: 'mx' };
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripResponseWithSealsAndInvoice)),
            ),
        );
        TripSharedService.setPageLoadSettings({ showCLColumns: true });
        spy.mockImplementation(() => contextMockMX);
        TripSharedService.setFeatureFlags({ enableHubDeconDestinations: true });
        const trans = jest.fn((a) => updateDestinationTrans[a]);
        LocalizeLang.default.localizeLang.mockImplementation(() => trans);
    });
    afterAll(() => {
        window.open = open;
        jest.clearAllMocks();
    });
    it('should display Update destination button if the feature flag is on', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        expect(updateDestinationButton).toBeDefined();
    });

    it('should not display Update destination button if the feature flag is off', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        TripSharedService.setFeatureFlags({ enableHubDeconDestinations: false });
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = screen.queryByTestId('updateDestination');
        expect(updateDestinationButton).toBeNull();
    });

    it('should display Update destination button for outbound trip', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        expect(updateDestinationButton).toBeDefined();
    });

    it('should display Update destination button if trip has single load', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        expect(await wrapper.findByText('1 load')).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        expect(updateDestinationButton).toBeDefined();
    });

    it('should display Update destination button if trip has seal & invoice#', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        expect(updateDestinationButton).toBeDefined();
    });

    it('should display Update destination if trip is in WORKLOAD_ASSIGNMENT status', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        expect(updateDestinationButton).toBeDefined();
    });

    it('should not display Update destination button if trip has multiple loads', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripWithMultipleLoad)),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        const { rerender } = wrapper;
        rerender(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        expect(await wrapper.findByText('2 loads')).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = screen.queryByTestId('updateDestination');
        expect(updateDestinationButton).toBeNull();
    });

    it('should not display Update destination button if trip has no seal & invoice#', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripWithoutSealAndInvoice)),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        const { rerender } = wrapper;
        rerender(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = screen.queryByTestId('updateDestination');
        expect(updateDestinationButton).toBeNull();
    });

    it('should display success toast on update destination', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripResponseWithSealsAndInvoice)),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        fireEvent.click(updateDestinationButton);

        const loctionType = wrapper.getByTestId('locationType');
        expect(loctionType).toBeDefined();
        fireEvent.click(loctionType);
        fireEvent.click(wrapper.getByTestId('single-select-simple-option-Decon'));

        const loctionId = await wrapper.findByTestId('locationId');
        fireEvent.click(loctionId);
        fireEvent.click(wrapper.getByTestId('single-select-simple-option-DCN'));
        expect(await wrapper.findByText('Origin location')).toBeDefined();
        expect(await wrapper.findByText('Intermediate destination')).toBeDefined();

        const calendarIcon = await screen.findByText('Planned arrival date/time');

        expect(calendarIcon).toBeDefined();
        fireEvent.click(calendarIcon);

        const deconArrivalDt = wrapper.getByText('17');
        expect(deconArrivalDt).toBeDefined();
        fireEvent.click(deconArrivalDt);

        const applyButton = wrapper.getByText('Apply');
        expect(applyButton).toBeDefined();
        fireEvent.click(applyButton);

        const updateDestination = await wrapper.findAllByTestId('updateDestination');
        fireEvent.click(updateDestination[1]);

        expect(await screen.findByText('Trip 30000583')).toBeDefined();
        expect(await screen.findByText('Successfully updated intermediate destination.')).toBeDefined();
    });

    it('Should display error when splitLoadAPI returns error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}splitLoad/splitLoad`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json('Something went wrong')),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        fireEvent.click(await screen.findByTestId('dt-chkbx-1-30064496'));
        fireEvent.click(await screen.findByTestId('updateDestination'));

        fireEvent.click(wrapper.getByTestId('locationType'));
        fireEvent.click(wrapper.getByTestId('single-select-simple-option-Decon'));
        fireEvent.click(await wrapper.findByTestId('locationId'));
        fireEvent.click(wrapper.getByTestId('single-select-simple-option-DCN'));

        fireEvent.click(await screen.findByText('Planned arrival date/time'));
        fireEvent.click(wrapper.getByText('17'));
        fireEvent.click(wrapper.getByText('Apply'));

        const updateDestination = await wrapper.findAllByTestId('updateDestination');
        fireEvent.click(updateDestination[1]);

        expect(await screen.findByText('Something went wrong')).toBeDefined();
    });

    it('should open newly created trip details (Hub/Decon) in new tab on splitLoadAPI is success', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripResponseWithSealsAndInvoice)),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        fireEvent.click(updateDestinationButton);

        const loctionType = wrapper.getByTestId('locationType');
        expect(loctionType).toBeDefined();
        fireEvent.click(loctionType);
        fireEvent.click(wrapper.getByTestId('single-select-simple-option-Decon'));

        const loctionId = await wrapper.findByTestId('locationId');
        fireEvent.click(loctionId);
        fireEvent.click(wrapper.getByTestId('single-select-simple-option-DCN'));
        expect(await wrapper.findByText('Origin location')).toBeDefined();
        expect(await wrapper.findByText('Intermediate destination')).toBeDefined();

        const calendarIcon = await screen.findByText('Planned arrival date/time');

        expect(calendarIcon).toBeDefined();
        fireEvent.click(calendarIcon);

        const deconArrivalDt = wrapper.getByText('17');
        expect(deconArrivalDt).toBeDefined();
        fireEvent.click(deconArrivalDt);

        const applyButton = wrapper.getByText('Apply');
        expect(applyButton).toBeDefined();
        fireEvent.click(applyButton);

        const updateDestination = await wrapper.findAllByTestId('updateDestination');
        fireEvent.click(updateDestination[1]);

        expect(await screen.findByText('Successfully updated intermediate destination.')).toBeDefined();
        expect(window.open).toBeCalledWith('/mfe/stride/planquery/tripdetails?planId=30000583');
    });

    it('should not display Update destination button if trip is not in Processing tab', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(PlanLTPreviewCL)),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        expect(await wrapper.findByTestId('plan-table-body')).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-0-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);
        const updateDestinationButton = screen.queryByTestId('updateDestination');
        expect(updateDestinationButton).toBeNull();
    });
    it('should display Update destination button if carrier not assigned to trip', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        expect(updateDestinationButton).toBeDefined();
    });

    it('should not display Update destination button if trip has carrier assigned', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripWithCarrierStatus)),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30000754');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = screen.queryByTestId('updateDestination');
        expect(updateDestinationButton).toBeNull();
    });

    it('should display Update destination button if trip is double trailer', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(doubleTrailerTripUpdateDestinationMock)),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        expect(await wrapper.findByText('2 loads')).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = await screen.findByTestId('updateDestination');
        expect(updateDestinationButton).toBeDefined();
    });

    it('should not display Update destination button if trip is double trailer and flag is off', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripWithMultipleLoad)),
            ),
        );
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        expect(await wrapper.findByText('2 loads')).toBeDefined();
        fireEvent.click(checkbox);

        const updateDestinationButton = screen.queryByTestId('updateDestination');
        expect(updateDestinationButton).toBeNull();
    });
});

describe('Double trailer ui tests', () => {
    const staticData = { ...transformedTripStaticData, equipmentConfigurationIds: [{ id: 'ARSF56', value: 'ARSF56' }] };
    beforeEach(() => {
        const contextMockMX = { ...contextMock, currentMarket: 'mx' };
        TripSharedService.setPageLoadSettings({ showCLColumns: true });
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockMX);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(validTripsForDoubleTrailer)),
            ),
        );
        TripSharedService.setFeatureFlags({
            enableHubDeconDestinations: true,
            showCreateTripForDoubleTrailer: true,
            enableDifferentOriginForDoubleTrailer: true,
        });
        const trans = jest.fn((a) => a);
        LocalizeLang.default.localizeLang.mockImplementation(() => trans);
    });

    it('should display double trailer button if two trips are selected', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        expect(await wrapper.findByTestId('plan-table-body')).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const checkBoxTwo = await screen.findByTestId('dt-chkbx-1-30064497');
        expect(checkBoxTwo).toBeDefined();
        fireEvent.click(checkBoxTwo);

        const createButton = await screen.findByTestId('create-double-trailer-trip');
        expect(createButton).toBeDefined();
    });

    it('should not display double trailer button if feature flag is off', async () => {
        TripSharedService.setFeatureFlags({
            enableHubDeconDestinations: true,
            showCreateTripForDoubleTrailer: false,
            enableDifferentOriginForDoubleTrailer: true,
        });
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        expect(await wrapper.findByTestId('plan-table-body')).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const checkBoxTwo = await screen.findByTestId('dt-chkbx-1-30064497');
        expect(checkBoxTwo).toBeDefined();
        fireEvent.click(checkBoxTwo);

        const createButton = screen.queryByTestId('create-double-trailer-trip');
        expect(createButton).toBeNull();
    });

    it('should return valid response on double trailer trip creation', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={staticData}
            />,
        );
        expect(wrapper).toBeDefined();
        expect(await wrapper.findByTestId('plan-table-body')).toBeDefined();
        const tripOne = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(tripOne).toBeDefined();
        fireEvent.click(tripOne);
        const tripTwo = await screen.findByTestId('dt-chkbx-1-30064497');
        expect(tripTwo).toBeDefined();
        fireEvent.click(tripTwo);
        const doubleTrailerButton = await screen.findByTestId('create-double-trailer-trip');
        expect(doubleTrailerButton).toBeDefined();
        fireEvent.click(doubleTrailerButton);
        const singleSelect = await screen.findByTestId('double-trailer');
        expect(singleSelect).toBeDefined();
        fireEvent.click(singleSelect);
        const selectOption = await screen.findByTestId('single-select-simple-option-ARSF56');
        expect(selectOption).toBeDefined();
        fireEvent.click(selectOption);
        const createBtn = await screen.findByTestId('createBtn');
        expect(createBtn).toBeDefined();
        fireEvent.click(createBtn);
        const toastMessage = await screen.findByTestId('ld-sc-ui-toast');
        expect(toastMessage).toBeDefined();
    });
    describe('double load assignment ui tests', () => {
        beforeEach(() => {
            server.use(
                rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                    res(ctx.json(validLoadsForDoubleAssign)),
                ),
            );
            TripSharedService.setFeatureFlags({
                enableHubDeconDestinations: true,
                showAssignTripForDoubleTrailer: true,
            });
            mockPush.mockClear();
        });

        it('should display assign to trip button if two loads are selected and flag is enabled', async () => {
            const wrapper = render(
                <PlanTable
                    queryState={queryState}
                    dispatch={mockPush}
                    pIsLoading={false}
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pOnTripTender={mockPush}
                    pIsActive
                    pUserPerm={permissionsMock}
                    mdmLocationTypes={mdmLocationTypes}
                    pSetsIsSearchFilterModalOpen={mockPush}
                    pStaticData={staticData}
                />,
            );
            expect(wrapper).toBeDefined();
            expect(await wrapper.findByTestId('plan-table-body')).toBeDefined();

            const loadOne = await screen.findByTestId('dt-chkbx-0-30064490');
            expect(loadOne).toBeDefined();
            fireEvent.click(loadOne);

            const loadTwo = await screen.findByTestId('dt-chkbx-0-30064491');
            expect(loadTwo).toBeDefined();
            fireEvent.click(loadTwo);

            const assignToTripButton = await screen.findByTestId('assignToTrip');
            expect(assignToTripButton).toBeDefined();
        });

        it('should not display assign to trip button if two loads are selected and flag is disabled', async () => {
            TripSharedService.setFeatureFlags({
                enableHubDeconDestinations: true,
                showAssignTripForDoubleTrailer: false,
            });
            const wrapper = render(
                <PlanTable
                    queryState={queryState}
                    dispatch={mockPush}
                    pIsLoading={false}
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pOnTripTender={mockPush}
                    pIsActive
                    pUserPerm={permissionsMock}
                    mdmLocationTypes={mdmLocationTypes}
                    pSetsIsSearchFilterModalOpen={mockPush}
                    pStaticData={staticData}
                />,
            );
            expect(wrapper).toBeDefined();
            expect(await wrapper.findByTestId('plan-table-body')).toBeDefined();

            const loadOne = await screen.findByTestId('dt-chkbx-0-30064490');
            expect(loadOne).toBeDefined();
            fireEvent.click(loadOne);

            const loadTwo = await screen.findByTestId('dt-chkbx-0-30064491');
            expect(loadTwo).toBeDefined();
            fireEvent.click(loadTwo);

            const assignToTripButton = screen.queryByTestId('assignToTrip');
            expect(assignToTripButton).toBeNull();
        });

        it('should switch page with double loads if two loads are selected and flag is enabled', async () => {
            const wrapper = render(
                <PlanTable
                    queryState={queryState}
                    dispatch={mockPush}
                    pIsLoading={false}
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pOnTripTender={mockPush}
                    pIsActive
                    pUserPerm={permissionsMock}
                    mdmLocationTypes={mdmLocationTypes}
                    pSetsIsSearchFilterModalOpen={mockPush}
                    pStaticData={staticData}
                />,
            );
            expect(wrapper).toBeDefined();
            expect(await wrapper.findByTestId('plan-table-body')).toBeDefined();

            const loadOne = await screen.findByTestId('dt-chkbx-0-30064490');
            expect(loadOne).toBeDefined();
            fireEvent.click(loadOne);

            const loadTwo = await screen.findByTestId('dt-chkbx-0-30064491');
            expect(loadTwo).toBeDefined();
            fireEvent.click(loadTwo);

            const assignToTripButton = await screen.findByTestId('assignToTrip');
            expect(assignToTripButton).toBeDefined();
            fireEvent.click(assignToTripButton);

            const mockState = mockPush.mock.calls[0][0].state;
            expect(mockState.filteredPlans).toBeDefined();
            expect(mockState.isDoubleAssign).toBeTruthy();
        });

        it('should switch page with single load if single load is selected and flag is disabled', async () => {
            TripSharedService.setFeatureFlags({
                enableHubDeconDestinations: true,
                showAssignTripForDoubleTrailer: false,
            });
            const wrapper = render(
                <PlanTable
                    queryState={queryState}
                    dispatch={mockPush}
                    pIsLoading={false}
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pOnTripTender={mockPush}
                    pIsActive
                    pUserPerm={permissionsMock}
                    mdmLocationTypes={mdmLocationTypes}
                    pSetsIsSearchFilterModalOpen={mockPush}
                    pStaticData={staticData}
                />,
            );
            expect(wrapper).toBeDefined();
            expect(await wrapper.findByTestId('plan-table-body')).toBeDefined();

            const loadOne = await screen.findByTestId('dt-chkbx-0-30064490');
            expect(loadOne).toBeDefined();
            fireEvent.click(loadOne);

            const assignToTripButton = screen.queryByTestId('assignToTrip');
            expect(assignToTripButton).toBeDefined();
            fireEvent.click(assignToTripButton);

            const mockState = mockPush.mock.calls[0][0];
            expect(mockState.filteredPlans).toBeUndefined();
            expect(mockState.isDoubleAssign).toBeUndefined();
        });
    });
});

describe('Edit assignment tests', () => {
    const config = {
        ...transformedConfigResponseMock,
        rowsPerPage: 1,
    };
    const spy = jest.spyOn(AppUtils, 'get');
    beforeEach(() => {
        const contextMockMX = { ...contextMock, currentMarket: 'mx' };
        server.use(
            rest.post(`${API_GATEWAY_PREFIX}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripResponseWithBillOfLading)),
            ),
        );
        TripSharedService.setPageLoadSettings({ showCLColumns: true });
        TripSharedService.setFeatureFlags({ enableBillOfLading: true });
        TripSharedService.setConfig(configResponseMock);
        TripSharedService.setTripStaticData(tripStaticDataMock);
        spy.mockImplementation(() => contextMockMX);
        const trans = jest.fn((a) => a);
        LocalizeLang.default.localizeLang.mockImplementation(() => trans);
    });
    afterAll(() => {
        jest.clearAllMocks();
    });

    it('should display bill of lading and auto fill if flag is on', async () => {
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await wrapper.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const editAssignmentButton = await wrapper.findByTestId('editAssignment');
        expect(editAssignmentButton).toBeDefined();
        fireEvent.click(editAssignmentButton);

        const carrier = await wrapper.findByTestId('carrier');
        expect(carrier).toBeDefined();
        fireEvent.click(carrier);

        const carrierSelection = await wrapper.findByTestId('single-select-simple-option-89792722');
        expect(carrierSelection).toBeDefined();
        fireEvent.click(carrierSelection);

        const equipmentType = await wrapper.findAllByTestId('ld-sc-ui-segment');
        expect(equipmentType.length).toEqual(2);
        fireEvent.click(equipmentType[0]);

        const billOfLadingField = wrapper.queryByTestId('billOfLading');
        expect(billOfLadingField).toBeDefined();

        const billOfLadingValue = wrapper.queryByText('123456789');
        expect(billOfLadingValue).toBeDefined();
    });

    it('should not display bill of lading or auto fill if flag is off', async () => {
        TripSharedService.setFeatureFlags({ enableBillOfLading: false });
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const editAssignmentButton = await screen.findByTestId('editAssignment');
        expect(editAssignmentButton).toBeDefined();
        fireEvent.click(editAssignmentButton);

        const carrier = await screen.findByTestId('carrier');
        expect(carrier).toBeDefined();
        fireEvent.click(carrier);

        const carrierSelection = await wrapper.findByTestId('single-select-simple-option-89792722');
        expect(carrierSelection).toBeDefined();
        fireEvent.click(carrierSelection);

        const equipmentType = await screen.findAllByTestId('ld-sc-ui-segment');
        expect(equipmentType.length).toEqual(2);
        fireEvent.click(equipmentType[0]);

        const billOfLadingField = screen.queryByTestId('billOfLading');
        expect(billOfLadingField).toBeNull();

        const billOfLadingValue = wrapper.queryByText('123456789');
        expect(billOfLadingValue).toBeNull();
    });

    it('should display cargo and car if flag is on', async () => {
        TripSharedService.setFeatureFlags({ enableNewEquipmentTypes: true });
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await wrapper.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const editAssignmentButton = await wrapper.findByTestId('editAssignment');
        expect(editAssignmentButton).toBeDefined();
        fireEvent.click(editAssignmentButton);

        const carrier = await wrapper.findByTestId('carrier');
        expect(carrier).toBeDefined();
        fireEvent.click(carrier);

        const carrierSelection = await wrapper.findByTestId('single-select-simple-option-89792722');
        expect(carrierSelection).toBeDefined();
        fireEvent.click(carrierSelection);

        const equipmentType = await wrapper.findAllByTestId('ld-sc-ui-segment');
        expect(equipmentType.length).toEqual(4);
        fireEvent.click(equipmentType[0]);

        const cargoType = screen.queryByTestId('cargo');
        expect(cargoType).toBeDefined();

        const carType = screen.queryByText('car');
        expect(carType).toBeDefined();
    });

    it('should not display cargo or car if flag is off', async () => {
        TripSharedService.setFeatureFlags({ enableNewEquipmentTypes: false });
        const wrapper = render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={config}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const checkbox = await screen.findByTestId('dt-chkbx-1-30064496');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const editAssignmentButton = await screen.findByTestId('editAssignment');
        expect(editAssignmentButton).toBeDefined();
        fireEvent.click(editAssignmentButton);

        const carrier = await screen.findByTestId('carrier');
        expect(carrier).toBeDefined();
        fireEvent.click(carrier);

        const carrierSelection = await wrapper.findByTestId('single-select-simple-option-89792722');
        expect(carrierSelection).toBeDefined();
        fireEvent.click(carrierSelection);

        const equipmentType = await screen.findAllByTestId('ld-sc-ui-segment');
        expect(equipmentType.length).toEqual(2);
        fireEvent.click(equipmentType[0]);

        const cargoType = screen.queryByTestId('cargo');
        expect(cargoType).toBeNull();

        const carType = wrapper.queryByText('car');
        expect(carType).toBeNull();
    });
});

describe('Add comment test', () => {
    const onViewAllCommentsMock = jest.fn();

    const renderPlanTableNew = (props = {}) =>
        render(
            <PlanTable
                queryState={queryState}
                dispatch={mockPush}
                pIsLoading={false}
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pOnTripTender={mockPush}
                pIsActive
                pUserPerm={permissionsMock}
                mdmLocationTypes={mdmLocationTypes}
                pSetsIsSearchFilterModalOpen={mockPush}
                pStaticData={transformedTripStaticData}
                pOnViewAllComments={onViewAllCommentsMock}
                {...props}
            />,
        );

    beforeEach(() => {
        jest.clearAllMocks();
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCA);
        const trans = jest.fn((str) => {
            const translations = {
                'button.addCommentToLoads': 'Add Comment',
            };
            return translations[str] || str;
        });
        TripSharedService.setFeatureFlags({ enableAddMultiComment: true, enableActionMenu: true });
        TripSharedService.setPageLoadSettings({ showCAColumns: true });
        TripSharedService.setTrans(trans);
    });

    it('should show add comment button if multi load is selected and enableAddMultiComment is true', async () => {
        renderPlanTableNew();
        const planTable = screen.getByTestId('plan-table');
        expect(planTable).toBeDefined();
        const planTableBody = screen.getByTestId('plan-table-body');
        expect(planTableBody).toBeDefined();
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        fireEvent.click(screen.getByTestId('dt-chkbx-1-50000678'));
        fireEvent.click(screen.getByTestId('dt-chkbx-1-50004376'));

        expect(screen.getByText('Add Comment')).toBeDefined();
    });

    it('should not show add comment button if multi load is selected and enableAddMultiComment is false', async () => {
        TripSharedService.setFeatureFlags({ enableAddMultiComment: false });
        renderPlanTableNew();
        const planTable = screen.getByTestId('plan-table');
        expect(planTable).toBeDefined();
        const planTableBody = screen.getByTestId('plan-table-body');
        expect(planTableBody).toBeDefined();
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        fireEvent.click(screen.getByTestId('dt-chkbx-1-50000678'));
        fireEvent.click(screen.getByTestId('dt-chkbx-1-50004376'));

        expect(screen.queryByText('Add Comment')).toBeNull();
    });

    it('should invoke pOnViewAllComments add button is clicked', async () => {
        renderPlanTableNew();
        const planTable = screen.getByTestId('plan-table');
        expect(planTable).toBeDefined();
        const planTableBody = screen.getByTestId('plan-table-body');
        expect(planTableBody).toBeDefined();
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        fireEvent.click(screen.getByTestId('dt-chkbx-1-50000678'));
        fireEvent.click(screen.getByTestId('dt-chkbx-1-50004376'));
        const addCommentsButton = screen.getByText('Add Comment');
        expect(addCommentsButton).toBeDefined();
        fireEvent.click(addCommentsButton);

        expect(onViewAllCommentsMock).toHaveBeenCalled();
    });
});
