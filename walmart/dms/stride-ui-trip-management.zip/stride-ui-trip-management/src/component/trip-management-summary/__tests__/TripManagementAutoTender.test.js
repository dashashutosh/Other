import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ResizeObserver from 'resize-observer-polyfill';

import { render, screen, fireEvent, within, waitFor } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

import { planSearchAggregatesProcessing, LocationErrorMock } from './mocks/PlanLTPreview.mock';
import { userRlInfoMock } from './mocks/TripManagementSummary.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import PlanSearchAggregatesCA from './mocks/PlanSearchAggregatesCA.mock.json';
import PlanSearchAggregates from './mocks/PlanSearchAggregates.mock.json';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';

import TripManagementSummary from '../TripManagementSummary';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import TripSharedService from '../../../service/TripSharedService';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'CA_CA') {
            return res(ctx.json(PlanSearchAggregatesCA));
        }
        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }
        if (tenantId === 'CL' || tenantId === 'CAM_GT') {
            return res(ctx.json(PlanSearchAggregates));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(CmsConfigUS));
        }
        return res(ctx.json(CmsConfig));
    }),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

// TOOD: @anirudh return proper value
const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const spy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    spy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

beforeEach(() => {
    // jest.useFakeTimers('');
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Auto tender - US', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us', invokeBulkUpdate: jest.fn(() => Promise.resolve()) };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
    });
    it('Should open "Auto Tender" drawer on click auto tender action and verify all fields are available', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const acceptTenderBtn = await screen.findAllByText('Auto Tender');
        fireEvent.click(acceptTenderBtn[0]);

        const originLocationField = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocationField).toBeDefined();
        fireEvent.change(originLocationField, { target: { value: '04/09/2023' } });
        expect(originLocationField.value).toBe('04/09/2023');

        const pickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(pickupDateField).toBeDefined();
        fireEvent.change(pickupDateField, { target: { value: '08/05/2023' } });
        expect(pickupDateField.value).toBe('08/05/2023');

        const carrierAssignmentBtns = screen.getAllByTestId('ld-sc-ui--chip');
        fireEvent.click(carrierAssignmentBtns[1]);
        const carrierField = screen.getByTestId('carrier-scac-input');
        fireEvent.change(carrierField, { target: { value: '453' } });
        expect(carrierField.value).toBe('453');
    });

    it('Should verify tender button available and clickable', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const acceptTenderBtn = await screen.findAllByText('Auto Tender');
        fireEvent.click(acceptTenderBtn[0]);

        const tenderBtn = await screen.findByTestId('auto-tender-button');
        expect(tenderBtn).toBeDefined();
        fireEvent.click(tenderBtn);
    });

    it('Should tender button disable on all fields empty', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const acceptTenderBtn = await screen.findAllByText('Auto Tender');
        fireEvent.click(acceptTenderBtn[0]);

        const originLocationField = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocationField).toBeDefined();
        fireEvent.change(originLocationField, { target: { value: '' } });
        expect(originLocationField.value).toBe('');

        const pickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(pickupDateField).toBeDefined();
        fireEvent.change(pickupDateField, { target: { value: '' } });
        expect(pickupDateField.value).toBe('');

        const locationField = screen.getByTestId('locationId-destination').querySelector('input');
        expect(locationField).toBeDefined();
        fireEvent.change(locationField, { target: { value: '' } });
        expect(locationField.value).toBe('');

        const carrierAssignmentBtns = screen.getAllByTestId('ld-sc-ui--chip');
        fireEvent.click(carrierAssignmentBtns[1]);
        const carrierField = screen.getByTestId('carrier-scac-input');
        fireEvent.change(carrierField, { target: { value: '' } });
        expect(carrierField.value).toBe('');

        const tenderBtn = await screen.findByTestId('auto-tender-button');
        expect(tenderBtn).toHaveProperty('disabled', true);
    });

    it('Should disable tender button on selecting back dates', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const acceptTenderBtn = await screen.findAllByText('Auto Tender');
        fireEvent.click(acceptTenderBtn[0]);

        const pickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(pickupDateField).toBeDefined();
        fireEvent.click(pickupDateField);

        const date = await screen.findByText('15');
        fireEvent.click(date);
        const updatedPickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(updatedPickupDateField.value).toBe('07/15/2023');
        const tenderBtn = await screen.findByTestId('auto-tender-button');
        expect(tenderBtn).toHaveProperty('disabled', true);
    });

    it('Should show success message on Api success', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const acceptTenderBtn = await screen.findAllByText('Auto Tender');
        fireEvent.click(acceptTenderBtn[0]);
        const carrierAssignmentBtns = screen.getAllByTestId('ld-sc-ui--chip');
        fireEvent.click(carrierAssignmentBtns[1]);
        const carrierField = screen.getByTestId('carrier-scac-input');
        fireEvent.change(carrierField, { target: { value: '65415' } });
        expect(carrierField.value).toBe('65415');

        const tenderBtn = await screen.findByTestId('auto-tender-button');
        expect(tenderBtn).toHaveProperty('disabled', false);
        fireEvent.click(tenderBtn);

        const successMsg = screen.queryByText('1 plans submitted for tender successfully. Changes will reflect soon');
        expect(successMsg).toBeDefined();
    });

    it('Should select loads from checkboxes and verify tender button available and clickable', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('100138608'));
        fireEvent.click(checkboxOne);
        const checkboxTwo = await screen.findByTestId(getCheckboxTestId('1000056453'));
        fireEvent.click(checkboxTwo);
        const tenderButton = await screen.findByTestId('AUTO_TENDER');
        expect(tenderButton).toBeDefined();
        fireEvent.click(tenderButton);
    });

    it('Should select one loads from checkboxes and verify tender button available and clickable', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('100138608'));
        fireEvent.click(checkboxOne);
        const tenderButton = await screen.findByTestId('AUTO_TENDER');
        expect(tenderButton).toBeDefined();
        fireEvent.click(tenderButton);

        const originLocationField = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocationField).toBeDefined();
        fireEvent.change(originLocationField, { target: { value: '04/09/2023' } });
        expect(originLocationField.value).toBe('04/09/2023');

        const pickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(pickupDateField).toBeDefined();
        fireEvent.change(pickupDateField, { target: { value: '08/05/2023' } });
        expect(pickupDateField.value).toBe('08/05/2023');
    });

    it('Should not show tender button if both loads dont have same action', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('1000056453'));
        fireEvent.click(checkboxOne);
        const checkboxTwo = await screen.findByTestId(getCheckboxTestId('31710061'));
        fireEvent.click(checkboxTwo);
        expect(screen.queryByTestId('AUTO_TENDER')).toBeNull();
    });

    it('Should select different type load and verify tender button available and fields editable', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('100138608'));
        fireEvent.click(checkboxOne);
        const checkboxTwo = await screen.findByTestId(getCheckboxTestId('1000056453'));
        fireEvent.click(checkboxTwo);
        const tenderButton = await screen.findByTestId('AUTO_TENDER');
        expect(tenderButton).toBeDefined();
        fireEvent.click(tenderButton);

        const pickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(pickupDateField).toBeDefined();
        fireEvent.change(pickupDateField, { target: { value: '08/05/2023' } });
        expect(pickupDateField.value).toBe('08/05/2023');

        const carrierAssignmentBtns = screen.getAllByTestId('ld-sc-ui--chip');
        fireEvent.click(carrierAssignmentBtns[1]);
        const carrierField = screen.getByTestId('carrier-scac-input');
        fireEvent.change(carrierField, { target: { value: '453' } });
        expect(carrierField.value).toBe('453');
    });

    it('Should select different OD pair loads and verify locations fields hide correctly', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('100138608'));
        fireEvent.click(checkboxOne);
        const checkboxTwo = await screen.findByTestId(getCheckboxTestId('1000056453'));
        fireEvent.click(checkboxTwo);
        const tenderButton = await screen.findByTestId('AUTO_TENDER');
        expect(tenderButton).toBeDefined();
        fireEvent.click(tenderButton);
        expect(screen.queryByTestId('locationId-orgin')).toBeNull();
        expect(screen.queryByTestId('locationId-destination')).toBeNull();
    });

    it('Should show tender cancel status', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const thirdRowStatusCell = Array.from(planTableBody.children[2].children).at(-2);
        const individualStatus = within(thirdRowStatusCell).getByAltText('Tender Cancelled');
        expect(individualStatus).toBeDefined();
    });

    it('Should select two loads from checkbox open "Auto Tender" drawer and show success message', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('100138608'));
        fireEvent.click(checkboxOne);
        const checkboxTwo = await screen.findByTestId(getCheckboxTestId('1000056453'));
        fireEvent.click(checkboxTwo);
        const tenderButton = await screen.findByTestId('AUTO_TENDER');
        expect(tenderButton).toBeDefined();
        fireEvent.click(tenderButton);

        const tenderBtn = await screen.findByTestId('auto-tender-button');
        expect(tenderBtn).toHaveProperty('disabled', false);
        fireEvent.click(tenderBtn);

        const successMsg = screen.queryByText('1 Plans are approved. Changes will reflect soon');
        expect(successMsg).toBeDefined();
    });

    it('Should show error message on location API fail in auto tender', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}locationDetails/locationTSSSearch`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(LocationErrorMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const acceptTenderBtn = await screen.findAllByText('Auto Tender');
        fireEvent.click(acceptTenderBtn[0]);
        expect(screen.queryByText("Couldn't process the request. Try again")).toBeDefined();
    });
});
