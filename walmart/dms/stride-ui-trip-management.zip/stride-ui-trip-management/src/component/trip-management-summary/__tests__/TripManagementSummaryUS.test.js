import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { AppUtils } from '@gscope-mfe/app-bridge';

import ResizeObserver from 'resize-observer-polyfill';
import { render, screen, fireEvent, within, waitFor } from '../../../utils/test-utils';
import { API_GATEWAY_PREFIX_NEW, getUpdatedCMSConfig } from '../../../utils/test-helpers';
import {
    SEARCH_RESULT_TABLE_BODY_TEST_ID,
    getTableCellTestId,
    getCheckboxTestId,
} from './trip-management-summary-us-test-helpers';

import TripSharedService from '../../../service/TripSharedService';
import TripManagementSummary from '../TripManagementSummary';

// Mock Data
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import PlanSearchAggregatesForRelayTrip from '../US/__tests__/mocks/PlanSearchAggregrateRelayTrip.mock.json';
import PlanSearchAggregateFailUS from '../US/__tests__/mocks/PlanSearchAggregateFailUS.mock.json';
import { groupByIMPlanResults, groupByLoadPlanResults } from '../US/__tests__/mocks/PlanSearchResultsGroupBy.mock';
import {
    apporveMock,
    approveErrorMock,
    assignCarrierMock,
    assignTripMock,
    autoTenderMock,
    cancelErrorMock,
    cancelMock,
    cancelTripMock,
    markasDeliveredMock,
    planSearchAggregatesInTransit,
    tripSheetErrorMock,
    userRlInfoMock,
    cancelErrorInfoMock,
    cancelTripErrorMock,
    cancelTripPartialErrorMock,
    cancelTripNotFoundError,
    cancelRelayTripError,
} from './mocks/TripManagementSummary.mock';
import { planCountsZero } from '../US/__tests__/mocks/planCounts.mock';
import { fileSample } from './mocks/PlanLTPreview.mock';
import TableColumnsUS from '../../model/TableColumnsUS';

const serviceTypeReal = 'stride-ResouceBEAPI';
const fileBuffer = Uint8Array.from(window.atob(fileSample), (c) => c.charCodeAt(0));

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;

        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }

        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}approveStatusChange/approveStatusChange`, (req, res, ctx) =>
        res(ctx.json(apporveMock)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res;
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}assignTrip/assignTrip`, (req, res, ctx) => res(ctx.json(assignTripMock))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}autoTender/autoTender`, (req, res, ctx) => res(ctx.json(autoTenderMock))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}assignCarrier/assignCarrier`, (req, res, ctx) =>
        res(ctx.json(assignCarrierMock)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}markInTransitDelivered/markInTransitDelivered`, (req, res, ctx) =>
        res(ctx.json(markasDeliveredMock)),
    ),
    rest.post(`${serviceTypeReal}/getDispatchDocument`, (req, res, ctx) =>
        res(
            ctx.set('Content-Length', fileBuffer.byteLength.toString()),
            ctx.set('Content-Type', 'application/pdf'),
            ctx.body(fileBuffer),
        ),
    ),
    rest.post(`${serviceTypeReal}/getDispatchLabel`, (req, res, ctx) =>
        res(
            ctx.set('Content-Length', fileBuffer.byteLength.toString()),
            ctx.set('Content-Type', 'application/pdf'),
            ctx.body(fileBuffer),
        ),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}approvePlans/approvePlans`, (req, res, ctx) => res(ctx.json(apporveMock))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}planCounts/planCounts`, (req, res, ctx) => res(ctx.json(planCountsZero))),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us' || market === 'ustrx') {
            return res(ctx.json(CmsConfigUS));
        }
        return res.status(404);
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}cancelLoadMulti/cancelLoadMulti`, (req, res, ctx) => res(ctx.json(cancelMock))),
    rest.post('api/gateway/v4/stride-ResouceBEAPI/getDispatchDocument', (req, res, ctx) => res(ctx.status(200))),
    rest.post('api/gateway/v4/stride-ResouceBEAPI/getDispatchLabel', (req, res, ctx) => res(ctx.status(200))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}cancelTrip/cancelTrip`, (req, res, ctx) => res(ctx.json(cancelTripMock))),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
        'ustrx.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt', 'ustrx'],
});

const userReadPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:READ',
        'ustrx.stride.ltm-tripManagement:READ',
    ],
    markets: ['ca', 'us', 'cl', 'gt', 'ustrx'],
});

// TOOD: @anirudh return proper value
const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));

jest.setTimeout(30000);

beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const spy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    spy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

beforeEach(() => {
    // jest.useFakeTimers('');
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Bulk history link', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
    });
    it('Should open bulk history page on clicking bulk history icon', () => {
        render(<TripManagementSummary />);
        window.open = jest.fn();
        const bulkHistoryLink = screen.getByTestId('bulkHistoryButton').querySelector('svg');
        fireEvent.click(bulkHistoryLink);
        expect(window.open).toBeCalledWith('/bulkupload/history');
    });
});

// Todo: R2 - review comment - Move the US related test cases to a dedicated file.
describe('Trip management summary test cases for US', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
    });

    it('should render without crashing', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Delivered tab should be shown for US
        const tab = await screen.findByText('Delivered');
        expect(tab).toBeDefined();
    });

    it('should have a default sorting column on each phase', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        let planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const processingTab = screen.getByText('Processing');
        const readyToStartTab = screen.getByText('Ready to start');
        const inTransitTab = screen.getByText('In transit');
        const deliveredTab = screen.getByText('Delivered');

        // On load, Planning tab should have planId as default sort column
        expect(screen.getByTestId(getTableCellTestId('0', TableColumnsUS.PLAN_ID.id)).getAttribute('aria-sort')).toBe(
            'none',
        );
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.ORIGIN_LOCATION_ID.id)).getAttribute('aria-sort'),
        ).toBe('none');
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.PLANNED_START.id)).getAttribute('aria-sort'),
        ).toBe('ascending');

        fireEvent.click(processingTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        expect(screen.getByTestId(getTableCellTestId('0', TableColumnsUS.PLAN_ID.id)).getAttribute('aria-sort')).toBe(
            'none',
        );
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.ORIGIN_LOCATION_ID.id)).getAttribute('aria-sort'),
        ).toBe('none');
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.PLANNED_START.id)).getAttribute('aria-sort'),
        ).toBe('ascending');

        fireEvent.click(readyToStartTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        expect(screen.getByTestId(getTableCellTestId('0', TableColumnsUS.PLAN_ID.id)).getAttribute('aria-sort')).toBe(
            'none',
        );
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.ORIGIN_LOCATION_ID.id)).getAttribute('aria-sort'),
        ).toBe('none');
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.PLANNED_START.id)).getAttribute('aria-sort'),
        ).toBe('ascending');

        fireEvent.click(inTransitTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        expect(screen.getByTestId(getTableCellTestId('0', TableColumnsUS.PLAN_ID.id)).getAttribute('aria-sort')).toBe(
            'none',
        );
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.ORIGIN_LOCATION_ID.id)).getAttribute('aria-sort'),
        ).toBe('none');
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.ACTUAL_START.id)).getAttribute('aria-sort'),
        ).toBe('ascending');

        fireEvent.click(deliveredTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(screen.getByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID).children.length).toBeGreaterThan(0);
        });
        expect(screen.getByTestId(getTableCellTestId('0', TableColumnsUS.PLAN_ID.id)).getAttribute('aria-sort')).toBe(
            'none',
        );
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.ORIGIN_LOCATION_ID.id)).getAttribute('aria-sort'),
        ).toBe('none');
        expect(
            screen.getByTestId(getTableCellTestId('0', TableColumnsUS.ACTUAL_START.id)).getAttribute('aria-sort'),
        ).toBe('ascending');
    });

    it('sorting columns', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // On load, Planning tab should have plannedStart as default sort column
        expect(
            screen.getByTestId(getTableCellTestId(0, TableColumnsUS.PLANNED_START.id)).getAttribute('aria-sort'),
        ).toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by plan type on click on table header cell
        // const planEntity = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.PLAN_ENTITY.id));
        // fireEvent.click(planEntity.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.PLAN_ENTITY.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // should sort by origin on click on table header cell
        const origin = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.ORIGIN_LOCATION_ID.id));
        fireEvent.click(origin.children[0]);
        expect(
            screen.getByTestId(getTableCellTestId(0, TableColumnsUS.ORIGIN_LOCATION_ID.id)).getAttribute('aria-sort'),
        ).toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by distance on click on table header cell
        // const distance = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.DISTANCE.id));
        // fireEvent.click(distance.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.DISTANCE.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // should sort by destination on click on table header cell
        const destination = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.DESTINATION_LOCATION_ID.id));
        fireEvent.click(destination.children[0]);
        expect(
            screen
                .getByTestId(getTableCellTestId(0, TableColumnsUS.DESTINATION_LOCATION_ID.id))
                .getAttribute('aria-sort'),
        ).toBe('ascending');

        // should sort by plannedStart on click on table header cell
        const plannedStart = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.PLANNED_START.id));
        fireEvent.click(plannedStart.children[0]);
        expect(
            screen.getByTestId(getTableCellTestId(0, TableColumnsUS.PLANNED_START.id)).getAttribute('aria-sort'),
        ).toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by duration on click on table header cell
        // const duration = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.DURATION.id));
        // fireEvent.click(duration.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.DURATION.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by pickupStops on click on table header cell
        // const pickupStops = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.PICKUP_STOPS.id));
        // fireEvent.click(pickupStops.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.PICKUP_STOPS.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by deliveryStops on click on table header cell
        // const deliveryStops = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.DELIVERY_STOPS.id));
        // fireEvent.click(deliveryStops.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.DELIVERY_STOPS.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // should not sort by status

        const statusHeaderCell = screen.queryByTestId(getTableCellTestId(0, TableColumnsUS.STATUS.id));
        expect(statusHeaderCell.textContent).toBe('Status');
        expect(within(statusHeaderCell).queryByRole('button')).not.toBeInTheDocument();

        // should not sort by actions
        const actionsHeaderCell = screen.queryByTestId(getTableCellTestId(0, TableColumnsUS.ACTIONS.id));
        expect(actionsHeaderCell.textContent).toBe('Actions');
        expect(within(actionsHeaderCell).queryByRole('button')).not.toBeInTheDocument();

        // fireEvent.click(processingTab);
        // Todo: once BE team provided, will uncomment
        // // should sort by carrier on click on table header cell
        // const carrierId = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.CARRIER_ID.id));
        // fireEvent.click(carrierId.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.CARRIER_ID.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by serviceTerritory on click on table header cell
        // const serviceTerritory = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.SERVICE_TERRITORY.id));
        // fireEvent.click(serviceTerritory.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.SERVICE_TERRITORY.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by trailer on click on table header cell
        // const trailerId = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.TRAILER_ID.id));
        // fireEvent.click(trailerId.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.TRAILER_ID.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by driver on click on table header cell
        // const driverId = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.DRIVER_ID.id));
        // fireEvent.click(driverId.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.DRIVER_ID.id)).getAttribute('aria-sort'))
        // .toBe('ascending');

        // Todo: once BE team provided, will uncomment
        // // should sort by billsByTime on click on table header cell
        // const billsByTime = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.BILLS_BY_TIME.id));
        // fireEvent.click(billsByTime.children[0]);
        // expect(screen.getByTestId(getTableCellTestId(0, TableColumnsUS.BILLS_BY_TIME.id)).getAttribute('aria-sort'))
        // .toBe('ascending');
        const inTransitTab = screen.getByText('In transit');
        fireEvent.click(inTransitTab);

        const searchResultsTableBodyInTransit = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(searchResultsTableBodyInTransit.children.length).toBeGreaterThan(0);
        });

        // should sort by actualStart on click on table header cell
        const actualStartHeaderCell = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.ACTUAL_START.id));
        const planIdHeaderCell = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.PLAN_ID.id));

        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(actualStartHeaderCell.getAttribute('aria-sort')).toBe('ascending');

        fireEvent.click(actualStartHeaderCell.children[0]);
        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(actualStartHeaderCell.getAttribute('aria-sort')).toBe('descending');

        // when enableMultiSortForSearchTable feature flag is disabled,
        // clicking on a column with shift key shouldn't trigger multi sort
        fireEvent.click(within(planIdHeaderCell).getByRole('button'), { shiftKey: true });
        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(actualStartHeaderCell.getAttribute('aria-sort')).toBe('none');
    });

    it('multi sorting should work as expected when enableMultiSortForSearchTable feature flag is enabled', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfigUS, {
            enableMultiSortForSearchTable: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));

        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const plannedStartHeaderCell = await screen.findByTestId(
            getTableCellTestId(0, TableColumnsUS.PLANNED_START.id),
        );
        const planIdHeaderCell = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.PLAN_ID.id));
        const originHeaderCell = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.ORIGIN_LOCATION_ID.id));
        const destinationHeaderCell = await screen.findByTestId(
            getTableCellTestId(0, TableColumnsUS.DESTINATION_LOCATION_ID.id),
        );

        expect(plannedStartHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(originHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(destinationHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(within(destinationHeaderCell).getByRole('button')).toBeInTheDocument();
        expect(screen.queryByTestId('query-chips-container')).not.toBeInTheDocument();

        fireEvent.click(within(planIdHeaderCell).getByRole('button'), { shiftKey: true });
        expect(plannedStartHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(originHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(destinationHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(within(destinationHeaderCell).getByRole('button')).toBeInTheDocument();
        expect(screen.getByTestId('query-chips-container')).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.PLANNED_START.id)).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.PLAN_ID.id)).toBeInTheDocument();

        fireEvent.click(within(originHeaderCell).getByRole('button'), { shiftKey: true });
        expect(plannedStartHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(originHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(destinationHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(screen.getByTestId('query-chips-container')).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.PLANNED_START.id)).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.PLAN_ID.id)).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.ORIGIN_LOCATION_ID.id)).toBeInTheDocument();

        // trying to sort 4th column shouldn't make any change in the UI
        expect(within(destinationHeaderCell).queryByRole('button')).not.toBeInTheDocument();
        fireEvent.click(destinationHeaderCell, { shiftKey: true });
        expect(plannedStartHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(originHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(destinationHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(screen.getByTestId('query-chips-container')).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.PLANNED_START.id)).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.PLAN_ID.id)).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.ORIGIN_LOCATION_ID.id)).toBeInTheDocument();

        // clicking on close button in sort chip should remove the sort
        const originSortChip = screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.ORIGIN_LOCATION_ID.id);
        fireEvent.click(within(originSortChip).getByLabelText('Remove'));
        expect(plannedStartHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(originHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(destinationHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(screen.getByTestId('query-chips-container')).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.PLANNED_START.id)).toBeInTheDocument();
        expect(screen.getByTestId('multi-sort-info-chip-' + TableColumnsUS.PLAN_ID.id)).toBeInTheDocument();
        expect(originSortChip).not.toBeInTheDocument();

        // clicking on a header without holding shift key should come out of multi sort
        fireEvent.click(within(originHeaderCell).getByRole('button'));
        expect(plannedStartHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(planIdHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(originHeaderCell.getAttribute('aria-sort')).toBe('ascending');
        expect(destinationHeaderCell.getAttribute('aria-sort')).toBe('none');
        expect(screen.queryByTestId('query-chips-container')).not.toBeInTheDocument();

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
    });

    // TODO: Fix this test after MFE migration
    it.skip('different sets of table data', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);

        // Plan Id should be available
        const planIdCell = await screen.findAllByTestId('planId-cell');
        expect(planIdCell[0].textContent).toBe('22527129');

        // For load, it should also display load type
        const planTypeCell = await screen.findAllByTestId('planType-cell');
        expect(planTypeCell[0].textContent).toBe('Load - STR');
        // For trip, it should also display trip type and load count
        expect(planTypeCell[1].textContent).toBe('Trip - STR2');

        // Carrier should show '--' if none assigned
        const carrier = await screen.findAllByTestId('carrierId-cell');
        expect(carrier[2].textContent).toBe('--');
        // Carrier should show if assigned
        expect(carrier[0].textContent).toBe('WALM Carrier');

        // Service territory should show '-' for loads
        const serviceTerritory = await screen.findAllByTestId('serviceTerritory-cell');
        expect(serviceTerritory[0].textContent).toBe('-');
        // Service territory should show for trips
        expect(serviceTerritory[4].textContent).toBe('WALM Territory');
        // Service territory should show '--' for trips if data not available
        expect(serviceTerritory[1].textContent).toBe('6801');

        // Trailer id should show '--' if no data
        const trailerId = await screen.findAllByTestId('trailerId-cell');
        expect(trailerId[0].textContent).toBe('--');
        expect(trailerId[2].textContent).toBe('--');
        // Trailer id should show for trips of first load and +<count> if more than one trailer for
        // the loads under trip
        expect(trailerId[1].textContent).toBe('12345+1');

        // driverId should show '-' for loads
        const driverId = await screen.findAllByTestId('driverId-cell');
        expect(driverId[0].textContent).toBe('-');
        // driverId should show for trips
        expect(driverId[1].textContent).toBe('1234driver_firstname driver_lastname');
        // driverId should show ''(--) for trips if data not available
        expect(driverId[4].textContent).toBe('--');

        // planStartTime should show in the format dd MMM, YYYY
        const planStartTime = await screen.findAllByTestId('planStartTime-cell');
        expect(planStartTime[1].textContent).toMatch(/01 Nov, 2021/);

        // planStartTime should show date with timestamp
        const planStartTime1 = await screen.findAllByTestId('planStartTime-cell');
        expect(planStartTime1[0].textContent).toBe(' 16 Jan, 2023, 09:58 pm (CT) ');

        // duration should show in the format HH:MM
        const duration = await screen.findAllByTestId('duration-cell');
        expect(duration[1].textContent).toBe('01:10');

        // billsByTime should show '-' for loads
        const billsByTime = await screen.findAllByTestId('billsByTime-cell');
        expect(billsByTime[0].textContent).toBe('-');
        // billsByTime should show date(dd MMM, YYYY; hh:MM) for trips
        expect(billsByTime[1].textContent).toMatch(/01 Nov, 2021/);

        // billsByTime should show date with timestamp
        const billsByTime1 = await screen.findAllByTestId('billsByTime-cell');
        expect(billsByTime1[4].textContent).toBe('01 Nov, 2021, 08:51 pm (CT)');

        // status should show for all main entities
        // const status = await screen.findAllByTestId('status-cell');
        // const individualStatus = within(status[2]).getByAltText('Awaiting carrier assignment');
        // expect(individualStatus).toBeDefined();

        // Transit phase table should not have checkboxes
        const inTransitTab = screen.getByText('In transit');
        fireEvent.click(inTransitTab);
        expect(screen.queryByTestId('dt-chkbx-3-500003987')).toBeNull();

        // actualTs should show date with timestamp
        const actualTs = await screen.findAllByTestId('actualTs-cell');
        expect(actualTs[0].textContent).toMatch(/20 Jan, 2023, 02:01 am/);

        const inTransitEndDateEstimatedCell = await screen.findAllByTestId('endDateEstimated-cell');
        expect(inTransitEndDateEstimatedCell[0].textContent).toBe('--');

        const priorityCell = await screen.findAllByTestId('priority-cell');
        expect(priorityCell[0].textContent).toBe('MEDIUM');

        // Actions column should show '...'
        const actions = await screen.findAllByTestId('actions-cell');
        expect(actions[0].textContent).toBe('...');

        const intrasitStartDatePlannedCell = await screen.findAllByTestId('intrasitStartDatePlanned-cell');
        expect(intrasitStartDatePlannedCell[0].textContent).toMatch('16 Jan, 2023, 09:58 pm (CT)');

        const inTransitEndDatePlannedCell = await screen.findAllByTestId('endDatePlanned-cell');
        expect(inTransitEndDatePlannedCell[0].textContent).toBe('20 Jan, 2023, 12:00 am (GMT+0)');

        // Delivered phase table should not have checkboxes
        const deliveredTab = screen.getByText('Delivered');
        fireEvent.click(deliveredTab);
        expect(screen.queryByTestId('dt-chkbx-4-500003987')).toBeNull();
        const deliveredEndDatePlannedCell = await screen.findAllByTestId('endDatePlanned-cell');
        expect(deliveredEndDatePlannedCell[0].textContent).toBe('20 Jan, 2023, 12:00 am (GMT+0)');
        const deliveredEndDateActualCell = await screen.findAllByTestId('endDateActual-cell');
        expect(deliveredEndDateActualCell[0].textContent).toBe('--');
    });

    it('table client search', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const totalResult = screen.getByText('10 results');
        expect(totalResult).toBeDefined();

        const tableSearch = await screen.findByTestId('search');
        fireEvent.change(tableSearch, { target: { value: 'PLT' } });

        await waitFor(() => {
            const totalResult1 = screen.getByText('1 results');
            expect(totalResult1).toBeDefined();
        });

        fireEvent.change(tableSearch, { target: { value: '' } });

        await waitFor(() => {
            const result = screen.getByText('10 results');
            expect(result).toBeDefined();
        });

        fireEvent.change(tableSearch, { target: { value: '20 Jan' } });

        await waitFor(() => {
            const result = screen.getByText('0 results');
            expect(result).toBeDefined();
        });
    });

    // Todo: No checkbox column for R1
    it.skip('Multi checkbox selection', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // single select load.
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('500003987'));
        fireEvent.click(checkbox1);
        const msg1 = await screen.findByText('plan selected');
        expect(msg1).toBeDefined();

        // multi select load.
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('50001927'));
        fireEvent.click(checkbox2);
        const msg2 = await screen.findByText('plans selected');
        expect(msg2).toBeDefined();

        // clear selected checkbox selection
        const clear = await screen.findByText('Clear');
        expect(clear).toBeDefined();
        fireEvent.click(clear);
        const selectMsg = screen.queryByText('plans selected');
        expect(selectMsg).toBeNull();

        // checkbox selection in processing tab
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        // single select trip.
        const checkbox3 = await screen.findByTestId('dt-chkbx-1-30068925');
        fireEvent.click(checkbox3);
        const msg3 = await screen.findByText('plan selected');
        expect(msg3).toBeDefined();
        // multi select trip.
        const checkbox4 = await screen.findByTestId('dt-chkbx-1-30003577');
        fireEvent.click(checkbox4);
        const msg4 = await screen.findByText('plans selected');
        expect(msg4).toBeDefined();
    });

    // Todo: No checkbox column for R1
    it.skip('No actions for the plans - selection', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // single select load.
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('50001928'));
        fireEvent.click(checkbox1);
        const msg1 = await screen.findByText('plan selected');
        expect(msg1).toBeDefined();

        // multi select load.
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('50000616'));
        fireEvent.click(checkbox2);
        const msg2 = await screen.findByText('plans selected');
        expect(msg2).toBeDefined();

        const cancelButton = screen.queryByTestId('CANCEL');
        expect(cancelButton).toBeNull();
    });

    it('Trip row expantion', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        let planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const loadId = screen.queryByText('22527127');
        expect(loadId).toBeNull();
        const expandRowIcon = await screen.findAllByLabelText('Row Expand Toggle');
        fireEvent.click(expandRowIcon[0]);
        const msg1 = await screen.findByText('22527127');
        expect(msg1).toBeDefined();

        // Delivered phase table row expantion
        const deliveredTab = screen.getByText('Delivered');
        fireEvent.click(deliveredTab);

        planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const deliveryLoadId = screen.queryByText('22527127');
        expect(deliveryLoadId).toBeNull();
        const expandRow = await screen.findAllByLabelText('Row Expand Toggle');
        fireEvent.click(expandRow[0]);
        const load2 = await screen.findByText('22527127');
        expect(load2).toBeDefined();
    });

    // Todo: No actions column for R1
    it.skip('Accessing action from action menu on Actions column', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // Actions column should show '...'
        const actions = await screen.findAllByTestId('actions-cell');
        expect(actions[0].textContent).toBe('...');
        const btn = actions[0].firstChild;
        fireEvent.click(btn);
        const actionApprove = await screen.findByText('Approve');
        expect(actionApprove).toBeDefined();
        fireEvent.click(actionApprove);
        // Success message should appear
        const msg = await screen.findByText('Plan(s) approved. Changes will reflect soon.');
        expect(msg).toBeDefined();
    });

    // Todo: no Exception filters for R1
    it.skip('exception filter chips flow', async () => {
        render(<TripManagementSummary />);

        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const processingTab = screen.getByText('Processing');
        const inTransitTab = screen.getByText('In transit');
        const exceptionChipsCode = {
            AUTO_TOTE_EXCHANE: 'AUTO_TOTE_EXCHANE',
            NO_TRAILER_ASSIGNED: 'NO_TRAILER_ASSIGNED',
        };

        // changing tab show show new set of filter chips
        fireEvent.click(processingTab);
        const autoToteExceptionChip = screen.getByTestId(`stc-exception-chip-${exceptionChipsCode.AUTO_TOTE_EXCHANE}`);
        expect(autoToteExceptionChip).toBeDefined();

        // Clicking on exception filter chip action button should toggle the text
        const actionButton = within(autoToteExceptionChip).getByTestId(
            `stc-exception-chip-action-${exceptionChipsCode.AUTO_TOTE_EXCHANE}`,
        );
        expect(actionButton.textContent).toEqual('View loads');
        fireEvent.click(actionButton);
        expect(actionButton.textContent).toEqual('Remove filter');
        fireEvent.click(actionButton);
        expect(actionButton.textContent).toEqual('View loads');

        fireEvent.click(inTransitTab);
        expect(screen.queryByTestId(`stc-exception-chip-${exceptionChipsCode.AUTO_TOTE_EXCHANE}`)).toBeNull();
    });

    // Todo: No golbal search for R1
    it('Global search flow if no results', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(PlanSearchAggregateFailUS));
                }
            }),
        );

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const gsText = await wrapper.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        fireEvent.change(gsText, { target: { value: '12345,12345' } });
        expect(gsText.value).toBe('12345,12345');

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);

        const zeroResults = await screen.findByText('0 search results');
        expect(zeroResults).toBeDefined();

        const noResults = await screen.findByText('No search results found');
        expect(noResults).toBeDefined();
    });

    it('Global search flow if some results', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const gsText = await wrapper.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        fireEvent.change(gsText, { target: { value: '1,2' } });
        expect(gsText.value).toBe('1,2');

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);
        const title = await screen.findByText('152 search results');
        expect(title).toBeDefined();
    });

    it('Global search flow - Trip', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const gsText = await wrapper.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        const gsPlanType = screen.getByText('Type');
        fireEvent.click(gsPlanType);
        const gsTrip = screen.getByText('Trip');
        fireEvent.click(gsTrip);

        fireEvent.change(gsText, { target: { value: '1,2' } });
        expect(gsText.value).toBe('1,2');

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);
        const title = await screen.findByText('152 search results');
        expect(title).toBeDefined();

        const expandRowIcon = screen.queryAllByLabelText('Row Expand Toggle');
        expect(expandRowIcon).toHaveLength(0);
    });

    it('Global search flow - for RDC loads', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const gsText = await wrapper.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        fireEvent.change(gsText, { target: { value: '123' } });
        expect(gsText.value).toBe('123');

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);
        const title = await screen.findByText('152 search results');
        expect(title).toBeDefined();

        const expandRowIcon = screen.queryAllByLabelText('Row Expand Toggle');
        expect(expandRowIcon).toHaveLength(0);
    });

    // Todo: No golbal search for R1
    it.skip('Global search - should show error alert if api fails', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planCounts/planCounts`, (req, res, ctx) =>
                res(
                    ctx.status(500),
                    ctx.json({
                        error: 'error',
                    }),
                ),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const gsText = await wrapper.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        fireEvent.change(gsText, { target: { value: '1,2' } });
        expect(gsText.value).toBe('1,2');

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);
        const title = await screen.findByText('Load & Trip Lifecycle');
        expect(title).toBeDefined();
    });

    // Todo: No actions for R1
    it.skip('approve action in planning tab with succesful responce', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // Select a trip with pending approval status.
        const checkbox = await screen.findByTestId(getCheckboxTestId('500003987'));
        fireEvent.click(checkbox);
        // Click on apporve button.
        const apporveButton = await screen.findByTestId('APPROVE');
        expect(apporveButton).toBeDefined();
        fireEvent.click(apporveButton);
        // Success message should appear
        const msg = await screen.findByText('Plan(s) approved. Changes will reflect soon.');
        expect(msg).toBeDefined();
    });

    // Todo: No actions for R1
    // TODO: Approve Action - 200 Okay with invalid payload
    it.skip('TODO: approve action in planning tab with invalid payload', async () => {});

    // Todo: No actions for R1
    it.skip('approve action failure in planning tab with with service failure', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}approvePlans/approvePlans`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(approveErrorMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // Select a trip with pending approval status.
        const checkbox = await screen.findByTestId(getCheckboxTestId('500003987'));
        fireEvent.click(checkbox);
        // Click on apporve button.
        const apporveButton = await screen.findByTestId('APPROVE');
        expect(apporveButton).toBeDefined();
        fireEvent.click(apporveButton);
        // Failure message should appear
        const msg = await screen.findByText(approveErrorMock.errors[0].errorIdentifiers.details.errors[0].description);
        expect(msg).toBeDefined();
    });

    it('cancel action in planning tab with successful response - load', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // Select a trip with pending approval status.
        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the load?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the load will move the orders to back to the planning pool.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Success message should appear
        const msg = await screen.findByText('Load Cancelled successfully. Changes will reflect soon.');
        expect(msg).toBeDefined();

        // Cancel plan modal should not be visible
        expect(screen.queryByText('Are you sure you want to cancel the load?')).toBeNull();
    });

    it('cancel action in planning tab with successful response - trip', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('500003888'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the trip?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the trip will cancel all the loads and the associated transportation orders.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Success message should appear
        const msg = await screen.findByText('Trip Cancelled successfully. Changes will reflect soon.');
        expect(msg).toBeDefined();

        // Cancel plan modal should not be visible
        expect(screen.queryByText('Are you sure you want to cancel the trip?')).toBeNull();
    });
    it('cancel trip action should display error alert - 5xx error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}cancelTrip/cancelTrip`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(cancelTripErrorMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('500003888'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the trip?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the trip will cancel all the loads and the associated transportation orders.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Failure message should appear
        const msg = await screen.findByText(
            cancelTripErrorMock.errors[0].errorIdentifiers.details.tripDetails.errors[0].description,
        );
        expect(msg).toBeDefined();
        // Cancel plan modal should not be visible
        expect(screen.queryByText('Are you sure you want to cancel the trip?')).toBeNull();
    });
    it('cancel trip action should display error alert - 5xx partial error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}cancelTrip/cancelTrip`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(cancelTripPartialErrorMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('500003888'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the trip?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the trip will cancel all the loads and the associated transportation orders.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Failure message should appear
        const msg = await screen.findByText(
            cancelTripPartialErrorMock.errors[0].errorIdentifiers.details.planDetails.errors[0].description,
        );
        expect(msg).toBeDefined();
        // Cancel plan modal should not be visible
        expect(screen.queryByText('Are you sure you want to cancel the trip?')).toBeNull();
    });
    it('cancel trip action should display error alert - 4xx error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}cancelTrip/cancelTrip`, (req, res, ctx) =>
                res(ctx.status(400), ctx.json(cancelTripNotFoundError)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('500003888'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the trip?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the trip will cancel all the loads and the associated transportation orders.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Failure message should appear
        const msg = await screen.findByText(cancelTripNotFoundError.error);
        expect(msg).toBeDefined();
        // Cancel plan modal should not be visible
        expect(screen.queryByText('Are you sure you want to cancel the trip?')).toBeNull();
    });
    it('cancel relay trip action should display error alert - 5xx error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(PlanSearchAggregatesForRelayTrip));
                }
            }),
        );
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}cancelRelayTrip/cancelRelayTrip`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(cancelRelayTripError)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('600014129'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the trip?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the trip will cancel all the loads and the associated transportation orders.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Failure message should appear
        const msg = await screen.findByText(
            cancelRelayTripError.errors[0].errorIdentifiers.details.errors[0].description,
        );
        expect(msg).toBeDefined();
        // Cancel plan modal should not be visible
        expect(screen.queryByText('Are you sure you want to cancel the trip?')).toBeNull();
    });
    it('cancel relay trip action should display error alert - 4xx error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(PlanSearchAggregatesForRelayTrip));
                }
            }),
        );
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}cancelRelayTrip/cancelRelayTrip`, (req, res, ctx) =>
                res(ctx.status(400), ctx.json(cancelTripNotFoundError)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('600014129'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the trip?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the trip will cancel all the loads and the associated transportation orders.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Failure message should appear
        const msg = await screen.findByText(cancelTripNotFoundError.error);
        expect(msg).toBeDefined();
        // Cancel plan modal should not be visible
        expect(screen.queryByText('Are you sure you want to cancel the trip?')).toBeNull();
    });
    it('cancel action failure with error description response', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}cancelLoadMulti/cancelLoadMulti`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(cancelErrorMock)),
            ),
        );

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // Select a trip with pending approval status.
        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the load?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the load will move the orders to back to the planning pool.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Failure message should appear
        const msg = await screen.findByText('RLOG load attached to trip cant be canceled');
        expect(msg).toBeDefined();
    });
    it('cancel action failure with error info response', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}cancelLoadMulti/cancelLoadMulti`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(cancelErrorInfoMock)),
            ),
        );

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // Select a trip with pending approval status.
        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        // Click on cancel button.
        const cancelButton = await screen.findByTestId('CANCEL');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        // Cancel plan modal should appear
        const cancelModalHeader = await screen.findByText('Are you sure you want to cancel the load?');
        expect(cancelModalHeader).toBeDefined();
        const cancelMsg = await screen.findByText(
            'Cancelling the load will move the orders to back to the planning pool.',
        );
        expect(cancelMsg).toBeDefined();
        const cancelReasonDropdown = screen.getByTestId('input-reason');
        expect(cancelReasonDropdown).toBeDefined();
        fireEvent.click(cancelReasonDropdown);
        const dropdownMenuItem = screen.getByText('Walmart Transportation');
        fireEvent.click(dropdownMenuItem);
        const confirmButton = await screen.findByTestId('actionBtn');
        expect(confirmButton).toBeDefined();
        fireEvent.click(confirmButton);
        // Failure message should appear
        const msg = await screen.findByText('load attached to trip cant be canceled');
        expect(msg).toBeDefined();
    });
    // Todo: No actions for R1
    it.skip('Generate trip sheet action in planning tab with successful response', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('30003577'));
        fireEvent.click(checkbox);
        // Click on generate trip sheet button.
        const tripSheetButton = await screen.findByTestId('GENERATE_TRIP_SHEET');
        expect(tripSheetButton).toBeDefined();
        fireEvent.click(tripSheetButton);
        // Success message should appear
        const msg = await screen.findByText('Successfully generated trip sheet');
        expect(msg).toBeDefined();
    });

    // Todo: No actions for R1
    it.skip('Generate trip sheet action in planning tab with service failure with default error message', async () => {
        server.use(
            rest.post('api/gateway/v4/stride-ResouceBEAPI/getDispatchDocument', (req, res, ctx) =>
                res(ctx.status(500)),
            ),
        );

        const wrapper = render(<TripManagementSummary />);

        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('30003577'));
        fireEvent.click(checkbox);
        // Click on generate trip sheet button.
        const tripSheetButton = await screen.findByTestId('GENERATE_TRIP_SHEET');
        expect(tripSheetButton).toBeDefined();

        fireEvent.click(tripSheetButton);
        // Failure message should appear
        const msg = await screen.findByText("Couldn't process the request. Try again");
        expect(msg).toBeDefined();
    });

    // Todo: No actions for R1
    it.skip('Generate trip sheet action in planning tab with service failure with api error message', async () => {
        server.use(
            rest.post('api/gateway/v4/stride-ResouceBEAPI/getDispatchDocument', (req, res, ctx) =>
                res(ctx.status(500), ctx.json(tripSheetErrorMock)),
            ),
        );

        const wrapper = render(<TripManagementSummary />);

        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('30003577'));
        fireEvent.click(checkbox);
        // Click on generate trip sheet button.
        const tripSheetButton = await screen.findByTestId('GENERATE_TRIP_SHEET');
        expect(tripSheetButton).toBeDefined();

        fireEvent.click(tripSheetButton);
        // API error message should appearr
        const msg = await screen.findByText(
            tripSheetErrorMock.errors[0].errorIdentifiers.details.errors[0].description,
        );
        expect(msg).toBeDefined();
    });

    // Todo: No actions for R1
    it.skip('should open RLOG modal', async () => {
        const wrapper = render(<TripManagementSummary />);

        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('30003577'));
        fireEvent.click(checkbox);
        // Click on ADD REVERSE LOGISTICS button.
        const RLOGButton = await screen.findByTestId('ADD_REVERSE_LOGISTICS');
        expect(RLOGButton).toBeDefined();

        fireEvent.click(RLOGButton);
        // RLOG modal should appear
        const modalHeader = await screen.findByTestId('rl-modal-header');
        expect(modalHeader).toBeDefined();
    });

    it('edit action in planning tab with succesful responce', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // Select a trip with pending approval status.
        const checkbox = await screen.findByTestId(getCheckboxTestId('27690294'));
        fireEvent.click(checkbox);
        // Click on EDIT button.
        const editButton = await screen.findByTestId('EDIT');
        expect(editButton).toBeDefined();
        fireEvent.click(editButton);
        // shold navigate to edit load sceen
        expect(mockHistoryPush).toHaveBeenCalledWith({
            pathname: '/stride/planquery/updateload',
            search: '?planId=27690294&section=',
        });
    });

    it('Primary Destination column - feature flag false', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const primaryDestinationCells = screen.queryAllByTestId(
            getTableCellTestId(0, TableColumnsUS.PRIMARY_DESTINATION_LOCATION_ID.id),
        );
        expect(primaryDestinationCells).toHaveLength(0);
    });

    it('Primary Destination column - feature flag true', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfigUS, {
            showProfile: false,
            showGlobalSearch: true,
            showPlanSearch: false,
            enableGroupBy: true,
            showExceptionChips: true,
            openDetailsPageInNewTab: false,
            showPrimaryDestinationCol: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
        const primaryDestinationHeaderCellTestId = getTableCellTestId(
            0,
            TableColumnsUS.PRIMARY_DESTINATION_LOCATION_ID.id,
        );

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const priDestinationHeaderCell = await screen.findByTestId(primaryDestinationHeaderCellTestId);
        expect(priDestinationHeaderCell.getAttribute('aria-sort')).toBe('none');

        // should sort by primary destination on click on table header cell
        fireEvent.click(priDestinationHeaderCell.children[0]);
        expect(priDestinationHeaderCell.getAttribute('aria-sort')).toBe('ascending');

        fireEvent.click(priDestinationHeaderCell.children[0]);
        expect(priDestinationHeaderCell.getAttribute('aria-sort')).toBe('descending');
    });

    it('Dwell days column - feature flag false', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const dwellDaysHeaderCell = screen.queryByTestId(getTableCellTestId(0, TableColumnsUS.DWELL_DAYS.id));
        expect(dwellDaysHeaderCell).not.toBeInTheDocument();
    });

    it('Dwell days column - feature flag true', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfigUS, {
            showProfile: false,
            showGlobalSearch: true,
            showPlanSearch: false,
            enableGroupBy: true,
            showExceptionChips: true,
            openDetailsPageInNewTab: false,
            extOpenDetailsPageInNewTab: false,
            showDwellDays: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(PlanSearchAggregatesUS));
                }
            }),
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))),
        );

        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const dwellDaysHeaderCell = screen.queryByTestId(getTableCellTestId(0, TableColumnsUS.DWELL_DAYS.id));
        expect(dwellDaysHeaderCell).toBeInTheDocument();

        const dwellDaysCellInFirstRow = screen.getByTestId(getTableCellTestId(22527129, TableColumnsUS.DWELL_DAYS.id));
        expect(dwellDaysCellInFirstRow.textContent).toBe('2');
    });

    it('Tags column - feature flag false', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const tagsHeaderCell = screen.queryByTestId(getTableCellTestId(0, TableColumnsUS.TAGS.id));
        expect(tagsHeaderCell).not.toBeInTheDocument();
    });

    it('Tags column - feature flag true', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfigUS, {
            showProfile: false,
            showGlobalSearch: true,
            showPlanSearch: false,
            enableGroupBy: true,
            showExceptionChips: true,
            openDetailsPageInNewTab: false,
            extOpenDetailsPageInNewTab: false,
            showPrimaryDestinationCol: true,
            showTagsCol: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const tagsHeaderCell = screen.queryByTestId(getTableCellTestId(0, TableColumnsUS.TAGS.id));
        expect(tagsHeaderCell).toBeInTheDocument();
    });
    it('service territory columns - feature flag false', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const serviceTerritoryHeaderCell = screen.queryByTestId(
            getTableCellTestId(0, TableColumnsUS.SERVICE_TERRITORY.id),
        );
        expect(serviceTerritoryHeaderCell).toBeInTheDocument();
        const tripServiceTerritoryHeaderCell = screen.queryByTestId(
            getTableCellTestId(0, TableColumnsUS.TRIP_SERVICE_TERRITORY.id),
        );
        expect(tripServiceTerritoryHeaderCell).not.toBeInTheDocument();
        const planningServiceTerritoryHeaderCell = screen.queryByTestId(
            getTableCellTestId(0, TableColumnsUS.PLAN_SERVICE_TERRITORY.id),
        );
        expect(planningServiceTerritoryHeaderCell).not.toBeInTheDocument();
    });

    it('service territory columns - feature flag true', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfigUS, {
            showProfile: false,
            showGlobalSearch: true,
            showPlanSearch: false,
            enableGroupBy: true,
            showExceptionChips: true,
            openDetailsPageInNewTab: false,
            extOpenDetailsPageInNewTab: false,
            showPrimaryDestinationCol: true,
            showTagsCol: true,
            showServiceTerritory: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(PlanSearchAggregatesUS));
                }
            }),
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))),
        );

        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const serviceTerritoryHeaderCell = screen.queryByTestId(
            getTableCellTestId(0, TableColumnsUS.SERVICE_TERRITORY.id),
        );
        expect(serviceTerritoryHeaderCell).not.toBeInTheDocument();
        const tripServiceTerritoryHeaderCell = screen.queryByTestId(
            getTableCellTestId(0, TableColumnsUS.TRIP_SERVICE_TERRITORY.id),
        );
        expect(tripServiceTerritoryHeaderCell).toBeInTheDocument();
        const planningServiceTerritoryHeaderCell = screen.queryByTestId(
            getTableCellTestId(0, TableColumnsUS.PLAN_SERVICE_TERRITORY.id),
        );
        expect(planningServiceTerritoryHeaderCell).toBeInTheDocument();

        const tripServiceTerritoryCellInFirstRow = screen.getByTestId(
            getTableCellTestId(22527129, TableColumnsUS.TRIP_SERVICE_TERRITORY.id),
        );
        const planServiceTerritoryCellInFirstRow = screen.getByTestId(
            getTableCellTestId(22527129, TableColumnsUS.PLAN_SERVICE_TERRITORY.id),
        );
        const tripServiceTerritoryCellInSecondRow = screen.getByTestId(
            getTableCellTestId(500003987, TableColumnsUS.TRIP_SERVICE_TERRITORY.id),
        );
        const planServiceTerritoryCellInSecondRow = screen.getByTestId(
            getTableCellTestId(500003987, TableColumnsUS.PLAN_SERVICE_TERRITORY.id),
        );

        expect(tripServiceTerritoryCellInFirstRow.textContent).toBe('6801');
        expect(planServiceTerritoryCellInFirstRow.textContent).toBe('1234');
        expect(tripServiceTerritoryCellInSecondRow.textContent).toBe('6801');
        expect(planServiceTerritoryCellInSecondRow.textContent).toBe('-');
    });

    it('Must Depart Time column - feature flag false', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const readyToStartTab = screen.getByText('Ready to start');
        fireEvent.click(readyToStartTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);

        const mustDepartTimeCells = screen.queryAllByTestId(getTableCellTestId(0, TableColumnsUS.MUST_DEPART_TIME.id));
        expect(mustDepartTimeCells).toHaveLength(0);
    });

    it('Must Depart Time column - feature flag true', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfigUS, {
            showProfile: false,
            showGlobalSearch: true,
            showPlanSearch: false,
            enableGroupBy: true,
            showExceptionChips: true,
            openDetailsPageInNewTab: false,
            showPrimaryDestinationCol: true,
            showMustDepartTimeCol: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
        const mustDepartTimeHeaderCellTestId = getTableCellTestId(0, TableColumnsUS.MUST_DEPART_TIME.id);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const planningTab = screen.getByText('Planning');
        const processingTab = screen.getByText('Processing');
        const readyToStartTab = screen.getByText('Ready to start');
        const inTransitTab = screen.getByText('In transit');
        const deliveredTab = screen.getByText('Delivered');

        fireEvent.click(planningTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        const mustDepartTimeCells4 = screen.queryAllByTestId(getTableCellTestId(0, TableColumnsUS.MUST_DEPART_TIME.id));
        expect(mustDepartTimeCells4).toHaveLength(0);

        fireEvent.click(processingTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        const mustDepartTimeCells1 = screen.queryAllByTestId(getTableCellTestId(0, TableColumnsUS.MUST_DEPART_TIME.id));
        expect(mustDepartTimeCells1).toHaveLength(0);

        fireEvent.click(inTransitTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        const mustDepartTimeCells2 = screen.queryAllByTestId(getTableCellTestId(0, TableColumnsUS.MUST_DEPART_TIME.id));
        expect(mustDepartTimeCells2).toHaveLength(0);

        fireEvent.click(deliveredTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        const mustDepartTimeCells3 = screen.queryAllByTestId(getTableCellTestId(0, TableColumnsUS.MUST_DEPART_TIME.id));
        expect(mustDepartTimeCells3).toHaveLength(0);

        fireEvent.click(readyToStartTab);
        await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        const mustDepartTimeHeaderCell = await screen.findByTestId(mustDepartTimeHeaderCellTestId);
        expect(mustDepartTimeHeaderCell.getAttribute('aria-sort')).toBe('none');
    });
});

describe('Group by functionality - US', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
    });
    it('Default group by trip', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByTestId('group-by');
        expect(groupByDropdown).toBeDefined();
        // Default group by Trips
        expect(screen.getByDisplayValue('Trips')).toBeDefined();
    });

    it('group by change to Loads/Intermodal', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByText('Group by');
        expect(groupByDropdown).toBeDefined();
        fireEvent.click(groupByDropdown);
        // Loads group by selection
        const loadsGB = screen.getByText('Loads');
        expect(loadsGB).toBeDefined();
        fireEvent.click(loadsGB);
        expect(screen.queryByText('Trips')).toBeNull();
        // Intermodal group by selection
        fireEvent.click(groupByDropdown);
        const imGB = screen.getByText('Intermodal');
        expect(imGB).toBeDefined();
        fireEvent.click(imGB);
        expect(screen.queryByText('Loads')).toBeNull();
    });
    it('group by change to Trips and IM loads should be individual rows should not show row expansion', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByText('Group by');
        expect(groupByDropdown).toBeDefined();
        // Trips group by selection
        fireEvent.click(groupByDropdown);
        const tripsGB = screen.getByText('Trips');
        expect(tripsGB).toBeDefined();
        fireEvent.click(tripsGB);

        const allTableBodyRows = Array.from(planTableBody.children);
        expect(allTableBodyRows[0].children[1].textContent).toBe('22527129');
        expect(allTableBodyRows[1].children[1].textContent).toBe('123456');
        expect(allTableBodyRows[0].children[2].textContent).toBe('Load - STR');
        expect(allTableBodyRows[1].children[2].textContent).toBe('Load - IM');

        const expandRowIcon = screen.queryAllByLabelText('Row Expand Toggle');
        expect(expandRowIcon).toHaveLength(0);
    });

    it('group by change to Loads and table results should be individual rows', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByText('Group by');
        expect(groupByDropdown).toBeDefined();
        // Loads group by selection
        fireEvent.click(groupByDropdown);
        const loadsGB = screen.getByText('Loads');
        expect(loadsGB).toBeDefined();
        fireEvent.click(loadsGB);

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const allTableBodyRows = planTableBody.children;
        expect(allTableBodyRows[0].children[1].textContent).toBe('22527129');
        expect(allTableBodyRows[1].children[1].textContent).toBe('123456');
        expect(allTableBodyRows[0].children[2].textContent).toBe('Load - STR');
        expect(allTableBodyRows[1].children[2].textContent).toBe('Load - IM');

        const expandRowIcon = screen.queryAllByLabelText('Row Expand Toggle');
        expect(expandRowIcon).toHaveLength(0);
    });

    it('group by change to Intermodal and table results should be in parent-child rows structure', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByIMPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByText('Group by');
        expect(groupByDropdown).toBeDefined();
        // Intermodal group by selection
        fireEvent.click(groupByDropdown);
        const imGB = screen.getByText('Intermodal');
        expect(imGB).toBeDefined();
        fireEvent.click(imGB);

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const allTableBodyRows = planTableBody.children;
        expect(allTableBodyRows[0].children[1].textContent).toBe('222312521');
        expect(allTableBodyRows[0].children[2].textContent).toBe('Load - IM3');

        const loadIdChild = screen.queryByText('27458477');
        expect(loadIdChild).not.toBeInTheDocument();

        const expandRowIcon = await within(allTableBodyRows[0]).findByLabelText('Row Expand Toggle');
        fireEvent.click(expandRowIcon);

        const childLoad = await screen.findByText('27458477');
        expect(childLoad).toBeInTheDocument();
    });

    it('should navigate the user to the load details page in a new tab when click on parent IM load', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByIMPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const planId = screen.getByText('222312521');
        expect(planId).toBeDefined();
        fireEvent.click(planId);

        // shold navigate to load details sceen
        expect(mockHistoryPush).toHaveBeenCalledWith({
            pathname: '/stride/planquery/loaddetails',
            search: '?planId=222312521',
        });
    });
});

describe('Mark as Service Failure', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us', invokeBulkUpdate: jest.fn(() => Promise.resolve()) };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
    });
    it('Should display modal on click of mark as service failure', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesInTransit)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const actionsMenuCellOfFirstRow = screen.getByTestId(getTableCellTestId(600009587, TableColumnsUS.ACTIONS.id));
        expect(actionsMenuCellOfFirstRow.textContent).toBe('...');
        const button = actionsMenuCellOfFirstRow.firstChild;
        fireEvent.click(button);
        const serviceFailure = await screen.findAllByText('Mark as service failure');
        fireEvent.click(serviceFailure[0]);
        const serviceFailureTypeDropDown = wrapper.getByTestId('service-failure');
        expect(serviceFailureTypeDropDown).toBeDefined();
        fireEvent.click(serviceFailureTypeDropDown);
        const dropdownMenuItem = await screen.findByText('BUYER LATE');
        fireEvent.click(dropdownMenuItem);
        const updateBtn = await screen.findByTestId('onupdate-button');
        expect(updateBtn).toBeDefined();
    });

    it('Should disable update on no service failure selected', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesInTransit)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const actionsMenuCellOfFirstRow = screen.getByTestId(getTableCellTestId(600009587, TableColumnsUS.ACTIONS.id));
        expect(actionsMenuCellOfFirstRow.textContent).toBe('...');
        const button = actionsMenuCellOfFirstRow.firstChild;
        fireEvent.click(button);
        const serviceFailure = await screen.findAllByText('Mark as service failure');
        fireEvent.click(serviceFailure[0]);
        const serviceFailureTypeDropDown = wrapper.getByTestId('service-failure');
        expect(serviceFailureTypeDropDown).toBeDefined();
        const updateBtn = await screen.findByTestId('onupdate-button');
        expect(updateBtn.disabled).toBeTruthy();
    });

    it('Should update button should be disabled if service failure type not selected', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesInTransit)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const actionsMenuCellOfFirstRow = screen.getByTestId(getTableCellTestId(600009587, TableColumnsUS.ACTIONS.id));
        expect(actionsMenuCellOfFirstRow.textContent).toBe('...');
        const button = actionsMenuCellOfFirstRow.firstChild;
        fireEvent.click(button);
        const serviceFailure = await screen.findAllByText('Mark as service failure');
        fireEvent.click(serviceFailure[0]);
        const btnUpdate = screen.getByTestId('onupdate-button');
        expect(btnUpdate).toHaveProperty('disabled');
    });

    it('Should show success message on mark service failure success', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesInTransit)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const actionsMenuCellOfFirstRow = screen.getByTestId(getTableCellTestId(600009587, TableColumnsUS.ACTIONS.id));
        expect(actionsMenuCellOfFirstRow.textContent).toBe('...');
        const button = actionsMenuCellOfFirstRow.firstChild;
        fireEvent.click(button);

        const serviceFailure = await screen.findAllByText('Mark as service failure');
        fireEvent.click(serviceFailure[0]);
        const serviceFailureTypeDropDown = wrapper.getByTestId('service-failure');
        expect(serviceFailureTypeDropDown).toBeDefined();
        fireEvent.click(serviceFailureTypeDropDown);
        const dropdownMenuItem = await screen.findAllByText('BUYER LATE');
        fireEvent.click(dropdownMenuItem[0]);
        const updateBtn = screen.getByTestId('onupdate-button');
        fireEvent.click(updateBtn);
        const msg = await screen.findByText('Mark service failure successfully. Changes will reflect soon.');
        expect(msg).toBeDefined();
    });
});

describe('Testing user actions with permissions', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
        TripSharedService.setUserPermissions(null);
    });
    // TODO: Fix this test after MFE migration
    it.skip('should not show any action with readonly permission', async () => {
        const localStorageGetItem = jest.fn((arg) => {
            if (arg === 'ngStorage-permissionData') {
                return userReadPermMock;
            }

            if (arg === 'ngStorage-rlUserInfo') {
                return userRlInfoMock;
            }
        });
        Object.defineProperty(global, 'localStorage', {
            value: {
                getItem: localStorageGetItem,
                setItem: () => {},
            },
            writable: true,
        });

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const actions = await screen.findAllByTestId('actions-cell');
        expect(actions[8].textContent).toBe('...');
        const button = actions[8].firstChild;
        fireEvent.click(button);
        expect(screen.queryByText('Review & Approve')).toBeNull();
    });

    it('should show actions with permisson', async () => {
        const localStorageGetItem = jest.fn((arg) => {
            if (arg === 'ngStorage-permissionData') {
                return userPermMock;
            }

            if (arg === 'ngStorage-rlUserInfo') {
                return userRlInfoMock;
            }
        });
        Object.defineProperty(global, 'localStorage', {
            value: {
                getItem: localStorageGetItem,
                setItem: () => {},
            },
            writable: true,
        });

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const actionsMenuCellOfFirstRow = screen.getByTestId(getTableCellTestId(22527129, TableColumnsUS.ACTIONS.id));
        expect(actionsMenuCellOfFirstRow.textContent).toBe('...');
        const button = actionsMenuCellOfFirstRow.firstChild;
        fireEvent.click(button);
        // TODO: Fix this test after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByText('Review & Approve')).toBeDefined();
    });
});

describe('Profile testing', () => {
    const contextMockCA = { ...contextMock, currentMarket: 'us' };
    beforeEach(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCA);
    });

    it('should show the profile selector', () => {
        render(<TripManagementSummary />);
        // TODO: Fix this test after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        const profileTitle = screen.findByText('My Profile');
        // eslint-disable-next-line testing-library/await-async-queries
        const profileAdd = screen.findByTestId('manage-accounts-icon');
        expect(profileAdd).toBeDefined();
        expect(profileTitle).toBeDefined();
    });
});

describe('Bulk upload', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    beforeEach(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setPageLoadSettings({});
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
    });
    it('Should open bulk history page on clicking bulk upload icon when enableBulkUpload flag is false', async () => {
        const config = getUpdatedCMSConfig(CmsConfigUS, { enableBulkUpload: false });
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));

        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const bulkHistoryLink = screen.queryByTestId('bulkHistoryButton').querySelector('svg');
        expect(bulkHistoryLink).toBeDefined();
        window.open = jest.fn();
        fireEvent.click(bulkHistoryLink);
        expect(window.open).toBeCalledWith('/bulkupload/history');
    });
    it('Should open bulk upload page on clicking bulk upload icon when enableBulkUpload flag is true', async () => {
        const config = getUpdatedCMSConfig(CmsConfigUS, { enableBulkUpload: true });
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));

        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const bulkHistoryLink = screen.queryByTestId('bulkHistoryButton');
        expect(bulkHistoryLink).toBeNull();

        const bulkUpload = screen.getByTestId('bulk-upload-button-container-right').querySelector('svg');
        expect(bulkUpload).toBeDefined();
    });
});
