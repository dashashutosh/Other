import React from 'react';
import Enzyme, { shallow, mount } from 'enzyme';
import Adapter from '@wojtekmaj/enzyme-adapter-react-17';
import { act } from 'react-dom/test-utils';
import { TableFooter, TableSortLabel } from '@walmart/living-design-sc-ui';
import { WorkloadAssignment } from '@walmart/stride-ui-commons';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
import PlanTable from '../PlanTable';
import {
    contextMock,
    transformedConfigResponseMock,
    tripStaticDataMock,
    featureFlagsMockGT,
    featureFlagsMock,
    featureFlagsMockGTFilteringOn,
    transformedConfigResponseMockCR,
    transformedConfigResponseMockSV,
    transformedConfigResponseMockMKP,
} from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import { transformedPlanMock } from './mocks/TripManagementSummary.mock';
import PlanTableRow from '../PlanTableRow';
import TripSharedService from '../../../service/TripSharedService';
import CreateTripConfirmModal from '../CreateTripConfirmModal';
import { render, fireEvent, screen } from '../../../utils/test-utils';

Enzyme.configure({ adapter: new Adapter() });

jest.mock('@gscope-mfe/common-components', () => {
    const actualModule = jest.requireActual('@gscope-mfe/common-components');
    return {
        ...actualModule,
        LocalizeLang: {
            default: {
                ...actualModule.LocalizeLang.default,
                localizeLang: jest.fn(),
            },
        },
    };
});
jest.useFakeTimers();
const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));

sessionStorage.setItem('ngStorage-permissionData', { permissions: ['cl.stride.tripLoadManagement:EDIT_TRIP'] });

const permissionsMock = {
    canEditTrip: true,
};

describe('Plan Table', () => {
    beforeAll(() => {
        const mockFn = jest.fn();
        LocalizeLang.default.localizeLang.mockImplementation(() => mockFn);
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMock);
        TripSharedService.setTripStaticData(tripStaticDataMock);
    });

    it('should render without crashing', () => {
        const wrapper = shallow(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
            />,
        );
        expect(wrapper).toBeDefined();
    });

    it('should able to search for table data', () => {
        const wrapper = shallow(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pActiveTab={0}
            />,
        );
        expect(wrapper.find('[data-testid="search"]')).toHaveLength(1);
        act(() => {
            wrapper.find('[data-testid="search"]').simulate('change', { target: { value: '30025475' } });
            jest.runAllTimers();
        });
        expect(wrapper.find('[data-testid="search"]').prop('value')).toBe('30025475');
    });

    it('should sort rows in ascending order based on create date', () => {
        const wrapper = mount(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
            />,
        );
        expect(wrapper.find(TableSortLabel)).toHaveLength(15);
        act(() => {
            wrapper.find(TableSortLabel).at(0).simulate('click');
        });
        expect(wrapper.find(TableSortLabel).at(0).prop('direction')).toEqual('asc');
    });

    it.skip('should set table footer message', () => {
        const wrapper = mount(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
            />,
        );
        expect(wrapper.find(TableFooter)).toHaveLength(1);
        expect(wrapper.find('.ld-sc-ui-table-footer-page-count')).toHaveLength(1);
        act(() => {
            wrapper.find(TableFooter).prop('onNextPage')();
        });
        act(() => {
            wrapper.find(TableFooter).prop('onPrevPage')();
        });
        expect(wrapper.find('.ld-sc-ui-table-footer-page-count').text()).toMatch('Showing 1-9 of 9');
    });

    it('should clear all selection on clear all button click', () => {
        const wrapper = mount(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
            />,
        );
        expect(wrapper.find('[data-testid="clearAll"]')).toHaveLength(0);
        act(() => {
            wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025475']);
        });
        wrapper.update();
        expect(wrapper.find('[data-testid="clearAll"]').hostNodes()).toHaveLength(1);
        act(() => {
            wrapper.find('[data-testid="clearAll"]').hostNodes().prop('onClick')();
        });
        wrapper.update();
        expect(wrapper.find('[data-testid="clearAll"]')).toHaveLength(0);
    });

    it('should call PlanLTPreview API when Next button is clicked - showPaginationInAssignTrip is set  ', async () => {
        const mockFn = jest.fn();
        const newConfig = {
            ...transformedConfigResponseMock,
            rowsPerPage: 8,
        };
        const wrapper = render(
            <PlanTable
                pTabIndex={1}
                pConfig={newConfig}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={mockFn}
                pPageNumber={1}
                pFetchedTripCount={100}
                pActiveTab={1}
                pFeatureFlagsData={{ showPaginationInAssignTrip: true }}
            />,
        );
        const nextButton = await wrapper.findByTestId('ld-sc-ui-table-next-page');
        expect(nextButton).toBeDefined();
        fireEvent.click(nextButton);
        expect(mockFn).toHaveBeenCalledWith(2);
    });

    it('should not call PlanLTPreview API when Next button is clicked - showPaginationInAssignTrip is reset', async () => {
        const mockFn = jest.fn();
        const newConfig = {
            ...transformedConfigResponseMock,
            rowsPerPage: 8,
        };
        const wrapper = render(
            <PlanTable
                pTabIndex={1}
                pConfig={newConfig}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={mockFn}
                pPageNumber={1}
                pFetchedTripCount={100}
                pActiveTab={1}
                pFeatureFlagsData={{ showPaginationInAssignTrip: false }}
            />,
        );
        const nextButton = await wrapper.findByTestId('ld-sc-ui-table-next-page');
        expect(nextButton).toBeDefined();
        fireEvent.click(nextButton);
        expect(mockFn).not.toHaveBeenCalledWith(2);
    });

    describe('planning', () => {
        it('should show approve trip button if trip selected', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025475']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="approveTrip"]').hostNodes().length).toEqual(1);
        });

        it('should show call pOnTripApprove on approve trip button click', () => {
            const mockFn = jest.fn();
            const wrapper = mount(
                <PlanTable
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pOnTripApprove={mockFn}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025475']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="approveTrip"]').hostNodes().length).toEqual(1);
            act(() => {
                wrapper.find('[data-testid="approveTrip"]').hostNodes().prop('onClick')();
            });
            expect(mockFn).toHaveBeenCalled();
        });

        it('should show assign to trip and create trip button if load selected', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025476']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="assignToTrip"]').hostNodes().length).toEqual(1);
            expect(wrapper.find('[data-testid="createTrip"]').hostNodes().length).toEqual(1);
        });

        it('should navigate to assign trip on confirmation', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025476']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="assignToTrip"]').hostNodes().length).toEqual(1);
            act(() => {
                wrapper.find('[data-testid="assignToTrip"]').at(0).prop('onClick')();
            });
            expect(mockHistoryPush).toHaveBeenCalledWith({
                pathname: '/mfe/stride/tripmanagement/assign-trip',
                state: transformedPlanMock[2],
            });
        });

        it('should call pOnTripSelection on plan selection for assign trip', () => {
            const mockFn = jest.fn();
            const wrapper = mount(
                <PlanTable
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pOnTripSelection={mockFn}
                    pUserPerm={permissionsMock}
                    pIsAssignTrip
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025476']);
            });
            wrapper.update();
            expect(mockFn).toHaveBeenCalled();
        });

        it('should show create trip button only if loads selected', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025476', '30025477']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="assignToTrip"]').hostNodes().length).toEqual(0);
            expect(wrapper.find('[data-testid="createTrip"]').hostNodes().length).toEqual(1);
        });

        it('should show confirm create trip modal on create trip button click', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025476', '30025477']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="createTrip"]').hostNodes().length).toEqual(1);
            act(() => {
                wrapper.find('[data-testid="createTrip"]').at(0).prop('onClick')();
            });
            wrapper.update();
            expect(wrapper.find(CreateTripConfirmModal).prop('pIsOpen')).toEqual(true);
        });

        it('should close confirm create trip modal on close button click', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={0}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025476', '30025477']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="createTrip"]').hostNodes().length).toEqual(1);
            act(() => {
                wrapper.find('[data-testid="createTrip"]').at(0).prop('onClick')();
            });
            wrapper.update();
            expect(wrapper.find(CreateTripConfirmModal).prop('pIsOpen')).toEqual(true);
            act(() => {
                wrapper.find(CreateTripConfirmModal).prop('pOnClose')();
            });
            wrapper.update();
            expect(wrapper.find(CreateTripConfirmModal)).toHaveLength(0);
        });
    });

    xdescribe('processing', () => {
        it('should show assign manually and tender trip buttons if trip selected is in work load assignment state', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={1}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025405']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="assignManually"]').hostNodes().length).toEqual(1);
            expect(wrapper.find('[data-testid="tenderTrip"]').hostNodes().length).toEqual(1);
        });

        it('should show work load assignment modal on assign manually button click', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={1}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025405']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="assignManually"]').hostNodes().length).toEqual(1);
            act(() => {
                wrapper.find('[data-testid="assignManually"]').at(0).prop('onClick')();
            });
            wrapper.update();
            expect(wrapper.find(WorkloadAssignment)).toHaveLength(1);
        });

        it('should close confirm create trip modal on close button click', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={1}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025405']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="assignManually"]').hostNodes().length).toEqual(1);
            act(() => {
                wrapper.find('[data-testid="assignManually"]').at(0).prop('onClick')();
            });
            wrapper.update();
            expect(wrapper.find(WorkloadAssignment)).toHaveLength(1);
            act(() => {
                wrapper.find(WorkloadAssignment).prop('pOnClose')();
            });
            wrapper.update();
            expect(wrapper.find(WorkloadAssignment)).toHaveLength(0);
        });

        it('should show tender trip button only if trips selected are in work load assignment state', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={1}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025405', '30025485']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="assignManually"]').hostNodes().length).toEqual(0);
            expect(wrapper.find('[data-testid="tenderTrip"]').hostNodes().length).toEqual(1);
        });

        it('should show edit assignment button if trip selected is in awaiting finalization state', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={1}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025488']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="editAssignment"]').hostNodes().length).toEqual(1);
        });

        it('should not show assign manually and tender trip buttons if market not chile', () => {
            const spy = jest.spyOn(AppUtils, 'get');
            spy.mockImplementation(() => ({ ...contextMock, currentMarket: 'cr' }));
            const wrapper = mount(
                <PlanTable
                    pTabIndex={1}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025405']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="assignManually"]').hostNodes().length).toEqual(0);
            expect(wrapper.find('[data-testid="tenderTrip"]').hostNodes().length).toEqual(0);
        });

        it('should show edit assignment and confirm buttons for cam countries', () => {
            const spy = jest.spyOn(AppUtils, 'get');
            spy.mockImplementation(() => ({ ...contextMock, currentMarket: 'cr' }));
            const wrapper = mount(
                <PlanTable
                    pTabIndex={1}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025405']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="editAssignment"]').hostNodes().length).toEqual(1);
            expect(wrapper.find('[data-testid="confirm"]').hostNodes().length).toEqual(1);
        });
    });

    describe('dispatch', () => {
        it('should show edit work load assignments and dispatch button if trip selected', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={2}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025498']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="editWorkLoadAssignments"]').hostNodes().length).toEqual(1);
            expect(wrapper.find('[data-testid="dispatch"]').hostNodes().length).toEqual(1);
        });

        it('should show dispatch button if trips selected', () => {
            const wrapper = mount(
                <PlanTable
                    pTabIndex={2}
                    pConfig={transformedConfigResponseMock}
                    pPlanList={transformedPlanMock}
                    pUserPerm={permissionsMock}
                    pPageChange={jest.fn()}
                    pPageNumber={1}
                    pFetchedTripCount={100}
                />,
            );
            act(() => {
                wrapper.find(PlanTableRow).at(0).prop('pSetCheckedRows')(['30025498', '30025408']);
            });
            wrapper.update();
            expect(wrapper.find('[data-testid="editWorkLoadAssignments"]').hostNodes().length).toEqual(0);
            expect(wrapper.find('[data-testid="dispatch"]').hostNodes().length).toEqual(1);
        });
    });

    // TODO: Fix this test after MFE migration
    it.skip('should load actions for processing tab if market is cl', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pActiveTab={1}
                pFeatureFlagsData={{ enableAssignTrailer: true }}
            />,
        );
        // TODO: Fix this eslint after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByTestId('tenderTrip')).toBeDefined();
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByTestId('assignTrailer')).toBeDefined();
    });

    it('should not load assign trailer actions for processing tab if market is cl and enableAssignTrailer is false', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pActiveTab={1}
                pFeatureFlagsData={{ enableAssignTrailer: false }}
            />,
        );
        expect(wrapper).toBeDefined();
        expect(screen.queryByTestId('assignTrailer')).toBeNull();
    });

    // TODO: Fix this test after MFE migration
    it.skip('should load actions for in transit tab if market is cl', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={3}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pActiveTab={3}
            />,
        );
        // TODO: Fix this eslint after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByTestId('reprintDispatchDoc')).toBeDefined();
    });

    it('should show filter icon button if showSearchFilterForAssignTrip is true for GT market', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pFeatureFlagsData={featureFlagsMockGT}
            />,
        );

        const filterBtn = wrapper.queryByTestId('search-filter-icon');
        expect(filterBtn).toBeDefined();
    });

    it('should show filter icon button if showSearchFilterForAssignTrip is true for CR market', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMockCR}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pFeatureFlagsData={featureFlagsMockGT}
            />,
        );

        const filterBtn = wrapper.queryByTestId('search-filter-icon');
        expect(filterBtn).toBeDefined();
    });

    it('should show filter icon button if showSearchFilterForAssignTrip is true for SV market', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMockSV}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pFeatureFlagsData={featureFlagsMockGT}
            />,
        );

        const filterBtn = wrapper.queryByTestId('search-filter-icon');
        expect(filterBtn).toBeDefined();
    });

    it('should show filter icon button if showSearchFilterForAssignTrip is true for MKP market', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMockMKP}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pFeatureFlagsData={featureFlagsMockGT}
            />,
        );

        const filterBtn = wrapper.queryByTestId('search-filter-icon');
        expect(filterBtn).toBeDefined();
    });

    it('should not show filter icon button if showSearchFilterForAssignTrip is false for other markets', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pFeatureFlagsData={featureFlagsMock}
            />,
        );

        const filterBtn = wrapper.queryByTestId('search-filter-icon');
        expect(filterBtn).toBeNull();
    });

    it('should open filter model on click of filter icon', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pFeatureFlagsData={featureFlagsMockGT}
                pSetsIsSearchFilterModalOpen={mockFn}
            />,
        );

        const filterBtn = wrapper.queryByTestId('search-filter-icon');
        expect(filterBtn).toBeDefined();
        fireEvent.click(filterBtn.firstChild);
        expect(mockFn).toBeCalled();
    });
    it('should not show round trips if filter is activated', () => {
        const mockFn = jest.fn();
        const wrapper = render(
            <PlanTable
                pTabIndex={0}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={mockFn}
                pPageNumber={1}
                pFetchedTripCount={100}
                pFeatureFlagsData={featureFlagsMockGTFilteringOn}
                pSetsIsSearchFilterModalOpen={mockFn}
            />,
        );
        const planTableBody = wrapper.queryByTestId('ld-sc-ui-table');
        expect(planTableBody).toBeDefined();
        expect(planTableBody.firstChild.children.length).toEqual(1);
    });

    // TODO: Fix this test after MFE migration
    it.skip('should load edit/Assign trailer modal on click of assign trailer action for processing tab if market is cl', () => {
        const wrapper = render(
            <PlanTable
                pTabIndex={1}
                pConfig={transformedConfigResponseMock}
                pPlanList={transformedPlanMock}
                pUserPerm={permissionsMock}
                pPageChange={jest.fn()}
                pPageNumber={1}
                pFetchedTripCount={100}
                pActiveTab={1}
            />,
        );
        // TODO: Fix this eslint after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        const assignTrailerBtn = wrapper.findByTestId('assignTrailer');
        expect(assignTrailerBtn).toBeDefined();
        // eslint-disable-next-line testing-library/await-async-queries
        const assignTrailePopup = wrapper.findByTestId('ld-sc-ui--modal-header');
        expect(assignTrailePopup).toBeDefined();
    });
});
