import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ResizeObserver from 'resize-observer-polyfill';

import { render, screen, fireEvent, waitFor, within } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

import {
    planSearchAggregatesInTransit,
    userRlInfoMock,
    loadDetailsMock,
    losData,
    updateTimeLineErrMock,
    updateTimeLineBackend400ErrMock,
} from './mocks/TripManagementSummary.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';

import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';

import TripManagementSummary from '../TripManagementSummary';
import TripSharedService from '../../../service/TripSharedService';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(planSearchAggregatesInTransit));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(CmsConfigUS));
        }
        return res(ctx.json(CmsConfig));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}getLoadDetails/loadDetails`, (req, res, ctx) => res(ctx.json(loadDetailsMock))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}fetchStaticData/fetchStaticData`, (req, res, ctx) => res(ctx.json(losData))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}updateTimeline/updateTimeline`, (req, res, ctx) => res(ctx.json(true))),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const spy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    spy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Update timeline - US', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
    });
    it('Should open update timeline popup', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const updateTimeLineBtn = await screen.findAllByText('Update timeline');
        fireEvent.click(updateTimeLineBtn[0]);

        const updateTimelinePopup = await screen.findByTestId('ld-sc-ui--modal-content');
        expect(updateTimelinePopup).toBeDefined();
    });

    it('Should verify confirm button available and fields are editable', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const updateTimelineButton = await screen.findByTestId('UPDATE_TIMELINE');
        expect(updateTimelineButton).toBeDefined();
        fireEvent.click(updateTimelineButton);
        const updateTimelinePopup = await screen.findByTestId('ld-sc-ui--modal-content');
        expect(updateTimelinePopup).toBeDefined();

        await waitFor(() => {
            const inputLabel = screen.getAllByText('Actual arrival time');
            expect(inputLabel[0]).toBeDefined();
        });
        const inputArrivalTime = screen.getAllByPlaceholderText('Actual arrival time');
        expect(inputArrivalTime[0]).toBeDefined();

        fireEvent.change(inputArrivalTime[0], { target: { value: '2023-26-10T12:21:00.000-05:00' } });
        expect(inputArrivalTime[0].value).toBe('2023-26-10T12:21:00.000-05:00');

        const inputDepartureTime = screen.getAllByPlaceholderText('Actual departure time');
        expect(inputDepartureTime[0]).toBeDefined();

        fireEvent.change(inputDepartureTime[0], { target: { value: '2023-26-10T12:21:00.000-05:00' } });
        expect(inputDepartureTime[0].value).toBe('2023-26-10T12:21:00.000-05:00');

        const inputLosEvent = screen.getAllByTestId('LOS event');
        expect(inputLosEvent[0]).toBeDefined();
        fireEvent.click(inputLosEvent[0]);
        const losEventOption = screen.getByText('Late Pickup');
        fireEvent.click(losEventOption);

        expect(inputArrivalTime[1]).toBeDefined();
        fireEvent.change(inputArrivalTime[1], { target: { value: '2023-26-11T12:21:00.000-05:00' } });
        expect(inputArrivalTime[1].value).toBe('2023-26-11T12:21:00.000-05:00');

        expect(inputDepartureTime[1]).toBeDefined();
        fireEvent.change(inputDepartureTime[1], { target: { value: '2023-28-11T12:21:00.000-05:00' } });
        expect(inputDepartureTime[1].value).toBe('2023-28-11T12:21:00.000-05:00');

        expect(inputLosEvent[1]).toBeDefined();
        fireEvent.click(inputLosEvent[1]);
        const losEventValue = screen.getByText('Late Pickup');
        fireEvent.click(losEventValue);
        const confirmBtn = screen.getByText('Confirm');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
    });

    it('Should show error on api fail', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}updateTimeline/updateTimeline`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(updateTimeLineErrMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const updateTimelineButton = await screen.findByTestId('UPDATE_TIMELINE');
        expect(updateTimelineButton).toBeDefined();
        fireEvent.click(updateTimelineButton);

        const updateTimeLineBtn = await screen.findAllByText('Update timeline');
        fireEvent.click(updateTimeLineBtn[0]);
        await waitFor(() => {
            const inputLabel = screen.getAllByText('Actual arrival time');
            expect(inputLabel[0]).toBeDefined();
        });
        const updateTimelinePopup = await screen.findByTestId('ld-sc-ui--modal-content');
        expect(updateTimelinePopup).toBeDefined();
        const inputArrivalTime = screen.getAllByPlaceholderText('Actual arrival time');
        expect(inputArrivalTime[0]).toBeDefined();
        fireEvent.change(inputArrivalTime[0], { target: { value: '2024-27-10T12:21:00.000-05:00' } });

        const inputDepartureTime = screen.getAllByPlaceholderText('Actual departure time');
        expect(inputDepartureTime[0]).toBeDefined();
        fireEvent.change(inputDepartureTime[0], { target: { value: '2024-27-10T12:21:00.000-05:00' } });

        const inputLosEvent = screen.getAllByTestId('LOS event');
        expect(inputLosEvent[0]).toBeDefined();
        fireEvent.click(inputLosEvent[0]);
        const losEventOption = screen.getByText('Late Pickup');
        fireEvent.click(losEventOption);
        expect(losEventOption).toBeDefined();

        expect(inputArrivalTime[1]).toBeDefined();
        fireEvent.change(inputArrivalTime[1], { target: { value: '2024-28-11T12:21:00.000-05:00' } });

        expect(inputDepartureTime[1]).toBeDefined();
        fireEvent.change(inputDepartureTime[1], { target: { value: '2024-28-11T12:21:00.000-05:00' } });

        expect(inputLosEvent[1]).toBeDefined();
        fireEvent.click(inputLosEvent[1]);
        const losEventValue = screen.getByText('Late Pickup');
        fireEvent.click(losEventValue);
        expect(losEventValue).toBeDefined();

        const confirmBtn = screen.getByText('Confirm');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);

        const errorMsg = await screen.findByText('FAIL');
        expect(errorMsg).toBeDefined();
    });

    it('Should show error from backend 400', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}updateTimeline/updateTimeline`, (req, res, ctx) =>
                res(ctx.status(400), ctx.json(updateTimeLineBackend400ErrMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const updateTimelineButton = await screen.findByTestId('UPDATE_TIMELINE');
        expect(updateTimelineButton).toBeDefined();
        fireEvent.click(updateTimelineButton);

        const updateTimelinePopup = await screen.findByTestId('ld-sc-ui--modal-content');
        expect(updateTimelinePopup).toBeDefined();
        await waitFor(() => {
            const inputLabel = screen.getAllByText('Actual arrival time');
            expect(inputLabel[0]).toBeDefined();
        });
        const inputArrivalTime = screen.getAllByPlaceholderText('Actual arrival time');
        expect(inputArrivalTime[0]).toBeDefined();
        fireEvent.change(inputArrivalTime[0], { target: { value: '2024-27-10T12:21:00.000-05:00' } });

        const inputDepartureTime = screen.getAllByPlaceholderText('Actual departure time');
        expect(inputDepartureTime[0]).toBeDefined();

        fireEvent.change(inputDepartureTime[0], { target: { value: '2024-27-10T12:21:00.000-05:00' } });

        const inputLosEvent = screen.getAllByTestId('LOS event');
        expect(inputLosEvent[0]).toBeDefined();
        fireEvent.click(inputLosEvent[0]);
        const losEventOption = screen.getByText('Late Pickup');
        fireEvent.click(losEventOption);

        expect(inputArrivalTime[1]).toBeDefined();
        fireEvent.change(inputArrivalTime[1], { target: { value: '2024-28-11T12:21:00.000-05:00' } });

        expect(inputDepartureTime[1]).toBeDefined();
        fireEvent.change(inputDepartureTime[1], { target: { value: '2024-28-11T12:21:00.000-05:00' } });

        expect(inputLosEvent[1]).toBeDefined();
        fireEvent.click(inputLosEvent[1]);
        const losEventValue = screen.getByText('Late Pickup');
        fireEvent.click(losEventValue);

        const confirmBtn = screen.getByText('Confirm');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);

        const errorMsg = await screen.findByText('Invalid Request');
        expect(errorMsg).toBeDefined();
    });

    it('Should handles a successful update after error occurrence', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}updateTimeline/updateTimeline`, (req, res, ctx) => res(ctx.json(true))),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const updateTimelineButton = await screen.findByTestId('UPDATE_TIMELINE');
        expect(updateTimelineButton).toBeDefined();
        fireEvent.click(updateTimelineButton);

        const updateTimelinePopup = await screen.findByTestId('ld-sc-ui--modal-content');
        expect(updateTimelinePopup).toBeDefined();
        await waitFor(() => {
            const inputLabel = screen.getAllByText('Actual arrival time');
            expect(inputLabel[0]).toBeDefined();
        });
        const inputArrivalTime = screen.getAllByPlaceholderText('Actual arrival time');
        expect(inputArrivalTime[0]).toBeDefined();
        fireEvent.change(inputArrivalTime[0], { target: { value: '2023-26-10T12:21:00.000-05:00' } });
        const inputDepartureTime = screen.getAllByPlaceholderText('Actual departure time');
        expect(inputDepartureTime[0]).toBeDefined();

        fireEvent.change(inputDepartureTime[0], { target: { value: '2022-10-10T12:21:00.000-05:00' } });

        expect(screen.queryByText('Departure time must be later than arrival time.')).toBeDefined();

        fireEvent.change(inputDepartureTime[0], { target: { value: '2023-26-10T12:21:00.000-05:00' } });
        const inputLosEvent = screen.getAllByTestId('LOS event');
        expect(inputLosEvent[0]).toBeDefined();
        fireEvent.click(inputLosEvent[0]);
        const losEventOption = screen.getByText('Late Pickup');
        fireEvent.click(losEventOption);

        expect(inputArrivalTime[1]).toBeDefined();
        fireEvent.change(inputArrivalTime[1], { target: { value: '2023-26-11T12:21:00.000-05:00' } });
        expect(inputDepartureTime[1]).toBeDefined();
        fireEvent.change(inputDepartureTime[1], { target: { value: '2023-28-11T12:21:00.000-05:00' } });
        expect(inputLosEvent[1]).toBeDefined();
        fireEvent.click(inputLosEvent[1]);
        const losEventValue = screen.getByText('Late Pickup');
        fireEvent.click(losEventValue);
        const confirmBtn = screen.getByText('Confirm');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);
        const successMsg = await screen.findByText('Timeline updated successfully.');
        expect(successMsg).toBeDefined();
    });

    it('Should not show Update timeline button if both loads dont have same action', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const checkboxTwo = await screen.findByTestId(getCheckboxTestId('200043948'));
        fireEvent.click(checkboxTwo);
        expect(screen.queryByTestId('UPDATE_TIMELINE')).toBeNull();
    });

    it("Should show success message on update api success for 'Update timeline' action with ForceToDelivered with toggle", async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}updateTimeline/updateTimeline`, (req, res, ctx) => res(ctx.json(true))),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const updateTimelineButton = await screen.findByTestId('UPDATE_TIMELINE');
        expect(updateTimelineButton).toBeDefined();
        fireEvent.click(updateTimelineButton);

        const updateTimelinePopup = await screen.findByTestId('ld-sc-ui--modal-content');
        expect(updateTimelinePopup).toBeDefined();
        await waitFor(() => {
            const inputLabel = screen.getAllByText('Actual arrival time');
            expect(inputLabel[0]).toBeDefined();
        });
        const inputArrivalTime = screen.getAllByPlaceholderText('Actual arrival time');
        expect(inputArrivalTime[0]).toBeDefined();
        fireEvent.change(inputArrivalTime[0], { target: { value: '2024-09-10T12:21:00.000-05:00' } });
        const inputDepartureTime = screen.getAllByPlaceholderText('Actual departure time');
        expect(inputDepartureTime[0]).toBeDefined();

        fireEvent.change(inputDepartureTime[0], { target: { value: '2024-10-10T12:21:00.000-05:00' } });

        const arrivalDepartToggle = await screen.findAllByTestId('Arrival & Departure');
        expect(arrivalDepartToggle[0]).toBeDefined();

        // Select 'Arrival & Departure' toggle option
        fireEvent.click(arrivalDepartToggle[0]);

        // populate Arrival LOS
        const arrivalLos = await screen.findAllByText('Arrival LOS');
        expect(arrivalLos[0]).toBeDefined();
        fireEvent.click(arrivalLos[0]);
        const arrivalLosOption = await screen.findByText('Late Pickup');
        fireEvent.click(arrivalLosOption);
        expect(arrivalLosOption).toBeDefined();

        // populate Departure LOS
        const departureLos = await screen.findAllByText('Departure LOS');
        expect(departureLos[0]).toBeDefined();
        fireEvent.click(departureLos[0]);
        const departureLosOption = await screen.findByText('Traffic Congestion');
        fireEvent.click(departureLosOption);
        expect(departureLosOption).toBeDefined();

        const confirmBtn = await screen.findByText('Confirm');
        expect(confirmBtn).toBeDefined();
        fireEvent.click(confirmBtn);

        const successMsg = await screen.findByText('Timeline updated successfully.');
        expect(successMsg).toBeDefined();
    });
});
