export const mockStaticData = {
    equipmentConfigurationIds: [
        {
            id: 'TRRF56',
            value: 'TRRF56',
        },
    ],
};

export const mockCheckedRows = ['30000967', '30000040'];
