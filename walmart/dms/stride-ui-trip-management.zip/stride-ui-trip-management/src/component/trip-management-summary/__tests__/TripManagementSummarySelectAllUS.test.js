import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { AppUtils } from '@gscope-mfe/app-bridge';
import ResizeObserver from 'resize-observer-polyfill';

import { render, screen, fireEvent, within, waitFor, waitForElementToBeRemoved } from '../../../utils/test-utils';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';
import TripManagementSummary from '../TripManagementSummary';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';

import TripSharedService from '../../../service/TripSharedService';
import { groupByIMPlanResults, groupByLoadPlanResults } from '../US/__tests__/mocks/PlanSearchResultsGroupBy.mock';
import LocalStorageMock from './mocks/localStorageUS.mock.json';
import { userRlInfoMock } from './mocks/TripManagementSummary.mock';
import {
    getCheckboxTestId,
    getTableCellTestId,
    SEARCH_RESULT_TABLE_BODY_TEST_ID,
    SELECT_ALL_CHECKBOX_TEST_ID,
} from './trip-management-summary-us-test-helpers';
import TableColumnsUS from '../../model/TableColumnsUS';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),

    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(CmsConfigUS));
        }
        return res(ctx.json(CmsConfigUS));
    }),
);

const userPermMock = JSON.stringify({
    permissions: [
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

const userPreferencesMock = JSON.stringify(LocalStorageMock);
const spy = jest.spyOn(AppUtils, 'get');

spy.mockImplementation(() => contextMock);

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(50000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    spy.mockImplementation(() => contextMockUS);
    TripSharedService.setPageLoadSettings({});
    TripSharedService.setFeatureFlags(null);
    TripSharedService.setConfig(null);
    const config = {
        ...CmsConfigUS,
        payload: {
            ...CmsConfigUS.payload,
            custom: {
                ...CmsConfigUS.payload.custom,
                featureFlags:
                    '{"dev.tripManagement.configs":{"showExceptionChips": true, "enableManageColumns": true, "enableGroupBy": true, "showTimeHorizonV2": true, "showProfileSelectorV2": true, "showGlobalSearch": true }}',
            },
        },
    };
    server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));

    global.ResizeObserver = ResizeObserver;

    const getBoundingClientRectSpy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    getBoundingClientRectSpy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Select all and Select checkbox test cases US', () => {
    it('should display the selection header correctly when select all is checked', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();
    });
    it('should deselect all , when cancel button is clicked', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        const clearAllBtn = await screen.findByTestId('clearAll');
        expect(clearAllBtn).toBeDefined();
        fireEvent.click(clearAllBtn);
        expect(screen.queryByText('plans selected')).toBeNull();
    });
    it('select all and deselect all - planning tab', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // checkbox selected select all should be partially selected
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox1);
        expect(checkbox1).toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // all checkboxs selected select all should be selected
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('123456'));
        fireEvent.click(checkbox2);
        expect(checkbox2).toBeChecked();

        expect(screen.getAllByText('2').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).toBeChecked();

        // deselect any checkbox should move the selcet all to partial select state
        fireEvent.click(checkbox1);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        expect(checkbox1).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // deselct all checkbox should move the select all to non checked state
        fireEvent.click(checkbox2);
        expect(checkbox2).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).not.toBeChecked();
    });
    it('select all and deselect all - processing tab', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const processingTab = await screen.findByTestId('tabChild1');
        expect(processingTab).toBeDefined();
        fireEvent.click(processingTab);

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // checkbox selected select all should be partially selected
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox1);
        expect(checkbox1).toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // all checkboxs selected select all should be selected
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('123456'));
        fireEvent.click(checkbox2);
        expect(checkbox2).toBeChecked();

        expect(screen.getAllByText('2').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).toBeChecked();

        // deselect any checkbox should move the selcet all to partial select state
        fireEvent.click(checkbox1);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        expect(checkbox1).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // deselct all checkbox should move the select all to non checked state
        fireEvent.click(checkbox2);
        expect(checkbox2).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).not.toBeChecked();
    });
    it('select all and deselect all - ready to start tab', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const readyToStartTab = await screen.findByTestId('tabChild2');
        expect(readyToStartTab).toBeDefined();
        fireEvent.click(readyToStartTab);

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // checkbox selected select all should be partially selected
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox1);
        expect(checkbox1).toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // all checkboxs selected select all should be selected
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('123456'));
        fireEvent.click(checkbox2);
        expect(checkbox2).toBeChecked();

        expect(screen.getAllByText('2').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).toBeChecked();

        // deselect any checkbox should move the selcet all to partial select state
        fireEvent.click(checkbox1);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        expect(checkbox1).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // deselct all checkbox should move the select all to non checked state
        fireEvent.click(checkbox2);
        expect(checkbox2).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).not.toBeChecked();
    });
    it('select all and deselect all - in transit tab', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const inTransitTab = await screen.findByTestId('tabChild3');
        expect(inTransitTab).toBeDefined();
        fireEvent.click(inTransitTab);

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // checkbox selected select all should be partially selected
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox1);
        expect(checkbox1).toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // all checkboxs selected select all should be selected
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('123456'));
        fireEvent.click(checkbox2);
        expect(checkbox2).toBeChecked();

        expect(screen.getAllByText('2').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).toBeChecked();

        // deselect any checkbox should move the selcet all to partial select state
        fireEvent.click(checkbox1);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        expect(checkbox1).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // deselct all checkbox should move the select all to non checked state
        fireEvent.click(checkbox2);
        expect(checkbox2).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).not.toBeChecked();
    });
    it('select all and deselect all - delivered tab', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const deliveredTab = await screen.findByTestId('tabChild4');
        expect(deliveredTab).toBeDefined();
        fireEvent.click(deliveredTab);

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // checkbox selected select all should be partially selected
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox1);
        expect(checkbox1).toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // all checkboxs selected select all should be selected
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('123456'));
        fireEvent.click(checkbox2);
        expect(checkbox2).toBeChecked();

        expect(screen.getAllByText('2').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).toBeChecked();

        // deselect any checkbox should move the selcet all to partial select state
        fireEvent.click(checkbox1);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        expect(checkbox1).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // deselct all checkbox should move the select all to non checked state
        fireEvent.click(checkbox2);
        expect(checkbox2).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).not.toBeChecked();
    });
    it('select all with change in tab should display navigation modal and continue should change the tab', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        fireEvent.click(screen.getByText('Processing'));

        const processingTab = await screen.findByTestId('tabChild2');
        expect(processingTab).toBeDefined();
        fireEvent.click(processingTab);

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        const containerNew = await screen.findByTestId('page-content-container');
        expect(containerNew).toBeDefined();

        const planTableBodyNew = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBodyNew.children.length).toBeGreaterThan(0);
        });
        const planId = await screen.findByText('123456');
        expect(planId).toBeDefined();

        const selectAllCheckbox = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAllCheckbox).not.toBeChecked();
    });
    it('select all with change in tab should display navigation modal and cancel should deselect', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        fireEvent.click(screen.getByText('Processing'));

        const processingTab = await screen.findByTestId('tabChild2');
        expect(processingTab).toBeDefined();
        fireEvent.click(processingTab);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        const selectAllCheckbox = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAllCheckbox).toBeChecked();
    });
    it('select partial with change in tab should display navigation modal and continue should change the tab', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        fireEvent.click(screen.getByText('Processing'));

        const processingTab = await screen.findByTestId('tabChild2');
        expect(processingTab).toBeDefined();
        fireEvent.click(processingTab);

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        const containerNew = await screen.findByTestId('page-content-container');
        expect(containerNew).toBeDefined();

        const planTableBodyNew = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBodyNew.children.length).toBeGreaterThan(0);
        });
        const planId = await screen.findByText('123456');
        expect(planId).toBeDefined();

        // const selectAllCheckbox = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        // expect(selectAllCheckbox.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        // expect(selectAll).not.toBeChecked();
        // expect(checkbox).not.toBeChecked();
        // expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);

        const selectAllNew = screen.getByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAllNew).not.toBeChecked();
        expect(selectAllNew).not.toBePartiallyChecked();
    });
    it('select all with exception click should display navigation modal and continue should apply filter', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const processingTab = await screen.findByTestId('tabChild1');
        expect(processingTab).toBeDefined();
        fireEvent.click(processingTab);

        const containerNew = await screen.findByTestId('page-content-container');
        expect(containerNew).toBeDefined();

        const planTableBodyNew = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBodyNew.children.length).toBeGreaterThan(0);
        });

        const exceptionChipsCode = {
            PICKUP_96_HOURS_AWAY: 'PICKUP_96_HOURS_AWAY',
            PICKUP_IN_PAST: 'PICKUP_IN_PAST',
        };

        // changing tab show new set of filter chips
        const exceptionChip = await screen.findByTestId(
            `stc-exception-chip-${exceptionChipsCode.PICKUP_96_HOURS_AWAY}`,
        );
        expect(exceptionChip).toBeDefined();

        // check selectAll checbox
        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        // Clicking on exception filter chip action button should toggle the text
        const actionButton = within(exceptionChip).getByTestId(
            `stc-exception-chip-action-${exceptionChipsCode.PICKUP_96_HOURS_AWAY}`,
        );
        expect(actionButton.textContent).toEqual('View loads');
        fireEvent.click(actionButton);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(actionButton.textContent).toEqual('Remove filter');
        expect(selectAll).not.toBeChecked();
    });
    it('select all with exception click should display navigation modal and cancel should deselect', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const processingTab = await screen.findByTestId('tabChild1');
        expect(processingTab).toBeDefined();
        fireEvent.click(processingTab);

        const containerNew = await screen.findByTestId('page-content-container');
        expect(containerNew).toBeDefined();

        const planTableBodyNew = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBodyNew.children.length).toBeGreaterThan(0);
        });

        const exceptionChipsCode = {
            PICKUP_96_HOURS_AWAY: 'PICKUP_96_HOURS_AWAY',
            PICKUP_IN_PAST: 'PICKUP_IN_PAST',
        };

        // changing tab show new set of filter chips
        const exceptionChip = await screen.findByTestId(
            `stc-exception-chip-${exceptionChipsCode.PICKUP_96_HOURS_AWAY}`,
        );
        expect(exceptionChip).toBeDefined();

        // check selectAll checbox
        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        // Clicking on exception filter chip action button should toggle the text
        const actionButton = within(exceptionChip).getByTestId(
            `stc-exception-chip-action-${exceptionChipsCode.PICKUP_96_HOURS_AWAY}`,
        );
        expect(actionButton.textContent).toEqual('View loads');
        fireEvent.click(actionButton);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        expect(actionButton.textContent).toEqual('View loads');
        expect(selectAll).toBeChecked();
    });
    it('select partial with exception click should display navigation modal and continue should apply filter', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const processingTab = await screen.findByTestId('tabChild1');
        expect(processingTab).toBeDefined();
        fireEvent.click(processingTab);

        const containerNew = await screen.findByTestId('page-content-container');
        expect(containerNew).toBeDefined();

        const planTableBodyNew = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBodyNew.children.length).toBeGreaterThan(0);
        });

        const exceptionChipsCode = {
            PICKUP_96_HOURS_AWAY: 'PICKUP_96_HOURS_AWAY',
            PICKUP_IN_PAST: 'PICKUP_IN_PAST',
        };

        // changing tab show new set of filter chips
        const exceptionChip = await screen.findByTestId(
            `stc-exception-chip-${exceptionChipsCode.PICKUP_96_HOURS_AWAY}`,
        );
        expect(exceptionChip).toBeDefined();

        //  select a checbox
        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        // Clicking on exception filter chip action button should toggle the text
        const actionButton = within(exceptionChip).getByTestId(
            `stc-exception-chip-action-${exceptionChipsCode.PICKUP_96_HOURS_AWAY}`,
        );
        expect(actionButton.textContent).toEqual('View loads');
        fireEvent.click(actionButton);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(actionButton.textContent).toEqual('Remove filter');
        expect(selectAll).not.toBeChecked();
        expect(checkbox).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
    });
    it('select all with group by change should display navigation modal and continue should apply group by', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByText('Group by');
        expect(groupByDropdown).toBeDefined();
        expect(screen.getByDisplayValue('Trips')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        // Loads group by selection
        fireEvent.click(groupByDropdown);
        const loadsGB = screen.getByText('Loads');
        expect(loadsGB).toBeDefined();
        fireEvent.click(loadsGB);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(groupByDropdown).toBeDefined();
        expect(screen.getByDisplayValue('Loads')).toBeDefined();

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const [firstRow, secondRow] = planTableBody.children;
        expect(firstRow.children[1].textContent).toBe('22527129');
        expect(secondRow.children[1].textContent).toBe('123456');

        expect(firstRow.children[2].textContent).toBe('Load - STR');
        expect(secondRow.children[2].textContent).toBe('Load - IM');

        const expandRowIcon = screen.queryAllByLabelText('Row Expand Toggle');
        expect(expandRowIcon).toHaveLength(0);

        expect(selectAll).not.toBeChecked();
    });
    it('select all with group by change should display navigation modal and cancel should not apply group by', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByText('Group by');
        expect(groupByDropdown).toBeDefined();
        expect(screen.getByDisplayValue('Trips')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        // Loads group by selection
        fireEvent.click(groupByDropdown);
        const loadsGB = screen.getByText('Loads');
        expect(loadsGB).toBeDefined();
        fireEvent.click(loadsGB);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        expect(groupByDropdown).toBeDefined();
        expect(screen.getByDisplayValue('Trips')).toBeDefined();
        expect(selectAll).toBeChecked();
    });
    it('select partial with group by change should display navigation modal and continue should apply group by', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByText('Group by');
        expect(groupByDropdown).toBeDefined();
        expect(screen.getByDisplayValue('Trips')).toBeDefined();

        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        // Loads group by selection
        fireEvent.click(groupByDropdown);
        const loadsGB = screen.getByText('Loads');
        expect(loadsGB).toBeDefined();
        fireEvent.click(loadsGB);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(groupByDropdown).toBeDefined();
        expect(screen.getByDisplayValue('Loads')).toBeDefined();

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const [firstRow, secondRow] = planTableBody.children;
        expect(firstRow.children[1].textContent).toBe('22527129');
        expect(secondRow.children[1].textContent).toBe('123456');

        expect(firstRow.children[2].textContent).toBe('Load - STR');
        expect(secondRow.children[2].textContent).toBe('Load - IM');

        const expandRowIcon = screen.queryAllByLabelText('Row Expand Toggle');
        expect(expandRowIcon).toHaveLength(0);

        expect(selectAll).not.toBeChecked();
        expect(checkbox).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
    });
    it('select all with global search should display navigation modal and continue should apply global search', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        const gsText = await screen.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        fireEvent.change(gsText, { target: { value: '123' } });
        expect(gsText.value).toBe('123');

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        const title = await screen.findByText('152 search results');
        expect(title).toBeDefined();

        expect(selectAll).not.toBeChecked();

        const expandRowIcon = screen.queryAllByTestId('expandRowIcon');
        expect(expandRowIcon).toHaveLength(0);
    });
    it('select all with global search should display navigation modal and cancel should not apply global search', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        const gsText = await screen.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        fireEvent.change(gsText, { target: { value: '123' } });
        expect(gsText.value).toBe('123');

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        const title = await screen.findByText('Load & Trip Lifecycle');
        expect(title).toBeDefined();

        const globalSearchTitle = screen.queryByText('152 search results');
        expect(globalSearchTitle).toBeNull();

        expect(selectAll).toBeChecked();
    });
    it('select all with global search should display navigation modal and continue should apply global search', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const gsText = await screen.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        fireEvent.change(gsText, { target: { value: '123' } });
        expect(gsText.value).toBe('123');

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        const title = await screen.findByText('152 search results');
        expect(title).toBeDefined();

        expect(selectAll).not.toBeChecked();
        expect(checkbox).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);

        const expandRowIcon = screen.queryAllByTestId('expandRowIcon');
        expect(expandRowIcon).toHaveLength(0);
    });
    it('select all and deselect all - global search', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const gsText = await screen.findByPlaceholderText('Search for Load IDs, Trip IDs');
        expect(gsText).toBeDefined();

        fireEvent.change(gsText, { target: { value: '123' } });
        expect(gsText.value).toBe('123');

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByLoadPlanResults));
                }
            }),
        );

        const searchElmt = await screen.findByTestId('globalSearch-tm');
        const searchBtn = within(searchElmt).getByTestId('ld-sc-ui-button');
        fireEvent.click(searchBtn);

        const title = await screen.findByText('152 search results');
        expect(title).toBeDefined();

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        // checkbox selected select all should be partially selected
        const checkbox1 = screen.getByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox1);
        expect(checkbox1).toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const selectAll = screen.getByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // all checkboxs selected select all should be selected
        const checkbox2 = screen.getByTestId(getCheckboxTestId('123456'));
        fireEvent.click(checkbox2);
        expect(checkbox2).toBeChecked();

        expect(screen.getAllByText('2').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).toBeChecked();

        // deselect any checkbox should move the selcet all to partial select state
        fireEvent.click(checkbox1);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        expect(checkbox1).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        // deselct all checkbox should move the select all to non checked state
        fireEvent.click(checkbox2);
        expect(checkbox2).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
        expect(selectAll).not.toBeChecked();
    });
    it('should be able to select trip', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('500003888'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        fireEvent.click(checkbox);
        expect(checkbox).not.toBeChecked();

        const selectAllCheckbox = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAllCheckbox.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
    });
    it('should be able to select IM loads', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'US_US') {
                    return res(ctx.json(groupByIMPlanResults));
                }
            }),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const groupByDropdown = await screen.findByText('Group by');
        expect(groupByDropdown).toBeDefined();
        // Intermodal group by selection
        fireEvent.click(groupByDropdown);
        const imGB = screen.getByText('Intermodal');
        expect(imGB).toBeDefined();
        fireEvent.click(imGB);

        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const [firstRow] = planTableBody.children;
        expect(firstRow.children[1].textContent).toBe('222312521');
        expect(firstRow.children[2].textContent).toBe('Load - IM3');

        const loadIdChild = screen.queryByText('27458477');
        expect(loadIdChild).toBeNull();
        const expandRowIcon = within(firstRow).getByLabelText('Row Expand Toggle');
        fireEvent.click(expandRowIcon);
        const childLoad = await screen.findByText('27458477');
        expect(childLoad).toBeDefined();

        const checkbox = await screen.findByTestId(getCheckboxTestId('222312521'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        fireEvent.click(checkbox);
        expect(checkbox).not.toBeChecked();

        const selectAllCheckbox = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAllCheckbox.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
    });
    it('select all with table client search should display navigation modal and continue should search', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        const tableSearch = await screen.findByTestId('search');
        fireEvent.change(tableSearch, { target: { value: 'PLT' } });

        expect(await screen.findByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = screen.getByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        expect(screen.queryByText('1 results')).not.toBeNull();
        expect(selectAll).not.toBeChecked();
    });
    it('select all with table client search should display navigation modal and cancel should not search', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        const tableSearch = await screen.findByTestId('search');
        fireEvent.change(tableSearch, { target: { value: 'PLT' } });

        expect(await screen.findByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        expect(screen.queryByText('1 results')).toBeNull();
        expect(selectAll).toBeChecked();
    });
    it('select partial with table client search should display navigation modal and continue should search', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const tableSearch = await screen.findByTestId('search');
        fireEvent.change(tableSearch, { target: { value: 'PLT' } });

        expect(await screen.findByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = screen.getByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        expect(screen.queryByText('1 results')).not.toBeNull();

        expect(selectAll).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
    });
    it('select all with sort field change should display navigation modal and continue should apply sort', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        // should sort by origin on click on table header cell
        const origin = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.ORIGIN_LOCATION_ID.id));
        expect(origin.getAttribute('aria-sort')).toBe('none');
        fireEvent.click(within(origin).getByRole('button'));

        expect(await screen.findByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByTestId('page-content-container')).toBeDefined();
        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        expect(origin.getAttribute('aria-sort')).not.toBeNull();
        expect(origin.getAttribute('aria-sort')).toBe('ascending');
        expect(selectAll).not.toBeChecked();
    });

    it('select all with sort field change should display navigation modal and cancel should not apply sort', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        // should sort by origin on click on table header cell
        const origin = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.ORIGIN_LOCATION_ID.id));
        fireEvent.click(within(origin).getByRole('button'));
        expect(origin.getAttribute('aria-sort')).toBe('none');

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        expect(origin.getAttribute('aria-sort')).toBe('none');
        expect(selectAll).toBeChecked();
    });

    it('select partial with sort field change should display navigation modal and continue should apply sort', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        // should sort by origin on click on table header cell
        const origin = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.ORIGIN_LOCATION_ID.id));
        expect(origin.getAttribute('aria-sort')).toBe('none');
        fireEvent.click(within(origin).getByRole('button'));

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByTestId('page-content-container')).toBeDefined();
        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        expect(origin.getAttribute('aria-sort')).not.toBeNull();
        expect(origin.getAttribute('aria-sort')).toBe('ascending');
        expect(checkbox).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
    });

    it('select all with sort direction change should display navigation modal and continue should apply sort', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        const plannedStart = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.PLANNED_START.id));
        expect(plannedStart.getAttribute('aria-sort')).toBe('ascending');
        fireEvent.click(within(plannedStart).getByRole('button'));

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByTestId('page-content-container')).toBeDefined();
        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        expect(plannedStart.getAttribute('aria-sort')).toBe('descending');
        expect(selectAll).not.toBeChecked();
    });

    it('select all with sort direction change should display navigation modal and cancel should not apply sort', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        expect(screen.getAllByText('10').length).toBeGreaterThan(0);
        expect(screen.getByText('plans selected')).toBeDefined();

        const plannedStart = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.PLANNED_START.id));
        expect(plannedStart.getAttribute('aria-sort')).toBe('ascending');
        fireEvent.click(within(plannedStart).getByRole('button'));

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        expect(plannedStart.getAttribute('aria-sort')).toBe('ascending');
        expect(selectAll).toBeChecked();
    });

    it('select partial with sort direction change should display navigation modal and continue should apply sort', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        const plannedStart = await screen.findByTestId(getTableCellTestId(0, TableColumnsUS.PLANNED_START.id));
        expect(plannedStart.getAttribute('aria-sort')).toBe('ascending');
        fireEvent.click(within(plannedStart).getByRole('button'));

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByTestId('page-content-container')).toBeDefined();
        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        expect(plannedStart.getAttribute('aria-sort')).toBe('descending');
        expect(checkbox).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
    });

    it('select all with time horizon change should display navigation modal and continue should apply time horizon', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const timeHorizonDropdown = await screen.findByTestId('timeHorizon');
        expect(timeHorizonDropdown).toBeDefined();
        // default timehorizon
        expect(await screen.findByText('Oct 1, 2023 - Nov 13, 2023')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        // change time horizon
        const title = await screen.findByText('Time Horizon');
        expect(title).toBeDefined();
        fireEvent.click(timeHorizonDropdown);
        const customListPopover = await screen.findByTestId('custom-list-popover');
        expect(within(customListPopover).getByText('Past: 40 days - Future: 10 days')).toBeDefined();
        const option1 = screen.getByTestId('select-item-0');
        fireEvent.click(option1);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        await waitFor(() => expect(screen.queryByTestId('custom-list-popover')).not.toBeInTheDocument());

        expect(await screen.findByText('Past: 40 days - Future: 10 days')).toBeDefined();
        expect(screen.queryByText('Oct 1, 2023 - Nov 13, 2023')).toBeNull();
        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        expect(selectAll).not.toBeChecked();
    });
    it('select all with time horizon change should display navigation modal and cancel should not apply time horizon', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const timeHorizonDropdown = await screen.findByTestId('timeHorizon');
        expect(timeHorizonDropdown).toBeDefined();
        // default timehorizon
        expect(await screen.findByText('Oct 1, 2023 - Nov 13, 2023')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        // change time horizon
        const title = await screen.findByText('Time Horizon');
        expect(title).toBeDefined();
        fireEvent.click(timeHorizonDropdown);
        expect(await screen.findByText('Past: 40 days - Future: 10 days')).toBeDefined();
        const option1 = screen.getByTestId('select-item-0');
        fireEvent.click(option1);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        expect(await screen.findByText('Oct 1, 2023 - Nov 13, 2023')).toBeDefined();
        expect(screen.queryByText('Past: 40 days - Future: 10 days')).toBeNull();
        expect(selectAll).toBeChecked();
    });
    it('select partial with time horizon change should display navigation modal and continue should apply time horizon', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const timeHorizonDropdown = await screen.findByTestId('timeHorizon');
        expect(timeHorizonDropdown).toBeDefined();
        // default timehorizon
        expect(await screen.findByText('Oct 1, 2023 - Nov 13, 2023')).toBeDefined();

        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        // change time horizon
        const title = await screen.findByText('Time Horizon');
        expect(title).toBeDefined();
        fireEvent.click(timeHorizonDropdown);
        expect(await screen.findByText('Past: 40 days - Future: 10 days')).toBeDefined();
        const option1 = screen.getByTestId('select-item-0');
        fireEvent.click(option1);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByText('Past: 40 days - Future: 10 days')).toBeDefined();
        expect(screen.queryByText('Oct 1, 2023 - Nov 13, 2023')).toBeNull();
        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        expect(checkbox).not.toBeChecked();
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-false/gi);
    });
    it('select all with profile change should display navigation modal and continue should apply profile', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const profileDropdown = await screen.findByTestId('profileSelect');
        expect(profileDropdown).toBeDefined();
        // default profile
        expect(await screen.findByText('All load types')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        // change profile
        const title = await screen.findByText('Profile');
        expect(title).toBeDefined();
        fireEvent.click(profileDropdown);
        expect(await screen.findByText('DC 6094')).toBeDefined();
        const option2 = screen.getByTestId('select-item-1');
        fireEvent.click(option2);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByText('DC 6094')).toBeDefined();
        expect(screen.queryByText('All load types')).toBeNull();
        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        expect(selectAll).not.toBeChecked();
    });
    it('select all with profile change should display navigation modal and cancel should not apply profile', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const profileDropdown = await screen.findByTestId('profileSelect');
        expect(profileDropdown).toBeDefined();
        // default profile
        expect(await screen.findByText('All load types')).toBeDefined();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        fireEvent.click(selectAll);
        expect(selectAll).toBeChecked();

        // change profile
        const title = await screen.findByText('Profile');
        expect(title).toBeDefined();
        fireEvent.click(profileDropdown);
        expect(await screen.findByText('DC 6094')).toBeDefined();
        const option2 = screen.getByTestId('select-item-1');
        fireEvent.click(option2);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const cancelBtn = await screen.findByTestId('modal-cancel-btn');
        fireEvent.click(cancelBtn);

        expect(await screen.findByText('All load types')).toBeDefined();
        expect(screen.queryByText('DC 6094')).toBeNull();
        expect(selectAll).toBeChecked();
    });
    it('select partial with profile change should display navigation modal and continue should apply profile', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const profileDropdown = await screen.findByTestId('profileSelect');
        expect(profileDropdown).toBeDefined();
        // default profile
        expect(await screen.findByText('All load types')).toBeDefined();

        const checkbox = await screen.findByTestId(getCheckboxTestId('22527129'));
        fireEvent.click(checkbox);
        expect(checkbox).toBeChecked();

        const selectAll = await screen.findByTestId(SELECT_ALL_CHECKBOX_TEST_ID);
        expect(selectAll.className).toMatch(/ld-sc-ui-checkbox-partial-true/gi);
        expect(selectAll).not.toBeChecked();

        expect(screen.getAllByText('1').length).toBeGreaterThan(0);
        expect(screen.getByText('plan selected')).toBeDefined();

        // change profile
        const title = await screen.findByText('Profile');
        expect(title).toBeDefined();
        fireEvent.click(profileDropdown);
        expect(await screen.findByText('DC 6094')).toBeDefined();
        const option2 = screen.getByTestId('select-item-1');
        fireEvent.click(option2);

        expect(screen.getByText('Are you sure you want to navigate away ?')).toBeDefined();
        const continueBtn = await screen.findByText('Yes, continue');
        fireEvent.click(continueBtn);

        expect(await screen.findByText('DC 6094')).toBeDefined();
        expect(screen.queryByText('All load types')).toBeNull();
        expect(await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID)).toBeDefined();
        expect(selectAll).not.toBeChecked();
    });
});
