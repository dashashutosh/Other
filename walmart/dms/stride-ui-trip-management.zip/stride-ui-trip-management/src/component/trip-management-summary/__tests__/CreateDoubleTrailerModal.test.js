import React from 'react';
import { fireEvent, render, screen } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import CreateDoubleTrailerModal from '../CreateDoubleTrailerModal';
import TripSharedService from '../../../service/TripSharedService';
import { mockDoubleTrailerPlans } from './mocks/DataModels.mock';
import { mockCheckedRows, mockStaticData } from './mocks/CreateDoubleTrailerModal.mock';

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
    TripSharedService.setFeatureFlags({
        enableDifferentOriginForDoubleTrailer: true,
    });
    const trans = jest.fn((a) => a);
    TripSharedService.setTrans(trans);
});

jest.mock('@walmart/stride-ui-commons', () => ({
    ...jest.requireActual('@walmart/stride-ui-commons'),
}));

describe('Create double trailer modal', () => {
    it('should display modal title when rendered', () => {
        const wrapper = render(
            <CreateDoubleTrailerModal
                pIsOpen
                pOnClose={() => {}}
                pOnCreate={() => {}}
                pCheckedRows={mockCheckedRows}
                pPaginatedData={mockDoubleTrailerPlans}
                pStaticData={mockStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        expect(wrapper.queryByText('Create double trailer')).toBeDefined();
    });

    it('should call cancel when clicked', () => {
        const cancelMockFn = jest.fn();
        const wrapper = render(
            <CreateDoubleTrailerModal
                pIsOpen
                pOnClose={cancelMockFn}
                pOnCreate={() => {}}
                pCheckedRows={mockCheckedRows}
                pPaginatedData={mockDoubleTrailerPlans}
                pStaticData={mockStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const cancelBtn = wrapper.queryByTestId('cancelBtn');
        expect(cancelBtn).toBeDefined();
        fireEvent.click(cancelBtn);
        expect(cancelMockFn).toHaveBeenCalled();
    });

    it('should call submit if the equipment type drop down is populated', async () => {
        const submitMockFn = jest.fn();
        const wrapper = render(
            <CreateDoubleTrailerModal
                pIsOpen
                pOnClose={() => {}}
                pOnCreate={submitMockFn}
                pCheckedRows={mockCheckedRows}
                pPaginatedData={mockDoubleTrailerPlans}
                pStaticData={mockStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const singleSelect = await screen.findByTestId('double-trailer');
        expect(singleSelect).toBeDefined();
        fireEvent.click(singleSelect);

        const option = await screen.findByTestId('single-select-simple-option-TRRF56');
        expect(option).toBeDefined();
        fireEvent.click(option);

        const createBtn = await screen.findByTestId('createBtn');
        expect(createBtn).toBeDefined();
        fireEvent.click(createBtn);
        expect(submitMockFn).toHaveBeenCalled();
    });

    it('should not call submit if the equipment type drop down is not populated', async () => {
        const submitMockFn = jest.fn();
        const wrapper = render(
            <CreateDoubleTrailerModal
                pIsOpen
                pOnClose={() => {}}
                pOnCreate={submitMockFn}
                pCheckedRows={mockCheckedRows}
                pPaginatedData={mockDoubleTrailerPlans}
                pStaticData={mockStaticData}
            />,
        );
        expect(wrapper).toBeDefined();
        const singleSelect = await screen.findByTestId('double-trailer');
        expect(singleSelect).toBeDefined();
        fireEvent.click(singleSelect);

        const createBtn = await screen.findByTestId('createBtn');
        expect(createBtn).toBeDefined();
        fireEvent.click(createBtn);
        expect(submitMockFn).not.toHaveBeenCalled();
    });
});
