import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { render, screen, fireEvent, within, waitFor } from '../../../utils/test-utils';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

import { PlanLTProcessing, PlanLTTransit, fileSample } from './mocks/PlanLTPreview.mock';
import {
    apporveMock,
    assignTripMock,
    autoTenderMock,
    validateTariff,
    assignCarrierMock,
    markasDeliveredMock,
    cancelMock,
    tripResponseWithChargeLocations,
    userRlInfoMock,
    cancelTripMock,
    addCommentMockResponse,
    addCommentToAllMockResponse,
    addCommentToAllPartialMockResponse,
} from './mocks/TripManagementSummary.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';

// TODO: reduce mock data content
import PlanSearchAggregatesCA from './mocks/PlanSearchAggregatesCA.mock.json';
import PlanSearchAggregates from './mocks/PlanSearchAggregates.mock.json';
import PlanLTPreviewCL from './mocks/PlanLTPreviewCL.mock.json';
import PlanLTPreviewGT from './mocks/PlanLTPreviewGT.mock.json';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataGT from './mocks/MdmLtmStaticDataGT.mock.json';

import TripManagementSummary from '../TripManagementSummary';
import TripSharedService from '../../../service/TripSharedService';
import { getUpdatedCMSConfig } from '../../../utils/test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';
const serviceTypeReal = 'stride-ResouceBEAPI';
const fileBuffer = Uint8Array.from(window.atob(fileSample), (c) => c.charCodeAt(0));

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'CA_CA') {
            return res(ctx.json(PlanSearchAggregatesCA));
        }
        if (tenantId === 'CL' || tenantId === 'CAM_GT') {
            return res(ctx.json(PlanSearchAggregates));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}approveStatusChange/approveStatusChange`, (req, res, ctx) =>
        res(ctx.json(apporveMock)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}planLTPreview/planLTPreview`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        const { status } = JSON.parse(req.body.payload).payload;
        if (tenantId === 'CL') {
            if (status.some((dta) => dta.status === 'NEED_ATTENTION')) {
                return res(ctx.json(PlanLTProcessing));
            }
            if (status.some((dta) => dta.status === 'IN_TRANSIT')) {
                return res(ctx.json(PlanLTTransit));
            }
            return res(ctx.json(PlanLTPreviewCL));
        }
        if (tenantId === 'CAM_GT') {
            if (status.some((dta) => dta.status === 'NEED_ATTENTION')) {
                return res(ctx.json(PlanLTProcessing));
            }
            if (status.some((dta) => dta.status === 'IN_TRANSIT')) {
                return res(ctx.json(PlanLTTransit));
            }
            return res(ctx.json(PlanLTPreviewGT));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}assignTrip/assignTrip`, (req, res, ctx) => res(ctx.json(assignTripMock))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}autoTender/autoTender`, (req, res, ctx) => res(ctx.json(autoTenderMock))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}assignCarrier/assignCarrier`, (req, res, ctx) =>
        res(ctx.json(assignCarrierMock)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}getCarriers/getCarriers`, (req, res, ctx) => res(ctx.json(validateTariff))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}markInTransitDelivered/markInTransitDelivered`, (req, res, ctx) =>
        res(ctx.json(markasDeliveredMock)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}withdrawTender/withdrawTender`, (req, res, ctx) => res(ctx.status(200))),
    rest.post(`${serviceTypeReal}/getDispatchDocument`, (req, res, ctx) =>
        res(
            ctx.set('Content-Length', fileBuffer.byteLength.toString()),
            ctx.set('Content-Type', 'application/pdf'),
            ctx.body(fileBuffer),
        ),
    ),
    rest.post(`${serviceTypeReal}/getDispatchLabel`, (req, res, ctx) =>
        res(
            ctx.set('Content-Length', fileBuffer.byteLength.toString()),
            ctx.set('Content-Type', 'application/pdf'),
            ctx.body(fileBuffer),
        ),
    ),

    // us
    rest.post(`${API_GATEWAY_PREFIX_NEW}approvePlans/approvePlans`, (req, res, ctx) => res(ctx.json(apporveMock))),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        return res(ctx.json(CmsConfig));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}cancelLoadMulti/cancelLoadMulti`, (req, res, ctx) => res(ctx.json(cancelMock))),
    rest.post('api/gateway/v4/stride-ResouceBEAPI/getDispatchDocument', (req, res, ctx) => res(ctx.status(200))),
    rest.post('api/gateway/v4/stride-ResouceBEAPI/getDispatchLabel', (req, res, ctx) => res(ctx.status(200))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}cancelTrip/cancelTrip`, (req, res, ctx) => res(ctx.json(cancelTripMock))),
    rest.post('api/gateway/v4/undefined', (req, res, ctx) => res(ctx.status(200))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}addComments/addComments?planId=50004376`, (req, res, ctx) =>
        res(ctx.json(addCommentMockResponse)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}addCommentToLoads/addCommentToLoads`, (req, res, ctx) =>
        res(ctx.json(addCommentToAllMockResponse)),
    ),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
        'ustrx.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt', 'ustrx'],
});

// TOOD: @anirudh return proper value
const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();
});

beforeEach(() => {
    // jest.useFakeTimers('');
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Trip management summary tests for CL & GT', () => {
    const contextMockCL = { ...contextMock, currentMarket: 'cl' };
    beforeEach(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCL);
        TripSharedService.setFeatureFlags({
            descDateTimeCreated: false,
        });
    });

    it('should render without crashing with featureFlag off', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Dispatch pending tab should be shown for CA
        const tab = await wrapper.findByText('Dispatch pending');
        expect(tab).toBeDefined();

        // Should have "Created date/time" as default sort column
        expect(screen.getByTestId('plan-table-header-createdTs').getAttribute('aria-sort')).toBe('ascending');
    });

    it('should render without crashing with featureFlag on', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            descDateTimeCreated: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Dispatch pending tab should be shown for CA
        const tab = await wrapper.findByText('Dispatch pending');
        expect(tab).toBeDefined();

        // Should have "Created date/time" as default sort column
        expect(screen.getByTestId('plan-table-header-createdTs').getAttribute('aria-sort')).toBe('descending');
    });

    it('tab change on click', () => {
        render(<TripManagementSummary />);
        fireEvent.click(screen.getByText('Planning'));
        fireEvent.click(screen.getByText('Processing'));
        fireEvent.click(screen.getByText('Dispatch pending'));
        fireEvent.click(screen.getByText('In transit'));
    });

    it('approve action in planning tab', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Select a trip with pending approval status.
        const checkbox = await screen.findByTestId('dt-chkbx-0-30064496');
        fireEvent.click(checkbox);
        // Click on apporve button.
        const apporveButton = await screen.findByTestId('approveTrip');
        expect(apporveButton).toBeDefined();
        fireEvent.click(apporveButton);
        // Success message should appear
        const msg = await wrapper.findByText('Trip plan is approved');
        expect(msg).toBeDefined();
    });
    it('should not show total count', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const totalCount = screen.queryByText('20 results');
        expect(totalCount).toBeNull();
        const pageCount = screen.queryByText('ld-sc-ui-table-page-count');
        expect(pageCount).toBeNull();
    });

    it('dispatch trip action in dispatch pending tab', async () => {
        render(<TripManagementSummary />);
        const dispatch = await screen.findByTestId('tabChild2');
        expect(dispatch).toBeDefined();
        fireEvent.click(dispatch);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Select a load with unplanned status.
        const checkbox = await screen.findByTestId('dt-chkbx-2-30000754');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        // Click on dispatch a trip button.
        const dispatchButton = await screen.findByTestId('dispatch');
        expect(dispatchButton).toBeDefined();
        fireEvent.click(dispatchButton);

        // Successfull create trip msg
        const msg = await screen.findByText('Trip plan 30000754 dispatched successfully');
        expect(msg).toBeDefined();
        const subMsg = await screen.findByText('Dispatch documents will be downloaded automatically');
        expect(subMsg).toBeDefined();
    });

    it('reprint doc action in transit tab', async () => {
        rest.post(`${API_GATEWAY_PREFIX_NEW}planLTPreview/planLTPreview`, (req, res, ctx) => {
            const { tenantId } = req.body.additionalHeaders;
            const { status } = JSON.parse(req.body.payload).payload;
            if (tenantId === 'CL') {
                if (status.some((dta) => dta.status === 'NEED_ATTENTION')) {
                    return res(ctx.json(PlanLTProcessing));
                }
                if (status.some((dta) => dta.status === 'IN_TRANSIT')) {
                    return res(ctx.json(PlanLTTransit));
                }
                return res(ctx.json(PlanLTPreviewCL));
            }
            return res(ctx.status(404));
        });
        render(<TripManagementSummary />);
        const dispatch = await screen.findByTestId('tabChild3');
        expect(dispatch).toBeDefined();
        fireEvent.click(dispatch);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Select a load with unplanned status.
        const checkbox = await screen.findByTestId('dt-chkbx-3-30002715');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        // Click on Reprint Dispatch Doc button.
        const dispatchButton = await screen.findByTestId('reprintDispatchDoc');
        expect(dispatchButton).toBeDefined();
        fireEvent.click(dispatchButton);

        // Successfull open the reprint document modal
        const reprintModal = await screen.findByTestId('ld-sc-ui--modal-content');
        expect(reprintModal).toBeDefined();
    });

    it('mark as delivered action in transit tab', async () => {
        rest.post(`${API_GATEWAY_PREFIX_NEW}planLTPreview/planLTPreview`, (req, res, ctx) => {
            const { tenantId } = req.body.additionalHeaders;
            const { status } = JSON.parse(req.body.payload).payload;
            if (tenantId === 'CL') {
                if (status.some((dta) => dta.status === 'NEED_ATTENTION')) {
                    return res(ctx.json(PlanLTProcessing));
                }
                if (status.some((dta) => dta.status === 'IN_TRANSIT')) {
                    return res(ctx.json(PlanLTTransit));
                }
                return res(ctx.json(PlanLTPreviewCL));
            }
            return res(ctx.status(404));
        });
        render(<TripManagementSummary />);
        const dispatch = await screen.findByTestId('tabChild3');
        expect(dispatch).toBeDefined();
        fireEvent.click(dispatch);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Select a load with unplanned status.
        const checkbox = await screen.findByTestId('dt-chkbx-3-30002715');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        // Click on dispatch a trip button.
        const dispatchButton = await screen.findByTestId('markAsDelivered');
        expect(dispatchButton).toBeDefined();
        fireEvent.click(dispatchButton);

        // Successfull create trip msg
        const msg = await screen.findByText('Trip plan is delivered');
        expect(msg).toBeDefined();
    });

    it('auto tender action in processing tab', async () => {
        const wrapper = render(<TripManagementSummary />);
        const dispatch = await screen.findByTestId('tabChild1');
        expect(dispatch).toBeDefined();
        fireEvent.click(dispatch);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        // wait till table is populated with some data
        const checkbox = await screen.findByTestId('dt-chkbx-1-30072631');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const autoTenderBtn = await screen.findByTestId('tenderTrip');
        expect(autoTenderBtn).toBeDefined();
        fireEvent.click(autoTenderBtn);
        // Success message should appear
        const msg = await wrapper.findByText('Auto tendered successfully');
        expect(msg).toBeDefined();
    });

    it('should hide assign to trip button when the feature flag hideAssignToTripForSTRLoad is set', async () => {
        const contextMockGT = { ...contextMock, currentMarket: 'gt' };
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockGT);

        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"hideAssignToTripForSTRLoad": true, "viewMoreRecords": true}}',
                },
            },
        };
        TripSharedService.setConfig(config);
        const PlanLTPreviewithSTRLoads = {
            ...PlanLTPreviewCL,
            payload: [
                {
                    ...PlanLTPreviewCL.payload[1],
                    planResponse: {
                        ...PlanLTPreviewCL.payload[1].planResponse,
                        planCategory: 'STR',
                    },
                },
            ],
        };
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(PlanLTPreviewithSTRLoads)),
            ),
        );
        TripSharedService.setFeatureFlags({ hideAssignToTripForSTRLoad: true });
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId('dt-chkbx-0-50089630');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);
        expect(screen.queryByTestId('assignToTrip')).toBeNull();
    });

    it('should display assign to trip button when the feature flag hideAssignToTripForSTRLoad is reset', async () => {
        const contextMockGT = { ...contextMock, currentMarket: 'gt' };

        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockGT);

        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"hideAssignToTripForSTRLoad": false, "viewMoreRecords": true}}',
                },
            },
        };
        TripSharedService.setConfig(config);
        const PlanLTPreviewithSTRLoads = {
            ...PlanLTPreviewCL,
            payload: [
                {
                    ...PlanLTPreviewCL.payload[1],
                    planResponse: {
                        ...PlanLTPreviewCL.payload[1].planResponse,
                        planCategory: 'STR',
                    },
                },
            ],
        };
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(PlanLTPreviewithSTRLoads)),
            ),
        );

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId('dt-chkbx-0-50089630');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);
        expect(screen.queryByTestId('assignToTrip')).not.toBeNull();
        TripSharedService.setConfig(null);
    });

    it('create trip action in planning tab', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Select a load with unplanned status.
        const checkbox = await screen.findByTestId('dt-chkbx-0-50089630');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        // Click on create a trip button.
        const createButton = await screen.findByTestId('createTrip');
        expect(createButton).toBeDefined();
        fireEvent.click(createButton);

        // Click on create button
        const createConfirmBtn = await screen.findByText('Yes, create trip');
        expect(createConfirmBtn).toBeDefined();
        fireEvent.click(createConfirmBtn);

        // Successfull create trip msg
        const msg = await screen.findByText('Successfully created trip(s)');
        expect(msg).toBeDefined();
    });
});

describe('Trip management summary test cases for CA', () => {
    const contextMockCA = { ...contextMock, currentMarket: 'ca' };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCA);
    });

    it('should render without crashing', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // // wait till table is populated with some data
        // const planTable = screen.getByTestId('plan-table');
        // await waitForElementToBeRemoved(() => within(planTable).queryByText('No data available'));

        // Ready to start tab should be shown for CA
        const tab = await screen.findByText('Ready to start');
        expect(tab).toBeDefined();
    });

    it('should have a default sorting column on each phase', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const planningTab = screen.getByText('Planning');
        const processingTab = screen.getByText('Processing');
        const readyToStartTab = screen.getByText('Ready to start');
        const inTransitTab = screen.getByText('In transit');

        // On load, Planning tab should have planned departure as default sort column
        expect(screen.getByTestId('plan-table-header-departureTs').getAttribute('aria-sort')).toBe('ascending');
        expect(screen.getByTestId('plan-table-header-arrivalTs').getAttribute('aria-sort')).toBeFalsy();

        // Changing to Processing tab should have planned departure as default sort column
        fireEvent.click(processingTab);
        expect(screen.getByTestId('plan-table-header-departureTs').getAttribute('aria-sort')).toBe('ascending');
        expect(screen.getByTestId('plan-table-header-arrivalTs').getAttribute('aria-sort')).toBeFalsy();

        // Changing to Ready to Start tab should have planned departure as default sort column
        fireEvent.click(readyToStartTab);
        expect(screen.getByTestId('plan-table-header-departureTs').getAttribute('aria-sort')).toBe('ascending');
        expect(screen.getByTestId('plan-table-header-arrivalTs').getAttribute('aria-sort')).toBeFalsy();

        // Changing to In transit tab should have planned arrival as default sort column
        fireEvent.click(inTransitTab);
        expect(screen.queryByTestId('plan-table-header-departureTs')).toBeFalsy();
        expect(screen.getByTestId('plan-table-header-arrivalTs').getAttribute('aria-sort')).toBe('ascending');

        // Changing to Planning tab should have planned departure as default sort column
        fireEvent.click(planningTab);
        expect(screen.getByTestId('plan-table-header-departureTs').getAttribute('aria-sort')).toBe('ascending');
        expect(screen.getByTestId('plan-table-header-arrivalTs').getAttribute('aria-sort')).toBeFalsy();
    });

    it('exception filter chips flow', async () => {
        render(<TripManagementSummary />);

        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planningTab = screen.getByText('Planning');
        const inTransitTab = screen.getByText('In transit');
        const exceptionChipsCode = {
            underUtilisedLoad: 'UNDER_UTILISED_LOAD',
            noUpdate: 'NO_UPDATE',
        };

        expect(screen.queryByTestId(`stc-exception-chip-${exceptionChipsCode.underUtilisedLoad}`)).toBeDefined();

        // changing tab show show new set of filter chips
        fireEvent.click(inTransitTab);
        expect(screen.queryByTestId(`stc-exception-chip-${exceptionChipsCode.noUpdate}`)).toBeDefined();
        // expect(
        //   screen.queryByTestId(`stc-exception-chip-${exceptionChipsCode.underUtilisedLoad}`),
        // ).toBeFalsy();

        fireEvent.click(planningTab);
        const underUtilizedLoadExceptionChip = screen.getByTestId(
            `stc-exception-chip-${exceptionChipsCode.underUtilisedLoad}`,
        );
        expect(underUtilizedLoadExceptionChip).toBeDefined();

        // Clicking on exception filter chip action button should toggle the text
        const actionButton = within(underUtilizedLoadExceptionChip).getByTestId(
            `stc-exception-chip-action-${exceptionChipsCode.underUtilisedLoad}`,
        );
        expect(actionButton.textContent).toEqual('View loads');
        fireEvent.click(actionButton);
        expect(actionButton.textContent).toEqual('Remove filter');
        fireEvent.click(actionButton);
        expect(actionButton.textContent).toEqual('View loads');
    });

    it('approve action in planning tab', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        // Select a trip with pending approval status.
        const checkbox = await screen.findByTestId('dt-chkbx-0-50000678');
        fireEvent.click(checkbox);
        // Click on apporve button.
        const apporveButton = await screen.findByTestId('approveLoad');
        expect(apporveButton).toBeDefined();
        fireEvent.click(apporveButton);
        // Success message should appear
        const msg = await wrapper.findByText('Trip plan is approved');
        expect(msg).toBeDefined();
    });

    it('auto tender action in processing tab', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        // Select a trip with Tender cancelled status.
        const checkbox = await screen.findByTestId('dt-chkbx-1-50000786');
        fireEvent.click(checkbox);

        // Click on auto tender button.
        const autoTenderBtn = await screen.findByTestId('tenderLoad');
        expect(autoTenderBtn).toBeDefined();
        fireEvent.click(autoTenderBtn);
        // Success message should appear
        const msg = await wrapper.findByText('Auto tendered successfully');
        expect(msg).toBeDefined();
    });

    it('assign manually action in processing tab', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        // Select a trip with needs attention status.
        const checkbox = await screen.findByTestId('dt-chkbx-1-50000857');
        fireEvent.click(checkbox);

        // Click on assign manually button.
        const assignManualBtn = await screen.findByTestId('loadAssignManually');
        expect(assignManualBtn).toBeDefined();
        fireEvent.click(assignManualBtn);

        fireEvent.click(screen.getByText('Enter SCAC'));

        const inputElement = screen.getByLabelText('Enter SCAC');
        expect(inputElement).toBeDefined();

        // Enter scac id
        fireEvent.change(inputElement, { target: { value: '9294426' } });
        const assignButton = screen.getByText('Assign');
        expect(assignButton.getAttribute('disabled')).toBe(null);

        // Click on Assign button
        fireEvent.click(assignButton);
        // Todo: Need to add expectation
        // const msg = await screen.findByText('Workload assigned successfully');
        // // expect(msg).toBeDefined();
    });

    it('should show total count', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const totalCount = await screen.findByText('20 results');
        expect(totalCount).toBeDefined();
        const pageCount = await screen.findByTestId('ld-sc-ui-table-page-count');
        expect(pageCount).toBeDefined();
    });

    it('should load accordion with child elemnt if view more record feature flag available', async () => {
        render(<TripManagementSummary />);
        const accordion = await screen.findAllByTestId('accordion-container');
        expect(accordion).toBeDefined();
        const filteraccordion = await screen.findByTestId('filteraccordion');
        expect(filteraccordion).toBeDefined();
    });
    describe('location id filter', () => {
        it('should show origin and destination location id filter fields on each phase', async () => {
            render(<TripManagementSummary />);
            const container = await screen.findByTestId('page-content-container');
            expect(container).toBeDefined();
            const filterIcon = screen.getByTestId('filter-icon');
            expect(filterIcon).toBeDefined();

            const planningTab = screen.getByText('Planning');
            const processingTab = screen.getByText('Processing');
            const readyToStartTab = screen.getByText('Ready to start');
            const inTransitTab = screen.getByText('In transit');

            fireEvent.click(planningTab);
            fireEvent.click(filterIcon.firstChild);
            expect(screen.getByTestId('originLocId')).toBeDefined();
            expect(screen.getByTestId('destinationLocId')).toBeDefined();

            fireEvent.click(processingTab);
            fireEvent.click(filterIcon.firstChild);
            expect(screen.getByTestId('originLocId')).toBeDefined();
            expect(screen.getByTestId('destinationLocId')).toBeDefined();

            fireEvent.click(readyToStartTab);
            fireEvent.click(filterIcon.firstChild);
            expect(screen.getByTestId('originLocId')).toBeDefined();
            expect(screen.getByTestId('destinationLocId')).toBeDefined();

            fireEvent.click(inTransitTab);
            fireEvent.click(filterIcon.firstChild);
            expect(screen.getByTestId('originLocId')).toBeDefined();
            expect(screen.getByTestId('destinationLocId')).toBeDefined();
        });

        it('should disable all origin fields if location id is present', async () => {
            render(<TripManagementSummary />);
            const container = await screen.findByTestId('page-content-container');
            expect(container).toBeDefined();
            const filterIcon = screen.getByTestId('filter-icon');
            fireEvent.click(filterIcon.firstChild);
            const originLocIdElement = screen.getByTestId('originLocId');
            fireEvent.change(originLocIdElement, { target: { value: '1000' } });
            expect(screen.getByTestId('originCity').disabled).toBeTruthy();
            expect(screen.getByTestId('originProvince').disabled).toBeTruthy();
            expect(screen.getByTestId('originPostalCode').disabled).toBeTruthy();
            expect(screen.getByTestId('originCountry').disabled).toBeTruthy();
        });

        it('should disable all destination fields if location id is present', async () => {
            render(<TripManagementSummary />);
            const container = await screen.findByTestId('page-content-container');
            expect(container).toBeDefined();
            const filterIcon = screen.getByTestId('filter-icon');
            fireEvent.click(filterIcon.firstChild);
            const destinationLocIdElement = screen.getByTestId('destinationLocId');
            fireEvent.change(destinationLocIdElement, { target: { value: '1000' } });
            expect(screen.getByTestId('destinationCity').disabled).toBeTruthy();
            expect(screen.getByTestId('destinationProvince').disabled).toBeTruthy();
            expect(screen.getByTestId('destinationPostalCode').disabled).toBeTruthy();
            expect(screen.getByTestId('destinationCountry').disabled).toBeTruthy();
        });

        it('should disable location id if any of the other origin data is present', async () => {
            render(<TripManagementSummary />);
            const container = await screen.findByTestId('page-content-container');
            expect(container).toBeDefined();
            const filterIcon = screen.getByTestId('filter-icon');
            fireEvent.click(filterIcon.firstChild);
            const originLocIdElement = screen.getByTestId('originLocId');
            expect(originLocIdElement.disabled).toBeFalsy();
            fireEvent.change(screen.getByTestId('originPostalCode'), { target: { value: '1000' } });
            expect(originLocIdElement.disabled).toBeTruthy();
        });

        it('should disable location id if any of the other destination data is present', async () => {
            render(<TripManagementSummary />);
            const container = await screen.findByTestId('page-content-container');
            expect(container).toBeDefined();
            const filterIcon = screen.getByTestId('filter-icon');
            fireEvent.click(filterIcon.firstChild);
            const destinationLocIdElement = screen.getByTestId('destinationLocId');
            expect(destinationLocIdElement.disabled).toBeFalsy();
            fireEvent.change(screen.getByTestId('destinationPostalCode'), { target: { value: '1000' } });
            expect(destinationLocIdElement.disabled).toBeTruthy();
        });

        // TODO: Fix this test after MFE migration
        it.skip('should clear location id filters on clear all filters button click', async () => {
            render(<TripManagementSummary />);
            const container = await screen.findByTestId('page-content-container');
            expect(container).toBeDefined();
            const filterIcon = screen.getByTestId('filter-icon');
            fireEvent.click(filterIcon.firstChild);
            const originLocIdElement = screen.getByTestId('destinationLocId');
            fireEvent.change(originLocIdElement, { target: { value: '1000' } });
            const destinationLocIdElement = screen.getByTestId('destinationLocId');
            fireEvent.change(destinationLocIdElement, { target: { value: '1000' } });
            const clearAllFiltersBtn = screen.getByTestId('clearAllFilters');
            expect(clearAllFiltersBtn).toBeDefined();
            fireEvent.click(clearAllFiltersBtn);
            expect(originLocIdElement.value).toEqual('');
            expect(destinationLocIdElement.value).toEqual('');
        });

        it('should show chips for origin and destination location id filters', async () => {
            render(<TripManagementSummary />);
            const container = await screen.findByTestId('page-content-container');
            expect(container).toBeDefined();
            const filterIcon = screen.getByTestId('filter-icon');
            fireEvent.click(filterIcon.firstChild);
            const originLocIdElement = screen.getByTestId('originLocId');
            fireEvent.change(originLocIdElement, { target: { value: '1000' } });
            const destinationLocIdElement = screen.getByTestId('destinationLocId');
            fireEvent.change(destinationLocIdElement, { target: { value: '1000' } });
            const confirmBtn = screen.getByTestId('confirmBtn');
            expect(confirmBtn).toBeDefined();
            fireEvent.click(confirmBtn);
            expect(await screen.findByText('Origin Location ID : 1000')).toBeDefined();
            expect(await screen.findByText('Destination Location ID : 1000')).toBeDefined();
        });
        it('mark as delivered action in transit tab', async () => {
            render(<TripManagementSummary />);
            const dispatch = await screen.findByTestId('tabChild3');
            expect(dispatch).toBeDefined();
            fireEvent.click(dispatch);
            const container = await screen.findByTestId('page-content-container');
            expect(container).toBeDefined();

            // Select a load with unplanned status.
            const checkbox = await screen.findByTestId('dt-chkbx-3-50000678');
            expect(checkbox).toBeDefined();
            fireEvent.click(checkbox);

            // Click on dispatch a trip button.
            const dispatchButton = await screen.findByTestId('forceLoadToDelivered');
            expect(dispatchButton).toBeDefined();
            fireEvent.click(dispatchButton);

            // Successfull open the forceload to delivered modal
            const modal = await screen.findByTestId('ld-sc-ui--modal-content');
            expect(modal).toBeDefined();
        });
    });

    it('should auto carrier assign in processing tab', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableActionMenu: true,
            enableMultiLoadAssignment: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50000786'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50000857'));

        const loadAssignManuallyBtn = await screen.findByText('Assign manually');
        expect(loadAssignManuallyBtn).toBeDefined();
        fireEvent.click(loadAssignManuallyBtn);

        const enterCarrierInput = await screen.findByTestId('stride-select-carrier-input');
        expect(enterCarrierInput).toBeDefined();
        fireEvent.change(enterCarrierInput, { target: { value: 'Test' } });

        fireEvent.click(screen.getByText('Assign'));
        const msg = await screen.findByText('Work loads assigned successfully.');
        expect(msg).toBeDefined();
    });
    it('should show add comment component when add comment button is clicked', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableAddMultiComment: true,
            enableActionMenu: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50004376'));
        // fireEvent.click(await screen.findByTestId('dt-chkbx-1-50002027'));

        const addCommentButton = await screen.findByText('Add Comment');
        expect(addCommentButton).toBeDefined();
        fireEvent.click(addCommentButton);

        const commentsDrawer = await screen.findByTestId('comments-sidebar-drawer');
        expect(commentsDrawer).toBeDefined();

        // check the comments drawer is rendering correctly for single load
        expect(screen.getByText('Comments - Load 50004376')).toBeDefined();
        expect(screen.getByTestId('comment-filter-All')).toBeDefined();
        expect(screen.getByTestId('comment-filter-General')).toBeDefined();
        expect(screen.getByTestId('comment-filter-Carrier')).toBeDefined();
        expect(screen.getByTestId('comment-1-comment-container')).toBeDefined();
        expect(screen.getByText('test1')).toBeDefined();
        expect(screen.getByTestId('stride-select-comments')).toBeDefined();
        expect(screen.getByText('0 / 150')).toBeDefined();
        expect(screen.getByTestId('post-comment-button')).toBeDisabled();
    });

    it('should call add comment methods for single load', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableAddMultiComment: true,
            enableActionMenu: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50004376'));

        const addCommentButton = await screen.findByText('Add Comment');
        expect(addCommentButton).toBeDefined();
        fireEvent.click(addCommentButton);

        const commentsDrawer = await screen.findByTestId('comments-sidebar-drawer');
        expect(commentsDrawer).toBeDefined();

        expect(screen.getByText('Comments - Load 50004376')).toBeDefined();

        //add comment validation
        const commentInput = screen.getByTestId('comment-box-input');
        expect(commentInput).toBeDefined();
        fireEvent.change(commentInput, { target: { value: 'test123456' } });
        const postCommentButton = screen.getByTestId('post-comment-button');
        expect(postCommentButton).toBeDefined();
        fireEvent.click(postCommentButton);

        const newComment = await screen.findByText('test123456');
        expect(newComment).toBeDefined();
    });

    it('should show add comment component for multiple loads when add comment button is clicked', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableAddMultiComment: true,
            enableActionMenu: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50004376'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50002027'));

        const addCommentButton = await screen.findByText('Add Comment');
        expect(addCommentButton).toBeDefined();
        fireEvent.click(addCommentButton);

        const commentsDrawer = await screen.findByTestId('comments-sidebar-drawer');
        expect(commentsDrawer).toBeDefined();

        // check the comments drawer is rendering correctly for multi load
        expect(screen.getByText('Comments - Multiple plans')).toBeDefined();
        expect(screen.queryByTestId('comment-filter-All')).toBeDefined();
        expect(screen.queryByTestId('comment-filter-General')).toBeDefined();
        expect(screen.queryByTestId('comment-filter-Carrier')).toBeDefined();
        expect(screen.queryByTestId('comment-1-comment-container')).toBeDefined();
        expect(screen.queryByText('test1')).toBeDefined();
        expect(screen.getByTestId('stride-select-comments')).toBeDefined();
        expect(screen.getByText('0 / 150')).toBeDefined();
        expect(screen.getByTestId('post-comment-button')).toBeDisabled();
    });

    it('should display success message for multiple load', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableAddMultiComment: true,
            enableActionMenu: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50004376'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50002027'));

        const addCommentButton = await screen.findByText('Add Comment');
        expect(addCommentButton).toBeDefined();
        fireEvent.click(addCommentButton);

        const commentsDrawer = await screen.findByTestId('comments-sidebar-drawer');
        expect(commentsDrawer).toBeDefined();

        //add comment validation
        const commentInput = screen.getByTestId('comment-box-input');
        expect(commentInput).toBeDefined();
        fireEvent.change(commentInput, { target: { value: 'test123456' } });
        const postCommentButton = screen.getByTestId('post-comment-button');
        expect(postCommentButton).toBeDefined();
        fireEvent.click(postCommentButton);

        const successMessage = await screen.findByText('Load comment assigned successfully.');
        expect(successMessage).toBeDefined();
    });

    it('should display partial message for multiple load', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}addCommentToLoads/addCommentToLoads`, (req, res, ctx) =>
                res(ctx.json(addCommentToAllPartialMockResponse)),
            ),
        );
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableAddMultiComment: true,
            enableActionMenu: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50004376'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50002027'));

        const addCommentButton = await screen.findByText('Add Comment');
        expect(addCommentButton).toBeDefined();
        fireEvent.click(addCommentButton);

        const commentsDrawer = await screen.findByTestId('comments-sidebar-drawer');
        expect(commentsDrawer).toBeDefined();

        //add comment validation
        const commentInput = screen.getByTestId('comment-box-input');
        expect(commentInput).toBeDefined();
        fireEvent.change(commentInput, { target: { value: 'test123456' } });
        const postCommentButton = screen.getByTestId('post-comment-button');
        expect(postCommentButton).toBeDefined();
        fireEvent.click(postCommentButton);

        const partitalSuccessMessage = await screen.findByText('Failed to add comment to load(s): 50002027');
        expect(partitalSuccessMessage).toBeDefined();
    });
    it('should restrict special character if feature flag is enabled', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableAddMultiComment: true,
            enableActionMenu: true,
            enableCommentValidation: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50004376'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50002027'));

        const addCommentButton = await screen.findByText('Add Comment');
        expect(addCommentButton).toBeDefined();
        fireEvent.click(addCommentButton);

        const commentsDrawer = await screen.findByTestId('comments-sidebar-drawer');
        expect(commentsDrawer).toBeDefined();

        const commentInput = screen.getByTestId('comment-box-input');
        expect(commentInput).toBeDefined();
        fireEvent.change(commentInput, { target: { value: '<>' } });

        expect(screen.getByText('Asterisk, Greater than, less than, tilde, colon not allowed')).toBeDefined();
        expect(screen.getByTestId('post-comment-button')).toBeDisabled();
    });
    it('should not restrict special character if feature flag is disabled', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableAddMultiComment: true,
            enableActionMenu: true,
            enableCommentValidation: false,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50004376'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50002027'));

        const addCommentButton = await screen.findByText('Add Comment');
        expect(addCommentButton).toBeDefined();
        fireEvent.click(addCommentButton);

        const commentsDrawer = await screen.findByTestId('comments-sidebar-drawer');
        expect(commentsDrawer).toBeDefined();

        const commentInput = screen.getByTestId('comment-box-input');
        expect(commentInput).toBeDefined();
        fireEvent.change(commentInput, { target: { value: '<>' } });

        expect(screen.queryByText('Asterisk, Greater than, less than, tilde, colon not allowed')).toBeNull();
        expect(screen.getByTestId('post-comment-button')).not.toBeDisabled();
    });
    it('should show auto carrier assign error in processing tab', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableActionMenu: true,
            enableMultiLoadAssignment: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))),
            rest.post(`${API_GATEWAY_PREFIX_NEW}assignCarrier/assignCarrier`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(erroreMock)),
            ),
        );

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50000786'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-1-50000857'));

        const loadAssignManuallyBtn = await screen.findByText('Assign manually');
        expect(loadAssignManuallyBtn).toBeDefined();
        fireEvent.click(loadAssignManuallyBtn);

        const enterCarrierInput = await screen.findByTestId('stride-select-carrier-input');
        expect(enterCarrierInput).toBeDefined();
        fireEvent.change(enterCarrierInput, { target: { value: 'Test' } });

        fireEvent.click(screen.getByText('Assign'));
        const msg = await screen.findByText('Failed to assign carrier. View loads to verify');
        expect(msg).toBeDefined();
    });
    it('should auto withdraw tender in the in_transit tab', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableActionMenu: true,
            enableMultiWithdrawTender: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('In transit'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-3-500002241'));

        const withDrawTenderButton = screen.getByText('Withdraw tender');
        expect(withDrawTenderButton).toBeDefined();
        fireEvent.click(withDrawTenderButton);

        const msg = await screen.findByText('Tender withdrawn successfully');
        expect(msg).toBeDefined();
    });
    it('should show auto withdraw tender error message in the in_transit tab', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableActionMenu: true,
            enableMultiWithdrawTender: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))),
            rest.post(`${API_GATEWAY_PREFIX_NEW}withdrawTender/withdrawTender`, (req, res, ctx) =>
                res(ctx.status(400)),
            ),
        );

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('In transit'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-3-500002241'));

        const withDrawTenderButton = screen.getByText('Withdraw tender');
        expect(withDrawTenderButton).toBeDefined();
        fireEvent.click(withDrawTenderButton);

        const msg = await screen.findByText('Failed to cancel tender. View loads to verify');
        expect(msg).toBeDefined();
    });
    it('should cancel load in planning tab', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableActionMenu: true,
            enableMultiLoadCancel: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))));

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Planning'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-0-50000678'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-0-50004376'));

        const cancelBtn = screen.getByText('Cancel');
        expect(cancelBtn).toBeDefined();
        fireEvent.click(cancelBtn);

        expect(screen.getByText('Are you sure you want to cancel the load')).toBeDefined();

        const inputReason = screen.getByTestId('input-reason');
        expect(inputReason).toBeDefined();
        fireEvent.click(inputReason);

        fireEvent.click(screen.getByTestId('single-select-simple-option-DC'));
        const confirmBtn = screen.getByTestId('actionBtn');
        expect(confirmBtn).not.toBeDisabled();

        fireEvent.click(confirmBtn);

        const msg = await screen.findByText('Work loads canceled successfully.');
        expect(msg).toBeDefined();
    });
    it('should cancel load error message in planning tab', async () => {
        const updatedCMS = getUpdatedCMSConfig(CmsConfig, {
            enableActionMenu: true,
            enableMultiLoadCancel: true,
        });

        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);

        server.use(
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCMS))),
            rest.post(`${API_GATEWAY_PREFIX_NEW}cancelLoadMulti/cancelLoadMulti`, (req, res, ctx) =>
                res(ctx.status(500)),
            ),
        );

        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Planning'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-0-50000678'));
        fireEvent.click(await screen.findByTestId('dt-chkbx-0-50004376'));

        const cancelBtn = screen.getByText('Cancel');
        expect(cancelBtn).toBeDefined();
        fireEvent.click(cancelBtn);

        expect(screen.getByText('Are you sure you want to cancel the load')).toBeDefined();

        const inputReason = screen.getByTestId('input-reason');
        expect(inputReason).toBeDefined();
        fireEvent.click(inputReason);

        fireEvent.click(screen.getByTestId('single-select-simple-option-DC'));
        const confirmBtn = screen.getByTestId('actionBtn');
        expect(confirmBtn).not.toBeDisabled();

        fireEvent.click(confirmBtn);

        const msg = await screen.findByText('Work load cancelation failed. View loads to verify');
        expect(msg).toBeDefined();
    });
});

describe('Timezone testing block', () => {
    const contextMockGT = { ...contextMock, currentMarket: 'gt' };
    beforeEach(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockGT);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'CAM_GT') {
                    return res(ctx.json(MdmLtmStaticDataGT));
                }
                return res(ctx.json(MdmLtmStaticData));
            }),
        );
    });

    it('should return short time abbreviation if shorttimezone is set', async () => {
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(CmsConfig))));
        server.listen();
        render(<TripManagementSummary />);
        expect(await screen.findAllByText('25 Feb, 2022, 09:30 pm (CT)')).toBeDefined();
    });
    it('should return short time abbreviation if shorttimezone is reset', () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"enableShortTimezone": false,"displayPhaseStatusCount":false, "viewMoreRecords": true}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        server.listen();
        render(<TripManagementSummary />);
        expect(screen.queryByText('(CT)')).toBeNull();
    });
});

describe('Testing phase count', () => {
    contextMock.currentMarket = 'gt';
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMock);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
        rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
            const { tenantId } = req.body.additionalHeaders;
            if (tenantId === 'CAM_GT') {
                return res(ctx.json(MdmLtmStaticDataGT));
            }
            return res(ctx.json(MdmLtmStaticData));
        });
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags: '{"dev.tripManagement.configs":{"displayPhaseStatusCount": true}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'CAM_GT') {
                    return res(ctx.json(PlanSearchAggregates));
                }
            }),
        );
        server.listen();
    });

    it('should show total count', async () => {
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('tabChild0');
        expect(container).toBeDefined();
        const planCount = screen.queryByText('30');
        const processCount = screen.queryByText('24');
        expect(planCount).toBeDefined();
        expect(processCount).toBeDefined();
    });

    it('should not show total count', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags: '{"dev.tripManagement.configs":{"displayPhaseStatusCount": false}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        server.listen();
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('tabChild0');
        expect(container).toBeDefined();
        const noPhaseCount = screen.getAllByText('--');
        expect(noPhaseCount.length).toBeGreaterThan(0);
    });
});

describe('Testing phase count for CL', () => {
    const contextMockCL = { ...contextMock, currentMarket: 'cl' };
    beforeEach(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCL);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'CL') {
                    return res(ctx.json(MdmLtmStaticDataGT));
                }
                return res(ctx.json(MdmLtmStaticDataGT));
            }),
        );
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
                const { tenantId } = req.body.additionalHeaders;
                if (tenantId === 'CL') {
                    return res(ctx.json(PlanSearchAggregates));
                }
            }),
        );
    });

    it('should show total count when displayPhaseStatusCount is set', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"enableShortTimezone": false,"displayPhaseStatusCount":true, "viewMoreRecords": true}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        render(<TripManagementSummary />);
        await waitFor(() => {
            const container = screen.getByTestId('tabChild0');
            expect(container).toBeDefined();
        });
        const planCount = await screen.findByText('30');
        const processCount = screen.queryByText('24');
        expect(planCount).toBeDefined();
        expect(processCount).toBeDefined();
    });

    it('should not show total count when displayPhaseStatusCount is reset', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags: '{"dev.tripManagement.configs":{"displayPhaseStatusCount": false}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        const wrapper = render(<TripManagementSummary />);
        await waitFor(() => {
            const container = wrapper.getByTestId('tabChild0');
            expect(container).toBeDefined();
        });
        const noPhaseCount = screen.getAllByText('--');
        expect(noPhaseCount.length).toBeGreaterThan(0);
    });
});

describe('Autopopulate carrier in trip summary - Processing tab', () => {
    const contextMockCL = { ...contextMock, currentMarket: 'cl' };
    beforeEach(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCL);
        TripSharedService.setPageLoadSettings({ showCLColumns: true });
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"displayPhaseStatusCount": true, "autoSelectCarrierInWorkLoadAssgnmt": true}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
    });
    it('should auto populate carrier details if autoSelectCarrierInWorkLoadAssgnmt is true', async () => {
        TripSharedService.setFeatureFlags({ autoSelectCarrierInWorkLoadAssgnmt: true });
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        // Select a trip with needs attention status.
        const checkbox = await screen.findByTestId('dt-chkbx-1-30065983');
        fireEvent.click(checkbox);

        // Click on assign manually button.
        const assignManualBtn = await screen.findByTestId('assignManually');
        expect(assignManualBtn).toBeDefined();
        fireEvent.click(assignManualBtn);

        fireEvent.click(screen.getByText('ANY'));

        const inputElement = screen.getByText('ANY');
        expect(inputElement).toBeDefined();
    });

    it('should not auto populate carrier details if autoSelectCarrierInWorkLoadAssgnmt is false ', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"displayPhaseStatusCount": true, "autoSelectCarrierInWorkLoadAssgnmt": false}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        server.listen();
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        // wait till table is populated with some data
        const planTableBody = await screen.findByTestId('plan-table-body');
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        fireEvent.click(screen.getByText('Processing'));

        // Select a trip with needs attention status.
        const checkbox = await screen.findByTestId('dt-chkbx-1-30065983');
        fireEvent.click(checkbox);

        // Click on assign manually button.
        const assignManualBtn = await screen.findByTestId('assignManually');
        expect(assignManualBtn).toBeDefined();
        fireEvent.click(assignManualBtn);

        const inputElement = screen.getByText('Carrier');
        expect(inputElement).toBeDefined();
    });
});

describe('Charge location validation on trip dispatch', () => {
    beforeEach(() => {
        TripSharedService.setPageLoadSettings({ showCLColumns: true });
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags: '{"dev.tripManagement.configs":{"validateChargeLocationOnTripDispatch": true}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
    });
    it('should not be able to dispatch trips if loads have no charge location added if the flag is on', async () => {
        render(<TripManagementSummary />);
        const dispatch = await screen.findByTestId('tabChild2');
        expect(dispatch).toBeDefined();
        fireEvent.click(dispatch);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const checkbox = await screen.findByTestId('dt-chkbx-2-30000754');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const dispatchButton = await screen.findByTestId('dispatch');
        expect(dispatchButton).toBeDefined();
        fireEvent.click(dispatchButton);

        const errorMsg = await screen.findByTestId('ld-sc-ui-alert-text-only');
        expect(errorMsg.textContent).toEqual('30000754: Charge Location is missing for Load(s)  - 50001754');
    });

    it('should be able to dispatch  trips if loads have charge location if the flag is on', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planLTPreview/planLTPreview`, (req, res, ctx) =>
                res(ctx.json(tripResponseWithChargeLocations)),
            ),
        );

        render(<TripManagementSummary />);
        const dispatch = await screen.findByTestId('tabChild2');
        expect(dispatch).toBeDefined();
        fireEvent.click(dispatch);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const checkbox = await screen.findByTestId('dt-chkbx-2-30000754');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const dispatchButton = await screen.findByTestId('dispatch');
        expect(dispatchButton).toBeDefined();
        fireEvent.click(dispatchButton);

        const msg = await screen.findByText('Trip plan 30000754 dispatched successfully');
        expect(msg).toBeDefined();
        const subMsg = await screen.findByText('Dispatch documents will be downloaded automatically');
        expect(subMsg).toBeDefined();
    });

    it('should be able to dispatch selected trips if the flag is off', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags: '{"dev.tripManagement.configs":{"validateChargeLocationOnTripDispatch": false}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        render(<TripManagementSummary />);
        const dispatch = await screen.findByTestId('tabChild2');
        expect(dispatch).toBeDefined();
        fireEvent.click(dispatch);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const checkbox = await screen.findByTestId('dt-chkbx-2-30000754');
        expect(checkbox).toBeDefined();
        fireEvent.click(checkbox);

        const dispatchButton = await screen.findByTestId('dispatch');
        expect(dispatchButton).toBeDefined();
        fireEvent.click(dispatchButton);

        const msg = await screen.findByText('Trip plan 30000754 dispatched successfully');
        expect(msg).toBeDefined();
        const subMsg = await screen.findByText('Dispatch documents will be downloaded automatically');
        expect(subMsg).toBeDefined();
    });
});

describe('S2S,Region changes in transportation management preview', () => {
    const contextMockCL = { ...contextMock, currentMarket: 'cl' };
    beforeEach(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockCL);
        TripSharedService.setPageLoadSettings({ showCLColumns: true });
        TripSharedService.setFeatureFlags(null);
        TripSharedService.setConfig(null);
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"displayPhaseStatusCount": true, "showRegionAndMerchandiseDetails": true, "showLocationName": true}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
    });

    it('should display merchandize type ,location name(origin/destination) and region details in trip management summary if the flag is on', async () => {
        const wrapper = render(<TripManagementSummary />);
        await waitFor(() => {
            const merchandiseType = wrapper.getByTestId('plan-table-header-merchandiseType');
            expect(merchandiseType).toBeDefined();
            const originRegion = wrapper.getAllByTestId('originRegion-0-30064496');
            // TODO: Fix this test after MFE migration
            // eslint-disable-next-line testing-library/no-wait-for-multiple-assertions
            expect(originRegion).toBeDefined();
            const destinationRegion = wrapper.getAllByTestId('destinationRegion-0-30064496');
            // eslint-disable-next-line testing-library/no-wait-for-multiple-assertions
            expect(destinationRegion).toBeDefined();
            // eslint-disable-next-line testing-library/no-wait-for-multiple-assertions, testing-library/await-async-queries
            expect(screen.findByText('EKONO DC')).toBeDefined();
            // eslint-disable-next-line testing-library/no-wait-for-multiple-assertions, testing-library/await-async-queries
            expect(screen.findByText('BA MOSTAZAL')).toBeDefined();
        });
    });

    it('should not display merchandize type , region details and location name in trip management summary if the flag is off', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"displayPhaseStatusCount":true, "showRegionAndMerchandiseDetails": false, "showLocationName": false}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        server.listen();
        const wrapper = render(<TripManagementSummary />);
        await waitFor(() => {
            const merchandiseType = wrapper.queryByTestId('plan-table-header-merchandiseType');
            expect(merchandiseType).toBeNull();
        });
        const originRegion = wrapper.queryByTestId('originRegion-0-30064496');
        expect(originRegion).toBeNull();
        const destinationRegion = wrapper.queryByTestId('destinationRegion-0-30064496');
        expect(destinationRegion).toBeNull();
        expect(screen.queryByText('EKONO DC')).toBeNull();
        expect(screen.queryByText('BA MOSTAZAL')).toBeNull();
    });
});
