import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ResizeObserver from 'resize-observer-polyfill';

import { render, screen, fireEvent, waitFor } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

import { planSearchAggregatesProcessing } from './mocks/PlanLTPreview.mock';
import { userRlInfoMock } from './mocks/TripManagementSummary.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import PlanSearchAggregatesCA from './mocks/PlanSearchAggregatesCA.mock.json';
import PlanSearchAggregates from './mocks/PlanSearchAggregates.mock.json';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';

import TripManagementSummary from '../TripManagementSummary';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'CA_CA') {
            return res(ctx.json(PlanSearchAggregatesCA));
        }
        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }
        if (tenantId === 'CL' || tenantId === 'CAM_GT') {
            return res(ctx.json(PlanSearchAggregates));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(CmsConfigUS));
        }
        return res(ctx.json(CmsConfig));
    }),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

// TOOD: @anirudh return proper value
const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const getBoundingClientRectSpy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    getBoundingClientRectSpy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

beforeEach(() => {
    // jest.useFakeTimers('');
});

afterEach(() => {
    server.resetHandlers();
});

const invokeBulkUpdateMock = jest.fn();

const contextMockUS = {
    ...contextMock,
    currentMarket: 'us',
    invokeBulkUpdate: invokeBulkUpdateMock,
};

const spy = jest.spyOn(AppUtils, 'get');
spy.mockImplementation(() => contextMockUS);

afterAll(() => server.close());

describe('Print Status', () => {
    it('Should select one trip from checkboxes and verify mark printed button available and clickable', async () => {
        invokeBulkUpdateMock.mockImplementation(() => Promise.resolve({ status: 200 }));

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);

        const printAction = await screen.findAllByTestId('MARK_UNMARK_PRINTED');
        expect(printAction[0]).toBeDefined();
        fireEvent.click(printAction[0]);
        const successMsg = await screen.findByText(
            '1 plan(s) submitted for print tag update. Click on Processing tab to view latest changes',
        );
        expect(successMsg).toBeDefined();
    });
    it('Should select multiple trips from checkboxes and verify mark printed button available and clickable', async () => {
        invokeBulkUpdateMock.mockImplementation(() => Promise.resolve({ status: 200 }));

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);

        const checkboxtwo = await screen.findByTestId(getCheckboxTestId('500004195'));
        fireEvent.click(checkboxtwo);

        const printAction = await screen.findAllByTestId('MARK_UNMARK_PRINTED');
        expect(printAction[0]).toBeDefined();
        fireEvent.click(printAction[0]);
        const successMsg = await screen.findByText(
            '2 plan(s) submitted for print tag update. Click on Processing tab to view latest changes',
        );
        expect(successMsg).toBeDefined();
    });
    it('Should test the error for print action', async () => {
        invokeBulkUpdateMock.mockImplementation(() =>
            Promise.reject(new Error("Couldn't process the request. Try again.")),
        );

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);
        const printAction = await screen.findAllByTestId('MARK_UNMARK_PRINTED');
        expect(printAction[0]).toBeDefined();
        fireEvent.click(printAction[0]);
        const errorMessage = await screen.findByText(`Couldn't process the request. Try again`);
        expect(errorMessage).toBeDefined();
    });
});
