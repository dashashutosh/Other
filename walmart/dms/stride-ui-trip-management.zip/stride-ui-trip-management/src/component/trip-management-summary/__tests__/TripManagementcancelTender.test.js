import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ResizeObserver from 'resize-observer-polyfill';

import { AppUtils } from '@gscope-mfe/app-bridge';
import { render, screen, fireEvent, waitFor, within } from '../../../utils/test-utils';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import { userRlInfoMock } from './mocks/TripManagementSummary.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import PlanSearchAggregatesCA from './mocks/PlanSearchAggregatesCA.mock.json';
import PlanSearchAggregates from './mocks/PlanSearchAggregates.mock.json';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';
import CancelTenderMock from './mocks/CancelTender.mock.json';
import TripManagementSummary from '../TripManagementSummary';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import TripSharedService from '../../../service/TripSharedService';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'CA_CA') {
            return res(ctx.json(PlanSearchAggregatesCA));
        }
        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }
        if (tenantId === 'CL' || tenantId === 'CAM_GT') {
            return res(ctx.json(PlanSearchAggregates));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(CmsConfigUS));
        }
        return res(ctx.json(CmsConfig));
    }),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

// TOOD: @anirudh return proper value
const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const spy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    spy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

beforeEach(() => {
    // jest.useFakeTimers('');
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Cancel Tender', () => {
    const useAppContext = jest.spyOn(AppUtils, 'get');
    beforeAll(() => {
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
    });

    it('Should test the Cancel tender button from actions', async () => {
        const contextMockUS = {
            ...contextMock,
            currentMarket: 'us',
            invokeBulkUpdate: jest.fn(() => Promise.resolve('response')),
        };
        useAppContext.mockImplementation(() => contextMockUS);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(CancelTenderMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const tab = await screen.findByText('Ready to start');
        expect(tab).toBeDefined();
        fireEvent.click(tab);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const cancelTenderOption = await screen.findAllByText('Cancel Tender');
        fireEvent.click(cancelTenderOption[0]);
        const successMessagge = await screen.findByText('Cancel tender successfully. Changes will reflect soon.');
        expect(successMessagge).toBeDefined();
    });

    it('Should test the Cancel tender button from actions and API return error', async () => {
        const contextMockUS = {
            ...contextMock,
            currentMarket: 'us',
            invokeBulkUpdate: jest.fn(() => Promise.reject(new Error("Couldn't process the request. Try again."))),
        };
        useAppContext.mockImplementation(() => contextMockUS);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(CancelTenderMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const tab = await screen.findByText('Ready to start');
        expect(tab).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const cancelTenderOption = await screen.findAllByText('Cancel Tender');
        fireEvent.click(cancelTenderOption[0]);
        const errorMessage = await screen.findByText("Couldn't process the request. Try again");
        expect(errorMessage).toBeDefined();
    });

    it('Should test the Cancel tender button when check the check box', async () => {
        const contextMockUS = {
            ...contextMock,
            currentMarket: 'us',
            invokeBulkUpdate: jest.fn(() => Promise.resolve('response')),
        };
        useAppContext.mockImplementation(() => contextMockUS);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(CancelTenderMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const tab = await screen.findByText('Ready to start');
        expect(tab).toBeDefined();
        fireEvent.click(tab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('100218102'));
        fireEvent.click(checkbox);
        const cancelTenderOption = await screen.findByTestId('CANCEL_TENDER');
        fireEvent.click(cancelTenderOption);
        const successMessagge = await screen.findByText('Cancel tender successfully. Changes will reflect soon.');
        expect(successMessagge).toBeDefined();
    });

    it('Should test the Cancel tender button when check the check box and API return Error', async () => {
        const contextMockUS = {
            ...contextMock,
            currentMarket: 'us',
            invokeBulkUpdate: jest.fn(() => Promise.reject(new Error("Couldn't process the request. Try again."))),
        };
        useAppContext.mockImplementation(() => contextMockUS);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(CancelTenderMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const tab = await screen.findByText('Ready to start');
        expect(tab).toBeDefined();
        fireEvent.click(tab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkbox = await screen.findByTestId(getCheckboxTestId('100218102'));
        fireEvent.click(checkbox);
        const cancelTenderOption = await screen.findByTestId('CANCEL_TENDER');
        fireEvent.click(cancelTenderOption);
        const errorMessage = await screen.findByText("Couldn't process the request. Try again");
        expect(errorMessage).toBeDefined();
    });

    it('Should test the Cancel tender button when check multiple check box', async () => {
        const contextMockUS = {
            ...contextMock,
            currentMarket: 'us',
            invokeBulkUpdate: jest.fn(() => Promise.resolve('response')),
        };
        useAppContext.mockImplementation(() => contextMockUS);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(CancelTenderMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const tab = await screen.findByText('Ready to start');
        expect(tab).toBeDefined();
        fireEvent.click(tab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkbox = await screen.findByTestId(getCheckboxTestId('100218102'));
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('100257861'));
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('100664105'));
        fireEvent.click(checkbox);
        fireEvent.click(checkbox1);
        fireEvent.click(checkbox2);
        const cancelTenderOption = await screen.findByTestId('CANCEL_TENDER');
        fireEvent.click(cancelTenderOption);
        const successMessagge = await screen.findByText('Cancel tender successfully. Changes will reflect soon.');
        expect(successMessagge).toBeDefined();
    });

    it('Should test the Cancel tender when check multiple check box and API return error', async () => {
        const contextMockUS = {
            ...contextMock,
            currentMarket: 'us',
            invokeBulkUpdate: jest.fn(() => Promise.reject(new Error("Couldn't process the request. Try again."))),
        };
        useAppContext.mockImplementation(() => contextMockUS);
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(CancelTenderMock)),
            ),
        );
        const wrapper = render(<TripManagementSummary />);
        const container = await wrapper.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const tab = await screen.findByText('Ready to start');
        expect(tab).toBeDefined();
        fireEvent.click(tab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('100218102'));
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('100257861'));
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('100664105'));
        fireEvent.click(checkbox);
        fireEvent.click(checkbox1);
        fireEvent.click(checkbox2);

        const cancelTenderOption = await screen.findByTestId('CANCEL_TENDER');
        fireEvent.click(cancelTenderOption);
        const errorMessage = await screen.findByText("Couldn't process the request. Try again");
        expect(errorMessage).toBeDefined();
    });
});
