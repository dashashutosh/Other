import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { render, screen, fireEvent, waitFor, waitForElementToBeRemoved } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import ResizeObserver from 'resize-observer-polyfill';

import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

import { planSearchAggregatesProcessing } from './mocks/PlanLTPreview.mock';
import { userRlInfoMock } from './mocks/TripManagementSummary.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import PlanSearchAggregatesCA from './mocks/PlanSearchAggregatesCA.mock.json';
import PlanSearchAggregates from './mocks/PlanSearchAggregates.mock.json';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';

import TripManagementSummary from '../TripManagementSummary';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import {
    editTrailerIdsSuccessMock,
    editTrailerIdsPartialSuccessMock,
    updateTrackingPlanErrorMock,
    losData,
    tripDetailsResponseMockReadyToStartTnt,
    planAggRes,
} from './mocks/TripUpdateTimeline.mock';
import { getUpdatedCMSConfig } from '../../../utils/test-helpers';
import TripSharedService from '../../../service/TripSharedService';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const configUpdated = getUpdatedCMSConfig(CmsConfigUS, { enableTrailerIdEdit: true, enableOdometerEdit: true });

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'CA_CA') {
            return res(ctx.json(PlanSearchAggregatesCA));
        }
        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }
        if (tenantId === 'CL' || tenantId === 'CAM_GT') {
            return res(ctx.json(PlanSearchAggregates));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(configUpdated));
        }
        return res(ctx.json(CmsConfig));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}getTripDetails/tripDetails`, (req, res, ctx) =>
        res(ctx.json(tripDetailsResponseMockReadyToStartTnt)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}fetchStaticData/fetchStaticData`, (req, res, ctx) => res(ctx.json(losData))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}editTrailerIds/editTrailerIds`, (req, res, ctx) =>
        res(ctx.json(editTrailerIdsSuccessMock)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}updateTrackingPlan/updateTrackingPlan`, (req, res, ctx) => res(ctx.json(true))),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

// TOOD: @anirudh return proper value
const userPreferencesMock = JSON.stringify({});

// jest.mock('../../../../../../contextComponent');
const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const getBoundingClientRectSpy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    getBoundingClientRectSpy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW

    const contextMockUS = {
        ...contextMock,
        currentMarket: 'us',
        invokeBulkUpdate: jest.fn(() => Promise.resolve({ status: 200 })),
    };
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMockUS);
});

beforeEach(() => {
    // jest.useFakeTimers('');
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Update timeline tests', () => {
    it('Should display timeline action in processing phase', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);
        const updateTimelineAction = await screen.findByTestId('UPDATE_TIMELINE_TRIP');
        expect(updateTimelineAction).toBeDefined();
        fireEvent.click(updateTimelineAction);
        const updateTimeline = await screen.findAllByText('Update timeline');
        expect(updateTimeline).toHaveLength(4);
    });
    it('Update trailer information - success', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planAggRes)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const readyToStartTab = screen.getByText('Ready to start');
        fireEvent.click(readyToStartTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500006700'));
        fireEvent.click(checkboxOne);
        const updateTimelineAction = await screen.findByTestId('UPDATE_TIMELINE_TRIP');
        expect(updateTimelineAction).toBeDefined();
        fireEvent.click(updateTimelineAction);
        const updateTimeline = await screen.findAllByText('Update timeline');
        expect(updateTimeline).toHaveLength(3);
        expect(await screen.findByText('Load - 100154700')).toBeDefined();
        expect(await screen.findByText('Trailer ID')).toBeDefined();
        const trailerId = await screen.findByTestId('trailerId');
        expect(trailerId).toBeDefined();
        fireEvent.change(trailerId, { target: { value: '890' } });
        const confirmBtn = await screen.findByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        expect(confirmBtn.disabled).toBeFalsy();
        fireEvent.click(confirmBtn);
        const successMsg = await screen.findByText('Trip timeline successfully updated. Changes will reflect soon.');
        expect(successMsg).toBeDefined();
    });
    it('Update trailer information - error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planAggRes)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}editTrailerIds/editTrailerIds`, (req, res, ctx) =>
                res(ctx.json(editTrailerIdsPartialSuccessMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const readyToStartTab = screen.getByText('Ready to start');
        fireEvent.click(readyToStartTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500006700'));
        fireEvent.click(checkboxOne);
        const updateTimelineAction = await screen.findByTestId('UPDATE_TIMELINE_TRIP');
        expect(updateTimelineAction).toBeDefined();
        fireEvent.click(updateTimelineAction);
        const updateTimeline = await screen.findAllByText('Update timeline');
        expect(updateTimeline).toHaveLength(3);
        expect(await screen.findByText('Load - 100154700')).toBeDefined();
        expect(await screen.findByText('Trailer ID')).toBeDefined();
        const trailerId = await screen.findByTestId('trailerId');
        expect(trailerId).toBeDefined();
        fireEvent.change(trailerId, { target: { value: '890' } });
        const confirmBtn = await screen.findByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        expect(confirmBtn.disabled).toBeFalsy();
        fireEvent.click(confirmBtn);
        expect(await screen.findByText('Failed to update Trailer ID for 100154700')).toBeDefined();
        expect(confirmBtn.disabled).toBeTruthy();
    });

    it('Update timeline information - success', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planAggRes)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const readyToStartTab = screen.getByText('Ready to start');
        fireEvent.click(readyToStartTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500006700'));
        fireEvent.click(checkboxOne);
        const updateTimelineAction = await screen.findByTestId('UPDATE_TIMELINE_TRIP');
        expect(updateTimelineAction).toBeDefined();
        fireEvent.click(updateTimelineAction);
        const updateTimeline = await screen.findAllByText('Update timeline');
        expect(updateTimeline).toHaveLength(3);
        expect(await screen.findByText('Load - 100154700')).toBeDefined();

        const calendarInputs = screen.queryAllByTestId('ld-sc-ui-text-input');
        expect(calendarInputs[0]).toBeDefined();
        expect(calendarInputs[1]).toBeDefined();

        fireEvent.click(calendarInputs[0]);
        fireEvent.click(screen.getByText('13'));
        fireEvent.click(screen.getByText('Apply'));

        const confirmBtn = await screen.findByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        expect(confirmBtn.disabled).toBeFalsy();
        fireEvent.click(confirmBtn);
        const successMsg = await screen.findByText('Trip timeline successfully updated. Changes will reflect soon.');
        expect(successMsg).toBeDefined();
    });

    it('Update timeline information - success when useStopSequenceV2MapperForTripDetails is true', async () => {
        const updatedCmsConfig = getUpdatedCMSConfig(configUpdated, {
            useStopSequenceV2MapperForTripDetails: true,
        });
        TripSharedService.setConfig(null);

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planAggRes)),
            ),
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(updatedCmsConfig))),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const readyToStartTab = screen.getByText('Ready to start');
        fireEvent.click(readyToStartTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500006700'));
        fireEvent.click(checkboxOne);
        const updateTimelineAction = await screen.findByTestId('UPDATE_TIMELINE_TRIP');
        expect(updateTimelineAction).toBeDefined();
        fireEvent.click(updateTimelineAction);
        const updateTimeline = await screen.findAllByText('Update timeline');
        expect(updateTimeline).toHaveLength(3);
        expect(await screen.findByText('Load - 100154700')).toBeDefined();

        const calendarInputs = screen.queryAllByTestId('ld-sc-ui-text-input');
        expect(calendarInputs[0]).toBeDefined();
        expect(calendarInputs[1]).toBeDefined();

        fireEvent.click(calendarInputs[0]);
        fireEvent.click(screen.getByText('13'));
        fireEvent.click(screen.getByText('Apply'));

        const confirmBtn = await screen.findByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        expect(confirmBtn.disabled).toBeFalsy();
        fireEvent.click(confirmBtn);
        const successMsg = await screen.findByText('Trip timeline successfully updated. Changes will reflect soon.');
        expect(successMsg).toBeDefined();
    });

    it('Update timeline information - error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planAggRes)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}updateTrackingPlan/updateTrackingPlan`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(updateTrackingPlanErrorMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const readyToStartTab = screen.getByText('Ready to start');
        fireEvent.click(readyToStartTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500006700'));
        fireEvent.click(checkboxOne);
        const updateTimelineAction = await screen.findByTestId('UPDATE_TIMELINE_TRIP');
        expect(updateTimelineAction).toBeDefined();
        fireEvent.click(updateTimelineAction);
        const updateTimeline = await screen.findAllByText('Update timeline');
        expect(updateTimeline).toHaveLength(3);
        expect(await screen.findByText('Load - 100154700')).toBeDefined();
        const calendarInputs = screen.queryAllByTestId('ld-sc-ui-text-input');
        expect(calendarInputs[0]).toBeDefined();
        expect(calendarInputs[1]).toBeDefined();

        fireEvent.click(calendarInputs[0]);
        fireEvent.click(screen.getByText('13'));
        fireEvent.click(screen.getByText('Apply'));

        const confirmBtn = await screen.findByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        expect(confirmBtn.disabled).toBeFalsy();
        fireEvent.click(confirmBtn);
        expect(
            await screen.findByText(
                'Failed to update stop timeline information. Provided tracking ids 12345 not present',
            ),
        ).toBeDefined();
        expect(confirmBtn.disabled).toBeTruthy();
    });
    it('Update timeline and trailer information - success', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planAggRes)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const readyToStartTab = screen.getByText('Ready to start');
        fireEvent.click(readyToStartTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500006700'));
        fireEvent.click(checkboxOne);
        const updateTimelineAction = await screen.findByTestId('UPDATE_TIMELINE_TRIP');
        expect(updateTimelineAction).toBeDefined();
        fireEvent.click(updateTimelineAction);
        const updateTimeline = await screen.findAllByText('Update timeline');
        expect(updateTimeline).toHaveLength(3);
        expect(await screen.findByText('Load - 100154700')).toBeDefined();
        expect(await screen.findByText('Trailer ID')).toBeDefined();
        const trailerId = await screen.findByTestId('trailerId');
        expect(trailerId).toBeDefined();
        fireEvent.change(trailerId, { target: { value: '890' } });

        const calendarInputs = screen.queryAllByTestId('ld-sc-ui-text-input');
        expect(calendarInputs[0]).toBeDefined();
        expect(calendarInputs[1]).toBeDefined();

        fireEvent.click(calendarInputs[0]);
        fireEvent.click(screen.getByText('13'));
        fireEvent.click(screen.getByText('Apply'));

        const confirmBtn = await screen.findByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        expect(confirmBtn.disabled).toBeFalsy();
        fireEvent.click(confirmBtn);
        const successMsg = await screen.findByText('Trip timeline successfully updated. Changes will reflect soon.');
        expect(successMsg).toBeDefined();
    });
    it('Update timeline and trailer information - error', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planAggRes)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}editTrailerIds/editTrailerIds`, (req, res, ctx) =>
                res(ctx.json(editTrailerIdsPartialSuccessMock)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}updateTrackingPlan/updateTrackingPlan`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(updateTrackingPlanErrorMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const readyToStartTab = screen.getByText('Ready to start');
        fireEvent.click(readyToStartTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500006700'));
        fireEvent.click(checkboxOne);
        const updateTimelineAction = await screen.findByTestId('UPDATE_TIMELINE_TRIP');
        expect(updateTimelineAction).toBeDefined();
        fireEvent.click(updateTimelineAction);
        const updateTimeline = await screen.findAllByText('Update timeline');
        expect(updateTimeline).toHaveLength(3);
        expect(await screen.findByText('Load - 100154700')).toBeDefined();
        expect(await screen.findByText('Trailer ID')).toBeDefined();
        const trailerId = await screen.findByTestId('trailerId');
        expect(trailerId).toBeDefined();
        fireEvent.change(trailerId, { target: { value: '890' } });

        const calendarInputs = screen.queryAllByTestId('ld-sc-ui-text-input');
        expect(calendarInputs[0]).toBeDefined();
        expect(calendarInputs[1]).toBeDefined();

        fireEvent.click(calendarInputs[0]);
        fireEvent.click(screen.getByText('13'));
        fireEvent.click(screen.getByText('Apply'));

        const confirmBtn = await screen.findByTestId('confirmBtn');
        expect(confirmBtn).toBeDefined();
        expect(confirmBtn.disabled).toBeFalsy();
        fireEvent.click(confirmBtn);
        const inlineAlert = await screen.findAllByTestId('inline-alert');
        expect(inlineAlert.length).toEqual(1);
        expect(confirmBtn.disabled).toBeTruthy();
    });
});
