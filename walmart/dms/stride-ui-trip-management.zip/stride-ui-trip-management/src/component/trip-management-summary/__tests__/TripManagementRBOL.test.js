import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ResizeObserver from 'resize-observer-polyfill';

import { render, screen, fireEvent, waitFor, within } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

import {
    planSearchAggregatesInTransit,
    userRlInfoMock,
    loadDetailsMock,
    losData,
} from './mocks/TripManagementSummary.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';

import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';

import TripManagementSummary from '../TripManagementSummary';
import TripSharedService from '../../../service/TripSharedService';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(planSearchAggregatesInTransit));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(CmsConfigUS));
        }
        return res(ctx.json(CmsConfig));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}getLoadDetails/loadDetails`, (req, res, ctx) => res(ctx.json(loadDetailsMock))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}fetchStaticData/fetchStaticData`, (req, res, ctx) => res(ctx.json(losData))),
    rest.post(`${API_GATEWAY_PREFIX_NEW}regenrateBOL/regenrateBOL`, (req, res, ctx) =>
        res(ctx.status(201), ctx.json({ response: 'response' })),
    ),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const spy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    spy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

afterEach(() => {
    server.resetHandlers();
});

const windowOpenSpy = jest.spyOn(window, 'open');

describe('Regenerate BOL - US', () => {
    const contextMockUS = { ...contextMock, currentMarket: 'us' };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
    });
    it('should close rbol model when click on close button', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = await screen.findByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const closeButton = await screen.findByTestId('ld-sc-ui-button-modal-close');
        expect(closeButton).toBeDefined();
        fireEvent.click(closeButton);
        expect(screen.queryByText('Regenerate BOL confirmation')).toBe(null);
    });

    it('should close rbol model when click on cancel button', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const cancelButton = screen.getByText('Cancel');
        expect(cancelButton).toBeDefined();
        fireEvent.click(cancelButton);
        expect(screen.queryByText('Regenerate BOL confirmation')).toBe(null);
    });

    it('should render rbol modal with current contacts selected', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const currentContacts = screen.getByText('Current contacts');
        expect(currentContacts).toBeDefined();
        const currentContactsCheckbox = await screen.findByTestId('currentContact');
        expect(currentContactsCheckbox).toBeDefined();
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        fireEvent.click(confirmationButton);
        expect(await screen.findByText('Regenerate BOL successful.')).toBeDefined();
    });

    it('should disable confirmation button if not enter email', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const otherContacts = screen.getByText('Other contacts');
        expect(otherContacts).toBeDefined();
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        expect(otherContactsCheckbox).toBeDefined();
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        expect(emailTextInput).toBeDefined();
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', true);
    });

    it('should disable confirmation button if enter wrong email', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const otherContacts = screen.getByText('Other contacts');
        expect(otherContacts).toBeDefined();
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        expect(otherContactsCheckbox).toBeDefined();
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        expect(emailTextInput).toBeDefined();
        fireEvent.change(emailTextInput, { target: { value: 'test' } });
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', true);
    });

    it('should disable confirmation button if enter email with special chars', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const otherContacts = screen.getByText('Other contacts');
        expect(otherContacts).toBeDefined();
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        expect(otherContactsCheckbox).toBeDefined();
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        expect(emailTextInput).toBeDefined();
        fireEvent.change(emailTextInput, { target: { value: 'test@test.com%%' } });
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', true);
    });

    it('should enable confirmation button if enter correct format email', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const otherContacts = screen.getByText('Other contacts');
        expect(otherContacts).toBeDefined();
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        expect(otherContactsCheckbox).toBeDefined();
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        expect(emailTextInput).toBeDefined();
        fireEvent.change(emailTextInput, { target: { value: 'test@test.com' } });
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', false);
        fireEvent.click(confirmationButton);
        expect(await screen.findByText('Regenerate BOL successful.')).toBeDefined();
    });

    it('should render Error when confirmation BOL API fail', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}regenrateBOL/regenrateBOL`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json({ errors: [{ error: 'error' }] })),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const otherContacts = screen.getByText('Other contacts');
        expect(otherContacts).toBeDefined();
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        expect(otherContactsCheckbox).toBeDefined();
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        expect(emailTextInput).toBeDefined();
        fireEvent.change(emailTextInput, { target: { value: 'test@test.com' } });
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', false);
        fireEvent.click(confirmationButton);
        expect(await screen.findByText("Couldn't process the request. Try again")).toBeDefined();
    });

    it('should enable confirmation button if enter multiple correct emails', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const otherContacts = screen.getByText('Other contacts');
        expect(otherContacts).toBeDefined();
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        expect(otherContactsCheckbox).toBeDefined();
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        expect(emailTextInput).toBeDefined();
        fireEvent.change(emailTextInput, { target: { value: 'test@test.com;test2@test.com test3@test.com' } });
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', false);
        fireEvent.click(confirmationButton);
        expect(await screen.findByText('Regenerate BOL successful.')).toBeDefined();
    });

    it('should disable confirmation button if not selected any contacts', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const currentContactsCheckbox = await screen.findByTestId('currentContact');
        fireEvent.click(currentContactsCheckbox, { target: { checked: false } });
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        fireEvent.click(otherContactsCheckbox, { target: { checked: false } });
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', true);
    });

    it('should select both contacts', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const currentContactsCheckbox = await screen.findByTestId('currentContact');
        fireEvent.click(currentContactsCheckbox);
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        fireEvent.change(emailTextInput, { target: { value: 'test@test.com;test2@test.com test3@test.com' } });
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', false);
        fireEvent.click(confirmationButton);
        expect(await screen.findByText('Regenerate BOL successful.')).toBeDefined();
    });

    it('should test location link', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const locationLink = await screen.findByTestId('locationLink');
        expect(locationLink).toBeDefined();
        fireEvent.click(locationLink);
        expect(windowOpenSpy).toBeCalledWith('/stride/location/details?type=DC&id=6094');
    });

    it('should test carrier link', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Regenerate bol');
        fireEvent.click(regeneratebolBtn[0]);
        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const carrierLink = await screen.findByTestId('carrierLink');
        expect(carrierLink).toBeDefined();
        fireEvent.click(carrierLink);
        expect(windowOpenSpy).toBeCalledWith('/stride/carrier/details?id=10450&vendorNum=762933');
    });

    it('Should render regenerate confirmation BOL model when select checkbox', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const regenerateBOLButton = await screen.findByTestId('REGENERATE_BOL');
        expect(regenerateBOLButton).toBeDefined();
        fireEvent.click(regenerateBOLButton);

        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
    });

    it('Should render and success RBOL API when select current and other contacts', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const regenerateBOLButton = await screen.findByTestId('REGENERATE_BOL');
        expect(regenerateBOLButton).toBeDefined();
        fireEvent.click(regenerateBOLButton);

        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const currentContactsCheckbox = await screen.findByTestId('currentContact');
        fireEvent.click(currentContactsCheckbox);
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        fireEvent.change(emailTextInput, { target: { value: 'test@test.com;test2@test.com test3@test.com' } });
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', false);
        fireEvent.click(confirmationButton);
        expect(await screen.findByText('Regenerate BOL successful.')).toBeDefined();
    });

    it('Should render and fail RBOL API when select current and other contacts', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}regenrateBOL/regenrateBOL`, (_req, res, ctx) =>
                res(ctx.status(500), ctx.json({ errors: [{ error: 'error' }] })),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkboxOne = await screen.findByTestId(getCheckboxTestId('200024732'));
        fireEvent.click(checkboxOne);
        const regenerateBOLButton = await screen.findByTestId('REGENERATE_BOL');
        expect(regenerateBOLButton).toBeDefined();
        fireEvent.click(regenerateBOLButton);

        const rbolText = screen.getByText('Regenerate BOL confirmation');
        expect(rbolText).toBeDefined();
        const currentContactsCheckbox = await screen.findByTestId('currentContact');
        fireEvent.click(currentContactsCheckbox);
        const otherContactsCheckbox = await screen.findByTestId('otherContact');
        fireEvent.click(otherContactsCheckbox);
        const emailTextInput = await screen.findByTestId('emailTextInput');
        fireEvent.change(emailTextInput, { target: { value: 'test@test.com;test2@test.com test3@test.com' } });
        const confirmationButton = screen.getByText('Send confirmation');
        expect(confirmationButton).toBeDefined();
        expect(await screen.findByTestId('confirmationButton')).toHaveProperty('disabled', false);
        fireEvent.click(confirmationButton);
        expect(await screen.findByText("Couldn't process the request. Try again")).toBeDefined();
    });
});
