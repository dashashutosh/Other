import React from 'react';
import Adapter from '@wojtekmaj/enzyme-adapter-react-17';
import Enzyme, { shallow } from 'enzyme';
import { act } from 'react-dom/test-utils';
import CreateTripConfirmModal from '../CreateTripConfirmModal';
import { connectLoads } from '../../../Constants';
import { confirmFormInitialState } from '../DataModels';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

Enzyme.configure({ adapter: new Adapter() });

beforeEach(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('Create trip confirm modal tests', () => {
    it('should render without crashing', () => {
        const wrapper = shallow(<CreateTripConfirmModal pIsOpen pOnClose={() => {}} pConnectLoads={connectLoads} />);
        expect(wrapper).toBeDefined();
    });

    it('should close modal on close button click', () => {
        const mockFn = jest.fn();
        const submitMockFn = jest.fn();
        const wrapper = shallow(
            <CreateTripConfirmModal pIsOpen pOnClose={mockFn} pOnSubmit={submitMockFn} pConnectLoads={connectLoads} />,
        );
        act(() => {
            wrapper.find('[data-testid="cancelBtn"]').prop('onClick')();
        });
        expect(mockFn).toHaveBeenCalledWith(false);
        act(() => {
            wrapper.find('[data-testid="confirmBtn"]').prop('onClick')();
        });
        expect(submitMockFn).toHaveBeenCalledWith(true, confirmFormInitialState);
    });

    it('should not show connect load, transit time and distance input if create trip', () => {
        const wrapper = shallow(<CreateTripConfirmModal pIsOpen pOnClose={() => {}} pConnectLoads={connectLoads} />);
        expect(wrapper.find('[data-testid="connectLoads"]').length).toEqual(0);
        expect(wrapper.find('[data-testid="transitTime"]').length).toEqual(0);
        expect(wrapper.find('[data-testid="distance"]').length).toEqual(0);
    });

    it('should show connect load, transit time and distance input if assign trip', () => {
        const wrapper = shallow(
            <CreateTripConfirmModal pIsOpen pOnClose={() => {}} pConnectLoads={connectLoads} pIsAssignTrip />,
        );
        expect(wrapper.find('[data-testid="connectLoads"]').length).toEqual(1);
        expect(wrapper.find('[data-testid="transitTime"]').length).toEqual(1);
        expect(wrapper.find('[data-testid="distance"]').length).toEqual(1);
    });

    it('should set field values', () => {
        const wrapper = shallow(
            <CreateTripConfirmModal pIsOpen pOnClose={() => {}} pConnectLoads={connectLoads} pIsAssignTrip />,
        );
        act(() => {
            wrapper.find('[data-testid="connectLoads"]').prop('onClick')({
                currentTarget: { dataset: { name: 'label.bobtail' } },
            });
        });
        expect(wrapper.find('[data-testid="loadBOB"]').prop('isSelected')).toEqual(true);
        expect(wrapper.find('[data-testid="loadDHD"]').prop('isSelected')).toEqual(false);
        act(() => {
            wrapper.find('[data-testid="transitTime"]').prop('onChange')({ target: { value: '10' } });
        });
        expect(wrapper.find('[data-testid="transitTime"]').prop('value')).toEqual('10');
        act(() => {
            wrapper.find('[data-testid="distance"]').prop('onChange')({ target: { value: '100' } });
        });
        expect(wrapper.find('[data-testid="distance"]').prop('value')).toEqual('100');
    });
});
