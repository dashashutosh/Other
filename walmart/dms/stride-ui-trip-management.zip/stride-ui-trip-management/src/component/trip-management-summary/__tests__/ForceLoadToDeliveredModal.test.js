import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ForceLoadToDeliveredModal from '../ForceLoadToDeliveredModal';
import { render } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import { loadDetailslsMockTnt } from './mocks/WorkloadAssignment.mock';
import TripSharedService from '../../../service/TripSharedService';

const mockFn = jest.fn();
const staticData = {
    los: [
        {
            id: 1,
        },
    ],
};
const API_GATEWAY_PREFIX = '/api/gateway/v4/stride-ui-trip-management';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX}-loadDetails/loadDetails`, (req, res, ctx) => res(ctx.json(loadDetailslsMockTnt))),
    rest.post(`${API_GATEWAY_PREFIX}-fetchStaticData/fetchStaticData`, (req, res, ctx) => res(ctx.json(staticData))),
);

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
    server.listen();
});

describe('Force Load to Delivered Modal test', () => {
    it('should render without crashing', async () => {
        await TripSharedService.setFeatureFlags({ showUpdateTimeline: true, showArrivalDepartureLosToggle: true });
        const wrapper = render(
            <ForceLoadToDeliveredModal
                pOpenModal
                pPlanId={1234}
                pSuccess={mockFn}
                pLoading={mockFn}
                pOnCloseModal={mockFn}
                pError={mockFn}
                pStaticData={{ planId: 1 }}
            />,
        );
        const container = wrapper.getByTestId('ld-sc-ui--modal-content');
        expect(container).toBeDefined();
        expect(wrapper.queryByText('Update Timeline')).toBeDefined();
        // TODO: Fix this eslint after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByText('Actual arrival time')).toBeDefined();
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByText('Actual departure time')).toBeDefined();
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByText('Los Event')).toBeDefined();
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByText('Cancel')).toBeDefined();
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByText('Confirm')).toBeDefined();
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByText('Arrival & Departure')).toBeDefined();
    });
});
