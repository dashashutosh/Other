import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ResizeObserver from 'resize-observer-polyfill';

import { render, screen, fireEvent, waitFor } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

import { planSearchAggregatesProcessing } from './mocks/PlanLTPreview.mock';
import { userRlInfoMock } from './mocks/TripManagementSummary.mock';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';

import TripManagementSummary from '../TripManagementSummary';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import { losData, tripDetailsResponseMockReadyToStartTnt } from './mocks/TripUpdateTimeline.mock';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';
import { getUpdatedCMSConfig } from '../../../utils/test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const configUpdated = getUpdatedCMSConfig(CmsConfigUS, { enablePrintTripSheet: true });

const printTripSheetErrorMock = {
    errors: [
        {
            description: 'Check error identifiers for specific details.',
            info: 'At least one of the underlying APIs failed.',
            errorIdentifiers: {
                details: {
                    prefix: 'DOCUMENT',
                    code: '1000',
                    description: 'Failed to get the trip sheet',
                    exceptionMessages: ['DOCUMENT-400.1000.1003:WM_SYSTEM is null or invalid'],
                },
            },
        },
    ],
};

const locationMultiFetchErrorMock = {
    errors: [
        {
            description: 'Check error identifiers for specific details.',
            info: 'At least one of the underlying APIs failed.',
            severity: 'ERROR',
            errorIdentifiers: {
                details: {
                    errors: {
                        errors: [
                            {
                                errorCode: 'STRIDE-E002',
                                errorText: 'Message: Location not found',
                                severity: 'ERROR',
                            },
                        ],
                    },
                    status: 'VALIDATION_ERROR',
                },
            },
        },
    ],
};

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        return res(ctx.json(MdmLtmStaticDataUS));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        return res(ctx.json(configUpdated));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}getTripDetails/tripDetails`, (req, res, ctx) =>
        res(ctx.json(tripDetailsResponseMockReadyToStartTnt)),
    ),
    rest.post(`${API_GATEWAY_PREFIX_NEW}fetchStaticData/fetchStaticData`, (req, res, ctx) => res(ctx.json(losData))),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const getBoundingClientRectSpy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    getBoundingClientRectSpy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW

    const contextMockUS = {
        ...contextMock,
        currentMarket: 'us',
        invokeBulkUpdate: jest.fn(() => Promise.resolve({ status: 200 })),
    };
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMockUS);
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Print trip sheet tests', () => {
    it('Should display print trip sheet action', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);
        const printTripSheetAction = await screen.findByTestId('PRINT_TRIP_SHEET');
        expect(printTripSheetAction).toBeDefined();
    });
    it('Should display error when trip details API fails', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}getTripDetails/tripDetails`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json({})),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);
        const printTripSheetAction = await screen.findByTestId('PRINT_TRIP_SHEET');
        expect(printTripSheetAction).toBeDefined();
        fireEvent.click(printTripSheetAction);
        expect(await screen.findByText('API.error.invalid')).toBeDefined();
    });
    it('Should display error when multi location fetch API fails', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}getTripDetails/tripDetails`, (req, res, ctx) =>
                res(ctx.json(tripDetailsResponseMockReadyToStartTnt)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}fetchMultiLocations/fetchMultiLocations`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(locationMultiFetchErrorMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);
        const printTripSheetAction = await screen.findByTestId('PRINT_TRIP_SHEET');
        expect(printTripSheetAction).toBeDefined();
        fireEvent.click(printTripSheetAction);
        expect(await screen.findByText('Message: Location not found')).toBeDefined();
    });
    it('Should display error when print trip sheet API fails', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}getTripDetails/tripDetails`, (req, res, ctx) =>
                res(ctx.json(tripDetailsResponseMockReadyToStartTnt)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}fetchMultiLocations/fetchMultiLocations`, (req, res, ctx) =>
                res(
                    ctx.json({
                        locations: [
                            {
                                primary_info: {
                                    location_id: 6094,
                                },
                            },
                            {
                                primary_info: {
                                    location_id: 100,
                                },
                            },
                        ],
                    }),
                ),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}printTripSheet/printTripSheet`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(printTripSheetErrorMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);
        const printTripSheetAction = await screen.findByTestId('PRINT_TRIP_SHEET');
        expect(printTripSheetAction).toBeDefined();
        fireEvent.click(printTripSheetAction);
        expect(await screen.findByText('Failed to get the trip sheet')).toBeDefined();
    });
    it('Should open print console on success', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesProcessing)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}getTripDetails/tripDetails`, (req, res, ctx) =>
                res(ctx.json(tripDetailsResponseMockReadyToStartTnt)),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}fetchMultiLocations/fetchMultiLocations`, (req, res, ctx) =>
                res(
                    ctx.json({
                        locations: [
                            {
                                primary_info: {
                                    location_id: 6094,
                                },
                            },
                            {
                                primary_info: {
                                    location_id: 100,
                                },
                            },
                        ],
                    }),
                ),
            ),
            rest.post(`${API_GATEWAY_PREFIX_NEW}printTripSheet/printTripSheet`, (req, res, ctx) =>
                res(
                    ctx.json({
                        document: {
                            externalPouchId: 'YZN5RIPK_46',
                            name: 'YZN5RIPK_46.pdf',
                            type: 'pdf',
                            category: 'NRA',
                            content: 'abc',
                        },
                    }),
                ),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Processing');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('500004194'));
        fireEvent.click(checkboxOne);
        const printTripSheetAction = await screen.findByTestId('PRINT_TRIP_SHEET');
        expect(printTripSheetAction).toBeDefined();
        fireEvent.click(printTripSheetAction);

        const appendChildSpy = jest.spyOn(document.body, 'appendChild');
        global.URL.createObjectURL = jest.fn().mockReturnValue('blobURL');
        await waitFor(() => {
            expect(appendChildSpy).toHaveBeenCalled();
        });
        appendChildSpy.mockClear();
        global.URL.createObjectURL.mockClear();
    });
});
