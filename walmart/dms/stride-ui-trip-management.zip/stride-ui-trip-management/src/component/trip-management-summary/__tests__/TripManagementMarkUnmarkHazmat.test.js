import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ResizeObserver from 'resize-observer-polyfill';

import { render, screen, fireEvent, waitFor, within } from '../../../utils/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import {
    planSearchAggregatesInTransit,
    planSearchAggregatesHazmat,
    userRlInfoMock,
    loadDetailsMock,
    losData,
} from './mocks/TripManagementSummary.mock';

import { planSearchAggregatesProcessing } from './mocks/PlanLTPreview.mock';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import PlanSearchAggregatesCA from './mocks/PlanSearchAggregatesCA.mock.json';
import PlanSearchAggregates from './mocks/PlanSearchAggregates.mock.json';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';

import TripManagementSummary from '../TripManagementSummary';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'CA_CA') {
            return res(ctx.json(PlanSearchAggregatesCA));
        }
        if (tenantId === 'US_US') {
            return res(ctx.json(planSearchAggregatesHazmat));
        }
        if (tenantId === 'CL' || tenantId === 'CAM_GT') {
            return res(ctx.json(PlanSearchAggregates));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(CmsConfigUS));
        }
        return res(ctx.json(CmsConfig));
    }),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});
const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;

    const getBoundingClientRectSpy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    getBoundingClientRectSpy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

beforeEach(() => {});

afterEach(() => {
    server.resetHandlers();
});

const invokeBulkUpdateMock = jest.fn();

const contextMockUS = {
    ...contextMock,
    currentMarket: 'us',
    invokeBulkUpdate: invokeBulkUpdateMock,
};

const spy = jest.spyOn(AppUtils, 'get');
spy.mockImplementation(() => contextMockUS);

afterAll(() => server.close());

describe('Mark/Unmark Hazmat', () => {
    it('Should retun mark hazmat action when check box is selected ', async () => {
        invokeBulkUpdateMock.mockImplementation(() => Promise.resolve({ status: 200 }));

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesHazmat)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planningTab = screen.getByText('Planning');
        fireEvent.click(planningTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('33677849'));
        fireEvent.click(checkboxOne);
        const hazmatAction = await screen.findAllByText('Mark Hazmat');
        expect(hazmatAction[0]).toBeDefined();
        fireEvent.click(hazmatAction[0]);
        const successMsg = await screen.findByText('1 plan(s) submitted for Hazmat update');
        expect(successMsg).toBeDefined();
    });

    it('Should retun mark hazmat action when  2 check box are selected', async () => {
        invokeBulkUpdateMock.mockImplementation(() => Promise.resolve({ status: 200 }));
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesHazmat)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planningTab = screen.getByText('Planning');
        fireEvent.click(planningTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('33677849'));
        fireEvent.click(checkboxOne);
        const checkboxTwo = await screen.findByTestId(getCheckboxTestId('33451078'));
        fireEvent.click(checkboxTwo);

        const hazmatAction = await screen.findAllByText('Mark Hazmat');
        expect(hazmatAction[0]).toBeDefined();
        fireEvent.click(hazmatAction[0]);
        const successMsg = await screen.findByText('2 plan(s) submitted for Hazmat update');
        expect(successMsg).toBeDefined();
    });
    it('Should retuen unmark hazmat action when select one Plan item which has hazmat is selected', async () => {
        invokeBulkUpdateMock.mockImplementation(() => Promise.resolve({ status: 200 }));

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesHazmat)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Planning');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('33486956'));
        fireEvent.click(checkboxOne);

        const hazmatAction = await screen.findAllByText('Unmark Hazmat');
        expect(hazmatAction[0]).toBeDefined();
        fireEvent.click(hazmatAction[0]);
        const successMsg = await screen.findByText('1 plan(s) submitted for Hazmat update');
        expect(successMsg).toBeDefined();
    });

    it('Should retuen mark/unmark hazmat action when select one Plan item which has hazmat is selected and one whithout hazmat is selected', async () => {
        invokeBulkUpdateMock.mockImplementation(() => Promise.resolve({ status: 200 }));

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesHazmat)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Planning');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('33486956'));
        fireEvent.click(checkboxOne);
        const checkboxTwo = await screen.findByTestId(getCheckboxTestId('33451078'));
        fireEvent.click(checkboxTwo);
        const hazmatAction = await screen.findAllByText('Mark/Unmark Hazmat');
        expect(hazmatAction[0]).toBeDefined();
        fireEvent.click(hazmatAction[0]);
        const successMsg = await screen.findByText('2 plan(s) submitted for Hazmat update');
        expect(successMsg).toBeDefined();
    });

    it('Should return hazmat action from actions menu, to update  hazmat', async () => {
        invokeBulkUpdateMock.mockImplementation(() => Promise.resolve({ status: 200 }));

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesHazmat)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planningTab = screen.getByText('Planning');
        fireEvent.click(planningTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const regeneratebolBtn = await screen.findAllByText('Mark Hazmat');
        fireEvent.click(regeneratebolBtn[0]);

        const hazmatAction = await screen.findAllByText('Mark Hazmat');
        expect(hazmatAction[0]).toBeDefined();
        fireEvent.click(hazmatAction[0]);
        const successMsg = await screen.findByText('1 plan(s) submitted for Hazmat update');
        expect(successMsg).toBeDefined();
    });
    it('Should return hazmat action from actions menu, to update  hazmat', async () => {
        invokeBulkUpdateMock.mockImplementation(() => Promise.resolve({ status: 200 }));

        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(planSearchAggregatesHazmat)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const processingTab = screen.getByText('Planning');
        fireEvent.click(processingTab);
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const firstRowActionCell = planTableBody.children[0].lastChild;
        const button = within(firstRowActionCell).getByText('...');
        fireEvent.click(button);
        const checkboxOne = await screen.findByTestId(getCheckboxTestId('33486956'));
        fireEvent.click(checkboxOne);

        const hazmatAction = await screen.findAllByText('Unmark Hazmat');
        expect(hazmatAction[0]).toBeDefined();
        fireEvent.click(hazmatAction[0]);
        const successMsg = await screen.findByText('1 plan(s) submitted for Hazmat update');
        expect(successMsg).toBeDefined();
    });
});
