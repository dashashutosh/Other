import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import ResizeObserver from 'resize-observer-polyfill';

import { render, screen, fireEvent, waitFor, within } from '../../../utils/test-utils';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import { LocationErrorMock } from './mocks/PlanLTPreview.mock';
import { userRlInfoMock, locationAutoCompleteMock } from './mocks/TripManagementSummary.mock';
import reviewAndApproveMock from './mocks/ReviewAndApprove.mock.json';
import CmsConfig from '../../../service/__tests__/mocks/CmsConfig.json';
import CmsConfigUS from '../../../service/__tests__/mocks/CmsConfigUS.json';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import MdmLtmStaticDataUS from './mocks/MdmLtmStaticDataUS.mock.json';
import TripManagementSummary from '../TripManagementSummary';
import PlanSearchAggregatesUS from '../US/__tests__/mocks/PlanSearchAggregrateUS.mock.json';
import TripSharedService from '../../../service/TripSharedService';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { getCheckboxTestId, SEARCH_RESULT_TABLE_BODY_TEST_ID } from './trip-management-summary-us-test-helpers';

const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

const server = setupServer(
    rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(PlanSearchAggregatesUS));
        }
        return res(ctx.status(404));
    }),
    rest.post(`${API_GATEWAY_PREFIX_NEW}staticData/staticData`, (req, res, ctx) => {
        const { tenantId } = req.body.additionalHeaders;
        if (tenantId === 'US_US') {
            return res(ctx.json(MdmLtmStaticDataUS));
        }
        return res(ctx.json(MdmLtmStaticData));
    }),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => {
        const market = req.url.searchParams.get('market');
        if (market === 'us') {
            return res(ctx.json(CmsConfigUS));
        }
        return res(ctx.json(CmsConfig));
    }),
);

const userPermMock = JSON.stringify({
    permissions: [
        'ca.stride.ltm-tripManagement:READ',
        'ca.stride.ltm-tripManagement:WRITE',
        'cl.stride.ltm-tripManagement:READ',
        'cl.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:READ',
        'us.stride.ltm-tripManagement:WRITE',
        'gt.stride.ltm-tripManagement:READ',
        'gt.stride.ltm-tripManagement:WRITE',
        'us.stride.ltm-tripManagement:DRAY_EXT_USER',
    ],
    markets: ['ca', 'us', 'cl', 'gt'],
});

const userPreferencesMock = JSON.stringify({});

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    }),
}));
jest.setTimeout(30000);
beforeAll(() => {
    const originalOffsetHeight = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetHeight');
    const originalOffsetWidth = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetWidth');
    Object.defineProperty(HTMLElement.prototype, 'offsetHeight', { configurable: true, value: 50 });
    Object.defineProperty(HTMLElement.prototype, 'offsetWidth', { configurable: true, value: 50 });
    const localStorageGetItem = jest.fn((arg) => {
        if (arg === 'ngStorage-permissionData') {
            return userPermMock;
        }

        if (arg === 'ngStorage-preferences_user') {
            return userPreferencesMock;
        }

        if (arg === 'ngStorage-rlUserInfo') {
            return userRlInfoMock;
        }
    });
    Object.defineProperty(global, 'localStorage', {
        value: {
            getItem: localStorageGetItem,
            setItem: () => {},
        },
        writable: true,
    });
    server.listen();

    global.ResizeObserver = ResizeObserver;
    const spy = jest.spyOn(global.Element.prototype, 'getBoundingClientRect');
    spy.mockReturnValue({ height: 50 * 50 }); // DEFAULT_ROW_HEIGHT * ROWS_PER_WINDOW
});

afterEach(() => {
    server.resetHandlers();
});

afterAll(() => server.close());

describe('Plannig phase action review & approve - US', () => {
    const contextMockUS = {
        ...contextMock,
        currentMarket: 'us',
        invokeBulkUpdate: jest.fn(() => Promise.resolve({ status: 200 })),
    };
    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
        TripSharedService.setPageLoadSettings({ enableDrayIntroColumn: true });
    });
    it('Should show review & approve action in action menu click on checkbox', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox = await screen.findByTestId(getCheckboxTestId('27510003'));
        fireEvent.click(checkbox);
        const reviewAndApproveButton = screen.queryByTestId('REVIEW_AND_APPROVE');
        expect(reviewAndApproveButton).toBeDefined();
    });

    it('should not show review & approve action with different OD pairs', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox1 = await screen.findByTestId(getCheckboxTestId('27510003'));
        fireEvent.click(checkbox1);
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('27651969'));
        fireEvent.click(checkbox2);
        const reviewAndApproveButton = screen.queryByTestId('REVIEW_AND_APPROVE');
        expect(reviewAndApproveButton).toBeNull();
    });

    it('should show review & approve action with same OD pairs', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const checkbox1 = await screen.findByTestId(getCheckboxTestId('27690295'));
        fireEvent.click(checkbox1);
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('27651969'));
        fireEvent.click(checkbox2);
        const reviewAndApproveButton = screen.queryByTestId('REVIEW_AND_APPROVE');
        expect(reviewAndApproveButton).toBeDefined();
    });

    it('should show review & approve on click of action dots', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const ninthRowActionCell = planTableBody.children[8].lastChild;
        const button = within(ninthRowActionCell).getByText('...');
        fireEvent.click(button);
        expect(await screen.findAllByText('Review & Approve')).toBeDefined();
    });

    it('Should verify open "Review & Approve" drawer on click Review & Approve action and fields editable', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const ninthRowActionCell = planTableBody.children[8].lastChild;
        const button = within(ninthRowActionCell).getByText('...');
        fireEvent.click(button);

        const approveBtn = await screen.findAllByText('Review & Approve');
        expect(approveBtn[0]).toBeDefined();
        fireEvent.click(approveBtn[0]);

        const originLocationField = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocationField).toBeDefined();
        fireEvent.change(originLocationField, { target: { value: 'STORE - 100' } });
        expect(originLocationField.value).toBe('STORE - 100');

        const pickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(pickupDateField).toBeDefined();
        fireEvent.change(pickupDateField, { target: { value: '08/05/2023' } });
        expect(pickupDateField.value).toBe('08/05/2023');

        const locationField = screen.getByTestId('locationId-destination').querySelector('input');
        expect(locationField).toBeDefined();
        fireEvent.change(locationField, { target: { value: 'DC - 7067' } });
        expect(locationField.value).toBe('DC - 7067');
    });

    it('Should disable review approve button on selecting old date', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const ninthRowActionCell = planTableBody.children[8].lastChild;
        const button = within(ninthRowActionCell).getByText('...');
        fireEvent.click(button);

        const approveBtn = await screen.findAllByText('Review & Approve');
        expect(approveBtn[0]).toBeDefined();
        fireEvent.click(approveBtn[0]);

        const pickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(pickupDateField).toBeDefined();
        fireEvent.click(pickupDateField);

        const date = await screen.findByText('15');
        fireEvent.click(date);
        const updatedPickupDateField = screen.getByTestId('planned-origin-date').querySelector('input');
        expect(updatedPickupDateField.value).toBe('08/15/2023');

        const reviewApproveBtn = await screen.findByTestId('review-approve-button');
        expect(reviewApproveBtn).toHaveProperty('disabled', true);
    });

    it('Should verify split load button is available clickable and fields editable', async () => {
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const ninthRowActionCell = planTableBody.children[8].lastChild;
        const button = within(ninthRowActionCell).getByText('...');
        fireEvent.click(button);

        const approveBtn = await screen.findAllByText('Review & Approve');
        expect(approveBtn[0]).toBeDefined();
        fireEvent.click(approveBtn[0]);

        const splidLoadBtn = await screen.findByTestId('split-load-button');
        expect(splidLoadBtn).toBeDefined();
        fireEvent.click(splidLoadBtn);

        const splitLoadFields = screen.getByTestId('split-load-fields').querySelectorAll('input');
        expect(splitLoadFields).toBeDefined();

        fireEvent.change(splitLoadFields[0], { target: { value: '08/05/2023' } });
        expect(splitLoadFields[0].value).toBe('08/05/2023');
        fireEvent.change(splitLoadFields[1], { target: { value: 'STORE - 100' } });
        expect(splitLoadFields[1].value).toBe('STORE - 100');
    });

    it('Should show success message on Api success', async () => {
        const contextMockUpdated = {
            ...contextMock,
            currentMarket: 'us',
            invokeBulkUpdate: jest.fn(() => Promise.resolve({ status: 'response' })),
        };
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUpdated);

        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const ninthRowActionCell = planTableBody.children[8].lastChild;
        const button = within(ninthRowActionCell).getByText('...');
        fireEvent.click(button);

        const approveBtn = await screen.findAllByText('Review & Approve');
        expect(approveBtn[0]).toBeDefined();
        fireEvent.click(approveBtn[0]);

        const reviewApproveBtn = await screen.findByTestId('review-approve-button');
        fireEvent.click(reviewApproveBtn);
        const successMsg = await screen.findByText('1 Plans are submitted for approval. Changes will reflect soon');
        expect(successMsg).toBeDefined();
    });

    it('Should show error message on location API fail in review and approve', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}locationDetails/locationTSSSearch`, (req, res, ctx) =>
                res(ctx.status(500), ctx.json(LocationErrorMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const ninthRowActionCell = planTableBody.children[8].lastChild;
        const button = within(ninthRowActionCell).getByText('...');
        fireEvent.click(button);

        const approveBtn = await screen.findAllByText('Review & Approve');
        expect(approveBtn[0]).toBeDefined();
        fireEvent.click(approveBtn[0]);

        const originLocationField = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocationField).toBeDefined();
        fireEvent.click(originLocationField);

        const searchTextBox = await screen.findByPlaceholderText('Search');
        expect(searchTextBox).toBeDefined();
        fireEvent.change(searchTextBox, { target: { value: '100' } });
        const saveBtn = await screen.findAllByTestId('ld-sc-ui-button');
        fireEvent.click(saveBtn[1]);
        expect(await screen.findByText("Couldn't process the request. Try again")).toBeDefined();

        await waitFor(() => {
            const reviewApproveBtn = screen.getByTestId('review-approve-button');
            expect(reviewApproveBtn).toHaveProperty('disabled', true);
        });
    });

    it('should test Lcation Drodown in review and approve with location description', async () => {
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}mdmAutoComplete/mdmAutoComplete`, (req, res, ctx) =>
                res(ctx.json(locationAutoCompleteMock)),
            ),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();

        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });

        const ninthRowActionCell = planTableBody.children[8].lastChild;
        const button = within(ninthRowActionCell).getByText('...');
        fireEvent.click(button);

        const approveBtn = await screen.findAllByText('Review & Approve');
        expect(approveBtn[0]).toBeDefined();
        fireEvent.click(approveBtn[0]);
        const originLocationField = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocationField).toBeDefined();
        fireEvent.click(originLocationField);
        const dropdownSearch = screen.getByRole('combobox');
        fireEvent.change(dropdownSearch, { target: { value: 'nv' } });
        expect(dropdownSearch).toBeInTheDocument();
        const listBox = await screen.findAllByRole('listbox');
        expect(listBox).toBeDefined();
        const options = await screen.findAllByRole('option');
        expect(options[1].textContent).toBe('DISP - 6801 - BENTONVILLE, AR');
    });
});

describe('Plannig phase action review & approve - US', () => {
    const contextMockUS = {
        ...contextMock,
        currentMarket: 'us',
        invokeBulkUpdate: jest.fn(() => Promise.resolve({ status: 200 })),
    };

    beforeAll(() => {
        const spy = jest.spyOn(AppUtils, 'get');
        spy.mockImplementation(() => contextMockUS);
        TripSharedService.setTripStaticData(null, null);
    });

    it('should show review & approve action with same OD pairs to edit origin and destination', async () => {
        const config = {
            ...CmsConfigUS,
            payload: {
                ...CmsConfigUS.payload,
                custom: {
                    ...CmsConfigUS.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"enableMultipleLocationsRA": true, "enableSplitLoad": true, "showLocationDescription": true, "enableDrayIntroColumns": true, "enableManageColumns": true }}',
                },
            },
        };
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(reviewAndApproveMock)),
            ),
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('33876470'));
        fireEvent.click(checkbox1);
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('35583669'));
        fireEvent.click(checkbox2);
        const reviewAndApproveButton = screen.queryByTestId('REVIEW_AND_APPROVE');
        expect(reviewAndApproveButton).toBeDefined();
        fireEvent.click(reviewAndApproveButton);
        const originLocationField = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocationField.value).toBe('VNDR - 380605');
        fireEvent.change(originLocationField, { target: { value: 'DC - 6088' } });
        expect(originLocationField.value).toBe('DC - 6088');
        expect(originLocationField).toBeDefined();
        const locationField = screen.getByTestId('locationId-destination').querySelector('input');
        expect(locationField).toBeDefined();
        fireEvent.change(locationField, { target: { value: 'DC - 7067' } });
        expect(locationField.value).toBe('DC - 7067');

        const reviewApproveBtn = await screen.findByTestId('review-approve-button');
        fireEvent.click(reviewApproveBtn);
        const successMsg = await screen.findByText('2 Plans are submitted for approval. Changes will reflect soon');
        expect(successMsg).toBeDefined();
    });

    it('should show review & approve action with same origin, to edit the origin', async () => {
        const config = {
            ...CmsConfigUS,
            payload: {
                ...CmsConfigUS.payload,
                custom: {
                    ...CmsConfigUS.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"enableMultipleLocationsRA": true, "enableSplitLoad": true, "showLocationDescription": true, "enableDrayIntroColumns": true, "enableManageColumns": true }}',
                },
            },
        };
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(reviewAndApproveMock)),
            ),
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('35644451'));
        fireEvent.click(checkbox1);
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('35666522'));
        fireEvent.click(checkbox2);
        const reviewAndApproveButton = screen.queryByTestId('REVIEW_AND_APPROVE');
        expect(reviewAndApproveButton).toBeDefined();
        fireEvent.click(reviewAndApproveButton);
        const originLocationField = screen.getByTestId('locationId-orgin').querySelector('input');
        expect(originLocationField.value).toBe('DC - 7094');
        fireEvent.change(originLocationField, { target: { value: 'DC - 6088' } });
        expect(originLocationField.value).toBe('DC - 6088');
        expect(originLocationField).toBeDefined();
        const locationField = screen.getByText('Multiple');
        expect(locationField).toBeDefined();

        const reviewApproveBtn = await screen.findByTestId('review-approve-button');
        fireEvent.click(reviewApproveBtn);
        const successMsg = await screen.findByText('2 Plans are submitted for approval. Changes will reflect soon');
        expect(successMsg).toBeDefined();
    });

    it('should show review & approve action with same destination, to edit the destination', async () => {
        const config = {
            ...CmsConfigUS,
            payload: {
                ...CmsConfigUS.payload,
                custom: {
                    ...CmsConfigUS.payload.custom,
                    featureFlags:
                        '{"dev.tripManagement.configs":{"enableMultipleLocationsRA": true, "enableSplitLoad": true, "showLocationDescription": true, "enableDrayIntroColumns": true, "enableManageColumns": true }}',
                },
            },
        };
        server.use(
            rest.post(`${API_GATEWAY_PREFIX_NEW}planSearchAggregates/planSearchAggregates`, (req, res, ctx) =>
                res(ctx.json(reviewAndApproveMock)),
            ),
            rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))),
        );
        render(<TripManagementSummary />);
        const container = await screen.findByTestId('page-content-container');
        expect(container).toBeDefined();
        const planTableBody = await screen.findByTestId(SEARCH_RESULT_TABLE_BODY_TEST_ID);
        await waitFor(() => {
            expect(planTableBody.children.length).toBeGreaterThan(0);
        });
        const checkbox1 = await screen.findByTestId(getCheckboxTestId('35718119'));
        fireEvent.click(checkbox1);
        const checkbox2 = await screen.findByTestId(getCheckboxTestId('35718127'));
        fireEvent.click(checkbox2);
        const reviewAndApproveButton = screen.queryByTestId('REVIEW_AND_APPROVE');
        expect(reviewAndApproveButton).toBeDefined();
        fireEvent.click(reviewAndApproveButton);
        const originLocationField = screen.getByText('Multiple');
        expect(originLocationField).toBeDefined();
        const locationField = screen.getByTestId('locationId-destination').querySelector('input');
        expect(locationField.value).toBe('VNDR - 42654204');
        expect(locationField).toBeDefined();
        fireEvent.change(locationField, { target: { value: 'DC - 7067' } });
        expect(locationField.value).toBe('DC - 7067');

        const reviewApproveBtn = await screen.findByTestId('review-approve-button');
        fireEvent.click(reviewApproveBtn);
        const successMsg = await screen.findByText('2 Plans are submitted for approval. Changes will reflect soon');
        expect(successMsg).toBeDefined();
    });
});
