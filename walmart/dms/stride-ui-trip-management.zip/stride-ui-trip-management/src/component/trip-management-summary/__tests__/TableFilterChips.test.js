import React from 'react';
import { render, screen } from '../../../utils/test-utils';
import { tripStaticDataMock, contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import TripSharedService from '../../../service/TripSharedService';
import TableFilterChips from '../TableFilterChips';
import { AppUtils } from '@gscope-mfe/app-bridge';

const mockFn = jest.fn();
const mockQuery = {
    page: 1,
    sortField: 'PLAN_DEPARTURE_TS',
    sortMode: 'ASC',
    exceptionType: null,
    filter: {
        loadId: '',
        toId: '',
        fromDate: '',
        tillDate: '',
        after: '',
        before: '',
        on: '',
        dateType: '',
        periodType: '',
        loadType: [],
        planType: '',
        status: [],
        carrierId: '',
        scacCode: '',
        coordinatorBoard: '',
        serviceTerritory: '',
        driverId: '',
        trailerId: '',
        originType: ['ADM', 'SPLR'],
        originId: '',
        originCity: '',
        originState: '',
        originCountry: '',
        originZipCode: '',
        destinationType: '',
        destinationId: '',
        destinationCity: '',
        destinationState: '',
        destinationCountry: '',
        destinationZipCode: '',
    },
    profile: {},
    activeTabIndex: 0,
    timeHorizon: 48,
    globalSearchData: null,
};

beforeEach(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('ExceptionFilterChips', () => {
    beforeAll(() => {
        TripSharedService.setTripStaticData(tripStaticDataMock);
    });
    it('should render without crashing', () => {
        const wrapper = render(<TableFilterChips queryState={mockQuery} showMoreButton pGetFilterChipCount={mockFn} />);
        expect(wrapper).toBeDefined();
    });
    it('should call the callback funtion for the count ', () => {
        const wrapper = render(<TableFilterChips queryState={mockQuery} showMoreButton pGetFilterChipCount={mockFn} />);
        expect(wrapper).toBeDefined();
        expect(mockFn).toHaveBeenCalled();
    });
    // TODO: Fix this test after MFE migration
    it('should show more button if show more button is true', () => {
        const wrapper = render(<TableFilterChips queryState={mockQuery} showMoreButton pGetFilterChipCount={mockFn} />);
        expect(wrapper).toBeDefined();
        // eslint-disable-next-line testing-library/await-async-queries
        const moreIcon = wrapper.findByTestId('moreIcon');
        expect(moreIcon).toBeDefined();
    });
    it('should not show more button if show more button is false', () => {
        const wrapper = render(
            <TableFilterChips queryState={mockQuery} showMoreButton={false} pGetFilterChipCount={mockFn} />,
        );
        expect(wrapper).toBeDefined();
        const moreIcon = wrapper.queryByTestId('moreIcon');
        expect(moreIcon).toBeNull();
    });
});
