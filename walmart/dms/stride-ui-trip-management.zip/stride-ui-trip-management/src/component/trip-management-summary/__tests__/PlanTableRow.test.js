import React from 'react';
import Adapter from '@wojtekmaj/enzyme-adapter-react-17';
import Enzyme, { shallow } from 'enzyme';
import { act } from 'react-dom/test-utils';
import { TableRow } from '@walmart/living-design-sc-ui';
import { openPageInNewTab } from '@walmart/stride-ui-commons';
import PlanTableRow from '../PlanTableRow';
import { transformedPlanMock } from './mocks/TripManagementSummary.mock';
import { render, fireEvent, screen } from '../../../utils/test-utils';
import TripSharedService from '../../../service/TripSharedService';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';

const mockPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockPush,
    }),
}));

Enzyme.configure({ adapter: new Adapter() });
sessionStorage.setItem('ngStorage-permissionData', { permissions: ['cl.stride.tripLoadManagement:EDIT_TRIP'] });

const permissionsMock = {
    canEditTrip: true,
};

beforeAll(() => {
    TripSharedService.setPageLoadSettings({
        checkCoherence: true,
        showLocationName: false,
        showCLColumns: true,
    });
});

beforeEach(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('Plan Table Row tests for gt', () => {
    it('should check origin and destination name for gt', async () => {
        let wrapper = render(
            <PlanTableRow
                pRowData={transformedPlanMock[0]}
                pCheckedRows={[]}
                pSetCheckedRows={() => {}}
                pTabIndex={0}
                pIsTripSelected
                pTripStatus="PENDING_APPROVAL"
                pUserPerm={permissionsMock}
            />,
        );
        let msg = await wrapper.findAllByText('20'); // only originid is defined
        expect(msg).toBeDefined();
        TripSharedService.setPageLoadSettings({
            // setting locationName para true for gt
            checkCoherence: true,
            showLocationName: true,
            showCLColumns: true,
        });
        wrapper = render(
            <PlanTableRow
                pRowData={transformedPlanMock[0]}
                pCheckedRows={[]}
                pSetCheckedRows={() => {}}
                pTabIndex={0}
                pIsTripSelected
                pTripStatus="PENDING_APPROVAL"
                pUserPerm={permissionsMock}
            />,
        );
        msg = await wrapper.findByText('20 - Chennai'); // both id and name are shown
        expect(msg).toBeDefined();
    });
});

xdescribe('Plan Table Row tests', () => {
    it('should render without crashing', () => {
        const wrapper = shallow(
            <PlanTableRow
                pRowData={transformedPlanMock[0]}
                pCheckedRows={[]}
                pSetCheckedRows={() => {}}
                pTabIndex={0}
                pIsTripSelected
                pTripStatus="PENDING_APPROVAL"
                pUserPerm={permissionsMock}
            />,
        );
        expect(wrapper).toBeDefined();
    });

    it('should call pSetCheckedRows on checkbox selection', () => {
        const mockFn = jest.fn();
        const wrapper = shallow(
            <PlanTableRow
                pRowData={transformedPlanMock[0]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pTabIndex={0}
                pIsTripSelected
                pTripStatus="PENDING_APPROVAL"
                pUserPerm={permissionsMock}
            />,
        );
        act(() => {
            wrapper.find('[data-testid="selectRow"]').prop('onChange')();
        });
        expect(mockFn).toHaveBeenCalled();
    });

    it('should show loads on expand row icon click', () => {
        const mockFn = jest.fn();
        const wrapper = shallow(
            <PlanTableRow
                pRowData={transformedPlanMock[0]}
                pCheckedRows={[]}
                pSetCheckedRows={mockFn}
                pTabIndex={0}
                pIsTripSelected
                pTripStatus="PENDING_APPROVAL"
                pUserPerm={permissionsMock}
            />,
        );
        expect(wrapper.find(TableRow).length).toEqual(1);
        act(() => {
            wrapper.find('[data-testid="expandRowIcon"]').prop('onClick')();
        });
        expect(wrapper.find(TableRow).length).toEqual(3);
    });

    it('should not show expand row icon for loads', () => {
        const wrapper = shallow(
            <PlanTableRow
                pRowData={transformedPlanMock[2]}
                pCheckedRows={[]}
                pSetCheckedRows={() => {}}
                pTabIndex={0}
                pTripStatus="PENDING_APPROVAL"
                pUserPerm={permissionsMock}
            />,
        );
        expect(wrapper.find('[data-testid="expandRowIcon"]').length).toEqual(0);
    });
});

describe('Out of sync tag test', () => {
    it('table row should have out of sync tag', async () => {
        render(
            <PlanTableRow
                pRowData={transformedPlanMock[1]}
                pCheckedRows={[]}
                pSetCheckedRows={() => {}}
                pTabIndex={0}
                pIsTripSelected
                pTripStatus="PENDING_APPROVAL"
                pUserPerm={permissionsMock}
            />,
        );

        const outOfSyncTag = await screen.findByText('Out of sync');
        expect(outOfSyncTag).toBeDefined();
    });
});

describe('Navigate load/trip details page', () => {
    it.skip('should navigate the user to the details page', () => {
        const wrapper = render(<PlanTableRow pRowData={transformedPlanMock[0]} />);
        const loadTripId = wrapper.getByTestId('ld-sc-ui-button');
        fireEvent.click(loadTripId);
        expect(mockPush).toHaveBeenCalledWith({
            pathname: '/mfe/stride/planquery/tripdetails',
            search: `?planId=${transformedPlanMock[0].planId}`,
        });
    });

    it('should navigate the user to the details page in a new tab', () => {
        const wrapper = render(
            <PlanTableRow pRowData={transformedPlanMock[0]} pFeatureFlag={{ openDetailsPageInNewTab: true }} />,
        );
        const mockedOpen = jest.fn();
        const originalOpen = window.open;
        window.open = mockedOpen;
        const page = `http://${window.location.host}/stride/planquery/loaddetails?planId=${transformedPlanMock[0].planId}`;
        const loadTripId = wrapper.getByTestId('ld-sc-ui-button');
        fireEvent.click(loadTripId);
        openPageInNewTab(page);
        expect(mockedOpen).toBeCalled();
        window.open = originalOpen;
    });

    it('should navigate the user to the details page in the same tab when the featureflag is off', () => {
        const wrapper = render(
            <PlanTableRow
                pRowData={transformedPlanMock[0]}
                pFeatureFlag={{ openDetailsPageInNewTab: false, hasPQMigratedToMFE: true }}
            />,
        );
        const loadTripId = wrapper.getByTestId('ld-sc-ui-button');
        fireEvent.click(loadTripId);
        expect(mockPush).toHaveBeenCalledWith({
            pathname: '/mfe/stride/planquery/tripdetails',
            search: `?planId=${transformedPlanMock[0].planId}`,
        });
    });
});

describe('Mode display based on flag', () => {
    it('should not display mode when showModeColumnInTripSummary flag is false', () => {
        const rowData = { ...transformedPlanMock[0] };
        const wrapper = render(
            <PlanTableRow pRowData={rowData} pFeatureFlag={{ showModeColumnInTripSummary: false }} />,
        );
        expect(wrapper.queryByText('Truckload')).toBeNull();
    });
    it('should display mode if showModeColumnInTripSummary flag is enabled', () => {
        const wrapper = render(
            <PlanTableRow pRowData={transformedPlanMock[1]} pFeatureFlag={{ showModeColumnInTripSummary: true }} />,
        );
        expect(wrapper.getByText('Truckload')).toBeDefined();
    });
});

describe('reference load type', () => {
    it('should display load type if displayLoadTypeFromReference flag is disabled', () => {
        const rowData = { ...transformedPlanMock[1], isTrip: false, referenceLoadType: 'HUBSTR' };
        const wrapper = render(
            <PlanTableRow pRowData={rowData} pFeatureFlag={{ displayLoadTypeFromReference: false }} />,
        );
        expect(wrapper.getByText('STR')).toBeDefined();
        expect(wrapper.queryByText('HUBSTR')).toBeNull();
    });
    it('should display reference load type if displayLoadTypeFromReference flag is enabled', () => {
        const rowData = { ...transformedPlanMock[1], isTrip: false, referenceLoadType: 'HUBSTR' };
        const wrapper = render(
            <PlanTableRow pRowData={rowData} pFeatureFlag={{ displayLoadTypeFromReference: true }} />,
        );
        expect(wrapper.queryByText('STR')).toBeNull();
        expect(wrapper.getByText('HUBSTR')).toBeDefined();
    });
});
