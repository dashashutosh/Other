import React from 'react';
import ExceptionFilterChips from '../ExceptionFilterChips';
import { fireEvent, render } from '../../../utils/test-utils';
import TripSharedService from '../../../service/TripSharedService';
import {
    configResponseMock,
    staticDataWithoutExcepFilt,
    staticDataWithoutomStaticData,
    contextMock,
} from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import MdmLtmStaticData from './mocks/MdmLtmStaticData.mock.json';
import { AppUtils } from '@gscope-mfe/app-bridge';

const mockFn = jest.fn();

beforeEach(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('Create trip confirm modal tests', () => {
    beforeAll(() => {
        TripSharedService.setConfig(configResponseMock);
        TripSharedService.setTripStaticData(MdmLtmStaticData);
    });
    it('should render without crashing', () => {
        const wrapper = render(
            <ExceptionFilterChips
                pActiveTab={0}
                pCurrentMarket="ca"
                pOnExceptionFilterChange={mockFn}
                pGetExceptionCount={mockFn}
            />,
        );
        expect(wrapper).toBeDefined();
    });
    it('should call the callback funtion for the count ', () => {
        const wrapper = render(<ExceptionFilterChips pActiveTab={0} pCurrentMarket="ca" pGetExceptionCount={mockFn} />);
        expect(wrapper).toBeDefined();
        expect(mockFn).toHaveBeenCalled();
    });
    it('should render without crashing if static data has exceptional filter data', () => {
        const wrapper = render(
            <ExceptionFilterChips pActiveTab={0} pCurrentMarket="ca" pGetExceptionFilter="UNDER_UTILISED_LOAD" />,
        );
        expect(wrapper.getByTestId('stc-exception-chip-UNDER_UTILISED_LOAD')).toBeDefined();
    });
    it('should not render if static data is not avaialble', () => {
        TripSharedService.setTripStaticData(staticDataWithoutExcepFilt);
        const wrapper = render(
            <ExceptionFilterChips pActiveTab={0} pCurrentMarket="ca" pGetExceptionFilter="UNDER_UTILISED_LOAD" />,
        );
        // TODO: Fix this test after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByTestId('stc-exception-chip-UNDER_UTILISED_LOAD')).toBeDefined();
    });
    it('should not render if static data is not avaialble', () => {
        TripSharedService.setTripStaticData(staticDataWithoutomStaticData);
        const wrapper = render(
            <ExceptionFilterChips pActiveTab={0} pCurrentMarket="ca" pGetExceptionFilter="UNDER_UTILISED_LOAD" />,
        );
        // TODO: Fix this test after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByTestId('stc-exception-chip-UNDER_UTILISED_LOAD')).toBeDefined();
    });
    it('should not render if static data is not avaialble for ustrx', () => {
        TripSharedService.setTripStaticData(staticDataWithoutomStaticData);
        const wrapper = render(
            <ExceptionFilterChips pActiveTab={0} pCurrentMarket="ustrx" pGetExceptionFilter="UNDER_UTILISED_LOAD" />,
        );
        // TODO: Fix this test after MFE migration
        // eslint-disable-next-line testing-library/await-async-queries
        expect(wrapper.findByTestId('stc-exception-chip-UNDER_UTILISED_LOAD')).toBeDefined();
    });
});
