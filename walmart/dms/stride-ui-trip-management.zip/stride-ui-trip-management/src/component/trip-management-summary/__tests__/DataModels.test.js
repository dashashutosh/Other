import {
    formatAssignTripReq,
    getCarrierAssignRequest,
    getSelectedTripInfo,
    transformPlanPreviewData,
    parseResourceAssignRequest,
    searchFilterReqPayloadToChips,
    transformLoads,
    processDriversResponse,
    processEquipmentsResponse,
    getEquipmentDriverRequestPayload,
    formatAssignWorkLoadReq,
    transformTenderRequest,
    processCarriersResponse,
    getResourceAssignRequest,
    getCreatedDate,
    transformApproveTripRequest,
    formatForceToDeleverPlanRequest,
    bulkUploadProcessorCAM,
    formatResponseForTableData,
    getColumnsToExport,
    transformLoadsToEditTailer,
    getPlanLabel,
    getWorkloadAssignmentLabels,
    getTrailerAssignmentTypes,
    getCALabels,
    getEquipmentTypes,
    getFormattedEquipmentAPIValidationError,
    getEquipmentsOfSelectedCarrier,
    getWarningMessage,
    getTrailerErrorList,
    getFilteredColumnHeaders,
    getSelectedRowsText,
    displayConfirmButton,
    getWorkLoadEditData,
    getEquipmentTypeSeg,
    getTrailerAssignSeg,
    displayHeaderLabel,
    getFooterLabels,
    displayAssignToTripButton,
    getTransformedPlansList,
    getCountData,
    getFilteredRows,
    getPaginatedRows,
    getAppliedFiltersCount,
    showOriginSection,
    showDestinationSection,
    showLoadSection,
    showServiceSection,
    showCarrierSection,
    showPlanSection,
    isLocationIdDisabled,
    hasmatTransLabels,
    formatLoadEqpPair,
    getLabelWithUOM,
    isAllLoadsHaveChargeLocation,
    getTripsWithChargeLocValidation,
    getFormattedChargeLocError,
    displayUpdateDestinationButton,
    getLocationIdsList,
    transformLoadsToUpdateDestination,
    sealAndInvoiceDetailsExistInAllStops,
    getSelectedPlanDetails,
    transformedPlanListWithCarrierAssignedStatus,
    formatUpdateTimeLineData,
    getDoubleTrailerType,
    formatDoubleTrailerTripReq,
    formatDoubleTrailerStopSequence,
    getDoubleTrailerLabels,
    displayDoubleTrailerButton,
    getStatusColor,
} from '../DataModels';
import * as DataModels from '../DataModels';
import {
    assignTripFormMock,
    assignTripReqMock,
    cmsConfigMock,
    loadInfoMock,
    tripDataMock,
    tripListMock,
    equipmentAndTransitDetail,
} from './mocks/AssignTrip.mock';
import { getMarketSettings } from '../../../utils/MarketSettings';
import * as commonUtils from '../../../utils/CommonUtils';
import {
    resourceAssignPayloadMock,
    resourceAssignReqMock,
    selectedTripMock,
    equipmentAPIErrorMock,
    equipmentsOfSelectedCarrier,
    equipmentAPIErrorWithValidResourceAssmnt,
    selectedTripMockWithChargeLoc,
    selectedTripWithUpdateDestionationMock,
    tripMockWithChildPlanStops,
    tripWithBillOfLadingInLoads,
} from './mocks/WorkloadAssignment.mock';
import {
    planDataMock,
    driverInfo,
    equiInfo,
    tarrifInfo,
    carrierCodesMock,
    pTripDataMock,
    equiInfoTrailer,
    plansPreviewMock,
    planRowListMock,
    tripsAllDetailsMock,
    transformedPlanListWithSealsAndInvoice,
    transformedPlanListWithoutSealsAndInvoice,
    transformedPlanMock,
} from './mocks/TripManagementSummary.mock';
import {
    workLoadModel,
    driverEqpData,
    equipmTractorMock,
    equipmentTrailerMock,
    equipmentLoadCountListMock,
    paramsForForceToDeleverActionRequest,
    transformedParamsForForceToDeleverActionRequest,
    planDetailsMock,
    transformedPlanFieldsForLoads,
    formValue,
    allowedFilters,
    columnHeadersInAssignTripPlanningTab,
    columnHeadersInSummaryPlanningTab,
    columnHeadersInProcessingTab,
    staticDataForIntermediateLocation,
    locationIdsList,
    transformedTripForUpdateDestination,
    formatUpdateTimeLineDataResponseMock,
    formatUpdateTimeLineLoadPayLoadMock,
    formatUpdateTimeLineTripPayLoadMock,
    columnHeadersInDispatchAndTransitTab,
    columnHeadersInProcessingTabWithMode,
    staticDataEquipmentTypeListMX,
    mockStopSequence,
    mockDoubleTrailerPlans,
    doubleTrailerPayloadMock,
    staticDataEquipmentTypeListCL,
    mockDoubleTrailerLabels,
    displayDoubleTrailerButtonData,
    checkedRows,
    billOfLadingWorkLoadAssignmentMock,
    trailerInfo,
    carrierCodeMock,
    emptyCarrierCodeMock,
} from './mocks/DataModels.mock';
import TripSharedService from '../../../service/TripSharedService';
import { planTableHeadCells } from '../../../Constants';

const shortTimezoneSpy = jest.spyOn(commonUtils, 'getShortTimezoneAbbr').mockImplementation();

describe('Data Models test', () => {
    it('should return correct carrier assignment request data for gt', () => {
        const carrierAssignmentRequest = getCarrierAssignRequest({ autoAccept: true }, null, null, null);
        expect(carrierAssignmentRequest.carrier.autoAccept).toEqual(true);
    });
    it('should return correct carrier assignment request data for cl', () => {
        const carrierAssignmentRequest = getCarrierAssignRequest({}, null, null, null);
        expect(carrierAssignmentRequest.carrier.autoAccept).not.toBeDefined();
    });
    it('should return selected trip info', () => {
        const tripInfo = getSelectedTripInfo('30001005', tripListMock);
        expect(tripInfo).toEqual(tripDataMock);
    });
    it('should return formatted data for trip summary table', () => {
        const pageBehaviour = getMarketSettings('cl');
        const planResponseList = {
            payload: [...plansPreviewMock.payload.planResponseList],
        };
        const tData = formatResponseForTableData(planResponseList, pageBehaviour);
        expect(tData.length).toEqual(3);
    });

    describe('getPlanLabel() - To get plan label for displaying exception count in each tabs', () => {
        it('getPlanLabel() - return plan label if isOnlyLoad true and exceptionCount is one', () => {
            const phaseStatusCount = {
                isOnlyLoads: true,
                exceptionCount: 1,
            };
            expect(getPlanLabel(phaseStatusCount, (a) => a)).toEqual('exception.load');
        });
        it('getPlanLabel() - return plan label if isOnlyLoad true and exceptionCount is greater than one', () => {
            const phaseStatusCount = {
                isOnlyLoads: true,
                exceptionCount: 2,
            };
            expect(getPlanLabel(phaseStatusCount, (a) => a)).toEqual('exception.loads');
        });
        it('getPlanLabel() - return plan label if isOnlyLoad false and exceptionCount is one', () => {
            const phaseStatusCount = {
                isOnlyLoads: false,
                exceptionCount: 1,
            };
            expect(getPlanLabel(phaseStatusCount, (a) => a)).toEqual('exception.plan');
        });
        it('getPlanLabel() -  return plan label if isOnlyLoad false and exceptionCount is greater than one', () => {
            const phaseStatusCount = {
                isOnlyLoads: false,
                exceptionCount: 2,
            };
            expect(getPlanLabel(phaseStatusCount, (a) => a)).toEqual('exception.plans');
        });
    });

    describe('getWorkloadAssignmentLabels() - To get workload assignment labels', () => {
        it('getWorkloadAssignmentLabels() - should return workload assignment labels', () => {
            expect(getWorkloadAssignmentLabels({}, (a) => a)).toEqual({
                modalTitle: 'workloadAssignment.title.modalTitle',
                carrier: 'workloadAssignment.label.carrier',
                infoCarrier: 'workloadAssignment.label.infoCarrier',
                equipmentType: 'workloadAssignment.label.equipmentType',
                driver: 'workloadAssignment.label.driver',
                trailerTractor: 'workloadAssignment.label.trailerTractor',
                truck: 'workloadAssignment.label.truck',
                carrierAssignDriver: 'workloadAssignment.label.carrierAssignDriver',
                titleTrailerDetails: 'workloadAssignment.label.titleTrailerDetails',
                trailerAssignment: 'workloadAssignment.label.trailerAssignment',
                trailer: 'workloadAssignment.label.trailer',
                load: 'workloadAssignment.label.load',
                originLocation: 'workloadAssignment.label.originLocation',
                destinationLocation: 'workloadAssignment.label.destinationLocation',
                buttonCancel: 'workloadAssignment.label.buttonCancel',
                buttonAssignManually: 'workloadAssignment.label.buttonAssignManually',
                singleTrailer: 'workloadAssignment.label.singleTrailer',
                onLoadCount: 'workloadAssignment.label.onLoadCount',
                tractor: 'workloadAssignment.label.tractor',
                containerId: 'workloadAssignment.label.containerId',
                dolly: 'workloadAssignment.label.dolly',
                billOfLading: 'workloadAssignment.label.billOfLading',
                billOfLadingError: 'workloadAssignment.label.billOfLadingError',
                cargo: 'workloadAssignment.label.cargoVan',
                car: 'workloadAssignment.label.car',
            });
        });

        it('getWorkloadAssignmentLabels() - should return label chasis when the flag is on', () => {
            expect(getWorkloadAssignmentLabels({ useLabelChasisForTruck: true }, (a) => a).truck).toEqual(
                'workloadAssignment.label.chasis',
            );
        });

        it('getWorkloadAssignmentLabels() - should return label truck when the flag is off', () => {
            expect(getWorkloadAssignmentLabels({ useLabelChasisForTruck: false }, (a) => a).truck).toEqual(
                'workloadAssignment.label.truck',
            );
        });
    });

    it('getCALabels() - should return CALables', () => {
        expect(getCALabels((a) => a)).toEqual({
            recommended: 'wl.label.recommended',
            enterScac: 'wl.label.enterScac',
            title: 'wl.label.title',
            selectionType: 'wl.label.selectionType',
            selectCarrier: 'wl.label.selectCarrier',
            selectCarrierHelperText: 'wl.label.selectCarrierHelperText',
            cancel: 'wl.label.cancel',
            assign: 'wl.label.assign',
        });
    });
    it('getFilteredColumnHeaders() - should return filtered column headers when tabIndex is 0 (for planning) & isAssigntrip is true', () => {
        expect(getFilteredColumnHeaders(0, planTableHeadCells, true).map((col) => col.id)).toEqual(
            columnHeadersInAssignTripPlanningTab,
        );
    });

    it('getFilteredColumnHeaders() - should return filtered column headers when tabIndex is 0 (planning) &  isAssigntrip is false', () => {
        expect(getFilteredColumnHeaders(0, planTableHeadCells, false).map((col) => col.id)).toEqual(
            columnHeadersInSummaryPlanningTab,
        );
    });

    it('getFilteredColumnHeaders() - should return filtered column headers when tabIndex is 1 (processing)', () => {
        expect(getFilteredColumnHeaders(1, planTableHeadCells, '').map((col) => col.id)).toEqual(
            columnHeadersInProcessingTab,
        );
    });

    it('getFilteredColumnHeaders() - should not return mode as in the column header variable even when the flag is true when it is planning', () => {
        expect(
            getFilteredColumnHeaders(0, planTableHeadCells, false, { showModeColumnInTripSummary: true }).map(
                (col) => col.id,
            ),
        ).toEqual(columnHeadersInSummaryPlanningTab);
    });
    it('getFilteredColumnHeaders() - should return mode as in the column header variable when the flag is true when it is processing', () => {
        expect(
            getFilteredColumnHeaders(1, planTableHeadCells, '', { showModeColumnInTripSummary: true }).map(
                (col) => col.id,
            ),
        ).toEqual(columnHeadersInProcessingTabWithMode);
    });
    it('getFilteredColumnHeaders() - should not return mode as in the column header variable when the flag is false when it is processing', () => {
        expect(
            getFilteredColumnHeaders(1, planTableHeadCells, '', { showModeColumnInTripSummary: false }).map(
                (col) => col.id,
            ),
        ).toEqual(columnHeadersInProcessingTab.filter((cell) => cell !== 'mode'));
    });

    it('getFilteredColumnHeaders() - should not return mode as in the column header variable when the flag is false when it is dispatch/transit', () => {
        expect(
            getFilteredColumnHeaders(2, planTableHeadCells, false, { showModeColumnInTripSummary: false }).map(
                (col) => col.id,
            ),
        ).toEqual(columnHeadersInDispatchAndTransitTab.filter((cell) => cell !== 'mode'));
    });

    it('getSelectedRowsText() - should return checked rows label(trip/s selected or load/s selected) in the table action header when a trip/load is selected', () => {
        expect(getSelectedRowsText(true, [1], (a) => a)).toEqual('planTable.tripSelected');
        expect(getSelectedRowsText(true, [1, 2], (a) => a)).toEqual('planTable.tripsSelected');
        expect(getSelectedRowsText(false, [1], (a) => a)).toEqual('planTable.loadSelected');
        expect(getSelectedRowsText(false, [1, 2], (a) => a)).toEqual('planTable.loadsSelected');
    });

    it('displayHeaderLabel() - should return header coulmn label', () => {
        const config = {
            UOM: {
                weight: 'KG',
            },
        };
        expect(displayHeaderLabel('planColumns.origin', config, 0, (a) => a)).toEqual('planColumns.origin');
        expect(displayHeaderLabel('planColumns.weight', config, 2, (a) => a)).toEqual('planColumns.weight (KG)');
    });

    describe('getCountData - To get plan data count', () => {
        it('getCountData() - should return plan data count if the flag is on and no search provided', () => {
            expect(getCountData('', 10, 12, { showTotalCount: true })).toEqual(10);
        });

        it('getCountData() - should return plan data count if the flag is on and search provided', () => {
            expect(getCountData('s', 10, 12, { showTotalCount: true })).toEqual(12);
        });

        it('getCountData() - should return plan data count if the flag is off', () => {
            expect(getCountData('', 10, 12, { showTotalCount: false })).toEqual(12);
        });
    });

    describe('getFilteredRows - To get filtered plan row list', () => {
        it('getFilteredRows() - should return filtered rows if no search is given', () => {
            expect(getFilteredRows('', planRowListMock, ['planId']).map((plan) => plan.planId)).toEqual([
                '50003013',
                '50003018',
                '50003019',
            ]);
        });
        it('getFilteredRows() - should return filtered rows if search is given', () => {
            expect(getFilteredRows('50003013', planRowListMock, ['planId']).map((plan) => plan.planId)).toEqual([
                '50003013',
            ]);
        });
    });

    describe('getPaginatedRows - To get paginated plan row list', () => {
        it('getPaginatedRows() - should return paginated rows if rows count  less than pagination count(rowsPerPage)', () => {
            expect(getPaginatedRows(planRowListMock, 1, { rowsPerPage: 4 }).length).toEqual(3);
        });
        it('getPaginatedRows() - should return paginated rows if rows count greater than pagination count(rowsPerPage)', () => {
            expect(getPaginatedRows(planRowListMock, 1, { rowsPerPage: 1 }).length).toEqual(1);
        });
    });

    it('getFooterLabels() - should return footer labels', () => {
        expect(getFooterLabels((a) => a)).toEqual({ previous: 'button.previous', next: 'button.next' });
    });

    describe('getTransformedPlansList() - To get transformed plan list', () => {
        it('getTransformedPlansList() - should return transformed plan list fields when the selected tab is Planning - Market CL', () => {
            expect(
                Object.keys(
                    getTransformedPlansList(
                        0,
                        [{ ...selectedTripMock, planWorkflowPhase: { name: 'PLANNING' } }],
                        {},
                        {},
                        'cl',
                        {},
                        { showCLColumns: true },
                        (a) => a,
                    )[0],
                ),
            ).toEqual(transformedPlanFieldsForLoads);
        });

        it('getTransformedPlansList() - should return transformed plan list fields  when the selected tab is Planning - Market CA', () => {
            expect(
                Object.keys(
                    getTransformedPlansList(
                        0,
                        [{ ...selectedTripMock }],
                        {},
                        {},
                        'ca',
                        {},
                        { showCAColumns: true },
                        (a) => a,
                    )[0],
                ),
            ).toEqual(transformedPlanFieldsForLoads);
        });

        it('getTransformedPlansList() - should return transformed unplanned loads when the selected tab is Planning- Market CL', () => {
            expect(
                getTransformedPlansList(
                    0,
                    [
                        {
                            ...selectedTripMock,
                            planId: '50005899',
                            planEntity: 'LOAD',
                            planWorkflowPhase: { name: 'UNPLANNED' },
                            planStatus: { name: 'UNPLANNED' },
                        },
                        {
                            ...selectedTripMock,
                            planId: '50005819',
                            planEntity: 'LOAD',
                            planWorkflowPhase: { name: 'PLANNED' },
                            planStatus: { name: 'PLANNED' },
                        },
                    ],
                    {},
                    {},
                    'cl',
                    {},
                    { showCLColumns: true },
                    (a) => a,
                ).map((item) => item.planId),
            ).toEqual(['50005899']);
        });

        it('getTransformedPlansList() - should return transformed planned trips when the selected tab is Processing- Market CL', () => {
            expect(
                getTransformedPlansList(
                    0,
                    [
                        {
                            ...selectedTripMock,
                            planId: '30005899',
                            planEntity: 'TRIP',
                            planWorkflowPhase: { name: 'UNPLANNED' },
                            planStatus: { name: 'UNPLANNED' },
                        },
                        {
                            ...selectedTripMock,
                            planId: '30005819',
                            planEntity: 'TRIP',
                            planWorkflowPhase: { name: 'PLANNING' },
                            planStatus: { name: 'PLANNING' },
                        },
                    ],
                    {},
                    {},
                    'cl',
                    {},
                    { showCLColumns: true },
                    (a) => a,
                ).map((item) => item.planId),
            ).toEqual(['30005819']);
        });

        it('getTransformedPlansList() - should return transformed trips when the selected tab is Processing- Market CL', () => {
            expect(
                getTransformedPlansList(
                    1,
                    [
                        {
                            ...selectedTripMock,
                            planId: '30005899',
                            planEntity: 'TRIP',
                            planWorkflowPhase: { name: 'PROCESSING' },
                            planStatus: { name: 'PROCESSING' },
                        },
                        {
                            ...selectedTripMock,
                            planId: '30005819',
                            planEntity: 'TRIP',
                            planWorkflowPhase: { name: 'PLANNING' },
                            planStatus: { name: 'PLANNING' },
                        },
                    ],
                    {},
                    {},
                    'cl',
                    {},
                    { showCLColumns: true },
                    (a) => a,
                ).map((item) => item.planId),
            ).toEqual(['30005899']);
        });

        it('getTransformedPlansList() - should return transformed trips when the selected tab is Planning- Market CA', () => {
            expect(
                Object.keys(
                    getTransformedPlansList(
                        1,
                        [{ ...selectedTripMock }],
                        {},
                        {},
                        'ca',
                        {},
                        { showCAColumns: true },
                        (a) => a,
                    )[0],
                ),
            ).toEqual(transformedPlanFieldsForLoads);
        });

        it('getTransformedPlansList() - should return transformed trips when the selected tab is Dispatch Pending- Market CL', () => {
            expect(
                getTransformedPlansList(
                    2,
                    [
                        {
                            ...selectedTripMock,
                            planId: '30005899',
                            planEntity: 'TRIP',
                            planWorkflowPhase: { name: 'DISPATCH' },
                            planStatus: { name: 'DISPATCH' },
                        },
                        {
                            ...selectedTripMock,
                            planId: '30005819',
                            planEntity: 'TRIP',
                            planWorkflowPhase: { name: 'DISPATCH' },
                            planStatus: { name: 'DISPATCH' },
                        },
                    ],
                    {},
                    {},
                    'cl',
                    {},
                    { showCLColumns: true },
                    (a) => a,
                ).map((item) => item.planId),
            ).toEqual(['30005899', '30005819']);
        });

        it('getTransformedPlansList() - should return transformed trips when the selected tab is Dispatch Pending- Market CA', () => {
            expect(
                Object.keys(
                    getTransformedPlansList(
                        2,
                        [{ ...selectedTripMock }],
                        {},
                        {},
                        'ca',
                        {},
                        { showCAColumns: true },
                        (a) => a,
                    )[0],
                ),
            ).toEqual(transformedPlanFieldsForLoads);
        });

        it('getTransformedPlansList() - should return transformed trips when the selected tab is Dispatch Pending- Market CL', () => {
            expect(
                getTransformedPlansList(
                    3,
                    [
                        {
                            ...selectedTripMock,
                            planId: '30005899',
                            planEntity: 'TRIP',
                            planWorkflowPhase: { name: 'IN_TRANSIT' },
                            planStatus: { name: 'IN_TRANSIT' },
                        },
                        {
                            ...selectedTripMock,
                            planId: '30005819',
                            planEntity: 'TRIP',
                            planWorkflowPhase: { name: 'DISPATCH' },
                            planStatus: { name: 'DISPATCH' },
                        },
                    ],
                    {},
                    {},
                    'cl',
                    {},
                    { showCLColumns: true },
                    (a) => a,
                ).map((item) => item.planId),
            ).toEqual(['30005899']);
        });

        it('getTransformedPlansList() - should return transformed trips when the selected tab is Dispatch Pending- Market CA', () => {
            expect(
                Object.keys(
                    getTransformedPlansList(
                        3,
                        [{ ...selectedTripMock }],
                        {},
                        {},
                        'ca',
                        {},
                        { showCAColumns: true },
                        (a) => a,
                    )[0],
                ),
            ).toEqual(transformedPlanFieldsForLoads);
        });
    });

    describe('displayAssignToTripButton() - To display AssignToTrip button in the table action header', () => {
        const transformedPlansList = [{ planId: '50005899', loadType: 'STR' }];
        it('displayAssignToTripButton() - should return false if no rows selected', () => {
            expect(displayAssignToTripButton([], transformedPlansList, {})).toEqual(false);
        });

        it('displayAssignToTripButton() - should hide AssignToTrip button when the flag is on', () => {
            expect(
                displayAssignToTripButton(['50005899'], transformedPlansList, { hideAssignToTripForSTRLoad: true }),
            ).toEqual(false);
        });

        it('displayAssignToTripButton() - should display AssignToTrip button when the flag is off', () => {
            expect(
                displayAssignToTripButton(['50005899'], transformedPlansList, { hideAssignToTripForSTRLoad: false }),
            ).toEqual(true);
        });

        it('displayAssignToTripButton() - should hide AssignToTrip button when two trips are selected and flag is off', () => {
            expect(
                displayAssignToTripButton(['50005899', '50005900'], transformedPlansList, {
                    showAssignTripForDoubleTrailer: false,
                }),
            ).toEqual(false);
        });

        it('displayAssignToTripButton() - should display AssignToTrip button when two trips are selected and flag is on', () => {
            expect(
                displayAssignToTripButton(
                    ['50005899', '50005900'],
                    [transformedPlansList[0], { ...transformedPlansList[0], planId: '50005900' }],
                    { showAssignTripForDoubleTrailer: true },
                ),
            ).toEqual(true);
        });
        it('displayAssignToTripButton() - should hide AssignToTrip button when two trips are selected and load type are different', () => {
            expect(
                displayAssignToTripButton(
                    ['50005899', '50005900'],
                    [transformedPlansList[0], { planId: '50005900', loadType: 'PLT' }],
                    { showAssignTripForDoubleTrailer: true },
                ),
            ).toEqual(false);
        });
    });

    it('displayConfirmButton() - should display the confirm button when the carrier status of the selected trip is assigned', () => {
        const planList = [{ planId: 30002345, carrierStatus: 'Assigned' }];
        expect(displayConfirmButton([30002345], planList)).toEqual(true);
    });

    it('displayConfirmButton() - should not display the confirm button when the carrier status of the selected trip is not assigned', () => {
        const planList = [{ planId: 30002345, carrierStatus: 'Unassigned' }];
        expect(displayConfirmButton([30002345], planList)).toEqual(false);
    });

    it('getWorkLoadEditData() - should return workload assignment data for edit', () => {
        expect(getWorkLoadEditData(planDetailsMock, (a) => a)).toEqual({
            carrier: '238',
            equipmentType: 'workloadAssignment.label.trailerTractor',
            driver: '12345692',
            tractor: 'sdu25r',
            truck: 'sdu25r',
            trailerAssignmentType: 'label.singleTrailer',
            trailer: 'GRDL97-WM',
        });
    });

    it('getTrailerAssignmentTypes() - should return trailer assignment types', () => {
        expect(getTrailerAssignmentTypes((a) => a)).toEqual([
            { id: 0, value: 'singleTrailer', label: 'label.singleTrailer' },
            { id: 1, value: 'onLoadCount', label: 'label.onLoadCount' },
        ]);
    });

    it('formatLoadEqpPair() - should return load equipment pair', () => {
        const mockLoads = [
            { equipmentId: 'EQ-01', planId: '30004532' },
            { equipmentId: 'EQ-02', planId: '30004533' },
        ];
        expect(formatLoadEqpPair(mockLoads)).toEqual({ 30004532: 'EQ-01', 30004533: 'EQ-02' });
    });

    it('getLabelWithUOM() - should return label with UOM', () => {
        const mockConfig = { UOM: { cube: 5, weight: 3, distance: 4 } };
        expect(getLabelWithUOM('planColumns.cases', mockConfig, (a) => a)).toEqual('planColumns.cases');
        expect(getLabelWithUOM('planColumns.pallets', mockConfig, (a) => a)).toEqual('planColumns.pallets');
        expect(getLabelWithUOM('planColumns.cube', mockConfig, (a) => a)).toEqual('planColumns.cube (5)');
        expect(getLabelWithUOM('planColumns.weight', mockConfig, (a) => a)).toEqual('planColumns.weight (3)');
        expect(getLabelWithUOM('planColumns.distance', mockConfig, (a) => a)).toEqual('planColumns.distance (4)');
    });

    describe('getEquipmentTypeSeg() - To get equipment type segment', () => {
        it('getEquipmentTypeSeg() - should return equipment type label if type is TRACTOR', () => {
            expect(getEquipmentTypeSeg('TRACTOR', (a) => a)).toEqual('workloadAssignment.label.trailerTractor');
        });

        it('getEquipmentTypeSeg() - should return equipment type label if type is TRUCK', () => {
            expect(getEquipmentTypeSeg('TRUCK', (a) => a)).toEqual('workloadAssignment.label.truck');
        });

        it('getEquipmentTypeSeg() - should return default equipment type', () => {
            expect(getEquipmentTypeSeg('', (a) => a)).toEqual('workloadAssignment.label.trailerTractor');
        });
    });

    describe('getTrailerAssignSeg() - To get trailer assignment details', () => {
        let childLoads = [
            { equipmentId: 'EQ-01', planId: '30004532' },
            { equipmentId: 'EQ-01', planId: '30004533' },
        ];
        it('getTrailerAssignSeg() - should return trailer assignment details if all trailer is same', () => {
            expect(getTrailerAssignSeg(childLoads, (a) => a)).toEqual({
                trailer: 'EQ-01',
                trailerAssignmentType: 'label.singleTrailer',
            });
        });

        it('getTrailerAssignSeg() - should return trailer assignment details if all trailer is not same', () => {
            childLoads = [{ ...childLoads[0] }, { ...childLoads[1], equipmentId: 'EQ-02' }];
            expect(getTrailerAssignSeg(childLoads, (a) => a)).toEqual({
                loads: { 30004532: 'EQ-01', 30004533: 'EQ-02' },
                trailerAssignmentType: 'label.onLoadCount',
            });
        });
    });

    describe('getEquipmentTypes() - To get equipment types', () => {
        it('getEquipmentTypes() - should return equipment types', () => {
            expect(getEquipmentTypes({}, (a) => a)).toEqual([
                { id: 0, label: 'workloadAssignment.label.trailerTractor', value: 'trailerTractor' },
                { id: 1, label: 'workloadAssignment.label.truck', value: 'truck' },
            ]);
        });
        it('getEquipmentTypes() - should return label for truck is chasis when the flag is on', () => {
            expect(getEquipmentTypes({ useLabelChasisForTruck: true }, (a) => a)[1].label).toEqual(
                'workloadAssignment.label.chasis',
            );
        });
        it('getEquipmentTypes() - should return label for truck is truck  when the flag is off', () => {
            expect(getEquipmentTypes({ useLabelChasisForTruck: false }, (a) => a)[1].label).toEqual(
                'workloadAssignment.label.truck',
            );
        });
        it('getEquipmentTypes() - get all equipment types with new types when feature flag is true', () => {
            expect(getEquipmentTypes({ enableNewEquipmentTypes: true }, (a) => a)).toEqual([
                { id: 0, label: 'workloadAssignment.label.trailerTractor', value: 'trailerTractor' },
                { id: 1, label: 'workloadAssignment.label.truck', value: 'truck' },
                { id: 2, label: 'workloadAssignment.label.cargoVan', value: 'cargo' },
                { id: 3, label: 'workloadAssignment.label.car', value: 'car' },
            ]);
        });
    });

    it('getEquipmentsOfSelectedCarrier() - should return equipments of selected carrier', () => {
        expect(getEquipmentsOfSelectedCarrier({}, '76042702')).toEqual({
            trailer: [],
            truck: [],
            tractor: [],
        });
    });

    it('getEquipmentsOfSelectedCarrier() - MX - get equipments of selected carrier with New Types when flag is true', () => {
        expect(getEquipmentsOfSelectedCarrier({}, '76042702', true)).toEqual({
            trailer: [],
            truck: [],
            tractor: [],
            cargo: [],
            car: [],
        });
    });

    it('getWarningMessage() - should return warning message', () => {
        const message = `Driver-1
  Equipment-1
  Trailer-1`;
        expect(
            getWarningMessage({
                driver: 'Driver-1',
                equipment: 'Equipment-1',
                trailer: 'Trailer-1',
            }),
        ).toEqual(message);
    });

    describe('getFormattedEquipmentAPIValidationError() - To get formatted  equipment API validation Error', () => {
        it('getFormattedEquipmentAPIValidationError() - should return formatted  equipment API validation Error', () => {
            expect(getFormattedEquipmentAPIValidationError(equipmentAPIErrorMock)).toEqual('Bad Request ');
        });

        it('getFormattedEquipmentAPIValidationError() - should return the given input error if the error response has valid resource assignment', () => {
            expect(getFormattedEquipmentAPIValidationError(equipmentAPIErrorWithValidResourceAssmnt)).toEqual(
                equipmentAPIErrorWithValidResourceAssmnt,
            );
        });
    });

    describe('getTrailerErrorList() - To get trailer error list', () => {
        let workloadAssignmentData = {
            equipmentType: 'Truck',
            truck: 'TRUCK-1',
        };
        const equipmentTypes = [{ label: 'Tractor' }, { label: 'Truck' }];
        let equipmentDetails = {
            equipmentInfo: null,
            equipmentsOfSelectedCarrier,
            equipmentTypes,
        };
        const trailerDetails = {
            trailerAssgnmntTypes: [
                { id: 0, value: 'singleTrailer', label: 'Single Trailer' },
                { id: 1, value: 'onLoadCount', label: 'on Load Count' },
            ],
            trailerInfo: [],
        };
        it('getTrailerErrorList() - should return trailer error list if equipmentInfo is null and equipmentType is truck', () => {
            expect(getTrailerErrorList(workloadAssignmentData, equipmentDetails, {})).toEqual(['TRUCK-1']);
        });

        it('getTrailerErrorList() - should return trailer error list if equipmentInfo is null and equipmentType is tractor', () => {
            expect(
                getTrailerErrorList({ equipmentType: 'Tractor', tractor: 'TRACTOR-1' }, equipmentDetails, {}),
            ).toEqual(['TRACTOR-1']);
        });

        it('getTrailerErrorList() - should return trailer error list if equipmentInfo is not null and trailerAssignmentType is on Load Count', () => {
            equipmentDetails = {
                equipmentInfo: 'EQ-01',
                equipmentsOfSelectedCarrier,
                equipmentTypes,
            };
            workloadAssignmentData = {
                trailerAssignmentType: 'on Load Count',
                equipmentType: 'Tractor',
                loads: ['TRAILER-1'],
            };
            expect(getTrailerErrorList(workloadAssignmentData, equipmentDetails, trailerDetails)).toEqual([
                'TRAILER-1',
            ]);
        });

        it('getTrailerErrorList() - should return trailer error list if equipmentInfo is not null and trailerAssignmentType is Single Trailer', () => {
            workloadAssignmentData = {
                trailerAssignmentType: 'Single Trailer',
                equipmentInfo: 'EQ-01',
                equipmentType: 'Tractor',
                loads: ['TRAILER-1'],
                trailer: 'TRAILER-1',
            };
            equipmentDetails = {
                equipmentInfo: 'EQ-01',
                equipmentsOfSelectedCarrier,
                equipmentTypes,
            };
            expect(getTrailerErrorList(workloadAssignmentData, equipmentDetails, trailerDetails)).toEqual([
                'TRAILER-1',
            ]);
        });
    });

    describe('Should return request payload for assign trip', () => {
        let cmsConfig = {
            cmsConfig: {
                ...cmsConfigMock,
                defaultOlsenTimezoneId: 'America/Guatemala',
            },
            currentMarket: 'gt',
            featureFlags: {
                includeTransitEquipmentInLoad: true,
                enableShortTimezone: true,
                provenanceTimezone: true,
            },
        };
        const tripAndLoadInfo = {
            tripData: tripDataMock,
            sLoadInfo: loadInfoMock,
            selectedTripId: '30001005',
        };
        const connectionLoadInfo = {
            formData: assignTripFormMock,
            TransitAndEquipmentDetail: equipmentAndTransitDetail,
        };

        const config = {
            market: 'gt',
            staticData: {},
            featureFlags: cmsConfig.featureFlags,
            config: cmsConfig,
        };

        const trans = jest.fn();
        it('should call getShortTimezoneAbbr if short timezone is disabled', () => {
            shortTimezoneSpy.mockClear();
            const configuration = {
                ...config,
                featureFlags: {
                    enableShortTimezone: false,
                    provenanceTimezone: false,
                },
            };
            transformPlanPreviewData({}, trans, configuration);
            expect(shortTimezoneSpy).not.toHaveBeenCalled();
        });

        it('should call getShortTimezoneAbbr if short timezone enabled', () => {
            shortTimezoneSpy.mockClear();
            transformPlanPreviewData({}, trans, config);
            expect(shortTimezoneSpy).toHaveBeenCalledTimes(2);
        });

        it('should return request payload for DHD loads', () => {
            const connectLoad = {
                ...connectionLoadInfo,
                formData: {
                    ...connectionLoadInfo.formData,
                    connectLoad: 'DHD',
                },
            };
            const assignTripReq = formatAssignTripReq(tripAndLoadInfo, cmsConfig, connectLoad);
            expect(assignTripReq.payload[0].plans[0].transitDetail).toBeDefined();
            expect(assignTripReq.payload[0].plans[0].equipment).toBeDefined();
        });

        it('should return request payload for BOB loads', () => {
            const assignTripReq = formatAssignTripReq(tripAndLoadInfo, cmsConfig, connectionLoadInfo);
            expect(assignTripReq).toEqual(assignTripReqMock);
        });

        it('should return request payload for other markets', () => {
            cmsConfig = {
                ...cmsConfig,
                currentMarket: 'cl',
                featureFlags: { includeTransitEquipmentInLoad: false },
            };
            let assignTripReq = formatAssignTripReq(tripAndLoadInfo, cmsConfig, connectionLoadInfo);
            expect(assignTripReq.payload[0].plans[0].transitDetail).toBeUndefined();
            expect(assignTripReq.payload[0].plans[0].equipment).toBeUndefined();
            expect(assignTripReq.payload[0].plans[0].locations.destination.locationName).toBeUndefined();
            expect(assignTripReq.payload[0].plans[0].locations.origin.locationName).toBeUndefined();

            const connectLoad = {
                ...connectionLoadInfo,
                formData: {
                    ...connectionLoadInfo.formData,
                    connectLoad: 'DHD',
                },
            };
            assignTripReq = formatAssignTripReq(tripAndLoadInfo, cmsConfig, connectLoad);
            expect(assignTripReq.payload[0].plans[0].transitDetail).toBeUndefined();
            expect(assignTripReq.payload[0].plans[0].equipment).toBeUndefined();
            expect(assignTripReq.payload[0].plans[0].locations.destination.locationName).toBeUndefined();
            expect(assignTripReq.payload[0].plans[0].locations.origin.locationName).toBeUndefined();
        });

        it('should return timezone details in payload if featureFlag includeTimeZoneIdInConnectingLoads is set', () => {
            cmsConfig = {
                ...cmsConfig,
                currentMarket: 'gt',
                featureFlags: { includeTimeZoneIdInConnectingLoads: true },
            };

            const tripLoadInfo = {
                tripData: {
                    ...tripDataMock,
                    originOlsenTimezoneId: 'America/Guatemala',
                    destinationOlsenTimezoneId: 'America/Guatemala',
                },
                sLoadInfo: {
                    ...loadInfoMock,
                },
                selectedTripId: '30001005',
            };
            const assignTripReq = formatAssignTripReq(tripLoadInfo, cmsConfig, connectionLoadInfo);
            const locationDetails = assignTripReq.payload[0].plans[0].locations;
            expect(locationDetails.origin.olsenTimezoneId).toBeDefined();
            expect(locationDetails.destination.olsenTimezoneId).toBeDefined();
        });

        it('should return timezone details in payload if featureFlag includeTimeZoneIdInConnectingLoads is reset', () => {
            cmsConfig = {
                ...cmsConfig,
                currentMarket: 'gt',
                featureFlags: { includeTimeZoneIdInConnectingLoads: false },
            };
            const assignTripReq = formatAssignTripReq(tripAndLoadInfo, cmsConfig, connectionLoadInfo);
            const locationDetails = assignTripReq.payload[0].plans[0].locations;
            expect(locationDetails.origin.olsenTimezoneId).toBeUndefined();
            expect(locationDetails.destination.olsenTimezoneId).toBeUndefined();
        });
        describe('request payload for assign trip', () => {
            const connectLoad = {
                ...connectionLoadInfo,
                formData: {
                    ...connectionLoadInfo.formData,
                    connectLoad: 'DHD',
                },
            };
            const configForChargeLocation = {
                ...cmsConfig,
                featureFlags: {
                    enableChargeLocAssignmentForFillerMoves: true,
                },
            };
            const tripAndLoadInfoWithChargeLoc = {
                ...tripAndLoadInfo,
                sLoadInfo: {
                    ...tripAndLoadInfo.sLoadInfo,
                    chargeLocation: {
                        locationId: 23,
                        locationType: 'STORE',
                        countryCode: 'MX',
                    },
                },
            };
            it('should return request payload with charge Location if feature flag is enabled', () => {
                const assignTripReq = formatAssignTripReq(
                    tripAndLoadInfoWithChargeLoc,
                    configForChargeLocation,
                    connectLoad,
                );
                expect(assignTripReq.payload[0].plans[0].locations.chargeLocation).toBeDefined();
            });
            it('should return request payload without charge Location if feature flag is disabled', () => {
                const configForChargeLocationDisable = {
                    ...configForChargeLocation,
                    featureFlags: {
                        enableChargeLocAssignmentForFillerMoves: false,
                    },
                };
                const assignTripReq = formatAssignTripReq(
                    tripAndLoadInfoWithChargeLoc,
                    configForChargeLocationDisable,
                    connectLoad,
                );
                expect(assignTripReq.payload[0].plans[0].locations.chargeLocation).toBeUndefined();
            });
            it('should return request payload without charge Location if load has no charge location ', () => {
                const assignTripReq = formatAssignTripReq(tripAndLoadInfo, configForChargeLocation, connectLoad);
                expect(assignTripReq.payload[0].plans[0].locations.chargeLocation).toBeUndefined();
            });
            it('should return request payload for double load assignment with DHD', () => {
                const doubleTripAndLoadInfo = {
                    ...tripAndLoadInfo,
                    sLoadInfo: {
                        filteredPlans: [
                            loadInfoMock,
                            {
                                ...loadInfoMock,
                                planId: '500009923',
                            },
                        ],
                    },
                };
                const assignTripReq = formatAssignTripReq(
                    doubleTripAndLoadInfo,
                    configForChargeLocation,
                    connectLoad,
                    true,
                );
                expect(assignTripReq.payload[0].plans.length).toEqual(4);
            });
            it('should return request payload for double load assignment with BOB', () => {
                const connectLoadBOB = {
                    ...connectionLoadInfo,
                    formData: {
                        ...connectionLoadInfo.formData,
                        connectLoad: 'BOB',
                    },
                };
                const doubleTripAndLoadInfo = {
                    ...tripAndLoadInfo,
                    sLoadInfo: {
                        filteredPlans: [
                            loadInfoMock,
                            {
                                ...loadInfoMock,
                                planId: '500009923',
                            },
                        ],
                    },
                };
                const assignTripReq = formatAssignTripReq(
                    doubleTripAndLoadInfo,
                    configForChargeLocation,
                    connectLoadBOB,
                    true,
                );
                expect(assignTripReq.payload[0].plans.length).toEqual(3);
            });
        });
    });

    it('isAllLoadsHaveChargeLocation() - should return true if all loads have charge location', () => {
        expect(isAllLoadsHaveChargeLocation([{ ...tripsAllDetailsMock[0].plans[0] }])).toEqual(true);
    });

    it('isAllLoadsHaveChargeLocation() - should return false if all loads do not have charge location', () => {
        expect(isAllLoadsHaveChargeLocation(tripsAllDetailsMock[0].plans)).toEqual(false);
    });

    it('getTripsWithChargeLocValidation() - should return trip info with allLoadsHaveChargeLocAdded is false if all loads do not have charge location', () => {
        expect(getTripsWithChargeLocValidation(tripsAllDetailsMock, ['3000768'])).toEqual([
            {
                allLoadsHaveChargeLocAdded: false,
                loadsWithoutChargeLoc: ['5000678'],
                planId: '3000768',
            },
        ]);
    });

    it('getTripsWithChargeLocValidation() - should return trip info  with allLoadsHaveChargeLocAdded is true if all loads have charge location', () => {
        expect(getTripsWithChargeLocValidation(tripsAllDetailsMock, ['3000787'])).toEqual([
            {
                allLoadsHaveChargeLocAdded: true,
                loadsWithoutChargeLoc: [],
                planId: '3000787',
            },
        ]);
    });

    it('transformPlanPreviewData() - should return chargeLocationId if the flag is true', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { validateChargeLocationOnTripDispatch: true },
            config: {},
        };
        const transformedPlanData = transformPlanPreviewData(selectedTripMockWithChargeLoc, (a) => a, config);
        expect(transformedPlanData.plans[0].chargeLocationId).toEqual('657');
    });

    it('transformPlanPreviewData() - should not return chargeLocationId if the flag is false', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { validateChargeLocationOnTripDispatch: false },
            config: {},
        };
        const transformedPlanData = transformPlanPreviewData(selectedTripMockWithChargeLoc, (a) => a, config);
        expect(transformedPlanData.plans[0].chargeLocationId).toBeUndefined();
    });

    it('getFormattedChargeLocError - should return formatted error if loads have no charge location added', () => {
        const tripDetails = {
            loadsWithoutChargeLoc: ['5000678', '500067876'],
            planId: '300876',
        };
        TripSharedService.setTrans((a) => a);
        expect(getFormattedChargeLocError(tripDetails)).toEqual({
            errMessage: 'msg.chargeLocMissingError - 5000678, 500067876',
            planId: '300876',
        });
    });
    it('should return payload with loads in correct display order for GT market', () => {
        const resourceAssignReq = parseResourceAssignRequest(resourceAssignReqMock, selectedTripMock, 'gt');
        expect(resourceAssignReq).toEqual(resourceAssignPayloadMock);
    });

    it('should not call getShortTimezoneAbbr if short timezone disabled', () => {
        const trans = jest.fn();
        const config = {
            market: 'ca',
            staticData: {},
            featureFlags: { enableShortTimezone: false },
            config: {},
        };
        shortTimezoneSpy.mockClear();
        transformPlanPreviewData({}, trans, config);
        expect(shortTimezoneSpy).not.toHaveBeenCalled();
    });

    it('should call getShortTimezoneAbbr if short timezone enabled', () => {
        shortTimezoneSpy.mockClear();
        const trans = jest.fn();
        const config = {
            market: 'ca',
            staticData: {},
            featureFlags: { enableShortTimezone: true },
            config: {},
        };
        transformPlanPreviewData({}, trans, config);
        expect(shortTimezoneSpy).toHaveBeenCalledTimes(2);
    });

    it('should set search request payload to chips for origin and destination location id', () => {
        const data = { payload: { origins: [{ locationId: '6773' }], destinations: [{ locationId: '6771' }] } };
        expect(searchFilterReqPayloadToChips(data)).toEqual(
            expect.arrayContaining([
                {
                    display: '6773',
                    key: 'locationId',
                    source: 'origins',
                    value: '6773',
                },
                {
                    display: '6771',
                    key: 'locationId',
                    source: 'destinations',
                    value: '6771',
                },
            ]),
        );
    });

    it('should provide transformed loads', () => {
        expect(transformLoads(planDataMock)).toEqual(
            expect.arrayContaining([
                {
                    destinationId: '751',
                    destinationType: 'STORE',
                    destinationValue: '',
                    loadId: '50000868',
                    originId: '6001',
                    originType: 'DC',
                    originValue: '',
                    loadType: 'STR',
                    trailerCode: undefined,
                },
            ]),
        );
    });

    it('should provide transformed loads to feed edit trailer when equipment code is undefined', () => {
        expect(transformLoadsToEditTailer(planDataMock)).toEqual(
            expect.arrayContaining([
                {
                    destinationId: '751',
                    destinationType: 'STORE',
                    destinationValue: '',
                    loadId: '50000868',
                    originId: '6001',
                    originType: 'DC',
                    originValue: '',
                    loadType: 'STR',
                    trailerId: undefined,
                    originTypeToIcon: 'dc',
                    destinationTypeToIcon: 'store',
                    equipmentCode: undefined,
                },
            ]),
        );
    });

    it('should provide transformed loads to feed edit trailer', () => {
        planDataMock[0].equipmentCode = 'TSECO';
        expect(transformLoadsToEditTailer(planDataMock)).toEqual(
            expect.arrayContaining([
                {
                    destinationId: '751',
                    destinationType: 'STORE',
                    destinationValue: '',
                    loadId: '50000868',
                    originId: '6001',
                    originType: 'DC',
                    originValue: '',
                    loadType: 'STR',
                    trailerId: undefined,
                    originTypeToIcon: 'dc',
                    destinationTypeToIcon: 'store',
                    equipmentCode: 'TSECO',
                },
            ]),
        );
    });

    it('should provide correct driver response', () => {
        expect(processDriversResponse(driverInfo)).toEqual(
            expect.arrayContaining([{ id: '10023445', name: 'MARIO JARA', value: '10023445-MARIO JARA' }]),
        );
    });
    it('should provide correct equipment response', () => {
        expect(processEquipmentsResponse(equiInfo, tarrifInfo, 'CL')).toEqual(
            expect.arrayContaining([
                { id: 'CTHG59', type: 'TRACTOR', value: 'CTHG59 - TRANSPORTES TRANS-CAVALIERI LIMITAD' },
            ]),
        );
    });
    it('should provide correct equipment response for GT', () => {
        expect(processEquipmentsResponse(equiInfoTrailer, tarrifInfo, 'gt')).toEqual(
            expect.arrayContaining([
                { id: 'CTHG59', type: 'TRAILER', value: 'CTHG59 - TRANSPORTES TRANS-CAVALIERI LIMITAD' },
            ]),
        );
    });

    it('should provide correct equipment driver payload when feature flag is present', () => {
        expect(getEquipmentDriverRequestPayload('CR182021', carrierCodesMock, pTripDataMock.tariffReq, 10398)).toEqual({
            carrierRequest: { mdm_carrier_id: 352 },
            driverRequest: {
                payload: {
                    active: true,
                    driverCompany: ['CR182021'],
                },
            },
            equipmentRequest: {
                max_row: 5000,
                owner: [352],
                status_code: ['A'],
            },
            tariffRequest: {
                carrier_id: 'CR182021',
                destination: { location_id: undefined, location_type_code: undefined },
                equipment_type_code: undefined,
                mode: undefined,
                origin: { location_id: undefined, location_type_code: undefined },
                protection_level: undefined,
                service_level: undefined,
            },
        });
    });

    it('should result equipmentTypeCode value when restrictEquipmentCode feature flag is false/undefined', () => {
        pTripDataMock[0].tariffReq.equipment.equipmentCode = '12345';
        const driverEquipPayload = getEquipmentDriverRequestPayload(
            'CR182021',
            carrierCodesMock,
            pTripDataMock[0].tariffReq,
            { restrictEquipmentCode: false },
        );
        expect(driverEquipPayload.tariffRequest.equipment_type_code).toEqual('12345');
    });

    it('should result equipmentTypeCode as undefined when restrictEquipmentCode feature flag is true', () => {
        pTripDataMock[0].tariffReq.equipment.equipmentCode = '12345';
        const driverEquipPayload = getEquipmentDriverRequestPayload(
            'CR182021',
            carrierCodesMock,
            pTripDataMock[0].tariffReq,
            { restrictEquipmentCode: true },
        );
        expect(driverEquipPayload.tariffRequest.equipment_type_code).toBeUndefined();
    });

    it('should return vendor number in the payload when enableVendorNumber flag is true ', () => {
        TripSharedService.setFeatureFlags({ enableVendorNumber: true });
        const equipmentDriverPayload = getEquipmentDriverRequestPayload('08091994', carrierCodeMock, 'MX', 10398, true);
        expect(equipmentDriverPayload.driverRequest.payload.driverCompany).toEqual(['08091994']);
        expect(equipmentDriverPayload.equipmentRequest.vendor).toEqual(['08091994']);
    });
    it('should not return vendor number in the payload when enableVendorNumber flag is false ', () => {
        TripSharedService.setFeatureFlags({ enableVendorNumber: false });
        const equipmentDriverPayload = getEquipmentDriverRequestPayload('08091994', carrierCodeMock, 'MX', 10398, true);
        expect(equipmentDriverPayload.driverRequest.payload.driverCompany).not.toEqual('08091994');
        expect(equipmentDriverPayload.equipmentRequest.vendor).not.toEqual('08091994');
    });
    it('should not return vendor number in the payload when enableVendorNumber flag is false and carrierCodesMock is empty', () => {
        TripSharedService.setFeatureFlags({ enableVendorNumber: false });
        const equipmentDriverPayload = getEquipmentDriverRequestPayload(
            '08091994',
            emptyCarrierCodeMock,
            'MX',
            10398,
            true,
        );
        expect(equipmentDriverPayload.driverRequest.payload.driverCompany).not.toEqual([]);
        expect(equipmentDriverPayload.equipmentRequest.vendor).not.toEqual([]);
    });

    it('should provide correct equipment driver payload', () => {
        expect(getEquipmentDriverRequestPayload('CR182021', carrierCodesMock, pTripDataMock.tariffReq)).toEqual({
            carrierRequest: { mdm_carrier_id: 352 },
            driverRequest: {
                payload: {
                    active: true,
                    driverCompany: ['CR182021'],
                },
            },
            equipmentRequest: {
                max_row: 5000,
                owner: [352],
                status_code: ['A'],
            },
            tariffRequest: {
                carrier_id: 'CR182021',
                destination: { location_id: undefined, location_type_code: undefined },
                equipment_type_code: undefined,
                mode: undefined,
                origin: { location_id: undefined, location_type_code: undefined },
                protection_level: undefined,
                service_level: undefined,
            },
        });
    });

    it('should not return service level if trip is double trailer trip and feature flag is enabled', () => {
        const doubleTariffReqMock = {
            ...pTripDataMock[0].tariffReq,
            isDouble: true,
        };
        const featureFlag = {
            showCreateTripForDoubleTrailer: true,
        };
        expect(
            getEquipmentDriverRequestPayload('CR182021', carrierCodesMock, doubleTariffReqMock, featureFlag)
                .tariffRequest.service_level,
        ).toEqual(undefined);
    });

    it('should return service level if trip is single trailer trip and feature flag is enabled', () => {
        const featureFlag = {
            showCreateTripForDoubleTrailer: true,
        };
        expect(
            getEquipmentDriverRequestPayload('CR182021', carrierCodesMock, pTripDataMock[0].tariffReq, featureFlag)
                .tariffRequest.service_level,
        ).toEqual('DEDICATED');
    });

    it('should return service level if feature flag is disabled', () => {
        const featureFlag = {
            hideServiceLevelRequest: false,
        };
        expect(
            getEquipmentDriverRequestPayload('CR182021', carrierCodesMock, pTripDataMock[0].tariffReq, featureFlag)
                .tariffRequest.service_level,
        ).toEqual('DEDICATED');
    });

    it('should not return service level if feature flag is enabled', () => {
        const featureFlag = {
            hideServiceLevelRequest: true,
        };
        expect(
            getEquipmentDriverRequestPayload('CR182021', carrierCodesMock, pTripDataMock[0].tariffReq, featureFlag)
                .tariffRequest.service_level,
        ).toEqual(undefined);
    });

    it('should return service level if trip is double trailer trip and feature flag is disabled', () => {
        const doubleTariffReqMock = {
            ...pTripDataMock[0].tariffReq,
            isDouble: true,
        };
        const featureFlag = {
            showCreateTripForDoubleTrailer: false,
        };
        expect(
            getEquipmentDriverRequestPayload('CR182021', carrierCodesMock, doubleTariffReqMock, featureFlag)
                .tariffRequest.service_level,
        ).toEqual('DEDICATED');
    });

    it('should return service level if trip is single trailer trip and feature flag is disabled', () => {
        const featureFlag = {
            showCreateTripForDoubleTrailer: false,
        };
        expect(
            getEquipmentDriverRequestPayload('CR182021', carrierCodesMock, pTripDataMock[0].tariffReq, featureFlag)
                .tariffRequest.service_level,
        ).toEqual('DEDICATED');
    });

    it('should provide correct worload assignment data driver payload', () => {
        const trans = jest.fn((val) => val);
        expect(
            formatAssignWorkLoadReq(
                { equipmentType: 'workloadAssignment.label.trailerTractor', carrier: 'c1' },
                'ss123',
                { minPickTs: '' },
                driverEqpData,
                trans,
            ).assignResourceRequest,
        ).toEqual(workLoadModel.assignResourceRequest);
        expect(
            formatAssignWorkLoadReq(
                { equipmentType: 'workloadAssignment.label.trailerTractor', carrier: 'c1', tractor: 1 },
                'ss123',
                { minPickTs: '' },
                driverEqpData,
                trans,
            ).assignResourceRequest,
        ).toEqual(equipmTractorMock);
        expect(
            formatAssignWorkLoadReq(
                { equipmentType: 'workloadAssignment.label.truck', carrier: 'c1', truck: 1 },
                'ss123',
                { minPickTs: '' },
                driverEqpData,
                trans,
            ).assignResourceRequest,
        ).toEqual(equipmTractorMock);
        expect(
            formatAssignWorkLoadReq(
                { trailerAssignmentType: 'label.singleTrailer', carrier: 'c1', trailer: 1 },
                'ss123',
                { minPickTs: '', plans: [{ planId: '123' }] },
                driverEqpData,
                trans,
            ).assignResourceRequest,
        ).toEqual(equipmentTrailerMock);
        expect(
            formatAssignWorkLoadReq(
                { trailerAssignmentType: 'label.onLoadCount', carrier: 'c1', loads: { 1: 1 } },
                'ss123',
                { minPickTs: '', plans: [{ planId: '123' }] },
                driverEqpData,
                trans,
            ).assignResourceRequest,
        ).toEqual(equipmentLoadCountListMock);
    });

    it('should provide correct payload for transformTenderRequest', () => {
        expect(transformTenderRequest([1, 2, 3])).toEqual({
            planId: [1, 2, 3],
            carrier: null,
        });
    });

    it('should provide correct response for processCarriersResponse', () => {
        expect(
            processCarriersResponse(
                [{ mdm_carrier_id: 1, carrier_name: 'sample' }],
                [{ mdm_carrier_id: 1, carrier_id: 321 }],
            ),
        ).toEqual([{ id: 321, name: 'sample', value: '321-sample' }]);
    });

    it('should provide correct response for transformApproveTripRequest', () => {
        expect(transformApproveTripRequest([1, 2, 3])).toEqual({
            payload: {
                planIds: [1, 2, 3],
            },
        });
    });
});

describe('getResourceAssignRequest', () => {
    it('should provide resourceAssignmentStatus as RESOURCES_UNASSIGNED', () => {
        const trans = jest.fn((val) => val);
        expect(
            getResourceAssignRequest(
                { equipmentType: 'workloadAssignment.label.trailerTractor', loads: { 1: 1 } },
                {},
                {},
                [],
                trans,
            ).payload.resourceAssignmentStatus,
        ).toEqual('RESOURCES_UNASSIGNED');
    });
    it('should provide resourceAssignmentStatus as RESOURCES_ASSIGN_IN_PROGRESS', () => {
        const trans = jest.fn((val) => val);
        expect(
            getResourceAssignRequest(
                { equipmentType: 'workloadAssignment.label.trailerTractor', loads: { 1: 1 }, carrier: [] },
                {},
                {},
                [],
                trans,
            ).payload.resourceAssignmentStatus,
        ).toEqual('RESOURCES_ASSIGN_IN_PROGRESS');
    });
    it('should provide resourceAssignmentStatus as RESOURCES_UNASSIGNED', () => {
        const trans = jest.fn((val) => val);
        expect(
            getResourceAssignRequest(
                {
                    equipmentType: 'workloadAssignment.label.trailerTractor',
                    trailerAssignmentType: 'workloadAssignment.label.singleTrailer',
                    loads: { 1: 1 },
                    carrier: [],
                },
                {},
                {},
                [],
                trans,
            ).payload.resourceAssignmentStatus,
        ).toEqual('RESOURCES_UNASSIGNED');
    });
    it('should provide resourceAssignmentStatus as RESOURCES_UNASSIGNED', () => {
        const trans = jest.fn((val) => val);
        expect(
            getResourceAssignRequest(
                {
                    equipmentType: 'workloadAssignment.label.trailerTractor',
                    trailerAssignmentType: 'workloadAssignment.label.Trailer',
                    carrier: [],
                },
                {},
                {},
                [],
                trans,
            ).payload.resourceAssignmentStatus,
        ).toEqual('RESOURCES_UNASSIGNED');
    });
    it('Should display show timezone abbreviation if enableShortAbbrTimezone is set', () => {
        const staticData = [
            {
                olsen_timezone_id: 'America/Guatemala',
                short_abbr: 'CT',
            },
        ];
        const defaultTimeZoneId = 'America/Guatemala';
        const featureFlags = {
            enableShortAbbrTimezone: true,
            provenanceTimezone: true,
        };
        const market = 'gt';
        const result = getCreatedDate(
            '2023-02-12T12:30:00.000+05:30',
            { staticData, defaultTimeZoneId },
            { market, featureFlags },
        );
        expect(result).toContain('12 Feb, 2023, 01:00 am (CT)');
    });
    it('Should display show timezone abbreviation if enableShortAbbrTimezone is reset', () => {
        const staticData = [
            {
                olsen_timezone_id: 'America/Guatemala',
                short_abbr: 'CT',
            },
        ];
        const defaultTimeZoneId = 'America/Guatemala';
        const featureFlags = {
            enableShortAbbrTimezone: false,
            provenanceTimezone: false,
        };
        const market = 'gt';
        const result = getCreatedDate(
            '2023-02-12T12:30:00.000+05:30',
            { staticData, defaultTimeZoneId },
            { market, featureFlags },
        );
        expect(result).not.toContain('CT');
    });

    it('formatForceToDeleverTripRequest', () => {
        expect(formatForceToDeleverPlanRequest(paramsForForceToDeleverActionRequest)).toEqual(
            transformedParamsForForceToDeleverActionRequest,
        );
        expect(formatForceToDeleverPlanRequest({})).toEqual({
            plans: [
                {
                    trackingId: undefined,
                    trackingIdType: undefined,
                    transits: [],
                },
            ],
        });
    });
});

describe('bulkUploadProcessorCAM test', () => {
    it('Should test method', () => {
        const bulkUpload = jest.spyOn(DataModels, 'bulkUploadProcessorCAM').mockImplementation();
        bulkUpload.mockClear();
        const resp = bulkUploadProcessorCAM('es', [{}]);
        expect(resp).toBeUndefined();
        expect(bulkUpload).toBeCalled();
    });
});

describe('getColumnsToExport test for US market', () => {
    it('getColumnsToExport - returns US specific columns for export for Planning', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 0, trans, UOM);
        expect(columnHeading[0].key).toEqual('planId');
        expect(columnHeading[1].key).toEqual('planEntity');
        expect(columnHeading[2].key).toEqual('planType');
        expect(columnHeading[3].key).toEqual('trailerId');
        expect(columnHeading[4].key).toEqual('originId');
        expect(columnHeading[5].key).toEqual('originType');
        expect(columnHeading[6].key).toEqual('originName');
        expect(columnHeading[7].key).toEqual('originCity');
        expect(columnHeading[8].key).toEqual('originProvince');
        expect(columnHeading[9].key).toEqual('distance');
        expect(columnHeading[10].key).toEqual('destinationId');
        expect(columnHeading[11].key).toEqual('destinationType');
        expect(columnHeading[12].key).toEqual('destinationName');
        expect(columnHeading[13].key).toEqual('destinationCity');
        expect(columnHeading[14].key).toEqual('destinationProvince');
        expect(columnHeading[15].key).toEqual('priority');
        expect(columnHeading[16].key).toEqual('departureTs');
        expect(columnHeading[17].key).toEqual('endDatePlanned');
        expect(columnHeading[18].key).toEqual('duration');
        expect(columnHeading[19].key).toEqual('noOfPickupStops');
        expect(columnHeading[20].key).toEqual('noOfDropoffStops');
        expect(columnHeading[21].key).toEqual('statusDesc');
    });
    it('getColumnsToExport - returns primary destination columns for export if feature flag true - planning', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 0, trans, UOM, { showPrimaryDestinationCol: true });
        expect(columnHeading[15].key).toEqual('priDestinationId');
        expect(columnHeading[16].key).toEqual('priDestinationType');
        expect(columnHeading[17].key).toEqual('priDestinationName');
        expect(columnHeading[18].key).toEqual('priDestinationCity');
    });
    it('getColumnsToExport - returns tags columns for export if feature flag true - planning', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 0, trans, UOM, { showTagsCol: true });
        expect(columnHeading[1].key).toEqual('hazmatAbbr');
    });
    it('getColumnsToExport - returns dwell days columns for export if feature flag true - planning', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeadingWithPrimaryDestination = getColumnsToExport('US', 0, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
        });
        expect(columnHeadingWithPrimaryDestination[20].key).toEqual('dwellDays');
        const columnHeading = getColumnsToExport('US', 0, trans, UOM, {
            showPrimaryDestinationCol: false,
            showDwellDays: true,
        });
        expect(columnHeading[15].key).toEqual('dwellDays');
    });
    it('getColumnsToExport - returns US specific columns for export for Processing', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 1, trans, UOM);
        expect(columnHeading[0].key).toEqual('planId');
        expect(columnHeading[1].key).toEqual('planEntity');
        expect(columnHeading[2].key).toEqual('planType');
        expect(columnHeading[3].key).toEqual('carrierId');
        expect(columnHeading[4].key).toEqual('serviceTerritory');
        expect(columnHeading[5].key).toEqual('trailerId');
        expect(columnHeading[6].key).toEqual('driverId');
        expect(columnHeading[7].key).toEqual('driverName');
        expect(columnHeading[8].key).toEqual('originId');
        expect(columnHeading[9].key).toEqual('originType');
        expect(columnHeading[10].key).toEqual('originName');
        expect(columnHeading[11].key).toEqual('originCity');
        expect(columnHeading[12].key).toEqual('originProvince');
        expect(columnHeading[13].key).toEqual('distance');
        expect(columnHeading[14].key).toEqual('destinationId');
        expect(columnHeading[15].key).toEqual('destinationType');
        expect(columnHeading[16].key).toEqual('destinationName');
        expect(columnHeading[17].key).toEqual('destinationCity');
        expect(columnHeading[18].key).toEqual('destinationProvince');
        expect(columnHeading[19].key).toEqual('priority');
        expect(columnHeading[20].key).toEqual('departureTs');
        expect(columnHeading[21].key).toEqual('primaryDestinationEndDatePlanned');
        expect(columnHeading[22].key).toEqual('endDatePlanned');
        expect(columnHeading[23].key).toEqual('duration');
        expect(columnHeading[24].key).toEqual('billsByTime');
        expect(columnHeading[25].key).toEqual('noOfPickupStops');
        expect(columnHeading[26].key).toEqual('noOfDropoffStops');
        expect(columnHeading[27].key).toEqual('carrierStatusDesc');
        expect(columnHeading[28].key).toEqual('equipmentStatusDesc');
        expect(columnHeading[29].key).toEqual('driverStatusDesc');
    });
    it('getColumnsToExport - returns primary destination columns for export if feature flag true - processing', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 1, trans, UOM, { showPrimaryDestinationCol: true });
        expect(columnHeading[19].key).toEqual('priDestinationId');
        expect(columnHeading[20].key).toEqual('priDestinationType');
        expect(columnHeading[21].key).toEqual('priDestinationName');
        expect(columnHeading[22].key).toEqual('priDestinationCity');
    });
    it('getColumnsToExport - returns tags columns for export if feature flag true - processing', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 1, trans, UOM, { showTagsCol: true });
        expect(columnHeading[1].key).toEqual('hazmatAbbr');
    });
    it('getColumnsToExport - returns tags columns for export if feature flag true (Print Status) - processing', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 1, trans, UOM, { showTagsCol: true });
        expect(columnHeading[2].key).toEqual('printedAbbr');
    });
    it('getColumnsToExport - returns tags columns for export if feature flag false (Print Status) - processing', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 1, trans, UOM, { showTagsCol: false });
        expect(columnHeading[2].key).not.toEqual('printedAbbr');
    });
    it('getColumnsToExport - returns dwell days columns for export if feature flag true - processing', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeadingWithPrimaryDestination = getColumnsToExport('US', 1, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
        });
        expect(columnHeadingWithPrimaryDestination[24].key).toEqual('dwellDays');
        const columnHeading = getColumnsToExport('US', 1, trans, UOM, {
            showPrimaryDestinationCol: false,
            showDwellDays: true,
        });
        expect(columnHeading[19].key).toEqual('dwellDays');
    });
    it('getColumnsToExport - returns trip & planning service territory columns for export if feature flag true - processing', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 1, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
            showServiceTerritory: true,
        });
        expect(columnHeading[4].key).toEqual('tripServiceTerritory');
        expect(columnHeading[5].key).toEqual('planningServiceTerritory');
    });
    it('getColumnsToExport - should not return trip & planning service territory columns for export if feature flag false - processing', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 1, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
            showServiceTerritory: false,
        });
        expect(columnHeading[4].key).toEqual('serviceTerritory');
        expect(columnHeading[4].key).not.toEqual('tripServiceTerritory');
        expect(columnHeading[5].key).not.toEqual('planningServiceTerritory');
    });
    it('getColumnsToExport - returns US specific columns for export for Ready to start', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 2, trans, UOM);
        expect(columnHeading[0].key).toEqual('planId');
        expect(columnHeading[1].key).toEqual('planEntity');
        expect(columnHeading[2].key).toEqual('planType');
        expect(columnHeading[3].key).toEqual('originId');
        expect(columnHeading[4].key).toEqual('originType');
        expect(columnHeading[5].key).toEqual('originName');
        expect(columnHeading[6].key).toEqual('originCity');
        expect(columnHeading[7].key).toEqual('originProvince');
        expect(columnHeading[8].key).toEqual('distance');
        expect(columnHeading[9].key).toEqual('destinationId');
        expect(columnHeading[10].key).toEqual('destinationType');
        expect(columnHeading[11].key).toEqual('destinationName');
        expect(columnHeading[12].key).toEqual('destinationCity');
        expect(columnHeading[13].key).toEqual('destinationProvince');
        expect(columnHeading[14].key).toEqual('priority');
        expect(columnHeading[15].key).toEqual('departureTs');
        expect(columnHeading[16].key).toEqual('endDatePlanned');
        expect(columnHeading[17].key).toEqual('duration');
        expect(columnHeading[18].key).toEqual('carrierId');
        expect(columnHeading[19].key).toEqual('serviceTerritory');
        expect(columnHeading[20].key).toEqual('trailerId');
        expect(columnHeading[21].key).toEqual('driverId');
        expect(columnHeading[22].key).toEqual('driverName');
        expect(columnHeading[23].key).toEqual('billsByTime');
        expect(columnHeading[24].key).toEqual('noOfPickupStops');
        expect(columnHeading[25].key).toEqual('noOfDropoffStops');
        expect(columnHeading[26].key).toEqual('statusDesc');
    });
    it('getColumnsToExport - returns primary destination columns for export if feature flag true - ready to start', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 2, trans, UOM, { showPrimaryDestinationCol: true });
        expect(columnHeading[14].key).toEqual('priDestinationId');
        expect(columnHeading[15].key).toEqual('priDestinationType');
        expect(columnHeading[16].key).toEqual('priDestinationName');
        expect(columnHeading[17].key).toEqual('priDestinationCity');
    });
    it('getColumnsToExport - returns tags columns for export if feature flag true - ready to start', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 2, trans, UOM, { showTagsCol: true });
        expect(columnHeading[1].key).toEqual('hazmatAbbr');
    });
    it('getColumnsToExport - returns dwell days columns for export if feature flag true - ready to start', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeadingWithPrimaryDestination = getColumnsToExport('US', 2, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
        });
        expect(columnHeadingWithPrimaryDestination[19].key).toEqual('dwellDays');
        const columnHeading = getColumnsToExport('US', 1, trans, UOM, {
            showPrimaryDestinationCol: false,
            showDwellDays: true,
        });
        expect(columnHeading[19].key).toEqual('dwellDays');
    });
    it('getColumnsToExport - returns trip & planning service territory columns for export if feature flag true - ready to start', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 2, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
            showServiceTerritory: true,
        });
        expect(columnHeading[25].key).toEqual('tripServiceTerritory');
        expect(columnHeading[26].key).toEqual('planningServiceTerritory');
    });
    it('getColumnsToExport - should not return trip & planning service territory columns for export if feature flag false - ready to start', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 2, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
            showServiceTerritory: false,
        });
        expect(columnHeading[25].key).toEqual('serviceTerritory');
        expect(columnHeading[25].key).not.toEqual('tripServiceTerritory');
        expect(columnHeading[26].key).not.toEqual('planningServiceTerritory');
    });
    it('getColumnsToExport - returns US specific columns for export for In transit', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 3, trans, UOM);
        expect(columnHeading[0].key).toEqual('planId');
        expect(columnHeading[1].key).toEqual('planEntity');
        expect(columnHeading[2].key).toEqual('planType');
        expect(columnHeading[3].key).toEqual('originId');
        expect(columnHeading[4].key).toEqual('originType');
        expect(columnHeading[5].key).toEqual('originName');
        expect(columnHeading[6].key).toEqual('originCity');
        expect(columnHeading[7].key).toEqual('originProvince');
        expect(columnHeading[8].key).toEqual('distance');
        expect(columnHeading[9].key).toEqual('destinationId');
        expect(columnHeading[10].key).toEqual('destinationType');
        expect(columnHeading[11].key).toEqual('destinationName');
        expect(columnHeading[12].key).toEqual('destinationCity');
        expect(columnHeading[13].key).toEqual('destinationProvince');
        expect(columnHeading[14].key).toEqual('priority');
        expect(columnHeading[15].key).toEqual('departureTs');
        expect(columnHeading[16].key).toEqual('actualTs');
        expect(columnHeading[17].key).toEqual('endDatePlanned');
        expect(columnHeading[18].key).toEqual('EndDateEstimated');
        expect(columnHeading[19].key).toEqual('duration');
        expect(columnHeading[20].key).toEqual('nextStopId');
        expect(columnHeading[21].key).toEqual('nextStopType');
        expect(columnHeading[22].key).toEqual('nextStopName');
        expect(columnHeading[23].key).toEqual('nextStopCity');
        expect(columnHeading[24].key).toEqual('nextStopProvince');
        expect(columnHeading[25].key).toEqual('numberOfStopsRemaining');
        expect(columnHeading[26].key).toEqual('carrierId');
        expect(columnHeading[27].key).toEqual('serviceTerritory');
        expect(columnHeading[28].key).toEqual('trailerId');
        expect(columnHeading[29].key).toEqual('driverId');
        expect(columnHeading[30].key).toEqual('driverName');
        expect(columnHeading[31].key).toEqual('billsByTime');
        expect(columnHeading[32].key).toEqual('noOfPickupStops');
        expect(columnHeading[33].key).toEqual('noOfDropoffStops');
        expect(columnHeading[34].key).toEqual('statusDesc');
    });
    it('getColumnsToExport - returns primary destination columns for export if feature flag true - intransit', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 3, trans, UOM, { showPrimaryDestinationCol: true });
        expect(columnHeading[14].key).toEqual('priDestinationId');
        expect(columnHeading[15].key).toEqual('priDestinationType');
        expect(columnHeading[16].key).toEqual('priDestinationName');
        expect(columnHeading[17].key).toEqual('priDestinationCity');
    });
    it('getColumnsToExport - returns trip & planning service territory columns for export if feature flag true - intransit', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 3, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
            showServiceTerritory: true,
        });
        expect(columnHeading[32].key).toEqual('tripServiceTerritory');
        expect(columnHeading[33].key).toEqual('planningServiceTerritory');
    });
    it('getColumnsToExport - should not return trip & planning service territory columns for export if feature flag false - intransit', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 3, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
            showServiceTerritory: false,
        });
        expect(columnHeading[32].key).toEqual('serviceTerritory');
        expect(columnHeading[32].key).not.toEqual('tripServiceTerritory');
        expect(columnHeading[33].key).not.toEqual('planningServiceTerritory');
    });
    it('getColumnsToExport - returns US specific columns for export for Delivered', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 4, trans, UOM);
        expect(columnHeading[0].key).toEqual('planId');
        expect(columnHeading[1].key).toEqual('planEntity');
        expect(columnHeading[2].key).toEqual('planType');
        expect(columnHeading[3].key).toEqual('originId');
        expect(columnHeading[4].key).toEqual('originType');
        expect(columnHeading[5].key).toEqual('originName');
        expect(columnHeading[6].key).toEqual('originCity');
        expect(columnHeading[7].key).toEqual('originProvince');
        expect(columnHeading[8].key).toEqual('distance');
        expect(columnHeading[9].key).toEqual('destinationId');
        expect(columnHeading[10].key).toEqual('destinationType');
        expect(columnHeading[11].key).toEqual('destinationName');
        expect(columnHeading[12].key).toEqual('destinationCity');
        expect(columnHeading[13].key).toEqual('destinationProvince');
        expect(columnHeading[14].key).toEqual('priority');
        expect(columnHeading[15].key).toEqual('departureTs');
        expect(columnHeading[16].key).toEqual('actualTs');
        expect(columnHeading[17].key).toEqual('endDatePlanned');
        expect(columnHeading[18].key).toEqual('actualEndDate');
        expect(columnHeading[19].key).toEqual('duration');
        expect(columnHeading[20].key).toEqual('carrierId');
        expect(columnHeading[21].key).toEqual('serviceTerritory');
        expect(columnHeading[22].key).toEqual('trailerId');
        expect(columnHeading[23].key).toEqual('driverId');
        expect(columnHeading[24].key).toEqual('driverName');
        expect(columnHeading[25].key).toEqual('billsByTime');
        expect(columnHeading[26].key).toEqual('noOfPickupStops');
        expect(columnHeading[27].key).toEqual('noOfDropoffStops');
        expect(columnHeading[28].key).toEqual('statusDesc');
    });
    it('getColumnsToExport - returns primary destination columns for export if feature flag true - delivered', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 4, trans, UOM, { showPrimaryDestinationCol: true });
        expect(columnHeading[14].key).toEqual('priDestinationId');
        expect(columnHeading[15].key).toEqual('priDestinationType');
        expect(columnHeading[16].key).toEqual('priDestinationName');
        expect(columnHeading[17].key).toEqual('priDestinationCity');
    });
    it('getColumnsToExport - returns tags columns for export if feature flag true - delivered', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 4, trans, UOM, { showTagsCol: true });
        expect(columnHeading[1].key).toEqual('hazmatAbbr');
    });
    it('getColumnsToExport - returns trip & planning service territory columns for export if feature flag true - delivered', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 4, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
            showServiceTerritory: true,
        });
        expect(columnHeading[26].key).toEqual('tripServiceTerritory');
        expect(columnHeading[27].key).toEqual('planningServiceTerritory');
    });
    it('getColumnsToExport - should not return trip & planning service territory columns for export if feature flag false - delivered', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 4, trans, UOM, {
            showPrimaryDestinationCol: true,
            showDwellDays: true,
            showServiceTerritory: false,
        });
        expect(columnHeading[26].key).toEqual('serviceTerritory');
        expect(columnHeading[26].key).not.toEqual('tripServiceTerritory');
        expect(columnHeading[27].key).not.toEqual('planningServiceTerritory');
    });
    it('getColumnsToExport - returns tags columns for export if feature flag true - intransit', () => {
        const trans = jest.fn();
        const UOM = {};
        const columnHeading = getColumnsToExport('US', 3, trans, UOM, { showTagsCol: true });
        expect(columnHeading[1].key).toEqual('hazmatAbbr');
    });
    it('getAppliedFiltersCount - should return applied filters count', () => {
        expect(getAppliedFiltersCount(formValue)).toEqual(2);
    });
    it('Should return true for display section if allowed filter has value', () => {
        expect(showOriginSection(allowedFilters)).toEqual(true);
        expect(showDestinationSection(allowedFilters)).toEqual(true);
        expect(showLoadSection(allowedFilters)).toEqual(true);
        expect(showServiceSection(allowedFilters)).toEqual(true);
        expect(showCarrierSection(allowedFilters)).toEqual(true);
        expect(showPlanSection(allowedFilters)).toEqual(true);
    });
    it('Should return false for display section if allowed filter has no value', () => {
        expect(showOriginSection([])).toEqual(false);
        expect(showDestinationSection([])).toEqual(false);
        expect(showLoadSection([])).toEqual(false);
        expect(showServiceSection([])).toEqual(false);
        expect(showCarrierSection([])).toEqual(false);
        expect(showPlanSection([])).toEqual(false);
    });
    it('isLocationIdDisabled - Should return value for origin and destination', () => {
        const originValue = { originType: ['DC'] };
        expect(isLocationIdDisabled('origin', originValue)).toEqual(1);
        const destinationValue = { destinationType: ['DC'] };
        expect(isLocationIdDisabled('destination', destinationValue)).toEqual(1);
    });
    it('hasmatTransLabels - Should return array with length two', () => {
        expect(hasmatTransLabels(jest.fn()).length).toEqual(2);
    });

    it('getLocationIdsList() - should return location id lists', () => {
        const locationIdList = getLocationIdsList(staticDataForIntermediateLocation);
        expect(locationIdList).toEqual(locationIdsList);
    });

    it('transformPlanPreviewData() - should return stops if enableHubDeconDestinations flag is enabled ', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { enableHubDeconDestinations: true },
            config: {},
        };
        const transformedPlanData = transformPlanPreviewData(
            selectedTripWithUpdateDestionationMock.childPlans[0],
            (a) => a,
            config,
        );
        expect(transformedPlanData.stops).toBeDefined();
    });

    it('transformPlanPreviewData() - should return stops if enableHubDeconDestinations flag is disabled ', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { enableHubDeconDestinations: false },
            config: {},
        };
        const transformedPlanData = transformPlanPreviewData(
            selectedTripWithUpdateDestionationMock.childPlans[0],
            (a) => a,
            config,
        );
        expect(transformedPlanData.stops).toBeUndefined();
    });

    it('transformLoadsToUpdateDestination() - should build load data for update destination sidebar drawer ', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { enableHubDeconDestinations: true },
            config: {},
        };
        const transformedPlanData = transformPlanPreviewData(selectedTripWithUpdateDestionationMock, (a) => a, config);
        const transformedTripData = transformLoadsToUpdateDestination([transformedPlanData?.plans[0]]);
        expect(transformedTripData).toEqual(transformedTripForUpdateDestination);
    });

    describe('transformPlanPreviewData - chargeLocation changes', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { enableChargeLocAssignmentForFillerMoves: true },
            config: {},
        };
        it('should return chargeLocation if the flag is enabled', () => {
            const transformedPlanData = transformPlanPreviewData(selectedTripMockWithChargeLoc, (a) => a, config);
            expect(transformedPlanData.plans[0].chargeLocation).toBeDefined();
            expect(transformedPlanData.plans[0].chargeLocation.locationId).toEqual('657');
        });
        it('should not return chargeLocation if the flag is disabled', () => {
            const configWithDisabledFeatureFlag = {
                ...config,
                featureFlags: { enableChargeLocAssignmentForFillerMoves: false },
            };
            const transformedPlanData = transformPlanPreviewData(
                selectedTripMockWithChargeLoc,
                (a) => a,
                configWithDisabledFeatureFlag,
            );
            expect(transformedPlanData.plans[0].chargeLocation).toBeUndefined();
        });
        it('should not return chargeLocation if the load data has no charge Location', () => {
            const transformedPlanData = transformPlanPreviewData(selectedTripMock, (a) => a, config);
            expect(transformedPlanData.plans[0].chargeLocation).toBeUndefined();
        });
    });

    describe('transformedPlanPreviewData - load stop field test', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { showCreateTripForDoubleTrailer: true },
            config: {},
        };

        it('should return stops if feature flag is enabled', () => {
            const transformedData = transformPlanPreviewData(tripMockWithChildPlanStops, (a) => a, config);
            expect(transformedData.plans[0].stops).toBeDefined();
        });

        it('should not return stops if feature flag is disabled', () => {
            const configWithDisabledFeatureFlag = {
                ...config,
                featureFlags: { showCreateTripForDoubleTrailer: false },
            };
            const transformedData = transformPlanPreviewData(
                tripMockWithChildPlanStops,
                (a) => a,
                configWithDisabledFeatureFlag,
            );
            expect(transformedData.plans[0].stops).toBeUndefined();
        });
    });
    describe('transformedPlanPreviewData - final destination changes - double trailer', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { showCreateTripForDoubleTrailer: true },
            config: {},
        };
        it('should return last sequence stop id for destination if feature flag is enabled and trip is double', () => {
            const dataWithActivities = {
                ...selectedTripMock,
                activities: [{ location: { locationId: 96 }, stopSequenceNumber: 1 }],
                transitDetail: { mode: 'DBL' },
            };
            const transformedData = transformPlanPreviewData(dataWithActivities, (a) => a, config);
            expect(transformedData.destinationId).toEqual('96');
        });
        it('should return trip destination stop id for destination if feature flag is enabled and trip is single', () => {
            const dataWithActivities = {
                ...selectedTripMock,
                activities: [{ location: { locationId: 96 }, stopSequenceNumber: 1 }],
                transitDetail: { mode: 'TL' },
            };
            const transformedData = transformPlanPreviewData(dataWithActivities, (a) => a, config);
            expect(transformedData.destinationId).toEqual('7406');
        });
        it('should return trip destination stop id for destination if feature flag is disabled', () => {
            const dataWithActivities = {
                ...selectedTripMock,
                activities: [{ location: { locationId: 96 }, stopSequenceNumber: 1 }],
            };
            const configWithDisabledFeatureFlag = {
                ...config,
                featureFlags: { showCreateTripForDoubleTrailer: false },
            };
            const transformedData = transformPlanPreviewData(
                dataWithActivities,
                (a) => a,
                configWithDisabledFeatureFlag,
            );
            expect(transformedData.destinationId).toEqual('7406');
        });
    });

    describe('transformedPlanPreviewData - bill of lading tests', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { enableBillOfLading: true },
            config: {},
        };
        const tripWithBillOfLading = {
            ...selectedTripMock,
            equipment: {
                ...selectedTripMock.equipment,
                billOfLading: 1234567,
            },
        };
        it('should return bill of lading for trip if feature flag is enabled', () => {
            const transformedData = transformPlanPreviewData(tripWithBillOfLading, (a) => a, config);
            expect(transformedData.billOfLading).toEqual(1234567);
        });
        it('should not return bill of lading for trip if feature flag is disabled', () => {
            const disabledConfig = {
                ...config,
                featureFlags: { enableBillOfLading: false },
            };
            const transformedData = transformPlanPreviewData(tripWithBillOfLading, (a) => a, disabledConfig);
            expect(transformedData.billOflading).toEqual(undefined);
        });
        describe('bill of lading tests - load level', () => {
            it('should return bill of lading for load if feature flag is enabled', () => {
                const transformedData = transformPlanPreviewData(tripWithBillOfLadingInLoads, (a) => a, config);
                expect(transformedData.plans[0].billOfLading).toEqual(10000);
                expect(transformedData.plans[1].billOfLading).toEqual(20000);
                expect(transformedData.plans[2].billOfLading).toEqual(30000);
            });
            it('should not return bill of lading for load if feature flag is disabled', () => {
                const disabledConfig = {
                    ...config,
                    featureFlags: { enableBillOfLading: false },
                };
                const transformedData = transformPlanPreviewData(tripWithBillOfLadingInLoads, (a) => a, disabledConfig);
                expect(transformedData.plans[0].billOfLading).toEqual(undefined);
                expect(transformedData.plans[1].billOfLading).toEqual(undefined);
                expect(transformedData.plans[2].billOfLading).toEqual(undefined);
            });
        });
    });
    it('sealAndInvoiceDetailsExistInAllStops() - should check whether every stop has seal and invoice#', () => {
        const isTripEligibleForUpdateDestination = sealAndInvoiceDetailsExistInAllStops(
            transformedPlanListWithoutSealsAndInvoice[0].plans[0].stops,
        );
        expect(isTripEligibleForUpdateDestination).toEqual(false);
    });
    it('displayUpdateDestinationButton() - should return true if all checklist to display Update Destination button are passed', () => {
        expect(displayUpdateDestinationButton(['30064496'], transformedPlanListWithSealsAndInvoice)).toEqual(true);
    });
    it('displayUpdateDestinationButton() - should return false if trip has carrier assigned to it', () => {
        expect(displayUpdateDestinationButton(['30064496'], transformedPlanListWithCarrierAssignedStatus)).toEqual(
            false,
        );
    });
    it('displayUpdateDestinationButton() - should return false if any one checklist to display Update Destination button is failed', () => {
        expect(displayUpdateDestinationButton(['30064496'], transformedPlanListWithoutSealsAndInvoice)).toEqual(false);
    });
    it('displayUpdateDestinationButton() - should return true if carrier is assigned', () => {
        expect(displayUpdateDestinationButton(['30064496'], transformedPlanListWithSealsAndInvoice)).toEqual(true);
    });
    it('displayUpdateDestinationButton - should return false if plan location type is HUB/DCN', () => {
        const transformedPlanListWithReferenceLoadType = [
            {
                ...transformedPlanListWithSealsAndInvoice,
                plans: [
                    {
                        ...transformedPlanListWithSealsAndInvoice.plans,
                        destinationType: 'HUB',
                        originType: 'STORE',
                    },
                ],
            },
        ];
        expect(displayUpdateDestinationButton(['30064496'], transformedPlanListWithReferenceLoadType)).toEqual(false);
    });
    it('displayUpdateDestinationButton() - should return true if plan location type is not HUB and DCN', () => {
        expect(displayUpdateDestinationButton(['30064496'], transformedPlanListWithSealsAndInvoice)).toEqual(true);
    });

    it('displayUpdateDestinationButton() - should return true if plan is double trailer', () => {
        const doubleTrailerTrip = [
            {
                ...transformedPlanListWithSealsAndInvoice[0],
                plans: [
                    transformedPlanListWithSealsAndInvoice[0].plans[0],
                    transformedPlanListWithSealsAndInvoice[0].plans[0],
                ],
            },
        ];
        expect(displayUpdateDestinationButton(['30064496'], doubleTrailerTrip)).toEqual(true);
    });

    it('displayUpdateDestinationButton() - should return false if plan is double trailer and either load has no seal or invoice', () => {
        const doubleTrailerTrip = [
            {
                ...transformedPlanListWithSealsAndInvoice[0],
                plans: [
                    {
                        ...transformedPlanListWithSealsAndInvoice[0].plans[0],
                        stops: [
                            {
                                sealIdentifiers: [],
                                invoiceIdentifiers: [],
                            },
                        ],
                    },
                    transformedPlanListWithSealsAndInvoice[0].plans[0],
                ],
            },
        ];
        expect(displayUpdateDestinationButton(['30064496'], doubleTrailerTrip)).toEqual(false);
    });
    it('getSelectedPlanDetails() - should fetch selectedplan details for update destination', () => {
        const selectedPlanDetails = getSelectedPlanDetails(transformedPlanMock[0]);
        expect(selectedPlanDetails.planId).toEqual('30025475');
        expect(selectedPlanDetails.originId).toEqual('20');
        expect(selectedPlanDetails.destinationId).toEqual('2');
    });
    it('transformPlanPreviewData() - should return plan carrier status if enableHubDeconDestinations flag is enabled ', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { enableHubDeconDestinations: true },
            config: {},
        };
        const tripData = {
            ...selectedTripWithUpdateDestionationMock,
            planTenderStatus: {
                name: 'UNASSIGNED',
            },
        };
        const transformedPlanData = transformPlanPreviewData(tripData, (a) => a, config);
        expect(transformedPlanData.planCarrierStatus).toBeDefined();
    });

    it('transformPlanPreviewData() - should not return plan carrier status if enableHubDeconDestinations flag is disabled ', () => {
        const config = {
            market: 'mx',
            staticData: {},
            featureFlags: { enableHubDeconDestinations: false },
            config: {},
        };
        const transformedPlanData = transformPlanPreviewData(selectedTripWithUpdateDestionationMock, (a) => a, config);
        expect(transformedPlanData.planCarrierStatus).toBeUndefined();
    });
});

describe('Mode changes', () => {
    const trans = jest.fn();
    it('should not return transitDetailMode if showModeColumnInTripSummary flag is false', () => {
        const configuration = {
            featureFlags: {
                showModeColumnInTripSummary: false,
            },
        };
        const previewData = transformPlanPreviewData({}, trans, configuration);
        expect(previewData).not.toHaveProperty('transitDetailMode');
    });
    it('should return transitDetailMode if showModeColumnInTripSummary flag is true', () => {
        const configuration = {
            featureFlags: {
                showModeColumnInTripSummary: true,
            },
        };
        const previewData = transformPlanPreviewData({ transitDetail: { mode: 'TL' } }, trans, configuration);
        expect(previewData).toHaveProperty('transitDetailMode');
    });
});

describe('reference load type', () => {
    const trans = jest.fn();
    it('should not return referenceLoadType if displayLoadTypeFromReference flag disabled', () => {
        const configuration = {
            featureFlags: {
                displayLoadTypeFromReference: false,
            },
        };
        const previewData = transformPlanPreviewData({}, trans, configuration);
        expect(previewData).not.toHaveProperty('referenceLoadType');
    });
    it('should return referenceLoadType if displayLoadTypeFromReference flag enabled', () => {
        const configuration = {
            featureFlags: {
                displayLoadTypeFromReference: true,
            },
        };
        const previewData = transformPlanPreviewData({}, trans, configuration);
        expect(previewData).toHaveProperty('referenceLoadType');
    });
});

describe('comments from loads', () => {
    const trans = jest.fn();
    it('should return comments if enableAddMultiComment flag enabled', () => {
        const configuration = {
            featureFlags: {
                enableAddMultiComment: true,
            },
        };
        const previewData = transformPlanPreviewData({}, trans, configuration);
        expect(previewData).toHaveProperty('comments');
    });
    it('should not return comments if enableAddMultiComment flag disabled', () => {
        const configuration = {
            featureFlags: {
                enableAddMultiComment: false,
            },
        };
        const previewData = transformPlanPreviewData({}, trans, configuration);
        expect(previewData).not.toHaveProperty('commments');
    });
});

describe('Tests for - Update timeline payload', () => {
    it('should return update timeline payload with load', () => {
        expect(formatUpdateTimeLineData('1234453', formatUpdateTimeLineDataResponseMock, false)).toEqual(
            formatUpdateTimeLineLoadPayLoadMock,
        );
    });

    it('should return update timeline payload with trip', () => {
        expect(formatUpdateTimeLineData('1234453', formatUpdateTimeLineDataResponseMock, true)).toEqual(
            formatUpdateTimeLineTripPayLoadMock,
        );
    });
});

describe('Tests for double trailer creation format', () => {
    it('should return only double trailer equipment types, MX', () => {
        const featureFlags = {
            enableDifferentOriginForDoubleTrailer: true,
        };
        expect(getDoubleTrailerType(staticDataEquipmentTypeListMX, featureFlags)).toEqual([
            staticDataEquipmentTypeListMX.equipmentConfigurationIds[0],
            staticDataEquipmentTypeListMX.equipmentConfigurationIds[2],
        ]);
    });

    it('should return only double trailer equipment types, CL', () => {
        const featureFlags = {
            enableDifferentOriginForDoubleTrailer: false,
        };
        expect(getDoubleTrailerType(staticDataEquipmentTypeListCL, featureFlags)).toEqual([
            staticDataEquipmentTypeListCL.equipmentConfigurationIds[0],
        ]);
    });

    it('should return request payload for double trailer creation', () => {
        const data = {
            equipmentCode: 'ASRF56',
            planId: ['30000967', '30000040'],
            stopSequence: mockStopSequence,
        };
        expect(formatDoubleTrailerTripReq(data)).toEqual(doubleTrailerPayloadMock);
    });

    it('should return formatted stop sequence from two trips', () => {
        const formatDoubleTrailer = formatDoubleTrailerStopSequence(mockDoubleTrailerPlans);
        expect(formatDoubleTrailer.length).toEqual(4);
    });

    it('should return stop type from double trailer stop sequence formatter', () => {
        const formatDoubleTrailer = formatDoubleTrailerStopSequence(mockDoubleTrailerPlans);
        expect(formatDoubleTrailer[0].stopType).toEqual('PIKSTP');
        expect(formatDoubleTrailer[1].stopType).toEqual('PIKSTP');
        expect(formatDoubleTrailer[2].stopType).toEqual('DLVSTP');
        expect(formatDoubleTrailer[3].stopType).toEqual('DLVSTP');
    });

    it('getDoubleTrailerLabels() - should get double trailer labels', () => {
        expect(getDoubleTrailerLabels((a) => a)).toEqual(mockDoubleTrailerLabels);
    });
});

describe('displayDoubleTrailerButton() - tests to display double trailer buttons', () => {
    const featureFlags = {
        enableDifferentOriginForDoubleTrailer: true,
        showCreateTripForDoubleTrailer: true,
    };

    it('should return true with two valid trips', () => {
        expect(displayDoubleTrailerButton(displayDoubleTrailerButtonData, checkedRows, featureFlags)).toBeTruthy();
    });
    it('should return false if different origin and flag is off', () => {
        const differentOriginData = [
            displayDoubleTrailerButtonData[0],
            {
                ...displayDoubleTrailerButtonData[1],
                originId: '99999',
            },
        ];
        const featureFlagsDisabled = {
            enableDifferentOriginForDoubleTrailer: false,
        };
        expect(displayDoubleTrailerButton(differentOriginData, checkedRows, featureFlagsDisabled)).toBeFalsy();
    });
    it('should return false if trips load count is greater than 1', () => {
        const loadCountData = [
            displayDoubleTrailerButtonData[0],
            {
                ...displayDoubleTrailerButtonData[1],
                loadCount: 2,
            },
        ];
        expect(displayDoubleTrailerButton(loadCountData, checkedRows, featureFlags)).toBeFalsy();
    });
    it('should return false if either trips are round trips', () => {
        const roundTripData = [
            displayDoubleTrailerButtonData[0],
            {
                ...displayDoubleTrailerButtonData[1],
                destinationId: displayDoubleTrailerButtonData[1].originId,
            },
        ];
        expect(displayDoubleTrailerButton(roundTripData, checkedRows, featureFlags)).toBeFalsy();
    });
    it('should return false if load type of both trips are not equal', () => {
        const differentLoadTypeData = [
            displayDoubleTrailerButtonData[0],
            {
                ...displayDoubleTrailerButtonData[1],
                plans: [{ loadType: 'PLT' }],
            },
        ];
        expect(displayDoubleTrailerButton(differentLoadTypeData, checkedRows, featureFlags)).toBeFalsy();
    });
    it('should return false if either trips have carrier assigned', () => {
        const carrierAssignedData = [
            displayDoubleTrailerButtonData[0],
            {
                ...displayDoubleTrailerButtonData[1],
                carrierId: 'carrier test',
            },
        ];
        expect(displayDoubleTrailerButton(carrierAssignedData, checkedRows, featureFlags)).toBeFalsy();
    });
    it('should return false if feature flag is off', () => {
        const featureFlagsDisabled = {
            showCreateTripForDoubleTrailer: false,
        };
        expect(displayDoubleTrailerButton(displayDoubleTrailerButtonData, checkedRows, featureFlagsDisabled));
    });
});

describe('getCarrierAssignRequest() formatting test cases', () => {
    describe('check dolly field test', () => {
        it('should return dolly field if dolly has length greater than 1', () => {
            const workloadAssignmentMock = { dolly: 'TEST' };
            expect(getCarrierAssignRequest(workloadAssignmentMock).dolly).toEqual('TEST');
        });
        it('should not return dolly field if dolly is empty string', () => {
            const workloadAssignmentMock = { dolly: '' };
            expect(getCarrierAssignRequest(workloadAssignmentMock).dolly).toBeUndefined();
        });
    });
});

describe('getResourceAssignRequest() formatting test cases', () => {
    const trans = jest.fn((a) => a);
    describe('check dolly field test', () => {
        it('should return dolly field if dolly has length greater than 1', () => {
            const workloadAssignmentMock = { dolly: 'TEST' };
            expect(getResourceAssignRequest(workloadAssignmentMock, null, null, null, trans).payload.dolly).toEqual(
                'TEST',
            );
        });
        it('should not return dolly field if dolly is empty string', () => {
            const workloadAssignmentMock = { dolly: '' };
            expect(
                getResourceAssignRequest(workloadAssignmentMock, null, null, null, trans).payload.dolly,
            ).toBeUndefined();
        });
    });
    describe('should return bill of lading at trip level if feature flag is enabled', () => {
        const featureFlags = {
            enableBillOfLading: true,
        };
        it('should return bill of lading at trip level if feature flag is enabled', () => {
            expect(
                getResourceAssignRequest(
                    billOfLadingWorkLoadAssignmentMock,
                    null,
                    trailerInfo,
                    null,
                    trans,
                    featureFlags,
                ).payload.equipments[0].equipmentAttributes[2].value,
            ).toEqual(1);
        });

        it('should return empty bill of lading at trip level if feature flag is enabled', () => {
            const emptyBillOfLading = {
                ...billOfLadingWorkLoadAssignmentMock,
                billOfLading: {
                    ...billOfLadingWorkLoadAssignmentMock.billOfLading,
                    default: '',
                },
            };
            expect(
                getResourceAssignRequest(emptyBillOfLading, null, trailerInfo, null, trans, featureFlags).payload
                    .equipments[0].equipmentAttributes[2].value,
            ).toEqual('');
        });

        it('should not return bill of lading at trip level if feature flag is disabled', () => {
            expect(
                getResourceAssignRequest(billOfLadingWorkLoadAssignmentMock, null, trailerInfo, null, trans, {
                    enableBillOfLading: false,
                }).payload.equipments[0].equipmentAttributes[2],
            ).toEqual(undefined);
        });

        it('should return bill of lading at load level if feature flag is enabled', () => {
            const multipleLoadAssignment = {
                ...billOfLadingWorkLoadAssignmentMock,
                trailerAssignmentType: 'BASED_ON_LOAD_COUNT',
            };
            const resourceAssignment = getResourceAssignRequest(
                multipleLoadAssignment,
                null,
                trailerInfo,
                null,
                trans,
                featureFlags,
            );
            expect(resourceAssignment.payload.plans[0].equipments[0].equipmentAttributes[2].value).toEqual(10000);
            expect(resourceAssignment.payload.plans[1].equipments[0].equipmentAttributes[2].value).toEqual(20000);
        });

        it('should return empty bill of lading at load level if feature flag is enabled', () => {
            const multipleLoadAssignment = {
                ...billOfLadingWorkLoadAssignmentMock,
                trailerAssignmentType: 'BASED_ON_LOAD_COUNT',
                billOfLading: {
                    ...billOfLadingWorkLoadAssignmentMock.billOfLading,
                    10000: '',
                },
            };
            const resourceAssignment = getResourceAssignRequest(
                multipleLoadAssignment,
                null,
                trailerInfo,
                null,
                trans,
                featureFlags,
            );
            expect(resourceAssignment.payload.plans[0].equipments[0].equipmentAttributes[2].value).toEqual('');
            expect(resourceAssignment.payload.plans[1].equipments[0].equipmentAttributes[2].value).toEqual(20000);
        });

        it('should not return bill of lading at load level if feature flag is disabled', () => {
            const multipleLoadAssignment = {
                ...billOfLadingWorkLoadAssignmentMock,
                trailerAssignmentType: 'BASED_ON_LOAD_COUNT',
            };
            const resourceAssignment = getResourceAssignRequest(
                multipleLoadAssignment,
                null,
                trailerInfo,
                null,
                trans,
                { enableBillOfLading: false },
            );
            expect(resourceAssignment.payload.plans[0].equipments[0].equipmentAttributes[2]).toEqual(undefined);
            expect(resourceAssignment.payload.plans[1].equipments[0].equipmentAttributes[2]).toEqual(undefined);
        });
    });
    describe('orginal load sequence format test', () => {
        const resourceLoadAssignmentMock = {
            ...billOfLadingWorkLoadAssignmentMock,
            orderedLoads: [{ loadId: '20000' }, { loadId: '10000' }],
        };
        it('should return orginal load sequence if feature flag is enabled', () => {
            const resourceAssignment = getResourceAssignRequest(
                resourceLoadAssignmentMock,
                null,
                trailerInfo,
                null,
                trans,
                { useOrderedLoadsForDispatchDocument: true },
            );
            expect(resourceAssignment.payload.plans[0].planId).toEqual('20000');
            expect(resourceAssignment.payload.plans[1].planId).toEqual('10000');
        });
        it('should return mapped load sequence if feature flag is disabled', () => {
            const resourceAssignment = getResourceAssignRequest(
                resourceLoadAssignmentMock,
                null,
                trailerInfo,
                null,
                trans,
                { useOrderedLoadsForDispatchDocument: false },
            );
            expect(resourceAssignment.payload.plans[0].planId).toEqual('10000');
            expect(resourceAssignment.payload.plans[1].planId).toEqual('20000');
        });
    });
});

describe('getStatusColor', () => {
    it('should return color for pending approval status', () => {
        expect(getStatusColor('PENDING_APPROVAL', { enableAwaitingFinalizationStatus: false })).toEqual('yellow');
        expect(getStatusColor('PENDING_APPROVAL', { enableAwaitingFinalizationStatus: true })).toEqual('blue');
    });

    it('should return color for In Transit - Not Started status', () => {
        expect(getStatusColor('IN_TRANSIT_NOT_STARTED')).toEqual('blue');
    });
});
