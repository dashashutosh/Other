export const staticData = {
    carriers: [
        {
            id: 790,
            value: 'AT6821001',
        },
        {
            id: 592,
            value: 'test',
        },
    ],
    locationTypes: [
        {
            id: 'BVNDR',
            value: 'BVNDR',
        },
        {
            id: 'CRLOC',
            value: 'CRLOC',
        },
    ],
    loadTypes: [
        {
            id: 'CP',
            value: 'CP',
        },
        {
            id: 'STR',
            value: 'STR',
        },
    ],
    planTypes: [
        {
            id: 'LOAD',
            value: 'LOAD',
        },
        {
            id: 'TRIP',
            value: 'TRIP',
        },
    ],
    planStatus: [
        {
            id: 'PLANNED',
            value: 'PLANNED',
        },
        {
            id: 'UNPLANNED',
            value: 'UNPLANNED',
        },
    ],
    dateTypes: [
        {
            id: 'completedTS',
            value: 'Completed date/time',
        },
        {
            id: 'dispatchTS',
            value: 'Dispatch date/time',
        },
        {
            id: 'CREATED_DATE',
            value: 'Created Date',
        },
    ],
    periodTypes: [
        {
            id: 'IN_BETWEEN',
            value: 'In Between',
        },
        {
            id: 'AFTER',
            value: 'After',
        },
        {
            id: 'BEFORE',
            value: 'Before',
        },
        {
            id: 'ON',
            value: 'On',
        },
    ],
    loadOwners: [
        {
            id: 'REQ',
            value: 'Requestor Team',
        },
    ],
    priorities: [
        {
            id: 'EXPEDITED',
            value: 'Expedited',
        },
    ],
    temperatureControls: [
        {
            id: 'AM',
            value: 'Ambient',
        },
    ],
    equipmentConfigurationIds: [
        {
            id: '17079',
            value: '17079',
        },
    ],
    ibobs: [
        {
            id: 'OB',
            value: 'Outbound',
        },
    ],
    programmeTypes: [
        {
            id: 'COL',
            value: 'COLLECT',
        },
    ],
    channels: [
        {
            id: 'RTL',
            value: 'Retail',
        },
    ],
    serviceClasses: [
        {
            id: 'GROUND',
            value: 'Ground',
        },
    ],
    serviceModes: [
        {
            id: 'PARCEL',
            value: 'Parcel',
        },
    ],
    serviceLevels: [
        {
            id: 'SINGLE',
            value: 'Single',
        },
    ],
    serviceTypes: [
        {
            id: 'DOMESTIC',
            value: 'Domestic',
        },
    ],
};
