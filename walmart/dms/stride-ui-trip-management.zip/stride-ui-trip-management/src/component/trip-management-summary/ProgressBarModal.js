import React from 'react';
import { Modal, ModalContent, ModalFooter, Typography, Button } from '@walmart/living-design-sc-ui';
import PropTypes, { bool, string, number } from 'prop-types';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
const { makeStyles } = MaterialUiCore,
    { Grid, LinearProgress } = MaterialUiCore;
const styles = makeStyles({
    infoWidth: {
        width: '30rem',
        paddingTop: '4rem',
    },
});
export default function ProgressBarModal(props) {
    const {
        pIsModalOpen,
        pOnCloseModal,
        pModalTitle1,
        pModalTitle2,
        pCancelText,
        pProgressValue,
        pTotalLength,
        pProgressInfoText,
    } = props;
    const classes = styles();
    const normalise = (value) => ((value - 0) * 100) / (pTotalLength - 0);
    return (
        <>
            <Modal isOpen={pIsModalOpen} variant="fitContent">
                <ModalContent onClose={pOnCloseModal} variant="info">
                    <Typography variant="subtitle3" align="left" className="font-weight-bold">
                        {pModalTitle1}
                    </Typography>
                    <Typography variant="subtitle1" align="left" className="font-weight-bold">
                        {pModalTitle2}
                    </Typography>
                    <div className={`pb-5 ${classes.infoWidth}`}>
                        <Grid container justify="flex-start" alignItems="left" spacing={0} direction="column">
                            <Grid item justify="flex-start">
                                <Typography variant="body2" color="text.secondary">
                                    {pProgressInfoText}
                                </Typography>
                            </Grid>
                            <Grid item justify="flex-start">
                                <Typography variant="body2" color="text.secondary">
                                    {`${pProgressValue} out of ${pTotalLength}`}
                                </Typography>
                            </Grid>
                            <Grid item justify="center">
                                <LinearProgress variant="determinate" value={normalise(pProgressValue)} />
                            </Grid>
                        </Grid>
                    </div>
                </ModalContent>
                <ModalFooter>
                    <Button variant="secondary" onClick={pOnCloseModal} size="small" color="error">
                        {pCancelText}
                    </Button>
                </ModalFooter>
            </Modal>
        </>
    );
}
ProgressBarModal.propTypes = {
    pIsModalOpen: bool.isRequired,
    pOnCloseModal: PropTypes.func.isRequired,
    pModalTitle1: string.isRequired,
    pModalTitle2: string.isRequired,
    pCancelText: string.isRequired,
    pProgressValue: number.isRequired,
    pTotalLength: number.isRequired,
    pProgressInfoText: string.isRequired,
};
