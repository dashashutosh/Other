// Market field should be same as defined markets (Ex: ca, cl,gt, us etc.)
export const readPermissions = {
    ca: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
    cl: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
    gt: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
    cr: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
    sv: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
    mx: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
    mx_mkp: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
    us: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
    ustrx: ['stride.ltm-tripManagement:READ', 'stride.tripManagement:READ'],
};

// Markets to check permissions,
export const permMarkets = ['ca', 'cl', 'gt', 'cr', 'sv', 'mx', 'us', 'ustrx', 'mx_mkp'];

export const LocationODTypes = {
    ORIGIN: 'origin',
};
