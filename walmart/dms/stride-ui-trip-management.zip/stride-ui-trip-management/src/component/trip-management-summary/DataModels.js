import moment from 'moment-timezone';
import {
    dateTimeFormatter,
    MarketCodeEnum,
    dateTimeFormatterWithTz,
    getMinutesFromHhmm,
    getProvenanceTimezone,
    transformPreviewResponseToUIModel,
    transformCAPreviewResponseToUIModel,
    getLocationTypeToIconMap,
    onSearch as onTableSearch,
    isNullOrUndefined,
    isEmpty,
    LoadTypeUtils,
    StopActivityTypeEnum,
    getStopType,
    StopTypeEnum,
} from '@walmart/stride-ui-commons';
import { format } from 'date-fns';
import CarrierStatusEnum from '../../utils/CarrierStatusEnum';
import PlanStatusEnum from '../../utils/PlanStatusEnum';
import PhaseTypesEnum from '../../utils/enums/PhaseTypesEnum';
import {
    equipmentTypesSeg,
    trailerAssignmentTypes,
    resouceAssignStatusENUM,
    WALMART_CARRIER_ID,
    connectLoads,
    excludedColumnsForPlanning,
    excludedColumnsForProcessing,
    excludeColumnsForTrip,
    EquipmentTypeEnum,
    UOMHeaders,
    planTableHeadCellsCA,
    excludedColumnsForPlanningCA,
    excludedColumnsForProcessingCA,
    excludedColumnsForReadyToStartCA,
    excludedColumnsForInTransit,
    loadTypeSTR,
    FILTER_TYPES,
    INTERMEDIATE_LOCATION_TYPE,
    HYPHEN,
    DOUBLE_TRAILER_EQUIPMENT_REGEX,
    TRIP_MODE,
    camMarkets,
    MDM_LOCATION_TYPES,
} from '../../Constants';
import TrailerAssignmentTypeEnum from '../model/trailerAssignmentTypeEnum';
import { INPUT_DATE_FORMAT } from '../../utils/ui-mappers/PlanSearchMappers';
import { PlanStatusListForAvailableTrips } from '../constants';
import { LocationODTypes } from './Constants';
import { getShortTimezoneAbbr } from '../../utils/CommonUtils';
import { getMarketSettings } from '../../utils/MarketSettings';
import TripUiWorkloadPhaseEnum from '../model/tripUiWorkloadPhaseEnum';
import LoadUiPhaseEnum from '../model/loadUiPhaseEnum';
import LoadUIStatusEnum from '../model/loadUiStatusEnum';
import {
    planningColumnsToExportUS,
    processingColumnsToExportUS,
    readyToStartColumnsToExportUS,
    inTransitColumnsToExportUS,
    deliveredColumnsToExportUS,
} from './US/DataModelsUS';
import TripUiCarrierStatusEnum from '../model/tripUiCarrierStatusEnum';
import { PLAN_ENTITY_ENUM } from '../../utils/ui-mappers/US/PlanDetailsMapper';
import TripSharedService from '../../service/TripSharedService';

const isTrip = (plan) => Array.isArray(plan?.childPlans) && !!plan.childPlans.length;
export const getStatusColor = (status, featureFlags) => {
    switch (status) {
        case CarrierStatusEnum.UNASSIGNED.name:
            return 'yellow';
        case CarrierStatusEnum.TENDER_IN_PROGRESS.name:
            return 'blue';
        case CarrierStatusEnum.ASSIGNED.name:
            return 'green';
        // TODO: selected need color
        case CarrierStatusEnum.SELECTED.name:
            return 'red';
        case CarrierStatusEnum.NEEDS_ATTENTION.name:
            return 'red';
        case PlanStatusEnum.PENDING_APPROVAL.name:
            return featureFlags?.enableAwaitingFinalizationStatus ? 'blue' : 'yellow';
        case PlanStatusEnum.UNPLANNED.name:
            return 'blue';
        // TODO: below 2 need color
        case PlanStatusEnum.WORKLOAD_ASSIGNMENT.name:
            return 'yellow';
        case PlanStatusEnum.AWAITING_FINALIZATION.name:
            return 'blue';
        case PlanStatusEnum.READY_FOR_DISPATCH.name:
            return 'blue';
        case PlanStatusEnum.IN_TRANSIT.name:
            return 'blue';

        // For CA
        // case PlanStatusEnum.PENDING_APPROVAL_LOAD.name: return 'red';
        case PlanStatusEnum.TENDER_IN_PROGRESS.name:
            return 'blue';
        case PlanStatusEnum.AWAITING_CARRIER_ASSIGNMENT.name:
            return 'blue';
        case PlanStatusEnum.TENDERS_EXHAUSTED.name:
            return 'red';
        case PlanStatusEnum.TENDER_CANCELLED.name:
            return 'yellow';
        case PlanStatusEnum.AWAITING_PICKUP.name:
            return 'green';
        case PlanStatusEnum.PICKUP_DELAYED.name:
            return 'red';
        case PlanStatusEnum.IN_TRANSIT_STARTED.name:
            return 'blue';
        case PlanStatusEnum.IN_TRANSIT_EARLY.name:
            return 'green';
        case PlanStatusEnum.IN_TRANSIT_LATE.name:
            return 'red';
        case PlanStatusEnum.IN_TRANSIT_ON_TIME.name:
        case PlanStatusEnum.IN_TRANSIT_NOT_STARTED.name:
            return 'blue';
        default:
            return '';
    }
};
export const bulkUploadProcessor = (language, arr) => {
    const filteredArr = arr.filter((item) => Object.values(item).filter((val) => val).length);
    switch (language) {
        case 'es':
            return {
                data: filteredArr.map((item) => ({
                    ...item,
                    'Fecha de recolección de carga DDMMAAAA':
                        item['Fecha de recolección de carga DDMMAAAA'] && item['Hora de recolección de carga HH:mm:ss']
                            ? moment(
                                  `${item['Fecha de recolección de carga DDMMAAAA']} ${item['Hora de recolección de carga HH:mm:ss']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Fecha de vencimiento de carga DDMMAAAA':
                        item['Fecha de vencimiento de carga DDMMAAAA'] && item['Hora de vencimiento de carga HH:mm:ss']
                            ? moment(
                                  `${item['Fecha de vencimiento de carga DDMMAAAA']} ${item['Hora de vencimiento de carga HH:mm:ss']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                })),
            };
        default:
            return {
                data: filteredArr.map((item) => ({
                    ...item,
                    'load pickup date DDMMYYYY':
                        item['load pickup date DDMMYYYY'] && item['load pickup time HH:mm:ss']
                            ? moment(
                                  `${item['load pickup date DDMMYYYY']} ${item['load pickup time HH:mm:ss']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'load due date DDMMYYYY':
                        item['load due date DDMMYYYY'] && item['load due time HH:mm:ss']
                            ? moment(
                                  `${item['load due date DDMMYYYY']} ${item['load due time HH:mm:ss']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                })),
            };
    }
};
export const bulkUploadProcessorCAM = (language, arr) => {
    const filteredArr = arr.filter((item) => Object.values(item).filter((val) => val).length);
    switch (language) {
        case 'es':
            return {
                data: filteredArr.map((item) => ({
                    ...item,
                    'Parada 1 fecha de entrega DDMMAAAA':
                        item['Parada 1 fecha de entrega DDMMAAAA'] && item['Parada 1 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 1 fecha de entrega DDMMAAAA']} ${item['Parada 1 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 2 fecha de entrega DDMMAAAA':
                        item['Parada 2 fecha de entrega DDMMAAAA'] && item['Parada 2 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 2 fecha de entrega DDMMAAAA']} ${item['Parada 2 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 3 fecha de entrega DDMMAAAA':
                        item['Parada 3 fecha de entrega DDMMAAAA'] && item['Parada 3 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 3 fecha de entrega DDMMAAAA']} ${item['Parada 3 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 4 fecha de entrega DDMMAAAA':
                        item['Parada 4 fecha de entrega DDMMAAAA'] && item['Parada 4 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 4 fecha de entrega DDMMAAAA']} ${item['Parada 4 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 5 fecha de entrega DDMMAAAA':
                        item['Parada 5 fecha de entrega DDMMAAAA'] && item['Parada 5 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 5 fecha de entrega DDMMAAAA']} ${item['Parada 5 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 6 fecha de entrega DDMMAAAA':
                        item['Parada 6 fecha de entrega DDMMAAAA'] && item['Parada 6 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 6 fecha de entrega DDMMAAAA']} ${item['Parada 6 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 7 fecha de entrega DDMMAAAA':
                        item['Parada 7 fecha de entrega DDMMAAAA'] && item['Parada 7 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 7 fecha de entrega DDMMAAAA']} ${item['Parada 7 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 8 fecha de entrega DDMMAAAA':
                        item['Parada 8 fecha de entrega DDMMAAAA'] && item['Parada 8 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 8 fecha de entrega DDMMAAAA']} ${item['Parada 8 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 9 fecha de entrega DDMMAAAA':
                        item['Parada 9 fecha de entrega DDMMAAAA'] && item['Parada 9 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 9 fecha de entrega DDMMAAAA']} ${item['Parada 9 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Parada 10 fecha de entrega DDMMAAAA':
                        item['Parada 19 fecha de entrega DDMMAAAA'] && item['Parada 10 hora de entrega HH:MM']
                            ? moment(
                                  `${item['Parada 10 fecha de entrega DDMMAAAA']} ${item['Parada 10 hora de entrega HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Fecha de inicio de viaje DDMMAAAA':
                        item['Fecha de inicio de viaje DDMMAAAA'] && item['Hora de inicio de viaje HH:MM']
                            ? moment(
                                  `${item['Fecha de inicio de viaje DDMMAAAA']} ${item['Hora de inicio de viaje HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Fecha de vencimiento de carga DDMMAAAA':
                        item['Fecha de vencimiento de carga DDMMAAAA'] && item['Hora de vencimiento de carga HH:MM']
                            ? moment(
                                  `${item['Fecha de vencimiento de carga DDMMAAAA']} ${item['Hora de vencimiento de carga HH:MM']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                })),
            };
        default:
            return {
                data: filteredArr.map((item) => ({
                    ...item,
                    'Stop 1 Drop Off date DDMMYYYY':
                        item['Stop 1 Drop Off date DDMMYYYY'] && item['Stop 1 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 1 Drop Off date DDMMYYYY']} ${item['Stop 1 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 2 Drop Off date DDMMYYYY':
                        item['Stop 2 Drop Off date DDMMYYYY'] && item['Stop 2 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 2 Drop Off date DDMMYYYY']} ${item['Stop 2 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 3 Drop Off date DDMMYYYY':
                        item['Stop 3 Drop Off date DDMMYYYY'] && item['Stop 3 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 3 Drop Off date DDMMYYYY']} ${item['Stop 3 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 4 Drop Off date DDMMYYYY':
                        item['Stop 4 Drop Off date DDMMYYYY'] && item['Stop 4 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 4 Drop Off date DDMMYYYY']} ${item['Stop 4 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 5 Drop Off date DDMMYYYY':
                        item['Stop 5 Drop Off date DDMMYYYY'] && item['Stop 5 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 5 Drop Off date DDMMYYYY']} ${item['Stop 5 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 6 Drop Off date DDMMYYYY':
                        item['Stop 6 Drop Off date DDMMYYYY'] && item['Stop 6 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 6 Drop Off date DDMMYYYY']} ${item['Stop 6 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 7 Drop Off date DDMMYYYY':
                        item['Stop 7 Drop Off date DDMMYYYY'] && item['Stop 7 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 7 Drop Off date DDMMYYYY']} ${item['Stop 7 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 8 Drop Off date DDMMYYYY':
                        item['Stop 8 Drop Off date DDMMYYYY'] && item['Stop 8 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 8 Drop Off date DDMMYYYY']} ${item['Stop 8 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 9 Drop Off date DDMMYYYY':
                        item['Stop 9 Drop Off date DDMMYYYY'] && item['Stop 9 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 9 Drop Off date DDMMYYYY']} ${item['Stop 9 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Stop 10 Drop Off date DDMMYYYY':
                        item['Stop 10 Drop Off date DDMMYYYY'] && item['Stop 10 Drop Off  time HH:mm']
                            ? moment(
                                  `${item['Stop 10 Drop Off date DDMMYYYY']} ${item['Stop 10 Drop Off  time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Trip Start date DDMMYYYY':
                        item['Trip Start date DDMMYYYY'] && item['Trip Start time HH:mm']
                            ? moment(
                                  `${item['Trip Start date DDMMYYYY']} ${item['Trip Start time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                    'Trip Completion Date DDMMYYYY':
                        item['Trip Completion Date DDMMYYYY'] && item['Trip Completion Time HH:mm']
                            ? moment(
                                  `${item['Trip Completion Date DDMMYYYY']} ${item['Trip Completion Time HH:mm']}`,
                                  'DDMMYYYY HH:mm:ss',
                              ).format('YYYY-MM-DDTHH:mm:ss.SSSZ')
                            : '',
                })),
            };
    }
};
const getFormattedDt = (date, tzCode, olsenTzId, market, featureFlags) => {
    if (market === 'cl' || market === 'mx' || market === 'mx_mkp' || camMarkets.includes(market)) {
        if (featureFlags?.enableShortTimezone) {
            return dateTimeFormatterWithTz(date, olsenTzId, tzCode);
        }
        return dateTimeFormatter(date);
    }
    if (market === 'ca') {
        if (featureFlags?.enableShortTimezone) {
            return dateTimeFormatterWithTz(date, olsenTzId, tzCode);
        }
        return tzCode && olsenTzId ? dateTimeFormatterWithTz(date, olsenTzId, tzCode) : dateTimeFormatter(date);
    }
};
const getEquipmentTypeDesc = (type, staticData) =>
    staticData?.equipmentConfigurationIds?.find((t) => t?.id === type)?.value || type;
const getClassDesc = (classCode, staticData) =>
    staticData?.serviceClasses?.find((t) => t?.id === classCode)?.value || classCode;
const getModeDesc = (modeCode, staticData) =>
    staticData?.serviceModes?.find((t) => t?.id === modeCode)?.value || modeCode;
const getServiceLevelDesc = (code, staticData) => staticData?.serviceLevels?.find((t) => t?.id === code)?.value || code;
const getServiceTypeDesc = (code, staticData) => staticData?.serviceTypes?.find((t) => t?.id === code)?.value || code;
export const getCreatedDate = (createdTs, timeZoneDetail, config) => {
    const { staticData, defaultTimeZoneId } = timeZoneDetail;
    const { featureFlags } = config;
    if (createdTs) {
        if (featureFlags?.provenanceTimezone) {
            const { olsen_timezone_id: olsenTimeZoneId, short_abbr: shortAbbr } =
                getProvenanceTimezone(staticData, defaultTimeZoneId) || {};
            return dateTimeFormatterWithTz(createdTs, olsenTimeZoneId, shortAbbr);
        }
        return dateTimeFormatter(createdTs);
    }
    return '';
};

export const getModeLabel = (mode) => {
    const { trans } = TripSharedService;
    const modeMap = {
        TL: trans('mode.Truckload'),
        DBL: trans('mode.Double'),
    };

    return modeMap[mode];
};

const getChargeLocationOfLoad = (planInfo, featureFlags) =>
    featureFlags?.enableChargeLocAssignmentForFillerMoves && planInfo?.chargeLocation?.locationId
        ? {
              chargeLocation: planInfo?.chargeLocation,
          }
        : {};
const getTripFinalDestination = (plan, featureFlags) => {
    if (
        isTrip(plan) &&
        featureFlags?.showCreateTripForDoubleTrailer &&
        plan?.activities &&
        plan?.transitDetail?.mode === TRIP_MODE.DBL
    ) {
        const childPlans = plan?.childPlans;
        const tripActivities = [...plan?.activities]?.sort((a, b) => b?.stopSequenceNumber - a?.stopSequenceNumber);
        if (
            plan?.finalDestination?.locationType === MDM_LOCATION_TYPES.DECON ||
            plan?.finalDestination?.locationType === MDM_LOCATION_TYPES.HUB
        ) {
            return childPlans?.[0]?.finalDestination;
        } else {
            return childPlans?.filter(
                (loadPlan) => loadPlan?.finalDestination?.locationId === tripActivities?.[0]?.location?.locationId,
            )?.[0]?.finalDestination;
        }
    }
    return plan?.finalDestination;
};
const getPlan = (plan, trans, configDetail) => {
    const { market, staticData, featureFlags, config } = configDetail;
    const defaultTimeZoneId = config?.defaultOlsenTimezoneId;
    const canShowShortTimezone = featureFlags?.enableShortTimezone;
    const isShortTimezonesValid = Array.isArray(staticData?.shortTimezones) && staticData.shortTimezones.length;
    const originOlsenTzId = canShowShortTimezone && !isShortTimezonesValid ? null : plan?.origin?.olsenTimezoneId;
    const originTzCode = canShowShortTimezone
        ? getShortTimezoneAbbr(originOlsenTzId, staticData?.shortTimezones)
        : plan?.origin?.timeZoneCode;
    const finalDestination = getTripFinalDestination(plan, featureFlags);
    const destinationOlsenTzId =
        canShowShortTimezone && !isShortTimezonesValid ? null : finalDestination?.olsenTimezoneId;
    const destinationTzCode = canShowShortTimezone
        ? getShortTimezoneAbbr(destinationOlsenTzId, staticData?.shortTimezones)
        : finalDestination?.timeZoneCode;
    return {
        planType: plan.planEntity,
        planEntity: isTrip(plan) ? trans('label.trip') : trans('label.load'),
        ...(featureFlags?.showRegionAndMerchandiseDetails && {
            merchandiseType: plan?.merchandiseType || '',
            originRegion: plan?.origin?.region || '',
            destinationRegion: finalDestination?.region || '',
        }),
        isApproved: plan?.isApproved,
        planId: plan?.planId?.toString() || '',
        isTrip: isTrip(plan),
        loadType: plan?.planCategory || '',
        loadCount: isTrip(plan) ? plan.childPlans.length : 0,
        originId: plan?.origin?.locationId?.toString() || '',
        originName: plan?.origin?.locationName?.toString() || '',
        ...(featureFlags?.includeTimeZoneIdInConnectingLoads && {
            originOlsenTimezoneId: originOlsenTzId,
            destinationOlsenTimezoneId: destinationOlsenTzId,
        }),
        originType: plan?.origin?.locationType?.toString() || '',
        originCode: plan?.origin?.locationCity?.toString() || '',
        destinationId: finalDestination?.locationId?.toString() || '',
        destinationName: finalDestination?.locationName?.toString() || '',
        destinationType: finalDestination?.locationType?.toString() || '',
        destinationCode: finalDestination?.locationCity?.toString() || '',
        ...(featureFlags?.validateChargeLocationOnTripDispatch && {
            chargeLocationId: plan?.chargeLocation?.locationId,
        }),
        distance: plan?.distance?.measurementValue?.toString() || '',
        distanceUoM: plan?.distance?.unitOfMeasure?.toString() || '',
        noOfStops: plan?.numberOfStops?.toString() || '',
        laneId: plan?.laneAndRate?.laneId?.toString() || '',
        rate: plan?.laneAndRate?.rate?.toString() || '',
        rateType: plan?.laneAndRate?.rateType?.toString() || '',
        rateUOM: plan?.laneAndRate?.rateUOM?.toString() || '',
        carrierId:
            plan?.carrier?.id || (featureFlags?.autoSelectCarrierInWorkLoadAssgnmt && plan?.carrierReference?.id) || '',
        carrierName: plan?.carrier?.name || '',
        carrierStatus: plan?.planTenderStatus ? trans(plan?.planTenderStatus?.desc) : '',
        // getStatusLabel(plan?.carrierAssignmentStatus, trans),
        carrierStatusColor: getStatusColor(plan?.planTenderStatus?.name),
        equipmentLength: plan?.equipmentRequirements?.length?.measurementValue?.toString() || '',
        equipmentLengthUom: plan?.equipmentRequirements?.length?.unitOfMeasure?.toString() || '',
        protectionLevel: plan?.equipmentRequirements?.protectionLevel || '',
        equipmentId: plan?.equipment?.equipmentId || plan?.equipmentRequirements?.trailerId || '',
        equipmentType: plan?.equipment?.equipmentType || '',
        driverName: plan?.driver?.name || '',
        driverId: plan?.driver?.id || '',
        ...(featureFlags?.showModeColumnInTripSummary && {
            transitDetailMode: getModeLabel(plan?.transitDetail?.mode) || '',
        }),
        cases: plan?.sizes?.cases?.measurementValue?.toString() || '',
        casesUom: plan?.sizes?.cases?.unitOfMeasure?.toString() || '',
        pallets: plan?.sizes?.pallets?.measurementValue?.toString() || '',
        palletsUom: plan?.sizes?.pallets?.unitOfMeasure?.toString() || '',
        cube: plan?.sizes?.cube?.measurementValue?.toString() || '',
        cubeUom: plan?.sizes?.cube?.unitOfMeasure?.toString() || '',
        weight: plan?.sizes?.weight?.measurementValue?.toString() || '',
        weightUom: plan?.sizes?.weight?.unitOfMeasure?.toString() || '',
        ...(featureFlags?.enableHubDeconDestinations && {
            planCarrierStatus: plan?.planTenderStatus ? plan?.planTenderStatus?.name : '',
        }),
        ...((featureFlags?.enableHubDeconDestinations || featureFlags?.showCreateTripForDoubleTrailer) &&
            plan?.planEntity === PLAN_ENTITY_ENUM.LOAD && {
                stops: plan?.stops,
            }),
        departureTs: plan?.schedules?.minPickTs
            ? getFormattedDt(plan?.schedules?.minPickTs, originTzCode, originOlsenTzId, market, featureFlags)
            : '',
        arrivalTs: plan?.schedules?.maxDueTs
            ? getFormattedDt(plan?.schedules?.maxDueTs, destinationTzCode, destinationOlsenTzId, market, featureFlags)
            : '',
        actDeparture: plan?.schedules?.actualPickupTs
            ? getFormattedDt(plan?.schedules?.actualPickupTs, originTzCode, originOlsenTzId, market, featureFlags)
            : '',
        actArrivalTs: plan?.schedules?.estimatedDeliveryTs
            ? getFormattedDt(
                  plan?.schedules?.estimatedDeliveryTs,
                  destinationTzCode,
                  destinationOlsenTzId,
                  market,
                  featureFlags,
              )
            : '',
        enrouteMilestone: plan?.enrouteStatus?.toString() || '',
        nextStop: plan?.nextStop || {},
        nextStopId: plan?.nextStop?.location?.locationId || '',
        nextStopName: plan?.nextStop?.location?.locationName || '',
        nextStopETA: plan?.nextStop?.estimatedArrivalTs ? dateTimeFormatter(plan?.nextStop?.estimatedArrivalTs) : '',
        noOfStopsLeft: plan?.uncrossedStopCount || '',
        createdTs: getCreatedDate(
            plan?.schedules?.createdTs,
            { staticData: staticData?.shortTimezones, defaultTimeZoneId },
            { featureFlags },
        ),
        planStatus: plan?.planStatus || '',
        planStatusLabel: plan?.planStatus ? trans(plan?.planStatus?.desc) : '--',
        planStatusColor: getStatusColor(plan?.planStatus?.name, featureFlags),
        maxDueTs: plan?.schedules?.maxDueTs ? plan.schedules.maxDueTs : '',
        minPickTs: plan?.schedules?.minPickTs ? plan.schedules.minPickTs : '',
        mode: plan?.carrier?.mode || '',
        serviceLevel: plan?.carrier?.serviceLevel || '',
        planWorkflowPhase: plan?.planWorkflowPhase,
        planWorkflowStatusObj: plan?.planStatus,
        isCarrierTripExist: plan?.isCarrierTripExist,
        isDispatcherTripExist: plan?.isDispatcherTripExist,
        planSequence: plan?.planSequence,
        equipmentCode: plan?.equipmentRequirements?.equipmentCode,
        tariffReq: plan?.tariffReq,
        trailerAssignmentType: plan?.equipment?.trailerAssignmentType,
        /// //////////////////////
        originCity: plan?.origin?.city?.toString() || '',
        originProvince: plan?.origin?.province?.toString() || '',
        destinationCity: finalDestination?.city?.toString() || '',
        destinationProvince: finalDestination?.province?.toString() || '',
        noOfPickupStops: plan?.noOfPickupStops?.toString() || '',
        noOfDropoffStops: plan?.noOfDropoffStops?.toString() || '',
        loadLevelType: plan?.planCategory?.toString() || '',
        class: plan?.class?.toString() || '',
        classDesc: plan?.class ? getClassDesc(plan?.class, staticData) : '',
        loadMode: plan?.mode?.toString() || '',
        loadModeDesc: plan?.mode ? getModeDesc(plan?.mode, staticData) : '',
        loadServiceLevel: plan?.serviceLevel?.toString() || '',
        loadServiceLevelDesc: plan?.serviceLevel ? getServiceLevelDesc(plan?.serviceLevel, staticData) : '',
        loadServiceType: plan?.serviceType?.toString() || '',
        loadServiceTypeDesc: plan?.serviceType ? getServiceTypeDesc(plan?.serviceType, staticData) : '',
        tempControl: plan?.tempControl?.toString() || '',
        hazmat: plan?.hazmat && plan?.hazmat === true ? trans('hazmat.true') : trans('hazmat.false') || '',
        carrierLeft: plan?.carrier?.carrierLeft || '',
        timeLeftToRespond: plan?.carrier?.timeLeftToRespond || '',
        carrierMustRespondByTsRaw: plan?.schedules?.carrierMustRespondByTs || '',
        carrierMustRespondByTsForExport: plan?.schedules?.carrierMustRespondByTs
            ? dateTimeFormatter(plan?.schedules?.carrierMustRespondByTs)
            : '',
        equipmentIdReq: plan?.equipmentRequirements?.equipmentId?.toString() || '',
        equipmentTypeReq: plan?.equipmentRequirements?.equipmentType || '',
        equipmentTrailerTypeReq: plan?.equipmentRequirements?.trailerType || '',
        equipmentTrailerTypeDescReq: plan?.equipmentRequirements?.trailerType
            ? getEquipmentTypeDesc(plan?.equipmentRequirements?.trailerType, staticData)
            : '',
        isCoherent: plan?.isCoherent,
        palletPositions: plan?.palletPositions,
        trailerId: plan?.equipmentRequirements?.trailerId,
        ...(featureFlags?.displayLoadTypeFromReference && {
            referenceLoadType: LoadTypeUtils.getLoadTypeFromReferences(
                plan?.planCategory,
                plan?.references,
                featureFlags?.displayLoadTypeFromReference,
            ),
        }),
        ...getChargeLocationOfLoad(plan, featureFlags),
        ...(featureFlags?.enableBillOfLading && {
            billOfLading: plan?.equipment?.billOfLading,
        }),
        ...(featureFlags?.enableAddMultiComment && {
            comments: plan?.comments,
        }),
    };
};
export const transformPlanPreviewData = (plan, trans, config) => ({
    ...getPlan(plan, trans, config),
    plans: plan?.childPlans ? plan.childPlans.map((load) => getPlan(load, trans, config)) : [],
});
export const transformApproveTripRequest = (tripIds) => ({
    payload: {
        planIds: tripIds,
    },
});
export const formatForceToDeleverPlanRequest = (params) => {
    const payload = {
        trackingId: params?.trackingId,
        trackingIdType: params?.trackingIdType,
    };
    const stops = [];
    // eslint-disable-next-line no-unused-expressions
    params?.stops?.forEach((sData) => {
        const transit = {
            actual: sData?.actual,
            reasonCodes: sData?.reasonCodes,
            stopId: sData?.stopId,
            stopSeqNumber: sData?.stopSeqNumber,
            stopType: sData?.stopType,
        };
        stops.push(transit);
    });
    const plans = [
        {
            ...payload,
            transits: stops,
        },
    ];
    return {
        plans,
    };
};
export const transformDispatchTripRequest = (tripIds) => ({
    planId: tripIds,
    executionStatus: PlanStatusEnum.DISPATCH.name,
});
export const transformDeliveredTripRequest = (tripIds) => ({
    planId: tripIds,
    executionStatus: PlanStatusEnum.DELIVERED.name,
});
export const manualAssignFormInitialState = {
    carrier: '',
    equipmentType: '',
    driver: '',
    tractor: '',
    truck: '',
    carrierAssignDriver: false,
    trailerAssignmentType: '',
    trailer: '',
};
export const confirmFormInitialState = {
    connectLoad: '',
    transitTime: '',
    distance: '',
};
export const getSelectedRowsText = (isTripSelected, checkedRows, trans) => {
    if (isTripSelected) {
        return checkedRows.length === 1 ? trans('planTable.tripSelected') : trans('planTable.tripsSelected');
    }
    return checkedRows.length === 1 ? trans('planTable.loadSelected') : trans('planTable.loadsSelected');
};
export const displayConfirmButton = (checkedRows, planList) => {
    if (checkedRows.length === 1) {
        const selectedLoadInfo = planList.filter((plan) => checkedRows.includes(plan.planId))[0];
        return selectedLoadInfo?.carrierStatus === TripUiCarrierStatusEnum.ASSIGNED.name;
    }
    if (checkedRows.length > 1) {
        const selectedLoadInfo = planList.filter((plan) => checkedRows.includes(plan.planId));
        let count = 0;
        selectedLoadInfo.forEach((plan) => {
            if (plan.carrierStatus === TripUiCarrierStatusEnum.ASSIGNED.name) {
                count += 1;
            }
        });
        return checkedRows.length === count;
    }
    return false;
};
export const getEquipmentTypeSeg = (type, trans) => {
    switch (type) {
        case EquipmentTypeEnum.TRACTOR:
            return trans(equipmentTypesSeg[0]?.label);
        case EquipmentTypeEnum.TRUCK:
            return trans(equipmentTypesSeg[1]?.label);
        default:
            return trans(equipmentTypesSeg[0]?.label);
    }
};
export const formatLoadEqpPair = (loads) => {
    let obj = {};
    loads.forEach((item) => {
        obj = {
            ...obj,
            [item.planId]: item?.equipmentId,
        };
    });
    return obj;
};
export const getTrailerAssignSeg = (childLoads, trans) => {
    if (childLoads.length) {
        const isAllTrailerSame = childLoads.every(
            (item) => item?.equipmentId?.toString() === childLoads[0]?.equipmentId?.toString(),
        );
        if (isAllTrailerSame) {
            return {
                trailerAssignmentType: trans(trailerAssignmentTypes[0]?.label),
                trailer: childLoads[0]?.equipmentId,
            };
        }
        return {
            trailerAssignmentType: trans(trailerAssignmentTypes[1]?.label),
            loads: formatLoadEqpPair(childLoads),
        };
    }
};
export const getWorkLoadEditData = (planDetails, trans) => ({
    carrier: planDetails?.carrierId,
    equipmentType: getEquipmentTypeSeg(planDetails?.equipmentType, trans),
    driver: planDetails?.driverId,
    tractor: planDetails?.equipmentId,
    truck: planDetails?.equipmentId,
    ...getTrailerAssignSeg(planDetails?.plans, trans),
});
export const getCountData = (search, planAggregateCount, filteredRowsCount, featureFlags) => {
    if (featureFlags?.showTotalCount && !featureFlags?.displayPhaseStatusCount) {
        return search === '' ? planAggregateCount : filteredRowsCount;
    }
    return filteredRowsCount;
};
export const getLabelWithUOM = (label, config, trans) => {
    if (label === UOMHeaders[0]) {
        return trans(label);
    }
    if (label === UOMHeaders[1]) {
        return trans(label);
    }
    if (label === UOMHeaders[2]) {
        return `${trans(label)} (${config?.UOM?.cube})`;
    }
    if (label === UOMHeaders[3]) {
        return `${trans(label)} (${config?.UOM?.weight})`;
    }
    if (label === UOMHeaders[4]) {
        return `${trans(label)} (${config?.UOM?.distance})`;
    }
};
export const displayHeaderLabel = (label, config, planLength, trans) => {
    if (UOMHeaders.indexOf(label) !== -1 && planLength) {
        return getLabelWithUOM(label, config, trans);
    }
    return trans(label);
};
export const getFooterLabels = (trans) => ({
    previous: trans('button.previous'),
    next: trans('button.next'),
});
export const transformDriverEqp = (data) => {
    const drivers = data.drivers.map((driver) => ({
        id: driver?.driverUserId,
        value: `${driver?.firstName} ${driver?.lastName}`,
    }));
    const equipmentList = data.equipments.map((e) => ({
        eqpId: e?.primary_info.equipment_id,
        mdmEqpId: e?.primary_info.mdm_equipment_id.toString(),
        masterEqpId: e.primary_info.master_equipment_type_id.toString(),
        name: e?.primary_info.equipment_id,
        eqpType: e?.primary_info.master_equipment_type_code,
        licensePlate: e?.primary_info.license_plate_nbr,
        ownerId: e?.primary_info.owner_id,
    }));
    return {
        drivers,
        equipmentList,
    };
};
export const formatEquipmentTypes = (eqp) => {
    const trailerEqps = eqp.filter((item) => item.masterEqpId?.toString() === '2');
    const tractorEqps = eqp.filter((item) => item.masterEqpId?.toString() === '1');
    const truckEqps = eqp.filter((item) => item.masterEqpId?.toString() === '3');
    const trailerTypes = trailerEqps.map((eqpment) => ({
        id: eqpment.eqpId,
        value: eqpment.name,
    }));
    const tractorTypes = tractorEqps.map((eqpment) => ({
        id: eqpment.eqpId,
        value: eqpment.name,
    }));
    const truckTypes = truckEqps.map((eqpment) => ({
        id: eqpment.eqpId,
        value: eqpment.name,
    }));
    const eqpTypes = [
        {
            id: 0,
            value: 'trailerTractor',
            label: 'label.trailerTractor',
        },
        {
            id: 1,
            value: 'truck',
            label: 'label.truck',
            equipment: truckTypes,
        },
    ];
    return {
        trailerTypes,
        tractorTypes,
        truckTypes,
        eqpTypes,
    };
};

export const getLocationIdsList = (staticData) => {
    let hubTypeId;
    let deconTypeId;
    // eslint-disable-next-line no-unused-expressions
    staticData?.locationTypes?.forEach((type) => {
        if (type?.id === INTERMEDIATE_LOCATION_TYPE?.HUB?.code) {
            hubTypeId = type?.type_id;
        }
        if (type?.id === INTERMEDIATE_LOCATION_TYPE?.DECON?.code) {
            deconTypeId = type?.type_id;
        }
    });

    if (staticData?.locations?.length) {
        const { locationList } = staticData?.locations.reduce(
            (data, loc) => {
                const locationId = loc?.id?.concat(HYPHEN, loc?.value);
                if (loc?.type_id === hubTypeId || loc?.type_id === deconTypeId) {
                    // eslint-disable-next-line no-unused-expressions
                    data?.locationList?.push({
                        locationType:
                            loc?.type_id === hubTypeId
                                ? INTERMEDIATE_LOCATION_TYPE?.HUB?.desc
                                : INTERMEDIATE_LOCATION_TYPE?.DECON?.desc,
                        locationId,
                    });
                }
                return data;
            },
            { locationList: [] },
        );
        return locationList;
    }
    return [];
};

export const getPlanLabel = (phaseStatusCount, trans) => {
    if (phaseStatusCount?.isOnlyLoads) {
        return phaseStatusCount?.exceptionCount === 1 ? trans('exception.load') : trans('exception.loads');
    }
    return phaseStatusCount?.exceptionCount === 1 ? trans('exception.plan') : trans('exception.plans');
};
export const getWorkloadAssignmentLabels = (featureFlags, trans) => ({
    modalTitle: trans('workloadAssignment.title.modalTitle'),
    carrier: trans('workloadAssignment.label.carrier'),
    infoCarrier: trans('workloadAssignment.label.infoCarrier'),
    equipmentType: trans('workloadAssignment.label.equipmentType'),
    driver: trans('workloadAssignment.label.driver'),
    trailerTractor: trans('workloadAssignment.label.trailerTractor'),
    truck: featureFlags?.useLabelChasisForTruck
        ? trans('workloadAssignment.label.chasis')
        : trans('workloadAssignment.label.truck'),
    carrierAssignDriver: trans('workloadAssignment.label.carrierAssignDriver'),
    titleTrailerDetails: trans('workloadAssignment.label.titleTrailerDetails'),
    trailerAssignment: trans('workloadAssignment.label.trailerAssignment'),
    trailer: trans('workloadAssignment.label.trailer'),
    load: trans('workloadAssignment.label.load'),
    originLocation: trans('workloadAssignment.label.originLocation'),
    destinationLocation: trans('workloadAssignment.label.destinationLocation'),
    buttonCancel: trans('workloadAssignment.label.buttonCancel'),
    buttonAssignManually: trans('workloadAssignment.label.buttonAssignManually'),
    singleTrailer: trans('workloadAssignment.label.singleTrailer'),
    onLoadCount: trans('workloadAssignment.label.onLoadCount'),
    tractor: trans('workloadAssignment.label.tractor'),
    containerId: trans('workloadAssignment.label.containerId'),
    dolly: trans('workloadAssignment.label.dolly'),
    billOfLading: trans('workloadAssignment.label.billOfLading'),
    billOfLadingError: trans('workloadAssignment.label.billOfLadingError'),
    cargo: trans('workloadAssignment.label.cargoVan'),
    car: trans('workloadAssignment.label.car'),
});
export const getCALabels = (trans) => ({
    recommended: trans('wl.label.recommended'),
    enterScac: trans('wl.label.enterScac'),
    title: trans('wl.label.title'),
    selectionType: trans('wl.label.selectionType'),
    selectCarrier: trans('wl.label.selectCarrier'),
    selectCarrierHelperText: trans('wl.label.selectCarrierHelperText'),
    cancel: trans('wl.label.cancel'),
    assign: trans('wl.label.assign'),
});
export const getTrailerAssignmentTypes = (trans) => [
    {
        id: 0,
        value: 'singleTrailer',
        label: trans('label.singleTrailer'),
    },
    {
        id: 1,
        value: 'onLoadCount',
        label: trans('label.onLoadCount'),
    },
];
export const getEquipmentTypes = (featureFlags, trans) => {
    const typeArr = [
        {
            id: 0,
            value: 'trailerTractor',
            label: trans('workloadAssignment.label.trailerTractor'),
        },
        {
            id: 1,
            value: 'truck',
            label: featureFlags?.useLabelChasisForTruck
                ? trans('workloadAssignment.label.chasis')
                : trans('workloadAssignment.label.truck'),
        },
    ];
    const newTypeArr = [
        {
            id: 2,
            value: 'cargo',
            label: trans('workloadAssignment.label.cargoVan'),
        },
        {
            id: 3,
            value: 'car',
            label: trans('workloadAssignment.label.car'),
        },
    ];
    return featureFlags?.enableNewEquipmentTypes ? [...typeArr, ...newTypeArr] : typeArr;
};
export const getEquipmentsOfSelectedCarrier = (equipments, selectedCarrier, enableNewTypes = false) => {
    const equipmentGroupedByType = {
        trailer: [],
        truck: [],
        tractor: [],
    };
    if (enableNewTypes) {
        equipmentGroupedByType['cargo'] = [];
        equipmentGroupedByType['car'] = [];
    }
    // eslint-disable-next-line no-unused-expressions
    equipments[selectedCarrier]?.forEach((equipment) => {
        const key = equipment?.type.toLowerCase();
        equipmentGroupedByType[key].push(equipment);
    });
    return equipmentGroupedByType;
};
export const getWarningMessage = (warningMessage) => {
    const message = `${warningMessage?.driver}
  ${warningMessage?.equipment}
  ${warningMessage?.trailer}`;
    return message.trim();
};
export const getFormattedEquipmentAPIValidationError = (error) => {
    const detailsInErrorResponse = error?.errors?.[0]?.errorIdentifiers?.details;
    const validateResponse = detailsInErrorResponse?.resource_details;
    const messages = validateResponse?.messages;
    if (!validateResponse?.validResourceAssignment || validateResponse?.status === 'ERROR') {
        let errorMsg = '';
        if (messages?.length > 0) {
            messages.forEach((message) => {
                errorMsg += `${message?.description} `;
            });
        }
        return errorMsg;
    }
    return error;
};
export const getTrailerErrorList = (workloadAssignmentData, equipmentDetails, trailerDetails) => {
    const { equipmentInfo, equipmentsOfSelectedCarrier, equipmentTypes } = equipmentDetails;
    const { trailerAssgnmntTypes, trailerInfo } = trailerDetails;
    const trailerErrorList = [];
    if (!equipmentInfo) {
        if (workloadAssignmentData?.equipmentType === equipmentTypes[0]?.label && workloadAssignmentData?.tractor) {
            const eqpTractorObj = equipmentsOfSelectedCarrier?.tractor.find(
                (item) => item?.id === workloadAssignmentData?.tractor,
            );
            const errMsg = eqpTractorObj?.value;
            trailerErrorList.push(errMsg);
        } else if (
            workloadAssignmentData?.equipmentType === equipmentTypes[1]?.label &&
            workloadAssignmentData?.truck
        ) {
            const eqpTruckObj = equipmentsOfSelectedCarrier?.truck.find(
                (item) => item?.id === workloadAssignmentData?.truck,
            );
            const errMsg = eqpTruckObj?.value;
            if (errMsg) {
                trailerErrorList.push(errMsg);
            }
        }
    }
    if (workloadAssignmentData?.loads && workloadAssignmentData?.equipmentType === equipmentTypes[0]?.label) {
        let eqpTrailerObj = null;
        if (workloadAssignmentData?.trailerAssignmentType === trailerAssgnmntTypes[1]?.label) {
            Object.keys(workloadAssignmentData?.loads).forEach((key) => {
                if (workloadAssignmentData?.loads[key] && !trailerInfo[workloadAssignmentData?.loads[key]]) {
                    eqpTrailerObj = equipmentsOfSelectedCarrier?.trailer.find(
                        (item) => item.id === workloadAssignmentData?.loads[key],
                    );
                    const errMsg = eqpTrailerObj?.value;
                    trailerErrorList.push(errMsg);
                }
            });
        } else if (workloadAssignmentData?.trailerAssignmentType === trailerAssgnmntTypes[0]?.label) {
            if (workloadAssignmentData?.trailer && !trailerInfo[workloadAssignmentData?.trailer]) {
                eqpTrailerObj = equipmentsOfSelectedCarrier?.trailer.find(
                    (item) => item.id === workloadAssignmentData?.trailer,
                );
                const errMsg = eqpTrailerObj?.value;
                trailerErrorList.push(errMsg);
            }
        }
    }
    return trailerErrorList;
};
export const transformLoads = (data) => {
    const loads = data.map((load) => ({
        loadId: load?.planId,
        originId: load?.originId,
        originValue: load?.originName,
        originType: load?.originType,
        destinationId: load?.destinationId,
        destinationValue: load?.destinationName,
        destinationType: load?.destinationType,
        loadType: load?.loadType,
        trailerCode: load?.equipmentCode,
    }));
    return loads;
};
export const transformLoadsToEditTailer = (data) => {
    const loads = data.map((load) => ({
        loadId: load?.planId,
        loadType: load?.loadType,
        originId: load?.originId,
        originValue: load?.originName,
        originType: load?.originType,
        originTypeToIcon: getLocationTypeToIconMap(load?.originType),
        destinationId: load?.destinationId,
        destinationValue: load?.destinationName,
        destinationType: load?.destinationType,
        destinationTypeToIcon: getLocationTypeToIconMap(load?.destinationType),
        trailerId: load?.trailerId !== '--' ? load?.trailerId : '',
        equipmentCode: load?.equipmentCode ? load?.equipmentCode : undefined,
    }));
    return loads;
};
export const formatCarrierRequest = (data) => ({
    driverRequest: {
        payload: {
            driverCompany: [data],
            active: true,
        },
    },
    equipmentRequest: {
        owner: [data],
        status_code: ['A'],
        max_row: 5000,
    },
});
export const formatCreateTripReq = (data, loads) => ({
    payload: loads.map((load) => ({
        identifiers: null,
        plans: [
            {
                identifiers: {
                    planId: load,
                },
            },
        ],
    })),
});

export const transformLoadsToUpdateDestination = (data) =>
    data?.map((load) => ({
        loadId: load?.planId,
        origin: load?.originType.concat(HYPHEN, load?.originId),
        departureTs: new Date(load?.departureTs),
        arrivalTs: new Date(load?.arrivalTs),
        originName: load?.originName,
        originType: load?.originType,
        originId: load?.originId,
        destinationId: load?.destinationId,
        destinationName: load?.destinationName,
        destinationType: load?.destinationType,
    }));

const basedOnLoadCountList = (data, driverEqpData) => {
    const planList = [];
    Object.keys(data).forEach((loadId) => {
        const eqpObj = driverEqpData.equipmentList.find((eqp) => data[loadId] === eqp.eqpId);
        const plan = {
            planId: loadId,
            equipment: {
                equipmentType: eqpObj.eqpType,
                equipmentId: eqpObj.eqpId,
                equipmentOwner: eqpObj.ownerId,
                equipmentAttributes: [
                    {
                        name: 'licensePlate',
                        value: eqpObj.licensePlate,
                    },
                ],
            },
        };
        planList.push(plan);
    });
    return planList;
};
const singleTrailerLoadList = (eqpObj, loads) => {
    const planList = loads.map((item) => ({
        planId: item.planId,
        equipment: {
            equipmentType: eqpObj.eqpType,
            equipmentId: eqpObj.eqpId,
            equipmentOwner: eqpObj.ownerId,
            equipmentAttributes: [
                {
                    name: 'licensePlate',
                    value: eqpObj.licensePlate,
                },
            ],
        },
    }));
    return planList;
};
export const formatAssignWorkLoadReq = (modalData, loggedInUser, rowData, driverEqpData, trans) => {
    let eqpTypeObj = null;
    let assignObj = null;
    let loadWiseList = [];
    const eqpSegId = equipmentTypesSeg.find((item) => trans(item.label) === modalData?.equipmentType)?.id;
    if (eqpSegId === 0 && modalData.tractor) {
        eqpTypeObj = driverEqpData.equipmentList.find((eqp) => modalData.tractor === eqp.eqpId);
    } else if (eqpSegId === 1 && modalData.truck) {
        eqpTypeObj = driverEqpData.equipmentList.find((eqp) => modalData.truck === eqp.eqpId);
    }
    const trailerAssSegId = trailerAssignmentTypes.find(
        (item) => trans(item.label) === modalData?.trailerAssignmentType,
    )?.id;
    if (trailerAssSegId === 0 && modalData.trailer) {
        assignObj = driverEqpData.equipmentList.find((eqp) => modalData.trailer === eqp.eqpId);
        loadWiseList = singleTrailerLoadList(assignObj, rowData.plans);
    } else if (trailerAssSegId === 1 && modalData.loads) {
        loadWiseList = basedOnLoadCountList(modalData.loads, driverEqpData);
    }
    const payload = {
        assignCarrierRequest: {
            carrier: {
                assignedTs: new Date(),
                carrierId: modalData.carrier.toString(),
                createdBy: loggedInUser,
                dispatchOffice: '',
                // todo: we can remove as it is optional
                dueTs: rowData.maxDueTs,
                laneId: rowData.laneId,
                lastUpdatedBy: loggedInUser,
                mode: rowData.mode,
                mustRespondByDateTime: '',
                // todo: we can remove as it is optional
                pickupTs: rowData.minPickTs,
                protectionLevel: rowData.protectionLevel,
                scac: modalData.carrier.toString(),
                serviceLevel: rowData.serviceLevel,
                status: 'ASSIGNED',
            },
            planId: rowData.planId,
        },
        assignResourceRequest: {
            payload: {
                carrierId: modalData.carrier.toString(),
                resource: {
                    driverId: modalData.driver ? modalData.driver.toString() : '',
                    driverAttributes: [
                        {
                            key: '',
                            // todo: not applicable here
                            value: '', // todo: not applicable here
                        },
                    ],

                    equipment: {
                        equipmentType: eqpTypeObj ? eqpTypeObj.eqpType : '',
                        equipmentId: eqpTypeObj ? eqpTypeObj.eqpId : '',
                        equipmentAttributes: [
                            {
                                name: 'licensePlate',
                                value: eqpTypeObj ? eqpTypeObj.licensePlate : '',
                            },
                        ],
                    },
                    plans: loadWiseList,
                },
            },
        },
    };
    return payload;
};
export const searchLTReqPayloadForAvailableTrips = (pageNumber) => ({
    payload: {
        page: pageNumber,
        status: PlanStatusListForAvailableTrips,
        sortField: 'PLAN_CREATED_TIME',
        sortMode: 'DSC',
    },
});
export const searchPayloadForFilterGT = (planIds) => ({
    payload: {
        page: 1,
        planIds,
        status: PlanStatusListForAvailableTrips,
        sortField: 'PLAN_CREATED_TIME',
        sortMode: 'DSC',
    },
});
export const searchReqPayload = {
    tripManagementSearch: {
        payload: {
            origins: [
                {
                    countryCode: 'CL',
                    locationId: 6001,
                    locationType: 'DC',
                },
            ],
            destinations: [
                {
                    countryCode: 'CL',
                    locationId: 751,
                    locationType: 'STORE',
                },
            ],
        },
    },
    carrierSearch: {
        origin: {
            countryCode: 'CL',
            locationId: 6001,
            locationType: 'DC',
        },
        destination: {
            countryCode: 'CL',
            locationId: 751,
            locationType: 'STORE',
        },
    },
    dispatchSearch: {
        origins: ['6001'],
        destinations: ['751'],
    },
};
export const transformTenderRequest = (tripIds) => ({
    planId: tripIds,
    carrier: null,
});
export const processCarriersResponse = (carriers, carrierCodes) => {
    const carrierList = [];
    const carrierCodeMap = {};
    const carrierMap = {};
    carrierCodes.forEach((carrierCode) => {
        carrierCodeMap[carrierCode.mdm_carrier_id] = carrierCode.carrier_id;
    });
    carriers.forEach((carrier) => {
        carrierMap[carrier.mdm_carrier_id] = carrier.carrier_name;
    });
    Object.keys(carrierCodeMap).forEach((mdmId) => {
        carrierList.push({
            id: carrierCodeMap[mdmId],
            name: carrierMap[mdmId],
            value: `${carrierCodeMap[mdmId]}-${carrierMap[mdmId]}`,
        });
    });
    return carrierList;
};
export const processDriversResponse = (drivers) =>
    drivers.map((driver) => ({
        id: driver.driverUserId,
        value: `${driver.driverUserId}-${driver.firstName} ${driver.lastName}`,
        name: `${driver.firstName} ${driver.lastName}`,
    }));
export const processEquipmentsResponse = (
    equipments,
    tariffList,
    currentMarket,
    restrictEquipmentCode = undefined,
    pLoads = undefined,
) => {
    let primaryLoadEqupmntCode;
    if (restrictEquipmentCode) {
        const primaryLoad = pLoads?.find((load) => load?.loadType?.toLowerCase() === 'str');
        primaryLoadEqupmntCode = primaryLoad?.trailerCode;
    }
    const equipmentType = tariffList?.reduce((equipmentMap, tariff) => {
        tariff.tariff_details.map((x, i) => {
            // eslint-disable-next-line no-param-reassign
            equipmentMap[tariff.tariff_details[i].equipment_code || primaryLoadEqupmntCode] = true;
            return equipmentMap;
        });
        return equipmentMap;
    }, {});
    const equipmentList = Object.keys(equipmentType);
    const marketSettings = getMarketSettings(currentMarket);
    return equipments.reduce((acc, equipment) => {
        const tarrifMatch = equipmentList.find(
            (equipmentCode) =>
                equipmentCode === equipment?.equipment_type_config?.primary_info?.equipment_type_config_code ||
                equipment?.equipment_type_config?.primary_info?.master_equipment_type_code === 'TRACTOR' ||
                (marketSettings.enableNewEquipmentTypes &&
                    (equipment?.equipment_type_config?.primary_info?.master_equipment_type_code === 'CARGO' ||
                        equipment?.equipment_type_config?.primary_info?.master_equipment_type_code === 'CAR')) ||
                (marketSettings.showTrailerEquipments &&
                    equipment?.equipment_type_config?.primary_info?.master_equipment_type_code === 'TRAILER'),
        );
        if (tarrifMatch) {
            acc.push({
                id: equipment.primary_info.equipment_id,
                value: `${
                    marketSettings.showEquipmentIdForVehicle
                        ? equipment.primary_info.equipment_id
                        : equipment.primary_info.license_plate_nbr
                } - ${equipment.primary_info.owner_name}`,
                type: equipment.primary_info.master_equipment_type_code,
            });
        }
        return acc;
    }, []);
};
export const formatLoadsForWorkloadAssignment = (loads) =>
    loads.map((load) => ({
        loadId: load.loadNumber,
        originId: load.origin.locationId,
        originValue: load.origin.locationName,
        destinationId: load.destination.locationId,
        destinationValue: load.destination.locationName,
    }));
export const getEquipmentDriverRequestPayload = (carrierId, sCarrierCodes, loadTariffData, featureFlag) => {
    const selectedCarrierCode = sCarrierCodes.find((carrierCode) => carrierCode.carrier_id === carrierId.toString());
    const walmartCarrierId = sCarrierCodes.find((carrierCode) => carrierCode.carrier_id === WALMART_CARRIER_ID);
    const equipmentOwner = [selectedCarrierCode?.mdm_carrier_id];
    if (carrierId !== WALMART_CARRIER_ID && walmartCarrierId) {
        equipmentOwner.push(walmartCarrierId?.mdm_carrier_id);
    }
    if (featureFlag?.walmartCarrierID) {
        equipmentOwner.push(featureFlag?.walmartCarrierID);
    }
    const featureFlags = TripSharedService.getFeatureFlags();
    const driverPayload = {
        driverCompany: featureFlags?.enableVendorNumber ? [selectedCarrierCode?.vendor_nbr] : [carrierId],
        active: true,
    };
    const equipmentPayload = {
        owner: equipmentOwner,
        status_code: ['A'],
        max_row: 5000,
        ...(featureFlags?.enableVendorNumber && { vendor: [selectedCarrierCode?.vendor_nbr] }),
    };
    const shouldSendServiceLevel = featureFlag?.hideServiceLevelRequest
        ? false
        : !(loadTariffData?.isDouble && featureFlag?.showCreateTripForDoubleTrailer);
    return {
        driverRequest: {
            payload: driverPayload,
        },
        equipmentRequest: {
            ...equipmentPayload,
        },
        carrierRequest: {
            mdm_carrier_id: selectedCarrierCode?.mdm_carrier_id,
        },
        tariffRequest: {
            origin: {
                location_id: loadTariffData?.origin?.locationId,
                location_type_code: loadTariffData?.origin?.locationType,
            },
            destination: {
                location_id: loadTariffData?.destination?.locationId,
                location_type_code: loadTariffData?.destination?.locationType,
            },
            carrier_id: carrierId,
            mode: loadTariffData?.transitDetail?.mode,
            protection_level: loadTariffData?.transitDetail?.protectionLevel,
            ...(shouldSendServiceLevel && {
                service_level: loadTariffData?.transitDetail?.serviceLevel,
            }),
            equipment_type_code: !featureFlag?.restrictEquipmentCode
                ? loadTariffData?.equipment?.equipmentCode
                : undefined,
        },
    };
};
export const getDriverValidateRequestPayload = (driverId, planId, carrierId) => ({
    planId,
    carrierId,
    resources: [
        {
            driverId,
        },
    ],
});
export const getTractorTruckValidateRequestPayload = (equipmentId, planId, equipmentType, carrierId) => ({
    payload: {
        equipment_fetch_request: {
            equipment_id: equipmentId,
        },
        resource_request: {
            equipments: [
                {
                    equipmentId,
                    equipmentType,
                },
            ],
            planId,
            carrierId,
        },
    },
});
export const getTrailerValidateRequestPayload = (loadEquipmentIdMap, equipmentId, planId, carrierId) => ({
    payload: {
        equipment_fetch_request: {
            equipment_id: equipmentId,
        },
        resource_request: {
            planId,
            carrierId,
            plans: Object.keys(loadEquipmentIdMap).map((loadId) => ({
                equipments: [
                    {
                        equipmentId: loadEquipmentIdMap[loadId],
                        equipmentType: 'TRAILER',
                    },
                ],
                planId: loadId,
            })),
            // plans: [
            //   {
            //     equipments: [
            //       {
            //         equipmentId,
            //         equipmentType: 'TRAILER',
            //       },
            //     ],
            //     planId: loadEquipmentIdMap, // load id
            //   },
            // ],
        },
    },
});

export const getEquipmentValidateRequestPayload = (equipmentID, driverID, planId) => {
    if (driverID) {
        return {
            equipment_fetch_request: {
                equipment_id: equipmentID,
            },
            resource_request: {
                planId,
            },
            // equipment_validate_request: {
            //   equipments: [
            //     {
            //       equipmentId: equipmentID,
            //     },
            //   ],
            //   resources: [
            //     {
            //       driverId: driverID,
            //     },
            //   ],
            // },
        };
    }

    return {
        equipment_fetch_request: {
            equipment_id: equipmentID,
        },
        resource_request: {
            planId,
        },
        // equipment_validate_request: {
        //   equipments: [
        //     {
        //       equipmentId: equipmentID,
        //     },
        //   ],
        // },
    };
};

const getWorkloadRequestForPlans = (loads, isTAndTSelected, featureFlags) =>
    loads.map((load) => ({
        planId: load.planId,
        equipments:
            isTAndTSelected && load?.equipmentInfo
                ? [
                      {
                          equipmentId: load?.equipmentInfo?.primary_info?.equipment_id || '',
                          equipmentOwner: load?.equipmentInfo?.primary_info?.owner_name || '',
                          equipmentType:
                              load?.equipmentInfo?.equipment_type_config?.primary_info?.master_equipment_type_code ||
                              '',
                          equipmentAttributes: [
                              {
                                  name: 'trailerType',
                                  value: '',
                              },
                              {
                                  name: 'licensePlate',
                                  value: load?.equipmentInfo?.primary_info?.license_plate_nbr || '',
                              },
                              ...(featureFlags?.enableBillOfLading
                                  ? [
                                        {
                                            name: 'billOfLading',
                                            value: load?.billOfLading,
                                        },
                                    ]
                                  : []),
                          ],
                      },
                  ]
                : [],
        equipmentRequirements:
            isTAndTSelected && load?.equipmentInfo
                ? [
                      {
                          equipmentType: load?.equipmentInfo?.equipmentType || '',
                          equipmentAttributes: [
                              {
                                  name: 'skill',
                                  value: load?.equipmentInfo?.equipment_skills[0]?.skill_id || '',
                              },
                              {
                                  name: 'TrailerLength',
                                  value: load?.equipmentInfo?.config_details?.dimensions?.exterior_length || '',
                              },
                          ],
                      },
                  ]
                : [],
    }));
// TODO: work on updating the format of this request
export const getWorkloadAssignmentRequest = (
    workloadAssignment,
    { carrierInfo, equipmentInfo, trailerInfo },
    planId,
    userId,
) => {
    const childPlansInfo = [];
    if (workloadAssignment?.loads) {
        Object.keys(workloadAssignment?.loads).forEach((loadId) => {
            const trailer = {};
            trailer.planId = loadId;
            trailer.equipmentInfo = trailerInfo[workloadAssignment.loads[loadId]];
            childPlansInfo.push(trailer);
        });
    }
    return {
        carrierAssignRequest: {
            planId: parseInt(planId, 10),
            carrier: {
                createdBy: userId,
                lastUpdatedBy: userId,
                scac: workloadAssignment?.carrier || '',
                carrierId: workloadAssignment?.carrier || '',
                carrierName: workloadAssignment?.carrierName || '',
                mode: carrierInfo?.carrier_identifiers[0].carrier_services[0]?.mode_code || '',
                serviceLevel: carrierInfo?.carrier_identifiers[0]?.carrier_services[0]?.service_level_code || '',
                protectionLevel: carrierInfo?.carrier_identifiers[0]?.carrier_services[0]?.protection_level_code || '',
                assignedBy: 'Manual',
                assignedSystem: 'STRIDE_UI',
            },
        },
        resourceAssignRequest: {
            payload: {
                resourceAssignmentStatus: 'RESOURCES_ASSIGNED',
                // TODO : change this
                planId: parseInt(planId, 10),
                carrierId: workloadAssignment?.carrier || '',
                resources: [
                    {
                        driverId: workloadAssignment?.driver || '',
                        driverAttributes: [
                            {
                                key: 'name',
                                value: workloadAssignment?.driverName || '',
                            },
                        ],
                    },
                ],
                equipments: [
                    {
                        equipmentId: equipmentInfo?.primary_info?.equipment_id || '',
                        equipmentOwner: workloadAssignment?.carrier || '',
                        // equipmentInfo?.primary_info?.owner_name
                        equipmentType: equipmentInfo?.primary_info?.master_equipment_type_code || '',
                        // TRUCK/TRACTOR/TRAILER
                        equipmentAttributes: [
                            {
                                name: 'license_plate_nbr',
                                value: equipmentInfo?.primary_info?.license_plate_nbr || '',
                            },
                            // {
                            //   name: 'master_equipment_type_code',
                            //   value: equipmentInfo?.primary_info?.master_equipment_type_code || '',
                            // },
                        ],
                    },
                ],

                equipmentRequirements: [
                    {
                        equipmentType: equipmentInfo?.primary_info?.equipment_type_config_code || '',
                        equipmentAttributes: [],
                    },
                ],
                plans: getWorkloadRequestForPlans(childPlansInfo),
            },
        },
    };
};

/// ///////////////////////////////////////////////////////////////////////////

export const getCarrierAssignRequest = (workloadAssignment, carrierInfo, selectedTrip, userId) => ({
    planId: selectedTrip ? parseInt(selectedTrip, 10) : null,
    // int
    carrier: {
        createdBy: userId,
        lastUpdatedBy: userId,
        scac: workloadAssignment?.carrier || '',
        carrierId: workloadAssignment?.carrier || '',
        carrierName: workloadAssignment?.carrierName || '',
        mode: carrierInfo?.carrier_identifiers?.[0]?.carrier_services[0]?.mode_code || carrierInfo?.loadMode || '',
        serviceLevel:
            carrierInfo?.carrier_identifiers?.[0]?.carrier_services[0]?.service_level_code ||
            carrierInfo?.loadServiceLevel ||
            '',
        protectionLevel:
            carrierInfo?.carrier_identifiers?.[0]?.carrier_services[0]?.protection_level_code ||
            carrierInfo?.protectionLevel ||
            '',
        assignedBy: 'Manual',
        assignedSystem: 'STRIDE_UI',
        autoAccept: workloadAssignment?.autoAccept,
    },
    ...(workloadAssignment?.dolly?.length ? { dolly: workloadAssignment?.dolly } : {}),
});
function getLoadsAssignedWithTrailer(data) {
    if (!data.loads || Object.keys(data.loads).length === 0) return 0;
    let count = 0;
    const keys = Object.keys(data.loads);
    keys.forEach((key) => {
        if (data.loads[key] && data.loads[key] !== '') count += 1;
    });
    return count;
}
function isAllResourcesUnassigned(data, isTrailerTractorSelected, isSingleLoadSelected, loadsAssignedWithTrailer) {
    if (data.driver?.length) return false;
    if (!isTrailerTractorSelected && !data.truck?.length) {
        return true;
    }
    if (isTrailerTractorSelected && isSingleLoadSelected && !data.tractor?.length && !data.trailer?.length) {
        return true;
    }
    if (isTrailerTractorSelected && !isSingleLoadSelected && !data.tractor?.length && loadsAssignedWithTrailer === 0) {
        return true;
    }
    return false;
}
function isAllResourcesAssigned(data, isTrailerTractorSelected, isSingleLoadSelected, loadsAssignedWithTrailer) {
    if (!data.driver?.length) return false;
    if (!isTrailerTractorSelected && data.truck?.length) {
        return true;
    }
    if (isTrailerTractorSelected && isSingleLoadSelected && data.tractor?.length && data.trailer?.length) {
        return true;
    }
    if (
        isTrailerTractorSelected &&
        !isSingleLoadSelected &&
        data.tractor?.length &&
        loadsAssignedWithTrailer === data.numberOfLoads
    ) {
        return true;
    }
    return false;
}
export const getTrailerAssignmentTypeLabel = (label, trans) => {
    const map = {
        [TrailerAssignmentTypeEnum.SINGLE_TRAILER.name]: trans(TrailerAssignmentTypeEnum.SINGLE_TRAILER.desc),
        [TrailerAssignmentTypeEnum.BASED_ON_LOAD_COUNT.name]: trans(TrailerAssignmentTypeEnum.BASED_ON_LOAD_COUNT.desc),
        [trans(TrailerAssignmentTypeEnum.SINGLE_TRAILER.desc)]: TrailerAssignmentTypeEnum.SINGLE_TRAILER.name,
        [trans(TrailerAssignmentTypeEnum.BASED_ON_LOAD_COUNT.desc)]: TrailerAssignmentTypeEnum.BASED_ON_LOAD_COUNT.name,
    };
    return map[label];
};
const getResAssignStatus = (data, trans) => {
    if (!data || !data.carrier) return resouceAssignStatusENUM.RESOURCE_UNASSINED;
    const loadsAssignedWithTrailer = getLoadsAssignedWithTrailer(data);
    const isTrailerTractorSelected = data?.equipmentType === trans('workloadAssignment.label.trailerTractor');
    const isSingleLoadSelected = data?.trailerAssignmentType === trans('workloadAssignment.label.singleTrailer');
    if (isAllResourcesUnassigned(data, isTrailerTractorSelected, isSingleLoadSelected, loadsAssignedWithTrailer)) {
        return resouceAssignStatusENUM.RESOURCE_UNASSINED;
    }
    if (isAllResourcesAssigned(data, isTrailerTractorSelected, isSingleLoadSelected, loadsAssignedWithTrailer)) {
        return resouceAssignStatusENUM.RESOURCE_ASSINGED;
    }
    return resouceAssignStatusENUM.RESOURCE_ASSIGN_IN_PROGRESS;
};
export const getResourceAssignRequest = (
    workloadAssignment,
    equipmentInfo,
    trailerInfo,
    selectedTrip,
    trans,
    featureFlags,
) => {
    const isTrailerTractorSelected =
        workloadAssignment?.equipmentType === trans('workloadAssignment.label.trailerTractor');
    const childPlansInfo = [];
    const isSingleTrailerAssignment =
        getTrailerAssignmentTypeLabel(workloadAssignment?.trailerAssignmentType, trans) ===
        TrailerAssignmentTypeEnum.SINGLE_TRAILER.name;
    if (
        workloadAssignment?.loads ||
        (featureFlags?.useOrderedLoadsForDispatchDocument && workloadAssignment?.orderedLoads)
    ) {
        const loadArray = featureFlags?.useOrderedLoadsForDispatchDocument
            ? workloadAssignment?.orderedLoads
            : Object.keys(workloadAssignment?.loads);
        loadArray.forEach((load) => {
            const trailer = {};
            const loadId = featureFlags?.useOrderedLoadsForDispatchDocument ? load?.loadId : load;
            trailer.planId = loadId;
            trailer.equipmentInfo = workloadAssignment.loads[loadId]
                ? trailerInfo[workloadAssignment.loads[loadId]]
                : undefined;
            const trailerInformation = {
                ...trailer,
                ...(featureFlags?.enableBillOfLading && {
                    billOfLading: isSingleTrailerAssignment
                        ? workloadAssignment?.billOfLading?.default
                        : workloadAssignment?.billOfLading?.[loadId] || '',
                }),
            };
            childPlansInfo.push(trailerInformation);
        });
    }
    return {
        payload: {
            resourceAssignmentStatus: getResAssignStatus(workloadAssignment, trans),
            planId: selectedTrip ? parseInt(selectedTrip, 10) : null,
            carrierId: workloadAssignment?.carrier || '',
            resources: workloadAssignment?.driver
                ? [
                      {
                          driverId: workloadAssignment?.driver || '',
                          driverAttributes: [
                              {
                                  key: 'name',
                                  value: workloadAssignment?.driverName || '',
                              },
                          ],
                      },
                  ]
                : [],
            equipments:
                (isTrailerTractorSelected && workloadAssignment?.tractor) ||
                (!isTrailerTractorSelected && workloadAssignment?.truck) ||
                (featureFlags?.enableNewEquipmentTypes &&
                    ((!isTrailerTractorSelected && workloadAssignment?.cargo) ||
                        (!isTrailerTractorSelected && workloadAssignment?.car)))
                    ? [
                          {
                              equipmentId: equipmentInfo?.primary_info?.equipment_id || '',
                              equipmentOwner: workloadAssignment?.carrier || '',
                              equipmentType: equipmentInfo?.primary_info?.master_equipment_type_code || '',
                              // TRUCK/TRACTOR/TRAILER
                              equipmentAttributes: [
                                  {
                                      name: 'license_plate_nbr',
                                      value: equipmentInfo?.primary_info?.license_plate_nbr || '',
                                  },
                                  {
                                      name: 'trailerAssignmentType',
                                      value: isTrailerTractorSelected
                                          ? getTrailerAssignmentTypeLabel(
                                                workloadAssignment?.trailerAssignmentType,
                                                trans,
                                            )
                                          : '',
                                  },
                                  ...(featureFlags?.enableBillOfLading
                                      ? [
                                            {
                                                name: 'billOfLading',
                                                value: workloadAssignment?.billOfLading?.default || '',
                                            },
                                        ]
                                      : []),
                              ],
                          },
                      ]
                    : [],
            equipmentRequirements:
                (isTrailerTractorSelected && workloadAssignment?.tractor) ||
                (!isTrailerTractorSelected && workloadAssignment?.truck) ||
                (featureFlags?.enableNewEquipmentTypes &&
                    ((!isTrailerTractorSelected && workloadAssignment?.cargo) ||
                        (!isTrailerTractorSelected && workloadAssignment?.car)))
                    ? [
                          {
                              equipmentType: equipmentInfo?.primary_info?.equipment_type_config_code || '',
                              equipmentAttributes: [],
                          },
                      ]
                    : [],
            plans: getWorkloadRequestForPlans(childPlansInfo, isTrailerTractorSelected, featureFlags),
            ...(workloadAssignment?.dolly?.length ? { dolly: workloadAssignment?.dolly } : {}),
        },
    };
};
export const getCarrierResourceAssignRequest = (
    workloadAssignment,
    { carrierInfo, equipmentInfo, trailerInfo },
    selectedTrip,
    userId,
    trans,
    featureFlags = {},
) => ({
    carrierAssignRequest: getCarrierAssignRequest(workloadAssignment, carrierInfo, selectedTrip, userId),
    resourceAssignRequest: getResourceAssignRequest(
        workloadAssignment,
        equipmentInfo,
        trailerInfo,
        selectedTrip,
        trans,
        featureFlags,
    ),
});
export const parseResourceAssignRequest = (req, selectedTrip, currentMarket) => {
    const marketSettings = getMarketSettings(currentMarket);
    const requestPayload = req?.payload;
    const sortingArr = selectedTrip.childPlans.sort((a, b) => a.planSequence - b.planSequence).map((p) => p.planId);
    return {
        payload: {
            ...requestPayload,
            plans: marketSettings.sortPlansForDispatcher
                ? requestPayload.plans.sort(
                      (a, b) => sortingArr.indexOf(parseInt(a.planId, 10)) - sortingArr.indexOf(parseInt(b.planId, 10)),
                  )
                : requestPayload.plans,
        },
    };
};
const planningColumnsToExportCA = (trans, UOM) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    {
        key: 'planEntity',
        header: trans('planExportColumn.planType'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumn.departureTs'),
    },
    {
        key: 'arrivalTs',
        header: trans('planExportColumn.arrivalTs'),
    },
    {
        key: 'pallets',
        header: trans('planExportColumn.pallets'),
    },
    {
        key: 'weight',
        header: `${trans('planExportColumn.weight')} (${UOM?.weight})`,
    },
    {
        key: 'noOfPickupStops',
        header: trans('planExportColumn.noOfPickupStops'),
    },
    {
        key: 'noOfDropoffStops',
        header: trans('planExportColumn.noOfDropoffStops'),
    },
    {
        key: 'loadLevelType',
        header: trans('planExportColumn.loadType'),
    },
    {
        key: 'class',
        header: trans('planExportColumn.class'),
    },
    {
        key: 'loadMode',
        header: trans('planExportColumn.loadMode'),
    },
    {
        key: 'loadServiceLevel',
        header: trans('planExportColumn.serviceLevel'),
    },
    {
        key: 'tempControl',
        header: trans('planExportColumn.tempControl'),
    },
    {
        key: 'hazmat',
        header: trans('planExportColumn.hazmat'),
    },
    {
        key: 'equipmentCode',
        header: trans('planExportColumn.equipmentConfigId'),
    },
    {
        key: 'equipmentTrailerTypeDescReq',
        header: trans('planExportColumn.equipmentType'),
    },
    {
        key: 'planStatusLabel',
        header: trans('planExportColumn.planStatusLabel'),
    },
];
const processingColumnsToExportCA = (trans) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumn.departureTs'),
    },
    {
        key: 'arrivalTs',
        header: trans('planExportColumn.arrivalTs'),
    },
    {
        key: 'carrierId',
        header: trans('planExportColumn.carrierId'),
    },
    {
        key: 'carrierName',
        header: trans('planExportColumn.carrierName'),
    },
    {
        key: 'noOfPickupStops',
        header: trans('planExportColumn.noOfPickupStops'),
    },
    {
        key: 'noOfDropoffStops',
        header: trans('planExportColumn.noOfDropoffStops'),
    },
    {
        key: 'loadLevelType',
        header: trans('planExportColumn.loadType'),
    },
    {
        key: 'loadServiceType',
        header: trans('planExportColumn.serviceType'),
    },
    {
        key: 'tempControl',
        header: trans('planExportColumn.tempControl'),
    },
    {
        key: 'hazmat',
        header: trans('planExportColumn.hazmat'),
    },
    {
        key: 'carrierMustRespondByTsForExport',
        header: trans('planExportColumn.timeLeft'),
    },
    {
        key: 'carrierLeft',
        header: trans('planExportColumn.carriersLeft'),
    },
    {
        key: 'planStatusLabel',
        header: trans('planExportColumn.planStatusLabel'),
    },
];
const readyToStartColumnsToExportCA = (trans) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumn.departureTs'),
    },
    {
        key: 'arrivalTs',
        header: trans('planExportColumn.arrivalTs'),
    },
    {
        key: 'carrierId',
        header: trans('planExportColumn.carrierId'),
    },
    {
        key: 'carrierName',
        header: trans('planExportColumn.carrierName'),
    },
    {
        key: 'loadLevelType',
        header: trans('planExportColumn.loadType'),
    },
    {
        key: 'planStatusLabel',
        header: trans('planExportColumn.planStatusLabel'),
    },
];
const InTransitColumnsToExportCA = (trans) => [
    {
        key: 'planId',
        header: trans('planExportColumn.planId'),
    },
    {
        key: 'originId',
        header: trans('planExportColumn.originId'),
    },
    {
        key: 'originType',
        header: trans('planExportColumn.originType'),
    },
    {
        key: 'originName',
        header: trans('planExportColumn.originName'),
    },
    {
        key: 'originCity',
        header: trans('planExportColumn.originCity'),
    },
    {
        key: 'originProvince',
        header: trans('planExportColumn.originProvince'),
    },
    {
        key: 'destinationId',
        header: trans('planExportColumn.destinationId'),
    },
    {
        key: 'destinationType',
        header: trans('planExportColumn.destinationType'),
    },
    {
        key: 'destinationName',
        header: trans('planExportColumn.destinationName'),
    },
    {
        key: 'destinationCity',
        header: trans('planExportColumn.destinationCity'),
    },
    {
        key: 'destinationProvince',
        header: trans('planExportColumn.destinationProvince'),
    },
    {
        key: 'departureTs',
        header: trans('planExportColumn.departureTs'),
    },
    {
        key: 'actDeparture',
        header: trans('planExportColumn.actDeparture'),
    },
    {
        key: 'arrivalTs',
        header: trans('planExportColumn.arrivalTs'),
    },
    {
        key: 'carrierId',
        header: trans('planExportColumn.carrierId'),
    },
    {
        key: 'carrierName',
        header: trans('planExportColumn.carrierName'),
    },
    {
        key: 'loadLevelType',
        header: trans('planExportColumn.loadType'),
    },
    {
        key: 'enrouteMilestone',
        header: trans('planExportColumn.enrouteMilestone'),
    },
    {
        key: 'nextStopId',
        header: trans('planExportColumn.nextStopLocationId'),
    },
    {
        key: 'nextStopName',
        header: trans('planExportColumn.nextStopLocationName'),
    },
    {
        key: 'nextStopETA',
        header: trans('planExportColumn.nextStopETA'),
    },
    {
        key: 'noOfStopsLeft',
        header: trans('planExportColumn.noOfStopsLeft'),
    },
    {
        key: 'planStatusLabel',
        header: trans('planExportColumn.planStatusLabel'),
    },
];
export const getColumnsToExport = (market, index, trans, UOM, featureFlag) => {
    switch (market) {
        case MarketCodeEnum.CANADA.name:
            switch (index) {
                case PhaseTypesEnum.PLANNING.index:
                    return planningColumnsToExportCA(trans, UOM);
                case PhaseTypesEnum.PROCESSING.index:
                    return processingColumnsToExportCA(trans);
                case PhaseTypesEnum.READY_TO_START.index:
                    return readyToStartColumnsToExportCA(trans);
                case PhaseTypesEnum.IN_TRANSIT.index:
                    return InTransitColumnsToExportCA(trans);
                default:
                    return [];
            }
        case MarketCodeEnum.US.name:
        case MarketCodeEnum.USTRX.name:
            switch (index) {
                case PhaseTypesEnum.PLANNING.index: {
                    const columns = planningColumnsToExportUS(trans, UOM, featureFlag);
                    if (!featureFlag?.showPrimaryDestinationCol) {
                        columns.splice(15, 5);
                    }
                    return columns;
                }
                case PhaseTypesEnum.PROCESSING.index: {
                    const columns = processingColumnsToExportUS(trans, UOM, featureFlag);
                    if (!featureFlag?.showPrimaryDestinationCol) {
                        columns.splice(19, 5);
                    }
                    return columns;
                }
                case PhaseTypesEnum.READY_TO_START.index: {
                    const columns = readyToStartColumnsToExportUS(trans, UOM, featureFlag);
                    if (!featureFlag?.showPrimaryDestinationCol) {
                        columns.splice(14, 5);
                    }
                    return columns;
                }
                case PhaseTypesEnum.IN_TRANSIT.index: {
                    const columns = inTransitColumnsToExportUS(trans, UOM, featureFlag);
                    if (!featureFlag?.showPrimaryDestinationCol) {
                        columns.splice(14, 5);
                    }
                    return columns;
                }
                case PhaseTypesEnum.DELIVERED.index: {
                    const columns = deliveredColumnsToExportUS(trans, UOM, featureFlag);
                    if (!featureFlag?.showPrimaryDestinationCol) {
                        columns.splice(14, 5);
                    }
                    return columns;
                }
                default:
                    return [];
            }
        default:
            return [];
    }
};
export const initialWarnings = {
    driver: '',
    equipment: '',
    trailer: '',
};
export const getDateTypes = (dateTypes) =>
    dateTypes.map((dateType) => ({
        id: dateType.id,
        value: dateType.value,
    }));

// const getListFromMultiTextInput = (value) => (value
//   ? value.split('\t').join(' ').split(' ').join(',')
//     .split(',')
//   : []);

const SerachRequestToFilterKeyMapping = {
    origins: {
        locationType: 'originType',
        city: 'originCity',
        province: 'originProvince',
        postalCode: 'originPostalCode',
        countryCode: 'originCountry',
        locationId: 'originLocId',
    },
    destinations: {
        locationType: 'destinationType',
        city: 'destinationCity',
        province: 'destinationProvince',
        postalCode: 'destinationPostalCode',
        countryCode: 'destinationCountry',
        locationId: 'destinationLocId',
    },
    planDetails: {
        owner: 'loadOwner',
        priority: 'priority',
        temparatureControl: 'temperatureControl',
        isHazmat: 'hazmat',
        equipmentId: 'equipmentId',
        ibob: 'ibob',
        programType: 'program',
        channelType: 'channel',
    },
    transitDetails: {
        protectionLevel: 'temperatureControl',
        serviceClass: 'serviceClass',
        mode: 'mode',
        serviceLevel: 'serviceLevel',
        serviceType: 'serviceType',
    },
    queryDates: {
        type: 'dateType',
        endTs: 'tillDate',
        startTs: 'fromDate',
    },
    equipment: {
        equipmentCodes: 'equipmentConfigurationId',
    },
    externalIdentifier: {
        deliveryOrderIds: 'toId',
    },
    plans: {
        planIds: 'loadId',
    },
    carrier: 'scacCode',
};
export const fromReqPayloadKeyToSearchFilter = (formValue, val) => {
    // If any filter chip related to queryDate is removed, delete all data related to filter query
    if (val.source === 'queryDates') {
        return {
            ...formValue,
            dateType: '',
            tillDate: '',
            fromDate: '',
            date: '',
        };
    }
    if (val?.source === 'selectedStatus')
        return {
            ...formValue,
            status: [],
        };
    const key = val.key
        ? SerachRequestToFilterKeyMapping[val.source][val.key]
        : SerachRequestToFilterKeyMapping[val.source];
    if (Array.isArray(formValue[key])) {
        return {
            ...formValue,
            [key]: [],
        };
    }
    return {
        ...formValue,
        [key]: '',
    };
};
export const getTransformedPlansList = (
    tabIndex,
    planList,
    staticData,
    config,
    currentMarket,
    featureFlags,
    pageLoadSettings,
    trans,
) => {
    const configData = {
        market: currentMarket,
        staticData,
        featureFlags,
        config,
        trans,
    };
    switch (tabIndex) {
        case PhaseTypesEnum.PLANNING.index:
            if (pageLoadSettings?.showCLColumns) {
                return planList
                    .map((plan) => transformPlanPreviewData(plan, trans, configData))
                    .filter((plan) => {
                        if (plan.planType === 'LOAD') {
                            // TODO: change this filter to have a direct match
                            // these enums should be accessed from the commons.
                            return (
                                plan?.planWorkflowPhase?.name === LoadUiPhaseEnum.UNPLANNED.name &&
                                plan?.planWorkflowStatusObj?.name === LoadUIStatusEnum.UNPLANNED.name
                            );
                        }
                        return plan?.planWorkflowPhase.name === TripUiWorkloadPhaseEnum.PLANNING.name;
                    });
            }
            if (pageLoadSettings?.showCAColumns) {
                return planList.map((plan) => transformPlanPreviewData(plan, trans, configData));
                // .filter(
                //   (plan) => plan?.planStatus?.name === LoadUIStatusEnum.PENDING_APPROVAL_LOAD.name,
                // );
            }

            break;
        case PhaseTypesEnum.PROCESSING.index:
            if (pageLoadSettings?.showCLColumns) {
                return planList
                    .map((plan) => transformPlanPreviewData(plan, trans, configData))
                    .filter(
                        (plan) =>
                            plan?.planType === 'TRIP' &&
                            plan?.planWorkflowPhase?.name === TripUiWorkloadPhaseEnum.PROCESSING.name,
                    );
            }
            if (pageLoadSettings?.showCAColumns) {
                return planList.map((plan) => transformPlanPreviewData(plan, trans, configData));
                // .filter(
                //   (plan) => plan?.planStatus?.name === LoadUIStatusEnum.TENDER_IN_PROGRESS.name
                //   || plan?.planStatus?.name === LoadUIStatusEnum.TENDERS_EXHAUSTED.name
                //   || plan?.planStatus?.name === LoadUIStatusEnum.TENDER_CANCELLED.name
                //   || plan?.planWorkflowPhase?.name === TripUiWorkloadPhaseEnum.PROCESSING.name,
                // );
            }

            break;
        case PhaseTypesEnum.DISPATCH_PENDING.index:
            if (pageLoadSettings?.showCLColumns) {
                return planList
                    .map((plan) => transformPlanPreviewData(plan, trans, configData))
                    .filter(
                        (plan) =>
                            plan?.planType === 'TRIP' &&
                            plan?.planWorkflowPhase?.name === TripUiWorkloadPhaseEnum.DISPATCH.name,
                    );
            }
            if (pageLoadSettings?.showCAColumns) {
                return planList.map((plan) => transformPlanPreviewData(plan, trans, configData));
                // .filter(
                //   (plan) => plan?.planStatus?.name === LoadUIStatusEnum.PICKUP_DELAYED.name
                //   || plan?.planStatus?.name === LoadUIStatusEnum.AWAITING_PICKUP.name,
                // );
            }

            break;
        case PhaseTypesEnum.IN_TRANSIT.index:
            if (pageLoadSettings?.showCLColumns) {
                return planList
                    .map((plan) => transformPlanPreviewData(plan, trans, configData))
                    .filter(
                        (plan) =>
                            plan?.planType === 'TRIP' &&
                            plan?.planWorkflowPhase?.name === TripUiWorkloadPhaseEnum.IN_TRANSIT.name,
                    );
            }
            if (pageLoadSettings?.showCAColumns) {
                return planList.map((plan) => transformPlanPreviewData(plan, trans, configData));
                // .filter(
                //   (plan) => plan?.planStatus?.name === LoadUIStatusEnum.IN_TRANSIT_EARLY.name
                //     || plan?.planStatus?.name === LoadUIStatusEnum.IN_TRANSIT_ON_TIME.name
                //     || plan?.planStatus?.name === LoadUIStatusEnum.IN_TRANSIT_LATE.name,
                // );
            }

            break;
        default:
            return [];
    }
};
export const getFilteredRows = (sSearch, enhanceRowList, planSearchHeaders) => {
    let rows = [];
    if (sSearch && enhanceRowList.length) {
        rows = onTableSearch(enhanceRowList, sSearch, planSearchHeaders);
    } else {
        rows = enhanceRowList;
    }
    return rows;
};
export const getPaginatedRows = (filteredRows, pNo, config) => {
    const rows = filteredRows;
    const numOfRows = config?.rowsPerPage;
    if (rows.length > numOfRows) {
        return rows.slice((pNo - 1) * numOfRows, (pNo - 1) * numOfRows + numOfRows);
    }
    return rows;
};
export const getFilteredColumnHeaders = (tabIndex, planTableHeadCells, isAssignTrip, featureFlag = {}) => {
    const excludedProcessingColumns = [...excludedColumnsForProcessing];
    const excludedDispatchTransitColumns = [];
    const { showModeColumnInTripSummary } = featureFlag;
    if (!showModeColumnInTripSummary) {
        excludedProcessingColumns.push('mode');
        excludedDispatchTransitColumns.push('mode');
    }
    if (tabIndex === PhaseTypesEnum.PLANNING.index && !isAssignTrip) {
        return planTableHeadCells.filter((header) => !excludedColumnsForPlanning.includes(header?.id));
    }
    if (tabIndex === PhaseTypesEnum.PLANNING.index && isAssignTrip) {
        return planTableHeadCells
            .filter((header) => !excludeColumnsForTrip.includes(header?.id))
            .map((header) => {
                if (header?.id === 'planId')
                    return {
                        ...header,
                        label: 'tripColumns.tripId',
                    };
                if (header?.id === 'planStatus')
                    return {
                        ...header,
                        label: 'tripColumns.tripStatus',
                    };
                return header;
            });
    }
    if (tabIndex === PhaseTypesEnum.PROCESSING.index) {
        return planTableHeadCells.filter((header) => !excludedProcessingColumns.includes(header?.id));
    }
    return planTableHeadCells.filter((header) => !excludedDispatchTransitColumns.includes(header?.id));
};
export const getFilteredColumnHeadersCA = (tabIndex) => {
    if (tabIndex === PhaseTypesEnum.PLANNING.index) {
        return planTableHeadCellsCA.filter((header) => !excludedColumnsForPlanningCA.includes(header?.id));
    }
    if (tabIndex === PhaseTypesEnum.PROCESSING.index) {
        return planTableHeadCellsCA.filter((header) => !excludedColumnsForProcessingCA.includes(header?.id));
    }
    if (tabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) {
        return planTableHeadCellsCA.filter((header) => !excludedColumnsForReadyToStartCA.includes(header?.id));
    }
    if (tabIndex === PhaseTypesEnum.IN_TRANSIT.index) {
        return planTableHeadCellsCA.filter((header) => !excludedColumnsForInTransit.includes(header?.id));
    }
    return planTableHeadCellsCA;
};
export const displayAssignToTripButton = (checkedRows, transformedPlansList, FeatureFlags) => {
    if (checkedRows?.length === 2 && FeatureFlags?.showAssignTripForDoubleTrailer) {
        const selectedLoadInfo = transformedPlansList?.filter((plan) => checkedRows.includes(plan?.planId));
        if (selectedLoadInfo?.[0]?.loadType !== selectedLoadInfo?.[1]?.loadType) return false;
        if (FeatureFlags?.hideAssignToTripForSTRLoad) {
            const loadInfoWtihSTR = selectedLoadInfo?.filter((plan) => plan?.loadType?.includes(loadTypeSTR));
            return !(loadInfoWtihSTR?.length > 0);
        }
        return true;
    }

    if (checkedRows?.length !== 1) {
        return false;
    }
    if (FeatureFlags?.hideAssignToTripForSTRLoad) {
        const selectedLoadInfo = transformedPlansList.filter((plan) => checkedRows.includes(plan?.planId))[0];
        return selectedLoadInfo?.loadType !== loadTypeSTR;
    }
    return true;
};
const getOriginInfo = (origins) => {
    const locationType = [...new Set(origins.map((obj) => obj.locationType))];
    const city = [...new Set(origins.map((obj) => obj.city))];
    const province = [...new Set(origins.map((obj) => obj.province))];
    const postalCode = [...new Set(origins.map((obj) => obj.postalCode))];
    const country = [...new Set(origins.map((obj) => obj.country))];
    const locationId = [...new Set(origins.map((obj) => obj.locationId))];
    const origin = {};
    if (locationType.length > 0) {
        origin.locationType = [...locationType];
    }
    if (city.length > 0) {
        origin.city = [...city];
    }
    if (province.length > 0) {
        origin.province = [...province];
    }
    if (postalCode.length > 0) {
        origin.postalCode = [...postalCode];
    }
    if (country.length > 0) {
        origin.country = [...country];
    }
    if (locationId.length > 0) {
        origin.locationId = [...locationId];
    }
    return origin;
};
const getDestinationInfo = (destinations) => {
    const locationType = [...new Set(destinations.map((obj) => obj.locationType))];
    const city = [...new Set(destinations.map((obj) => obj.city))];
    const province = [...new Set(destinations.map((obj) => obj.province))];
    const postalCode = [...new Set(destinations.map((obj) => obj.postalCode))];
    const country = [...new Set(destinations.map((obj) => obj.country))];
    const locationId = [...new Set(destinations.map((obj) => obj.locationId))];
    const destination = {};
    if (locationType.length > 0) {
        destination.locationType = [...locationType];
    }
    if (city.length > 0) {
        destination.city = [...city];
    }
    if (province.length > 0) {
        destination.province = [...province];
    }
    if (postalCode.length > 0) {
        destination.postalCode = [...postalCode];
    }
    if (country.length > 0) {
        destination.country = [...country];
    }
    if (locationId.length > 0) {
        destination.locationId = [...locationId];
    }
    return destination;
};
export const searchFilterReqPayloadToChips = (data) => {
    const chips = [];
    if (data.payload) {
        const {
            origins,
            destinations,
            loadQueryInfo,
            serviceDetails,
            queryDates,
            planDetails,
            transitDetails,
            equipment,
            carrier,
            planIds,
            externalIdentifier,
            selectedStatus,
        } = data.payload;
        const origin = getOriginInfo(origins);
        const destination = getDestinationInfo(destinations);
        const object = {
            origins: origin,
            destinations: destination,
            loadQueryInfo,
            serviceDetails,
            queryDates,
            planDetails,
            transitDetails,
            equipment,
            carrier,
            plans: {
                planIds,
            },
            externalIdentifier,
            selectedStatus,
        };
        Object.keys(object).forEach((property) => {
            if (object[property]) {
                if (
                    Array.isArray(object[property]) &&
                    object[property].length > 0 &&
                    typeof object[property][0] === 'string'
                ) {
                    const obj = {
                        source: property,
                        value: object[property]?.toString(),
                    };
                    if (obj.value.length > 15) {
                        obj.display = `${obj.value.substring(0, 12)}...`;
                    } else {
                        obj.display = obj.value;
                    }
                    chips.push(obj);
                } else {
                    Object.keys(object[property]).forEach((key) => {
                        const val = object[property][key];
                        const obj = {
                            source: property,
                            key,
                        };
                        if (val || typeof val === 'boolean') {
                            if (Array.isArray(val) && val.length > 0) {
                                obj.value = val.toString();
                            } else if (key === 'endTs' || key === 'startTs') {
                                obj.value = val ? format(new Date(val), INPUT_DATE_FORMAT) : '';
                            } else {
                                obj.value = val;
                            }
                            if (obj.value.length > 15) {
                                obj.display = `${obj.value.substring(0, 12)}...`;
                            } else {
                                obj.display = obj.value;
                            }
                            chips.push(obj);
                        }
                    });
                }
            }
        });
    }
    return chips;
};
export const getBulkUploadConfig = (env, market, lang, featureFlags, bulkSemiColonDeliColumnCount) => {
    const fileName = `stride_plan_template_${lang}_${market}`;
    let bulkUploadConfig;
    if (market === 'cl' || camMarkets.includes(market)) {
        // temporary changes to test GSCOPE delimiter issue fix
        bulkUploadConfig = {
            sampleDownload: {
                fileName,
                fileType: 'zip',
            },
            serviceAction: `${env}.planquery${lang}${market}`,
            serviceType: 'stride',
            acceptFileTypes: '.csv',
            hasEditPermission: true,
            showTIDcolumn: true,
            processor: (arr) =>
                featureFlags?.bulkProcessorWithStopsDates
                    ? bulkUploadProcessorCAM(lang, arr)
                    : bulkUploadProcessor(lang, arr),
            delimiterConfig: {
                fileDelimiter: ';',
                dataDelimiter: '.',
                columnCount: bulkSemiColonDeliColumnCount,
            },
        };
    } else if (market === MarketCodeEnum.US.code) {
        bulkUploadConfig = {
            sampleDownload: {
                fileName: `stride_tenderBulkUpload_template_${lang}_${market.toUpperCase()}`,
                fileType: 'xlsx',
            },
            serviceAction: `manualTenderBulkUpload_${lang}_${market.toUpperCase()}_${env}`,
            serviceType: 'stride',
            moduleLanguage: ['en'],
            acceptFileTypes: '.xlsx',
            useWasmProcessor: true,
            hasEditPermission: true,
        };
    } else {
        bulkUploadConfig = {
            sampleDownload: {
                fileName,
                fileType: 'zip',
            },
            serviceAction: `${env}.planquery${lang}${market}`,
            serviceType: 'stride',
            acceptFileTypes: '.csv',
            hasEditPermission: true,
            showTIDcolumn: true,
            processor: (arr) => bulkUploadProcessor(lang, arr),
        };
    }
    return bulkUploadConfig;
};
export const getSelectedTripInfo = (selTripId, tripList) =>
    tripList.filter((plan) => selTripId.includes(plan?.planId))[0];
export const getEquipmentAndTransitDetailsOfTrip = (tripID, tripDetails) => {
    const tripDetail = tripDetails?.find((trip) => {
        const formattedTripID = trip?.planResponse?.identifiers?.planId?.toString().trim();
        return formattedTripID === tripID.toString();
    });
    if (tripDetail?.planResponse?.plans && tripDetail?.planResponse?.plans?.length) {
        const parentPlan = tripDetail.planResponse.plans[0];
        return {
            transitDetail: {
                mode: parentPlan?.transitDetail?.mode,
                serviceLevel: parentPlan?.transitDetail?.serviceLevel,
                protectionLevel: parentPlan?.transitDetail?.protectionLevel,
            },
            equipment: {
                equipmentCode: parentPlan?.equipment?.equipmentCode,
                length: parentPlan?.equipment?.length,
            },
        };
    }
    return null;
};

export const isAllLoadsHaveChargeLocation = (plans) =>
    plans?.every((plan) => !isNullOrUndefined(plan?.chargeLocationId));

export const getTripsWithChargeLocValidation = (tripsAll, selectedTrips) =>
    tripsAll
        ?.filter((plan) => selectedTrips?.includes(plan?.planId))
        .map((trip) => ({
            planId: trip?.planId,
            loadsWithoutChargeLoc: trip?.plans
                ?.filter((plan) => isNullOrUndefined(plan?.chargeLocationId))
                .map((plan) => plan?.planId),
            allLoadsHaveChargeLocAdded: isAllLoadsHaveChargeLocation(trip?.plans),
        }));

export const getFormattedChargeLocError = (selectedTrip) => {
    const { trans } = TripSharedService;
    return {
        errMessage: `${trans('msg.chargeLocMissingError')} - ${selectedTrip?.loadsWithoutChargeLoc?.join(', ')}`,
        planId: selectedTrip?.planId,
    };
};

const getFormattedFormDataPayload = (tripAndLoadInfo, configData, connectionLoadInfo) => {
    const { tripData, sLoadInfo } = tripAndLoadInfo;
    const { cmsConfig, currentMarket, featureFlags } = configData;
    const { formData, TransitAndEquipmentDetail } = connectionLoadInfo;
    const marketSettings = getMarketSettings(currentMarket);
    return {
        planCategory: formData?.connectLoad,
        locations: {
            origin: {
                locationId: tripData?.destinationId,
                locationType: tripData?.destinationType,
                countryCode: tripData?.destinationCode?.toUpperCase(),
                ...(marketSettings.connectEmptyTrailerLocation && {
                    locationName: tripData?.destinationName,
                }),
                ...(featureFlags?.includeTimeZoneIdInConnectingLoads && {
                    olsenTimezoneId: tripData?.destinationOlsenTimezoneId,
                }),
            },
            destination: {
                locationId: sLoadInfo?.originId,
                locationType: sLoadInfo?.originType,
                countryCode: sLoadInfo?.originCode?.toUpperCase(),
                ...(marketSettings.connectEmptyTrailerLocation && {
                    locationName: sLoadInfo?.originName,
                }),
                ...(featureFlags?.includeTimeZoneIdInConnectingLoads && {
                    olsenTimezoneId: tripData?.originOlsenTimezoneId,
                }),
            },
            ...getChargeLocationOfLoad(sLoadInfo, featureFlags),
        },
        ...(featureFlags?.includeTransitEquipmentInLoad &&
            formData?.connectLoad === connectLoads[1].id && {
                ...TransitAndEquipmentDetail,
            }),
        planAggregates: {
            totalDistance: {
                unitOfMeasure: cmsConfig?.UOM?.distance,
                measurementValue: formData?.distance ? parseInt(formData.distance, 10) : 0,
            },
            totalDuration: {
                unitOfMeasure: cmsConfig?.UOM?.duration,
                measurementValue: formData?.transitTime ? getMinutesFromHhmm(formData?.transitTime) : 0,
            },
        },
    };
};

const getFormattedAssignLoadId = (loadInfo) => ({
    identifiers: {
        planId: loadInfo?.planId,
    },
});

export const formatAssignTripReq = (tripAndLoadInfo, configData, connectionLoadInfo, isDoubleAssign = false) => {
    const { sLoadInfo, selectedTripId } = tripAndLoadInfo;
    const { formData } = connectionLoadInfo;

    if (isDoubleAssign) {
        const arrayLoadInfo = sLoadInfo?.filteredPlans;
        const formattedConnectingLoads = formData
            ? arrayLoadInfo?.map((loadInfo) => {
                  const separatedTripAndLoadInfo = {
                      ...tripAndLoadInfo,
                      sLoadInfo: loadInfo,
                  };
                  return getFormattedFormDataPayload(separatedTripAndLoadInfo, configData, connectionLoadInfo);
              })
            : [];
        const formattedLoadIdentifiers = arrayLoadInfo?.map((loadInfo) => getFormattedAssignLoadId(loadInfo));
        const isConnectLoadBOB = formData?.connectLoad === connectLoads[0].id;
        if (isConnectLoadBOB && Array.isArray(formattedConnectingLoads)) {
            formattedConnectingLoads.splice(1, 1);
        }
        return {
            payload: [
                {
                    identifiers: {
                        planId: selectedTripId,
                    },
                    plans: [...formattedConnectingLoads, ...formattedLoadIdentifiers],
                },
            ],
        };
    }
    return {
        payload: [
            {
                identifiers: {
                    planId: selectedTripId,
                },
                plans: formData
                    ? [
                          getFormattedFormDataPayload(tripAndLoadInfo, configData, connectionLoadInfo),
                          getFormattedAssignLoadId(sLoadInfo),
                      ]
                    : [getFormattedAssignLoadId(sLoadInfo)],
            },
        ],
    };
};

export const getReqPayloadCarrierTariff = (plan) => ({
    tariff_list_req: {
        origin: {
            location_id: plan?.originId,
            location_type_code: plan?.originType,
        },
        destination: {
            location_id: plan?.destinationId,
            location_type_code: plan?.destinationType,
        },
        mode: plan?.loadMode,
        protection_level: plan?.protectionLevel,
        service_level: plan?.loadServiceLevel,
        equipment_type_code: plan?.equipmentTrailerTypeReq,
    },
    carrier_list_req: {
        query: '{ carrier_by_mdm_carrier_id(tenant_id:"CA_CA",status_code:"A"){}}',
    },
});
export const formatResponseForTableData = (planResponseList, pageBehaviour, featureFlags) => {
    if (Array.isArray(planResponseList?.payload)) {
        const { planList, carrierList, dispatchList } = planResponseList?.payload?.reduce(
            (groupedData, data) => {
                if (data.planResponse) groupedData.planList.push(data.planResponse);
                if (data.cstResponse) {
                    groupedData.carrierList.push({
                        ...data.cstResponse,
                        planStatus: data?.planResponse?.planStatus,
                    });
                }
                if (data.dispatchResponse) {
                    groupedData.dispatchList.push({
                        ...data.dispatchResponse,
                        planStatus: data?.planResponse?.planStatus,
                    });
                }
                return groupedData;
            },
            {
                planList: [],
                carrierList: [],
                dispatchList: [],
            },
        );
        let tData = [];
        const optionFlags = {
            showCreateTripForDoubleTrailer: featureFlags?.showCreateTripForDoubleTrailer,
            enableBillOfLading: featureFlags?.enableBillOfLading,
        };
        if (pageBehaviour.showCLColumns) {
            tData = transformPreviewResponseToUIModel(planList, carrierList, dispatchList, [], optionFlags);
        } else if (pageBehaviour.showCAColumns) {
            tData = transformCAPreviewResponseToUIModel(planList, carrierList, dispatchList);
        }
        return tData;
    }
};
export const getAppliedFiltersCount = (formValue) => {
    let appliedFilters = 0;
    Object.entries(formValue).forEach(([key, value]) => {
        if (key !== 'dateType') {
            if (Array.isArray(value)) {
                if (value.length) {
                    appliedFilters += 1;
                }
            } else if (value) {
                appliedFilters += 1;
            }
        }
    });
    return appliedFilters;
};
export const showOriginSection = (allowedFilters) => {
    if (
        allowedFilters &&
        (allowedFilters.includes(FILTER_TYPES.ORIGIN_LOCATION_ID) ||
            allowedFilters.includes(FILTER_TYPES.ORIGIN_LOCATION_TYPE) ||
            allowedFilters.includes(FILTER_TYPES.ORIGIN_TYPE) ||
            allowedFilters.includes(FILTER_TYPES.ORIGIN_CITY) ||
            allowedFilters.includes(FILTER_TYPES.ORIGIN_PROVINCE) ||
            allowedFilters.includes(FILTER_TYPES.ORIGIN_POSTAL_CODE) ||
            allowedFilters.includes(FILTER_TYPES.ORIGIN_COUNTRY))
    ) {
        return true;
    }
    return false;
};
export const showDestinationSection = (allowedFilters) => {
    if (
        allowedFilters &&
        (allowedFilters.includes(FILTER_TYPES.DESTINATION_LOCATION_ID) ||
            allowedFilters.includes(FILTER_TYPES.DESTINATION_LOCATION_TYPE) ||
            allowedFilters.includes(FILTER_TYPES.DESTINATION_TYPE) ||
            allowedFilters.includes(FILTER_TYPES.DESTINATION_CITY) ||
            allowedFilters.includes(FILTER_TYPES.DESTINATION_PROVINCE) ||
            allowedFilters.includes(FILTER_TYPES.DESTINATION_POSTAL_CODE) ||
            allowedFilters.includes(FILTER_TYPES.DESTINATION_COUNTRY))
    ) {
        return true;
    }
    return false;
};
export const showLoadSection = (allowedFilters) => {
    if (
        allowedFilters &&
        (allowedFilters.includes(FILTER_TYPES.LOAD_OWNER) ||
            allowedFilters.includes(FILTER_TYPES.PRIORITY) ||
            allowedFilters.includes(FILTER_TYPES.TEMPERATURE_CONTROL) ||
            allowedFilters.includes(FILTER_TYPES.HAZMAT) ||
            allowedFilters.includes(FILTER_TYPES.EQUIPMENT_CONFIGURATION_ID) ||
            allowedFilters.includes(FILTER_TYPES.Equipment_ID) ||
            allowedFilters.includes(FILTER_TYPES.IBOB) ||
            allowedFilters.includes(FILTER_TYPES.PROGRAM) ||
            allowedFilters.includes(FILTER_TYPES.CHANNEL) ||
            allowedFilters.includes(FILTER_TYPES.LOAD_TYPE) ||
            allowedFilters.includes(FILTER_TYPES.CONTAINER_TRAILER_ID) ||
            allowedFilters.includes(FILTER_TYPES.TRACTOR_TRUCK_ID))
    ) {
        return true;
    }
    return false;
};
export const showServiceSection = (allowedFilters) => {
    if (
        allowedFilters &&
        (allowedFilters.includes(FILTER_TYPES.SERVICE_CLASS) ||
            allowedFilters.includes(FILTER_TYPES.SERVICE_MODE) ||
            allowedFilters.includes(FILTER_TYPES.SERVICE_LEVEL) ||
            allowedFilters.includes(FILTER_TYPES.SERVICE_TYPE))
    ) {
        return true;
    }
    return false;
};
export const showCarrierSection = (allowedFilters) => {
    if (allowedFilters && allowedFilters.includes(FILTER_TYPES.CARRIER_ID)) {
        return true;
    }
    return false;
};
export const showPlanSection = (allowedFilters) => {
    if (
        allowedFilters &&
        (allowedFilters.includes(FILTER_TYPES.PLAN_TYPE) || allowedFilters.includes(FILTER_TYPES.STATUS))
    ) {
        return true;
    }
    return false;
};
export const hasmatTransLabels = (trans) => [trans('label.with'), trans('label.without')];
export const isLocationIdDisabled = (location, formValue) => {
    if (location === LocationODTypes.ORIGIN) {
        return (
            formValue?.originType?.length ||
            formValue?.originCity ||
            formValue?.originProvince ||
            formValue?.originPostalCode ||
            formValue?.originCountry
        );
    }
    return (
        formValue?.destinationType?.length ||
        formValue?.destinationCity ||
        formValue?.destinationProvince ||
        formValue?.destinationPostalCode ||
        formValue?.destinationCountry
    );
};

export const sealAndInvoiceDetailsExistInAllStops = (stops) =>
    !!stops?.every((stop) => !!stop?.sealIdentifiers?.length && !!stop?.invoiceIdentifiers?.length);

export const displayUpdateDestinationButton = (checkedRows, planList) => {
    const selectedTripInfo = planList?.filter((plan) => checkedRows?.includes(plan?.planId))[0];
    const excludedLocationTypes = [INTERMEDIATE_LOCATION_TYPE?.HUB?.code, INTERMEDIATE_LOCATION_TYPE?.DECON?.code];
    const tripHasNoExcludedLocations = selectedTripInfo?.plans?.every(
        (plan) =>
            !excludedLocationTypes?.includes(plan?.destinationType) &&
            !excludedLocationTypes?.includes(plan?.originType),
    );
    return !!(
        selectedTripInfo?.plans?.length <= 2 &&
        selectedTripInfo?.plans?.[0]?.loadType === loadTypeSTR &&
        sealAndInvoiceDetailsExistInAllStops(selectedTripInfo?.plans?.[0]?.stops) &&
        checkedRows?.length === 1 &&
        selectedTripInfo?.planCarrierStatus === CarrierStatusEnum.UNASSIGNED.name &&
        tripHasNoExcludedLocations &&
        (isNullOrUndefined(selectedTripInfo?.carrierId) || isEmpty(selectedTripInfo?.carrierId))
    );
};

export const getSelectedPlanDetails = (planDetails) => ({
    planId: planDetails?.planId,
    originId: planDetails?.originId,
    originType: planDetails?.originType,
    originCode: planDetails?.originCode,
    destinationId: planDetails?.destinationId,
    destinationType: planDetails?.destinationType,
    destinationCode: planDetails?.destinationCode,
});

export const formatUpdateTimeLineData = (planId, response, pIsTripSelected) => {
    const payload = {
        plans: [
            {
                trackingId: Number(planId),
                trackingIdType: pIsTripSelected ? 'TRIP' : 'LOAD',
                transits: [],
            },
        ],
    };
    if (response?.length) {
        payload.plans[0].transits = response.map((e) => {
            const { actual, reasonCodes, stopId, stopSeqNumber, stopType } = e;

            return {
                actual,
                reasonCodes,
                stopId,
                stopSeqNumber,
                stopType,
            };
        });
    }
    return payload;
};

export const formatDoubleTrailerTripReq = (data) => {
    const { equipmentCode, planId, stopSequence } = data;
    const planIds = planId?.[0] === stopSequence?.[0]?.id ? planId : planId?.reverse();
    return {
        payload: {
            equipmentCode,
            planIds,
            mode: TRIP_MODE.DBL,
            activities: stopSequence?.map((sequence, index) => ({
                id: sequence?.planLocationId,
                stopSequenceNumber: index + 1,
                location: {
                    locationId: sequence?.planLocationId,
                    locationType: sequence?.planLocationType,
                    countryCode: sequence?.countryCode,
                    locationName: sequence?.planLocationName,
                },
                stopActivityType: sequence?.stopActivityType,
            })),
        },
    };
};

export const getDoubleTrailerType = (staticData, featureFlags) => {
    const regexMX = DOUBLE_TRAILER_EQUIPMENT_REGEX.REGEX_MX;
    const regexCL = DOUBLE_TRAILER_EQUIPMENT_REGEX.REGEX_CL;

    if (featureFlags?.enableDifferentOriginForDoubleTrailer) {
        return [...staticData?.equipmentConfigurationIds?.filter((equipment) => equipment?.id?.match(regexMX))];
    }
    return [...staticData?.equipmentConfigurationIds?.filter((equipment) => equipment?.id?.match(regexCL))];
};

const sortFilterStopSequence = (loadLocations) => {
    const sortedLocations = loadLocations?.sort((a, b) =>
        a?.planLocationId === b?.planLocationId ? a?.id - b?.id : a?.planLocationId - b?.planLocationId,
    );
    const filteredLocation = sortedLocations?.filter(
        (origin, index) => index === loadLocations?.findIndex((obj) => origin?.planLocationId === obj?.planLocationId),
    );
    return filteredLocation;
};

export const getDoubleTrailerLabels = () => {
    const { trans } = TripSharedService;
    return {
        DC: trans('label.locationType.DC'),
        STORE: trans('label.locationType.STORE'),
        HUB: trans('label.locationType.HUB'),
        DCN: trans('label.locationType.DCN'),
        CN: trans('label.locationType.CN'),
        VNDR: trans('label.locationType.VNDR'),
        VR: trans('label.locationType.VR'),
        CRLOC: trans('label.locationType.CRLOC'),
        UPFAC: trans('label.locationType.UPFAC'),
        BVNDR: trans('label.locationType.BVNDR'),
        PickLoaded: trans('label.doubleTrailer.pickLoaded'),
        DropLoaded: trans('label.doubleTrailer.dropLoaded'),
        createDoubleTrailer: trans('label.createDoubleTrailer'),
        doubleTrailerType: trans('label.doubleTrailerType'),
        stopSequence: trans('label.stopSequence'),
        createButton: trans('button.create'),
        cancelButton: trans('button.cancel'),
    };
};

export const formatDoubleTrailerStopSequence = (filteredPlans) => {
    const pickLoadLocations = [];
    const dropLoadLocations = [];

    if (!Array.isArray(filteredPlans)) return [];
    const labels = getDoubleTrailerLabels();

    filteredPlans.forEach((plan) => {
        const loadInfo = plan?.plans?.[0];
        const stops = loadInfo?.stops?.sort((a, b) => a?.stopSequenceNumber - b?.stopSequenceNumber);
        if (stops) {
            stops.forEach((stop) => {
                const data = {
                    id: plan?.planId,
                    loadId: loadInfo?.planId,
                    loadType: loadInfo?.loadType,
                    planLocationId: stop?.location?.locationId,
                    planLocationType: stop?.location?.locationType,
                    planLocationName: stop?.location?.locationName,
                    countryCode: stop?.location?.countryCode,
                    stopType: stop?.stopType,
                    title: `${labels?.[stop?.location?.locationType]} - ${stop?.location?.locationId}${
                        stop.location?.locationName ? ` - ${stop?.location?.locationName}` : ''
                    }`,
                    type: getStopType(stop?.location?.locationType),
                };
                if (
                    stop?.stopActivityType === StopActivityTypeEnum?.PICK_LOADED?.code ||
                    stop?.stopType === StopTypeEnum?.PICKUP_STOP?.type ||
                    stop?.stopType === StopTypeEnum?.PICKUP_STOP?.code
                ) {
                    pickLoadLocations.push({
                        ...data,
                        stopActivityType: StopActivityTypeEnum?.PICK_LOADED?.code,
                        group: '0',
                    });
                }
                if (
                    stop?.stopActivityType === StopActivityTypeEnum?.DROP_LOADED?.code ||
                    stop?.stopType === StopTypeEnum?.DELIVERY_STOP?.type ||
                    stop?.stopType === StopTypeEnum?.DELIVERY_STOP?.code
                ) {
                    dropLoadLocations.push({
                        ...data,
                        stopActivityType: StopActivityTypeEnum?.DROP_LOADED?.code,
                        group: '1',
                    });
                }
            });
        }
    });

    const uniquePickLocation = sortFilterStopSequence(pickLoadLocations);
    const uniqueDropLocation = sortFilterStopSequence(dropLoadLocations);

    return [...uniquePickLocation, ...uniqueDropLocation];
};

export const displayDoubleTrailerButton = (paginatedData, checkedRows, featureFlags) => {
    if (checkedRows?.length !== 2) return false;

    const selectedRows = paginatedData?.filter((planItem) => checkedRows.includes(planItem?.planId?.toString()));

    if (
        selectedRows[0]?.originId !== selectedRows[1]?.originId &&
        !featureFlags?.enableDifferentOriginForDoubleTrailer
    ) {
        return false;
    }
    if (selectedRows[0]?.loadCount > 1 || selectedRows[1]?.loadCount > 1) {
        return false;
    }
    if (
        selectedRows[0]?.originId === selectedRows[0]?.destinationId ||
        selectedRows[1]?.originId === selectedRows[1]?.destinationId
    ) {
        return false;
    }
    if (selectedRows[0]?.plans[0]?.loadType !== selectedRows[1]?.plans[0]?.loadType) {
        return false;
    }
    if (selectedRows[0]?.carrierId?.length !== 0 || selectedRows[1]?.carrierId?.length !== 0) {
        return false;
    }

    return featureFlags?.showCreateTripForDoubleTrailer;
};
