import React, { memo, useMemo, useState } from 'react';
import {
    ChevronDownIcon,
    TableCell,
    TableRow,
    Checkbox,
    Status,
    ArrowRightIcon,
    Button,
} from '@walmart/living-design-sc-ui';
import clsx from 'clsx';
import { onSelectionChange, calculateTimeDiff, openPageInNewTab } from '@walmart/stride-ui-commons';
import PropTypes, { string, number, bool } from 'prop-types';
import { useHistory } from 'react-router-dom';
import { isAfter, isEqual } from 'date-fns';
import PhaseTypesEnum from '../../utils/enums/PhaseTypesEnum';
import TripSharedService from '../../service/TripSharedService';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const useStyles = makeStyles({
    '@keyframes hidden-cells-entry': {
        '0%': {
            opacity: 0.1,
        },
        '100%': {
            opacity: 1,
        },
    },
    mainRow: {
        '&:hover td': {
            background: '#f1f1f2',
        },
    },
    mainRowExpanded: {
        '& td': {
            borderBottomColor: 'transparent',
        },
    },
    collapsedRows: {
        '& td': {
            borderBottomColor: 'transparent',
            transformOrigin: 'top center',
            animation: '$hidden-cells-entry 0.5s ease-in',
            '&:not(:first-child):not(:last-child)': {
                background: '#f1f1f2',
            },
        },
        '& $stickyColumn': {
            borderRightColor: 'transparent',
            borderLeftColor: 'transparent',
        },
        '& .MuiTableCell-root.MuiTableCell-body': {
            fontWeight: 400,
        },
    },
    collapsedRowFirst: {
        '&$collapsedRows td': {
            '&:nth-child(2)': {
                borderTopLeftRadius: 8,
            },
            '&:nth-last-child(2)': {
                borderTopRightRadius: 8,
            },
        },
    },
    collapsedRowLast: {
        '&$collapsedRows td': {
            '&:nth-child(2)': {
                borderBottomLeftRadius: 8,
            },
            '&:nth-last-child(2)': {
                borderBottomRightRadius: 8,
            },
        },
        '& + $mainRow td': {
            borderTop: '1px solid #e0e0e0',
        },
    },
    stickyColumn: {
        zIndex: 2,
        position: 'sticky',
        backgroundColor: '#fafafa !important',
    },
    stickyColumnCheckbox: {
        left: 0,
        minWidth: 90,
    },
    stickyColumnPlanId: {
        left: 90,
        width: 100,
    },
    stickyColumnPlanType: {
        left: 190,
        width: 100,
    },
    stickyColumnPlanTypeNoCheckbox: {
        left: 100,
        width: 100,
    },
    stickyColumnPlanStatus: {
        right: 0,
    },
    checkBoxCellContainer: {
        display: 'flex',
        justifyContent: 'space-between',
    },
    chevronIconOpen: {
        transition: 'transform 0.5s ease-in',
        transform: 'rotate(180deg)',
    },
    statusTableCell: {
        '& .ld-sc-ui-status.ld-sc-ui-fixed-width': {
            width: 110,
        },
    },
    distanceCellContent: {
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'column',
        '& > span': {
            fontSize: 14,
        },
    },
    timeDelay: {
        color: '#c40e18',
        textTransform: 'lowercase',
        fontSize: '12px !important',
    },
    timeEarly: {
        color: '#226c02',
        textTransform: 'lowercase',
        fontSize: '12px !important',
    },
    planStatus: {
        padding: '4px 8px',
    },
    stickyColumnPlanIdNoCheckBox: {
        left: 0,
        width: 100,
    },
    tableContentWrap: {
        '& td.MuiTableCell-body': {
            whiteSpace: 'nowrap',
            // overflow: 'hidden',
            textOverflow: 'ellipsis',
            fontWeight: 400,
            height: '50px !important',
            padding: '6px 12px',
        },
    },
});
function PlanTableRow({
    pRowData,
    pCheckedRows,
    pSetCheckedRows,
    pTabIndex,
    pIsTripSelected,
    pTripStatus,
    pIsAssignTrip,
    pUserPerm,
    pFeatureFlag,
    mdmLocationTypes,
}) {
    const trans = localizeLang();
    const [sShowCollapsedRows, setsShowCollapsedRows] = useState(false);
    const history = useHistory();
    const classes = useStyles();
    const pageLoadSettings = TripSharedService.getPageLoadSettings();
    const getLoadCountLabel = (rowData) =>
        `${rowData.loadCount} ${rowData.loadCount === 1 ? trans('info.load') : trans('info.loads')}`;
    const canDisableCheckbox = (rowData) =>
        pCheckedRows.length &&
        !pIsAssignTrip &&
        (pIsTripSelected !== rowData.isTrip || pTripStatus?.name !== rowData.planStatus?.name);
    const planIdClickHandler = (isTrip, planId) => {
        let path = '';
        if (isTrip) {
            path = 'tripdetails';
        } else path = 'loaddetails';
        if (pFeatureFlag?.openDetailsPageInNewTab) {
            openPageInNewTab(
                pFeatureFlag.hasPQMigratedToMFE
                    ? `/mfe/stride/planquery/${path}?planId=${planId}`
                    : `/stride/planquery/${path}?planId=${planId}`,
            );
        } else {
            history.push({
                pathname: pFeatureFlag.hasPQMigratedToMFE
                    ? `/mfe/stride/planquery/${path}`
                    : `/stride/planquery/${path}`,
                search: `?planId=${planId}`,
            });
        }
    };
    const renderCommonCells = (_rowData, isInnerRow) => (
        <>
            <TableCell
                type="info"
                className={
                    pUserPerm?.canEditTrip
                        ? clsx(classes.stickyColumn, classes.stickyColumnPlanId)
                        : clsx(classes.stickyColumn, classes.stickyColumnPlanIdNoCheckBox)
                }
            >
                <Button
                    id="lms-table-click"
                    size="small"
                    variant="text-only"
                    onClick={() => planIdClickHandler(_rowData.isTrip, _rowData.planId)}
                >
                    {_rowData.planId}
                </Button>
            </TableCell>
            {!pIsAssignTrip && (
                <TableCell type={isInnerRow ? 'default' : 'info'}>
                    {/* {!isInnerRow ? (
          <div>{_rowData.isTrip ? trans('label.trip') : trans('label.load')}</div>
         ) : ''} */}
                    {!isInnerRow ? <div>{_rowData.planEntity}</div> : ''}
                    {_rowData.isTrip ? (
                        <div>{getLoadCountLabel(_rowData)}</div>
                    ) : (
                        <div>
                            {pFeatureFlag?.displayLoadTypeFromReference
                                ? _rowData.referenceLoadType
                                : _rowData.loadType}
                        </div>
                    )}
                </TableCell>
            )}
            {pFeatureFlag?.showRegionAndMerchandiseDetails && (
                <TableCell type={_rowData.merchandiseType ? 'info' : 'empty'}>
                    <div>{`${_rowData.merchandiseType}`}</div>
                </TableCell>
            )}
            <TableCell type="info">
                {pageLoadSettings?.showLocationName || pFeatureFlag?.showLocationName ? (
                    <div>
                        {_rowData.originId} - {_rowData.originName}
                    </div>
                ) : (
                    <div>{_rowData.originId}</div>
                )}
                <div>{mdmLocationTypes[_rowData.originType]}</div>
                {pFeatureFlag?.showRegionAndMerchandiseDetails && (
                    <div data-testid={`originRegion-${pTabIndex}-${_rowData.planId}`}>{_rowData.originRegion}</div>
                )}
            </TableCell>
            <TableCell>
                <div className={classes.distanceCellContent}>
                    <ArrowRightIcon size="medium" />
                    <span>{_rowData.distance}</span>
                </div>
            </TableCell>
            <TableCell type="info">
                {pageLoadSettings?.showLocationName || pFeatureFlag?.showLocationName ? (
                    <div>
                        {_rowData.destinationId} - {_rowData.destinationName}
                    </div>
                ) : (
                    <div>{_rowData.destinationId}</div>
                )}
                <div>{_rowData.destinationType === 'STORE' ? 'Tienda' : _rowData.destinationType}</div>
                <div>{mdmLocationTypes[_rowData.destinationType]}</div>
                {pFeatureFlag?.showRegionAndMerchandiseDetails && (
                    <div data-testid={`destinationRegion-${pTabIndex}-${_rowData.planId}`}>
                        {_rowData.destinationRegion}
                    </div>
                )}
            </TableCell>
            <TableCell type={_rowData.noOfStops ? 'default' : 'empty'}>{_rowData.noOfStops}</TableCell>
            {(pTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index || pTabIndex === PhaseTypesEnum.IN_TRANSIT.index) && (
                <>
                    <TableCell type={_rowData.laneId ? 'default' : 'empty'}>{_rowData.laneId}</TableCell>
                    <TableCell type="info">
                        <div>{_rowData.rate}</div>
                        <div>{_rowData.rateType}</div>
                    </TableCell>
                </>
            )}
            {pTabIndex !== PhaseTypesEnum.PLANNING.index && (
                <>
                    {pFeatureFlag?.showModeColumnInTripSummary && (
                        <TableCell type={_rowData.transitDetailMode ? 'default' : 'empty'}>
                            {_rowData.transitDetailMode}
                        </TableCell>
                    )}
                    <TableCell type={_rowData.carrierId ? 'default' : 'empty'}>{_rowData.carrierId}</TableCell>
                    <TableCell type={_rowData.carrierStatus ? 'default' : 'empty'}>
                        <Status color={_rowData.carrierStatusColor} size="content-width">
                            {_rowData.carrierStatus}
                        </Status>
                    </TableCell>
                </>
            )}
            <TableCell type={_rowData.equipmentLength ? 'info' : 'empty'}>
                <div>{`${_rowData.equipmentLength} ${_rowData.equipmentLengthUom}`}</div>
                <div>{_rowData.protectionLevel}</div>
            </TableCell>
            {pTabIndex !== PhaseTypesEnum.PLANNING.index && (
                <>
                    <TableCell type={_rowData.equipmentId ? 'info' : 'empty'}>
                        <div>{_rowData.equipmentId}</div>
                        <div>{_rowData.equipmentType}</div>
                    </TableCell>
                    <TableCell type={_rowData.driverId ? 'info' : 'empty'}>
                        <div>{_rowData.driverName}</div>
                        <div>{_rowData.driverId}</div>
                    </TableCell>
                </>
            )}
            <TableCell type={_rowData.cases ? 'default' : 'empty'}>{_rowData.cases}</TableCell>
            <TableCell type={_rowData.pallets ? 'default' : 'empty'}>{_rowData.pallets}</TableCell>
            <TableCell type={_rowData.cube ? 'default' : 'empty'}>{_rowData.cube}</TableCell>
            <TableCell type={_rowData.weight ? 'default' : 'empty'}>{_rowData.weight}</TableCell>
            <TableCell>{_rowData.departureTs}</TableCell>
            <TableCell>{_rowData.arrivalTs}</TableCell>
            <TableCell>{_rowData.createdTs}</TableCell>
        </>
    );
    const renderCommonCellsCA = (_rowData) => (
        <>
            <TableCell
                type="info"
                className={
                    pUserPerm?.canEditTrip
                        ? clsx(classes.stickyColumn, classes.stickyColumnPlanId)
                        : clsx(classes.stickyColumn, classes.stickyColumnPlanIdNoCheckBox)
                }
            >
                <Button
                    id="lms-table-click"
                    size="small"
                    variant="text-only"
                    onClick={() => planIdClickHandler(_rowData.isTrip, _rowData.planId)}
                >
                    {_rowData.planId}
                </Button>
                {/* {_rowData.planId} */}
            </TableCell>
            {pTabIndex === PhaseTypesEnum.PLANNING.index && (
                <TableCell
                    type="default"
                    className={
                        pUserPerm?.canEditTrip
                            ? clsx(classes.stickyColumn, classes.stickyColumnPlanType)
                            : clsx(classes.stickyColumn, classes.stickyColumnPlanTypeNoCheckbox)
                    }
                >
                    {_rowData.planEntity}
                </TableCell>
            )}
            <TableCell type="info">
                <div>{`${_rowData.originId} - ${mdmLocationTypes[_rowData.originType] || ''}`}</div>
                <div>{_rowData.originName}</div>
            </TableCell>
            <TableCell type="info">
                <div>{_rowData.originCity}</div>
                <div>{_rowData.originProvince}</div>
            </TableCell>
            <TableCell type="info">
                <div>{`${_rowData.destinationId}- ${mdmLocationTypes[_rowData.destinationType]}`}</div>
                <div>{_rowData.destinationName}</div>
            </TableCell>
            <TableCell type="info">
                <div>{_rowData.destinationCity}</div>
                <div>{_rowData.destinationProvince}</div>
            </TableCell>
            {pTabIndex !== PhaseTypesEnum.IN_TRANSIT.index && <TableCell>{_rowData.departureTs}</TableCell>}
            {pTabIndex === PhaseTypesEnum.IN_TRANSIT.index && (
                <TableCell>
                    <div>{_rowData.actDeparture}</div>

                    {!isEqual(new Date(_rowData.departureTs), new Date(_rowData.actDeparture)) && (
                        <div
                            className={
                                isAfter(new Date(_rowData.departureTs), new Date(_rowData.actDeparture))
                                    ? classes.timeEarly
                                    : classes.timeDelay
                            }
                        >
                            {calculateTimeDiff(_rowData.departureTs, _rowData.actDeparture)?.time}
                        </div>
                    )}
                </TableCell>
            )}
            <TableCell>
                <div>{_rowData.arrivalTs}</div>
                {!isEqual(new Date(_rowData.arrivalTs), new Date(_rowData.actArrivalTs)) && (
                    <div
                        className={
                            isAfter(new Date(_rowData.arrivalTs), new Date(_rowData.actArrivalTs))
                                ? classes.timeEarly
                                : classes.timeDelay
                        }
                    >
                        {calculateTimeDiff(_rowData.arrivalTs, _rowData.actArrivalTs)?.time}
                    </div>
                )}
            </TableCell>
            {pTabIndex === PhaseTypesEnum.PLANNING.index && (
                <>
                    <TableCell type={_rowData.palletPositions ? 'default' : 'empty'}>
                        {_rowData.palletPositions}
                    </TableCell>
                    <TableCell type={_rowData.weight ? 'default' : 'empty'}>{_rowData.weight}</TableCell>
                </>
            )}
            {pTabIndex !== PhaseTypesEnum.PLANNING.index && (
                <TableCell type={_rowData.carrierId ? 'info' : 'empty'}>
                    <div>{_rowData.carrierName}</div>
                    <div>{_rowData.carrierId}</div>
                </TableCell>
            )}
            {pTabIndex !== PhaseTypesEnum.IN_TRANSIT.index && pTabIndex !== PhaseTypesEnum.DISPATCH_PENDING.index && (
                <>
                    <TableCell type={_rowData.noOfPickupStops ? 'default' : 'empty'}>
                        {_rowData.noOfPickupStops}
                    </TableCell>
                    <TableCell type={_rowData.noOfDropoffStops ? 'default' : 'empty'}>
                        {_rowData.noOfDropoffStops}
                    </TableCell>
                </>
            )}
            <TableCell type={_rowData.loadLevelType ? 'default' : 'empty'}>{_rowData.loadLevelType}</TableCell>
            {pTabIndex === PhaseTypesEnum.PLANNING.index && (
                <>
                    <TableCell type={_rowData.class ? 'default' : 'empty'}>{_rowData.class}</TableCell>
                    <TableCell type={_rowData.loadMode ? 'default' : 'empty'}>{_rowData.loadMode}</TableCell>
                    <TableCell type={_rowData.loadServiceLevel ? 'default' : 'empty'}>
                        {_rowData.loadServiceLevel}
                    </TableCell>
                </>
            )}
            {pTabIndex === PhaseTypesEnum.PROCESSING.index && (
                <TableCell type={_rowData.loadServiceType ? 'default' : 'empty'}>{_rowData.loadServiceType}</TableCell>
            )}
            {pTabIndex !== PhaseTypesEnum.IN_TRANSIT.index && pTabIndex !== PhaseTypesEnum.DISPATCH_PENDING.index && (
                <>
                    <TableCell type={_rowData.tempControl ? 'default' : 'empty'}>{_rowData.tempControl}</TableCell>
                    <TableCell type={_rowData.hazmat ? 'default' : 'empty'}>{_rowData.hazmat}</TableCell>
                </>
            )}
            {pTabIndex !== PhaseTypesEnum.IN_TRANSIT.index && pTabIndex === PhaseTypesEnum.PLANNING.index && (
                <TableCell type={_rowData.equipmentCode ? 'info' : 'empty'}>
                    <div>{_rowData.equipmentCode}</div>
                    <div>{_rowData.equipmentTrailerTypeDescReq}</div>
                </TableCell>
            )}
            {pTabIndex === PhaseTypesEnum.PROCESSING.index && (
                <>
                    <TableCell type={_rowData.remainingTime ? 'default' : 'empty'}>{_rowData.remainingTime}</TableCell>
                    <TableCell type={_rowData.carrierLeft ? 'default' : 'empty'}>{_rowData.carrierLeft}</TableCell>
                </>
            )}

            {pTabIndex === PhaseTypesEnum.IN_TRANSIT.index && (
                <>
                    <TableCell type="info">
                        <div>{_rowData.enrouteMilestone}</div>
                    </TableCell>
                    <TableCell type="info">
                        <div>
                            {_rowData?.nextStop?.location?.locationId}
                            {_rowData?.nextStop?.location?.locationName && (
                                <span>
                                    {' - '}
                                    {_rowData?.nextStop?.location?.locationName}
                                </span>
                            )}
                        </div>
                        {_rowData?.nextStopETA && <div>ETA - {_rowData?.nextStopETA}</div>}
                    </TableCell>
                    <TableCell type="info">
                        <div>{_rowData.noOfStopsLeft}</div>
                    </TableCell>
                </>
            )}
        </>
    );
    const isSelected = useMemo(() => pCheckedRows?.indexOf(pRowData.planId) !== -1, [pCheckedRows, pRowData.planId]);
    const rowKey = `${pTabIndex}-${pRowData.planId}`;
    const renderCells = (rowData) => {
        if (pageLoadSettings?.showCLColumns) {
            return renderCommonCells(rowData);
        }
        if (pageLoadSettings?.showCAColumns) {
            return renderCommonCellsCA(rowData);
        }
    };
    const coherentCheck = (rowData) => {
        if (pageLoadSettings?.checkCoherence) return !rowData.isCoherent;
    };
    return (
        <>
            <TableRow
                className={clsx(
                    classes.mainRow,
                    {
                        [classes.mainRowExpanded]: sShowCollapsedRows,
                    },
                    classes.tableContentWrap,
                )}
                data-testid={`dt-tr-${rowKey}`}
            >
                {pUserPerm?.canEditTrip && (
                    <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnCheckbox)}>
                        {pUserPerm?.canEditTrip ? (
                            <div className={classes.checkBoxCellContainer}>
                                <Checkbox
                                    color="primary"
                                    id={`dt-cb-${rowKey}`}
                                    name={rowKey}
                                    checked={isSelected}
                                    onChange={() => {
                                        pSetCheckedRows(
                                            pIsAssignTrip
                                                ? [pRowData.planId]
                                                : onSelectionChange(pRowData.planId, pCheckedRows),
                                        );
                                    }}
                                    disabled={canDisableCheckbox(pRowData) || coherentCheck(pRowData)}
                                    data-testid={`dt-chkbx-${rowKey}`}
                                />
                                {pRowData.plans.length > 0 && !pIsAssignTrip && (
                                    <ChevronDownIcon
                                        onClick={() =>
                                            setsShowCollapsedRows((_showCollapsedRows) => !_showCollapsedRows)
                                        }
                                        className={clsx({
                                            [classes.chevronIconOpen]: sShowCollapsedRows,
                                        })}
                                        data-testid="expandRowIcon"
                                    />
                                )}
                            </div>
                        ) : null}
                    </TableCell>
                )}
                {renderCells(pRowData)}
                <TableCell
                    className={clsx(classes.stickyColumn, classes.stickyColumnPlanStatus, classes.statusTableCell)}
                    align={pRowData.planStatus ? 'right' : 'center'}
                >
                    {pRowData.planStatus ? (
                        <>
                            <Status color={pRowData.planStatusColor} size="fixed-width">
                                {pRowData.planStatusLabel}
                            </Status>
                            {coherentCheck(pRowData) && (
                                <Status className="mt-1" color="red" size="fixed-width">
                                    {trans('outOfSync-tag')}
                                </Status>
                            )}
                        </>
                    ) : (
                        <span className={classes.planStatus}>{pRowData.planStatusLabel}</span>
                    )}
                </TableCell>
            </TableRow>
            {sShowCollapsedRows && (
                <>
                    {pRowData.plans.map((plan, index) => (
                        <TableRow
                            className={clsx(classes.collapsedRows, {
                                [classes.collapsedRowLast]: index === pRowData.plans.length - 1,
                                [classes.collapsedRowFirst]: index === 0,
                            })}
                            key={plan.planId}
                        >
                            <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnCheckbox)} />
                            {renderCommonCells(plan, true)}
                            <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnPlanStatus)} />
                        </TableRow>
                    ))}
                </>
            )}
        </>
    );
}
PlanTableRow.propTypes = {
    pRowData: PropTypes.object.isRequired,
    pCheckedRows: PropTypes.arrayOf(string).isRequired,
    pSetCheckedRows: PropTypes.func.isRequired,
    pTabIndex: number.isRequired,
    pIsTripSelected: bool.isRequired,
    pTripStatus: string.isRequired,
    pIsAssignTrip: bool.isRequired,
    pUserPerm: PropTypes.oneOfType([PropTypes.object]),
    mdmLocationTypes: PropTypes.oneOfType([PropTypes.object]),
    pFeatureFlag: PropTypes.shape({
        openDetailsPageInNewTab: PropTypes.bool,
        showRegionAndMerchandiseDetails: PropTypes.bool,
        showLocationName: PropTypes.bool,
        displayLoadTypeFromReference: PropTypes.bool,
        showModeColumnInTripSummary: PropTypes.bool,
    }),
};
PlanTableRow.defaultProps = {
    pUserPerm: {},
    mdmLocationTypes: {},
    pFeatureFlag: {},
};
export default memo(PlanTableRow);
