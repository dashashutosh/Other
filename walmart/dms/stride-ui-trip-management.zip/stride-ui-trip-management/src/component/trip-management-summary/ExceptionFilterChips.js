import React, { memo, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { ExceptionChip, MarketCodeEnum } from '@walmart/stride-ui-commons';
import TripSharedService from '../../service/TripSharedService';
import PhaseTypesEnum from '../../utils/enums/PhaseTypesEnum';
import { ExceptionFilters, toteExchangeMustShip } from '../../ConstantsUS';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default;
const useStyles = makeStyles({
    exceptionFilterChipsRoot: {
        display: 'flex',
        flexWrap: 'wrap',
        textAlign: 'left',
        rowGap: 12,
        width: '100%',
    },
    exceptionFilterChips: {
        maxWidth: 450,
        height: '36px',
    },
});

/**
 * @type {React.FC<PropTypes.InferProps<typeof propTypes>>}
 */
const ExceptionFilterChips = (props) => {
    const classes = useStyles();
    const trans = localizeLang();
    const {
        pActiveTab,
        pCurrentMarket,
        pExceptionFilter,
        pOnExceptionFilterChange,
        pGetExceptionCount,
        pEnableMustShip,
    } = props;
    const handleExceptionClick = useCallback(
        (clickedExceptionFilter) => {
            /* if (pExceptionFilters.includes(clickedExceptionFilter)) {
      pOnExceptionFiltersChange(pExceptionFilters.filter(
        (exceptionFilter) => exceptionFilter !== clickedExceptionFilter,
      ));
    } else {
      pOnExceptionFiltersChange([...pExceptionFilters, clickedExceptionFilter]);
    } */

            pOnExceptionFilterChange(pExceptionFilter === clickedExceptionFilter ? null : clickedExceptionFilter);
        },
        [pExceptionFilter, pOnExceptionFilterChange],
    );
    function getExceptionFilterTypes(market) {
        switch (market?.toString().toLowerCase()) {
            case MarketCodeEnum.CANADA.name.toLowerCase(): {
                const { payload } = TripSharedService.getTripStaticData();
                const staticData = payload?.om_static_data?.payload?.staticData;
                if (!staticData) return [];
                if (!Array.isArray(staticData?.exceptionFilterType)) return [];
                return staticData?.exceptionFilterType?.map((exception) => ({
                    ...exception,
                    type: 'error',
                    description: trans(exception.description),
                }));
            }
            case MarketCodeEnum.US.name.toLowerCase():
            case MarketCodeEnum.USTRX.name.toLowerCase(): {
                let exceptions = [];
                if (!pEnableMustShip) {
                    exceptions = ExceptionFilters.filter((obj) => obj.code !== toteExchangeMustShip);
                } else {
                    exceptions = ExceptionFilters;
                }
                return exceptions?.map((exception) => ({
                    ...exception,
                    abbr: trans(exception.abbr),
                    description: trans(exception.description),
                }));
            }
            default: {
                return [];
            }
        }
    }
    const exceptionFilterChips = useMemo(() => {
        const exceptionFilterTypes = getExceptionFilterTypes(pCurrentMarket);
        if (exceptionFilterTypes) {
            if (!Array.isArray(exceptionFilterTypes)) {
                return [];
            }
            const activePhaseType = Object.values(PhaseTypesEnum).find(
                (phase) => phase.index === pActiveTab && phase.markets.includes(pCurrentMarket),
            );
            const types = exceptionFilterTypes.reduce((exceptionTypesArr, exceptionType) => {
                if (exceptionType.phases?.includes(activePhaseType.code)) {
                    exceptionTypesArr.push({
                        code: exceptionType.code,
                        desc: exceptionType.description,
                        type: exceptionType.type,
                        label: trans(exceptionType?.label),
                    });
                }
                return exceptionTypesArr;
            }, []);
            return types;
        }
        return [];
    }, [pActiveTab, pCurrentMarket]);
    React.useEffect(() => {
        if (exceptionFilterChips?.length > 0) {
            pGetExceptionCount(exceptionFilterChips?.length);
        }
    }, [exceptionFilterChips]);
    return (
        <div className={classes.exceptionFilterChipsRoot}>
            {exceptionFilterChips.map((exceptionFilterChip) => (
                <ExceptionChip
                    key={exceptionFilterChip.code}
                    pId={exceptionFilterChip.code}
                    pVariant={exceptionFilterChip.type}
                    pClassName={classes.exceptionFilterChips}
                    pMessage={exceptionFilterChip.desc}
                    pOnActionClick={handleExceptionClick}
                    pActive={exceptionFilterChip.code === pExceptionFilter}
                    pTranslations={{
                        actionButtonInactive: exceptionFilterChip?.label,
                    }}
                />
            ))}
        </div>
    );
};
const propTypes = {
    pActiveTab: PropTypes.number.isRequired,
    pCurrentMarket: PropTypes.string.isRequired,
    pExceptionFilter: PropTypes.arrayOf(PropTypes.string).isRequired,
    pOnExceptionFilterChange: PropTypes.func.isRequired,
    pGetExceptionCount: PropTypes.func,
    pEnableMustShip: PropTypes.bool,
};
ExceptionFilterChips.propTypes = propTypes;
ExceptionFilterChips.defaultProps = {
    pGetExceptionCount: () => {},
    pEnableMustShip: false,
};
export default memo(ExceptionFilterChips);
