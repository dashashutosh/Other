import React, { useState, useEffect } from 'react';
import {
    TableContainer,
    Table,
    TableHead,
    TableWrapper,
    TableRow,
    TableCell,
    TableBody,
    TableHeader,
    TableHeaderLHS,
    TextInput,
    SearchIcon,
    TableHeaderRHS,
    Typography,
    TableSortLabel,
    TableActionHeader,
    Button,
    CloseIcon,
    Toast,
    Alert,
    FilterIcon,
} from '@walmart/living-design-sc-ui';
import clsx from 'clsx';
import {
    stableSort,
    getComparator,
    onSearch as onTableSearch,
    getDateComparator,
    getStrToIntComparator,
    paginatedData,
    MarketCodeEnum,
    useAPI,
    TableFooter,
} from '@walmart/stride-ui-commons';
import PropTypes, { number, string, bool } from 'prop-types';
import { useHistory } from 'react-router-dom';
import { planSearchHeaders, connectLoads, toastTimer, planTableHeadCells } from '../../Constants';
import PlanTableRow from './PlanTableRow';
import CreateTripConfirmModal from './CreateTripConfirmModal';
import { stTripToast } from '../../utils/StyleUtils';
import PhaseTypesEnum from '../../utils/enums/PhaseTypesEnum';
import {
    transformLoads,
    formatCreateTripReq,
    getCarrierResourceAssignRequest,
    getCarrierAssignRequest,
    getResourceAssignRequest,
    getFilteredColumnHeaders,
    getSelectedRowsText,
    displayConfirmButton,
    getWorkLoadEditData,
    displayHeaderLabel,
    getFooterLabels,
} from './DataModels';
import { TripAPI } from '../../service/TripAPI';
import TripUIStatusEnum from '../model/tripUiStatusEnum';
import WorkloadAssignmentModal from './WorkloadAssignmentModal';
import { isChile, isCAM, getFormattedTripError } from '../../utils/CommonUtils';
import { MaterialUiCore } from '@gscope-mfe/common-libs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { Utilities, AppUtils } from '@gscope-mfe/app-bridge';
const { makeStyles } = MaterialUiCore,
    { localizeLang } = LocalizeLang.default,
    { debounce } = Utilities;
const useStyles = makeStyles(() => ({
    stTripToast,
    lhsHeaderAction: {
        alignItems: 'center',
    },
    lhsHeader: {
        display: 'flex',
        flexDirection: 'column',
    },
    stTtContainer: {
        maxWidth: 'calc(100vw - 9em)',
        margin: '1em auto',
        '& $table': {
            borderCollapse: 'separate',
            whiteSpace: 'nowrap',
        },
    },
    tableWrapper: {
        '&.ld-sc-ui-table-wrapper': {
            maxHeight: 'unset',
        },
    },
    table: {
        '& .ld-sc-ui-checkbox-label': {
            paddingLeft: 1,
        },
    },
    stickyColumn: {
        position: 'sticky',
        backgroundColor: '#fafafa !important',
        '&:not(td)': {
            zIndex: '3 !important',
        },
    },
    stickyColumnCheckbox: {
        left: 0,
        minWidth: 90,
    },
    stickyColumnPlanId: {
        left: '90px !important',
        width: 100,
        // borderRight: '1px solid #ccc',
    },

    stickyColumnPlanStatus: {
        right: 0,
    },
}));
let selectedCarriersList = [];
export default function PlanTable(props) {
    const {
        pTabIndex,
        pConfig,
        pPlanList,
        pOnTripApprove,
        pIsAssignTrip,
        pOnTripSelection,
        pActiveTab,
        pOnTripDispatch,
        pOnTripDelivered,
        pCreateTripReq,
        pOnTripTender,
        pRefreshTableData,
        pOnReprintDoc,
        pUserPerm,
        pPageChange,
        pPageNumber,
        pFetchedTripCount,
        pSetsIsSearchFilterModalOpen,
        pFeatureFlagsData,
    } = props;
    const classes = useStyles();
    const trans = localizeLang();
    const history = useHistory();
    const { currentMarket, prefLang, userInfo, setloading, loading } = AppUtils.get();
    const [sHeaderCells, setsHeaderCells] = useState([]);
    const [sSearch, setsSearch] = useState('');
    const [sFilteredRows, setsFilteredRows] = useState([]);
    const [sPage, setsPage] = useState();
    const [sPlanDetails, setsPlanDetails] = useState([]);
    const [sCheckedRows, setsCheckedRows] = useState([]);
    const [sOrder, setsOrder] = useState('desc');
    const [sOrderBy, setsOrderBy] = useState('createdTs');
    const [sIsTripSelected, setsIsTripSelected] = useState(false);
    const [sIsConfirmTripModalOpen, setsIsConfirmTripModalOpen] = useState(false);
    const [sProcessTripStatus, setsProcessTripStatus] = useState('');
    const [sIsManualAssignModalOpen, setsIsManualAssignModalOpen] = useState(false);
    const [sLoadsToAssignManually, setsLoadsToAssignManually] = useState([]);
    const [sError, setsError] = useState('');
    const [sWorkLoadEditData, setsWorkLoadEditData] = useState();
    const [sIsWorkloadSuccess, setsIsWorkloadSuccess] = useState(false);
    const [sIsResourceApprovedSuccess, setsIsResourceApprovedSuccess] = useState(false);
    const { callAPI: createWorkloadAssignment, ...createWorkloadAssignmentResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .createWorkloadAssignment,
    );
    const { callAPI: updateWorkloadAssignment, ...updateWorkloadAssignmentResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .updateWorkloadAssignment,
    );
    const { callAPI: createResourceAssignment, ...createResourceResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .createResourceAssignment,
    );
    const { callAPI: updateResourceAssignment, ...updateResourceResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName)
            .updateResourceAssignment,
    );
    const { callAPI: carrierAssign, ...carrierAssignResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).carrierAssign,
    );
    const { callAPI: approveAssignment, ...approveAssignmentResponse } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).approveAssignment,
    );
    const debouncedFn = debounce((callback) => {
        callback();
    }, pConfig.debounceTime);
    const onSearch = (value) => {
        debouncedFn(() => {
            setsSearch(value);
        });
    };
    const handleRequestSort = (property) => {
        const isAsc = sOrderBy === property && sOrder === 'asc';
        setsOrder(isAsc ? 'desc' : 'asc');
        setsOrderBy(property);
    };
    const createSortHandler = (property) => () => {
        handleRequestSort(property);
    };
    const onClearAll = () => {
        setsCheckedRows([]);
    };
    const onConfirmTripModalClose = () => {
        setsIsConfirmTripModalOpen(false);
    };
    const onManualAssignModalClose = () => {
        setsIsManualAssignModalOpen(false);
    };
    const getSelectedLoadInfo = () => pPlanList.filter((plan) => sCheckedRows.includes(plan.planId))[0];
    useEffect(() => {
        setsHeaderCells(getFilteredColumnHeaders(pTabIndex, planTableHeadCells, pIsAssignTrip));
    }, [pTabIndex]);
    useEffect(() => {
        let rows = [];
        if (sSearch && pPlanList.length) {
            rows = onTableSearch(pPlanList, sSearch, planSearchHeaders);
        } else {
            rows = pPlanList;
        }
        if (sOrderBy === 'createdTs' || sOrderBy === 'departureTs' || sOrderBy === 'arrivalTs') {
            setsFilteredRows(stableSort(rows, getDateComparator(sOrder, sOrderBy, 'd MMM, yyyy, h:mm aaa')));
        } else if (
            sOrderBy === 'distance' ||
            sOrderBy === 'planId' ||
            sOrderBy === 'originId' ||
            sOrderBy === 'destinationId' ||
            sOrderBy === 'cases' ||
            sOrderBy === 'pallets' ||
            sOrderBy === 'cube' ||
            sOrderBy === 'weight'
        ) {
            setsFilteredRows(stableSort(rows, getStrToIntComparator(sOrder, sOrderBy)));
        } else {
            setsFilteredRows(stableSort(rows, getComparator(sOrder, sOrderBy)));
        }
        if (
            currentMarket === MarketCodeEnum.GUATEMALA.name.toLowerCase() ||
            currentMarket === MarketCodeEnum.MEXICO.name.toLowerCase() ||
            currentMarket === MarketCodeEnum.MEXICO_MARKET_PLACE.name.toLowerCase() ||
            currentMarket === MarketCodeEnum.EL_SALVADOR.name.toLowerCase() ||
            currentMarket === MarketCodeEnum.COSTA_RICA.name.toLowerCase() ||
            pFeatureFlagsData?.showPaginationInAssignTrip
        ) {
            setsPage(
                pPageNumber === 1 ? 1 : parseInt(((pPageNumber - 1) * pFetchedTripCount) / pConfig.rowsPerPage, 10),
            );
        } else {
            setsPage(1);
        }
        if (sCheckedRows.length) {
            setsCheckedRows([]);
        }
    }, [sSearch, pPlanList]);
    useEffect(() => {
        if (sSearch) {
            setsSearch('');
        }
        if (sCheckedRows.length) {
            setsCheckedRows([]);
        }
    }, [pPlanList, pActiveTab]);
    useEffect(() => {
        if (
            (pTabIndex === PhaseTypesEnum.PROCESSING.index || pTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) &&
            sCheckedRows.length
        ) {
            setsLoadsToAssignManually(transformLoads(getSelectedLoadInfo().plans));
        }
        if (pTabIndex === PhaseTypesEnum.PROCESSING.index && sCheckedRows.length) {
            selectedCarriersList = pPlanList
                ?.filter((plan) => sCheckedRows?.includes(plan.planId))
                ?.map((fPlan) => fPlan.carrierId);
        }
    }, [sCheckedRows]);
    useEffect(() => {
        if (sOrder && sOrderBy && sFilteredRows.length) {
            if (sOrderBy === 'createdTs' || sOrderBy === 'departureTs' || sOrderBy === 'arrivalTs') {
                setsFilteredRows(
                    stableSort(sFilteredRows, getDateComparator(sOrder, sOrderBy, 'd MMM, yyyy, h:mm aaa')),
                );
            } else if (
                sOrderBy === 'distance' ||
                sOrderBy === 'planId' ||
                sOrderBy === 'originId' ||
                sOrderBy === 'destinationId' ||
                sOrderBy === 'cases' ||
                sOrderBy === 'pallets' ||
                sOrderBy === 'cube' ||
                sOrderBy === 'weight'
            ) {
                setsFilteredRows(stableSort(sFilteredRows, getStrToIntComparator(sOrder, sOrderBy)));
            } else {
                setsFilteredRows(stableSort(sFilteredRows, getComparator(sOrder, sOrderBy)));
            }
        }
    }, [sOrder, sOrderBy]);
    useEffect(() => {
        if (sPage && sFilteredRows.length) {
            if (pFeatureFlagsData?.roundTripFiltering) {
                const list = sFilteredRows.filter((item) => item.originId !== item.destinationId);
                setsPlanDetails(paginatedData(list, pConfig.rowsPerPage, sPage));
            } else {
                setsPlanDetails(paginatedData(sFilteredRows, pConfig.rowsPerPage, sPage));
            }
        } else {
            setsPlanDetails([]);
        }
    }, [sPage, sFilteredRows]);
    useEffect(() => {
        let isTrip = false;
        let tripStatus = '';
        if (pPlanList.length && sCheckedRows.length) {
            isTrip = pPlanList.filter((plan) => plan.planId === sCheckedRows[0])[0].isTrip;
            tripStatus = pPlanList.filter((plan) => plan.planId === sCheckedRows[0])[0].planStatus;
        }
        setsIsTripSelected(isTrip);
        setsProcessTripStatus(tripStatus);
        if (pIsAssignTrip) pOnTripSelection(sCheckedRows[0]);
    }, [sCheckedRows]);
    useEffect(() => {
        if (
            !loading &&
            (updateWorkloadAssignmentResponse.loading ||
                approveAssignmentResponse.loading ||
                createWorkloadAssignmentResponse.loading ||
                createResourceResponse.loading ||
                updateResourceResponse.loading ||
                carrierAssignResponse.loading)
        ) {
            setloading(true);
        } else setloading(false);
    }, [
        updateWorkloadAssignmentResponse.loading,
        approveAssignmentResponse.loading,
        createWorkloadAssignmentResponse.loading,
        createResourceResponse.loading,
        updateResourceResponse.loading,
        carrierAssignResponse.loading,
    ]);
    const handleEditAssignment = () => {
        const planObj = pPlanList.find((plan) => plan.planId === sCheckedRows[0]);
        setsWorkLoadEditData(getWorkLoadEditData(planObj, trans));
    };
    useEffect(() => {
        if (sWorkLoadEditData) {
            setsIsManualAssignModalOpen(true);
        }
    }, [sWorkLoadEditData]);
    const onAssignTrip = () => {
        history.push({
            pathname: '/mfe/stride/tripmanagement/assign-trip',
            state: getSelectedLoadInfo(),
        });
    };
    const getPlanningActions = () => {
        if (pUserPerm.canEditTrip) {
            return sIsTripSelected ? (
                <Button
                    data-testid="approveTrip"
                    variant="primary"
                    size="small"
                    onClick={() => {
                        pOnTripApprove(sCheckedRows);
                    }}
                >
                    {trans('button.approveTrip')}
                </Button>
            ) : (
                <div className="d-flex">
                    {sCheckedRows.length === 1 && (
                        <Button
                            data-testid="assignToTrip"
                            variant="secondary"
                            size="small"
                            className="mr-3"
                            onClick={onAssignTrip}
                        >
                            {trans('button.assignToTrip')}
                        </Button>
                    )}
                    <Button
                        data-testid="createTrip"
                        variant="primary"
                        size="small"
                        onClick={() => {
                            setsIsConfirmTripModalOpen(true);
                        }}
                    >
                        {sCheckedRows.length === 1
                            ? trans('button.createNewTrip')
                            : `${trans('label.create')} ${sCheckedRows.length} ${trans('label.trips')}`}
                    </Button>
                </div>
            );
        }
    };
    const handleApproveAssignment = (planId) => {
        const payload = {
            planId,
            status: 'RESOURCES_ASSIGN_APPROVED',
        };
        approveAssignment(
            {
                planId,
                payload,
            },
            () => {
                setsIsResourceApprovedSuccess(true);
                pRefreshTableData();
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const canShowEditAssignment = () =>
        (sProcessTripStatus?.name === TripUIStatusEnum.AWAITING_FINALIZATION.name || isCAM(currentMarket)) &&
        sCheckedRows.length === 1;
    const getProcessingActions = () => {
        if (pUserPerm?.canEditTrip) {
            return (
                <div className="d-flex">
                    {sProcessTripStatus?.name === TripUIStatusEnum.WORKLOAD_ASSIGNMENT.name && isChile(currentMarket) && (
                        <>
                            {sCheckedRows.length === 1 && (
                                <Button
                                    data-testid="assignManually"
                                    variant="secondary"
                                    size="small"
                                    className="mr-3"
                                    onClick={() => {
                                        handleEditAssignment();
                                    }}
                                >
                                    {trans('button.assignManually')}
                                </Button>
                            )}
                            {!selectedCarriersList?.some((id) => id !== '') && (
                                <Button
                                    data-testid="tenderTrip"
                                    variant="primary"
                                    size="small"
                                    onClick={() => {
                                        pOnTripTender(sCheckedRows);
                                    }}
                                >
                                    {trans('button.tenderTrip')}
                                </Button>
                            )}
                        </>
                    )}
                    {displayConfirmButton(sCheckedRows, pPlanList) && (
                        <Button
                            data-testid="confirm"
                            variant="primary"
                            className="mr-3"
                            size="small"
                            onClick={() => {
                                handleApproveAssignment(sCheckedRows);
                            }}
                        >
                            {trans('button.confirm')}
                        </Button>
                    )}
                    {canShowEditAssignment() && (
                        <Button
                            data-testid="editAssignment"
                            variant="secondary"
                            size="small"
                            className="mr-3"
                            onClick={() => {
                                handleEditAssignment();
                            }}
                        >
                            {trans('button.editAssignment')}
                        </Button>
                    )}
                    {sProcessTripStatus?.name === TripUIStatusEnum.WORKLOAD_ASSIGNMENT.name && isCAM(currentMarket) && (
                        <Button
                            data-testid="confirm"
                            variant="primary"
                            size="small"
                            onClick={() => {
                                handleApproveAssignment(sCheckedRows);
                            }}
                        >
                            {trans('button.confirm')}
                        </Button>
                    )}
                </div>
            );
        }
    };
    const getDispatchPendingActions = () => {
        if (pUserPerm?.canEditTrip) {
            return (
                <div className="d-flex">
                    {sCheckedRows.length === 1 && (
                        <Button
                            data-testid="editWorkLoadAssignments"
                            variant="secondary"
                            size="small"
                            className="mr-3"
                            onClick={() => {
                                handleEditAssignment();
                            }}
                        >
                            {trans('button.editWorkLoadAssignments')}
                        </Button>
                    )}
                    <Button
                        data-testid="dispatch"
                        variant="primary"
                        size="small"
                        onClick={() => {
                            pOnTripDispatch(sCheckedRows);
                        }}
                    >
                        {trans('button.dispatch')}
                    </Button>
                </div>
            );
        }
    };
    const getInTransitActions = () => {
        if (pUserPerm?.canEditTrip) {
            return (
                <div className="d-flex">
                    <Button
                        data-testid="reprintDispatchDoc"
                        variant="secondary"
                        size="small"
                        className="mr-3"
                        onClick={() => {
                            pOnReprintDoc(sCheckedRows);
                        }}
                    >
                        {trans('button.reprintDispatchDoc')}
                    </Button>
                    <Button
                        data-testid="markAsDelivered"
                        variant="primary"
                        size="small"
                        onClick={() => {
                            pOnTripDelivered(sCheckedRows);
                        }}
                    >
                        {trans('button.markAsDelivered')}
                    </Button>
                </div>
            );
        }
    };
    const actions = () => {
        if (pTabIndex === PhaseTypesEnum.PLANNING.index) return getPlanningActions();
        if (pTabIndex === PhaseTypesEnum.PROCESSING.index) return getProcessingActions();
        if (pTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) return getDispatchPendingActions();
        if (pTabIndex === PhaseTypesEnum.IN_TRANSIT.index) return getInTransitActions();
    };
    const onCreateTripSubmit = (isAssign, data) => {
        setsIsConfirmTripModalOpen(false);
        pCreateTripReq(formatCreateTripReq(data, sCheckedRows));
    };
    const createWorkloadAssignmentAPI = (req, planId) => {
        createWorkloadAssignment(
            {
                payload: req,
                planId,
            },
            () => {
                pRefreshTableData();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const updateWorkloadAssignmentAPI = (req, planId) => {
        updateWorkloadAssignment(
            {
                payload: req,
                planId,
            },
            () => {
                pRefreshTableData();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const carrierAssignAPI = (req) => {
        carrierAssign(
            req,
            () => {
                pRefreshTableData();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const createResourceAssignmentAPI = (req) => {
        createResourceAssignment(
            req,
            () => {
                pRefreshTableData();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const updateResourceAssignmentAPI = (req) => {
        updateResourceAssignment(
            req,
            () => {
                pRefreshTableData();
                setsIsManualAssignModalOpen(false);
                setsIsWorkloadSuccess(true);
            },
            (err) => {
                setsError(err);
            },
        );
    };
    const handleWorkloadAssignConfirm = (
        workloadAssignmentData,
        options,
        isCreateCarrierAndResource,
        isCarrierOnly,
        isResourceAssign,
        isUpdateResource,
        isUpdateCarrier,
    ) => {
        const selectedStrip = sCheckedRows[0];
        if (isCreateCarrierAndResource && isCarrierOnly && isResourceAssign) {
            const cwRequest = getCarrierResourceAssignRequest(
                workloadAssignmentData,
                options,
                selectedStrip,
                userInfo.loggedInUserName,
                trans,
            );
            createWorkloadAssignmentAPI(cwRequest, selectedStrip);
        } else if (isCreateCarrierAndResource && isCarrierOnly && !isResourceAssign) {
            const cReq = getCarrierAssignRequest(
                workloadAssignmentData,
                options.carrierInfo,
                selectedStrip,
                userInfo.loggedInUserName,
            );
            carrierAssignAPI(cReq);
        } else if (
            !isCreateCarrierAndResource &&
            isCarrierOnly &&
            !isUpdateCarrier &&
            isResourceAssign &&
            !isUpdateResource
        ) {
            const crReq = getResourceAssignRequest(
                workloadAssignmentData,
                options.equipmentInfo,
                options.trailerInfo,
                selectedStrip,
                trans,
            );
            createResourceAssignmentAPI(crReq);
        } else if (
            !isCreateCarrierAndResource &&
            isCarrierOnly &&
            !isUpdateCarrier &&
            isResourceAssign &&
            isUpdateResource
        ) {
            const urReq = getResourceAssignRequest(
                workloadAssignmentData,
                options.equipmentInfo,
                options.trailerInfo,
                selectedStrip,
                trans,
            );
            updateResourceAssignmentAPI(urReq);
        } else if (
            !isCreateCarrierAndResource &&
            isCarrierOnly &&
            isUpdateCarrier &&
            isResourceAssign &&
            isUpdateResource
        ) {
            const uwReq = getCarrierResourceAssignRequest(
                workloadAssignmentData,
                options,
                selectedStrip,
                userInfo.loggedInUserName,
                trans,
            );
            updateWorkloadAssignmentAPI(uwReq, selectedStrip);
        } else if (
            !isCreateCarrierAndResource &&
            isCarrierOnly &&
            isUpdateCarrier &&
            isResourceAssign &&
            !isUpdateResource
        ) {
            const cwReq = getCarrierResourceAssignRequest(
                workloadAssignmentData,
                options,
                selectedStrip,
                userInfo.loggedInUserName,
                trans,
            );
            createWorkloadAssignmentAPI(cwReq, selectedStrip);
        } else if (
            !isCreateCarrierAndResource &&
            isCarrierOnly &&
            isUpdateCarrier &&
            !isResourceAssign &&
            !isUpdateResource
        ) {
            const request = getCarrierAssignRequest(
                workloadAssignmentData,
                options.carrierInfo,
                selectedStrip,
                userInfo.loggedInUserName,
            );
            carrierAssignAPI(request);
        } else if (
            !isCreateCarrierAndResource &&
            isCarrierOnly &&
            isUpdateCarrier &&
            !isResourceAssign &&
            isUpdateResource
        ) {
            const uWrequest = getCarrierResourceAssignRequest(
                workloadAssignmentData,
                options,
                selectedStrip,
                userInfo.loggedInUserName,
                trans,
            );
            updateWorkloadAssignmentAPI(uWrequest, selectedStrip);
        }
    };
    const header = () => (
        <TableRow key="header">
            <TableCell className={clsx(classes.stickyColumn, classes.stickyColumnCheckbox)} />
            {sHeaderCells.map((headCell) => (
                <TableCell
                    key={headCell.id}
                    sortDirection={sOrderBy === headCell.id ? sOrder : false}
                    className={clsx({
                        [classes.stickyColumn]: headCell.id === 'planId' || headCell.id === 'planStatusLabel',
                        [classes.stickyColumnPlanId]: headCell.id === 'planId',
                        [classes.stickyColumnPlanStatus]: headCell.id === 'planStatusLabel',
                    })}
                >
                    <TableSortLabel
                        active={sOrderBy === headCell.id}
                        direction={sOrderBy === headCell.id ? sOrder : 'asc'}
                        onClick={createSortHandler(headCell.id)}
                    >
                        {displayHeaderLabel(headCell.label, pConfig, pPlanList.length, trans)}
                        {headCell.id === 'rate' && pConfig?.country?.currency && (
                            <div>({pConfig.country.currency[0]})</div>
                        )}
                    </TableSortLabel>
                </TableCell>
            ))}
        </TableRow>
    );

    // const pages = useMemo(() => {
    //   const pageButtons = [];
    //   const pageSize = 100;
    //   const maxLimit = pFetchedTripCount === pageSize
    //     ? pPageNumber + 1
    //     : pPageNumber;
    //   for (let i = pPageNumber - 1 || 1; i <= maxLimit; i += 1) {
    //     pageButtons.push({
    //       id: i,
    //       value: `${1 + ((i - 1) * pageSize)} - ${i * pageSize}`,
    //     });
    //   }

    //   return pageButtons;
    // }, [pPageNumber, pFetchedTripCount]);

    const nextPageInfo = (e) => {
        e.stopPropagation();
        e.preventDefault();
        if (
            (sPage + 1) * pConfig.rowsPerPage >= pPlanList.length &&
            pPlanList.length > 0 &&
            pPlanList.length > pConfig.rowsPerPage &&
            (currentMarket === MarketCodeEnum.GUATEMALA.name.toLowerCase() ||
                currentMarket === MarketCodeEnum.MEXICO.name.toLowerCase() ||
                currentMarket === MarketCodeEnum.MEXICO_MARKET_PLACE.name.toLowerCase() ||
                currentMarket === MarketCodeEnum.COSTA_RICA.name.toLowerCase() ||
                currentMarket === MarketCodeEnum.EL_SALVADOR.name.toLowerCase() ||
                pFeatureFlagsData?.showPaginationInAssignTrip)
        ) {
            pPageChange(pPageNumber + 1);
        }
        setsPage(sPage + 1);
    };
    const previousPageInfo = (e) => {
        e.stopPropagation();
        e.preventDefault();
        setsPage(sPage - 1);
    };
    return (
        <>
            {sIsWorkloadSuccess && (
                <Toast
                    text={trans('msg.workloadAssignSuccess')}
                    variant="positive"
                    delay={toastTimer}
                    className={classes.stTripToast}
                    onClose={() => {
                        setsIsWorkloadSuccess(false);
                    }}
                />
            )}
            {sError && !sIsWorkloadSuccess && (
                <Alert
                    variant="error"
                    data-testid="workloadFailAlert"
                    onClose={() => {
                        setsError('');
                    }}
                >
                    {getFormattedTripError(sError, trans)}
                </Alert>
            )}
            {sIsResourceApprovedSuccess && (
                <Toast
                    text={trans('msg.resourceAssignApproveSuccess')}
                    variant="positive"
                    delay={toastTimer}
                    className={classes.stTripToast}
                    onClose={() => {
                        setsIsResourceApprovedSuccess(false);
                    }}
                />
            )}
            {approveAssignmentResponse?.error && !sIsResourceApprovedSuccess && (
                <Alert
                    variant="error"
                    data-testid="resourceApproveFailAlert"
                    onClose={() => {
                        setsError('');
                    }}
                >
                    {getFormattedTripError(approveAssignmentResponse?.error, trans)}
                </Alert>
            )}

            <TableContainer className={classes.stTtContainer}>
                <TableHeader>
                    <TableActionHeader show={sCheckedRows.length && !pIsAssignTrip}>
                        <TableHeaderLHS className={classes.lhsHeaderAction}>
                            <Typography>
                                {`${sCheckedRows.length} ${getSelectedRowsText(sIsTripSelected, sCheckedRows, trans)}`}
                            </Typography>
                            <Button
                                data-testid="clearAll"
                                variant="text-only"
                                startIcon={<CloseIcon size="small" />}
                                onClick={onClearAll}
                            >
                                {trans('button.clear')}
                            </Button>
                        </TableHeaderLHS>
                        <TableHeaderRHS>{actions()}</TableHeaderRHS>
                    </TableActionHeader>
                    <TableHeaderLHS className={classes.lhsHeader}>
                        <TextInput
                            id="search"
                            key="search"
                            value={sSearch}
                            label={trans('label.search')}
                            onChange={(e) => onSearch(e.target.value)}
                            endIcon={<SearchIcon size="small" />}
                            data-testid="search"
                        />
                    </TableHeaderLHS>
                    <TableHeaderRHS className="d-flex gap-4 mr-4">
                        {pFeatureFlagsData?.showSearchFilterForAssignTrip && (
                            <div data-testid="search-filter-icon">
                                <FilterIcon
                                    onClick={() => {
                                        pSetsIsSearchFilterModalOpen(true);
                                    }}
                                    size="small"
                                />
                            </div>
                        )}
                    </TableHeaderRHS>
                </TableHeader>
                <TableWrapper className={classes.tableWrapper}>
                    <Table stickyHeader className={classes.table}>
                        <TableHead>{header()}</TableHead>
                        <TableBody>
                            {sPlanDetails.map((rowData) => (
                                <PlanTableRow
                                    key={rowData.planId}
                                    pRowData={rowData}
                                    classes={classes}
                                    pCheckedRows={sCheckedRows}
                                    pSetCheckedRows={setsCheckedRows}
                                    pTabIndex={pTabIndex}
                                    pIsTripSelected={sIsTripSelected}
                                    pTripStatus={sProcessTripStatus}
                                    pIsAssignTrip={pIsAssignTrip}
                                    pUserPerm={pUserPerm}
                                />
                            ))}
                        </TableBody>
                    </Table>
                </TableWrapper>
                <TableFooter
                    count={sFilteredRows.length}
                    onNextPage={(e) => nextPageInfo(e)}
                    onPrevPage={(e) => previousPageInfo(e)}
                    page={sPage}
                    labels={getFooterLabels(trans)}
                    rowsPerPage={pConfig.rowsPerPage}
                />
            </TableContainer>
            {!pIsAssignTrip && (
                <>
                    {sIsConfirmTripModalOpen && (
                        <CreateTripConfirmModal
                            pIsOpen={sIsConfirmTripModalOpen}
                            pOnClose={onConfirmTripModalClose}
                            pConnectLoads={connectLoads.map((type) => ({
                                ...type,
                                value: trans(type.value),
                            }))}
                            pOnSubmit={onCreateTripSubmit}
                        />
                    )}

                    {sIsManualAssignModalOpen && (
                        <WorkloadAssignmentModal
                            pOnClose={onManualAssignModalClose}
                            pOnConfirmAssign={handleWorkloadAssignConfirm}
                            pLoads={sLoadsToAssignManually}
                            pWorkloadData={sWorkLoadEditData}
                            pTrip={pPlanList?.find((plan) => plan?.planId === sCheckedRows[0])}
                        />
                    )}
                </>
            )}
        </>
    );
}
PlanTable.propTypes = {
    pTabIndex: number.isRequired,
    pConfig: PropTypes.shape({
        rowsPerPage: number.isRequired,
        debounceTime: number.isRequired,
        country: PropTypes.shape({
            currency: PropTypes.arrayOf(string).isRequired,
        }).isRequired,
        UOM: PropTypes.object.isRequired,
    }).isRequired,
    pPlanList: PropTypes.arrayOf(
        PropTypes.shape({
            planId: string,
            isTrip: bool,
            loadType: string,
            loadCount: number,
            originId: string,
            originName: string,
            destinationId: string,
            destinationName: string,
            noOfStops: string,
            laneId: string,
            rate: string,
            carrierName: string,
            carrierStatus: string,
            carrierStatusColor: string,
            equipmentLength: string,
            protectionLevel: string,
            equipmentId: string,
            equipmentType: string,
            driverName: string,
            driverId: string,
            cases: string,
            pallets: string,
            cube: string,
            weight: string,
            departureTs: string,
            arrivalTs: string,
            createdTs: string,
            planStatus: string,
            planStatusLabel: string,
            planStatusColor: string,
        }),
    ).isRequired,
    pOnTripApprove: PropTypes.func,
    pIsAssignTrip: bool,
    pOnTripSelection: PropTypes.func,
    pOnTripDispatch: PropTypes.func,
    pOnTripDelivered: PropTypes.func,
    pCreateTripReq: PropTypes.func,
    pOnTripTender: PropTypes.func,
    pRefreshTableData: PropTypes.func,
    pActiveTab: number,
    pOnReprintDoc: PropTypes.func,
    pUserPerm: PropTypes.oneOfType([PropTypes.object]),
    pPageChange: PropTypes.func,
    pPageNumber: number,
    pFetchedTripCount: number,
    pSetsIsSearchFilterModalOpen: PropTypes.func,
    pFeatureFlagsData: PropTypes.oneOfType([PropTypes.object]),
};
PlanTable.defaultProps = {
    pOnTripApprove: () => {},
    pIsAssignTrip: false,
    pOnTripSelection: () => {},
    pOnTripDispatch: () => {},
    pOnTripDelivered: () => {},
    pCreateTripReq: () => {},
    pOnTripTender: () => {},
    pRefreshTableData: () => {},
    pActiveTab: 0,
    pOnReprintDoc: () => {},
    pUserPerm: {},
    pPageChange: () => {},
    pPageNumber: {},
    pFetchedTripCount: {},
    pSetsIsSearchFilterModalOpen: () => {},
    pFeatureFlagsData: {},
};
