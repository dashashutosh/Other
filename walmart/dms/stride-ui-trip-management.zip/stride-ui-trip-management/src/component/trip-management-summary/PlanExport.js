import React from 'react';
import { DownloadIcon } from '@walmart/living-design-sc-ui';
import PropTypes, { string } from 'prop-types';
import ExcelJS from 'exceljs';
import FileSaver from 'file-saver';
import moment from 'moment-timezone';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { localizeLang } = LocalizeLang.default;
export default function PlanExport(props) {
    const { planData, columnsToExport } = props;
    const { userInfo } = AppUtils.get();
    const trans = localizeLang();
    const exportQuery = async () => {
        const workbook = new ExcelJS.Workbook();
        const sheet = workbook.addWorksheet(trans('downloadPlanQuery.sheetName'));
        sheet.columns = columnsToExport;
        sheet.addRows(planData);
        const file = await workbook.xlsx.writeBuffer();
        const blob = new Blob([file], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8',
        });
        FileSaver.saveAs(
            blob,
            `${trans('downloadPlanQuery.fileName')}_${userInfo.loggedInUserName}_${moment().format(
                'MM-DD-YYYY_hh-mm-ss-SSS_A',
            )}.xlsx`,
        );
    };
    const onClickExport = () => {
        exportQuery();
    };
    return (
        <div>
            <DownloadIcon data-testid="downloadIcon" onClick={onClickExport} />
        </div>
    );
}
PlanExport.propTypes = {
    columnsToExport: PropTypes.arrayOf(
        PropTypes.shape({
            key: string,
            header: string,
        }),
    ).isRequired,
    planData: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
};
