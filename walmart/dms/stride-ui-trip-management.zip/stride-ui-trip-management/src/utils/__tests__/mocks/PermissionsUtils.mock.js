export const mockPermissionsForCA = [
    'ca.stride.tripManagement:READ',
    'ca.stride.tripManagement:READ_DETAILS',
    'ca.stride.tripManagement:READ_QUERY',
    'ca.stride.tripManagement:WRITE',
    'ca.stride.ltm-tripManagement:READ_DETAILS',
    'ca.stride.ltm-tripManagement:READ_QUERY',
    'ca.stride.ltm-tripManagement:WRITE',
];
export const mockPermissionsForUS = [
    'us.stride.ltm-tripManagement:READ',
    'us.stride.ltm-tripManagement:WRITE',
    'us.stride.ltm-tripManagement:RATE_READ',
];
