export const planStatusMockData = [
    {
        type: 'PLANNING',
    },
    {
        type: 'PROCESSING',
    },
    {
        type: 'READY_TO_START',
    },
    {
        type: 'IN_TRANSIT',
    },
];

export const multiLoadCancelError = {
    status: 'FAIL',
    header: {
        headerAttributes: {},
    },
    errors: [
        {
            code: 'ITEM_NOT_FOUND',
            field: '500008437',
            description: 'No item found',
            info: 'STRIDE_API_0003',
            severity: 'ERROR',
            category: 'REQUEST',
            causes: [],
        },
        {
            code: 'ITEM_NOT_FOUND',
            field: '500009655',
            description: 'No item found',
            info: 'STRIDE_API_0003',
            severity: 'ERROR',
            category: 'REQUEST',
            causes: [],
        },
    ],
    payload: [],
};
