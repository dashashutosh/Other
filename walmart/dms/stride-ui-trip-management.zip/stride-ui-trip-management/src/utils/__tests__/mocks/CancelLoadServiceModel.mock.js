import { getCancelLoadError, getCancelLoadReqPayload, getCancelLoadResponse } from '../../CancelLoadServiceModel';

export const mockApiParams = {
    pApiParams: {
        axios: () => {},
        ccmServiceName: 'stride-ui-trip-management-cancelLoadMulti',
        ccmRouteName: 'cancelLoadMulti',
        userId: 'testUser',
        language: 'en',
        currentMarket: 'ca',
        baseUrl: 'localhost:8080',
    },
    pTrans: () => '',
};

export const mockApiParamsResult = {
    pTransformResponseFn: getCancelLoadResponse,
    pGetErrorsFromAPIErrorFn: getCancelLoadError,
    pTransformRequestFn: getCancelLoadReqPayload,
    pGetDataValidationErrorsFn: () => {},
    pApiParams: {
        axios: mockApiParams.pApiParams.axios,
        ccmServiceName: mockApiParams.pApiParams.ccmServiceName,
        ccmRouteName: mockApiParams.pApiParams.ccmRouteName,
        method: 'post',
        baseUrl: mockApiParams.pApiParams.baseUrl,
        headers: {
            userId: 'testUser',
            userName: '',
            'WM_SVC.TENANT_ID': 'CA_CA',
        },
    },
    pConfigs: {
        handlePartialSuccess: false,
    },
    pTrans: mockApiParams.pTrans,
};
