import { LoadActionsEnum, TripActionsEnum } from '@walmart/stride-ui-commons';
import {
    canEditTrip,
    canReadRate,
    canEdit,
    getUserActions,
    userEditActions,
    canAccessNonDrayLoads,
    canBulkUploadTender,
} from '../PermissionsUtils';
import { mockPermissionsForCA, mockPermissionsForUS } from './mocks/PermissionsUtils.mock';

describe('Permission Utils', () => {
    it('should check permissions for US market', () => {
        expect(canEditTrip([], 'us')).toEqual(false);
        expect(canEditTrip(mockPermissionsForUS, 'us')).toEqual(true);

        expect(canReadRate([], 'us')).toEqual(false);
        expect(canReadRate(mockPermissionsForUS, 'us')).toEqual(true);
    });

    it('should check permissions for CA market', () => {
        expect(canEditTrip([], 'ca')).toEqual(false);
        expect(canEditTrip(mockPermissionsForCA, 'ca')).toEqual(true);
    });

    // TODO: Fix this test after MFE migration
    it.skip('should check permissions for US market with module group', () => {
        expect(canEdit(mockPermissionsForUS, 'us', 'ltm')).toEqual(true);
        expect(canEdit(mockPermissionsForUS, 'us', 'mdm')).toEqual(false);
    });

    it('should return user actions based on permissions', () => {
        expect(getUserActions([], 'us')).toEqual([
            LoadActionsEnum.STOP_SEQUENCE_AUDIT,
            TripActionsEnum.STOP_SEQUENCE_AUDIT,
            TripActionsEnum.PRINT_TRIP_SHEET,
        ]);
        expect(getUserActions(mockPermissionsForUS, 'us')).toEqual(userEditActions);
    });

    it('should check permissions for canAccessNonDrayLoads', () => {
        expect(canAccessNonDrayLoads([], 'us')).toEqual(true);
        expect(canAccessNonDrayLoads(mockPermissionsForUS, 'us')).toEqual(true);
        expect(
            canAccessNonDrayLoads([...mockPermissionsForUS, 'us.stride.ltm-tripManagement:DRAY_EXTERNAL_USERS'], 'us'),
        ).toEqual(false);
    });

    it('should check permissions for canBulkUploadTender', () => {
        expect(canBulkUploadTender([], 'us')).toEqual(false);
        expect(canBulkUploadTender(mockPermissionsForUS, 'us')).toEqual(true);
        expect(canBulkUploadTender(['us.stride.ltm-tripManagement:READ'], 'us')).toEqual(false);
    });
});
