import { PlanScreenEnum } from '@walmart/stride-ui-commons';
import featureConfig from '../featureConfig';

describe('featureConfig Utils', () => {
    const featureFlags = {
        enablePaperPrint: true,
        enableDrayExtUserPerm: true,
        enableTrailerIdEdit: true,
        enableOdometerEdit: true,
        disableActionsForOBLoadTypes: true,
        enablePrintTripSheet: true,
        filterShadowModeEntities: true,
        enableHazmatUpdate: true,
        enableMarkServiceFailureForDray: true,
        enableHoldTag: true,
        enableWTMSLoadStatus: true,
    };
    const pConfigs = {
        hazmatUpdateAllowedPlanTypes: ['IMP_DRAY', 'IMP_MTDRAY', 'IMP_OCEAN'],
        WTMSLoadlength: 8,
        WTMSLoadSeries: ['6', '7', '8', '9'],
        WTMSCreatedSourceSystem: '',
    };
    it('should return feature flag config', () => {
        expect(featureConfig(featureFlags, pConfigs)).toEqual({
            screen: PlanScreenEnum.LIFECYCLE.code,
            enablePaperPrint: true,
            enableDrayExtUserPerm: true,
            enableTrailerIdEdit: true,
            enableOdometerEdit: true,
            disableActionsForOBLoadTypes: true,
            enablePrintTripSheet: true,
            filterShadowModeEntities: true,
            enableHazmatUpdate: true,
            hazmatUpdateAllowedPlanTypes: ['IMP_DRAY', 'IMP_MTDRAY', 'IMP_OCEAN'],
            WTMSLoadlength: 8,
            WTMSLoadSeries: ['6', '7', '8', '9'],
            WTMSCreatedSourceSystem: '',
            enableMarkServiceFailureForDray: true,
            enableHoldTag: true,
            enableWTMSLoadStatus: true,
        });
    });
});
