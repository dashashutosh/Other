import TripSharedService from '../../service/TripSharedService';
import {
    transformMultiInputStringValue,
    formatAssignErrors,
    errorHandler,
    getTimezoneFromIsoDateString,
    formatTripErrors,
    getShortTimezoneAbbr,
    getFormattedTripError,
    getPlanStatusList,
    getValidationError,
    isChile,
    isCAM,
    getUsUsTenantFlagValue,
    isHubstrOrDecstrTripLoad,
    getCommentsConfigurations,
    getTableActions,
    formatCancelTripActionRequest,
    formatErrorListFromResponse,
} from '../CommonUtils';
import { multiLoadCancelError, planStatusMockData } from './mocks/CommonUtils.mock';

describe('CommonUtils', () => {
    it('isChile() - should validate the given market is Chile or not', () => {
        expect(isChile('cl')).toEqual(true);
        expect(isChile('mx')).toEqual(false);
    });

    it('isCAM() - should validate the given market belongs CAM countries or not', () => {
        expect(isCAM('gt')).toEqual(true);
        expect(isCAM('mx')).toEqual(true);
        expect(isCAM('cl')).toEqual(false);
        expect(isCAM('ca')).toEqual(false);
        expect(isCAM('us')).toEqual(false);
    });
});

describe('getShortTimezoneAbbr', () => {
    const timezoneStaticData = [{ olsen_timezone_id: 'America/St_Johns', short_abbr: 'NT' }];
    it('should handle invalid olsenTimezoneId and timezones', () => {
        expect(getShortTimezoneAbbr('', timezoneStaticData)).toEqual('');
        expect(getShortTimezoneAbbr('America/St_Johns', '')).toEqual('');
    });
    it('should find short abbr for given olsen timezone id', () => {
        expect(getShortTimezoneAbbr('America/St_Johns', timezoneStaticData)).toEqual('NT');
    });
});

describe('transformMultiInputStringValue', () => {
    it('should return comma seperated values if value is provided', () => {
        const config = transformMultiInputStringValue('cfoo   bar quxa');
        expect(config).toEqual(['cfoo', '', '', 'bar', 'quxa']);
    });
    it('should return empty array if value is empty string', () => {
        const config = transformMultiInputStringValue('');
        expect(config).toEqual([]);
    });
});
describe('formatAssignErrors', () => {
    it('should returntime out error key if error code is ECONNABORTED', () => {
        const config = formatAssignErrors({ code: 'ECONNABORTED' });
        expect(config.key).toEqual('API.error.timeout');
    });
    it('should return invalid error key if error code and errors are not available', () => {
        const config = formatAssignErrors({});
        expect(config.key).toEqual('API.error.invalid');
    });
    const error = {
        errors: [],
    };
    it('should return invalid error key if error list is empty array', () => {
        const config = formatAssignErrors(error);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorList = {
        errors: [
            {
                description: 'sample',
            },
        ],
    };
    it('should return invalid error key if error list is available', () => {
        const config = formatAssignErrors(errorList);
        expect(config).toEqual('sample');
    });
});

describe('errorHandler', () => {
    const errorList = {
        errors: [
            {
                description: 'sample',
            },
        ],
    };
    it('should return error if error list available', () => {
        const config = errorHandler(errorList);
        expect(config).toEqual(errorList);
    });
    it('should return no service error if errors is empty', () => {
        const config = errorHandler({});
        expect(config.key).toEqual('pageError.summary.noService');
    });
    it('getFormattedTripError() - should return formatted error text', () => {
        expect(getFormattedTripError('Error Response', (a) => a)).toEqual('API.error.invalid');
    });
});

describe.skip('getTimezoneFromIsoDateString  ', () => {
    it.skip('should return time zone for a date', () => {
        const config = getTimezoneFromIsoDateString('2022-03-15T06:13:58.000-05:00');
        expect(config).toContain('T');
    });
});
describe('formatTripErrors', () => {
    it('should return time out error key if error code is ECONNABORTED', () => {
        const config = formatTripErrors({ code: 'ECONNABORTED' });
        expect(config.key).toEqual('API.error.timeout');
    });
    it('should return invalid error key if error code and errors are not available', () => {
        const config = formatTripErrors({});
        expect(config.key).toEqual('API.error.invalid');
    });
    const error = {
        errors: [],
    };
    it('should return invalid error key if error list is empty array', () => {
        const config = formatTripErrors(error);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorList = {
        httpStatusCode: 200,
        errors: [
            {
                description: 'sample',
            },
        ],
    };
    it('should return invalid error key if error list is available', () => {
        const config = formatTripErrors(errorList);
        expect(config).toEqual('sample');
    });
    const errorListWithSttaus = {
        httpStatusCode: 200,
    };
    it('should return not found error key if error list is empty array and sttaus code 200', () => {
        const config = formatTripErrors(errorListWithSttaus);
        expect(config.key).toEqual('API.error.notFound');
    });
    const errorListWithIdentifiers = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        errors: [{ description: 'sample' }],
                    },
                },
            },
        ],
    };
    it('should return error description', () => {
        const config = formatTripErrors(errorListWithIdentifiers);
        expect(config).toEqual('sample');
    });
    const errorListWithIdentifiersNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        errors: [],
                    },
                },
            },
        ],
    };
    it('should return invalid error key if error list is empty array', () => {
        const config = formatTripErrors(errorListWithIdentifiersNull);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithMessages = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        messages: [{ description: 'sample' }],
                    },
                },
            },
        ],
    };
    it('should return error description is message is present', () => {
        const config = formatTripErrors(errorListWithMessages);
        expect(config).toEqual('sample');
    });
    const errorListWithMessagesNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        messages: [],
                    },
                },
            },
        ],
    };
    it('should return invalid error key if message list is empty ', () => {
        const config = formatTripErrors(errorListWithMessagesNull);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithMessagesDTO = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: [{ messagesDTO: [{ description: 'sample' }] }],
                },
            },
        ],
    };
    it('should return description if message dto is present', () => {
        const config = formatTripErrors(errorListWithMessagesDTO);
        expect(config).toEqual('sample');
    });
    const errorListWithMessagesDTONull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: [{ messagesDTO: [] }],
                },
            },
        ],
    };
    it('should return invalid error key if messagedto list is empty', () => {
        const config = formatTripErrors(errorListWithMessagesDTONull);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithMessagesDet = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: [
                        {
                            messages: [{ description: 'sample' }],
                        },
                    ],
                },
            },
        ],
    };
    it('should return description if error detail msg available', () => {
        const config = formatTripErrors(errorListWithMessagesDet);
        expect(config).toEqual('sample');
    });
    const errorListWithMessagesDetNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: [
                        {
                            messages: [],
                        },
                    ],
                },
            },
        ],
    };
    it('should return invalid error key if error detail message list is empty array', () => {
        const config = formatTripErrors(errorListWithMessagesDetNull);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithCarrierSearch = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        carrierSearch: { error: 'sample' },
                    },
                },
            },
        ],
    };
    it('should return description if carriersearch available', () => {
        const config = formatTripErrors(errorListWithCarrierSearch);
        expect(config).toEqual('sample');
    });
    const errorListWithCarrierSearchNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        carrierSearch: { error: '' },
                    },
                },
            },
        ],
    };
    it('should return invalid error key if carrier search list is empty ', () => {
        const config = formatTripErrors(errorListWithCarrierSearchNull);
        expect(config.key).toEqual('API.error.invalid');
    });

    const errorListWithdispatchSearch = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        dispatchSearch: { error: 'sample' },
                    },
                },
            },
        ],
    };
    it('should return description  if dispatch list available', () => {
        const config = formatTripErrors(errorListWithdispatchSearch);
        expect(config).toEqual('sample');
    });
    const errorListWithdispatchSearchNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        dispatchSearch: { error: '' },
                    },
                },
            },
        ],
    };
    it('should return  invalid error key if dispatch search is empty', () => {
        const config = formatTripErrors(errorListWithdispatchSearchNull);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithtripManagementSearch = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        tripManagementSearch: { error: 'sample' },
                    },
                },
            },
        ],
    };
    it('should return description  if trip search available', () => {
        const config = formatTripErrors(errorListWithtripManagementSearch);
        expect(config).toEqual('sample');
    });
    const errorListWithtripManagementSearchNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        tripManagementSearch: { error: '' },
                    },
                },
            },
        ],
    };
    it('should return invalid error key if trip search list is empty', () => {
        const config = formatTripErrors(errorListWithtripManagementSearchNull);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithcarrier = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        carrier_info: { message: 'sample' },
                    },
                },
            },
        ],
    };
    it('should return description if carier infor available', () => {
        const config = formatTripErrors(errorListWithcarrier);
        expect(config).toEqual('sample');
    });
    const errorListWithcarrierNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        carrier_info: { message: '' },
                    },
                },
            },
        ],
    };
    it('should return invalid key if carrier info list is empty', () => {
        const config = formatTripErrors(errorListWithcarrierNull);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithresource = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        resource_info: { messages: ['sample'] },
                    },
                },
            },
        ],
    };
    it('should return description if resource list is empty', () => {
        const config = formatTripErrors(errorListWithresource);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithresourceNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        resource_info: { messages: [] },
                    },
                },
            },
        ],
    };
    it('should return invalid  error key if error list is empty', () => {
        const config = formatTripErrors(errorListWithresourceNull);
        expect(config.key).toEqual('API.error.invalid');
    });
    const errorListWithpayload = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        payload: { message: 'sample' },
                    },
                },
            },
        ],
    };
    it('should return description if payload message list ', () => {
        const config = formatTripErrors(errorListWithpayload);
        expect(config).toEqual('sample');
    });
    const errorListWithpayloadNull = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        payload: { message: '' },
                    },
                },
            },
        ],
    };
    it('should return invalid error key if payload message list is empty', () => {
        const config = formatTripErrors(errorListWithpayloadNull);
        expect(config.key).toEqual('API.error.invalid');
    });

    const errorListArr = [{ planId: 123, errMessage: 'sample' }];
    it('should return description if error message', () => {
        const config = formatTripErrors(errorListArr);
        expect(config).toEqual('123: sample');
    });

    const errorListObj = {
        errors: [
            {
                description: 'sample',
                errorIdentifiers: {
                    details: {
                        error: 'sample',
                    },
                },
            },
        ],
    };
    it('should return description if error identifiers available', () => {
        const config = formatTripErrors(errorListObj);
        expect(config).toEqual('sample');
    });
    const err = {
        error: 'sample',
    };
    it('should return desc if error available', () => {
        const config = formatTripErrors(err);
        expect(config).toEqual('sample');
    });
    const errKey = {
        key: 'sample',
    };
    it('should return desc errKey available', () => {
        const config = formatTripErrors(errKey);
        expect(config).toEqual(errKey);
    });
    const errKeyErrors = {
        errors: [
            {
                info: 'sample',
            },
        ],
    };
    it('should return  description if err info', () => {
        const config = formatTripErrors(errKeyErrors);
        expect(config).toEqual('sample');
    });
    it('should return  status list by plantype and planstatus', () => {
        expect(getPlanStatusList(0, planStatusMockData)).toEqual([planStatusMockData[0]]);
        expect(getPlanStatusList(1, planStatusMockData)).toEqual([planStatusMockData[1]]);
        expect(getPlanStatusList(2, planStatusMockData)).toEqual([planStatusMockData[2]]);
        expect(getPlanStatusList(3, planStatusMockData)).toEqual([planStatusMockData[3]]);
        expect(getPlanStatusList('', planStatusMockData)).toEqual([]);
    });

    it('should return validation error', () => {
        const formValue = { status: ['Planned'] };
        expect(getValidationError(formValue, 1)).toEqual('onlyStatusError');
    });

    it('should not return validation error', () => {
        expect(getValidationError({}, 0)).toEqual('');
    });

    it('getUSUsgetTenantValue should return correct value', () => {
        expect(getUsUsTenantFlagValue('us', true)).toEqual(true);
        expect(getUsUsTenantFlagValue('ustrx', true)).toEqual(true);
        expect(getUsUsTenantFlagValue('ustrx', false)).toEqual(false);
    });

    it('should return error message for multi load cancel', () => {
        expect(formatTripErrors(multiLoadCancelError)).toEqual('No item found\nNo item found');
    });
});

describe('Hubstr or Decstr Trip Load', () => {
    it('should return false if tripData or sLoadInfo is undefined or empty', () => {
        expect(isHubstrOrDecstrTripLoad({})).toBe(false);
        expect(isHubstrOrDecstrTripLoad({ tripData: {}, sLoadInfo: {} })).toBe(false);
    });

    it('should return false if referenceLoadType is not in HUBSTR or DECSTR', () => {
        expect(
            isHubstrOrDecstrTripLoad({
                tripData: { plans: [{ referenceLoadType: 'STR' }] },
                sLoadInfo: { referenceLoadType: 'PLT' },
            }),
        ).toBe(false);
    });

    it('should return true if referenceLoadType is in HUBSTR or DECSTR and referenceLoadType matches', () => {
        expect(
            isHubstrOrDecstrTripLoad({
                tripData: { plans: [{ referenceLoadType: 'HUBSTR' }] },
                sLoadInfo: { referenceLoadType: 'PLT' },
            }),
        ).toBe(true);
        expect(
            isHubstrOrDecstrTripLoad({
                tripData: { plans: [{ referenceLoadType: 'DECSTR' }] },
                sLoadInfo: { referenceLoadType: 'PLT' },
            }),
        ).toBe(true);
    });
});

describe('getTableActions', () => {
    beforeEach(() => {
        TripSharedService.setFeatureFlags({});
        TripSharedService.setTrans(jest.fn((str) => str));
    });
    it('should return empty actions if user selects no rows', () => {
        expect(getTableActions({}, 5, [], 0)).toEqual([]);
    });
    it('should return empty actions if user selects more than 15 rows', () => {
        expect(getTableActions({}, 5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], 0)).toEqual([]);
    });
    it('should return correct actions for planning tab', () => {
        expect(getTableActions({}, 5, [1000], 0)).toEqual([{ name: 'APPROVE_LOAD', desc: 'button.approveLoad' }]);
    });
    it('should return correct actions for processing tab', () => {
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000], 1)).toEqual([
            { name: 'ASSIGN_CARRIER_AUTO', desc: 'button.assignManually' },
        ]);
    });
    it('should return correct actions for processing tab with multi load and feature flag is enabled', () => {
        TripSharedService.setFeatureFlags({
            enableMultiLoadAssignment: true,
        });
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000, 5000001, 5000002], 1)).toEqual([
            { name: 'ASSIGN_CARRIER_AUTO', desc: 'button.assignManually' },
        ]);
    });
    it('should return correct actions for dispatch tab', () => {
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000], 2)).toEqual([
            { name: 'FORCE_LOAD_TO_DELIVERED', desc: 'button.forceLoadToDelivered' },
        ]);
    });
    it('should return correct actions for in-transit tab', () => {
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000], 3)).toEqual([
            { name: 'FORCE_LOAD_TO_DELIVERED', desc: 'button.forceLoadToDelivered' },
        ]);
    });

    it('should return withdraw tender for [ready to start, in transit] tab and feature flag is enabled', () => {
        TripSharedService.setFeatureFlags({
            enableMultiWithdrawTender: true,
        });
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000, 5000001], 2)).toEqual([
            { name: 'WITHDRAW_TENDER', desc: 'button.withdrawTender' },
        ]);
        expect(getTableActions({ name: 'IN_TRANSIT' }, 5, [5000000, 5000001], 3)).toEqual([
            { name: 'WITHDRAW_TENDER', desc: 'button.withdrawTender' },
        ]);
    });
    it('should not return withdraw tender for [ready to start, in transit] tab and feature flag is disabled', () => {
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000, 5000001], 2)).toEqual([]);
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000, 5000001], 3)).toEqual([]);
    });

    it('should return cancel load for [planning, processing, ready to start] tab and feature flag is enabled', () => {
        TripSharedService.setFeatureFlags({
            enableMultiLoadCancel: true,
        });
        expect(getTableActions({ name: 'AWAITING_FINALIZATION' }, 5, [5000000, 5000001], 0)).toEqual([
            { name: 'APPROVE_LOAD', desc: 'button.approveLoad' },
            { name: 'CANCEL_LOAD', desc: 'button.cancelLoad' },
        ]);
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000, 5000001], 1)).toEqual([
            { name: 'CANCEL_LOAD', desc: 'button.cancelLoad' },
        ]);
        expect(getTableActions({ name: 'NOT_STARTED_AT_RISK' }, 5, [5000000, 5000001], 2)).toEqual([
            { name: 'CANCEL_LOAD', desc: 'button.cancelLoad' },
        ]);
    });
    it('should not return cancel load for [planning, processing, ready to start] tab and feature flag is disabled', () => {
        expect(getTableActions({ name: 'AWAITING_FINALIZATION' }, 5, [5000000, 5000001], 0)).toEqual([
            { name: 'APPROVE_LOAD', desc: 'button.approveLoad' },
        ]);
        expect(getTableActions({ name: 'NEEDS_ATTENTION' }, 5, [5000000, 5000001], 1)).toEqual([]);
        expect(getTableActions({ name: 'NOT_STARTED_AT_RISK' }, 5, [5000000, 5000001], 2)).toEqual([]);
    });
});

describe('getCommentsConfigurations tests', () => {
    it('should return correct config for enableAddMultiComment', () => {
        expect(getCommentsConfigurations({ enableAddMultiComment: true }, false)).toEqual({
            hideSearchFilter: true,
            filterByCommentType: true,
            enableCommentTypeDropDown: true,
            hideEntityType: true,
            enableCommentRestriction: true,
            hideFilterComponent: false,
            hideCommentList: false,
        });
    });
    it('should return correct config for enableAddMultiComment and multi load select', () => {
        expect(getCommentsConfigurations({ enableAddMultiComment: true }, true)).toEqual({
            hideSearchFilter: true,
            filterByCommentType: true,
            enableCommentTypeDropDown: true,
            hideEntityType: true,
            enableCommentRestriction: true,
            hideFilterComponent: true,
            hideCommentList: true,
        });
    });
    it('should return correct config for no feature flag', () => {
        expect(getCommentsConfigurations({ enableAddMultiComment: false }, true)).toEqual({});
    });
});

describe('formatCancelTripActionRequest', () => {
    it('should format correct cancel request payload', () => {
        expect(formatCancelTripActionRequest([10000, 20000, 30000], 'DC - CANCEL')).toEqual({
            payload: {
                ids: [10000, 20000, 30000],
                reason: 'DC - CANCEL',
                status: 'CANCELLED',
            },
        });
    });
});

describe('formatErrorListFromResponse', () => {
    it('should format error list from response', () => {
        expect(
            formatErrorListFromResponse([
                { description: 'No item found', field: 10000 },
                { description: 'Exception when processing request', field: 20000 },
            ]),
        ).toEqual([
            { planId: 10000, errMessage: 'No item found' },
            { planId: 20000, errMessage: 'Exception when processing request' },
        ]);
    });
    it('should return empty list if invalid response', () => {
        expect(formatErrorListFromResponse(null)).toEqual([]);
    });
});
