import {
    getCancelLoadResponse,
    getCancelLoadAPIParams,
    getCancelLoadError,
    getCancelLoadReqPayload,
} from '../CancelLoadServiceModel';
import { mockApiParams, mockApiParamsResult } from './mocks/CancelLoadServiceModel.mock';

describe('CancelLoadServiceModel', () => {
    const translations = {
        'msg.cancelLoad.fail': 'Cancel load failed',
    };

    const trans = jest.fn((str) => translations[str] || str);
    it('should return isSuccess if response status is OK', () => {
        expect(
            getCancelLoadResponse({
                response: {
                    status: 'OK',
                },
                trans: trans,
            }),
        ).toEqual({ isSuccess: true });
    });

    it('should return error list if response status is FAIL', () => {
        expect(
            getCancelLoadResponse({
                response: {
                    status: 'FAIL',
                    errors: [
                        {
                            code: 'ITEM_NOT_FOUND',
                            field: '500008437',
                            description: 'No item found',
                            info: 'STRIDE_API_0003',
                            severity: 'ERROR',
                            category: 'REQUEST',
                            causes: [],
                        },
                    ],
                },
                trans: trans,
            }),
        ).toEqual({
            errorList: [
                {
                    errMessage: 'No item found',
                    planId: '500008437',
                },
            ],
            errorMessage: 'Cancel load failed',
        });
    });
    it('should return error list if response error', () => {
        expect(
            getCancelLoadError({
                error: {
                    errors: [
                        {
                            errorIdentifiers: {
                                details: {
                                    errors: [
                                        {
                                            code: 'ITEM_NOT_FOUND',
                                            field: '500008437',
                                            description: 'No item found',
                                            info: 'STRIDE_API_0003',
                                            severity: 'ERROR',
                                            category: 'REQUEST',
                                            causes: [],
                                        },
                                    ],
                                },
                            },
                        },
                    ],
                },
                trans: trans,
            }),
        ).toEqual({
            errorList: [
                {
                    errMessage: 'No item found',
                    planId: '500008437',
                },
            ],
            errorMessage: 'Cancel load failed',
        });
    });
    it('should return payload for cancel load request', () => {
        expect(
            getCancelLoadReqPayload({
                request: {
                    checkedRows: [1000, 2000],
                    reasonCode: 'DC',
                },
            }),
        ).toEqual({
            payload: {
                ids: [1000, 2000],
                reason: 'DC',
                status: 'CANCELLED',
            },
        });
    });
    it('should return valid pApiParams and pConfigs', () => {
        const result = getCancelLoadAPIParams(mockApiParams);
        expect(JSON.stringify(result)).toEqual(JSON.stringify(mockApiParamsResult));
    });
});
