import { getPlanCategoryTQ, PlanCategories, getShadowModeExistsQuery } from '@walmart/stride-ui-commons';
import PhaseTypesEnum from '../../enums/PhaseTypesEnum';
import PlanStatusEnum from '../../PlanStatusEnum';
import { getPlanTableSearchRequestPayload } from '../PlanSearchMappers';
import { transformedConfigResponseMockUS } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import { getElasticRequestQuery, searchAggregatesElasticQueryAll } from '../ElasticQueriesUS';
import {
    planningAggQuery,
    processingAggQuery,
    readyToStartAggQuery,
    inTransitAggQuery,
    deliveredAggQuery,
} from './mocks/mocks/ElasticQueriesUSMock.mock';
import TripSharedService from '../../../service/TripSharedService';

describe('getPlanTableSearchRequestPayload', () => {
    const queryState = {
        page: 1,
        sortField: 'PLAN_CREATED_TIME',
        sortMode: 'DESC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
    };

    const sampleProfile = {
        key: 1648203904009,
        name: 'Both Inbound and Outboud',
        preferences: [
            {
                parameter: 'DC',
                values: [
                    {
                        field: 'id',
                        value: '6773',
                    },
                ],
                attributes: [
                    {
                        field: 'DIRECTION',
                        value: 'BOTH',
                    },
                ],
            },
        ],
        editMode: false,
    };

    it('should return proper request payload based on the active tab index', () => {
        expect(getPlanTableSearchRequestPayload({ ...queryState }, 'ca').payload).toEqual(
            expect.objectContaining({
                isApproved: false,
                status: [{ planType: 'LOAD_PLAN_TYPE', status: 'PLANNED' }],
            }),
        );

        expect(
            getPlanTableSearchRequestPayload({ ...queryState, activeTabIndex: PhaseTypesEnum.PROCESSING.index }, 'ca')
                .payload,
        ).toEqual(
            expect.objectContaining({
                isApproved: true,
                status: [
                    { planType: 'LOAD_PLAN_TYPE', status: 'PLANNED' },
                    { planType: 'LOAD_PLAN_TYPE', status: 'TENDERED' },
                    { planType: 'LOAD_PLAN_TYPE', status: 'TENDER_REJECTED' },
                    { planType: 'LOAD_PLAN_TYPE', status: 'TENDER_TIMEOUT' },
                    { planType: 'LOAD_PLAN_TYPE', status: 'NEED_ATTENTION' },
                    { planType: 'LOAD_PLAN_TYPE', status: 'TENDER_CANCELED' },
                ],
            }),
        );

        expect(
            getPlanTableSearchRequestPayload(
                { ...queryState, activeTabIndex: PhaseTypesEnum.READY_TO_START.index },
                'ca',
            ).payload,
        ).toEqual(
            expect.objectContaining({
                status: [{ planType: 'LOAD_PLAN_TYPE', status: 'TENDER_ACCEPTED' }],
            }),
        );

        expect(
            getPlanTableSearchRequestPayload({ ...queryState, activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index }, 'ca')
                .payload,
        ).toEqual(
            expect.objectContaining({
                status: [{ planType: 'LOAD_PLAN_TYPE', status: 'IN_TRANSIT' }],
            }),
        );
    });

    it('should return user selected origin and destination values if profile is not present', () => {
        expect(
            getPlanTableSearchRequestPayload(
                { ...queryState, filter: { originCity: 'Detroit', destinationCity: 'Toronto' } },
                'ca',
            ).payload,
        ).toEqual(
            expect.objectContaining({
                origins: [{ city: 'Detroit' }],
                destinations: [{ city: 'Toronto' }],
            }),
        );
    });

    it('should return array of locations with all properties when locationTypes are selected', () => {
        expect(
            getPlanTableSearchRequestPayload(
                {
                    ...queryState,
                    filter: {
                        originCity: 'Detroit',
                        destinationCity: 'Toronto',
                        originType: ['DC', 'CP'],
                        destinationType: ['DC', 'CP'],
                    },
                },
                'ca',
            ).payload,
        ).toEqual(
            expect.objectContaining({
                origins: [
                    { locationType: 'DC', city: 'Detroit' },
                    { locationType: 'CP', city: 'Detroit' },
                ],
                destinations: [
                    { locationType: 'DC', city: 'Toronto' },
                    { locationType: 'CP', city: 'Toronto' },
                ],
            }),
        );
    });

    it('should return profile provided origin and destination values if profile is not present', () => {
        expect(
            getPlanTableSearchRequestPayload(
                {
                    ...queryState,
                    filter: { originCity: 'Detroit', destinationCity: 'Toronto' },
                    profile: sampleProfile,
                },
                'ca',
            ).payload,
        ).toEqual(
            expect.objectContaining({
                origins: [{ locationId: '6773', locationType: 'DC' }],
                destinations: [{ locationId: '6773', locationType: 'DC' }],
            }),
        );
    });

    it('should return the status with selected status in the form of request payload required', () => {
        expect(
            getPlanTableSearchRequestPayload(
                {
                    ...queryState,
                    activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
                    filter: { status: ['STARTED', 'EARLY', 'ONTIME', 'LATE'] },
                },
                'ca',
            ).payload,
        ).toEqual(
            expect.objectContaining({
                status: [
                    {
                        planType: 'LOAD_PLAN_TYPE',
                        status: PlanStatusEnum.IN_TRANSIT_STARTED.name,
                    },
                    {
                        planType: 'LOAD_PLAN_TYPE',
                        status: PlanStatusEnum.IN_TRANSIT_EARLY.name,
                    },
                    {
                        planType: 'LOAD_PLAN_TYPE',
                        status: PlanStatusEnum.IN_TRANSIT_ON_TIME.name,
                    },
                    {
                        planType: 'LOAD_PLAN_TYPE',
                        status: PlanStatusEnum.IN_TRANSIT_LATE.name,
                    },
                ],
            }),
        );
    });

    it('should return provided origin and destination location id', () => {
        expect(
            getPlanTableSearchRequestPayload(
                { ...queryState, filter: { originLocId: '6773', destinationLocId: '6774' } },
                'ca',
            ).payload,
        ).toEqual(
            expect.objectContaining({
                origins: [{ locationId: '6773' }],
                destinations: [{ locationId: '6774' }],
            }),
        );
    });
    it('should return calculateSearchCount if feature flag is true', () => {
        expect(
            getPlanTableSearchRequestPayload(
                { ...queryState, filter: { originLocId: '6773', destinationLocId: '6774' } },
                'ca',
                null,
                { showTotalCount: true },
            ).payload,
        ).toEqual(
            expect.objectContaining({
                calculateSearchesResultCount: true,
            }),
        );
    });
    it('should not return calculateSearchCount if feature flag is true', () => {
        expect(
            getPlanTableSearchRequestPayload(
                { ...queryState, filter: { originLocId: '6773', destinationLocId: '6774' } },
                'ca',
                null,
                { showTotalCount: false },
            ).payload,
        ).toEqual(
            expect.not.objectContaining({
                calculateSearchesResultCount: true,
            }),
        );
    });
    it('should return isApproved if fetchUnapprovedPlansInPlanning feature flag is true', () => {
        expect(
            getPlanTableSearchRequestPayload(
                { ...queryState, filter: { originLocId: '6773', destinationLocId: '6774' } },
                'cl',
                null,
                { fetchUnapprovedPlansInPlanning: true },
            ).payload,
        ).toEqual(
            expect.objectContaining({
                isApproved: false,
            }),
        );
    });
    it('should not return isApproved if fetchUnapprovedPlansInPlanning feature flag is false', () => {
        expect(
            getPlanTableSearchRequestPayload(
                { ...queryState, filter: { originLocId: '6773', destinationLocId: '6774' } },
                'cl',
                null,
                { fetchUnapprovedPlansInPlanning: false },
            ).payload,
        ).toEqual(
            expect.not.objectContaining({
                isApproved: false,
            }),
        );
    });
});

describe('getPlanTableSearchRequestPayload - us market - non Dray external users', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'TRIP',
    };
    const cmsConfig = transformedConfigResponseMockUS;

    it('should return proper elastic query request payload - Planning tab - enableDrayExtUserPerm false', () => {
        const planningQuery = getPlanTableSearchRequestPayload(
            { ...queryState, activeTabIndex: PhaseTypesEnum.PLANNING.index },
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(queryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(queryState, cmsConfig, 'us').toJSON();

        expect(planningQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - Planning tab - enableDrayExtUserPerm true', () => {
        const planningQuery = getPlanTableSearchRequestPayload(
            { ...queryState, activeTabIndex: PhaseTypesEnum.PLANNING.index },
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(queryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(queryState, cmsConfig, 'us').toJSON();

        expect(planningQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - processing tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - processing tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - ready to start tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - ready to start tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - intransit tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - intransit tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - delivered tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - delivered tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: true },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
});

describe('getPlanTableSearchRequestPayload - us market - Dray external users', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'TRIP',
    };
    const cmsConfig = transformedConfigResponseMockUS;

    it('should return proper elastic query request payload - Planning tab - enableDrayExtUserPerm false', () => {
        const planningQuery = getPlanTableSearchRequestPayload(
            { ...queryState, activeTabIndex: PhaseTypesEnum.PLANNING.index },
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(queryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(queryState, cmsConfig, 'us').toJSON();

        expect(planningQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - Planning tab - enableDrayExtUserPerm true', () => {
        const planningQuery = getPlanTableSearchRequestPayload(
            { ...queryState, activeTabIndex: PhaseTypesEnum.PLANNING.index },
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(queryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(queryState, cmsConfig, 'us').toJSON();

        expect(planningQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - processing tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - processing tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - ready to start tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - ready to start tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - intransit tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - intransit tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - delivered tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - delivered tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
});
describe('getPlanTableSearchRequestPayload - us market - usePlanCategoriesFromCommons flag true', () => {
    beforeEach(() => {
        jest.spyOn(TripSharedService, 'getFeatureFlags').mockReturnValue({
            showTimeHorizonV2: true,
            usePlanCategoriesFromCommons: true,
        });
    });
    afterEach(() => {
        jest.clearAllMocks();
    });
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'TRIP',
    };
    const cmsConfig = transformedConfigResponseMockUS;

    it('should return proper elastic query request payload - Planning tab', () => {
        const planningQuery = getPlanTableSearchRequestPayload(
            { ...queryState, activeTabIndex: PhaseTypesEnum.PLANNING.index },
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(queryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(queryState, cmsConfig, 'us').toJSON();

        expect(planningQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - processing tab', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - ready to start tab', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - intransit tab', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - delivered tab', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: dataQuery,
            },
            aggrQuery: {
                searchQuery: aggrQuery,
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
});
describe('searchAggregatesElasticQueryAll - us market - usePlanCategoriesFromCommons flag true', () => {
    beforeEach(() => {
        jest.spyOn(TripSharedService, 'getFeatureFlags').mockReturnValue({
            showTimeHorizonV2: true,
            usePlanCategoriesFromCommons: true,
        });
    });
    afterEach(() => {
        jest.clearAllMocks();
    });
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'TRIP',
    };
    const cmsConfig = transformedConfigResponseMockUS;

    it('should return correct agg query - Planning tab', () => {
        const aggrQuery = searchAggregatesElasticQueryAll(queryState, 'us').toJSON();
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.planning).toEqual(planningAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.processing).toEqual(processingAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart).toEqual(readyToStartAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit).toEqual(inTransitAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.delivered).toEqual(deliveredAggQuery);
    });
    it('should return correct agg query - processing tab', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        };
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.planning).toEqual(planningAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.processing).toEqual(processingAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart).toEqual(readyToStartAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit).toEqual(inTransitAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.delivered).toEqual(deliveredAggQuery);
    });
    it('should return correct agg query - ready to start tab', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        };
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.planning).toEqual(planningAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.processing).toEqual(processingAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart).toEqual(readyToStartAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit).toEqual(inTransitAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.delivered).toEqual(deliveredAggQuery);
    });
    it('should return correct agg query - intransit tab', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        };
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.planning).toEqual(planningAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.processing).toEqual(processingAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart).toEqual(readyToStartAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit).toEqual(inTransitAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.delivered).toEqual(deliveredAggQuery);
    });
    it('should return correct agg query - delivered tab', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        };
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.planning).toEqual(planningAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.processing).toEqual(processingAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart).toEqual(readyToStartAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit).toEqual(inTransitAggQuery);
        expect(aggrQuery?.aggs?.tssAggregate?.filters?.filters?.delivered).toEqual(deliveredAggQuery);
    });
});
describe('getPlanTableSearchRequestPayload - us market - filterShadowModeEntities flag true', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'TRIP',
    };
    const cmsConfig = transformedConfigResponseMockUS;

    it('should return proper elastic query request payload - Planning tab - enableDrayExtUserPerm false', () => {
        const planningQuery = getPlanTableSearchRequestPayload(
            { ...queryState, activeTabIndex: PhaseTypesEnum.PLANNING.index },
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(queryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(queryState, cmsConfig, 'us').toJSON();

        expect(planningQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - Planning tab - enableDrayExtUserPerm true', () => {
        const planningQuery = getPlanTableSearchRequestPayload(
            { ...queryState, activeTabIndex: PhaseTypesEnum.PLANNING.index },
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(queryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(queryState, cmsConfig, 'us').toJSON();

        expect(planningQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - processing tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - processing tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        };
        const processingQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(processingQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - ready to start tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        };
        const readyToStartQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(readyToStartQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - ready to start tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        };
        const readyToStartQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(readyToStartQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - intransit tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        };
        const inTransitQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(inTransitQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - intransit tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        };
        const inTransitQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(inTransitQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - delivered tab - enableDrayExtUserPerm false', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        };
        const deliveredQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: false, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(deliveredQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
    it('should return proper elastic query request payload - delivered tab - enableDrayExtUserPerm true', () => {
        const updatedQueryState = {
            ...queryState,
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        };
        const deliveredQuery = getPlanTableSearchRequestPayload(
            updatedQueryState,
            'us',
            cmsConfig,
            { enableDrayExtUserPerm: true, filterShadowModeEntities: true },
            { canAccessNonDrayLoads: false },
        );
        const aggrQuery = searchAggregatesElasticQueryAll(updatedQueryState, 'us').toJSON();
        const dataQuery = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us').toJSON();

        expect(deliveredQuery).toEqual({
            dataQuery: {
                responseGroup: 'TRANS.EP_PLAN.FULL',
                searchQuery: {
                    ...dataQuery,
                    post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                    query: {
                        bool: {
                            ...dataQuery?.query?.bool,
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
            },
            aggrQuery: {
                searchQuery: {
                    ...aggrQuery,
                    query: {
                        bool: {
                            filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                            must_not: getShadowModeExistsQuery(),
                        },
                    },
                },
                isNonVerboseResponse: true,
                index: 'sct_stride_dev',
            },
        });
    });
});
