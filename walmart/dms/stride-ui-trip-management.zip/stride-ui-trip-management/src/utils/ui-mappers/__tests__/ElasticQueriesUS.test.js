import { isNullOrUndefined } from '@walmart/stride-ui-commons';
import { transformedConfigResponseMockUS } from '../../../service/__tests__/mocks/mocks/TripMapper.mock';
import { getElasticRequestQuery, searchAggregatesElasticQueryAll } from '../ElasticQueriesUS';
import {
    deliveredElasticQuery,
    deliveredElasticQueryForGlobalSearch,
    deliveredElasticQueryForGlobalSearchTrip,
    deliveredGroupByIMQuery,
    deliveredGroupByLoadQuery,
    deliveredTabElasticQueryForPriDestinationSorting,
    inTransitElasticQuery,
    inTransitElasticQueryForGlobalSearch,
    inTransitElasticQueryForGlobalSearchTrip,
    intransitGroupByIMQuery,
    intransitGroupByLoadQuery,
    intransitTabElasticQueryForPriDestinationSorting,
    mockQueryState,
    planningGroupByIMQuery,
    planningGroupByLoadQuery,
    planningTabElasticQuery,
    planningTabElasticQueryForGlobalSearch,
    planningTabElasticQueryForGlobalSearchTrip,
    planningTabElasticQueryForPriDestinationSorting,
    processingGroupByIMQuery,
    processingGroupByLoadQuery,
    processingTabElasticQuery,
    processingTabElasticQueryForGlobalSearch,
    processingTabElasticQueryForGlobalSearchTrip,
    processingTabElasticQueryForPriDestinationSorting,
    processingWithExceptions,
    readyToStartElasticQuery,
    readyToStartElasticQueryForGlobalSearch,
    readyToStartElasticQueryForGlobalSearchTrip,
    readyToStartGroupByIMQuery,
    readyToStartGroupByLoadQuery,
    readyToStartTabElasticQueryForPriDestinationSorting,
    deliveredTabElasticQueryForPriDestinationSortingUstrx,
    inTransitElasticQueryForGlobalSearchTripUstrx,
    deliveredElasticQueryForGlobalSearchTripUstrx,
    readyToStartElasticQueryForGlobalSearchTripUstrx,
    processingTabElasticQueryForGlobalSearchTripUstrx,
    planningTabElasticQueryForGlobalSearchUstrx,
    processingTabElasticQueryForGlobalSearchUstrx,
    readyToStartElasticQueryForGlobalSearchUstrx,
    inTransitElasticQueryForGlobalSearchUstrx,
    deliveredElasticQueryForGlobalSearchUstrx,
    planningGroupByLoadQueryUstrx,
    processingGroupByLoadQueryUstrx,
    readyToStartGroupByLoadQueryUstrx,
    intransitGroupByLoadQueryUstrx,
    deliveredGroupByLoadQueryUstrx,
    planningGroupByIMQueryUstrx,
    processingGroupByIMQueryUstrx,
    readyToStartGroupByIMQueryUstrx,
    intransitGroupByIMQueryUstrx,
    deliveredGroupByIMQueryUstrx,
    planningGroupByLoadQueryWithNewLoadTypes,
    processingGroupByLoadQueryWithNewLoadTypes,
    readyToStartGroupByLoadQueryWithNewLoadTypes,
    intransitGroupByLoadQueryWithNewLoadTypes,
    deliveredGroupByLoadQueryWithNewLoadTypes,
} from './mocks/mocks/ElasticQueriesUSMock.mock';
import TripSharedService from '../../../service/TripSharedService';

describe.skip('getElasticRequestQuery - query param checks', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'TRIP',
    };
    const market = 'us';

    const cmsConfig = transformedConfigResponseMockUS;

    it('should return proper elastic query request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningTabElasticQuery);
    });

    it('should return proper elastic query request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingTabElasticQuery);
    });

    it('should return proper elastic query request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartElasticQuery);
    });

    it('should return proper elastic query request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(inTransitElasticQuery);
    });

    it('should return proper elastic query request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredElasticQuery);
    });
});

describe('getElasticRequestQuery for Group by Load - query param checks', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'LOAD',
    };

    const cmsConfig = transformedConfigResponseMockUS;
    const market = 'us';

    it('should return proper elastic query request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningGroupByLoadQuery);
    });

    it('should return proper elastic query request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingGroupByLoadQuery);
    });

    it('should return proper elastic query request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartGroupByLoadQuery);
    });

    it('should return proper elastic query request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(intransitGroupByLoadQuery);
    });

    it('should return proper elastic query request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredGroupByLoadQuery);
    });
});

describe.skip('getElasticRequestQuery for Group by Load - query param checks for USTRX', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'LOAD',
    };

    const cmsConfig = transformedConfigResponseMockUS;
    const market = 'ustrx';

    it('should return proper elastic query request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningGroupByLoadQueryUstrx);
    });

    it('should return proper elastic query request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingGroupByLoadQueryUstrx);
    });

    it('should return proper elastic query request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartGroupByLoadQueryUstrx);
    });

    it('should return proper elastic query request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(intransitGroupByLoadQueryUstrx);
    });

    it('should return proper elastic query request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredGroupByLoadQueryUstrx);
    });
});

describe('getElasticRequestQuery for Group by Intermodal - query param checks', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'INTERMODAL',
    };

    const cmsConfig = transformedConfigResponseMockUS;

    const market = 'us';

    it('should return proper elastic query request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningGroupByIMQuery);
    });

    it('should return proper elastic query request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingGroupByIMQuery);
    });

    it('should return proper elastic query request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartGroupByIMQuery);
    });

    it('should return proper elastic query request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(intransitGroupByIMQuery);
    });

    it('should return proper elastic query request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredGroupByIMQuery);
    });
});

describe.skip('getElasticRequestQuery for Group by Intermodal - query param checks - USTRX', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'INTERMODAL',
    };

    const cmsConfig = transformedConfigResponseMockUS;

    const market = 'ustrx';

    it('should return proper elastic query request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningGroupByIMQueryUstrx);
    });

    it('should return proper elastic query request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingGroupByIMQueryUstrx);
    });

    it('should return proper elastic query request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartGroupByIMQueryUstrx);
    });

    it('should return proper elastic query request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(intransitGroupByIMQueryUstrx);
    });

    it('should return proper elastic query request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredGroupByIMQueryUstrx);
    });
});

describe('getElasticRequestQuery for global search by LOAD - query param checks', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: '12345,12345,12345',
        searchByOption: '1',
    };

    const cmsConfig = transformedConfigResponseMockUS;
    const market = 'us';

    it('should return proper elastic query for global search request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningTabElasticQueryForGlobalSearch);
    });

    it('should return proper elastic query for global search request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingTabElasticQueryForGlobalSearch);
    });

    it('should return proper elastic query for global search request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartElasticQueryForGlobalSearch);
    });

    it('should return proper elastic query for global search request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(inTransitElasticQueryForGlobalSearch);
    });

    it('should return proper elastic query for global search request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredElasticQueryForGlobalSearch);
    });
});

describe.skip('getElasticRequestQuery for global search by LOAD - query param checks for USTRX', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: '12345,12345,12345',
        searchByOption: '1',
    };

    const cmsConfig = transformedConfigResponseMockUS;
    const market = 'ustrx';

    it('should return proper elastic query for global search request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningTabElasticQueryForGlobalSearchUstrx);
    });

    it('should return proper elastic query for global search request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingTabElasticQueryForGlobalSearchUstrx);
    });

    it('should return proper elastic query for global search request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartElasticQueryForGlobalSearchUstrx);
    });

    it('should return proper elastic query for global search request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(inTransitElasticQueryForGlobalSearchUstrx);
    });

    it('should return proper elastic query for global search request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, 'ustrx');
        expect(query?.toJSON()).toEqual(deliveredElasticQueryForGlobalSearchUstrx);
    });
});

describe('getElasticRequestQuery for Global Search by TRIP - query param checks', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: '12345,12345,12345',
        searchByOption: '2',
    };

    const cmsConfig = transformedConfigResponseMockUS;

    const market = 'us';

    it('should return proper elastic query for global search request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningTabElasticQueryForGlobalSearchTrip);
    });

    it('should return proper elastic query for global search request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingTabElasticQueryForGlobalSearchTrip);
    });

    it('should return proper elastic query for global search request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartElasticQueryForGlobalSearchTrip);
    });

    it('should return proper elastic query for global search request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(inTransitElasticQueryForGlobalSearchTrip);
    });

    it('should return proper elastic query for global search request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredElasticQueryForGlobalSearchTrip);
    });
});

describe.skip('getElasticRequestQuery for Global Search by TRIP - query param checks for ustrx', () => {
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: '12345,12345,12345',
        searchByOption: '2',
    };

    const cmsConfig = transformedConfigResponseMockUS;

    const market = 'ustrx';

    it('should return proper elastic query for global search request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningTabElasticQueryForGlobalSearchTrip);
    });

    it('should return proper elastic query for global search request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingTabElasticQueryForGlobalSearchTripUstrx);
    });

    it('should return proper elastic query for global search request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartElasticQueryForGlobalSearchTripUstrx);
    });

    it('should return proper elastic query for global search request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(inTransitElasticQueryForGlobalSearchTripUstrx);
    });

    it('should return proper elastic query for global search request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredElasticQueryForGlobalSearchTripUstrx);
    });
});
describe('elastic search query - time horizon range checks for trip', () => {
    jest.spyOn(TripSharedService, 'getFeatureFlags').mockReturnValue({ showTimeHorizonV2: true });
    const outputQuery = searchAggregatesElasticQueryAll(mockQueryState, 'us').toJSON();

    const timeDiffInDays = (a, b) => {
        const date1 = new Date(a);
        const date2 = new Date(b);

        const diffInMilliSecs = Math.abs(date1.getDate() - date2.getDate());
        return diffInMilliSecs;
    };

    it('should verify time horizon range for - planning tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.planning;
        const dateRangeCondition = tabQuery.bool.should.bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - processing tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.processing;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - ready to start tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart;
        const dateRangeCondition = tabQuery.bool.should[1].bool.filter.find(
            (condition) => !isNullOrUndefined(condition?.range?.ep_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.ep_schedule_max_due_ts.lte,
                dateRangeCondition.range.ep_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - in transit tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit;
        const dateRangeCondition = tabQuery.bool.should[1].bool.filter.find(
            (condition) => !isNullOrUndefined(condition?.range),
        );
        expect(dateRangeCondition).toBeUndefined();
    });
    it('should verify time horizon range for - delivered tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.delivered;
        const dateRangeCondition = tabQuery.bool.should[1].bool.filter.find(
            (condition) => !isNullOrUndefined(condition?.range?.ep_tnt_actual_end_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.ep_tnt_actual_end_ts.lte,
                dateRangeCondition.range.ep_tnt_actual_end_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayCount);
    });
});

describe.skip('elastic search query - time horizon range checks for trip ustrx', () => {
    jest.spyOn(TripSharedService, 'getFeatureFlags').mockReturnValue({ showTimeHorizonV2: true });
    const outputQuery = searchAggregatesElasticQueryAll(mockQueryState, 'ustrx').toJSON();

    const timeDiffInDays = (a, b) => {
        const date1 = new Date(a);
        const date2 = new Date(b);

        const diffInMilliSecs = Math.abs(date1.getDate() - date2.getDate());
        return diffInMilliSecs;
    };

    it('should verify time horizon range for - planning tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.planning;
        const dateRangeCondition = tabQuery.bool.should.bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - processing tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.processing;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - ready to start tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart;
        const dateRangeCondition = tabQuery.bool.should[1].bool.filter.find(
            (condition) => !isNullOrUndefined(condition?.range?.ep_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.ep_schedule_max_due_ts.lte,
                dateRangeCondition.range.ep_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - in transit tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit;
        const dateRangeCondition = tabQuery.bool.should[1].bool.filter.find(
            (condition) => !isNullOrUndefined(condition?.range),
        );
        expect(dateRangeCondition).toBeUndefined();
    });
    it('should verify time horizon range for - delivered tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.delivered;
        const dateRangeCondition = tabQuery.bool.should[1].bool.filter.find(
            (condition) => !isNullOrUndefined(condition?.range?.ep_tnt_actual_end_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.ep_tnt_actual_end_ts.lte,
                dateRangeCondition.range.ep_tnt_actual_end_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayCount);
    });
});
describe('elastic search query - exceptions', () => {
    const mockQuery = {
        ...mockQueryState,
        exceptionType: 'TOTE_EXCHANGE_MUST_SHIP',
    };
    const market = 'us';
    const cmsConfig = transformedConfigResponseMockUS;
    it('should return proper elastic query request payload - Processing tab', () => {
        const processingQueryState = {
            ...mockQuery,
            activeTabIndex: 1,
            timeHorizon: null,
            filter: null,
        };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingWithExceptions);
    });
});

describe('elastic search query - time horizon range checks for load', () => {
    const outputQuery = searchAggregatesElasticQueryAll(mockQueryState, 'us').toJSON();

    const timeDiffInDays = (a, b) => {
        const date1 = new Date(a);
        const date2 = new Date(b);

        const diffInMilliSecs = Math.abs(date1.getDate() - date2.getDate());
        return diffInMilliSecs;
    };

    it('should verify time horizon range for - planning tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.planning;
        const dateRangeCondition = tabQuery.bool.should.bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - processing tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.processing;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - ready to start tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - in transit tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range),
        );
        expect(dateRangeCondition).toBeUndefined();
    });
    it('should verify time horizon range for - delivered tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.delivered;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_actual_delivery_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_actual_delivery_ts.lte,
                dateRangeCondition.range.plan_schedule_actual_delivery_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayCount);
    });
});

describe.skip('elastic search query - time horizon range checks for load for ustrx', () => {
    const outputQuery = searchAggregatesElasticQueryAll(mockQueryState, 'ustrx').toJSON();

    const timeDiffInDays = (a, b) => {
        const date1 = new Date(a);
        const date2 = new Date(b);

        const diffInMilliSecs = Math.abs(date1.getDate() - date2.getDate());
        return diffInMilliSecs;
    };

    it('should verify time horizon range for - planning tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.planning;
        const dateRangeCondition = tabQuery.bool.should.bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - processing tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.processing;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - ready to start tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.readyToStart;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_max_due_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_max_due_ts.lte,
                dateRangeCondition.range.plan_schedule_max_due_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayDiff);
    });
    it('should verify time horizon range for - in transit tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.inTransit;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range),
        );
        expect(dateRangeCondition).toBeUndefined();
    });
    it('should verify time horizon range for - delivered tab', () => {
        const tabQuery = outputQuery?.aggs?.tssAggregate?.filters?.filters?.delivered;
        const dateRangeCondition = tabQuery.bool.should[0].bool.must.find(
            (condition) => !isNullOrUndefined(condition?.range?.plan_schedule_actual_delivery_ts),
        );
        expect(
            timeDiffInDays(
                dateRangeCondition.range.plan_schedule_actual_delivery_ts.lte,
                dateRangeCondition.range.plan_schedule_actual_delivery_ts.gte,
            ),
        ).toEqual(mockQueryState.timeHorizon.dayCount);
    });
});
describe('getElasticRequestQuery - elastic query for primary destination column sorting', () => {
    const queryState = {
        page: 1,
        sortField: 'ep_plans_locations_destination_location_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'TRIP',
    };

    const cmsConfig = transformedConfigResponseMockUS;

    it('should return proper elastic query request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, 'us');
        expect(planningQuery?.toJSON()).toEqual(planningTabElasticQueryForPriDestinationSorting);
    });

    it('should return proper elastic query request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, 'us');
        expect(query?.toJSON()).toEqual(processingTabElasticQueryForPriDestinationSorting);
    });

    it('should return proper elastic query request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us');
        expect(query?.toJSON()).toEqual(readyToStartTabElasticQueryForPriDestinationSorting);
    });

    it('should return proper elastic query request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us');
        expect(query?.toJSON()).toEqual(intransitTabElasticQueryForPriDestinationSorting);
    });

    it('should return proper elastic query request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, 'us');
        expect(query?.toJSON()).toEqual(deliveredTabElasticQueryForPriDestinationSorting);
    });

    it.skip('should return proper elastic query request payload - Delivered tab for ustrx', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, 'ustrx');
        expect(query?.toJSON()).toEqual(deliveredTabElasticQueryForPriDestinationSortingUstrx);
    });
});
describe('getElasticRequestQuery - usePlanCategoriesFromCommons flag true', () => {
    beforeEach(() => {
        jest.spyOn(TripSharedService, 'getFeatureFlags').mockReturnValue({
            showTimeHorizonV2: true,
            usePlanCategoriesFromCommons: true,
        });
    });
    afterEach(() => {
        jest.clearAllMocks();
    });
    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'LOAD',
    };

    const cmsConfig = transformedConfigResponseMockUS;
    const market = 'us';

    it('should return proper elastic query for global search request payload - Planning tab', () => {
        const planningQuery = getElasticRequestQuery(queryState, cmsConfig, market);
        expect(planningQuery?.toJSON()).toEqual(planningGroupByLoadQueryWithNewLoadTypes);
    });

    it('should return proper elastic query request payload - Processing tab', () => {
        const processingQueryState = { ...queryState, activeTabIndex: 1 };
        const query = getElasticRequestQuery(processingQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(processingGroupByLoadQueryWithNewLoadTypes);
    });

    it('should return proper elastic query request payload - Ready to start tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 2 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(readyToStartGroupByLoadQueryWithNewLoadTypes);
    });

    it('should return proper elastic query request payload - Intransit tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 3 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(intransitGroupByLoadQueryWithNewLoadTypes);
    });

    it('should return proper elastic query request payload - Delivered tab', () => {
        const updatedQueryState = { ...queryState, activeTabIndex: 4 };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON()).toEqual(deliveredGroupByLoadQueryWithNewLoadTypes);
    });
});

describe('getElasticRequestQuery - sorting', () => {
    const spy = jest.spyOn(TripSharedService, 'getFeatureFlags');

    afterEach(() => {
        jest.clearAllMocks();
    });

    const queryState = {
        page: 1,
        sortField: 'entity_id',
        sortMode: 'ASC',
        multiSortFields: [
            { id: 'ORIGIN_ID', desc: false, sortField: 'ORIGIN_ID' },
            { id: 'DESTINATION_ID', desc: true, sortField: 'DESTINATION_ID' },
        ],
        exceptionType: null,
        filter: {},
        profile: {},
        activeTabIndex: 0,
        timeHorizon: null,
        globalSearchData: null,
        groupBy: 'LOAD',
    };
    const cmsConfig = transformedConfigResponseMockUS;
    const market = 'us';

    it('should use multiSortFields to form sort query when enableMultiSortForSearchTable flag is enabled', () => {
        spy.mockReturnValue({ enableMultiSortForSearchTable: true });

        const updatedQueryState = { ...queryState };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);

        expect(query?.toJSON().sort).toEqual([
            {
                ORIGIN_ID: 'asc',
            },
            {
                DESTINATION_ID: 'desc',
            },
        ]);
    });

    it('should use sortField and sortMode to form sort query when enableMultiSortForSearchTable flag is disabled', () => {
        spy.mockReturnValue({ enableMultiSortForSearchTable: false });

        const updatedQueryState = { ...queryState };
        const query = getElasticRequestQuery(updatedQueryState, cmsConfig, market);
        expect(query?.toJSON().sort).toEqual([
            {
                entity_id: 'asc',
            },
        ]);
    });
});
