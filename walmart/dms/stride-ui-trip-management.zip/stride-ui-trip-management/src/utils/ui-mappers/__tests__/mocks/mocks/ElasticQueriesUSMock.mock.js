export const planningTabElasticQuery = {
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['PLANNED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [false],
                            },
                        },
                    ],
                    must_not: {
                        exists: {
                            field: 'plan_identifiers_parent_plan_id_v1',
                        },
                    },
                },
            },
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const processingTabElasticQuery = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_ACCEPTED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        filter: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    ep_execution_plan_category: ['STR'],
                                },
                            },
                            {
                                terms: {
                                    ep_status: ['CREATED', 'DRIVER_ASSIGNED'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['EXECUTION_PLAN'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const readyToStartElasticQuery = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        filter: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    ep_execution_plan_category: ['STR'],
                                },
                            },
                            {
                                terms: {
                                    ep_status: ['DISPATCHED'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['EXECUTION_PLAN'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const inTransitElasticQuery = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['IN_TRANSIT'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        filter: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    ep_execution_plan_category: ['STR'],
                                },
                            },
                            {
                                terms: {
                                    ep_status: ['IN_TRANSIT'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['EXECUTION_PLAN'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const deliveredElasticQuery = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['DELIVERED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        filter: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    ep_execution_plan_category: ['STR'],
                                },
                            },
                            {
                                terms: {
                                    ep_status: ['DELIVERED'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['EXECUTION_PLAN'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const mockQueryState = {
    page: 1,
    sortField: 'entity_id',
    sortMode: 'ASC',
    exceptionType: null,
    filter: {
        loadId: '',
        toId: '',
        fromDate: '',
        tillDate: '',
        after: '',
        before: '',
        on: '',
        dateType: '',
        periodType: '',
        loadType: [],
        planType: '',
        status: [],
        carrierId: '',
        scacCode: '',
        coordinatorBoard: '',
        serviceTerritory: '',
        driverId: '',
        trailerId: '',
        originType: '',
        originId: '',
        originCity: '',
        originState: '',
        originCountry: '',
        originZipCode: '',
        destinationType: '',
        destinationId: '',
        destinationCity: '',
        destinationState: '',
        destinationCountry: '',
        destinationZipCode: '',
    },
    profile: {},
    activeTabIndex: 0,
    timeHorizon: {
        name: 'Past: 7 days - Future: 7 days',
        preferences: 'Feb 26, 2024 - Mar 11, 2024',
        dayCount: 2,
        dayDiff: 15,
        dayCountDel: ['2024-03-02T13:37:30.361-08:00', '2024-03-04T13:37:30.361-08:00'],
        dateType: 'PLANNED_END_DATE',
    },
    globalSearchData: null,
    groupBy: 'TRIP',
};

export const mockCmsConfig = {
    rowsPerPage: 15,
    debounceTime: 500,
    country: {
        currency: ['USD'],
        id: '44',
        iso2: 'CA',
        iso3: 'CA',
        name: 'Canada',
    },
    UOM: {
        width: 'M',
        height: 'M',
        length: 'M',
        weight: 'KG',
        pallet: '',
        volume: 'CU M3',
        distance: 'mi',
        cube: 'M3',
        duration: 'HH:MM',
        currency: 'CLP',
        cases: 'EA',
        transitTime: 'MJ',
    },
    paginationSize: 100,
    tabStatus: {
        planning: ['PLANNED'],
        processingLoad: [
            'PLANNED',
            'TENDERED',
            'TENDER_ACCEPTED',
            'TENDER_CANCELED',
            'TENDER_REJECTED',
            'NEED_ATTENTION',
        ],
        processingLoadDray: ['PLANNED', 'TENDERED', 'TENDER_CANCELED', 'TENDER_REJECTED', 'NEED_ATTENTION'],
        processingTrip: ['CREATED', 'DRIVER_ASSIGNED'],
        reactToStart: ['DISPATCHED'],
        reactToStartLoad: ['TENDER_ACCEPTED'],
        inTransit: ['IN_TRANSIT'],
        delivered: ['DELIVERED'],
    },
    planAggsIndex: {
        dev: 'sct_stride_dev',
        qa: 'sct_dev_2',
        stg: 'sct_stride_dev_3',
        pre: '',
        prod: 'sct_stride',
        localhost: 'sct_stride_dev',
    },
    sortFields: {
        PLAN_ID: 'entity_id',
        PLAN_TYPE: null,
        ORIGIN_LOCATION_ID: 'locations_origin_location_id',
        DISTANCE: null,
        DESTINATION_LOCATION_ID: 'locations_destination_location_id',
        PLANNED_START: 'schedule_min_pickup_ts',
        ACTUAL_START: null,
        CREATED_DATE: 'provenance_created_ts',
        DURATION: null,
        NEXT_STOP: null,
        NEXT_STOP_REMAINING: null,
        CARRIER_ID: null,
        SERVICE_TERRITORY: null,
        TRAILER_ID: null,
        DRIVER_ID: null,
        BILLS_BY_TIME: null,
        PICKUP_STOPS: null,
        DELIVERY_STOPS: null,
    },
    defaultOlsenTimezoneId: null,
};

export const planningTabElasticQueryForGlobalSearch = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['PLANNED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [false],
                            },
                        },
                        {
                            terms: {
                                entity_id: ['12345', '12345', '12345'],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const processingTabElasticQueryForGlobalSearch = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                terms: {
                                    entity_id: ['12345', '12345', '12345'],
                                },
                            },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                terms: {
                                    entity_id: ['12345', '12345', '12345'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const readyToStartElasticQueryForGlobalSearch = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                terms: {
                                    entity_id: ['12345', '12345', '12345'],
                                },
                            },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                exists: {
                                    field: 'plan_identifiers_parent_plan_id_v1',
                                },
                            },
                            {
                                terms: {
                                    entity_id: ['12345', '12345', '12345'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const inTransitElasticQueryForGlobalSearch = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['IN_TRANSIT'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                        {
                            terms: {
                                entity_id: ['12345', '12345', '12345'],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const deliveredElasticQueryForGlobalSearch = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['DELIVERED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                        {
                            terms: {
                                entity_id: ['12345', '12345', '12345'],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const planningGroupByLoadQuery = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'STR',
                                        'PLT',
                                        'CLM',
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['PLANNED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [false],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['IM_RAIL', 'IM_DRAY'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['PLANNED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [false],
                                },
                            },
                            {
                                exists: {
                                    field: 'plan_identifiers_parent_plan_id_v1',
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const processingGroupByLoadQuery = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                exists: {
                                    field: 'plan_identifiers_parent_plan_id_v1',
                                },
                            },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_ACCEPTED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const readyToStartGroupByLoadQuery = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                exists: {
                                    field: 'plan_identifiers_parent_plan_id_v1',
                                },
                            },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US_US'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const intransitGroupByLoadQuery = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['IN_TRANSIT'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const deliveredGroupByLoadQuery = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['DELIVERED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const planningGroupByIMQuery = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['PLANNED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [false],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const processingGroupByIMQuery = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: [
                                    'PLANNED',
                                    'TENDERED',
                                    'TENDER_CANCELED',
                                    'TENDER_REJECTED',
                                    'NEED_ATTENTION',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const readyToStartGroupByIMQuery = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['TENDER_ACCEPTED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const intransitGroupByIMQuery = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['IN_TRANSIT'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const deliveredGroupByIMQuery = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['DELIVERED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const planningTabElasticQueryForGlobalSearchTrip = {
    from: 0,
    query: {
        match_none: {},
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const processingTabElasticQueryForGlobalSearchTrip = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    filter: [
                        {
                            terms: {
                                tenant_id: ['US_US'],
                            },
                        },
                        {
                            terms: {
                                ep_execution_plan_category: ['STR'],
                            },
                        },
                        {
                            terms: {
                                ep_status: ['CREATED', 'DRIVER_ASSIGNED'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['EXECUTION_PLAN'],
                            },
                        },
                        {
                            terms: {
                                entity_id: ['12345', '12345', '12345'],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const planningTabElasticQueryUstrx = {
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['PLANNED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [false],
                            },
                        },
                    ],
                    must_not: {
                        exists: {
                            field: 'plan_identifiers_parent_plan_id_v1',
                        },
                    },
                },
            },
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const processingTabElasticQueryUstrx = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_ACCEPTED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        filter: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    ep_execution_plan_category: ['STR'],
                                },
                            },
                            {
                                terms: {
                                    ep_status: ['CREATED', 'DRIVER_ASSIGNED'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['EXECUTION_PLAN'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const readyToStartElasticQueryUstrx = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        filter: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    ep_execution_plan_category: ['STR'],
                                },
                            },
                            {
                                terms: {
                                    ep_status: ['DISPATCHED'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['EXECUTION_PLAN'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const inTransitElasticQueryUstrx = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['IN_TRANSIT'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        filter: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    ep_execution_plan_category: ['STR'],
                                },
                            },
                            {
                                terms: {
                                    ep_status: ['IN_TRANSIT'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['EXECUTION_PLAN'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const deliveredElasticQueryUstrx = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['DELIVERED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        filter: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    ep_execution_plan_category: ['STR'],
                                },
                            },
                            {
                                terms: {
                                    ep_status: ['DELIVERED'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['EXECUTION_PLAN'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const planningTabElasticQueryForGlobalSearchUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US.TRX'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['PLANNED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [false],
                            },
                        },
                        {
                            terms: {
                                entity_id: ['12345', '12345', '12345'],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const processingTabElasticQueryForGlobalSearchUstrx = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                terms: {
                                    entity_id: ['12345', '12345', '12345'],
                                },
                            },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                terms: {
                                    entity_id: ['12345', '12345', '12345'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const readyToStartElasticQueryForGlobalSearchUstrx = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                terms: {
                                    entity_id: ['12345', '12345', '12345'],
                                },
                            },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                exists: {
                                    field: 'plan_identifiers_parent_plan_id_v1',
                                },
                            },
                            {
                                terms: {
                                    entity_id: ['12345', '12345', '12345'],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const inTransitElasticQueryForGlobalSearchUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['IN_TRANSIT'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                        {
                            terms: {
                                entity_id: ['12345', '12345', '12345'],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const deliveredElasticQueryForGlobalSearchUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['DELIVERED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                        {
                            terms: {
                                entity_id: ['12345', '12345', '12345'],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const planningGroupByLoadQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'STR',
                                        'PLT',
                                        'CLM',
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['PLANNED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [false],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['IM_RAIL', 'IM_DRAY'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['PLANNED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [false],
                                },
                            },
                            {
                                exists: {
                                    field: 'plan_identifiers_parent_plan_id_v1',
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const processingGroupByLoadQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                exists: {
                                    field: 'plan_identifiers_parent_plan_id_v1',
                                },
                            },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_ACCEPTED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                        must_not: {
                            exists: {
                                field: 'plan_identifiers_parent_plan_id_v1',
                            },
                        },
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const readyToStartGroupByLoadQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: ['STR', 'PLT', 'CLM'],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                            {
                                exists: {
                                    field: 'plan_identifiers_parent_plan_id_v1',
                                },
                            },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            {
                                terms: {
                                    tenant_id: ['US.TRX'],
                                },
                            },
                            {
                                terms: {
                                    sub_entity_type: ['PLAN'],
                                },
                            },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: ['TENDER_ACCEPTED'],
                                },
                            },
                            {
                                terms: {
                                    plan_is_approved_v1: [true],
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const intransitGroupByLoadQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['IN_TRANSIT'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const deliveredGroupByLoadQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['DELIVERED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const planningGroupByIMQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['PLANNED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [false],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const processingGroupByIMQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: [
                                    'PLANNED',
                                    'TENDERED',
                                    'TENDER_CANCELED',
                                    'TENDER_REJECTED',
                                    'NEED_ATTENTION',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const readyToStartGroupByIMQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['TENDER_ACCEPTED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const intransitGroupByIMQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['IN_TRANSIT'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const deliveredGroupByIMQueryUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['PLAN'],
                            },
                        },
                        {
                            terms: {
                                plan_category: ['IM'],
                            },
                        },
                        {
                            terms: {
                                plan_status: ['DELIVERED'],
                            },
                        },
                        {
                            terms: {
                                plan_is_approved_v1: [true],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const planningTabElasticQueryForGlobalSearchTripUstrx = {
    from: 0,
    query: {
        match_none: {},
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};
export const processingTabElasticQueryForGlobalSearchTripUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    filter: [
                        {
                            terms: {
                                tenant_id: ['US.TRX'],
                            },
                        },
                        {
                            terms: {
                                ep_execution_plan_category: ['STR'],
                            },
                        },
                        {
                            terms: {
                                ep_status: ['CREATED', 'DRIVER_ASSIGNED'],
                            },
                        },
                        {
                            terms: {
                                sub_entity_type: ['EXECUTION_PLAN'],
                            },
                        },
                        {
                            terms: {
                                entity_id: ['12345', '12345', '12345'],
                            },
                        },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [
        {
            entity_id: 'asc',
        },
    ],
};

export const readyToStartElasticQueryForGlobalSearchTripUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US.TRX'] } },
                        { terms: { ep_execution_plan_category: ['STR'] } },
                        { terms: { ep_status: ['DISPATCHED'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                        { terms: { entity_id: ['12345', '12345', '12345'] } },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const deliveredTabElasticQueryForPriDestinationSortingUstrx = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US.TRX'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            { terms: { plan_status: ['DELIVERED'] } },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        filter: [
                            { terms: { sub_entity_type: ['EXECUTION_PLAN_PLANS'] } },
                            { term: { ep_plans_plan_sequence: 1 } },
                            { term: { is_active: true } },
                            {
                                has_parent: {
                                    query: {
                                        bool: {
                                            should: {
                                                bool: {
                                                    filter: [
                                                        { terms: { tenant_id: ['US.TRX'] } },
                                                        { terms: { ep_execution_plan_category: ['STR'] } },
                                                        { terms: { ep_status: ['DELIVERED'] } },
                                                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                                                    ],
                                                },
                                            },
                                        },
                                    },
                                    parent_type: 'STRIDE_EXECUTION_PLAN',
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [{ ep_plans_locations_destination_location_id: 'asc' }],
};

export const intransitTabElasticQueryForPriDestinationSorting = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            { terms: { plan_status: ['IN_TRANSIT'] } },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        filter: [
                            { terms: { sub_entity_type: ['EXECUTION_PLAN_PLANS'] } },
                            { term: { ep_plans_plan_sequence: 1 } },
                            { term: { is_active: true } },
                            {
                                has_parent: {
                                    query: {
                                        bool: {
                                            should: {
                                                bool: {
                                                    filter: [
                                                        { terms: { tenant_id: ['US_US'] } },
                                                        { terms: { ep_execution_plan_category: ['STR'] } },
                                                        { terms: { ep_status: ['IN_TRANSIT'] } },
                                                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                                                    ],
                                                },
                                            },
                                        },
                                    },
                                    parent_type: 'STRIDE_EXECUTION_PLAN',
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [{ ep_plans_locations_destination_location_id: 'asc' }],
};

export const deliveredTabElasticQueryForPriDestinationSorting = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            { terms: { plan_status: ['DELIVERED'] } },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        filter: [
                            { terms: { sub_entity_type: ['EXECUTION_PLAN_PLANS'] } },
                            { term: { ep_plans_plan_sequence: 1 } },
                            { term: { is_active: true } },
                            {
                                has_parent: {
                                    query: {
                                        bool: {
                                            should: {
                                                bool: {
                                                    filter: [
                                                        { terms: { tenant_id: ['US_US'] } },
                                                        { terms: { ep_execution_plan_category: ['STR'] } },
                                                        { terms: { ep_status: ['DELIVERED'] } },
                                                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                                                    ],
                                                },
                                            },
                                        },
                                    },
                                    parent_type: 'STRIDE_EXECUTION_PLAN',
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [{ ep_plans_locations_destination_location_id: 'asc' }],
};

export const readyToStartTabElasticQueryForPriDestinationSorting = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            { terms: { plan_status: ['TENDER_ACCEPTED'] } },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        filter: [
                            { terms: { sub_entity_type: ['EXECUTION_PLAN_PLANS'] } },
                            { term: { ep_plans_plan_sequence: 1 } },
                            { term: { is_active: true } },
                            {
                                has_parent: {
                                    query: {
                                        bool: {
                                            should: {
                                                bool: {
                                                    filter: [
                                                        { terms: { tenant_id: ['US_US'] } },
                                                        { terms: { ep_execution_plan_category: ['STR'] } },
                                                        { terms: { ep_status: ['DISPATCHED'] } },
                                                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                                                    ],
                                                },
                                            },
                                        },
                                    },
                                    parent_type: 'STRIDE_EXECUTION_PLAN',
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [{ ep_plans_locations_destination_location_id: 'asc' }],
};

export const processingTabElasticQueryForPriDestinationSorting = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            { terms: { plan_category: ['STR', 'PLT', 'CLM'] } },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_ACCEPTED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        filter: [
                            { terms: { sub_entity_type: ['EXECUTION_PLAN_PLANS'] } },
                            { term: { ep_plans_plan_sequence: 1 } },
                            { term: { is_active: true } },
                            {
                                has_parent: {
                                    query: {
                                        bool: {
                                            should: {
                                                bool: {
                                                    filter: [
                                                        { terms: { tenant_id: ['US_US'] } },
                                                        { terms: { ep_execution_plan_category: ['STR'] } },
                                                        { terms: { ep_status: ['CREATED', 'DRIVER_ASSIGNED'] } },
                                                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                                                    ],
                                                },
                                            },
                                        },
                                    },
                                    parent_type: 'STRIDE_EXECUTION_PLAN',
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [{ ep_plans_locations_destination_location_id: 'asc' }],
};

export const planningTabElasticQueryForPriDestinationSorting = {
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        { terms: { plan_status: ['PLANNED'] } },
                        { terms: { plan_is_approved_v1: [false] } },
                    ],
                    must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                },
            },
        },
    },
    from: 0,
    size: 100,
    sort: [{ ep_plans_locations_destination_location_id: 'asc' }],
};

export const inTransitElasticQueryForGlobalSearchTripUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US.TRX'] } },
                        { terms: { ep_execution_plan_category: ['STR'] } },
                        { terms: { ep_status: ['IN_TRANSIT'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                        { terms: { entity_id: ['12345', '12345', '12345'] } },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const deliveredElasticQueryForGlobalSearchTrip = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { ep_execution_plan_category: ['STR'] } },
                        { terms: { ep_status: ['DELIVERED'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                        { terms: { entity_id: ['12345', '12345', '12345'] } },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const inTransitElasticQueryForGlobalSearchTrip = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { ep_execution_plan_category: ['STR'] } },
                        { terms: { ep_status: ['IN_TRANSIT'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                        { terms: { entity_id: ['12345', '12345', '12345'] } },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const deliveredElasticQueryForGlobalSearchTripUstrx = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US.TRX'] } },
                        { terms: { ep_execution_plan_category: ['STR'] } },
                        { terms: { ep_status: ['DELIVERED'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                        { terms: { entity_id: ['12345', '12345', '12345'] } },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const readyToStartElasticQueryForGlobalSearchTrip = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { ep_execution_plan_category: ['STR'] } },
                        { terms: { ep_status: ['DISPATCHED'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                        { terms: { entity_id: ['12345', '12345', '12345'] } },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const processingWithExceptions = {
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            { terms: { plan_category: ['STR', 'PLT', 'CLM'] } },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_ACCEPTED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            { terms: { plan_is_approved_v1: [true] } },
                            { terms: { plan_exception_flags: ['TOTE_EXCHANGE_MUST_SHIP'] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            { terms: { plan_is_approved_v1: [true] } },
                            { terms: { plan_exception_flags: ['TOTE_EXCHANGE_MUST_SHIP'] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        filter: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { ep_execution_plan_category: ['STR'] } },
                            { terms: { ep_status: ['CREATED', 'DRIVER_ASSIGNED'] } },
                            { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                            {
                                has_child: {
                                    query: {
                                        bool: {
                                            must: { terms: { ep_plans_exception_flags: ['TOTE_EXCHANGE_MUST_SHIP'] } },
                                        },
                                    },
                                    type: 'EXECUTION_PLAN_PLANS',
                                },
                            },
                        ],
                    },
                },
            ],
        },
    },
    from: 0,
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const planningGroupByLoadQueryWithNewLoadTypes = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'STR',
                                        'PLT',
                                        'CLM',
                                        'RTN',
                                        'BOB',
                                        'DHD',
                                        'BOX',
                                        'STK',
                                        'WMGW',
                                        'GRSTR',
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            { terms: { plan_status: ['PLANNED'] } },
                            { terms: { plan_is_approved_v1: [false] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            { terms: { plan_category: ['IM_RAIL', 'IM_DRAY', 'GRSTR'] } },
                            { terms: { plan_status: ['PLANNED'] } },
                            { terms: { plan_is_approved_v1: [false] } },
                            { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const processingGroupByLoadQueryWithNewLoadTypes = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'STR',
                                        'PLT',
                                        'CLM',
                                        'RTN',
                                        'BOB',
                                        'DHD',
                                        'BOX',
                                        'STK',
                                        'WMGW',
                                        'GRSTR',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            { terms: { plan_is_approved_v1: [true] } },
                            { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'STR',
                                        'PLT',
                                        'CLM',
                                        'RTN',
                                        'BOB',
                                        'DHD',
                                        'BOX',
                                        'STK',
                                        'WMGW',
                                        'GRSTR',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_ACCEPTED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                        must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                    },
                },
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            {
                                terms: {
                                    plan_status: [
                                        'PLANNED',
                                        'TENDERED',
                                        'TENDER_CANCELED',
                                        'TENDER_REJECTED',
                                        'NEED_ATTENTION',
                                    ],
                                },
                            },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const readyToStartGroupByLoadQueryWithNewLoadTypes = {
    from: 0,
    query: {
        bool: {
            should: [
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'STR',
                                        'PLT',
                                        'CLM',
                                        'RTN',
                                        'BOB',
                                        'DHD',
                                        'BOX',
                                        'STK',
                                        'WMGW',
                                        'GRSTR',
                                    ],
                                },
                            },
                            { terms: { plan_status: ['TENDER_ACCEPTED'] } },
                            { terms: { plan_is_approved_v1: [true] } },
                            { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                        ],
                    },
                },
                {
                    bool: {
                        must: [
                            { terms: { tenant_id: ['US_US'] } },
                            { terms: { sub_entity_type: ['PLAN'] } },
                            {
                                terms: {
                                    plan_category: [
                                        'IMP_DRAY',
                                        'IMP_OCEAN',
                                        'OICC',
                                        'IWFS',
                                        'PPD_BKHL',
                                        'IMP_MTDRAY',
                                        'IM',
                                        'IM_RAIL',
                                        'IM_DRAY',
                                    ],
                                },
                            },
                            { terms: { plan_status: ['TENDER_ACCEPTED'] } },
                            { terms: { plan_is_approved_v1: [true] } },
                        ],
                    },
                },
            ],
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const intransitGroupByLoadQueryWithNewLoadTypes = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'RTN',
                                    'BOB',
                                    'DHD',
                                    'BOX',
                                    'STK',
                                    'WMGW',
                                    'GRSTR',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        { terms: { plan_status: ['IN_TRANSIT'] } },
                        { terms: { plan_is_approved_v1: [true] } },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const deliveredGroupByLoadQueryWithNewLoadTypes = {
    from: 0,
    query: {
        bool: {
            should: {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'RTN',
                                    'BOB',
                                    'DHD',
                                    'BOX',
                                    'STK',
                                    'WMGW',
                                    'GRSTR',
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        { terms: { plan_status: ['DELIVERED'] } },
                        { terms: { plan_is_approved_v1: [true] } },
                    ],
                },
            },
        },
    },
    size: 100,
    sort: [{ entity_id: 'asc' }],
};

export const planningAggQuery = {
    bool: {
        should: {
            bool: {
                must: [
                    { terms: { tenant_id: ['US_US'] } },
                    { terms: { sub_entity_type: ['PLAN'] } },
                    {
                        terms: {
                            plan_category: [
                                'STR',
                                'PLT',
                                'CLM',
                                'RTN',
                                'BOB',
                                'DHD',
                                'BOX',
                                'STK',
                                'WMGW',
                                'GRSTR',
                                'IMP_DRAY',
                                'IMP_OCEAN',
                                'OICC',
                                'IWFS',
                                'PPD_BKHL',
                                'IMP_MTDRAY',
                                'IM',
                                'IM_RAIL',
                                'IM_DRAY',
                            ],
                        },
                    },
                    { terms: { plan_status: ['PLANNED'] } },
                    { terms: { plan_is_approved_v1: [false] } },
                ],
                must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
            },
        },
    },
};

export const processingAggQuery = {
    bool: {
        should: [
            {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'STR',
                                    'PLT',
                                    'CLM',
                                    'RTN',
                                    'BOB',
                                    'DHD',
                                    'BOX',
                                    'STK',
                                    'WMGW',
                                    'GRSTR',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: [
                                    'PLANNED',
                                    'TENDERED',
                                    'TENDER_ACCEPTED',
                                    'TENDER_CANCELED',
                                    'TENDER_REJECTED',
                                    'NEED_ATTENTION',
                                ],
                            },
                        },
                        { terms: { plan_is_approved_v1: [true] } },
                    ],
                    must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                },
            },
            {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        {
                            terms: {
                                plan_status: [
                                    'PLANNED',
                                    'TENDERED',
                                    'TENDER_CANCELED',
                                    'TENDER_REJECTED',
                                    'NEED_ATTENTION',
                                ],
                            },
                        },
                        { terms: { plan_is_approved_v1: [true] } },
                    ],
                    must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                },
            },
            {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US_US'] } },
                        {
                            terms: {
                                ep_execution_plan_category: [
                                    'STR',
                                    'BOB',
                                    'DHD',
                                    'BOX',
                                    'STK',
                                    'GROC',
                                    'FLTGRO',
                                    'RLY',
                                ],
                            },
                        },
                        { terms: { ep_status: ['CREATED', 'DRIVER_ASSIGNED'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                    ],
                },
            },
        ],
    },
};

export const readyToStartAggQuery = {
    bool: {
        should: [
            {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                ],
                            },
                        },
                        { terms: { plan_status: ['TENDER_ACCEPTED'] } },
                        { terms: { plan_is_approved_v1: [true] } },
                    ],
                    must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                },
            },
            {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US_US'] } },
                        {
                            terms: {
                                ep_execution_plan_category: [
                                    'STR',
                                    'BOB',
                                    'DHD',
                                    'BOX',
                                    'STK',
                                    'GROC',
                                    'FLTGRO',
                                    'RLY',
                                ],
                            },
                        },
                        { terms: { ep_status: ['DISPATCHED'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                    ],
                },
            },
        ],
    },
};

export const inTransitAggQuery = {
    bool: {
        should: [
            {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                    'GRSTR',
                                ],
                            },
                        },
                        { terms: { plan_status: ['IN_TRANSIT'] } },
                        { terms: { plan_is_approved_v1: [true] } },
                    ],
                    must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                },
            },
            {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US_US'] } },
                        {
                            terms: {
                                ep_execution_plan_category: [
                                    'STR',
                                    'BOB',
                                    'DHD',
                                    'BOX',
                                    'STK',
                                    'GROC',
                                    'FLTGRO',
                                    'RLY',
                                ],
                            },
                        },
                        { terms: { ep_status: ['IN_TRANSIT'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                    ],
                },
            },
        ],
    },
};

export const deliveredAggQuery = {
    bool: {
        should: [
            {
                bool: {
                    must: [
                        { terms: { tenant_id: ['US_US'] } },
                        { terms: { sub_entity_type: ['PLAN'] } },
                        {
                            terms: {
                                plan_category: [
                                    'IMP_DRAY',
                                    'IMP_OCEAN',
                                    'OICC',
                                    'IWFS',
                                    'PPD_BKHL',
                                    'IMP_MTDRAY',
                                    'IM',
                                    'IM_RAIL',
                                    'IM_DRAY',
                                    'GRSTR',
                                ],
                            },
                        },
                        { terms: { plan_status: ['DELIVERED'] } },
                        { terms: { plan_is_approved_v1: [true] } },
                    ],
                    must_not: { exists: { field: 'plan_identifiers_parent_plan_id_v1' } },
                },
            },
            {
                bool: {
                    filter: [
                        { terms: { tenant_id: ['US_US'] } },
                        {
                            terms: {
                                ep_execution_plan_category: [
                                    'STR',
                                    'BOB',
                                    'DHD',
                                    'BOX',
                                    'STK',
                                    'GROC',
                                    'FLTGRO',
                                    'RLY',
                                ],
                            },
                        },
                        { terms: { ep_status: ['DELIVERED'] } },
                        { terms: { sub_entity_type: ['EXECUTION_PLAN'] } },
                    ],
                },
            },
        ],
    },
};
