import { TabStatus } from '@walmart/stride-ui-commons';
import {
    PlanCategories,
    getIsApprovedTQ,
    getPlanCategoryTQ,
    getPlanStatusTQ,
    getPrimaryDestinationSortingTripQuery,
    getTenantTQ,
} from '../ElasticQueryUtils';

describe('Elastic query utils', () => {
    it('should return proper elastic query for is approve - false', () => {
        const query = getIsApprovedTQ(false);
        expect(query?.toJSON()).toEqual({
            terms: {
                plan_is_approved_v1: [false],
            },
        });
    });

    it('should return proper elastic query for is approve - true', () => {
        const query = getIsApprovedTQ(true);
        expect(query?.toJSON()).toEqual({
            terms: {
                plan_is_approved_v1: [true],
            },
        });
    });

    it('should return proper elastic query for load plan category', () => {
        const query = getPlanCategoryTQ(false, PlanCategories.groupByIntermodal);
        expect(query?.toJSON()).toEqual({
            terms: {
                plan_category: ['IM'],
            },
        });
    });

    it('should return proper elastic query for trip plan category', () => {
        const query = getPlanCategoryTQ(true, PlanCategories.groupByIntermodal);
        expect(query?.toJSON()).toEqual({
            terms: {
                ep_execution_plan_category: ['IM'],
            },
        });
    });

    it('should return proper elastic query for load plan status', () => {
        const query = getPlanStatusTQ(false, TabStatus?.delivered);
        expect(query?.toJSON()).toEqual({
            terms: {
                plan_status: ['DELIVERED'],
            },
        });
    });

    it('should return proper elastic query for trip plan status', () => {
        const query = getPlanStatusTQ(true, TabStatus?.delivered);
        expect(query?.toJSON()).toEqual({
            terms: {
                ep_status: ['DELIVERED'],
            },
        });
    });

    it('getPrimaryDestinationSortingTripQuery - elastic query', () => {
        const queryExpected = [
            { terms: { sub_entity_type: ['EXECUTION_PLAN_PLANS'] } },
            { term: { ep_plans_plan_sequence: 1 } },
            { term: { is_active: true } },
            {
                has_parent: {
                    query: {
                        bool: {
                            should: {
                                bool: { filter: { terms: { plan_is_approved_v1: [false] } } },
                            },
                        },
                    },
                    parent_type: 'STRIDE_EXECUTION_PLAN',
                },
            },
        ];

        const query = getPrimaryDestinationSortingTripQuery(getIsApprovedTQ(false));
        expect(JSON.stringify(query)).toEqual(JSON.stringify(queryExpected));
    });

    it('should return right query based on market us', () => {
        const query = getTenantTQ('us');
        expect(query?.toJSON()).toEqual({ terms: { tenant_id: ['US_US'] } });
    });

    it('should return right query based on market ustrx', () => {
        const query = getTenantTQ('ustrx');
        expect(query?.toJSON()).toEqual({ terms: { tenant_id: ['US.TRX'] } });
    });
});
