import esb from 'elastic-builder';
import { getUsUsTenantFlagValue } from '../CommonUtils';
import {
    ElasticBEQueryFieldsUSEnum,
    BEPlanCategoryEnum,
    GenericTSSFieldsEnum,
    getTenant,
} from '@walmart/stride-ui-commons';
export const getTenantTQ = (market) => {
    const tenantId = getTenant(market, {
        hostname: window.location.hostname,
        usUsTenant: getUsUsTenantFlagValue(market, false),
    });

    return esb.termsQuery(ElasticBEQueryFieldsUSEnum.TENANT_ID, [tenantId]);
};
export const entityPlanTQ = esb.termsQuery(ElasticBEQueryFieldsUSEnum.SUB_ENTITY_TYPE, ['PLAN']);
export const entityTripTQ = esb.termsQuery(ElasticBEQueryFieldsUSEnum.SUB_ENTITY_TYPE, ['EXECUTION_PLAN']);
export const mustShipPlanTQ = esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_EXCEPTION_FLAGS, [
    'TOTE_EXCHANGE_MUST_SHIP',
]);
export const mustShipTripTQ = esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_PLANS_EXCEPTIONS_FLAGS, [
    'TOTE_EXCHANGE_MUST_SHIP',
]);
export const getIsApprovedTQ = (value) => esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_IS_APPROVED, [value]);
export const getPlanCategoryTQ = (isTrip, planCategoryList) =>
    esb.termsQuery(
        isTrip ? ElasticBEQueryFieldsUSEnum.EP_PLAN_CATEGORY : ElasticBEQueryFieldsUSEnum.PLAN_CATEGORY,
        planCategoryList,
    );
export const getPlanStatusTQ = (isTrip, statusList) =>
    esb.termsQuery(isTrip ? ElasticBEQueryFieldsUSEnum.EP_STATUS : ElasticBEQueryFieldsUSEnum.PLAN_STATUS, statusList);

export const getPrimaryDestinationSortingTripQuery = (tripQueries) => [
    esb.termsQuery(ElasticBEQueryFieldsUSEnum.SUB_ENTITY_TYPE, GenericTSSFieldsEnum.EXECUTION_PLAN_PLANS),
    esb.termQuery(ElasticBEQueryFieldsUSEnum.EP_PLANS_PLAN_SEQUENCE, 1),
    esb.termQuery(ElasticBEQueryFieldsUSEnum.PLAN_IS_ACTIVE, true),
    esb.hasParentQuery(
        esb.boolQuery().should([esb.boolQuery().filter(tripQueries)]),
        GenericTSSFieldsEnum.STRIDE_EXECUTION_PLAN,
    ),
];
/**
 * @deprecated This PlanCategories will be removed in favour of `PlanCategories` from
 * `@walmart/stride-ui-commons`. Please add new changes in `@walmart/stride-ui-commons`
 * instead of this file
 */
export const PlanCategories = {
    planning: [
        BEPlanCategoryEnum.STR?.code,
        BEPlanCategoryEnum.PLT?.code,
        BEPlanCategoryEnum.CLM?.code,
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    planningGroupByLoad: [BEPlanCategoryEnum.IM_RAIL?.code, BEPlanCategoryEnum.IM_DRAY?.code],
    processingOBLoad: [BEPlanCategoryEnum.STR?.code, BEPlanCategoryEnum.PLT?.code, BEPlanCategoryEnum.CLM?.code],
    processingDrayLoad: [
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    processingTrip: [BEPlanCategoryEnum.STR?.code],
    readyToStartDrayLoad: [
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    readyToStartTrip: [BEPlanCategoryEnum.STR?.code],
    readyToStartOBLoad: [BEPlanCategoryEnum.STR?.code, BEPlanCategoryEnum.PLT?.code, BEPlanCategoryEnum.CLM?.code],
    readyToStartGroupByLoad: [
        BEPlanCategoryEnum.STR?.code,
        BEPlanCategoryEnum.PLT?.code,
        BEPlanCategoryEnum.CLM?.code,
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    inTransitLoad: [
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    inTransitTrip: [BEPlanCategoryEnum.STR?.code],
    inTransitGroupByLoad: [
        BEPlanCategoryEnum.STR?.code,
        BEPlanCategoryEnum.PLT?.code,
        BEPlanCategoryEnum.CLM?.code,
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    inTransitGlobalSearchLoad: [
        BEPlanCategoryEnum.STR?.code,
        BEPlanCategoryEnum.PLT?.code,
        BEPlanCategoryEnum.CLM?.code,
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    deliveredLoad: [
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    deliveredTrip: [BEPlanCategoryEnum.STR?.code],
    deliveredGroupByLoad: [
        BEPlanCategoryEnum.STR?.code,
        BEPlanCategoryEnum.PLT?.code,
        BEPlanCategoryEnum.CLM?.code,
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    deliveredGlobalSearchLoad: [
        BEPlanCategoryEnum.STR?.code,
        BEPlanCategoryEnum.PLT?.code,
        BEPlanCategoryEnum.CLM?.code,
        BEPlanCategoryEnum.IMP_DRAY?.code,
        BEPlanCategoryEnum.IMP_OCEAN?.code,
        BEPlanCategoryEnum.OICC?.code,
        BEPlanCategoryEnum.IWFS?.code,
        BEPlanCategoryEnum.PPD_BKHL?.code,
        BEPlanCategoryEnum.IMP_MTDRAY?.code,
        BEPlanCategoryEnum.IM?.code,
        BEPlanCategoryEnum.IM_RAIL?.code,
        BEPlanCategoryEnum.IM_DRAY?.code,
    ],
    groupByIntermodal: [BEPlanCategoryEnum.IM?.code],
};
