import esb from 'elastic-builder';
import moment from 'moment';
import {
    ElasticBEQueryFieldsUSEnum,
    TabStatus,
    GenericTSSFieldsEnum,
    DirectionEnum,
    ParamEnum,
    getTripTypesForLoads,
    PlanCategories as PlanCategoriesFromCommons,
} from '@walmart/stride-ui-commons';
import TimehorizonUiPhaseEnum from '../../component/model/timehorizonUiType';
import DateTypeUiEnum from '../dateTypeuiEnum';
import { GlobalSearchOption, timeHorizonDateFormat, defaultTimeHorizon } from '../../ConstantsUS';
import { phasesForAggsEnum } from '../../Constants';
import PhaseTypesEnum from '../enums/PhaseTypesEnum';
import { groupByList, modifyCategoryValue } from '../../component/trip-management-summary/US/DataModelsUS';
import {
    PlanCategories as PlanCategoriesList,
    entityPlanTQ,
    entityTripTQ,
    getIsApprovedTQ,
    getPlanCategoryTQ,
    getPlanStatusTQ,
    getTenantTQ,
    getPrimaryDestinationSortingTripQuery,
    mustShipTripTQ,
    mustShipPlanTQ,
} from './ElasticQueryUtils';
import TripSharedService from '../../service/TripSharedService';
const getRowStartNbr = (size, pageNbr) => (pageNbr - 1) * size;
const getSearchTimeHorizonReqPayloadAll = (hours) => {
    if (TripSharedService.getFeatureFlags()?.showTimeHorizonV2 && hours !== defaultTimeHorizon) {
        const delPast = hours?.dayCountDel?.[0];
        const delFuture = hours?.dayCountDel?.[1];
        const payload = {};
        const startDateStr = hours?.preferences?.split(' - ')[0] || hours?.name?.split(' - ')[0];
        const endDateStr = hours?.preferences?.split(' - ')[1] || hours?.name?.split(' - ')[1];
        const pastTabsTime = moment(new Date(startDateStr)).format(timeHorizonDateFormat);
        const futureTabsTime = moment(new Date(endDateStr)).format(timeHorizonDateFormat);
        const planning = esb
            .rangeQuery(
                hours.dateType === DateTypeUiEnum.PLANNED_START_DATE.name
                    ? ElasticBEQueryFieldsUSEnum.PLAN_SCHEDULE_MIN_PICKUP_TS
                    : ElasticBEQueryFieldsUSEnum.PLAN_SCHEDULE_MAXDUE_TS,
            )
            .gte(pastTabsTime)
            .lte(futureTabsTime);
        const processing = {
            load: esb
                .rangeQuery(
                    hours.dateType === DateTypeUiEnum.PLANNED_START_DATE.name
                        ? ElasticBEQueryFieldsUSEnum.PLAN_SCHEDULE_MIN_PICKUP_TS
                        : ElasticBEQueryFieldsUSEnum.PLAN_SCHEDULE_MAXDUE_TS,
                )
                .gte(pastTabsTime)
                .lte(futureTabsTime),
            trip: esb
                .rangeQuery(
                    hours.dateType === DateTypeUiEnum.PLANNED_START_DATE.name
                        ? ElasticBEQueryFieldsUSEnum.EP_SCHEDULE_MAX_PICKUP_TS
                        : ElasticBEQueryFieldsUSEnum.EP_SCHEDULE_MAXDUE_TS,
                )
                .gte(pastTabsTime)
                .lte(futureTabsTime),
        };
        const delivered = {
            trip: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.EP_TNT_ACTUAL_END_TS).gte(delPast).lte(delFuture),
            load: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.PLAN_COMPLETED_DATE).gte(delPast).lte(delFuture),
        };
        payload.planningEsbQuery = planning;
        payload.processingEsbQuery = processing;
        payload.deliveredEsbQuery = delivered;
        return payload;
    }
};
const getSearchProfilePayload = (profile) => {
    if (!profile?.preferences) {
        return [];
    }
    const arrayPrefLoad = profile.preferences.map((item) => {
        const direction = item?.attributes[0]?.value;
        const parameter = item?.parameter;
        let paramQuery;
        let valuesQuery;
        let paramQueryBoth;
        let valueQueryBoth;
        let loadTypeQuery;
        if (parameter === ParamEnum.LOAD_TYPE.desc) {
            loadTypeQuery = item?.values?.map((valueItem) => {
                const value = valueItem?.value;
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_CATEGORY, value);
            });
            return loadTypeQuery;
        }
        if (direction === DirectionEnum.OUTBOUND.name) {
            paramQuery = esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_LOCATIONS_ORIGIN_LOCATION_TYPE, [
                item?.parameter,
            ]);
            valuesQuery = item?.values?.map((valueItem) => {
                const value = valueItem?.value?.map((val) => val?.id);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_LOCATIONS_ORIGIN_LOCATION_ID, value) || [];
            });
        } else if (direction === DirectionEnum.INBOUND.name) {
            paramQuery = esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_LOCATIONS_DESTINATION_LOCATION_TYPE, [
                item?.parameter,
            ]);
            valuesQuery = item?.values?.map((valueItem) => {
                const value = valueItem?.value?.map((val) => val?.id);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_LOCATIONS_DESTINATION_LOCATION_ID, value);
            });
        } else if (direction === DirectionEnum.BOTH.name) {
            paramQueryBoth = esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_LOCATIONS_DESTINATION_LOCATION_TYPE, [
                item?.parameter,
            ]);
            valueQueryBoth = item?.values?.map((valueItem) => {
                const value = valueItem?.value?.map((val) => val?.id);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_LOCATIONS_DESTINATION_LOCATION_ID, value);
            });
            paramQuery = esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_LOCATIONS_ORIGIN_LOCATION_TYPE, [
                item?.parameter,
            ]);
            valuesQuery = item?.values?.map((valueItem) => {
                const value = valueItem?.value?.map((val) => val?.id);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.PLAN_LOCATIONS_ORIGIN_LOCATION_ID, value) || [];
            });
        }
        return direction === DirectionEnum.BOTH.name
            ? [paramQuery, ...valuesQuery, paramQueryBoth, ...valueQueryBoth]
            : [paramQuery, ...valuesQuery];
    });
    const arrayPrefTrip = profile.preferences.map((item) => {
        const direction = item?.attributes[0]?.value;
        const parameter = item?.parameter;
        let paramQuery;
        let valuesQuery;
        let paramQueryBoth;
        let valueQueryBoth;
        let loadTypeQuery;
        if (parameter === ParamEnum.LOAD_TYPE.desc) {
            loadTypeQuery = item?.values?.map((valueItem) => {
                let value = getTripTypesForLoads(valueItem?.value);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_PLAN_CATEGORY, value);
            });
            return loadTypeQuery;
        }
        if (direction === DirectionEnum.OUTBOUND.name) {
            paramQuery = esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_LOCATIONS_ORIGIN_LOCATION_TYPE, [
                item?.parameter,
            ]);
            valuesQuery = item?.values?.map((valueItem) => {
                const value = valueItem?.value?.map((val) => val?.id);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_LOCATION_ORIGIN_LOCATION_ID, value) || [];
            });
        } else if (direction === DirectionEnum.INBOUND.name) {
            paramQuery = esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_LOCATIONS_DESTINATION_LOCATION_TYPE, [
                item?.parameter,
            ]);
            valuesQuery = item?.values?.map((valueItem) => {
                const value = valueItem?.value?.map((val) => val?.id);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_LOCATIONS_DESTINATION_LOCATION_ID, value);
            });
        } else if (direction === DirectionEnum.BOTH.name) {
            paramQueryBoth = esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_LOCATIONS_DESTINATION_LOCATION_TYPE, [
                item?.parameter,
            ]);
            valueQueryBoth = item?.values?.map((valueItem) => {
                const value = valueItem?.value?.map((val) => val?.id);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_LOCATIONS_DESTINATION_LOCATION_ID, value);
            });
            paramQuery = esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_LOCATIONS_ORIGIN_LOCATION_TYPE, [
                item?.parameter,
            ]);
            valuesQuery = item?.values?.map((valueItem) => {
                const value = valueItem?.value?.map((val) => val?.id);
                return esb.termsQuery(ElasticBEQueryFieldsUSEnum.EP_LOCATION_ORIGIN_LOCATION_ID, value) || [];
            });
        }
        return direction === DirectionEnum.BOTH.name
            ? [paramQuery, ...valuesQuery, paramQueryBoth, ...valueQueryBoth]
            : [paramQuery, ...valuesQuery];
    });
    const payload = {
        load: esb.boolQuery(),
        trip: esb.boolQuery(),
    };
    arrayPrefLoad.flatMap((subarray) => {
        if (subarray.length === 4) {
            const firstPart = subarray.slice(0, 2);
            const secondPart = subarray.slice(2);
            const firstPartQuery = esb.boolQuery().must(firstPart.map((query) => query));
            const secondPartQuery = esb.boolQuery().must(secondPart.map((query) => query));
            const combinedQuery = esb.boolQuery().should([firstPartQuery, secondPartQuery]);
            payload.load.must(combinedQuery);
        } else {
            payload.load.must(esb.boolQuery().must(subarray));
        }
    });
    arrayPrefTrip.flatMap((subarray) => {
        if (subarray.length === 4) {
            const firstPart = subarray.slice(0, 2);
            const secondPart = subarray.slice(2);
            const firstPartQuery = esb.boolQuery().must(firstPart.map((query) => query));
            const secondPartQuery = esb.boolQuery().must(secondPart.map((query) => query));
            const combinedQuery = esb.boolQuery().should([firstPartQuery, secondPartQuery]);
            payload.trip.must(combinedQuery);
        } else {
            payload.trip.must(esb.boolQuery().must(subarray));
        }
    });
    return payload;
};
const planningCommonQuery = (timeHorizonElasticQuery, globalSearchData, searchBy, groupBy, profile, market) => {
    let queries1 = [];
    let queries2 = [];
    let queries3 = [];
    const PlanCategories = TripSharedService.getFeatureFlags()?.usePlanCategoriesFromCommons
        ? PlanCategoriesFromCommons
        : PlanCategoriesList;
    queries1 = [
        getTenantTQ(market),
        entityPlanTQ,
        getPlanCategoryTQ(false, PlanCategories.planning),
        getPlanStatusTQ(false, TabStatus?.planning),
        getIsApprovedTQ(false),
    ];
    if (profile) {
        queries1.unshift(profile?.load);
    }
    if (timeHorizonElasticQuery) {
        queries1.push(timeHorizonElasticQuery);
    }
    switch (groupBy) {
        case groupByList[0].id:
            if (globalSearchData) {
                if (searchBy === GlobalSearchOption[0].id) {
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    queries1 = [...queries1, searchIDs];
                    return esb.boolQuery().should([esb.boolQuery().must(queries1)]);
                }
                if (searchBy === GlobalSearchOption[1].id) {
                    return esb.matchNoneQuery();
                }
            }
            return esb.boolQuery().should([
                esb
                    .boolQuery()
                    .mustNot([esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID)])
                    .must(queries1),
            ]);
        case groupByList[1].id:
            queries2 = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.planningGroupByLoad),
                getPlanStatusTQ(false, TabStatus?.planning),
                getIsApprovedTQ(false),
                esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID),
            ];
            if (profile) {
                queries2.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery) {
                queries2.push(timeHorizonElasticQuery);
            }
            return esb.boolQuery().should([
                esb
                    .boolQuery()
                    .mustNot([esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID)])
                    .must(queries1),
                esb.boolQuery().must(queries2),
            ]);
        case groupByList[2].id:
            queries3 = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.groupByIntermodal),
                getPlanStatusTQ(false, TabStatus?.planning),
                getIsApprovedTQ(false),
            ];
            if (profile) {
                queries3.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery) {
                queries3.push(timeHorizonElasticQuery);
            }
            return esb.boolQuery().should([esb.boolQuery().must(queries3)]);
        default:
            break;
    }
};
const processingCommonQuery = (
    timeHorizonElasticQuery,
    globalSearchData,
    searchBy,
    groupBy,
    profile,
    exceptionQuery = undefined,
    queryState,
    market,
) => {
    let loadQueries = [];
    let drayloadQueries = [];
    let childLoadOBQueries = [];
    let tripQueries = [];
    let imQuery = [];
    const PlanCategories = TripSharedService.getFeatureFlags()?.usePlanCategoriesFromCommons
        ? PlanCategoriesFromCommons
        : PlanCategoriesList;
    loadQueries = [
        getTenantTQ(market),
        entityPlanTQ,
        getPlanCategoryTQ(false, PlanCategories.processingOBLoad),
        getPlanStatusTQ(false, TabStatus?.processingLoad),
        getIsApprovedTQ(true),
    ];
    if (profile) {
        loadQueries.unshift(profile?.load);
    }
    if (timeHorizonElasticQuery?.load) {
        loadQueries.push(timeHorizonElasticQuery?.load);
    }
    if (exceptionQuery?.load) {
        loadQueries.push(exceptionQuery?.load);
    }
    drayloadQueries = [
        getTenantTQ(market),
        entityPlanTQ,
        getPlanCategoryTQ(false, PlanCategories.processingDrayLoad),
        getPlanStatusTQ(false, TabStatus?.processingLoadDray),
        getIsApprovedTQ(true),
    ];
    if (profile) {
        drayloadQueries.unshift(profile?.load);
    }
    if (timeHorizonElasticQuery?.load) {
        drayloadQueries.push(timeHorizonElasticQuery?.load);
    }
    if (exceptionQuery?.load) {
        drayloadQueries.push(exceptionQuery?.load);
    }
    switch (groupBy) {
        case groupByList[0].id:
            tripQueries = [
                getTenantTQ(market),
                getPlanCategoryTQ(true, PlanCategories.processingTrip),
                getPlanStatusTQ(true, TabStatus?.processingTrip),
                entityTripTQ,
            ];
            if (profile) {
                tripQueries.unshift(profile?.trip);
            }
            if (timeHorizonElasticQuery?.trip) {
                tripQueries.push(timeHorizonElasticQuery?.trip);
            }
            if (exceptionQuery?.trip) {
                tripQueries.push(exceptionQuery?.trip);
            }
            if (globalSearchData) {
                if (searchBy === GlobalSearchOption[0].id) {
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    loadQueries = [
                        getTenantTQ(market),
                        entityPlanTQ,
                        // Using dray status field, bez of same.
                        getPlanCategoryTQ(false, PlanCategories.processingOBLoad),
                        getPlanStatusTQ(false, TabStatus?.processingLoadDray),
                        getIsApprovedTQ(true),
                        searchIDs,
                    ];
                    drayloadQueries = [...drayloadQueries, searchIDs];
                    return esb
                        .boolQuery()
                        .should([esb.boolQuery().must(loadQueries), esb.boolQuery().must(drayloadQueries)]);
                }
                if (searchBy === GlobalSearchOption[1].id) {
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    tripQueries = [...tripQueries, searchIDs];
                    if (
                        queryState.sortField === ElasticBEQueryFieldsUSEnum.EP_PLANS_LOCATIONS_DESTI_LOCATION_ID &&
                        queryState.activeTabIndex === PhaseTypesEnum.PROCESSING.index
                    ) {
                        tripQueries = getPrimaryDestinationSortingTripQuery(tripQueries);
                    }
                    return esb.boolQuery().should([esb.boolQuery().filter(tripQueries)]);
                }
            }

            if (
                queryState.sortField === ElasticBEQueryFieldsUSEnum.EP_PLANS_LOCATIONS_DESTI_LOCATION_ID &&
                queryState.activeTabIndex === PhaseTypesEnum.PROCESSING.index
            ) {
                tripQueries = getPrimaryDestinationSortingTripQuery(tripQueries);
            }

            return esb.boolQuery().should([
                esb
                    .boolQuery()
                    .mustNot([esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID)])
                    .must(loadQueries),
                esb
                    .boolQuery()
                    .mustNot([esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID)])
                    .must(drayloadQueries),
                esb.boolQuery().filter(tripQueries),
            ]);
        case groupByList[1].id:
            childLoadOBQueries = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.processingOBLoad),
                getPlanStatusTQ(false, TabStatus?.processingLoadDray),
                getIsApprovedTQ(true),
                esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID),
            ];
            if (profile) {
                childLoadOBQueries.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery?.load) {
                childLoadOBQueries.push(timeHorizonElasticQuery?.load);
            }
            if (exceptionQuery?.load) {
                childLoadOBQueries.push(exceptionQuery?.load);
            }
            return esb.boolQuery().should([
                esb.boolQuery().must(childLoadOBQueries),
                esb
                    .boolQuery()
                    .mustNot([esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID)])
                    .must(loadQueries),
                esb.boolQuery().must(drayloadQueries),
            ]);
        case groupByList[2].id:
            imQuery = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.groupByIntermodal),
                getPlanStatusTQ(false, TabStatus?.processingLoadDray),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                imQuery.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery?.load) {
                imQuery.push(timeHorizonElasticQuery?.load);
            }
            if (exceptionQuery?.load) {
                imQuery.push(exceptionQuery?.load);
            }
            return esb.boolQuery().should([esb.boolQuery().must(imQuery)]);
        default:
            break;
    }
};
const readyToStartCommonQuery = (
    timeHorizonElasticQuery,
    globalSearchData,
    searchBy,
    groupBy,
    profile,
    exceptionQuery = undefined,
    queryState,
    market,
) => {
    let loadQueries = [];
    let tripQueries = [];
    let imQuery = [];
    let loadOBQueries = [];
    let loadDrayQueries = [];
    const PlanCategories = TripSharedService.getFeatureFlags()?.usePlanCategoriesFromCommons
        ? PlanCategoriesFromCommons
        : PlanCategoriesList;
    loadOBQueries = [
        getTenantTQ(market),
        entityPlanTQ,
        getPlanCategoryTQ(false, PlanCategories.readyToStartOBLoad),
        getPlanStatusTQ(false, TabStatus?.reactToStartLoad),
        getIsApprovedTQ(true),
        esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID),
    ];
    if (profile) {
        loadOBQueries.unshift(profile?.load);
    }
    switch (groupBy) {
        case groupByList[0].id:
            loadQueries = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.readyToStartDrayLoad),
                getPlanStatusTQ(false, TabStatus?.reactToStartLoad),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                loadQueries.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery?.load) {
                loadQueries.push(timeHorizonElasticQuery?.load);
            }
            tripQueries = [
                getTenantTQ(market),
                getPlanCategoryTQ(true, PlanCategories.readyToStartTrip),
                getPlanStatusTQ(true, TabStatus?.reactToStart),
                entityTripTQ,
            ];
            if (profile) {
                tripQueries.unshift(profile?.trip);
            }
            if (timeHorizonElasticQuery?.trip) {
                tripQueries.push(timeHorizonElasticQuery?.trip);
            }
            if (globalSearchData) {
                if (searchBy === GlobalSearchOption[0].id) {
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    loadQueries = [...loadQueries, searchIDs];
                    loadOBQueries = [...loadOBQueries, searchIDs];
                    return esb
                        .boolQuery()
                        .should([esb.boolQuery().must(loadQueries), esb.boolQuery().must(loadOBQueries)]);
                }
                if (searchBy === GlobalSearchOption[1].id) {
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    tripQueries = [...tripQueries, searchIDs];
                    if (
                        queryState.sortField === ElasticBEQueryFieldsUSEnum.EP_PLANS_LOCATIONS_DESTI_LOCATION_ID &&
                        queryState.activeTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index
                    ) {
                        tripQueries = getPrimaryDestinationSortingTripQuery(tripQueries);
                    }
                    return esb.boolQuery().should([esb.boolQuery().filter(tripQueries)]);
                }
            }
            if (exceptionQuery?.load) {
                loadQueries.push(exceptionQuery?.load);
            }
            if (exceptionQuery?.trip) {
                tripQueries.push(exceptionQuery?.trip);
            }

            if (
                queryState.sortField === ElasticBEQueryFieldsUSEnum.EP_PLANS_LOCATIONS_DESTI_LOCATION_ID &&
                queryState.activeTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index
            ) {
                tripQueries = getPrimaryDestinationSortingTripQuery(tripQueries);
            }

            return esb.boolQuery().should([
                esb
                    .boolQuery()
                    .mustNot([esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID)])
                    .must(loadQueries),
                esb.boolQuery().filter(tripQueries),
            ]);
        case groupByList[1].id:
            if (timeHorizonElasticQuery?.load) {
                loadOBQueries.push(timeHorizonElasticQuery?.load);
            }
            if (exceptionQuery?.load) {
                loadOBQueries.push(exceptionQuery?.load);
            }
            loadDrayQueries = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.readyToStartDrayLoad),
                getPlanStatusTQ(false, TabStatus?.reactToStartLoad),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                loadDrayQueries.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery?.load) {
                loadDrayQueries.push(timeHorizonElasticQuery?.load);
            }
            if (exceptionQuery?.load) {
                loadDrayQueries.push(exceptionQuery?.load);
            }
            return esb.boolQuery().should([esb.boolQuery().must(loadOBQueries), esb.boolQuery().must(loadDrayQueries)]);
        case groupByList[2].id:
            imQuery = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.groupByIntermodal),
                getPlanStatusTQ(false, TabStatus?.reactToStartLoad),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                imQuery.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery?.load) {
                imQuery.push(timeHorizonElasticQuery?.load);
            }
            if (exceptionQuery?.load) {
                imQuery.push(exceptionQuery?.load);
            }
            return esb.boolQuery().should([esb.boolQuery().must(imQuery)]);
        default:
            break;
    }
};
const inTransitCommonQuery = (globalSearchData, searchBy, groupBy, profile, queryState, market) => {
    let loadQueries = [];
    let tripQueries = [];
    let imQuery = [];
    const PlanCategories = TripSharedService.getFeatureFlags()?.usePlanCategoriesFromCommons
        ? PlanCategoriesFromCommons
        : PlanCategoriesList;
    switch (groupBy) {
        case groupByList[0].id:
            loadQueries = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.inTransitLoad),
                getPlanStatusTQ(false, TabStatus?.inTransit),
                getIsApprovedTQ(true),
            ];
            tripQueries = [
                getTenantTQ(market),
                getPlanCategoryTQ(true, PlanCategories.inTransitTrip),
                getPlanStatusTQ(true, TabStatus?.inTransit),
                entityTripTQ,
            ];
            if (profile) {
                loadQueries.unshift(profile?.load);
                tripQueries.unshift(profile?.trip);
            }
            if (globalSearchData) {
                if (searchBy === GlobalSearchOption[0].id) {
                    loadQueries = [
                        getTenantTQ(market),
                        entityPlanTQ,
                        getPlanCategoryTQ(false, PlanCategories.inTransitGlobalSearchLoad),
                        getPlanStatusTQ(false, TabStatus?.inTransit),
                        getIsApprovedTQ(true),
                    ];
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    loadQueries = [...loadQueries, searchIDs];
                    return esb.boolQuery().should([esb.boolQuery().must(loadQueries)]);
                }
                if (searchBy === GlobalSearchOption[1].id) {
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    tripQueries = [...tripQueries, searchIDs];
                    if (
                        queryState.sortField === ElasticBEQueryFieldsUSEnum.EP_PLANS_LOCATIONS_DESTI_LOCATION_ID &&
                        queryState.activeTabIndex === PhaseTypesEnum.IN_TRANSIT.index
                    ) {
                        tripQueries = getPrimaryDestinationSortingTripQuery(tripQueries);
                    }
                    return esb.boolQuery().should([esb.boolQuery().filter(tripQueries)]);
                }
            }
            if (
                queryState.sortField === ElasticBEQueryFieldsUSEnum.EP_PLANS_LOCATIONS_DESTI_LOCATION_ID &&
                queryState.activeTabIndex === PhaseTypesEnum.IN_TRANSIT.index
            ) {
                tripQueries = getPrimaryDestinationSortingTripQuery(tripQueries);
            }
            return esb.boolQuery().should([
                esb
                    .boolQuery()
                    .mustNot([esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID)])
                    .must(loadQueries),
                esb.boolQuery().filter(tripQueries),
            ]);
        case groupByList[1].id:
            loadQueries = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.inTransitGroupByLoad),
                getPlanStatusTQ(false, TabStatus?.inTransit),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                loadQueries.unshift(profile?.load);
            }
            return esb.boolQuery().should([esb.boolQuery().must(loadQueries)]);
        case groupByList[2].id:
            imQuery = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.groupByIntermodal),
                getPlanStatusTQ(false, TabStatus?.inTransit),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                imQuery.unshift(profile?.load);
            }
            return esb.boolQuery().should([esb.boolQuery().must(imQuery)]);
        default:
            break;
    }
};
const deliveredCommonQuery = (
    timeHorizonElasticQuery,
    globalSearchData,
    searchBy,
    groupBy,
    profile,
    queryState,
    market,
) => {
    let loadQueries = [];
    let tripQueries = [];
    let imQuery = [];
    const PlanCategories = TripSharedService.getFeatureFlags()?.usePlanCategoriesFromCommons
        ? PlanCategoriesFromCommons
        : PlanCategoriesList;
    switch (groupBy) {
        case groupByList[0].id:
            loadQueries = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.deliveredLoad),
                getPlanStatusTQ(false, TabStatus?.delivered),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                loadQueries.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery?.load) {
                loadQueries.push(timeHorizonElasticQuery?.load);
            }
            tripQueries = [
                getTenantTQ(market),
                getPlanCategoryTQ(true, PlanCategories.deliveredTrip),
                getPlanStatusTQ(true, TabStatus?.delivered),
                entityTripTQ,
            ];
            if (profile) {
                tripQueries.unshift(profile?.trip);
            }
            if (timeHorizonElasticQuery?.trip) {
                tripQueries.push(timeHorizonElasticQuery?.trip);
            }
            if (globalSearchData) {
                if (searchBy === GlobalSearchOption[0].id) {
                    loadQueries = [
                        getTenantTQ(market),
                        entityPlanTQ,
                        getPlanCategoryTQ(false, PlanCategories.deliveredGlobalSearchLoad),
                        getPlanStatusTQ(false, TabStatus?.delivered),
                        getIsApprovedTQ(true),
                    ];
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    loadQueries = [...loadQueries, searchIDs];
                    return esb.boolQuery().should([esb.boolQuery().must(loadQueries)]);
                }
                if (searchBy === GlobalSearchOption[1].id) {
                    const searchIDs = esb.termsQuery(GenericTSSFieldsEnum.ENTITY_ID, globalSearchData.split(','));
                    tripQueries = [...tripQueries, searchIDs];
                    if (
                        queryState.sortField === ElasticBEQueryFieldsUSEnum.EP_PLANS_LOCATIONS_DESTI_LOCATION_ID &&
                        queryState.activeTabIndex === PhaseTypesEnum.DELIVERED.index
                    ) {
                        tripQueries = getPrimaryDestinationSortingTripQuery(tripQueries);
                    }
                    return esb.boolQuery().should([esb.boolQuery().filter(tripQueries)]);
                }
            }
            if (
                queryState.sortField === ElasticBEQueryFieldsUSEnum.EP_PLANS_LOCATIONS_DESTI_LOCATION_ID &&
                queryState.activeTabIndex === PhaseTypesEnum.DELIVERED.index
            ) {
                tripQueries = getPrimaryDestinationSortingTripQuery(tripQueries);
            }
            return esb.boolQuery().should([
                esb
                    .boolQuery()
                    .mustNot([esb.existsQuery(ElasticBEQueryFieldsUSEnum.PLAN_PARENT_PLANID)])
                    .must(loadQueries),
                esb.boolQuery().filter(tripQueries),
            ]);
        case groupByList[1].id:
            loadQueries = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.deliveredGroupByLoad),
                getPlanStatusTQ(false, TabStatus?.delivered),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                loadQueries.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery?.load) {
                loadQueries.push(timeHorizonElasticQuery?.load);
            }
            return esb.boolQuery().should([esb.boolQuery().must(loadQueries)]);
        case groupByList[2].id:
            imQuery = [
                getTenantTQ(market),
                entityPlanTQ,
                getPlanCategoryTQ(false, PlanCategories.groupByIntermodal),
                getPlanStatusTQ(false, TabStatus?.delivered),
                getIsApprovedTQ(true),
            ];
            if (profile) {
                imQuery.unshift(profile?.load);
            }
            if (timeHorizonElasticQuery?.load) {
                imQuery.push(timeHorizonElasticQuery?.load);
            }
            return esb.boolQuery().should([esb.boolQuery().must(imQuery)]);
        default:
            break;
    }
};
const checkForDefaultTH = () => {
    if (TripSharedService.getFeatureFlags()?.getTimeHorizonV2) {
        return getSearchTimeHorizonReqPayloadAll(
            `${TimehorizonUiPhaseEnum.PAST.desc} - ${TimehorizonUiPhaseEnum.FUTURE.desc}`,
        );
    }
    return undefined;
};
function getExceptionQueryReqPayloadAll(exceptionType) {
    let currentDateTime = new Date();
    switch (exceptionType) {
        case 'PICKUP_96_HOURS_AWAY': {
            const lteTime = moment(
                new Date(currentDateTime.setTime(currentDateTime.getTime() + 96 * 60 * 60 * 1000)),
            )?.format(timeHorizonDateFormat);
            currentDateTime = new Date();
            const gteTime = moment(new Date(currentDateTime))?.format(timeHorizonDateFormat);
            return {
                load: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.PLAN_SCHEDULE_MIN_PICKUP_TS).gte(gteTime).lte(lteTime),
                trip: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.EP_SCHEDULE_MAX_PICKUP_TS).gte(gteTime).lte(lteTime),
            };
        }
        case 'PICKUP_IN_PAST': {
            const lteTime = moment(new Date(currentDateTime))?.format(timeHorizonDateFormat);
            return {
                load: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.PLAN_SCHEDULE_MIN_PICKUP_TS).lte(lteTime),
                trip: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.EP_SCHEDULE_MAX_PICKUP_TS).lte(lteTime),
            };
        }
        case 'PICKUP_GREATER_THAN_24_HOURS_IN_PAST': {
            const gteTime = moment(
                new Date(currentDateTime.setTime(currentDateTime.getTime() - 72 * 60 * 60 * 1000)),
            )?.format(timeHorizonDateFormat);
            currentDateTime = new Date();
            const lteTime = moment(
                new Date(currentDateTime.setTime(currentDateTime.getTime() - 24 * 60 * 60 * 1000)),
            )?.format(timeHorizonDateFormat);
            return {
                load: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.PLAN_SCHEDULE_MIN_PICKUP_TS).gte(gteTime).lte(lteTime),
                trip: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.EP_SCHEDULE_MAX_PICKUP_TS).gte(gteTime).lte(lteTime),
            };
        }
        case 'PICKUP_GREATER_THAN_72_HOURS_IN_PAST': {
            const lteTime = moment(
                new Date(currentDateTime.setTime(currentDateTime.getTime() - 72 * 60 * 60 * 1000)),
            )?.format(timeHorizonDateFormat);
            return {
                load: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.PLAN_SCHEDULE_MIN_PICKUP_TS).lte(lteTime),
                trip: esb.rangeQuery(ElasticBEQueryFieldsUSEnum.EP_SCHEDULE_MAX_PICKUP_TS).lte(lteTime),
            };
        }
        case 'TOTE_EXCHANGE_MUST_SHIP': {
            return {
                load: mustShipPlanTQ,
                trip: esb
                    .hasChildQuery()
                    .query(esb.boolQuery().must(mustShipTripTQ))
                    .type(GenericTSSFieldsEnum.EXECUTION_PLAN_PLANS),
            };
        }
        default:
            return {};
    }
}
const getCommonQueries = (queryState, market) => {
    let timeHorizonElasticQuery;
    let exceptionQuery;
    let groupBy;
    let profile;
    const searchDataIDs = queryState?.globalSearchData || null;
    const searchBy = queryState?.searchByOption || null;
    if (queryState?.globalSearchData) {
        timeHorizonElasticQuery = undefined;
        exceptionQuery = undefined;
        groupBy = groupByList[0].id;
        profile = null;
    } else {
        timeHorizonElasticQuery = queryState?.timeHorizon
            ? getSearchTimeHorizonReqPayloadAll(queryState?.timeHorizon)
            : checkForDefaultTH();
        groupBy = queryState?.groupBy;
        exceptionQuery = queryState?.exceptionType ? getExceptionQueryReqPayloadAll(queryState?.exceptionType) : {};
        profile =
            queryState?.profile && Object.keys(queryState?.profile)?.length > 0
                ? getSearchProfilePayload(queryState?.profile)
                : null;
    }
    if (queryState.activeTabIndex === PhaseTypesEnum.PLANNING.index) {
        return planningCommonQuery(
            timeHorizonElasticQuery?.planningEsbQuery,
            searchDataIDs,
            searchBy,
            groupBy,
            profile,
            market,
        );
    }
    if (queryState.activeTabIndex === PhaseTypesEnum.PROCESSING.index) {
        return processingCommonQuery(
            timeHorizonElasticQuery?.processingEsbQuery,
            searchDataIDs,
            searchBy,
            groupBy,
            profile,
            exceptionQuery,
            queryState,
            market,
        );
    }
    if (queryState.activeTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) {
        return readyToStartCommonQuery(
            timeHorizonElasticQuery?.processingEsbQuery,
            searchDataIDs,
            searchBy,
            groupBy,
            profile,
            exceptionQuery,
            queryState,
            market,
        );
    }
    if (queryState.activeTabIndex === PhaseTypesEnum.IN_TRANSIT.index) {
        return inTransitCommonQuery(searchDataIDs, searchBy, groupBy, profile, queryState, market);
    }
    if (queryState.activeTabIndex === PhaseTypesEnum.DELIVERED.index) {
        return deliveredCommonQuery(
            timeHorizonElasticQuery?.deliveredEsbQuery,
            searchDataIDs,
            searchBy,
            groupBy,
            profile,
            queryState,
            market,
        );
    }
    return {};
};
export const searchAggregatesElasticQueryAll = (queryState, market) => {
    let timeHorizonElasticQuery;
    let groupBy;
    let profile;
    if (queryState?.globalSearchData) {
        timeHorizonElasticQuery = undefined;
        groupBy = groupByList[0].id;
        profile = null;
    } else {
        timeHorizonElasticQuery = queryState?.timeHorizon
            ? getSearchTimeHorizonReqPayloadAll(queryState?.timeHorizon)
            : undefined;
        groupBy = queryState?.groupBy;
        profile =
            queryState?.profile && Object.keys(queryState?.profile)?.length > 0
                ? getSearchProfilePayload(queryState?.profile)
                : null;
    }
    const aggQry = esb
        .requestBodySearch()
        .agg(
            esb
                .filtersAggregation(ElasticBEQueryFieldsUSEnum.TSS_AGGREGATE)
                .filter(
                    phasesForAggsEnum.PLANNING,
                    planningCommonQuery(
                        timeHorizonElasticQuery?.planningEsbQuery,
                        queryState?.globalSearchData,
                        queryState?.searchByOption,
                        groupBy,
                        profile,
                        market,
                    ),
                )
                .filter(
                    phasesForAggsEnum.PROCESSING,
                    processingCommonQuery(
                        timeHorizonElasticQuery?.processingEsbQuery,
                        queryState?.globalSearchData,
                        queryState?.searchByOption,
                        groupBy,
                        profile,
                        undefined,
                        queryState,
                        market,
                    ),
                )
                .filter(
                    phasesForAggsEnum.READY_TO_START,
                    readyToStartCommonQuery(
                        timeHorizonElasticQuery?.processingEsbQuery,
                        queryState?.globalSearchData,
                        queryState?.searchByOption,
                        groupBy,
                        profile,
                        undefined,
                        queryState,
                        market,
                    ),
                )
                .filter(
                    phasesForAggsEnum.IN_TRANSIT,
                    inTransitCommonQuery(
                        queryState?.globalSearchData,
                        queryState?.searchByOption,
                        groupBy,
                        profile,
                        queryState,
                        market,
                    ),
                )
                .filter(
                    phasesForAggsEnum.DELIVERED,
                    deliveredCommonQuery(
                        timeHorizonElasticQuery?.deliveredEsbQuery,
                        queryState?.globalSearchData,
                        queryState?.searchByOption,
                        groupBy,
                        profile,
                        queryState,
                        market,
                    ),
                )
                .filter(phasesForAggsEnum.ADDITIONAL_FILTER, getCommonQueries(queryState, market)),
        )
        .size(0);
    return aggQry;
};
export const getElasticRequestQuery = (queryState, cmsConfig, market) => {
    let qry = esb
        .requestBodySearch()
        .query(getCommonQueries(queryState, market))
        .from(getRowStartNbr(cmsConfig?.paginationSize, queryState?.page))
        .size(cmsConfig?.paginationSize);

    if (TripSharedService.getFeatureFlags()?.enableMultiSortForSearchTable) {
        qry = qry.sorts(
            queryState?.multiSortFields?.map((sortInfo) =>
                esb.sort(sortInfo?.sortField).order(sortInfo.desc ? 'desc' : 'asc'),
            ) || [],
        );
    } else {
        qry = qry.sort(esb.sort(queryState?.sortField).order(queryState?.sortMode?.toLowerCase()));
    }

    return qry;
};
