import { format } from 'date-fns';
import {
    isNullOrUndefined,
    MarketCodeEnum,
    ElasticBEQueryFieldsUSEnum,
    getEnvironment,
    LOCAL_TIME_ZONE,
    INPUT_DATE_FORMAT as INPUT_DATE,
    formatZonedTimeToUtc,
    getPlanCategoryTQ,
    PlanCategories,
    getShadowModeExistsQuery,
} from '@walmart/stride-ui-commons';
import PhaseTypesEnum from '../enums/PhaseTypesEnum';
import PlanStatusEnum from '../PlanStatusEnum';
import { getElasticRequestQuery, searchAggregatesElasticQueryAll } from './ElasticQueriesUS';
import TripSharedService from '../../service/TripSharedService';
import { groupByList } from '../../component/trip-management-summary/US/DataModelsUS';
import { GlobalSearchOption } from '../../ConstantsUS';
import { CONST_FILTER_PROCESSING_DEFAULT_STATUS, camMarkets } from '../../Constants';

export const INPUT_DATE_FORMAT = 'yyyy-MM-dd';

export const getPhaseTabsForCurrentMarket = (market) =>
    Object.values(PhaseTypesEnum)
        .reduce((phaseTypesForCurrentMarket, PhaseTypeEnum) => {
            if (PhaseTypeEnum.markets.includes(market)) phaseTypesForCurrentMarket.push(PhaseTypeEnum);
            return phaseTypesForCurrentMarket;
        }, [])
        .sort((a, b) => a.index - b.index);

export const shouldDisableLocationFields = (profile, market) => {
    let disableOriginFields = false;
    let disableDestinationFields = false;
    if (market === 'ca' && profile?.preferences) {
        profile.preferences.forEach((element) => {
            const direction = element?.attributes.find((it) => it.field === 'DIRECTION')?.value;
            if (direction === 'OUTBOUND' || direction === 'BOTH') {
                disableOriginFields = true;
            }
            if (direction === 'INBOUND' || direction === 'BOTH') {
                disableDestinationFields = true;
            }
        });
    }
    return { disableDestinationFields, disableOriginFields };
};

const getOriginInfo = (data) => {
    const origin = {};
    if (data?.originCity) {
        origin.city = data?.originCity;
    }
    if (data?.originProvince) {
        origin.province = data?.originProvince;
    }
    if (data?.originPostalCode) {
        origin.postalCode = data?.originPostalCode;
    }
    if (data?.originCountry) {
        origin.countryCode = data?.originCountry;
    }
    if (data?.originLocId) {
        origin.locationId = data?.originLocId;
    }

    return origin;
};

const getDestinationInfo = (data) => {
    const destination = {};
    if (data?.destinationCity) {
        destination.city = data?.destinationCity;
    }
    if (data?.destinationProvince) {
        destination.province = data?.destinationProvince;
    }
    if (data?.destinationPostalCode) {
        destination.postalCode = data?.destinationPostalCode;
    }
    if (data?.destinationCountry) {
        destination.countryCode = data?.destinationCountry;
    }
    if (data?.destinationLocId) {
        destination.locationId = data?.destinationLocId;
    }

    return destination;
};

const getQueryDates = (data) => {
    switch (data.periodType) {
        case 'IN_BETWEEN':
            if (TripSharedService.getFeatureFlags()?.searchDateWithTimezone) {
                return {
                    endTs: data?.tillDate
                        ? formatZonedTimeToUtc(new Date(data?.tillDate), LOCAL_TIME_ZONE, INPUT_DATE)
                        : '',
                    startTs: data?.fromDate
                        ? formatZonedTimeToUtc(new Date(data?.fromDate), LOCAL_TIME_ZONE, INPUT_DATE)
                        : '',
                    type: data?.dateType ? data.dateType : null,
                };
            }
            return {
                endTs: data?.tillDate ? format(data.tillDate, INPUT_DATE_FORMAT) : null,
                startTs: data?.fromDate ? format(data.fromDate, INPUT_DATE_FORMAT) : null,
                type: data?.dateType ? data.dateType : null,
            };

        case 'AFTER':
            return {
                endTs: '2100-02-08T23:59:59',
                startTs: data?.date ? format(data?.date, INPUT_DATE_FORMAT) : null,
                type: data?.dateType ? data.dateType : null,
            };

        case 'BEFORE':
            return {
                endTs: data?.date ? format(data?.date, INPUT_DATE_FORMAT) : null,
                startTs: '1970-01-01T00:00:00',
                type: data?.dateType ? data.dateType : null,
            };

        case 'ON':
            return {
                endTs: data?.date ? `${format(data.date, INPUT_DATE_FORMAT)}T23:59:59` : null,
                startTs: data?.date ? `${format(data.date, INPUT_DATE_FORMAT)}T00:00:00` : null,
                type: data?.dateType ? data.dateType : null,
            };

        default:
            return {};
    }
};

const formatProcessingFilterStatus = (filterStatus) => {
    const statusArray = [];
    filterStatus.forEach((eachStatus) => {
        if (eachStatus === PlanStatusEnum.TENDER_IN_PROGRESS.name) {
            statusArray.push(
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: PlanStatusEnum.PLANNED.name,
                },
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: PlanStatusEnum.TENDERED.name,
                },
            );
        }
        if (eachStatus === PlanStatusEnum.TENDER_DECLINED.name) {
            statusArray.push(
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: PlanStatusEnum.TENDER_REJECTED.name,
                },
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: PlanStatusEnum.TENDER_CANCELED.name,
                },
            );
        }
        if (eachStatus === PlanStatusEnum.TENDER_EXHAUSTED.name) {
            statusArray.push(
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: PlanStatusEnum.NEED_ATTENTION.name,
                },
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: PlanStatusEnum.TENDER_TIMEOUT.name,
                },
            );
        }
    });
    if (statusArray.length > 0) return statusArray;
    return CONST_FILTER_PROCESSING_DEFAULT_STATUS;
};

const formatIntransitFilterStatus = (status) => {
    switch (status) {
        case 'STARTED':
            return PlanStatusEnum.IN_TRANSIT_STARTED.name;
        case 'EARLY':
            return PlanStatusEnum.IN_TRANSIT_EARLY.name;
        case 'ONTIME':
            return PlanStatusEnum.IN_TRANSIT_ON_TIME.name;
        case 'LATE':
            return PlanStatusEnum.IN_TRANSIT_LATE.name;
        default:
            return PlanStatusEnum.IN_TRANSIT.name;
    }
};

const getCaStatusFilters = (filter, currentTab) => {
    if (currentTab === PhaseTypesEnum.PROCESSING.index) {
        const formatData = formatProcessingFilterStatus(filter);
        return {
            isApproved: true,
            status: formatData,
        };
    }
    if (currentTab === PhaseTypesEnum.IN_TRANSIT.index) {
        const formatData = filter?.map((InTransitStatus) => ({
            planType: 'LOAD_PLAN_TYPE',
            status: formatIntransitFilterStatus(InTransitStatus),
        }));
        return {
            status: formatData,
        };
    }
    return null;
};

export const searchFilterReqPayload = (data, market, currentTab) => {
    const payload = {};
    const planDetails = {};
    const transitDetails = {};
    const equipment = {};
    const externalIdentifier = {};
    // if (data?.planId) {
    //   const planIds = data.planId.split(',').map((id) => (parseInt(id, 10)));
    //   if (planIds.length > 0) { payload.planIds = planIds; }
    // }

    if (data?.scacCode) {
        const carrScacs = data?.scacCode?.split(',');
        payload.carrier = carrScacs;
    }

    if (data?.dateType && data?.periodType) {
        payload.queryDates = getQueryDates(data);
    }

    const origin = getOriginInfo(data);
    const destination = getDestinationInfo(data);
    if (data?.originType?.length > 0) {
        payload.origins = data?.originType?.map((originType) => ({ locationType: originType, ...origin }));
    } else {
        payload.origins = Object.keys(origin).length > 0 ? [origin] : [];
    }

    if (data?.destinationType?.length > 0) {
        payload.destinations = data?.destinationType?.map((destinationType) => ({
            locationType: destinationType,
            ...destination,
        }));
    } else {
        payload.destinations = Object.keys(destination).length > 0 ? [destination] : [];
    }

    if (data?.equipmentConfigurationId) {
        equipment.equipmentCodes = data?.equipmentConfigurationId;
    }
    payload.equipment = equipment;
    // if (data?.equipmentId) planDetails.equipmentId = data?.equipmentId;

    if (data?.loadId) {
        const loadIds = data.loadId.split(',').map((id) => parseInt(id, 10));
        if (loadIds.length > 0) {
            payload.planIds = loadIds;
        }
    }
    if (data?.toId) {
        const numbers = data.toId.split(',').map((id) => parseInt(id, 10));
        if (numbers.length > 0) {
            externalIdentifier.deliveryOrderIds = numbers;
        }
    }
    if (data?.loadOwner) planDetails.owner = data?.loadOwner;
    if (data?.priority) planDetails.priority = data?.priority;
    if (!isNullOrUndefined(data?.hazmat)) planDetails.isHazmat = data?.hazmat;
    if (data?.ibob) planDetails.ibob = data?.ibob;
    if (data?.program) planDetails.programType = data?.program;
    if (data?.channel) planDetails.channelType = data?.channel;

    payload.planDetails = planDetails;

    if (data?.serviceClass) transitDetails.serviceClass = data?.serviceClass;
    if (data?.mode) transitDetails.mode = data?.mode;
    if (data?.serviceLevel) transitDetails.serviceLevel = data?.serviceLevel;
    if (data?.serviceType) transitDetails.serviceType = data?.serviceType;
    if (data?.temperatureControl) transitDetails.protectionLevel = data?.temperatureControl;

    payload.transitDetails = transitDetails;
    payload.externalIdentifier = externalIdentifier;
    if (
        (market === MarketCodeEnum.CANADA.code ||
            market === MarketCodeEnum.US.code ||
            market === MarketCodeEnum.USTRX.code) &&
        data?.status?.length > 0
    ) {
        const statusList = data?.status?.length ? getCaStatusFilters(data?.status, currentTab) : [];
        if (statusList?.status?.length > 0) {
            payload.status = statusList?.status;
            payload.selectedStatus = data?.status;
            if (statusList?.isApproved) payload.isApproved = statusList?.isApproved;
        }
    }
    // payload.page = 1;
    // if (data?.status && data?.status?.length) {
    //   payload.status = data.status.map((singleStatus) => ({
    //     planType: data?.planType,
    //     status: singleStatus,
    //   }));
    // }

    return payload;
};

const getSearchProfileReqPayload = (profile, market) => {
    const payload = {};
    const featureFlags = TripSharedService.getFeatureFlags();
    if (
        (market === MarketCodeEnum.CANADA.code ||
            market === MarketCodeEnum.US.code ||
            market === MarketCodeEnum.USTRX.code ||
            featureFlags?.tripProfile) &&
        profile?.preferences
    ) {
        const destinations = [];
        const origins = [];
        profile.preferences.forEach((element) => {
            const direction = element?.attributes.find((it) => it.field === 'DIRECTION')?.value;
            const locationId = element?.values.find((it) => it.field === 'id')?.value;
            if (direction === 'OUTBOUND' || direction === 'BOTH') {
                if (Array.isArray(locationId) && featureFlags?.tripProfile) {
                    for (let i = 0; i < locationId.length; i += 1) {
                        origins.push({
                            locationId: locationId[i],
                            locationType: element.parameter,
                        });
                    }
                } else {
                    origins.push({
                        locationId,
                        locationType: element.parameter,
                    });
                }
            }
            if (direction === 'INBOUND' || direction === 'BOTH') {
                if (Array.isArray(locationId) && featureFlags?.tripProfile) {
                    for (let i = 0; i < locationId.length; i += 1) {
                        destinations.push({
                            locationId: locationId[i],
                            locationType: element.parameter,
                        });
                    }
                } else {
                    destinations.push({
                        locationId,
                        locationType: element.parameter,
                    });
                }
            }
        });
        payload.origins = origins;
        payload.destinations = destinations;
    }
    return payload;
};

const searchPlanningReqPayload = (market, featureFlags) => {
    if (market === 'cl' || market === 'mx' || market === 'mx_mkp' || camMarkets.includes(market)) {
        return {
            ...(featureFlags?.fetchUnapprovedPlansInPlanning && { isApproved: false }),
            status: [
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'CREATED',
                },
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: 'UNPLANNED',
                },
            ],
        };
    }
    if (market === 'ca') {
        return {
            isApproved: false,
            status: [
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: 'PLANNED',
                },
            ],
        };
    }
};

const searchProcessingReqPayload = (market) => {
    if (market === 'cl' || market === 'mx' || market === 'mx_mkp' || camMarkets.includes(market)) {
        return {
            isApproved: true,
            status: [
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'CREATED',
                },
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'ASSIGNED',
                },
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'TENDERED',
                },
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'TENDER_ACCEPTED',
                },
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'TENDER_REJECTED',
                },
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'TENDER_CANCELED',
                },
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'NEED_ATTENTION',
                },
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'TENDER_TIMEOUT',
                },
            ],
        };
    }
    if (market === 'ca') {
        return {
            isApproved: true,
            status: CONST_FILTER_PROCESSING_DEFAULT_STATUS,
        };
    }
};

const searchDispatchReqPayload = (market) => {
    if (market === 'cl' || market === 'mx' || market === 'mx_mkp' || camMarkets.includes(market)) {
        return {
            status: [
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'READY_FOR_DISPATCH',
                },
            ],
        };
    }
    if (market === 'ca') {
        return {
            status: [
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: 'TENDER_ACCEPTED',
                },
            ],
        };
    }
};

const searchIntransitReqPayload = (market) => {
    if (market === 'cl' || market === 'mx' || market === 'mx_mkp' || camMarkets.includes(market)) {
        return {
            status: [
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'DISPATCHED',
                },
                {
                    planType: 'TRIP_PLAN_TYPE',
                    status: 'IN_TRANSIT',
                },
            ],
        };
    }
    if (market === 'ca') {
        return {
            status: [
                {
                    planType: 'LOAD_PLAN_TYPE',
                    status: 'IN_TRANSIT',
                },
            ],
        };
    }
};

const getAggsIndex = (planAggsIndex) => {
    const { hostname } = window.location;
    const env = getEnvironment({ hostname });
    return planAggsIndex?.[env] ? planAggsIndex?.[env] : '';
};

const getResponseGroup = (queryState) => {
    if (queryState?.globalSearchData) {
        if (queryState.searchByOption === GlobalSearchOption[0].id) {
            return ElasticBEQueryFieldsUSEnum.RESPONSE_GROUP_LOAD_WITH_TRIP_INFO;
        }
        if (queryState.searchByOption === GlobalSearchOption[1].id) {
            return ElasticBEQueryFieldsUSEnum.RESPONSE_GROUP;
        }
    }
    if (queryState.groupBy === groupByList[0].id) {
        return ElasticBEQueryFieldsUSEnum.RESPONSE_GROUP;
    }
    if (queryState.groupBy === groupByList[1].id) {
        return ElasticBEQueryFieldsUSEnum.RESPONSE_GROUP_LOAD_WITH_TRIP_INFO;
    }
    if (queryState.groupBy === groupByList[2].id) {
        return ElasticBEQueryFieldsUSEnum.RESPONSE_GROUP_IM;
    }
};
export const getTabRequestPayloadUS = (queryState, market, cmsConfig, featureFlags, userPerm) => {
    const payload = {};

    let dataQuery = getElasticRequestQuery(queryState, cmsConfig, market)?.toJSON();
    let aggPayload = searchAggregatesElasticQueryAll(queryState, market)?.toJSON();
    if (featureFlags?.enableDrayExtUserPerm && !userPerm?.canAccessNonDrayLoads) {
        dataQuery = {
            ...dataQuery,
            post_filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
        };
        aggPayload = {
            ...aggPayload,
            query: {
                bool: {
                    filter: getPlanCategoryTQ(false, PlanCategories.drayLoadTypes),
                },
            },
        };
    }
    if (featureFlags?.filterShadowModeEntities) {
        dataQuery = {
            ...dataQuery,
            query: {
                bool: {
                    ...dataQuery?.query?.bool,
                    must_not: getShadowModeExistsQuery(),
                },
            },
        };
        aggPayload = {
            ...aggPayload,
            query: {
                bool: {
                    ...aggPayload?.query?.bool,
                    must_not: getShadowModeExistsQuery(),
                },
            },
        };
    }
    payload.aggrQuery = {
        isNonVerboseResponse: true,
        index: getAggsIndex(cmsConfig?.planAggsIndex),
        searchQuery: aggPayload,
    };
    payload.dataQuery = {
        responseGroup: getResponseGroup(queryState),
        searchQuery: dataQuery,
    };

    return payload;
};
export const getPlanTableSearchRequestPayload = (queryState, market, cmsConfig, featureFlags, userPerm) => {
    const { activeTabIndex, filter, profile, timeHorizon, globalSearchData, multiSortFields, ...rest } = queryState;
    let tabStatuses = null;

    let request = {};
    if (market === MarketCodeEnum.US.code || market === MarketCodeEnum.USTRX.code) {
        const payload = getTabRequestPayloadUS(queryState, market, cmsConfig, featureFlags, userPerm);
        request = payload;
    } else {
        // for other markets
        if (queryState.activeTabIndex === PhaseTypesEnum.PLANNING.index) {
            tabStatuses = searchPlanningReqPayload(market, featureFlags, queryState);
        } else if (queryState.activeTabIndex === PhaseTypesEnum.PROCESSING.index) {
            tabStatuses = searchProcessingReqPayload(market, queryState);
        } else if (queryState.activeTabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) {
            tabStatuses = searchDispatchReqPayload(market, queryState);
        } else if (queryState.activeTabIndex === PhaseTypesEnum.IN_TRANSIT.index) {
            tabStatuses = searchIntransitReqPayload(market, queryState);
        }

        const profileRequestPayload = getSearchProfileReqPayload(profile, market);
        const filterRequestPayload = searchFilterReqPayload(filter, market, queryState?.activeTabIndex);
        request = {
            payload: {
                ...tabStatuses,
                ...filterRequestPayload,
                ...rest,
                // The origins and destination are present in profile takes higher precidence
                origins:
                    profileRequestPayload?.origins?.length > 0
                        ? profileRequestPayload?.origins
                        : filterRequestPayload.origins,
                destinations:
                    profileRequestPayload?.destinations?.length > 0
                        ? profileRequestPayload?.destinations
                        : filterRequestPayload.destinations,
            },
        };
        if (featureFlags?.showTotalCount) {
            request = {
                payload: {
                    ...request?.payload,
                    calculateSearchesResultCount: true,
                },
            };
        }
    }
    return request;
};
