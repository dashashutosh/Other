/* eslint-disable prefer-template */
import { getStopType, epochToIsoString } from '@walmart/stride-ui-commons';
export const PLAN_ENTITY_ENUM = {
    LOAD: 'LOAD',
    TRIP: 'TRIP',
};
export const getShortTimezoneAbbr = (olsenTimezoneId, timezones) => {
    if (!olsenTimezoneId || !Array.isArray(timezones)) return '';
    return timezones.find((timezone) => olsenTimezoneId === timezone.olsen_timezone_id)?.short_abbr || '';
};
const updateStopDetails = (stop, tnt) => {
    const stopDetails = {
        ...stop,
    };
    const inTransitDetails = tnt;
    if (stopDetails.eta) {
        stopDetails.eta = epochToIsoString(stop?.eta, inTransitDetails.stopTimezone);
    }
    if (stopDetails.etd) {
        stopDetails.etd = epochToIsoString(stop?.etd, inTransitDetails.stopTimezone);
    }
    if (inTransitDetails?.timeZone && stopDetails?.timeZone !== undefined) {
        delete stopDetails.timeZone;
    }
    return {
        ...stopDetails,
        ...inTransitDetails,
    };
};
const getPlannedStopDetails = (planDetailsResponse, staticData, featureFlags) =>
    planDetailsResponse?.stops
        ?.sort((stopA, stopB) => {
            if (stopA.stopSequenceNumber > stopB.stopSequenceNumber) {
                return 1;
            }
            if (stopA.stopSequenceNumber < stopB.stopSequenceNumber) {
                return -1;
            }
            return 0;
        })
        ?.map((stop) => {
            const { location } = stop;
            const timeZomeFromLtm = location.olsenTimezoneId ? location?.timeZoneCode : '';
            const timeZoneToShow = featureFlags?.enableShortTimezone
                ? getShortTimezoneAbbr(location.olsenTimezoneId, staticData?.shortTimezones)
                : timeZomeFromLtm;
            return {
                id: stop.stopSequenceNumber,
                type: getStopType(location.locationType),
                locationId: location?.locationId,
                locationType: location.locationType,
                title: location?.locationType + ' - ' + location?.locationId + ' - ' + location?.locationName,
                loadId: '',
                activities: [],
                timeZone: timeZoneToShow || '',
            };
        });
const getPlannedStopDetailsInTransit = (tntCore, staticData, featureFlags) => {
    const tntStopSequenceDetails = tntCore?.stops
        ?.sort((stopA, stopB) => {
            if (stopA.stopSeqNumber > stopB.stopSeqNumber) {
                return 1;
            }
            if (stopA.stopSeqNumber < stopB.stopSeqNumber) {
                return -1;
            }
            return 0;
        })
        ?.map((stop) => {
            const timeZoneToShow = featureFlags?.enableShortTimezone
                ? getShortTimezoneAbbr(stop.stopTimezone, staticData?.shortTimezones)
                : stop?.stopTimeZoneAbbr;
            return {
                stopSeqNumber: stop?.stopSeqNumber,
                ata: epochToIsoString(stop?.actual?.arrivalTs, stop?.stopTimezone) || '',
                atd: epochToIsoString(stop?.actual?.departureTs, stop?.stopTimezone) || '',
                arrivalEst: epochToIsoString(stop?.estimated?.arrivalTs, stop?.stopTimezone) || '',
                departEst: epochToIsoString(stop?.estimated?.departureTs, stop?.stopTimezone) || '',
                timeZone: timeZoneToShow || '',
                stopTimezone: stop?.stopTimezone,
            };
        });
    return tntStopSequenceDetails;
};
const getStopSequenceData = ({ planDetailsResponse, tntCoreResponse }, staticData, featureFlags) => {
    const tntStopDetails = tntCoreResponse
        ? getPlannedStopDetailsInTransit(tntCoreResponse, staticData, featureFlags)
        : {};
    const planStoDetails = getPlannedStopDetails(planDetailsResponse, staticData, featureFlags);
    const res = {
        stops: tntCoreResponse
            ? planStoDetails?.map((stop) => {
                  const inTransitDetails = tntStopDetails?.find((s) => s.stopSeqNumber === stop?.id);
                  return inTransitDetails?.stopTimezone ? updateStopDetails(stop, inTransitDetails) : stop;
              })
            : planStoDetails,
    };
    return res;
};
export const getLoadDetailsCA = (planResponse, staticData, featureFlags) => {
    const { planDetails, tntCore } = planResponse;
    const planDetailsResponse = planDetails.payload;
    const tntCoreResponse = tntCore?.trackingData?.[0] || {};
    return {
        planId: planDetailsResponse?.identifiers?.planId || '',
        stopSequence: getStopSequenceData(
            {
                planDetailsResponse,
                tntCoreResponse,
            },
            staticData,
            featureFlags,
        ),
    };
};
