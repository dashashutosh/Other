import { getTripDetails, getActionDesc } from '../TripDetailsMapper';
import { staticData } from './mocks/staticData.mock';
import {
    tripDetailslsMock,
    tripDetailsMockInTransit,
    stopFirst,
    firstInTransit,
    selectedRowsMock,
    actionMock,
} from './mocks/TripDetailsMapper.mock';

const trans = (str) => str;

const tripDetailsData = getTripDetails(tripDetailslsMock, trans, staticData);

describe('getStopSequenceSummary', () => {
    const { stops } = tripDetailsData.stopSequence;

    it('should return first stop', () => {
        expect(stops[0]).toEqual(stopFirst);
    });
});

const tripDetailsTnt = getTripDetails(tripDetailsMockInTransit, trans, staticData);

describe('getStopSequenceSummary In Transit', () => {
    const { stops } = tripDetailsTnt.stopSequence;

    it('should return first stop', () => {
        expect(stops[0]).toEqual(firstInTransit);
    });
});

describe('getActionDesc test cases', () => {
    it('should return mark printed when printed is falsy', () => {
        expect(getActionDesc(selectedRowsMock, actionMock)).toEqual('trip.action.mark.printed');
    });
    it('should return unmark printed when printed has a value', () => {
        expect(
            getActionDesc(
                [
                    {
                        ...selectedRowsMock[0],
                        printed: 'Printed',
                    },
                    {
                        ...selectedRowsMock[1],
                        printed: 'Printed',
                    },
                ],
                actionMock,
            ),
        ).toEqual('trip.action.unmark.printed');
    });
    it('should return mark/unmark printed when printed has a value for some trips and some trips dont', () => {
        expect(
            getActionDesc(
                [
                    {
                        ...selectedRowsMock[0],
                    },
                    {
                        ...selectedRowsMock[1],
                        printed: 'Printed',
                    },
                ],
                actionMock,
            ),
        ).toEqual('trip.action.mark.unmark.printed');
    });
});
