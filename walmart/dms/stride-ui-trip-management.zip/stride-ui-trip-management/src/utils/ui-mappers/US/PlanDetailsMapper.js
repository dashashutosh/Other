import {
    getLoadStatusFromSystems,
    epochToIsoString,
    isValidTimezoneIANAString,
    getStopType,
} from '@walmart/stride-ui-commons';
import TripSharedService from '../../../service/TripSharedService';
export const PLAN_ENTITY_ENUM = {
    LOAD: 'LOAD',
    TRIP: 'TRIP',
};
const getPlannedStopDetailsInTransit = (tntCore) => {
    const tntStopSequenceDetails = tntCore?.stops
        ?.sort((stopA, stopB) => {
            if (stopA.stopSeqNumber > stopB.stopSeqNumber) {
                return 1;
            }
            if (stopA.stopSeqNumber < stopB.stopSeqNumber) {
                return -1;
            }
            return 0;
        })
        ?.map((stop) => ({
            stopSeqNumber: stop?.stopSeqNumber,
            ata: epochToIsoString(stop?.actual?.arrivalTs, stop?.stopTimezone) || '',
            atd: epochToIsoString(stop?.actual?.departureTs, stop?.stopTimezone) || '',
            arrivalEst: epochToIsoString(stop?.estimated?.arrivalTs, stop?.stopTimezone) || '',
            departEst: epochToIsoString(stop?.estimated?.departureTs, stop?.stopTimezone) || '',
            timeZone: stop?.stopTimeZoneAbbr || '',
            stopTimezone: stop?.stopTimezone,
            status: stop?.status || '',
        }));
    return tntStopSequenceDetails;
};
export const getPlannedStopDetails = (planDetailsResponse, trans) =>
    planDetailsResponse?.stops
        ?.sort((stopA, stopB) => {
            if (stopA.stopSequenceNumber > stopB.stopSequenceNumber) {
                return 1;
            }
            if (stopA.stopSequenceNumber < stopB.stopSequenceNumber) {
                return -1;
            }
            return 0;
        })
        ?.map((stop) => {
            const { location } = stop;
            const isValidOlsenId = isValidTimezoneIANAString(location?.olsenTimezoneId);
            return {
                id: stop.stopSequenceNumber,
                type: getStopType(location.locationType),
                locationId: location?.locationId,
                locationType: location.locationType,
                title: location?.locationType + ' - ' + location?.locationId + ' - ' + location?.locationName,
                trackingId: planDetailsResponse?.identifiers?.planId || '',
                trackingIdType: PLAN_ENTITY_ENUM.LOAD,
                planSequenceNumber: planDetailsResponse?.planSequence || '',
                loadId: planDetailsResponse?.identifiers?.parentPlanId || '',
                activityType: stop?.stopActivityType ? trans('activityType.' + stop?.stopActivityType) : '',
                activities: [],
                timeZone: isValidOlsenId ? location?.timeZoneCode : '',
                appointmentNumber: stop?.schedulerDetails?.appointmentNbr,
            };
        });
const getStopSequenceData = ({ planDetailsResponse, tntCoreResponse }, trans, staticData) => {
    const tntStopDetails = tntCoreResponse ? getPlannedStopDetailsInTransit(tntCoreResponse) : {};
    const planStopDetails = getPlannedStopDetails(planDetailsResponse, trans, staticData);
    const res = {
        stops: tntCoreResponse
            ? planStopDetails?.map((stop) => {
                  const inTransitDetails = tntStopDetails?.find((s) => s.stopSeqNumber === stop?.id);
                  return inTransitDetails?.stopTimezone ? updateStopDetails(stop, inTransitDetails) : stop;
              })
            : planStopDetails,
    };
    return res;
};
const updateStopDetails = (stop, tnt) => {
    const stopDetails = {
        ...stop,
    };
    const inTransitDetails = tnt;
    if (inTransitDetails?.timeZone && stopDetails?.timeZone !== undefined) {
        delete stopDetails.timeZone;
    }
    return {
        ...stopDetails,
        ...inTransitDetails,
    };
};
const getLoadDetails = (planResponse, trans, staticData) => {
    const { planDetails, planTenderDetails, tracking, tntCore, etaDetails, trace } = planResponse;
    const planDetailsResponse = planDetails?.payload;
    const combinedPlanDetailsData = {
        planDetailsResponse,
        planTenderDetailsResponse: planTenderDetails,
        tntCoreResponse: tntCore?.trackingData?.[0] || {},
        etaDetails: tracking?.etaDetails || etaDetails,
        trace: tracking?.trace || trace,
    };
    const getCarrierAtLastIndex = (carriers) => carriers?.[carriers?.length - 1];
    const assignedCarrier =
        combinedPlanDetailsData.planTenderDetailsResponse?.carrier?.[
            combinedPlanDetailsData.planTenderDetailsResponse?.carrier?.length - 1
        ];
    // TODO: check mappings after API integration
    const planStatusProps = {
        loadType: combinedPlanDetailsData?.planDetailsResponse?.planCategory || '',
        loadStatus: combinedPlanDetailsData?.planDetailsResponse?.planStatus || '',
        tripId: combinedPlanDetailsData?.planDetailsResponse?.identifiers?.parentPlanId || '',
        isApproved: combinedPlanDetailsData?.planDetailsResponse?.isApproved || true,
        cstTenderStatus: combinedPlanDetailsData?.planTenderDetailsResponse?.planStatus || '',
        cstCarrierStatus: combinedPlanDetailsData?.planTenderDetailsResponse?.carrier?.length
            ? getCarrierAtLastIndex(combinedPlanDetailsData?.planTenderDetailsResponse?.carrier)?.status
            : '',
        carrierId: assignedCarrier?.scac,
        trailerId: combinedPlanDetailsData?.planDetailsResponse?.equipment?.equipmentId,
        tntPlanStatus: combinedPlanDetailsData?.tntCoreResponse?.planStatus || '',
        tntTransitStatus: combinedPlanDetailsData?.tntCoreResponse?.inTransitStatus || '',
        pickupTimeAtOrigin: combinedPlanDetailsData?.planDetailsResponse?.schedule?.minPickupTs
            ? new Date(combinedPlanDetailsData?.planDetailsResponse?.schedule?.minPickupTs)
            : null,
        featureFlags: TripSharedService.getFeatureFlags(),
    };
    const planDetailsStatus = getLoadStatusFromSystems(planStatusProps);
    return {
        planId: planDetailsResponse?.identifiers?.parentPlanId,
        statusUtils: planDetailsStatus,
        stopSequence: getStopSequenceData(combinedPlanDetailsData, trans, staticData),
    };
};
export default {
    getLoadDetails,
};
