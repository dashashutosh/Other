import { staticData } from './mocks/staticData.mock';
import PlanDetailsMapper from '../PlanDetailsMapper';
import { loadDetailslsMockUS, transformedStops } from './mocks/PlanDetailsMapper.mock';

const trans = (str) => str;

describe('getStopSequenceSummary', () => {
    it('should map stop sequence', () => {
        expect(
            PlanDetailsMapper.getLoadDetails(loadDetailslsMockUS.payload, trans, 'us', staticData, {}).stopSequence,
        ).toStrictEqual(transformedStops);
    });
});
