/* eslint-disable prefer-template */
import {
    getTripStatusFromSystems,
    epochToIsoString,
    isValidTimezoneIANAString,
    getStopType,
    getShortTzAbbrFromStaticData as getShortTimezoneAbbr,
} from '@walmart/stride-ui-commons';
import { getPlannedStopDetails } from './PlanDetailsMapper';
const getTripStatusProps = (tripDetailsResponse, tntCore) => {
    const sortedTntPlans = tntCore?.trackingData?.[0]?.plans?.sort((a, b) => a?.planSeqNumber - b?.planSeqNumber);
    return {
        tripType: tripDetailsResponse?.executionPlanCategory,
        tripStatus: tripDetailsResponse?.status,
        pickupTimeAtOrigin: tripDetailsResponse?.schedule?.minPickupTs
            ? new Date(tripDetailsResponse?.schedule?.minPickupTs)
            : null,
        driverId: tripDetailsResponse?.drivers?.length
            ? tripDetailsResponse?.drivers?.find((driver) => !!driver?.driverUserId)?.driverUserId
            : '',
        trailerId: tripDetailsResponse?.plans?.[0]?.equipment?.equipmentId || '',
        tntPlanStatus: tntCore?.trackingData?.[0]?.planStatus || '',
        tntTransitStatus: sortedTntPlans?.length ? sortedTntPlans[sortedTntPlans?.length - 1]?.inTransitStatus : '',
    };
};
const getUniqueLocation = (location) => {
    if (!location) return null;
    return `${location?.locationId}-${location?.locationType}`;
};

export const getActionDesc = (selectedRows, action) => {
    const allPrinted = selectedRows.every((row) => row.printed);
    const allNotPrinted = selectedRows.every((row) => !row.printed);
    if (allPrinted) {
        return action?.desc?.unmark_printed;
    }
    if (allNotPrinted) {
        return action?.desc?.mark_printed;
    }
    return action?.desc?.mark_unmark_printed;
};

// If a trip has driver assigned, stops should be derived from the activities.
// The logic is: sort the activities by activitySequenceNumber
// iterate activities find the unique locations and corresponding loads associated with that stop

// returns :
// [{ location: {}, loads: [], sequenceNumber: null, activities: [] }]
const getFormattedStopsFromActivities = (tripDetailsResponse) => {
    const formattedStops = []; // { location: {}, loads: [], sequenceNumber: null, activities: [] }
    const { activities, plans } = tripDetailsResponse;
    if (!Array.isArray(plans) || !plans.length || !Array.isArray(activities) || !activities.length) {
        return [];
    }
    const sortedActivities = activities?.sort((a, b) => a.stopSequenceNumber - b.stopSequenceNumber);
    let location;
    let sliceIndex = 0;
    let loads = [];
    sortedActivities.forEach((activity, index) => {
        if (activity?.location?.locationId && activity?.location?.locationType) {
            const currentLocation = getUniqueLocation(activity?.location);
            if (location && currentLocation !== getUniqueLocation(location)) {
                const formattedStop = {
                    stopLocation: {
                        ...location,
                    },
                    loads,
                    sequenceNumber: formattedStops?.length + 1,
                    activities: activities.slice(sliceIndex, index),
                };
                formattedStops.push(formattedStop);
                sliceIndex = index;
                location = activity?.location;
                loads = [];
            } else if (!location) {
                location = activity?.location;
            }
        }
        if (activity?.planIds && activity?.planIds[0] && loads.indexOf(activity?.planIds[0]) === -1) {
            loads.push(activity?.planIds[0]);
        }
        if (index === sortedActivities?.length - 1) {
            formattedStops.push({
                stopLocation: {
                    ...location,
                },
                loads,
                sequenceNumber: formattedStops?.length + 1,
                activities: activities.slice(sliceIndex, index + 1),
            });
        }
    });
    return formattedStops;
};

// stops and loads info will be given by getFormattedStopsFromActivities function
// other stop information should be derived from child plans array and movements
// For each trip stop recevied find the corresponding load stop from plans []
// Similarly find the corresponding movement by matching OD pair
const getStopsFromActivities = (tripDetailsResponse, staticData) => {
    const formattedStops = getFormattedStopsFromActivities(tripDetailsResponse);
    if (!Array.isArray(formattedStops) || !formattedStops.length) {
        return [];
    }
    const stops = [];
    formattedStops.forEach((sData) => {
        const { stopLocation, sequenceNumber } = sData;
        const isValidOlsenId = isValidTimezoneIANAString(stopLocation?.olsenTimezoneId);
        const timeZoneToShow =
            getShortTimezoneAbbr(stopLocation?.olsenTimezoneId, staticData?.shortTimezones) ||
            stopLocation?.timeZoneCode;
        const stop = {
            id: sequenceNumber,
            type: getStopType(stopLocation?.locationType),
            locationId: stopLocation?.locationId,
            locationType: stopLocation?.locationType,
            title: stopLocation?.locationType + ' - ' + stopLocation?.locationId + ' - ' + stopLocation?.locationName,
            timeZone: isValidOlsenId ? timeZoneToShow : '',
        };
        stops.push(stop);
    });
    return stops;
};
const updateStopDetails = (stop, tnt) => {
    const stopDetails = {
        ...stop,
    };
    const inTransitDetails = tnt;
    if (inTransitDetails?.timeZone && stopDetails?.timeZone !== undefined) {
        delete stopDetails.timeZone;
    }
    return {
        ...stopDetails,
        ...inTransitDetails,
    };
};
const getAllStopsFromMultipleLoads = (tntCore) => {
    const stops = [];
    if (Object.entries(tntCore).length > 0) {
        // eslint-disable-next-line no-unused-expressions
        tntCore?.plans.forEach((plan) => {
            plan.stops.forEach((stop) => {
                if (!stops.find((s) => s.stopId === stop?.stopId)) {
                    stops.push({
                        ...stop,
                        trackingId: plan?.trackingId,
                        trackingIdType: plan?.trackingIdType,
                        planSequenceNumber: plan?.planSeqNumber,
                    });
                }
            });
        });
    }
    return stops;
};
export const getPlannedStopDetailsInTransit = (tntCore, staticData) => {
    const stops = getAllStopsFromMultipleLoads(tntCore);
    const tntStopSequenceDetails = stops
        .sort((stopA, stopB) => {
            if (stopA.stopSeqNumber > stopB.stopSeqNumber) {
                return 1;
            }
            if (stopA.stopSeqNumber < stopB.stopSeqNumber) {
                return -1;
            }
            return 0;
        })
        ?.map((stop) => {
            const intransitStops = {
                stopSeqNumber: stop?.stopSeqNumber,
                ata: epochToIsoString(stop?.actual?.arrivalTs, stop?.stopTimezone) || '',
                atd: epochToIsoString(stop?.actual?.departureTs, stop?.stopTimezone) || '',
                arrivalEst: epochToIsoString(stop?.estimated?.arrivalTs, stop?.stopTimezone) || '',
                departEst: epochToIsoString(stop?.estimated?.departureTs, stop?.stopTimezone) || '',
                stopTimezone: stop?.stopTimezone,
                status: stop?.status || '',
                trackingId: stop?.trackingId,
                trackingIdType: stop?.trackingIdType,
                planSequenceNumber: stop?.planSequenceNumber,
            };
            if (stop?.stopTimeZoneAbbr) {
                intransitStops.timeZone =
                    getShortTimezoneAbbr(stop?.stopTimezone, staticData?.shortTimezones) || stop?.stopTimeZoneAbbr;
            }
            return intransitStops;
        });
    return tntStopSequenceDetails;
};
export const getTripDetails = (tripDetailsResponse, trans, staticData) => {
    if (!tripDetailsResponse) return {};
    const { dispatcherDetails, tntCore } = tripDetailsResponse;
    const tripDetails = dispatcherDetails?.payload;
    let isDriverAssigned;
    if (tripDetails && tripDetails?.drivers?.length && tripDetails?.drivers[0]?.driverId) {
        isDriverAssigned = true;
    }
    const statusProps = getTripStatusProps(tripDetails, tntCore);
    const statusUtils = getTripStatusFromSystems(statusProps);
    const tntCoreResponse = tntCore?.trackingData?.[0] || {};
    const tntStopDetails = tntCoreResponse ? getPlannedStopDetailsInTransit(tntCoreResponse, staticData) : {};

    // If driver is not assigned , display 1st load stops
    // If driver is assigned, trip stops should be derived from activties, plans [], movements
    // eslint-disable-next-line max-len
    const planStopDetails = isDriverAssigned
        ? getStopsFromActivities(tripDetails, staticData)
        : getPlannedStopDetails(tripDetails?.plans?.[0], trans, staticData);
    const stopsList = tntCoreResponse
        ? planStopDetails?.map((stop) => {
              const inTransitDetails = tntStopDetails?.find((s) => s.stopSeqNumber === stop?.id);
              return inTransitDetails?.stopTimezone ? updateStopDetails(stop, inTransitDetails) : stop;
          })
        : planStopDetails;
    return {
        statusUtils,
        stopSequence: {
            stops: stopsList,
        },
    };
};
