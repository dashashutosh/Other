import { Moment as moment } from '@gscope-mfe/common-libs';
import {
    formatErrors,
    MarketCodeEnum,
    PlanPhaseEnum,
    EntityTypeEnum,
    CommentTypeEnum,
} from '@walmart/stride-ui-commons';
import { deliveryPhaseSecText } from '../component/trip-management-summary/US/DataModelsUS';
import {
    camCountries,
    commentEntities,
    HUB_DEC_LOAD_TYPES,
    HUB_DEC_RETURN_LOAD_TYPES,
    TABLE_ACTIONS_ENUM,
    SHORTENED_EXTENDED_DATE_TIME,
} from '../Constants';
import PhaseTypesEnum from './enums/PhaseTypesEnum';
import TripSharedService from '../service/TripSharedService';
import LoadUIStatusEnum from '../component/model/loadUiStatusEnum';
export const transformMultiInputStringValue = (value) =>
    value ? value.split('\t').join(' ').split(' ').join(',').split(',') : [];
const concatErrors = (accumulator, e, index, errorList) =>
    e?.description ? `${accumulator}${e?.description}${index === errorList.length - 1 ? '' : '\n'}` : accumulator;
const concatInfoErrors = (accumulator, e, index, errorList) =>
    e?.info ? `${accumulator}${e?.info}${index === errorList.length - 1 ? '' : '\n'}` : accumulator;
const concatSeqErrors = (accumulator, e, index, errorList) =>
    e?.planId
        ? `${accumulator}${e?.planId}: ${e?.errMessage}${index === errorList.length - 1 ? '' : '\n'}`
        : accumulator;
export const formatTripErrors = (error) => {
    if (error?.code === 'ECONNABORTED') {
        return {
            key: 'API.error.timeout',
        };
    }
    if (error?.httpStatusCode === 200) {
        const errorText = error?.errors?.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.notFound',
            }
        );
    }
    if (error?.status === 'FAIL') {
        if (Array.isArray(error?.errors) && error?.errors?.length > 0 && error?.errors[0]?.description) {
            const errorText = error?.errors.reduce(concatErrors, '');
            return (
                errorText || {
                    key: 'API.error.notFound',
                }
            );
        }
    }
    if (Array.isArray(error?.errors) && Array.isArray(error?.errors[0]?.errorIdentifiers?.details?.errors)) {
        const errorList = error?.errors[0]?.errorIdentifiers?.details?.errors || [];
        const errorText = errorList.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && Array.isArray(error?.errors[0]?.errorIdentifiers?.details?.messages)) {
        const errorList = error?.errors[0]?.errorIdentifiers?.details?.messages || [];
        const errorText = errorList.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && Array.isArray(error?.errors[0]?.errorIdentifiers?.details[0]?.messagesDTO)) {
        const errorList = error?.errors[0]?.errorIdentifiers?.details[0]?.messagesDTO || [];
        const errorText = errorList.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && Array.isArray(error?.errors[0]?.errorIdentifiers?.details[0]?.messages)) {
        const errorList = error?.errors[0]?.errorIdentifiers?.details[0]?.messages || [];
        const errorText = errorList.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && error?.errors[0]?.errorIdentifiers?.details?.carrierSearch?.error) {
        const errorText = error?.errors[0]?.errorIdentifiers?.details?.carrierSearch?.error || '';
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && error?.errors[0]?.errorIdentifiers?.details?.dispatchSearch?.error) {
        const errorText = error?.errors[0]?.errorIdentifiers?.details?.dispatchSearch?.error || '';
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && error?.errors[0]?.errorIdentifiers?.details?.tripManagementSearch?.error) {
        const errorText = error?.errors[0]?.errorIdentifiers?.details?.tripManagementSearch?.error || '';
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && error?.errors[0]?.errorIdentifiers?.details?.carrier_info?.message) {
        const errorText = error?.errors[0]?.errorIdentifiers?.details?.carrier_info?.message || '';
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (
        Array.isArray(error?.errors) &&
        Array.isArray(error?.errors[0]?.errorIdentifiers?.details?.resource_info?.messages)
    ) {
        const errorList = error?.errors[0]?.errorIdentifiers?.details?.resource_info?.messages || [];
        const errorText = errorList.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && error?.errors[0]?.errorIdentifiers?.details?.payload?.message) {
        const errorText = error?.errors[0]?.errorIdentifiers?.details?.payload?.message || '';
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }

    // Bulk actions error handler
    if (Array.isArray(error) && error?.length > 0 && error?.[0]?.planId && error?.[0]?.errMessage) {
        const errorText = error.reduce(concatSeqErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (Array.isArray(error?.errors) && error?.errors[0]?.errorIdentifiers?.details?.error) {
        const errorText = error?.errors[0]?.errorIdentifiers?.details?.error || '';
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (error?.error) {
        // backend not reachable
        return error.error;
    }
    if (error?.key) {
        // UI error like validation
        return error;
    }
    if (Array.isArray(error?.errors) && error?.errors?.length > 0 && error?.errors[0].info) {
        const errorText = error?.errors.reduce(concatInfoErrors, '');
        return (
            errorText || {
                key: 'API.error.notFound',
            }
        );
    }
    // for US TSS
    if (
        Array.isArray(error?.errors) &&
        Array.isArray(error?.errors[0]?.errorIdentifiers?.details?.data?.details?.messages)
    ) {
        const errorList = error?.errors[0]?.errorIdentifiers?.details?.data?.details?.messages || [];
        const errorText = errorList.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    if (
        Array.isArray(error?.errors) &&
        Array.isArray(error?.errors[0]?.errorIdentifiers?.details?.aggregates?.details?.messages)
    ) {
        const errorList = error?.errors[0]?.errorIdentifiers?.details?.aggregates?.details?.messages || [];
        const errorText = errorList.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    return {
        key: 'API.error.invalid',
    };
};
export const getFormattedTripError = (data, trans) => {
    const error = formatTripErrors(data);
    return error?.key ? trans(error?.key) : error;
};

// const concatCRErrors = (accumulator, e, index, errorList) => (e?.description ? `${accumulator}
// ${e?.field} : ${e?.description}${index === errorList.length - 1 ? '' : '\n'}` : accumulator);
export const formatAssignErrors = (error) => {
    if (error?.code === 'ECONNABORTED') {
        return {
            key: 'API.error.timeout',
        };
    }
    if (Array.isArray(error?.errors)) {
        const errorList = error?.errors || [];
        const errorText = errorList.reduce(concatErrors, '');
        return (
            errorText || {
                key: 'API.error.invalid',
            }
        );
    }
    return {
        key: 'API.error.invalid',
    };
};
export const errorHandler = (error) => {
    if (error?.errors) {
        // backend API failed
        return error;
    }
    // GSCOPE API failed
    return {
        key: 'pageError.summary.noService',
    };
};
export const getTimezoneFromIsoDateString = (date) => {
    const tzNames = moment.tz.names();
    const map = new Map();
    tzNames.forEach((name) => {
        const { offsets } = moment.tz.zone(name);
        offsets.forEach((offset) => {
            if (!map.has(offset)) {
                map.set(offset, new Set());
            }
            map.get(offset).add(name);
        });
    });
    const currentOffset = moment(date).utcOffset();
    const offsetList = map.get(currentOffset);
    let timezone = '';
    offsetList.forEach((item) => {
        timezone = moment().tz(item.toString()).zoneAbbr();
    });
    return timezone;
};
export const FORCE_TO_DELIVERED = {
    label: 'forceToDelivered.lable',
    cancel: 'forceToDelivered.cancel',
    confirm: 'forceToDelivered.confirm',
    translation: {
        arrivalLabel: 'forceToDelivered.arrivalTitle',
        departLabel: 'forceToDelivered.departTitle',
        losSelectLabel: 'forceToDelivered.losSelectTitle',
    },
};
export const getErrorText = (data, trans, options = { concatDesc: false }) => {
    const { concatDesc } = options;
    if (typeof data === 'string' || data instanceof String) {
        return data;
    }
    const error = formatErrors(data, { concatDesc });
    return error?.key ? trans(error?.key) : error;
};
export const getPlanErrorText = (data, trans) => {
    if (typeof data === 'string' || data instanceof String) {
        return data;
    }
    const error = formatTripErrors(data);
    return error?.key ? trans(error?.key) : error;
};
export const isChile = (market) => market === MarketCodeEnum.CHILE.code;
export const isCAM = (market) => camCountries.includes(market);
export const convertDocObjectBaseToBlob = (base64) => {
    const byteCharacters = atob(base64);
    const sliceSize = 512;
    const byteArrays = [];
    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
        const slice = byteCharacters.slice(offset, offset + sliceSize);
        const byteNumbers = new Array(slice.length);
        /* eslint-disable-next-line no-plusplus */
        for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }
    return new Blob(byteArrays);
};
export const validateTripSelectionForCAM = (loadInfo, tripInfo) => {
    let isValid = false;
    if (loadInfo.equipmentCode === tripInfo.plans[0].equipmentCode) {
        isValid = true;
    } else {
        isValid = false;
    }
    return isValid;
};
export const getShortTimezoneAbbr = (olsenTimezoneId, timezones) => {
    if (!olsenTimezoneId || !Array.isArray(timezones)) return '';
    return timezones.find((timezone) => olsenTimezoneId === timezone.olsen_timezone_id)?.short_abbr || '';
};
export const InitialSecondayTextForTabs = ['', '', '', '', ''];
export const getSecondaryTextForTabs = (market, trans, queryState) => {
    if (market === MarketCodeEnum.US.code || market === MarketCodeEnum.USTRX.code) {
        return ['', '', '', trans('timehorizon.label.all'), deliveryPhaseSecText(queryState, trans)];
    }
    return InitialSecondayTextForTabs;
};
export const forceLoadToDeliverModalTranslations = (isPhaseNameSame, trans) => {
    const forceDeliTrans = {
        arrivalLabel: trans('forceToDelivered.arrivalTitle'),
        departLabel: trans('forceToDelivered.departTitle'),
        losSelectLabel: trans('forceToDelivered.losSelectTitle'),
        stopLabel: trans('forceToDelivered.stopTitle'),
        arrivalAndDepartureLabel: trans('forceToDelivered.arrivalAndDepartureTitle'),
        losArrivalSelectLabel: trans('forceToDelivered.losArrivalSelectTitle'),
        losDepartureSelectLabel: trans('forceToDelivered.losDepartureSelectTitle'),
        cancelText: trans('forceToDelivered.cancel'),
        confirmText: trans('forceToDelivered.confirm'),
        modalTitle: trans('forceToDelivered.lable'),
        dateNotEmptyValidationMsg: trans('stops.error.dateNotEmptyValidation'),
        dateGreaterThanValidationMsg: trans('stops.error.dateGreaterThanValidation'),
        dateSequenceValidationMsg: trans('stops.error.dateSequenceValidation'),
        noteTripStatusText: trans('forceToDelivered.noteLoadStatusTextReadyToStart'),
        noteInTransitStatusText: trans('forceToDelivered.noteInTransitLoadStatusText'),
        noteDeleveredStatusText: trans('forceToDelivered.noteDeleveredLoadStatusText'),
        successMessage: trans('forceToDelivered.success.message'),
        errorMessage: trans('forceToDelivered.error.message'),
    };
    if (isPhaseNameSame) {
        forceDeliTrans.noteTripStatusText = trans('forceToDelivered.noteLoadStatusTextInTransit');
        forceDeliTrans.noteInTransitStatusText = '';
    }
    return forceDeliTrans;
};
export const checkPlanODSame = (plans) => {
    try {
        const origin = plans.filter((p) => p.originId !== plans[0].originId);
        if (origin.length > 0) {
            return false;
        }
        const destination = plans.filter((p) => p.destinationId !== plans[0].destinationId);
        if (destination.length > 0) {
            return false;
        }
        const type = plans.filter((p) => p.planType !== plans[0].planType);
        if (type.length > 0) {
            return false;
        }
        return true;
    } catch (e) {
        return false;
    }
};

export const checkPlanOriginSame = (plans) => {
    try {
        const origin = plans.filter((p) => p.originId !== plans[0].originId);
        if (origin.length > 0) {
            return true;
        }
        return false;
    } catch (e) {
        return true;
    }
};
export const checkPlanDestinationSame = (plans) => {
    try {
        const destination = plans.filter((p) => p.destinationId !== plans[0].destinationId);
        if (destination.length > 0) {
            return true;
        }
        return false;
    } catch (e) {
        return true;
    }
};
export const getPlanStatusList = (planType, planStatus) => {
    let status = [];
    if (planStatus && planStatus?.length) {
        switch (planType) {
            case PhaseTypesEnum.PLANNING.index:
                status = planStatus.filter((type) => type.type === PlanPhaseEnum.PLANNING.name);
                return [...status];
            case PhaseTypesEnum.PROCESSING.index:
                status = planStatus.filter((type) => type.type === PlanPhaseEnum.PROCESSING.name);
                return [...status];
            case PhaseTypesEnum.DISPATCH_PENDING.index:
                status = planStatus.filter((type) => type.type === PlanPhaseEnum.READY_TO_START.name);
                return [...status];
            case PhaseTypesEnum.IN_TRANSIT.index:
                status = planStatus.filter((type) => type.type === PlanPhaseEnum.IN_TRANSIT.name);
                return [...status];
            default:
                return [];
        }
    }
};
export const getValidationError = (formValue, filterCount) => {
    if (formValue.status && formValue.status?.length && filterCount === 1) {
        const err = 'onlyStatusError';
        return err;
    }
    return '';
};

export const getUsUsTenantFlagValue = (market, isMdmServiceCall) => {
    switch (market.toLowerCase()) {
        case MarketCodeEnum.US.code:
            return true;
        case MarketCodeEnum.USTRX.code:
            if (isMdmServiceCall) return true;
            return false;
        case MarketCodeEnum.CANADA.code:
        case MarketCodeEnum.CHILE.code:
        case MarketCodeEnum.GUATEMALA.code:
        case MarketCodeEnum.MEXICO.code:
        case MarketCodeEnum.MEXICO_MARKET_PLACE.code:
            return false;
        default:
            break;
    }
    return true;
};

export const isHubstrOrDecstrTripLoad = (tripLoadData) => {
    const { tripData, sLoadInfo } = tripLoadData;
    if (tripData && sLoadInfo) {
        if (tripData?.plans?.length) {
            const { referenceLoadType } = tripData?.plans[0];
            return (
                HUB_DEC_RETURN_LOAD_TYPES.includes(sLoadInfo?.referenceLoadType) &&
                HUB_DEC_LOAD_TYPES.includes(referenceLoadType)
            );
        }
    }
    return false;
};

export const getCommentsDrawerProps = (planDetails) => {
    const commentsDrawyerInput = {
        pSelectedPlan: {
            planId: planDetails?.planId,
            planType: planDetails?.planEntity,
            tripId: planDetails?.tripId,
        },
        pLoadIds: planDetails?.loadIds,
        pCommentEntites: [],
        pFilterEntities: [],
    };

    const commentEntities = {
        load: {
            id: EntityTypeEnum.LOAD.desc,
            value: EntityTypeEnum.LOAD.desc,
            disabled: false,
        },
        trip: {
            id: EntityTypeEnum.TRIP.desc,
            value: EntityTypeEnum.TRIP.desc,
            disabled: false,
        },
    };
    commentsDrawyerInput.pDefaultCommentEntitySelected = EntityTypeEnum.TRIP.desc;
    if (planDetails?.isTrip) {
        if (!commentsDrawyerInput?.pLoadIds?.length) {
            commentEntities.load.disabled = true;
            commentsDrawyerInput.pDefaultCommentEntitySelected = EntityTypeEnum.TRIP.desc;
        }
    } else {
        if (!planDetails?.tripId) {
            commentEntities.trip.disabled = true;
            commentsDrawyerInput.pDefaultCommentEntitySelected = EntityTypeEnum.LOAD.desc;
        }
    }
    commentsDrawyerInput.pCommentEntites.push(commentEntities.trip, commentEntities.load);
    commentsDrawyerInput.pFilterEntities = [
        {
            id: 'All',
            value: 'All',
            disabled: false,
        },
        {
            id: 'Trip',
            value: 'Trip',
            disabled: false,
        },
        {
            id: 'Load',
            value: 'Load',
            disabled: false,
        },
    ];
    commentsDrawyerInput.pComments = planDetails?.combinedComments;
    commentsDrawyerInput.pDefaultFilterEntity = 'All';
    return commentsDrawyerInput;
};

export const getTableActions = (tripStatus, maxRows = 5, checkedRows = [], tabIndex) => {
    const actions = [];
    if (checkedRows?.length > maxRows || checkedRows?.length === 0) {
        return actions;
    }
    const { trans, getFeatureFlags } = TripSharedService;
    if (tabIndex === PhaseTypesEnum.PLANNING.index) {
        const action = TABLE_ACTIONS_ENUM.APPROVE_LOAD;
        actions.push({ ...action, desc: trans(action.desc) });
        if (getFeatureFlags()?.enableMultiLoadCancel) {
            const action = TABLE_ACTIONS_ENUM.CANCEL_LOAD;
            actions.push({ ...action, desc: trans(action.desc) });
        }
    }

    if (tabIndex === PhaseTypesEnum.PROCESSING.index) {
        if (
            tripStatus?.name === LoadUIStatusEnum.TENDERS_EXHAUSTED.name ||
            tripStatus?.name === LoadUIStatusEnum.TENDER_CANCELLED.name ||
            tripStatus?.name === LoadUIStatusEnum.NEEDS_ATTENTION.name
        ) {
            if (
                (getFeatureFlags()?.enableMultiLoadAssignment && checkedRows?.length > 0) ||
                checkedRows?.length === 1
            ) {
                const action = TABLE_ACTIONS_ENUM.ASSIGN_CARRIER_AUTO;
                actions.push({ ...action, desc: trans(action.desc) });
            }
            if (getFeatureFlags()?.enableMultiLoadCancel) {
                const action = TABLE_ACTIONS_ENUM.CANCEL_LOAD;
                actions.push({ ...action, desc: trans(action.desc) });
            }
        }

        if (tripStatus?.name === LoadUIStatusEnum.TENDER_CANCELLED.name) {
            const action = TABLE_ACTIONS_ENUM.TENDER_AUTO;
            actions.push({ ...action, desc: trans(action.desc) });
        }
    }
    if (tabIndex === PhaseTypesEnum.DISPATCH_PENDING.index) {
        if (checkedRows?.length === 1) {
            const action = TABLE_ACTIONS_ENUM.FORCE_LOAD_TO_DELIVERED;
            actions.push({ ...action, desc: trans(action.desc) });
        }
        if (getFeatureFlags()?.enableMultiWithdrawTender) {
            const action = TABLE_ACTIONS_ENUM.WITHDRAW_TENDER;
            actions.push({ ...action, desc: trans(action.desc) });
        }
        if (getFeatureFlags()?.enableMultiLoadCancel) {
            const action = TABLE_ACTIONS_ENUM.CANCEL_LOAD;
            actions.push({ ...action, desc: trans(action.desc) });
        }
    }

    if (tabIndex === PhaseTypesEnum.IN_TRANSIT.index) {
        if (checkedRows?.length === 1) {
            const action = TABLE_ACTIONS_ENUM.FORCE_LOAD_TO_DELIVERED;
            actions.push({ ...action, desc: trans(action.desc) });
        }
        if (getFeatureFlags()?.enableMultiWithdrawTender) {
            const action = TABLE_ACTIONS_ENUM.WITHDRAW_TENDER;
            actions.push({ ...action, desc: trans(action.desc) });
        }
    }

    if (getFeatureFlags()?.enableAddMultiComment) {
        const action = TABLE_ACTIONS_ENUM.ADD_MULTI_COMMENT;
        actions.push({ ...action, desc: trans(action.desc) });
    }

    return actions;
};

export const getCommentsConfigurations = (featureFlags, isMultiSelect) => {
    if (featureFlags?.enableAddMultiComment) {
        return {
            hideSearchFilter: true,
            filterByCommentType: true,
            enableCommentTypeDropDown: true,
            hideEntityType: true,
            enableCommentRestriction: true,
            hideFilterComponent: isMultiSelect,
            hideCommentList: isMultiSelect,
        };
    }
    return {};
};

export const getCommentsDrawerPropsV2 = (planDetails, isMultiSelect, trans) => {
    const commentsDrawyerInput = {
        pSelectedPlan: {
            planId: isMultiSelect ? '' : planDetails?.[0]?.planId || '',
            planType: isMultiSelect ? trans('label.multiplePlansSelect') : planDetails?.[0]?.planEntity,
        },
        pFilterEntities: [...commentEntities],
        pMaxCharacters: 150,
        pLoadIds: planDetails?.map((plan) => plan?.planId),
    };

    commentsDrawyerInput.pComments = planDetails?.[0]?.comments?.length
        ? planDetails[0].comments.map((comment) => ({
              ...comment,
              entityType: EntityTypeEnum.LOAD.desc,
              commentBy: comment?.createdByUserId,
              commentByDisplayName: comment?.createdByUserName || comment?.createdByUserId || '',
              uniqueId: comment?.commentId,
              entityId: planDetails?.[0]?.planId,
              commentType: comment?.commentType || '',
              commentTimestamp: comment?.createdTs
                  ? moment(new Date(comment?.createdTs)).format(SHORTENED_EXTENDED_DATE_TIME)
                  : '',
              tags: [CommentTypeEnum?.[comment?.commentType]?.desc || ''],
          }))
        : [];

    commentsDrawyerInput.pCommentTypes = [...commentEntities].splice(1);
    commentsDrawyerInput.pDefaultFilterEntity = commentEntities[0].id;
    commentsDrawyerInput.pDefaultCommentEntitySelected = EntityTypeEnum.LOAD.desc;

    return commentsDrawyerInput;
};

export const formatCancelTripActionRequest = (planId, reason) => ({
    payload: {
        ids: planId,
        reason,
        status: 'CANCELLED',
    },
});

export const formatErrorListFromResponse = (errorList) =>
    errorList?.map((error) => ({
        errMessage: error?.description,
        planId: error?.field,
    })) || [];
