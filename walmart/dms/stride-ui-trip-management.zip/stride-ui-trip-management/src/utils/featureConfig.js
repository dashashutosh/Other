import { PlanScreenEnum, UILoadTypeEnum } from '@walmart/stride-ui-commons';

const featureConfig = (featureFlags, pConfigs) => {
    const config = {
        screen: PlanScreenEnum.LIFECYCLE.code,
        enablePaperPrint: featureFlags?.enablePaperPrint,
        enableHazmatUpdate: featureFlags?.enableHazmatUpdate,
        enableDrayExtUserPerm: featureFlags?.enableDrayExtUserPerm,
        enableTrailerIdEdit: featureFlags?.enableTrailerIdEdit,
        enableOdometerEdit: featureFlags?.enableOdometerEdit,
        disableActionsForOBLoadTypes: featureFlags?.disableActionsForOBLoadTypes,
        showStopSequenceAudit: featureFlags?.showStopSequenceAudit,
        enablePrintTripSheet: featureFlags?.enablePrintTripSheet,
        filterShadowModeEntities: featureFlags?.filterShadowModeEntities,
        hazmatUpdateAllowedPlanTypes: pConfigs?.hazmatUpdateAllowedPlanTypes || [],
        losStaticDataV2: featureFlags?.losStaticDataV2,
        enableEditDriverETD: featureFlags?.enableEditDriverETD,
        enableMarkServiceFailureForDray: featureFlags?.enableMarkServiceFailureForDray,
        enableHoldTag: featureFlags?.enableHoldTag,
        WTMSLoadlength: pConfigs?.WTMSLoadlength || 0,
        WTMSLoadSeries: pConfigs?.WTMSLoadSeries || [],
        WTMSCreatedSourceSystem: pConfigs?.WTMSCreatedSourceSystem || '',
        enableWTMSLoadStatus: featureFlags?.enableWTMSLoadStatus,
    };
    return config;
};

export default featureConfig;
