import { phasesForAggsEnum } from '../../Constants';

class PhaseTypesEnum {
    static PLANNING = new PhaseTypesEnum(
        '1',
        'tab.planning',
        0,
        ['ca', 'cl', 'gt', 'cr', 'sv', 'mx', 'mx_mkp', 'us', 'ustrx'],
        {
            ca: 'PLAN_DEPARTURE_TS',
            cl: 'PLAN_CREATED_TIME',
            us: { id: 'PLANNED_START', sortField: 'schedule_min_pickup_ts', desc: false },
            mx: 'PLAN_CREATED_TIME',
            mx_mkp: 'PLAN_CREATED_TIME',
        },
        phasesForAggsEnum.PLANNING,
    );
    static PROCESSING = new PhaseTypesEnum(
        '2',
        'tab.processing',
        1,
        ['ca', 'cl', 'gt', 'cr', 'sv', 'mx', 'mx_mkp', 'us', 'ustrx'],
        {
            ca: 'PLAN_DEPARTURE_TS',
            cl: 'PLAN_CREATED_TIME',
            us: { id: 'PLANNED_START', sortField: 'schedule_min_pickup_ts', desc: false },
            mx: 'PLAN_CREATED_TIME',
            mx_mkp: 'PLAN_CREATED_TIME',
        },
        phasesForAggsEnum.PROCESSING,
    );
    static DISPATCH_PENDING = new PhaseTypesEnum(
        '',
        'tab.dispatchPending',
        2,
        ['cl', 'gt', 'cr', 'sv', 'mx', 'mx_mkp'],
        {
            cl: 'PLAN_CREATED_TIME',
            mx: 'PLAN_CREATED_TIME',
            mx_mkp: 'PLAN_CREATED_TIME',
        },
        phasesForAggsEnum.DISPATCH_PENDING,
    );
    static READY_TO_START = new PhaseTypesEnum(
        '3',
        'tab.readyToStart',
        2,
        ['ca', 'us', 'ustrx'],
        {
            ca: 'PLAN_DEPARTURE_TS',
            us: { id: 'PLANNED_START', sortField: 'schedule_min_pickup_ts', desc: false },
        },
        phasesForAggsEnum.READY_TO_START,
    );
    static IN_TRANSIT = new PhaseTypesEnum(
        '4',
        'tab.inTransit',
        3,
        ['ca', 'cl', 'gt', 'cr', 'sv', 'mx', 'mx_mkp', 'us', 'ustrx'],
        {
            ca: 'PLAN_ARRIVAL_TS',
            cl: 'PLAN_CREATED_TIME',
            us: { id: 'ACTUAL_START', sortField: 'ep_tnt_actual_start_ts', desc: false },
            mx: 'PLAN_CREATED_TIME',
            mx_mkp: 'PLAN_CREATED_TIME',
        },
        phasesForAggsEnum.IN_TRANSIT,
    );
    static DELIVERED = new PhaseTypesEnum(
        '5',
        'tab.delivered',
        4,
        ['us', 'ustrx'],
        {
            us: { id: 'ACTUAL_START', sortField: 'ep_tnt_actual_start_ts', desc: false },
        },
        phasesForAggsEnum.DELIVERED,
    );
    constructor(code, desc, index, markets, defaultSortField, fieldBE) {
        this.code = code;
        this.desc = desc;
        this.index = index;
        this.markets = markets;
        this.defaultSortField = defaultSortField;
        this.fieldBE = fieldBE;
        Object.freeze(this);
    }
}
export default PhaseTypesEnum;
