class PermissionsEnum {
    static READ = new PermissionsEnum('READ', '1');
    static WRITE = new PermissionsEnum('WRITE', '2');
    static RATE_READ = new PermissionsEnum('RATE_READ', '3');
    static DRAY_EXTERNAL_USERS = new PermissionsEnum('DRAY_EXTERNAL_USERS', '4');

    constructor(code, index) {
        this.code = code;
        this.index = index;
        Object.freeze(this);
    }
}
export default PermissionsEnum;
