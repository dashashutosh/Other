export default class PlanStatusEnum {
    static PENDING_APPROVAL = new PlanStatusEnum('PENDING_APPROVAL', 0);
    static UNPLANNED = new PlanStatusEnum('UNPLANNED', 1);
    static WORKLOAD_ASSIGNMENT = new PlanStatusEnum('WORKLOAD_ASSIGNMENT', 2);
    static AWAITING_FINALIZATION = new PlanStatusEnum('AWAITING_FINALIZATION', 3);
    static READY_FOR_DISPATCH = new PlanStatusEnum('READY_FOR_DISPATCH', 4);
    static APPROVED = new PlanStatusEnum('APPROVED', 5);
    static IN_TRANSIT = new PlanStatusEnum('IN_TRANSIT', 6);
    static DISPATCH = new PlanStatusEnum('DISPATCHED', 7);
    static DELIVERED = new PlanStatusEnum('DELIVERED', 8);
    static CREATED = new PlanStatusEnum('CREATED', 9);
    static PLANNED = new PlanStatusEnum('PLANNED', 10);

    // For CA market

    static PENDING_APPROVAL_LOAD = new PlanStatusEnum('PENDING_APPROVAL', 11);
    static AWAITING_CARRIER_ASSIGNMENT = new PlanStatusEnum('AWAITING_CARRIER_ASSIGNMENT', 12);
    static TENDER_IN_PROGRESS = new PlanStatusEnum('TENDER_IN_PROGRESS', 13);
    static TENDERS_EXHAUSTED = new PlanStatusEnum('TENDERS_EXHAUSTED', 14);
    static TENDER_CANCELLED = new PlanStatusEnum('TENDER_CANCELLED', 15);
    static PICKUP_DELAYED = new PlanStatusEnum('NOT_STARTED_AT_RISK', 16);
    static AWAITING_PICKUP = new PlanStatusEnum('NOT_STARTED_ON_TIME', 17);
    static IN_TRANSIT_STARTED = new PlanStatusEnum('IN_TRANSIT_STARTED', 18);
    static IN_TRANSIT_EARLY = new PlanStatusEnum('IN_TRANSIT_EARLY', 19);
    static IN_TRANSIT_ON_TIME = new PlanStatusEnum('IN_TRANSIT_ON_TIME', 20);
    static IN_TRANSIT_LATE = new PlanStatusEnum('IN_TRANSIT_LATE', 21);
    static TENDERED = new PlanStatusEnum('TENDERED', 22);
    static TENDER_REJECTED = new PlanStatusEnum('TENDER_REJECTED', 23);
    static TENDER_TIMEOUT = new PlanStatusEnum('TENDER_TIMEOUT', 24);
    static NEED_ATTENTION = new PlanStatusEnum('NEED_ATTENTION', 24);
    static TENDER_CANCELED = new PlanStatusEnum('TENDER_CANCELED', 25);
    static TENDER_DECLINED = new PlanStatusEnum('TENDER_DECLINED', 26);
    static TENDER_EXHAUSTED = new PlanStatusEnum('TENDER_EXHAUSTED', 27);
    static IN_TRANSIT_NOT_STARTED = new PlanStatusEnum('IN_TRANSIT_NOT_STARTED', 28);
    constructor(name, index) {
        this.name = name;
        this.index = index;
        Object.freeze(this);
    }
}
