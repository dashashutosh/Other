import { differenceInMinutes, isValid } from 'date-fns';
import { getHhmmFromMinutes } from '@walmart/stride-ui-commons';
const getEnhancedRows = (rows) => {
    const currentTime = new Date();
    const enhancedTenderRowsList = rows?.reduce?.((list, rowItem) => {
        const carrierMustRespondByTime = new Date(rowItem.carrierMustRespondByTsRaw);
        if (isValid(carrierMustRespondByTime)) {
            const remainingTime = getHhmmFromMinutes(differenceInMinutes(carrierMustRespondByTime, currentTime));
            list.push({
                ...rowItem,
                remainingTime,
            });
        } else {
            list.push({
                ...rowItem,
                remainingTime: '00:00',
            });
        }
        return list;
    }, []);
    return enhancedTenderRowsList;
};
export default getEnhancedRows;
