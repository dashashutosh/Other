import { MarketCodeEnum } from '@walmart/stride-ui-commons';
import PhaseTypesEnum from '../enums/PhaseTypesEnum';
import { SORT_MODE } from '../../Constants';
import { GlobalSearchOption, defaultTimeHorizon } from '../../ConstantsUS';
import { groupByList } from '../../component/trip-management-summary/US/DataModelsUS';
import TripSharedService from '../../service/TripSharedService';

const getDefaultSortField = (activeTabIndex, market) => {
    const activePhase = Object.values(PhaseTypesEnum).find(
        (PhaseType) => PhaseType.index === activeTabIndex && PhaseType.markets.includes(market),
    );
    const sortFieldConfig = activePhase?.defaultSortField?.[market];

    const defaultSortFieldInfo = {
        sortField: '',
        multiSortFields: [],
    };

    if (sortFieldConfig !== null && typeof sortFieldConfig === 'object') {
        defaultSortFieldInfo.sortField = sortFieldConfig.sortField;
        defaultSortFieldInfo.multiSortFields = [sortFieldConfig];
    } else {
        defaultSortFieldInfo.sortField = sortFieldConfig || 'schedule_min_pickup_ts';
    }

    return defaultSortFieldInfo;
};

export const initialFilterState = {
    loadId: '',
    toId: '',
    fromDate: '',
    tillDate: '',
    after: '',
    before: '',
    on: '',
    dateType: '',
    periodType: '',
    loadType: [],
    planType: '',
    status: [],
    carrierId: '',
    scacCode: '',
    coordinatorBoard: '',
    serviceTerritory: '',
    driverId: '',
    trailerId: '',
    originType: '',
    originId: '',
    originCity: '',
    originState: '',
    originCountry: '',
    originZipCode: '',
    destinationType: '',
    destinationId: '',
    destinationCity: '',
    destinationState: '',
    destinationCountry: '',
    destinationZipCode: '',
};

export const getInitialQueryState = (filter = initialFilterState, market) => {
    const { sortField, multiSortFields } = getDefaultSortField(0, market);

    return {
        page: 1,
        sortField: sortField,
        multiSortFields: multiSortFields,
        sortMode:
            market.toLowerCase() === MarketCodeEnum.GUATEMALA.name.toLowerCase() ||
            market.toLowerCase() === MarketCodeEnum.COSTA_RICA.name.toLowerCase() ||
            market.toLowerCase() === MarketCodeEnum.EL_SALVADOR.name.toLowerCase() ||
            market.toLowerCase() === MarketCodeEnum.MEXICO.name.toLowerCase() ||
            market.toLowerCase() === MarketCodeEnum.MEXICO_MARKET_PLACE.name.toLowerCase()
                ? 'DSC'
                : 'ASC',
        exceptionType: null,
        filter,
        profile: {},
        activeTabIndex: 0,
        timeHorizon: TripSharedService.getFeatureFlags()?.showTimeHorizonV2
            ? 'Past: All days - Future: All days'
            : defaultTimeHorizon,
        globalSearchData: null,
        searchByOption: GlobalSearchOption[0].id,
        groupBy: groupByList[0].id,
    };
};

export const PLAN_TABLE_QUERY_ACTIONS_ENUM = {
    INCREMENT_PAGE_NUMBER: 1,
    CHANGE_SORT_FIELD: 2,
    CHANGE_SORT_DIRECTION: 3,
    RESET_PAGE_NUMBER: 4,
    CHANGE_EXCEPTION_TYPE: 5,
    CHANGE_PROFILE: 6,
    CHANGE_FILTER: 7,
    RESET_FILTER: 8,
    CHANGE_ACTIVE_TAB_INDEX: 9,
    CHANGE_TIME_HORIZON: 10,
    GLOBAL_SEARCH: 11,
    GROUP_BY: 12,
    SET_CHECKED_ROWS: 13,
    CONTINUE_NAVIGATION: 14,
    CLOSE_NAVIGATION: 15,
    TABLE_SEARCH: 16,
    RESET_CLIENT_PAGE_NUMBER: 17,
    INCREMENT_CLIENT_PAGE_NUMBER: 18,
    DECREMENT_CLIENT_PAGE_NUMBER: 19,
    CHANGE_SORT: 20,
    UPDATE_MULTI_SORT: 21,
};

export const queryReducer = (state, action) => {
    switch (action?.type) {
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.INCREMENT_PAGE_NUMBER:
            return {
                ...state,
                page: state.page + 1,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_PAGE_NUMBER:
            const { sortField, multiSortFields } = getDefaultSortField(state.activeTabIndex, action.market);
            return {
                ...getInitialQueryState(state.filter, action.market),
                exceptionType: state.exceptionType,
                activeTabIndex: state.activeTabIndex,
                sortField: sortField,
                multiSortFields: multiSortFields,
                profile: state.profile,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_SORT_DIRECTION:
            return {
                ...state,
                sortMode: state.sortMode === 'ASC' ? 'DESC' : 'ASC',
                page: 1,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_SORT_FIELD:
            return {
                ...state,
                sortField: action.sortField,
                sortMode: action.sortMode === 'ASC' ? 'DESC' : 'ASC',
                page: 1,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_SORT:
            return {
                ...state,
                sortField: action.sortField,
                sortMode: action.sortMode,
                page: 1,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.UPDATE_MULTI_SORT:
            return {
                ...state,
                multiSortFields: action.multiSortFields,
                page: 1,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_EXCEPTION_TYPE:
            return {
                ...state,
                exceptionType: action.exceptionType,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_PROFILE:
            return {
                ...state,
                profile: action.profile,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_TIME_HORIZON:
            return {
                ...state,
                timeHorizon: action.timeHorizon,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_FILTER:
            return {
                ...state,
                page: 1,
                filter: action.filter,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_FILTER:
            return {
                ...state,
                filter: {
                    ...initialFilterState,
                },
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_ACTIVE_TAB_INDEX: {
            const { sortField, multiSortFields } = getDefaultSortField(action.activeTabIndex, action.market);
            return {
                ...state,
                activeTabIndex: action.activeTabIndex,
                page: 1,
                exceptionType: null,
                sortField: sortField,
                multiSortFields: multiSortFields,
                sortMode: TripSharedService.getFeatureFlags()?.descDateTimeCreated ? SORT_MODE.DSC : state?.sortMode,
                filter: {
                    ...state?.filter,
                    status: [],
                },
            };
        }
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.GLOBAL_SEARCH: {
            const { sortField, multiSortFields } = getDefaultSortField(
                action.payload?.activeTabIndex,
                action.payload?.market,
            );
            return {
                ...state,
                activeTabIndex: action.payload.activeTabIndex,
                page: 1,
                exceptionType: null,
                sortField: sortField,
                multiSortFields: multiSortFields,
                globalSearchData: action.payload.globalSearch,
                searchByOption: action.payload?.searchByOption || GlobalSearchOption[0].id,
            };
        }
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.GROUP_BY:
            return {
                ...state,
                groupBy: action.groupBy,
            };
        default:
            return state;
    }
};
export const getInitialTableState = (filter = initialFilterState, market) => ({
    queryState: getInitialQueryState(filter, market),
    checkedRows: [],
    showNavConfirmationModal: false,
    lastDispatchedAction: null,
    tableSearchText: '',
    pageNumber: 1,
});

export const tableStateReducer = (state, action) => {
    switch (action?.type) {
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.SET_CHECKED_ROWS:
            return { ...state, checkedRows: action.checkedRows };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.RESET_CLIENT_PAGE_NUMBER:
            return { ...state, pageNumber: 1 };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.INCREMENT_CLIENT_PAGE_NUMBER:
            if (state.checkedRows?.length > 0) {
                return {
                    ...state,
                    showNavConfirmationModal: true,
                    lastDispatchedAction: action,
                };
            }
            return {
                ...state,
                checkedRows: [],
                pageNumber: state.pageNumber + 1,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.DECREMENT_CLIENT_PAGE_NUMBER:
            if (state.checkedRows?.length > 0) {
                return {
                    ...state,
                    showNavConfirmationModal: true,
                    lastDispatchedAction: action,
                };
            }
            return {
                ...state,
                checkedRows: [],
                pageNumber: state.pageNumber - 1,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CONTINUE_NAVIGATION: {
            const dispatchedAction = state.lastDispatchedAction.type;
            if (dispatchedAction === PLAN_TABLE_QUERY_ACTIONS_ENUM.INCREMENT_CLIENT_PAGE_NUMBER) {
                return {
                    ...state,
                    checkedRows: [],
                    showNavConfirmationModal: false,
                    lastDispatchedAction: null,
                    pageNumber: state.pageNumber + 1,
                };
            }
            if (dispatchedAction === PLAN_TABLE_QUERY_ACTIONS_ENUM.DECREMENT_CLIENT_PAGE_NUMBER) {
                return {
                    ...state,
                    checkedRows: [],
                    showNavConfirmationModal: false,
                    lastDispatchedAction: null,
                    pageNumber: state.pageNumber - 1,
                };
            }
            if (state.lastDispatchedAction.type === PLAN_TABLE_QUERY_ACTIONS_ENUM.TABLE_SEARCH) {
                return {
                    ...state,
                    checkedRows: [],
                    showNavConfirmationModal: false,
                    lastDispatchedAction: null,
                    tableSearchText: state.lastDispatchedAction.value,
                };
            }
            return {
                ...state,
                checkedRows: [],
                showNavConfirmationModal: false,
                lastDispatchedAction: null,
                queryState: queryReducer(state.queryState, state.lastDispatchedAction),
            };
        }
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.CLOSE_NAVIGATION:
            return {
                ...state,
                showNavConfirmationModal: false,
                lastDispatchedAction: null,
            };
        case PLAN_TABLE_QUERY_ACTIONS_ENUM.TABLE_SEARCH:
            if (state.checkedRows?.length > 0) {
                return {
                    ...state,
                    showNavConfirmationModal: true,
                    lastDispatchedAction: action,
                };
            }
            return {
                ...state,
                checkedRows: [],
                tableSearchText: action.value,
            };
        default:
            if (state.checkedRows?.length > 0) {
                return {
                    ...state,
                    showNavConfirmationModal: true,
                    lastDispatchedAction: action,
                };
            }
            return {
                ...state,
                queryState: queryReducer(state.queryState, action),
            };
    }
};
