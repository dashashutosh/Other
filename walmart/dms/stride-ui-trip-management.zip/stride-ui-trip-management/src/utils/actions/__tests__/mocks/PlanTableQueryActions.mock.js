export const mockFilterState = {
    fromDate: '',
    tillDate: '',
    after: '',
    before: '',
    on: '',
    dateType: '',
    periodType: '',
    loadType: [],
    planType: '',
    status: [],
    carrierId: '',
    scacCode: '',
};

export const initQueryStateChile = {
    activeTabIndex: 0,
    exceptionType: null,
    filter: {
        after: '',
        before: '',
        carrierId: '',
        dateType: '',
        fromDate: '',
        loadType: [],
        on: '',
        periodType: '',
        planType: '',
        scacCode: '',
        status: [],
        tillDate: '',
    },
    globalSearchData: null,
    page: 1,
    profile: {},
    searchByOption: '1',
    sortField: 'PLAN_CREATED_TIME',
    sortMode: 'DSC',
    multiSortFields: [],
    timeHorizon: 48,
    groupBy: 'TRIP',
};

export const changeTabChile = {
    activeTabIndex: 0,
    market: 'cl',
    type: 9,
};
