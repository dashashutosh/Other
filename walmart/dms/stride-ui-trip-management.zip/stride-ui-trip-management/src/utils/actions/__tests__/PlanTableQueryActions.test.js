import { getInitialQueryState, PLAN_TABLE_QUERY_ACTIONS_ENUM, queryReducer } from '../PlanTableQueryActions';
import { initQueryStateChile, changeTabChile, mockFilterState } from './mocks/PlanTableQueryActions.mock';
import TripSharedService from '../../../service/TripSharedService';
import PhaseTypesEnum from '../../enums/PhaseTypesEnum';

describe('getInitialQueryState with different market tests', () => {
    it('getInitialQueryState when market as GT', () => {
        expect(
            getInitialQueryState(
                {
                    fromDate: '',
                    tillDate: '',
                    after: '',
                    before: '',
                    on: '',
                    dateType: '',
                    periodType: '',
                    loadType: [],
                    planType: '',
                    status: [],
                    carrierId: '',
                    scacCode: '',
                },
                'gt',
            ),
        ).toEqual({
            activeTabIndex: 0,
            exceptionType: null,
            filter: {
                after: '',
                before: '',
                carrierId: '',
                dateType: '',
                fromDate: '',
                loadType: [],
                on: '',
                periodType: '',
                planType: '',
                scacCode: '',
                status: [],
                tillDate: '',
            },
            globalSearchData: null,
            multiSortFields: [],
            page: 1,
            profile: {},
            searchByOption: '1',
            sortField: 'schedule_min_pickup_ts',
            sortMode: 'DSC',
            timeHorizon: 48,
            groupBy: 'TRIP',
        });
    });

    it('getInitialQueryState when market as CR', () => {
        expect(
            getInitialQueryState(
                {
                    fromDate: '',
                    tillDate: '',
                    after: '',
                    before: '',
                    on: '',
                    dateType: '',
                    periodType: '',
                    loadType: [],
                    planType: '',
                    status: [],
                    carrierId: '',
                    scacCode: '',
                },
                'cr',
            ),
        ).toEqual({
            activeTabIndex: 0,
            exceptionType: null,
            filter: {
                after: '',
                before: '',
                carrierId: '',
                dateType: '',
                fromDate: '',
                loadType: [],
                on: '',
                periodType: '',
                planType: '',
                scacCode: '',
                status: [],
                tillDate: '',
            },
            globalSearchData: null,
            multiSortFields: [],
            page: 1,
            profile: {},
            searchByOption: '1',
            sortField: 'schedule_min_pickup_ts',
            sortMode: 'DSC',
            timeHorizon: 48,
            groupBy: 'TRIP',
        });
    });

    it('getInitialQueryState when market as SV', () => {
        expect(
            getInitialQueryState(
                {
                    fromDate: '',
                    tillDate: '',
                    after: '',
                    before: '',
                    on: '',
                    dateType: '',
                    periodType: '',
                    loadType: [],
                    planType: '',
                    status: [],
                    carrierId: '',
                    scacCode: '',
                },
                'sv',
            ),
        ).toEqual({
            activeTabIndex: 0,
            exceptionType: null,
            filter: {
                after: '',
                before: '',
                carrierId: '',
                dateType: '',
                fromDate: '',
                loadType: [],
                on: '',
                periodType: '',
                planType: '',
                scacCode: '',
                status: [],
                tillDate: '',
            },
            globalSearchData: null,
            multiSortFields: [],
            page: 1,
            profile: {},
            searchByOption: '1',
            sortField: 'schedule_min_pickup_ts',
            sortMode: 'DSC',
            timeHorizon: 48,
            groupBy: 'TRIP',
        });
    });

    it('getInitialQueryState when market as CL', () => {
        expect(getInitialQueryState(mockFilterState, 'cl')).toEqual({
            ...initQueryStateChile,
            multiSortFields: [],
            sortMode: 'ASC',
        });
    });

    it('getInitialQueryState when market as MX', () => {
        const initialQueryState = getInitialQueryState(mockFilterState, 'mx');
        expect(initialQueryState.sortField).toEqual('PLAN_CREATED_TIME');
        expect(initialQueryState.sortMode).toEqual('DSC');
    });

    it('getInitialQueryState when market as MX_MKP', () => {
        const initialQueryState = getInitialQueryState(mockFilterState, 'mx_mkp');
        expect(initialQueryState.sortField).toEqual('PLAN_CREATED_TIME');
        expect(initialQueryState.sortMode).toEqual('DSC');
    });

    it('getInitialQueryState when market as other', () => {
        expect(
            getInitialQueryState(
                {
                    fromDate: '',
                    tillDate: '',
                    after: '',
                    before: '',
                    on: '',
                    dateType: '',
                    periodType: '',
                    loadType: [],
                    planType: '',
                    status: [],
                    carrierId: '',
                    scacCode: '',
                },
                'other',
            ),
        ).toEqual({
            page: 1,
            sortField: 'schedule_min_pickup_ts',
            sortMode: 'ASC',
            exceptionType: null,
            filter: {
                fromDate: '',
                tillDate: '',
                after: '',
                before: '',
                on: '',
                dateType: '',
                periodType: '',
                loadType: [],
                planType: '',
                status: [],
                carrierId: '',
                scacCode: '',
            },
            searchByOption: '1',
            profile: {},
            activeTabIndex: 0,
            globalSearchData: null,
            multiSortFields: [],
            timeHorizon: 48,
            groupBy: 'TRIP',
        });
    });
});

describe('queryReducer with CL and different activeTabIndices tests', () => {
    it('queryReducer CL market featureFlag set and activeTabIndex to Processing', () => {
        TripSharedService.setFeatureFlags({
            descDateTimeCreated: true,
        });
        const initQueryState = {
            ...initQueryStateChile,
            sortField: 'PLAN_TYPE',
            sortMode: 'ASC',
        };
        const changeTab = {
            ...changeTabChile,
            activeTabIndex: 1,
        };

        expect(queryReducer(initQueryState, changeTab)).toEqual({
            ...initQueryStateChile,
            activeTabIndex: 1,
        });
    });

    it('queryReducer CL market featureFlag set and activeTabIndex to Dispatch Pending', () => {
        TripSharedService.setFeatureFlags({
            descDateTimeCreated: true,
        });
        const initQueryState = {
            ...initQueryStateChile,
            sortField: 'PLAN_MERCHANDISE_TYPE',
            sortMode: 'ASC',
        };
        const changeTab = {
            ...changeTabChile,
            activeTabIndex: 2,
        };
        expect(queryReducer(initQueryState, changeTab)).toEqual({
            ...initQueryStateChile,
            activeTabIndex: 2,
        });
    });

    it('queryReducer CL market featureFlag set and activeTabIndex to In Transit', () => {
        TripSharedService.setFeatureFlags({
            descDateTimeCreated: true,
        });
        const initQueryState = {
            ...initQueryStateChile,
        };
        const changeTab = {
            ...changeTabChile,
            activeTabIndex: 3,
        };
        expect(queryReducer(initQueryState, changeTab)).toEqual({
            ...initQueryStateChile,
            activeTabIndex: 3,
        });
    });

    it('queryReducer CL market featureFlag FALSE and activeTabIndex to Dispatch Pending', () => {
        TripSharedService.setFeatureFlags({
            descDateTimeCreated: false,
        });
        const initQueryState = {
            ...initQueryStateChile,
            sortField: 'PLAN_MERCHANDISE_TYPE',
            sortMode: 'ASC',
        };
        const changeTab = {
            ...changeTabChile,
            activeTabIndex: 2,
        };
        expect(queryReducer(initQueryState, changeTab)).toEqual({
            ...initQueryStateChile,
            sortMode: 'ASC',
            activeTabIndex: 2,
        });
    });
});

describe('queryReducer for sort actions', () => {
    it('UPDATE_MULTI_SORT action - should return updated state as expected', () => {
        const initialState = getInitialQueryState({}, 'US');
        let state = initialState;

        // update sort
        state = queryReducer(state, {
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.UPDATE_MULTI_SORT,
            multiSortFields: [{ id: 'PLAN_ID', desc: false, sortField: 'PLAN_ID' }],
        });
        expect(state).toEqual({
            ...initialState,
            multiSortFields: [{ id: 'PLAN_ID', desc: false, sortField: 'PLAN_ID' }],
        });

        // update sort with different value
        state = queryReducer(state, {
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.UPDATE_MULTI_SORT,
            multiSortFields: [{ id: 'ORIGIN_ID', desc: true, sortField: 'ORIGIN_ID' }],
        });
        expect(state).toEqual({
            ...initialState,
            multiSortFields: [{ id: 'ORIGIN_ID', desc: true, sortField: 'ORIGIN_ID' }],
        });
    });

    it('CHANGE_ACTIVE_TAB_INDEX action - should reset sort fields to default', () => {
        const initialState = {
            ...getInitialQueryState({}, 'US'),
            filter: {
                status: [],
            },
        };
        let state = {
            ...initialState,
            multiSortFields: [{ id: 'ORIGIN_ID', desc: true, sortField: 'ORIGIN_ID' }],
        };

        // change to PROCESSING tab
        state = queryReducer(state, {
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_ACTIVE_TAB_INDEX,
            market: 'us',
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        });
        expect(state).toEqual({
            ...initialState,
            sortField: 'schedule_min_pickup_ts',
            sortMode: 'ASC',
            multiSortFields: [{ id: 'PLANNED_START', sortField: 'schedule_min_pickup_ts', desc: false }],
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
        });

        // change to IN_TRANSIT tab
        state = queryReducer(state, {
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_ACTIVE_TAB_INDEX,
            market: 'us',
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        });
        expect(state).toEqual({
            ...initialState,
            sortField: 'ep_tnt_actual_start_ts',
            sortMode: 'ASC',
            multiSortFields: [{ id: 'ACTUAL_START', sortField: 'ep_tnt_actual_start_ts', desc: false }],
            activeTabIndex: PhaseTypesEnum.IN_TRANSIT.index,
        });

        // change to READY_TO_START tab
        state = queryReducer(state, {
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_ACTIVE_TAB_INDEX,
            market: 'us',
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        });
        expect(state).toEqual({
            ...initialState,
            sortField: 'schedule_min_pickup_ts',
            sortMode: 'ASC',
            multiSortFields: [{ id: 'PLANNED_START', sortField: 'schedule_min_pickup_ts', desc: false }],
            activeTabIndex: PhaseTypesEnum.READY_TO_START.index,
        });

        // change to DELIVERED tab
        state = queryReducer(state, {
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_ACTIVE_TAB_INDEX,
            market: 'us',
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        });
        expect(state).toEqual({
            ...initialState,
            sortField: 'ep_tnt_actual_start_ts',
            sortMode: 'ASC',
            multiSortFields: [{ id: 'ACTUAL_START', sortField: 'ep_tnt_actual_start_ts', desc: false }],
            activeTabIndex: PhaseTypesEnum.DELIVERED.index,
        });

        // change to PLANNING tab
        state = queryReducer(state, {
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.CHANGE_ACTIVE_TAB_INDEX,
            market: 'us',
            activeTabIndex: PhaseTypesEnum.PLANNING.index,
        });
        expect(state).toEqual({
            ...initialState,
            sortField: 'schedule_min_pickup_ts',
            sortMode: 'ASC',
            multiSortFields: [{ id: 'PLANNED_START', sortField: 'schedule_min_pickup_ts', desc: false }],
            activeTabIndex: PhaseTypesEnum.PLANNING.index,
        });
    });

    it('GLOBAL_SEARCH action - should reset the sort info to default', () => {
        const initialState = {
            ...getInitialQueryState({}, 'US'),
            filter: {
                status: [],
            },
        };
        let state = {
            ...initialState,
            multiSortFields: [{ id: 'ORIGIN_ID', desc: true, sortField: 'ORIGIN_ID' }],
        };

        state = queryReducer(state, {
            type: PLAN_TABLE_QUERY_ACTIONS_ENUM.GLOBAL_SEARCH,
            market: 'us',
            payload: {
                activeTabIndex: PhaseTypesEnum.PROCESSING.index,
                market: 'us',
                globalSearch: 1234,
            },
        });
        expect(state).toEqual({
            ...initialState,
            activeTabIndex: PhaseTypesEnum.PROCESSING.index,
            globalSearchData: 1234,
            sortField: 'schedule_min_pickup_ts',
            sortMode: 'ASC',
            multiSortFields: [{ id: 'PLANNED_START', sortField: 'schedule_min_pickup_ts', desc: false }],
        });
    });
});
