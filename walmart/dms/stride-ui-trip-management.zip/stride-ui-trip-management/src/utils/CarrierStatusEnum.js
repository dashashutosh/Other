export default class CarrierStatusEnum {
    static UNASSIGNED = new CarrierStatusEnum('UNASSIGNED', 0);
    static TENDER_IN_PROGRESS = new CarrierStatusEnum('TENDER_IN_PROGRESS', 1);
    static ASSIGNED = new CarrierStatusEnum('ASSIGNED', 2);
    static SELECTED = new CarrierStatusEnum('SELECTED', 3);
    static NEEDS_ATTENTION = new CarrierStatusEnum('NEEDS_ATTENTION', 4);
    constructor(name, index) {
        this.name = name;
        this.index = index;
        Object.freeze(this);
    }
}
