export default class DateTypeUiEnum {
    static PLANNED_START_DATE = new DateTypeUiEnum('PLANNED_START_DATE');
    static PLANNED_END_DATE = new DateTypeUiEnum('PLANNED_END_DATE');
    constructor(name) {
        this.name = name;
        Object.freeze(this);
    }
}
