import React from 'react';
import { render, configure } from '@testing-library/react';
import { I18nextProvider } from 'react-i18next';
import enData from '../lang/en.json';
import { LocalizeLang } from '@gscope-mfe/common-components';

const { loadI18n } = LocalizeLang.default;
configure({
    asyncUtilTimeout: 4500,
});

export const AllTheProviders = ({ children }) => {
    loadI18n([['en', enData]]);
    return <I18nextProvider>{children}</I18nextProvider>;
};
const customRender = (ui, options) =>
    render(ui, {
        wrapper: AllTheProviders,
        ...options,
    });

// re-export everything
export * from '@testing-library/react';

// override render method
export { customRender as render };
