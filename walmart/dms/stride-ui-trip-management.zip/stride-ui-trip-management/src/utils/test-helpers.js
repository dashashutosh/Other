export const API_GATEWAY_PREFIX_NEW = 'api/gateway/v4/stride-ui-trip-management-';

export const getUpdatedCMSConfig = (CmsConfig, featureFlagConfigUpdates) => {
    const featureFlagConfigForDev = JSON.parse(CmsConfig?.payload?.custom.featureFlags)['dev.tripManagement.configs'];

    return {
        ...CmsConfig,
        payload: {
            ...CmsConfig?.payload,
            custom: {
                ...CmsConfig?.payload?.custom,
                featureFlags: JSON.stringify({
                    'dev.tripManagement.configs': {
                        ...featureFlagConfigForDev,
                        ...featureFlagConfigUpdates,
                    },
                }),
            },
        },
    };
};
