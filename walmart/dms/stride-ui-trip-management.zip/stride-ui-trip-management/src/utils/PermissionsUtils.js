import {
    hasNecessaryPermission,
    PERMISSION_MODULE_TRIP_MANAGEMENT,
    PERMISSION_MODULE_GROUP_LTM,
    LoadActionsEnum,
    TripActionsEnum,
} from '@walmart/stride-ui-commons';
import PermissionsEnum from './enums/PermissionsEnum';
const module = PERMISSION_MODULE_TRIP_MANAGEMENT;
const group = PERMISSION_MODULE_GROUP_LTM;
export function canEditTrip(userPerm, market) {
    return (
        userPerm &&
        hasNecessaryPermission(userPerm, {
            market,
            module,
            action: PermissionsEnum.WRITE.code,
        })
    );
}
export function canEdit(userPerm, market, moduleGroup) {
    return (
        userPerm &&
        hasNecessaryPermission(userPerm, {
            market,
            module,
            action: PermissionsEnum.WRITE.code,
            group: moduleGroup,
        })
    );
}
export function canReadRate(userPerm, market) {
    return (
        userPerm &&
        hasNecessaryPermission(userPerm, {
            market,
            module,
            action: PermissionsEnum.RATE_READ.code,
        })
    );
}

export function canBulkUploadTender(userPerm, market) {
    return (
        userPerm &&
        hasNecessaryPermission(userPerm, {
            market,
            module,
            action: PermissionsEnum.WRITE.code,
        })
    );
}

export const userEditActions = [
    LoadActionsEnum.AUTO_TENDER,
    LoadActionsEnum.CANCEL,
    LoadActionsEnum.MARK_SERVICE_FAILURE,
    LoadActionsEnum.REVIEW_AND_APPROVE,
    LoadActionsEnum.CANCEL_TENDER,
    LoadActionsEnum.UPDATE_TIMELINE,
    LoadActionsEnum.REGENERATE_BOL,
    LoadActionsEnum.EDIT,
    LoadActionsEnum.EDIT_TRAILER_ID,
    LoadActionsEnum.UPDATE_STATUS,
    LoadActionsEnum.EDIT_EQUIPMENT,
    LoadActionsEnum.APPROVE,
    LoadActionsEnum.RESCHEDULE_STORE_LOAD,
    LoadActionsEnum.FORCE_TO_IN_TRANSIT,
    LoadActionsEnum.FORCE_TO_DELIVERED,
    LoadActionsEnum.STOP_SEQUENCE_AUDIT,
    TripActionsEnum.CANCEL,
    TripActionsEnum.FORCE_TO_IN_TRANSIT,
    TripActionsEnum.FORCE_TO_DELIVERED,
    TripActionsEnum.MARK_UNMARK_PRINTED,
    TripActionsEnum.UPDATE_TIMELINE_TRIP,
    TripActionsEnum.STOP_SEQUENCE_AUDIT,
    LoadActionsEnum.MARK_UNMARK_HAZMAT,
    TripActionsEnum.PRINT_TRIP_SHEET,
    TripActionsEnum.EDIT_DRIVER_ETD,
];

export const userReadActions = [
    LoadActionsEnum.STOP_SEQUENCE_AUDIT,
    TripActionsEnum.STOP_SEQUENCE_AUDIT,
    TripActionsEnum.PRINT_TRIP_SHEET,
];

export function getUserActions(userPerm, market) {
    return canEdit(userPerm, market, group) ? userEditActions : userReadActions;
}

export function canAccessNonDrayLoads(userPerm, market) {
    return (
        userPerm &&
        !hasNecessaryPermission(userPerm, {
            market,
            module,
            action: PermissionsEnum.DRAY_EXTERNAL_USERS.code,
        })
    );
}
