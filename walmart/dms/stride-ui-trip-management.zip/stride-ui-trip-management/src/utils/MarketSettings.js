import { MarketCodeEnum } from '@walmart/stride-ui-commons';
export const defaultMarketSettings = {
    showCAColumns: false,
    showCLColumns: false,
    showEquipmentIdForVehicle: false,
    showExport: false,
    showFilter: false,
    checkCoherence: false,
    showLocationName: false,
    carrierAutoAccept: false,
    connectEmptyTrailerLocation: false,
    enableShortTimezone: false,
    sortPlansForDispatcher: false,
    downloadDispatchLabel: true,
    enableLocationIdFilter: false,
    showTotalCount: false,
    includeTransitEquipmentInLoad: false,
    showProfileButton: true,
    openDetailsPageInNewTab: false,
    provenanceTimezone: false,
    removeEquipmentFromFilter: false,
    hideAssignToTripForSTRLoad: false,
    showUpdateTimeline: false,
    includeTimeZoneIdInConnectingLoads: false,
    displayPhaseStatusCount: false,
    setStaticDataForFetchingTimezone: false,
    showTrailerEquipments: false,
    showRegionAndMerchandiseDetails: false,
    fetchUnapprovedPlansInPlanning: false,
    enableLoadTypeIwfs: false,
    searchDateWithTimezone: false,
    autoSelectCarrierInWorkLoadAssgnmt: false,
    showProfileSelectorV2: false,
    showTimeHorizonV2: false,
    showExceptionChips: false,
    showPaginationInAssignTrip: false,
    useLabelChasisForTruck: false,
    validateChargeLocationOnTripDispatch: false,
    enablePermissionsCheck: false,
    getLicensePltNbrFromYms: false,
    enableHubDeconDestinations: false,
    restrictEquipmentCode: false,
    enableExternalUser: false,
    descDateTimeCreated: false,
    displayLoadTypeFromReference: false,
    showDwellDays: false,
    enableChargeLocAssignmentForFillerMoves: false,
    showModeColumnInTripSummary: false,
    enablePaperPrint: false,
    enableMustShipException: false,
    showServiceTerritory: false,
    enableManageColumns: false,
    enableMultiSortForSearchTable: false,
    showCreateTripForDoubleTrailer: false,
    enableDifferentOriginForDoubleTrailer: false,
    showAssignTripForDoubleTrailer: false,
    enableDateValidationInIntermediateDestination: false,
    enableBillOfLading: false,
    enableAwaitingFinalizationStatus: false,
    enableVendorNumber: false,
    hideServiceLevelRequest: false,
    showArrivalDepartureLosToggle: false,
    disableActionsForOBLoadTypes: false,
    useStopSequenceV2MapperForTripDetails: false,
    useOrderedLoadsForDispatchDocument: false,
    displayDCChargeLoc: false,
    usePlanCategoriesFromCommons: false,
    showCommentsColumn: false,
    filterShadowModeEntities: false,
    enableHazmatUpdate: false,
    hazmatUpdateAllowedPlanTypes: [],
    enableNewEquipmentTypes: false,
    showLocationDescription: false,
    losStaticDataV2: false,
    showRouteNumberColumn: false,
    enableMarkServiceFailureForDray: false,
    enableHazmatPayload: false,
    enableHoldTag: false,
    enableStopSeqUpdateTimelineForRelayTrips: false,
    enableWTMSLoadStatus: false,
    enableActionMenu: false,
    enableMultiLoadAssignment: false,
    enableCommentValidation: false,
    enableMultipleLocationsRA: false,
    enableMultiLoadCancel: false,
    enableMultiWithdrawTender: false,
};
export const getMarketSettings = (market) => {
    let marketSettings = defaultMarketSettings;
    switch (market) {
        case MarketCodeEnum.CANADA.code:
            marketSettings = {
                ...defaultMarketSettings,
                showCAColumns: true,
                showExport: true,
                showFilter: true,
                checkCoherence: true,
                enableShortTimezone: true,
                enableLocationIdFilter: true,
                searchDateWithTimezone: false,
            };
            break;
        case MarketCodeEnum.CHILE.code:
            marketSettings = {
                ...defaultMarketSettings,
                showCLColumns: true,
                validateEquipmentCode: false,
                displayPhaseStatusCount: true,
                showRegionAndMerchandiseDetails: true,
                carrierAutoAccept: true,
                showTrailerEquipments: true,
            };
            break;
        case MarketCodeEnum.MEXICO.code:
        case MarketCodeEnum.MEXICO_MARKET_PLACE.code:
            marketSettings = {
                ...defaultMarketSettings,
                showCLColumns: true,
                showLocationName: true,
                carrierAutoAccept: true,
                connectEmptyTrailerLocation: true,
                showEquipmentIdForVehicle: true,
                sortPlansForDispatcher: true,
                downloadDispatchLabel: false,
                includeTransitEquipmentInLoad: true,
                enableShortTimezone: true,
                provenanceTimezone: true,
                hideAssignToTripForSTRLoad: true,
                includeTimeZoneIdInConnectingLoads: true,
                displayPhaseStatusCount: true,
                setStaticDataForFetchingTimezone: true,
                showTrailerEquipments: true,
                enableNewEquipmentTypes: true,
            };
            break;
        case MarketCodeEnum.GUATEMALA.code:
        case MarketCodeEnum.COSTA_RICA.code:
        case MarketCodeEnum.EL_SALVADOR.code:
            marketSettings = {
                ...defaultMarketSettings,
                showCLColumns: true,
                showLocationName: true,
                carrierAutoAccept: true,
                connectEmptyTrailerLocation: true,
                showEquipmentIdForVehicle: true,
                sortPlansForDispatcher: true,
                downloadDispatchLabel: false,
                includeTransitEquipmentInLoad: true,
                enableShortTimezone: true,
                provenanceTimezone: true,
                hideAssignToTripForSTRLoad: true,
                includeTimeZoneIdInConnectingLoads: true,
                displayPhaseStatusCount: true,
                setStaticDataForFetchingTimezone: true,
                showTrailerEquipments: true,
            };
            break;
        case MarketCodeEnum.US.code:
            marketSettings = {
                ...defaultMarketSettings,
                enableExternalUser: true,
                useStopSequenceV2MapperForTripDetails: true,
                enableManageColumns: true,
                losStaticDataV2: false,
                enableMultiSortForSearchTable: true,
                showRouteNumberColumn: false,
                enableStopSeqUpdateTimelineForRelayTrips: false,
            };
            break;
        default:
            break;
    }
    return marketSettings;
};
