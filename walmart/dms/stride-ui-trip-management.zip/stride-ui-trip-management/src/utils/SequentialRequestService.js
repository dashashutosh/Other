import axios from './../axios';
import { useAPI } from '@walmart/stride-ui-commons';
import { TripAPI } from '../service/TripAPI';
import { AppUtils } from '@gscope-mfe/app-bridge';

export function SequenceRequestService(pCallbacks, trans, cancelToken) {
    const { prefLang, currentMarket, userInfo } = AppUtils.get();

    const { callAPI: withdrawTender } = useAPI(
        TripAPI(currentMarket, prefLang.current, userInfo.loggedInUserName, userInfo.displayName).withdrawTender,
    );

    const { setsSelectedPlans, setsIsWithdrawnTenderSuccess, setsErrorMessage, setsSeqErrorList, setsProgressValue } =
        pCallbacks;

    const doSequenceWithdrawTender = (tripIds, step, getPlans) => {
        cancelToken.current = axios.CancelToken.source();
        const body = {
            planId: tripIds[step],
            ct: cancelToken.current.token,
        };
        withdrawTender(
            body,
            () => {
                if (tripIds?.length > step + 1) doSequenceWithdrawTender(tripIds, step + 1, getPlans);
                setsProgressValue(step + 1);
                if (tripIds?.length === step + 1) {
                    setsSelectedPlans([]);
                    getPlans();
                    setsIsWithdrawnTenderSuccess(true);
                }
            },
            (err) => {
                if (!axios.isCancel(err)) {
                    const errorObj = {
                        errMessage: err?.errors?.[0]?.errorIdentifiers?.details?.payload?.message
                            ? err?.errors?.[0]?.errorIdentifiers?.details?.payload?.message
                            : trans('API.error.invalid'),
                        planId: tripIds?.[step],
                    };
                    setsErrorMessage(trans('msg.withdrawTender.fail'));
                    setsSeqErrorList((prev) => [...prev, errorObj]);
                    if (tripIds?.length > step + 1) doSequenceWithdrawTender(tripIds, step + 1, getPlans);
                    setsProgressValue(step + 1);
                    if (tripIds?.length === step + 1) {
                        setsSelectedPlans([]);
                        getPlans();
                    }
                } else {
                    setsSelectedPlans([]);
                    getPlans();
                }
            },
        );
    };

    return {
        doSequenceWithdrawTender,
    };
}
