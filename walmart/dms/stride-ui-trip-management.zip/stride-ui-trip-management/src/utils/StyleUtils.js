export const stTripToast = {
    '&.ld-sc-ui-toast--snack-bar': {
        position: 'absolute',
        bottom: '1rem',
        right: '1rem',
    },
};
export const stickyColumnCheckbox = {
    left: 0,
    minWidth: 90,
};
export const stickyColumnNoCheckbox = {
    left: '0px !important',
    width: 50,
    minWidth: 56,
};
export const stickyColumnPlanIdNoCheckBox = {
    left: '56px !important',
    width: 100,
    minWidth: 130,
    whiteSpace: 'nowrap',
};
export const stickyColumnPlanTypeNoCheckbox = {
    left: '186px !important',
    width: 100,
    minWidth: 130,
    whiteSpace: 'nowrap',
};
export const stickyColumnPlanId = {
    left: '90px !important',
    width: 100,
    minWidth: 100,
    maxWidth: '100px !important',
};
export const stickyColumnTags = {
    left: '190px !important',
    width: '100px',
    minWidth: '100px',
    whiteSpace: 'nowrap',
};
export const stickyColumnPlanType = {
    left: '290px !important',
    width: '200px',
    whiteSpace: 'nowrap',
};
export const stickyColumnPlanStatus = {
    right: '100px !important',
};
export const stickyColumnNoAction = {
    right: '0px !important',
    minWidth: 100,
};
export const stickyColumnPlanActions = {
    right: '0px !important',
    minWidth: 100,
};
