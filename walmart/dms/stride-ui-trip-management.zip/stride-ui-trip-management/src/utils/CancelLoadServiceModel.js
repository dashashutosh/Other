/* eslint-disable no-console */
import { generateHeaders, ServiceHeaders, ServiceMethods } from '@walmart/stride-ui-commons';
import { formatCancelTripActionRequest, formatErrorListFromResponse } from './CommonUtils';

const cancelLoadHeaders = [ServiceHeaders.USER_ID, ServiceHeaders.USER_NAME, ServiceHeaders.WM_SVC_TENANT_ID];

export const getCancelLoadResponse = (props) => {
    try {
        const { response, trans } = props;
        if (response?.status === 'OK') {
            return {
                isSuccess: true,
            };
        }

        if (response?.status === 'FAIL') {
            return {
                errorList: formatErrorListFromResponse(response?.errors),
                errorMessage: trans('msg.cancelLoad.fail'),
            };
        }
        const { error } = props;
        if (error?.errors?.length) {
            return {
                errorList: formatErrorListFromResponse(error?.errors?.[0]?.errorIdentifiers?.details?.errors),
                errorMessage: trans('msg.cancelLoad.fail'),
            };
        }
        return {
            errorList: [],
            errorMessage: '',
        };
    } catch (e) {
        console.log(e);
        return {};
    }
};

export const getCancelLoadError = (props) => {
    try {
        const { error, trans } = props;
        return {
            errorList: formatErrorListFromResponse(error?.errors?.[0]?.errorIdentifiers?.details?.errors),
            errorMessage: trans('msg.cancelLoad.fail'),
        };
    } catch (e) {
        console.log(e);
        return {};
    }
};

export const getCancelLoadReqPayload = (props) => {
    try {
        const { request } = props;
        const { checkedRows, reasonCode } = request;
        if (checkedRows?.length) {
            return formatCancelTripActionRequest(checkedRows, reasonCode);
        }
        return {};
    } catch (e) {
        console.log(e);
        return {};
    }
};

export const getCancelLoadAPIParams = (props) => {
    try {
        const { pApiParams, pTrans } = props;
        const {
            axios,
            ccmServiceName,
            ccmRouteName,
            userId,
            language,
            currentMarket,
            additionalHeaders = {},
            usUsTenantFlag,
            baseUrl,
        } = pApiParams;
        return {
            pTransformResponseFn: getCancelLoadResponse,
            pGetErrorsFromAPIErrorFn: getCancelLoadError,
            pTransformRequestFn: getCancelLoadReqPayload,
            pGetDataValidationErrorsFn: () => {},
            pApiParams: {
                axios,
                ccmServiceName,
                ccmRouteName,
                method: ServiceMethods.POST,
                baseUrl,
                headers: {
                    ...generateHeaders(cancelLoadHeaders, {
                        userId,
                        language,
                        currentMarket,
                        usUsTenantFlag,
                    }),
                    ...additionalHeaders,
                },
            },
            pConfigs: {
                handlePartialSuccess: false,
            },
            pTrans,
        };
    } catch (e) {
        return {};
    }
};
