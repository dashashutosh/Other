## Setup

```bash
$ yarn
```

## Linking module

```bash
$ create-gscope-module link
```

## Running

```bash
$ yarn dev
```

## To use server version of the module

```bash
$ create-gscope-module unlink
```
