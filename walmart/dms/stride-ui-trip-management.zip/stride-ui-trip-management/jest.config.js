// eslint-disable-next-line @typescript-eslint/no-var-requires
const gscopeMfeJestDefaults = require('@gscope-mfe/jest-config');
module.exports = async function () {
    const defaultConfig = await gscopeMfeJestDefaults({
        externals: {
            // You can pass custom overrides like this
            // '@stride-mfe/some-mfe-module': { version: '0.1.66', path: ['dist', 'main-unit-test.js'] },
            // or for react 18
            // 'react': { version: '18.2.0' },
            // 'react-dom': { version: '18.2.0' },
            // 'react-dom/test-utils': { version: '18.2.0' },
            '@gscope-mfe/app-bridge': { version: '0.1.111' },
        },
    });

    const isCI = process.env.CI === 'true';

    return {
        ...defaultConfig,
        setupFilesAfterEnv: [...defaultConfig.setupFilesAfterEnv, './setup-jest.js'],
        testMatch: ['**/__tests__/*.test.[jt]s?(x)'],
        collectCoverageFrom: ['**/*.{js,jsx,ts,tsx}'],
        coverageThreshold: {
            global: {
                branches: 30,
                functions: 30,
                lines: 30,
                statements: 30,
            },
        },
        coverageReporters: ['text', 'html'],
        testTimeout: 5000,
        // Rest of your jest config goes here

        // run jest in silent mode while running in looper
        silent: isCI,
        // use only 75% of cores while running in looper
        maxWorkers: 4,
    };
};
