import TripManagementSummary from './component/trip-management-summary';

export default TripManagementSummary;
