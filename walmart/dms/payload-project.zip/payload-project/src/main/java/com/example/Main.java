package com.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        File file = new File("src/main/java/com/example/payload.json"); // Update path if needed
        JsonNode rootNode = objectMapper.readTree(file);
        rootNode.forEach(Main::fetchAndValidate);
    }

    private static void fetchAndValidate(JsonNode payload) {
        validateFields(payload, "id", "partitionKey");

        Map<String, Consumer<JsonNode>> validators = Map.of(
                "requesterInfo", Main::validateRequesterInfo,
                "externalMetadata", Main::validateExternalMetadata,
                "unitDetails", Main::validateUnitDetails,
                "schedule", node -> validateFields(node, "minPickupTs", "maxPickupTs", "minDueTs", "maxDueTs", "mabdTs", "dnsb", "dnsa", "readyByDate"),
                "references", Main::validateReferences,
                "identifiers", node -> validateFields(node, "clientReferenceUnitId", "groupNbr", "unitId"),
                "locations", Main::validateLocations,
                "provenance", node -> validateFields(node, "createdTs", "lastUpdatedTs", "createdByUserId", "createdByUserName", "lastUpdatedByUserId", "lastUpdatedByUserName")
        );

        validators.forEach((key, validator) -> Optional.ofNullable(payload.get(key)).ifPresentOrElse(
                validator,
                () -> System.out.println("Missing or null field: " + key)
        ));
    }

    private static void validateFields(JsonNode node, String... fieldNames) {
        if (node == null) {
            System.out.println("Missing or null node.");
            return;
        }
        for (String field : fieldNames) {
            Optional.ofNullable(node.get(field))
                    .ifPresentOrElse(
                            value -> {
                                if (value.isArray()) {
                                    System.out.println(field + ": [Array with " + value.size() + " items]");
                                } else {
                                    System.out.println(field + ": " + value.asText());
                                }
                            },
                            () -> System.out.println("Missing or null field: " + field)
                    );
        }
    }

    private static void validateRequesterInfo(JsonNode requesterInfo) {
        validateFields(requesterInfo, "requesterId", "name", "requesterType");
    }


    private static void validateExternalMetadata(JsonNode externalMetadata) {
        if (externalMetadata == null) {
            System.out.println("Missing or null field: externalMetadata");
            return;
        }

        externalMetadata.forEach(item -> {
            validateFields(item, "key", "value");

            JsonNode targetSystems = item.get("targetSystems");
            if (targetSystems == null) {
                System.out.println("Missing or null field: targetSystems");
            } else {
                System.out.println("targetSystems: " + targetSystems.toString());
            }
        });
    }

    private static void validateUnitDetails(JsonNode unitDetails) {
        if (unitDetails == null) {
            System.out.println("Missing or null field: unitDetails");
            return;
        }

        validateFields(unitDetails, "mode", "paymentTerms", "commodity", "protectionLevel", "serviceLevel", "market");

        String[] nestedFields = {"ladenLength", "totalWeight", "totalCube", "totalCases", "totalPallets"};

        for (String field : nestedFields) {
            validateNestedField(unitDetails, field, "unitOfMeasure", "measurementValue");
        }

        JsonNode loadingDetails = unitDetails.get("loadingDetails");
        if (loadingDetails != null) {
            validateFields(loadingDetails, "loadingMethod", "maxStackPositions");
        } else {
            System.out.println("Missing or null field: loadingDetails");
        }
    }

    private static void validateNestedField(JsonNode parentNode, String fieldName, String... subFields) {
        JsonNode nestedNode = parentNode.get(fieldName);
        if (nestedNode == null) {
            System.out.println("Missing or null field: " + fieldName);
            return;
        }
        validateFields(nestedNode, subFields);
    }

    private static void validateReferences(JsonNode references) {
        if (references == null) {
            System.out.println("Missing or null field: references");
            return;
        }

        references.forEach(item -> {
            String key = item.has("referenceKey") ? item.get("referenceKey").asText() : "UNKNOWN";
            String value = item.has("referenceValue") ? item.get("referenceValue").asText() : "MISSING";

            switch (key) {
                case "omsPoNbr":
                case "vendorAgreementNbr":
                case "businessCategory":
                    System.out.println(key + ": " + value);
                    break;
                default:
                    break;
            }
        });
    }

    private static void validateLocations(JsonNode locations) {
        if (locations == null) {
            System.out.println("Missing or null field: locations");
            return;
        }
        validateFields(locations.get("origin"), "locationId", "locationType", "city", "postalCode", "state", "zip_code");
        validateFields(locations.get("destination"), "locationId", "locationType", "city", "postalCode", "state", "zip_code");
    }
}
