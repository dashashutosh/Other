import React from 'react';
import {
  Box,
  Button,
  Divider,
  Paper,
  TextField,
  Typography,
  Checkbox,
  FormControlLabel,
  Stack,
} from '@mui/material';
import { GitHub, Google } from '@mui/icons-material';

function Login() {
  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh" bgcolor="#f4f6fa">
      <Paper elevation={4} sx={{ padding: 4, width: 400, borderRadius: 3 }}>
        <Typography variant="h5" fontWeight="bold" textAlign="center" gutterBottom>
          Sign In
        </Typography>
        <Typography variant="body2" textAlign="center" gutterBottom color="text.secondary">
          Welcome user, please sign in to continue
        </Typography>

        <Stack spacing={2}>
          <Button
            variant="outlined"
            startIcon={<GitHub />}
            fullWidth
            sx={{ textTransform: 'none' }}
          >
            Sign In With OAuth GitHub
          </Button>

          <Button
            variant="outlined"
            startIcon={<Google />}
            fullWidth
            sx={{ textTransform: 'none' }}
          >
            Sign In With OAuth Google
          </Button>
        </Stack>

        <Divider sx={{ my: 3 }}>Or</Divider>

        <Stack spacing={2}>
          <TextField label="Email" type="email" fullWidth required />
          <TextField label="Password" type="password" fullWidth required />
          <FormControlLabel control={<Checkbox />} label="Remember Me" />

          <Button
            variant="contained"
            fullWidth
            sx={{
              background: 'linear-gradient(45deg, #000000 30%, #434343 90%)',
              color: 'white',
              textTransform: 'none',
              height: '45px',
            }}
          >
            Sign In
          </Button>
        </Stack>
      </Paper>
    </Box>
  );
}

export default Login;
