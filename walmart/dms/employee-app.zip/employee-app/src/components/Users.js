import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUsers, deleteUser } from '../redux/userSlice';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { DataGrid } from '@mui/x-data-grid';
import { Box, Button, IconButton, Typography, AppBar, Toolbar, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Menu, MenuItem } from '@mui/material';
import { Delete, Edit, Visibility, Add, Menu as MenuIcon, Email, Notifications, Refresh } from '@mui/icons-material';

function Users() {
    const dispatch = useDispatch();
    const { users, status, error } = useSelector(state => state.users);
    const [openErrorDialog, setOpenErrorDialog] = useState(false);
    const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
    const [userToDelete, setUserToDelete] = useState(null);
    const [anchorEl, setAnchorEl] = useState(null);

    useEffect(() => {
        if (!users || users.length === 0) {
            dispatch(fetchUsers());
        }
    }, [dispatch, users]);

    useEffect(() => {
        if (status === 'failed' && error) {
            setOpenErrorDialog(true);
        }
    }, [status, error]);

    const handleOpenDeleteDialog = (userId) => {
        setUserToDelete(userId);
        setOpenDeleteDialog(true);
    };

    const handleCloseDeleteDialog = () => {
        setOpenDeleteDialog(false);
        setUserToDelete(null);
    };

    const confirmDelete = () => {
        if (userToDelete) {
            dispatch(deleteUser(userToDelete));
            setOpenDeleteDialog(false);
        }
    };

    const handleMenuClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const navigate = useNavigate();

    const handleMenuItemClick = (option) => {
        handleMenuClose();
        if (option === 'Profile') navigate('/login');
      };
      
    const columns = [
        { field: 'name', headerName: 'Name', flex: 1 },
        { field: 'username', headerName: 'Username', flex: 1 },
        { field: 'email', headerName: 'Email', flex: 1 },
        { field: 'phone', headerName: 'Phone', flex: 1 },
        { field: 'website', headerName: 'Website', flex: 1 },
        {
            field: 'actions',
            headerName: 'Actions',
            flex: 1,
            renderCell: (params) => (
                <Box>
                    <IconButton component={Link} to={`/view/${params.row.id}`} color="primary">
                        <Visibility />
                    </IconButton>
                    <IconButton component={Link} to={`/edit/${params.row.id}`} color="secondary">
                        <Edit />
                    </IconButton>
                    <IconButton onClick={() => handleOpenDeleteDialog(params.row.id)} color="error">
                        <Delete />
                    </IconButton>
                </Box>
            ),
        },
    ];

    return (
        <>
            <AppBar position="static" sx={{ backgroundColor: "#1976d2" }}>
                <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
                    <IconButton edge="start" color="inherit" onClick={handleMenuClick}>
                        <MenuIcon />
                    </IconButton>
                    <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
                        <MenuItem onClick={() => handleMenuItemClick('Profile')}>Profile</MenuItem>
                        <MenuItem onClick={handleMenuClose}>About</MenuItem>
                        <MenuItem onClick={handleMenuClose}>Logout</MenuItem>
                    </Menu>
                    <Typography variant="h4" sx={{ fontWeight: "normal" }}>
                        Employee Management System
                    </Typography>
                    <Box>
                        <IconButton color="inherit">
                            <Email />
                        </IconButton>
                        <IconButton color="inherit">
                            <Notifications />
                        </IconButton>
                        <IconButton color="inherit">
                            <Refresh />
                        </IconButton>
                    </Box>
                </Toolbar>
            </AppBar>

            <Box sx={{ width: "80%", margin: "auto", mt: 4 }}>
                <Box display="flex" justifyContent="flex-end" mb={2}>
                    <Button component={Link} to="/add" variant="contained" color="primary" startIcon={<Add />}>
                        Add New User
                    </Button>
                </Box>

                <Box sx={{ height: 500, width: '100%' }}>
                    {status === 'succeeded' && users.length === 0 ? (
                        <Dialog open={openErrorDialog} onClose={() => setOpenErrorDialog(false)}>
                            <DialogTitle>No Users Found</DialogTitle>
                            <DialogContent>
                                <DialogContentText>There are no users to display.</DialogContentText>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => setOpenErrorDialog(false)}>Close</Button>
                            </DialogActions>
                        </Dialog>
                    ) : (
                        <DataGrid
                            rows={users}
                            columns={columns}
                            pageSize={10}
                            rowsPerPageOptions={[5, 10, 20]}
                            checkboxSelection
                            sx={{ bgcolor: 'background.paper' }}
                        />
                    )}
                </Box>
            </Box>

            <Dialog open={openDeleteDialog} onClose={handleCloseDeleteDialog}>
                <DialogTitle>Confirm Delete</DialogTitle>
                <DialogContent>
                    <DialogContentText>Are you sure you want to delete this user?</DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDeleteDialog}>Cancel</Button>
                    <Button onClick={confirmDelete} color="error">Delete</Button>
                </DialogActions>
            </Dialog>
        </>
    );
}

export default Users;
