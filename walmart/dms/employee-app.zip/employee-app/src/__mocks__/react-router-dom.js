const actualReactRouterDom = jest.requireActual('react-router-dom');

module.exports = {
  ...actualReactRouterDom,
  BrowserRouter: ({ children }) => <div>{children}</div>,
  Routes: ({ children }) => <div>{children}</div>,
  Route: ({ element }) => element,
  useNavigate: () => jest.fn(),
  useParams: () => ({}),
};
