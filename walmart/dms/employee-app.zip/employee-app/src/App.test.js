import { render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import { MemoryRouter } from 'react-router-dom';
import { store } from './redux/store';
import App from './App';

test('renders Employee Management System heading', () => {
  render(
    <MemoryRouter>
      <Provider store={store}>
        <App />
      </Provider>
    </MemoryRouter>
  );

  // Use getAllByText instead of getByText
  const headingElements = screen.getAllByText(/Employee Management System/i);
  expect(headingElements.length).toBeGreaterThan(0); // Ensure at least one is found
});
