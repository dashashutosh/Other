import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { Provider } from "react-redux";
import { MemoryRouter } from "react-router-dom";
import configureStore from "redux-mock-store";
import axios from "axios";
import MockAdapter from "axios-mock-adapter";
import EditUser from "../components/EditUser";
import { fetchUserById, updateUser } from "../redux/userSlice";

// Define the API URL for the user
const API_URL = "http://localhost:4000/users/2";

// Create a mock store
const mockStore = configureStore([]);

// Define the initial state for the Redux store
const initialState = {
    users: {
        selectedUser: {
            id: "2",
            name: "Kevin Howell",
            username: "Antonette",
            email: "Shanna@melissa.tv",
            phone: "010-692-6593 x09125",
            website: "anastasia.net"
        },
        status: "idle",
        error: null
    }
};

// Mock the fetchUserById and updateUser actions from the userSlice
jest.mock("../redux/userSlice", () => ({
    fetchUserById: jest.fn(() => ({ type: 'users/fetchUserById' })),
    updateUser: jest.fn(() => ({ type: 'users/updateUser' }))
}));

// Describe the test suite for the EditUser component
describe("EditUser Component", () => {
    let store;
    let mockAxios;

    // Before each test, initialize the store and mock Axios, and render the component
    beforeEach(() => {
        store = mockStore(initialState);
        store.dispatch = jest.fn();
        mockAxios = new MockAdapter(axios);
        render(
            <Provider store={store}>
                <MemoryRouter initialEntries={["/edit/2"]}>
                    <EditUser />
                </MemoryRouter>
            </Provider>
        );
    });

    // After each test, reset the mock Axios
    afterEach(() => {
        mockAxios.reset();
    });

    // Test if the component fetches user details when it mounts
    test('fetches user details when component mounts', () => {
        expect(store.dispatch).toHaveBeenCalledWith(fetchUserById("2"));
    });

    // Test if the header "Employee Management System" is rendered
    test("renders Employee Management System header", () => {
        expect(screen.getByTestId("header-title")).toBeInTheDocument();
    });

    // Test if all input fields in the Basic Details tab are rendered
    test("renders all input fields in Basic Details tab", async () => {
        await waitFor(() => {
            expect(screen.getByTestId("input-name")).toBeInTheDocument();
            expect(screen.getByTestId("input-email")).toBeInTheDocument();
        });
    });

    // Test if the tab switching functionality works correctly
    test("switches tabs correctly", () => {
        fireEvent.click(screen.getByTestId("tab-address"));
        expect(screen.getByTestId("address-details-form")).toBeInTheDocument();

        fireEvent.click(screen.getByTestId("tab-company"));
        expect(screen.getByTestId("company-details-form")).toBeInTheDocument();
    });

    // Test if the form is populated with the API data
    test("populates form with API data", async () => {
        await waitFor(() => {
            expect(screen.getByDisplayValue("Kevin Howell")).toBeInTheDocument();
            expect(screen.getByDisplayValue("Shanna@melissa.tv")).toBeInTheDocument();
        });
    });

    // Test if the "Save Changes" button triggers the API update request
    test("Save Changes button triggers API update request", async () => {
        const input = screen.getByTestId("input-name").querySelector("input");
        fireEvent.change(input, { target: { value: "Updated Name" } });
        fireEvent.click(screen.getByTestId("save-button"));

        mockAxios.onPut(API_URL).reply(200, { id: "2", name: "Updated Name" });
        await store.dispatch(updateUser());
        expect(store.dispatch).toHaveBeenCalledWith(updateUser());
    });

    // Test if an error message is shown when the update fails
    test("shows error message when update fails", async () => {
        mockAxios.onPut(API_URL).reply(500);

        store = mockStore({
            users: {
                selectedUser: {
                    id: "2",
                    name: "Kevin Howell",
                    username: "Antonette",
                    email: "Shanna@melissa.tv",
                    phone: "010-692-6593 x09125",
                    website: "anastasia.net"
                },
                status: "failed",
                error: "An error occurred while updating user."
            }
        });

        store.dispatch = jest.fn();

        render(
            <Provider store={store}>
                <MemoryRouter initialEntries={["/edit/2"]}>
                    <EditUser />
                </MemoryRouter>
            </Provider>
        );

        const saveButtons = screen.getAllByTestId("save-button");
        fireEvent.click(saveButtons[0]); 

        await waitFor(() => {
            expect(
                screen.getByText((content) => content.includes("An error occurred while updating user"))
            ).toBeInTheDocument();
        });
    });
});