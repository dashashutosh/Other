import CreateRLogLoad from './component';

export default CreateRLogLoad;
