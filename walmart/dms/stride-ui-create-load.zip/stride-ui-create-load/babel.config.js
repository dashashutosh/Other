module.exports = require('gscope-fe-config/babel/mfe-ts-react');
