import {
    hasNecessaryPermission,
    PERMISSION_MODULE_CREATE_LOAD,
    PERMISSION_MODULE_GROUP_LTM,
} from '@walmart/stride-ui-commons';
import PermissionsEnum from './enums/PermissionsEnum';

const module = PERMISSION_MODULE_CREATE_LOAD;
const group = PERMISSION_MODULE_GROUP_LTM;

export function canCreateLoad(userPerm, market) {
    return (
        userPerm &&
        hasNecessaryPermission(userPerm, {
            market,
            module,
            action: PermissionsEnum.WRITE.code,
            group: group,
        })
    );
}
