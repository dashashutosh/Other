import { getMarketSettings } from '../MarketSettings';

const defaultMarketSettingsMock = {
    enableManualCreateLoadChanges: false,
    showLoadIdInToast: false,
    enableDefaultEquipmentId: false,
};

describe('MarketSettings', () => {
    it('should return market settings correctly for US market', () => {
        const marketSettings = getMarketSettings('us');
        expect(marketSettings).toEqual({
            ...defaultMarketSettingsMock,
        });
    });
});
