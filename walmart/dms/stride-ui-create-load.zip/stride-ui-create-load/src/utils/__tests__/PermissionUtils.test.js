import { canCreateLoad } from '../PermissionsUtils';

describe('Permission Utils', () => {
    it('should check permissions for canCreateLoad', () => {
        expect(canCreateLoad([], 'us')).toEqual(false);
        expect(canCreateLoad(['us.stride.ltm-createLoad:WRITE'], 'us')).toEqual(true);
    });
});
