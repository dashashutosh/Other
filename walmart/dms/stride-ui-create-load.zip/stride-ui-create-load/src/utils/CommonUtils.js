import { formatErrors } from '@walmart/stride-ui-commons';
export const transformMultiInputStringValue = (value) =>
    value ? value.split('\t').join(' ').split(' ').join(',').split(',') : [];
export const errorHandler = (error) => {
    if (error?.errors) {
        // backend API failed
        return error;
    }
    // GSCOPE API failed
    return {
        key: 'pageError.summary.noService',
    };
};
export const getErrorText = (data, trans, params) => {
    if (typeof data === 'string' || data instanceof String) {
        return data;
    }
    const error = formatErrors(data, params);
    return error?.key ? trans(error?.key) : error;
};
export const getTomorrowDate = () => {
    const date = new Date();
    return new Date(date.setDate(date.getDate() + 1));
};
export const getShortTimezoneAbbr = (olsenTimezoneId, timezones) => {
    if (!olsenTimezoneId || !Array.isArray(timezones)) return '';
    return timezones.find((timezone) => olsenTimezoneId === timezone.olsenTimzoneId)?.abbrevation || '';
};
