class PermissionsEnum {
    static READ = new PermissionsEnum('READ', '1');
    static WRITE = new PermissionsEnum('WRITE', '2');

    constructor(code, index) {
        this.code = code;
        this.index = index;
        Object.freeze(this);
    }
}
export default PermissionsEnum;
