import { MarketCodeEnum } from '@walmart/stride-ui-commons';

export const defaultMarketSettings = {
    enableManualCreateLoadChanges: false,
    showLoadIdInToast: false,
    enableDefaultEquipmentId: false,
};

export const getMarketSettings = (market) => {
    let marketSettings = defaultMarketSettings;
    switch (market) {
        case MarketCodeEnum.US.code:
            marketSettings = {
                ...defaultMarketSettings,
            };
            break;
        default:
            break;
    }
    return marketSettings;
};
