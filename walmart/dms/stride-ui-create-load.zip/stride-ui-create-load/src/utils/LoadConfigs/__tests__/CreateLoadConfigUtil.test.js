import { UILoadTypeEnum } from '@walmart/stride-ui-commons';
import getFormConfigByLoadType from '../CreateLoadConfigUtil';
import ManageableCardsEnum from '../ManageableCardsEnum';
import ManageableFieldsEnum from '../ManageableFieldsEnum';
import ValidationsEnum from '../ValidationsEnum';

describe('getFormConfigByLoadType tests', () => {
    it('should return config correctly', () => {
        const mockConfig = {
            loadTypes: [
                UILoadTypeEnum.STR,
                UILoadTypeEnum.PLT,
                UILoadTypeEnum.CLM,
                UILoadTypeEnum.RTN,
                UILoadTypeEnum.BOB,
                UILoadTypeEnum.DHD,
                UILoadTypeEnum.BOX,
                UILoadTypeEnum.STK,
                UILoadTypeEnum.WMGW,
                UILoadTypeEnum.GRSTR,
            ],
            fields: {
                [ManageableFieldsEnum.REQUEST_TYPE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.EQUIPMENT_TYPE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: 'DRYV',
                    isEditable: true,
                },
                [ManageableFieldsEnum.EQUIPMENT_LENGTH.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '53',
                    isEditable: true,
                },
                [ManageableFieldsEnum.EQUIPMENT_ID.name]: {
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.MODE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: 'TL',
                    isEditable: true,
                },
                [ManageableFieldsEnum.LEVEL.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: 'SINGLE',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_ORIGIN.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_ORIGIN_ACTIVITY_TYPE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_PICK_UP_DATE_TIME.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_FINAL_DELIVERY_DATE_TIME.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_DESTINATION.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_DESTINATION_ACTIVITY_TYPE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.COMMENTS_FORM.name]: {
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.CARRIER_ID.name]: {
                    validations: [null],
                    defaultValue: {
                        id: 'WALM',
                        value: 'WALM - WAL-MART TRANSPORTATION LLC',
                    },
                    isEditable: true,
                    isDisable: true,
                },
            },
            sections: {
                [ManageableCardsEnum.REQUEST_DETAILS.name]: {},
                [ManageableCardsEnum.EQUIPMENT_DETAILS.name]: {},
                [ManageableCardsEnum.STOP_SEQUENCE.name]: {
                    validations: [
                        ValidationsEnum.PICKUP_DATE_CANNOT_BE_IN_PAST.code,
                        ValidationsEnum.DELIVERY_DATE_CANNOT_BE_IN_PAST.code,
                    ],
                },
                [ManageableCardsEnum.SERVICE_DETAILS.name]: {},
                [ManageableCardsEnum.COMMENTS.name]: {},
            },
        };
        expect(getFormConfigByLoadType({ showFinalDeliveryDate: true, showGRSTR: true })).toStrictEqual(mockConfig);
    });

    it('should return carrier related config correctly if feature flag showCarrierSection true and carrier field should be enable and mandatory for load type GRSTR', () => {
        const mockConfig = {
            loadTypes: [
                UILoadTypeEnum.STR,
                UILoadTypeEnum.PLT,
                UILoadTypeEnum.CLM,
                UILoadTypeEnum.RTN,
                UILoadTypeEnum.BOB,
                UILoadTypeEnum.DHD,
                UILoadTypeEnum.BOX,
                UILoadTypeEnum.STK,
                UILoadTypeEnum.WMGW,
                UILoadTypeEnum.GRSTR,
            ],
            fields: {
                [ManageableFieldsEnum.REQUEST_TYPE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.EQUIPMENT_TYPE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: 'DRYV',
                    isEditable: true,
                },
                [ManageableFieldsEnum.EQUIPMENT_LENGTH.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '53',
                    isEditable: true,
                },
                [ManageableFieldsEnum.EQUIPMENT_ID.name]: {
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.MODE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: 'TL',
                    isEditable: true,
                },
                [ManageableFieldsEnum.LEVEL.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: 'SINGLE',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_ORIGIN.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_ORIGIN_ACTIVITY_TYPE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_PICK_UP_DATE_TIME.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_FINAL_DELIVERY_DATE_TIME.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_DESTINATION.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.STOP_DESTINATION_ACTIVITY_TYPE.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.COMMENTS_FORM.name]: {
                    defaultValue: '',
                    isEditable: true,
                },
                [ManageableFieldsEnum.CARRIER_ID.name]: {
                    validations: [ValidationsEnum.MANDATORY_FIELD.code],
                    defaultValue: {
                        id: 'WALM',
                        value: 'WALM - WAL-MART TRANSPORTATION LLC',
                    },
                    isEditable: true,
                    isDisable: false,
                },
            },
            sections: {
                [ManageableCardsEnum.REQUEST_DETAILS.name]: {},
                [ManageableCardsEnum.EQUIPMENT_DETAILS.name]: {},
                [ManageableCardsEnum.STOP_SEQUENCE.name]: {
                    validations: [
                        ValidationsEnum.PICKUP_DATE_CANNOT_BE_IN_PAST.code,
                        ValidationsEnum.DELIVERY_DATE_CANNOT_BE_IN_PAST.code,
                    ],
                },
                [ManageableCardsEnum.SERVICE_DETAILS.name]: {},
                [ManageableCardsEnum.COMMENTS.name]: {},
                [ManageableCardsEnum.CARRIER_DETAILS.name]: {},
            },
        };
        expect(
            getFormConfigByLoadType(
                { showFinalDeliveryDate: true, showCarrierSection: true, showGRSTR: true },
                'GRSTR',
            ),
        ).toStrictEqual(mockConfig);
    });
});
