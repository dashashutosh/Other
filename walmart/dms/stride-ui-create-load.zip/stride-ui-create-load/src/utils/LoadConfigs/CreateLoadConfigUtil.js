import { UILoadTypeEnum } from '@walmart/stride-ui-commons';
import ManageableCardsEnum from './ManageableCardsEnum';
import ManageableFieldsEnum from './ManageableFieldsEnum';
import ValidationsEnum from './ValidationsEnum';

const getFormConfigByLoadType = (featureFlags, loadType) => ({
    loadTypes: [
        UILoadTypeEnum.STR,
        UILoadTypeEnum.PLT,
        UILoadTypeEnum.CLM,
        UILoadTypeEnum.RTN,
        UILoadTypeEnum.BOB,
        UILoadTypeEnum.DHD,
        UILoadTypeEnum.BOX,
        UILoadTypeEnum.STK,
        UILoadTypeEnum.WMGW,
        ...(featureFlags?.showGRSTR ? [UILoadTypeEnum.GRSTR] : []),
    ],
    fields: {
        [ManageableFieldsEnum.REQUEST_TYPE.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: '',
            isEditable: true,
        },
        [ManageableFieldsEnum.EQUIPMENT_TYPE.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: 'DRYV',
            isEditable: true,
        },
        [ManageableFieldsEnum.EQUIPMENT_LENGTH.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: '53',
            isEditable: true,
        },
        [ManageableFieldsEnum.EQUIPMENT_ID.name]: {
            defaultValue: '',
            isEditable: true,
        },
        [ManageableFieldsEnum.CARRIER_ID.name]: {
            validations: [
                featureFlags?.showCarrierSection && loadType === UILoadTypeEnum.GRSTR.name
                    ? ValidationsEnum.MANDATORY_FIELD.code
                    : null,
            ],
            defaultValue: {
                id: 'WALM',
                value: 'WALM - WAL-MART TRANSPORTATION LLC',
            },
            isEditable: true,
            isDisable: loadType === UILoadTypeEnum.GRSTR.name ? false : true,
        },
        [ManageableFieldsEnum.MODE.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: 'TL',
            isEditable: true,
        },
        [ManageableFieldsEnum.LEVEL.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: 'SINGLE',
            isEditable: true,
        },
        [ManageableFieldsEnum.STOP_ORIGIN.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: '',
            isEditable: true,
        },
        [ManageableFieldsEnum.STOP_ORIGIN_ACTIVITY_TYPE.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: '',
            isEditable: true,
        },
        [ManageableFieldsEnum.STOP_PICK_UP_DATE_TIME.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: '',
            isEditable: true,
        },
        [ManageableFieldsEnum.STOP_DESTINATION.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: '',
            isEditable: true,
        },
        [ManageableFieldsEnum.STOP_FINAL_DELIVERY_DATE_TIME.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: '',
            isEditable: true,
        },
        [ManageableFieldsEnum.STOP_DESTINATION_ACTIVITY_TYPE.name]: {
            validations: [ValidationsEnum.MANDATORY_FIELD.code],
            defaultValue: '',
            isEditable: true,
        },
        [ManageableFieldsEnum.COMMENTS_FORM.name]: {
            defaultValue: '',
            isEditable: true,
        },
    },
    sections: {
        [ManageableCardsEnum.REQUEST_DETAILS.name]: {},
        [ManageableCardsEnum.EQUIPMENT_DETAILS.name]: {},
        ...(featureFlags?.showCarrierSection ? { [ManageableCardsEnum.CARRIER_DETAILS.name]: {} } : null),
        [ManageableCardsEnum.STOP_SEQUENCE.name]: {
            validations: [
                ValidationsEnum.PICKUP_DATE_CANNOT_BE_IN_PAST.code,
                featureFlags?.showFinalDeliveryDate ? ValidationsEnum.DELIVERY_DATE_CANNOT_BE_IN_PAST.code : null,
            ],
        },
        [ManageableCardsEnum.SERVICE_DETAILS.name]: {},
        [ManageableCardsEnum.COMMENTS.name]: {},
    },
});

export default getFormConfigByLoadType;
