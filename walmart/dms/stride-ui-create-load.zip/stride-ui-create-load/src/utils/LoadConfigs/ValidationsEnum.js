export default class ValidationsEnum {
    static MANDATORY_FIELD = new ValidationsEnum('MANDATORY_FIELD', 0, 'label.validation.mandatory');

    static PICKUP_DATE_CANNOT_BE_IN_PAST = new ValidationsEnum(
        'PICKUP_DATE_CANNOT_BE_IN_PAST',
        1,
        'label.validation.pickupDateCannotBeInPast',
    );

    static DELIVERY_DATE_CANNOT_BE_IN_PAST = new ValidationsEnum(
        'DELIVERY_DATE_CANNOT_BE_IN_PAST',
        1,
        'label.validation.deliveryDateCannotBeInPast',
    );

    constructor(code, index, desc) {
        this.code = code;
        this.index = index;
        this.desc = desc;
        Object.freeze(this);
    }
}
