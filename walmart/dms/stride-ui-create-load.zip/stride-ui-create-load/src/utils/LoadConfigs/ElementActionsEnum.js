export default class ElementActionsEnum {
    static ADD_STOP = new ElementActionsEnum('ADD_STOP', 0);

    static EDIT = new ElementActionsEnum('EDIT', 1);

    static DELETE_STOP = new ElementActionsEnum('DELETE_STOP', 2);

    static REORDER_STOP = new ElementActionsEnum('REORDER_STOP', 3);

    constructor(name, index) {
        this.name = name;
        this.index = index;
        Object.freeze(this);
    }
}
