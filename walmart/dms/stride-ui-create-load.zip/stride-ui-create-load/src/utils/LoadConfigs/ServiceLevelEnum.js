export default class ServiceLevelEnum {
    static SINGLE = new ServiceLevelEnum('SINGLE', 0);

    static TEAM = new ServiceLevelEnum('TEAM', 1);

    static DEDF = new ServiceLevelEnum('DEDF', 2);

    constructor(name, index) {
        this.name = name;
        this.index = index;
        Object.freeze(this);
    }
}
