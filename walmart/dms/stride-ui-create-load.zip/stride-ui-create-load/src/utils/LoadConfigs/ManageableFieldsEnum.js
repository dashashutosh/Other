export default class ManageableFieldsEnum {
    static REQUEST_TYPE = new ManageableFieldsEnum('REQUEST_TYPE', 0);

    static EQUIPMENT_TYPE = new ManageableFieldsEnum('EQUIPMENT_TYPE', 1);

    static EQUIPMENT_LENGTH = new ManageableFieldsEnum('EQUIPMENT_LENGTH', 2);

    static EQUIPMENT_ID = new ManageableFieldsEnum('EQUIPMENT_ID', 3);

    static STOP_SEQUENCE_FORM = new ManageableFieldsEnum('STOP_SEQUENCE_FORM', 4);

    static MODE = new ManageableFieldsEnum('MODE', 5);

    static CLASS = new ManageableFieldsEnum('CLASS', 6);

    static LEVEL = new ManageableFieldsEnum('LEVEL', 7);

    static COMMENTS_FORM = new ManageableFieldsEnum('COMMENTS_FORM', 8);

    static STOP_ORIGIN = new ManageableFieldsEnum('STOP_ORIGIN', 9);

    static STOP_ORIGIN_ACTIVITY_TYPE = new ManageableFieldsEnum('STOP_ORIGIN_ACTIVITY_TYPE', 10);

    static STOP_PICK_UP_DATE_TIME = new ManageableFieldsEnum('STOP_PICK_UP_DATE_TIME', 11);

    static STOP_DESTINATION = new ManageableFieldsEnum('STOP_DESTINATION', 12);

    static STOP_DESTINATION_ACTIVITY_TYPE = new ManageableFieldsEnum('STOP_DESTINATION_ACTIVITY_TYPE', 13);

    static STOP_FINAL_DELIVERY_DATE_TIME = new ManageableFieldsEnum('STOP_FINAL_DELIVERY_DATE_TIME', 14);

    static CARRIER_ID = new ManageableFieldsEnum('CARRIER_ID', 15);

    constructor(name, index) {
        this.name = name;
        this.index = index;
        Object.freeze(this);
    }
}
