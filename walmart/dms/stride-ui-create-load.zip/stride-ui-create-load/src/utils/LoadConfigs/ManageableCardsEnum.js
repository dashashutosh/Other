export default class ManageableCardsEnum {
    static REQUEST_DETAILS = new ManageableCardsEnum('REQUEST_DETAILS', 'requestType', 0, 'title.requestDetails');

    static EQUIPMENT_DETAILS = new ManageableCardsEnum('EQUIPMENT_DETAILS', 'equipment', 1, 'title.equipmentDetails');

    static STOP_SEQUENCE = new ManageableCardsEnum('STOP_SEQUENCE', 'stops', 2, 'title.stopSequence');

    static SERVICE_DETAILS = new ManageableCardsEnum('SERVICE_DETAILS', 'transitDetail', 3, 'title.serviceDetails');

    static COMMENTS = new ManageableCardsEnum('COMMENTS', 'comments', 4, 'title.comments');

    static CARRIER_DETAILS = new ManageableCardsEnum('CARRIER_DETAILS', 'carrier', 5, 'title.carrierDetails');

    constructor(name, key, index, title) {
        this.name = name;
        this.key = key;
        this.index = index;
        this.title = title;
        Object.freeze(this);
    }
}
