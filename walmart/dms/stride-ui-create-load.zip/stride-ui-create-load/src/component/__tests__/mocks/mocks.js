export const contextMock = {
    setBreadCrumbArr: jest.fn(),
    setHeaderConfig: jest.fn(),
    setBulkUploadConfig: jest.fn(),
    prefLang: {
        current: 'en',
    },
    currentMarket: 'us',
    moduleName: 'create-load',
    setloading: jest.fn(),
    userInfo: {
        loggedInUserName: '123',
    },
    headerConfig: {},
    allLangs: [],
    setAllLangs: jest.fn(),
    bulkUploadConfig: {
        bulkActions: {},
        serviceAction: true,
        serviceType: true,
        hasEditPermission: true,
    },
};
export const locationAutoCompleteMock = {
    status: 'SUCCESS',
    payload: {
        static_data: {
            locations: [
                {
                    mdm_location_id: 11734,
                    location_type_id: 2,
                    location_type_abbr: 'STORE',
                    location_type_code: 'STORE',
                    location_id: 12,
                    location_name: 'CLAREMORE OK',
                    location_display_name: 'CLAREMORE OK',
                },
                {
                    mdm_location_id: 17641,
                    location_type_id: 2,
                    location_type_abbr: 'STORE',
                    location_type_code: 'STORE',
                    location_id: 120,
                    location_name: 'HUMBOLDT TN',
                    location_display_name: 'HUMBOLDT TN',
                },
                {
                    mdm_location_id: 16622,
                    location_type_id: 2,
                    location_type_abbr: 'STORE',
                    location_type_code: 'STORE',
                    location_id: 1200,
                    location_name: 'COLORADO SPRINGS CO',
                    location_display_name: 'COLORADO SPRINGS CO',
                },
                {
                    mdm_location_id: 16623,
                    location_type_id: 2,
                    location_type_abbr: 'VNDR',
                    location_type_code: 'VNDR',
                    location_id: 15,
                    location_name: 'COLORADO',
                    location_display_name: 'COLORADO',
                },
                {
                    mdm_location_id: 710,
                    location_type_id: 6,
                    location_type_abbr: 'VNDR',
                    location_type_code: 'VNDR',
                    location_id: 12005,
                    location_name: 'Sample Carrier Loc',
                    location_display_name: 'Sample Carrier Loc',
                    vendor_nbr: '154',
                },
                {
                    mdm_location_id: 53318,
                    location_type_id: 6,
                    location_type_abbr: 'VNDR',
                    location_type_code: 'VNDR',
                    location_id: 12009700,
                    location_name: 'ELK BRAND MANUFACTURING CO',
                    location_display_name: 'ELK BRAND MANUFACTURING CO',
                    vendor_nbr: '120097',
                },
            ],
        },
    },
};
export const destLocationAutoCompleteMock = {
    status: 'SUCCESS',
    static_data: {
        locations: [
            {
                mdm_location_id: 17641,
                location_type_id: 2,
                location_type_abbr: 'STORE',
                location_type_code: 'STORE',
                location_id: 120,
                location_name: 'HUMBOLDT TN',
                location_display_name: 'HUMBOLDT TN',
            },
            {
                mdm_location_id: 16622,
                location_type_id: 2,
                location_type_abbr: 'STORE',
                location_type_code: 'STORE',
                location_id: 1200,
                location_name: 'COLORADO SPRINGS CO',
                location_display_name: 'COLORADO SPRINGS CO',
            },
            {
                mdm_location_id: 16623,
                location_type_id: 2,
                location_type_abbr: 'VNDR',
                location_type_code: 'VNDR',
                location_id: 15,
                location_name: 'COLORADO',
                location_display_name: 'COLORADO',
            },
            {
                mdm_location_id: 710,
                location_type_id: 6,
                location_type_abbr: 'VNDR',
                location_type_code: 'VNDR',
                location_id: 12005,
                location_name: 'Sample Carrier Loc',
                location_display_name: 'Sample Carrier Loc',
                vendor_nbr: '154',
            },
            {
                mdm_location_id: 53318,
                location_type_id: 6,
                location_type_abbr: 'VNDR',
                location_type_code: 'VNDR',
                location_id: 12009700,
                location_name: 'ELK BRAND MANUFACTURING CO',
                location_display_name: 'ELK BRAND MANUFACTURING CO',
                vendor_nbr: '120097',
            },
        ],
    },
};
export const staticDataMock = {
    payload: {
        om_static_data: {
            payload: {
                staticData: {
                    planCategory: [
                        {
                            id: 2,
                            code: 'PLT',
                            abbr: 'PLT',
                            description: 'Trailer w/ Pallets only',
                        },
                        {
                            id: 1,
                            code: 'STR',
                            abbr: 'STR',
                            description: 'DC Loading to Warehouse - Single Trailer',
                        },
                        {
                            id: 3,
                            code: 'CLM',
                            abbr: 'CLM',
                            description: 'Trailer w/ Claim only',
                        },
                        {
                            id: 4,
                            code: 'RTN',
                            abbr: 'RTN',
                            description: 'Returnd',
                        },
                        {
                            id: 5,
                            code: 'BOB',
                            abbr: 'BOB',
                            description: 'BObtail',
                        },
                        {
                            id: 6,
                            code: 'DHD',
                            abbr: 'DHD',
                            description: 'DeadHead',
                        },
                        {
                            id: 7,
                            code: 'BOX',
                            abbr: 'BOX',
                            description: 'Box',
                        },
                        {
                            id: 8,
                            code: 'STK',
                            abbr: 'STK',
                            description: 'Stock to Stock',
                        },
                        {
                            id: 9,
                            code: 'WMGW',
                            abbr: 'WMGW',
                            description: 'Walmart Good Works',
                        },
                        {
                            id: 10,
                            code: 'GRSTR',
                            abbr: 'GRSTR',
                            description: 'Grocery Store',
                        },
                    ],
                },
            },
        },
        mdm_static_data: {
            static_data: {
                time_zones_juris: [
                    {
                        id: 412,
                        code: 'AR',
                        abbr: 'AR',
                        desc: 'Argentine Time D/L NO',
                        olsen_timezone_id: 'America/Winnipeg',
                        daylight_offset_sec_qty: -10800,
                        gmt_offset_sec_qty: -10800,
                        daylight_saving_ind: 'N',
                    },
                ],
                equipment_lengths: [
                    {
                        id: 34,
                        code: '13.7',
                        length: 13.7,
                        uom: {
                            id: 8,
                            code: 'M',
                            abbr: 'M',
                            desc: 'Meter',
                        },
                    },
                    {
                        id: 30,
                        code: '60.0',
                        length: 60,
                        uom: {
                            id: 4,
                            code: 'FT',
                            abbr: 'FT',
                            desc: 'Foot',
                        },
                    },
                    {
                        id: 21,
                        code: '53.0',
                        length: 53,
                        uom: {
                            id: 4,
                            code: 'FT',
                            abbr: 'FT',
                            desc: 'Foot',
                        },
                    },
                ],
                master_equipment_types: [
                    {
                        id: 9,
                        code: 'FL',
                        abbr: 'FL',
                        desc: 'Flatbed',
                    },
                    {
                        id: 12,
                        code: 'ST',
                        abbr: 'ST',
                        desc: 'Straight Truck',
                    },
                    {
                        id: 23,
                        code: 'DRYV',
                        abbr: 'DRYV',
                        desc: 'DRYV',
                    },
                ],
                modes: [
                    {
                        id: 1,
                        code: 'TL',
                        abbr: 'TL',
                        desc: 'Full Truck Load',
                    },
                    {
                        id: 8,
                        code: 'IM',
                        abbr: 'IM',
                        desc: 'Intermodal',
                    },
                    {
                        id: 2,
                        code: 'LTL',
                        abbr: 'LTL',
                        desc: 'Less Than Truck Load',
                    },
                ],
                service_levels: [
                    {
                        id: 267,
                        code: 'DEDF',
                        abbr: 'DEDF',
                        desc: 'DEDF',
                    },
                    {
                        id: 232,
                        code: 'OCEAN',
                        abbr: 'OCEAN',
                        desc: 'OCEAN',
                    },
                    {
                        id: 224,
                        code: 'EMPTY',
                        abbr: 'EMPTY',
                        desc: 'EMPTY',
                    },
                    {
                        id: 1,
                        code: 'SINGLE',
                        abbr: 'SINGLE',
                        desc: 'SINGLE',
                    },
                    {
                        id: 2,
                        code: 'TEAM',
                        abbr: 'TEAM',
                        desc: 'TEAM',
                    },
                ],
            },
        },
    },
};
export const locationSearchMock = {
    payload: {
        locations: [
            {
                time_zone_info: {
                    timezone: 290,
                    day_light_saving: 'Y',
                    zulu_adj_factor: 5,
                    olsen_timezone_id: 'America/Winnipeg',
                    time_zone_code: 'CDT',
                    time_zone_abbr: 'CDT',
                    time_zone_desc: 'Central Standard Time D/L Savings Yes',
                    daylight_offset_sec_qty: null,
                    gmt_offset_sec_qty: null,
                    short_abbr: null,
                },
                address: [
                    {
                        street: '2716 N CENTRAL AVE',
                        city: 'HUMBOLDT',
                        state_code: 'TN',
                        state_desc: null,
                        zip_code: '38343',
                        address_type_id: 3,
                        address_type_abbr: 'PA',
                        address_type_code: 'PA',
                        address_type_desc: 'Primary address',
                        bldg_address: '2716 N CENTRAL AVE',
                        country_code: 'US',
                        country_desc: null,
                        is_active: false,
                        county: 'GIBSON',
                        company: null,
                        zip_plus_four: null,
                        municipality: null,
                        department: null,
                        suburb: null,
                        neighbourhood: null,
                        district: null,
                        region: '22',
                        province: null,
                        notes: null,
                        longitude: 88.911864,
                        latitude: 35.840797,
                        last_change_userid: 'BUSYNC',
                        last_change_ts: '2022-09-20T07:29:31.623+00:00',
                    },
                ],
            },
        ],
    },
};
export const locationSearch2Mock = {
    payload: {
        locations: [
            {
                time_zone_info: {
                    timezone: 290,
                    day_light_saving: 'Y',
                    zulu_adj_factor: 5,
                    olsen_timezone_id: 'America/Argentina/Mendoza',
                    time_zone_code: 'CDT',
                    time_zone_abbr: 'CDT',
                    time_zone_desc: 'Central Standard Time D/L Savings Yes',
                    daylight_offset_sec_qty: null,
                    gmt_offset_sec_qty: null,
                    short_abbr: null,
                },
                address: [
                    {
                        street: '2716 N CENTRAL AVE',
                        city: 'HUMBOLDT',
                        state_code: 'TN',
                        state_desc: null,
                        zip_code: '38343',
                        address_type_id: 3,
                        address_type_abbr: 'PA',
                        address_type_code: 'PA',
                        address_type_desc: 'Primary address',
                        bldg_address: '2716 N CENTRAL AVE',
                        country_code: 'US',
                        country_desc: null,
                        is_active: false,
                        county: 'GIBSON',
                        company: null,
                        zip_plus_four: null,
                        municipality: null,
                        department: null,
                        suburb: null,
                        neighbourhood: null,
                        district: null,
                        region: '22',
                        province: null,
                        notes: null,
                        longitude: 88.911864,
                        latitude: 35.840797,
                        last_change_userid: 'BUSYNC',
                        last_change_ts: '2022-09-20T07:29:31.623+00:00',
                    },
                ],
            },
        ],
    },
};
export const createLoadSuccessMock = {
    payload: [
        {
            identifiers: {
                tenantId: 'US_US',
                deliveryOrderId: [700080631],
                planId: 10080631,
            },
        },
    ],
};
export const staticDataErrorMock = {
    errors: [
        {
            code: 'OMA-400.001',
            field: null,
            description: 'Check error identifiers for specific details.',
            info: 'At least one of the underlying APIs failed.',
            severity: 'ERROR',
            category: 'REQUEST',
            causes: [],
            errorIdentifiers: {
                details: {
                    mdm_static_data: {
                        httpStatusCode: '204',
                        httpStatus: 'No-Content found:stride-configmgmt.wcnp.dev.walmart.com/staticData',
                        severity: 'INFO',
                    },
                    om_static_data: {
                        status: 'NOT_FOUND',
                        errors: [
                            {
                                code: 'STRIDE_API_0037',
                                field: 'TENANT SA',
                                description: 'Invalid Tenant ID',
                                severity: 'LOW',
                                category: 'DAL',
                                causes: '',
                            },
                        ],
                    },
                },
            },
        },
    ],
};
export const locationSearchErrorMock = {
    errors: [
        {
            severity: 'ERROR',
            errorIdentifiers: {
                details: {
                    errors: [
                        {
                            description: 'Service Failure',
                            severity: 'ERROR',
                        },
                    ],
                },
            },
        },
    ],
};
export const createLoadErrorMock = {
    errors: [
        {
            severity: 'ERROR',
            errorIdentifiers: {
                details: {
                    errors: [
                        {
                            description: 'Service Failure',
                            severity: 'ERROR',
                        },
                    ],
                },
            },
        },
    ],
};

export const ccmAppConfigMock = {
    timeout: '30000',
    debounceTime: '500',
    country: {
        currency: ['USD'],
        id: '44',
        iso2: 'CA',
        iso3: 'CA',
        name: 'Canada',
    },
    openLoadDelayTimeInMillisecs: '5000',
    autoCompleteMaxCount: '10',
    autoCompleteMinSearchLength: '1',
    featureFlags: {
        enableStaticAndConfigHoc: true,
    },
};

export const commentsMock = [
    {
        commentId: 2,
        commentText: 'add comment 2 - edit',
        commentType: 'GENERAL',
        commentBy: 'b0s09le',
        commentTimestamp: '12 Jun, 2024; 17:16',
        createdTs: '2024-06-12T17:16:41.838-05:00',
        lastUpdatedTs: '2024-06-12T17:16:49.392-05:00',
    },
    {
        commentId: 1,
        commentText: 'add comment 1',
        commentType: 'GENERAL',
        commentBy: 'b0s09le',
        commentTimestamp: '12 Jun, 2024; 17:16',
        createdTs: '2024-06-12T17:16:37.300-05:00',
    },
];
export const commentsPayload = [
    {
        commentId: 2,
        commentText: 'add comment 2 - edit',
        createdByUserId: 'b0s09le',
        createdTs: '2024-06-12T17:16:41.838-05:00',
        lastUpdatedTs: '2024-06-12T17:16:49.392-05:00',
        commentType: 'GENERAL',
    },
    {
        commentId: 1,
        commentText: 'add comment 1',
        createdByUserId: 'b0s09le',
        createdTs: '2024-06-12T17:16:37.300-05:00',
        lastUpdatedTs: '2024-06-12T17:16:37.300-05:00',
        commentType: 'GENERAL',
    },
];
export const createLoadV2PlanError = {
    errors: [
        {
            errorIdentifiers: {
                details: {
                    toResponse: {
                        status: 'CREATED',
                        header: {
                            headerAttributes: {},
                        },
                        errors: [],
                        payload: {},
                    },
                    planResponse: {
                        status: 'BAD_REQUEST',
                        errors: [
                            {
                                field: 'stopactivitytype',
                                description: 'Invalid value',
                                severity: 'HIGH',
                                category: 'SERVICE',
                            },
                        ],
                    },
                    shipmentResponse: {
                        status: 'CREATED',
                        header: {
                            headerAttributes: {},
                        },
                        errors: [],
                        payload: [{}],
                    },
                },
            },
        },
    ],
};

export const createLoadShipmentError = {
    errors: [
        {
            errorIdentifiers: {
                details: {
                    toResponse: {
                        status: 'CREATED',
                        header: {
                            headerAttributes: {},
                        },
                        errors: [],
                        payload: {},
                    },
                    planResponse: {
                        status: 'BAD_REQUEST',
                        errors: [],
                        payload: {},
                    },
                    shipmentResponse: {
                        status: 'FAIL',
                        errors: [
                            {
                                code: 'SERVICE_001',
                                field: 'TRANSIT-SERVICE',
                                description:
                                    'TRANSIT-SERVICE service call failed with following Error:400 Bad Request. TRANSIT-SERVICE service call failed with following Error:400 Bad Request.TRANSIT-SERVICE service call failed with following Error:400 Bad Request',
                                info: 'TrackingId = 90b4a05d-2ea9-4eb2-af3f-ffba3f44d765',
                                severity: 'ERROR',
                                category: 'REQUEST',
                                causes: [],
                            },
                        ],
                        payload: null,
                    },
                },
            },
        },
    ],
};

export const createLoadTOError = {
    errors: [
        {
            errorIdentifiers: {
                details: {
                    toResponse: {
                        status: 'CREATED',
                        header: {
                            headerAttributes: {},
                        },
                        errors: [
                            {
                                code: 'SERVICE_001',
                                field: 'TRANSIT-SERVICE',
                                description:
                                    'TRANSIT-SERVICE service call failed with following Error:400 Bad Request. TRANSIT-SERVICE service call failed with following Error:400 Bad Request.TRANSIT-SERVICE service call failed with following Error:400 Bad Request',
                                info: 'TrackingId = 90b4a05d-2ea9-4eb2-af3f-ffba3f44d765',
                                severity: 'ERROR',
                                category: 'REQUEST',
                                causes: [],
                            },
                        ],
                        payload: {},
                    },
                    planResponse: {
                        status: 'BAD_REQUEST',
                        errors: [
                            {
                                field: 'stopactivitytype',
                                description: 'Invalid value',
                                severity: 'HIGH',
                                category: 'SERVICE',
                            },
                        ],
                    },
                    shipmentResponse: {
                        status: 'CREATED',
                        header: {
                            headerAttributes: {},
                        },
                        errors: [],
                        payload: [{}],
                    },
                },
            },
        },
    ],
};

export const carrierAutoCompleteMock = {
    status: 'SUCCESS',
    payload: {
        static_data: {
            carrier_codes: [
                {
                    carrier_id: 'BBCEFB',
                    mdm_carrier_id: 10473,
                    industry_scac: 'BFBBBE',
                    vendor_nbr: '268888',
                    carrier_name: 'Test 77751',
                    trp_carrier_ids: ['ACCBBD'],
                },
                {
                    carrier_id: 'BBECEC',
                    mdm_carrier_id: 10682,
                    industry_scac: 'AFFEBA',
                    vendor_nbr: '670247',
                    carrier_name: 'Test 80882',
                    trp_carrier_ids: ['DFEEDD'],
                },
                {
                    carrier_id: 'BBSE',
                    mdm_carrier_id: 8326,
                    industry_scac: 'BBSE',
                    vendor_nbr: '29587',
                    carrier_name: 'B2B TRANSPORT MARKET, LLC',
                    trp_carrier_ids: ['BBSE'],
                },
            ],
        },
    },
};
