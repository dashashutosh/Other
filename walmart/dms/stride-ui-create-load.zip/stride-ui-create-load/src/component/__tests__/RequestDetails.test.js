import React from 'react';
import { render, screen, fireEvent } from '../../utils/__tests__/test-utils';
import RequestDetails from '../RequestDetails';
import { defaultFormValues } from '../../Constants';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from './mocks/mocks';

const staticData = {
    requestTypes: [
        { id: 'PLT', value: 'PLT - Pallets', abbr: 'PLT' },
        { id: 'CLM', value: 'CLM - Claims', abbr: 'CLM' },
        { id: 'STR', value: 'STR - store', abbr: 'STR' },
        { id: 'RTN', value: 'RTN - returns', abbr: 'RTN' },
        { id: 'BOB', value: 'BOB - bobtail', abbr: 'BOB' },
        { id: 'DHD', value: 'DHD - Deadhead', abbr: 'DHD' },
        { id: 'BOX', value: 'BOX - box', abbr: 'BOX' },
        { id: 'STK', value: 'STK - stk', abbr: 'STK' },
        { id: 'WMGW', value: 'WMGW - wmgw', abbr: 'WMGW' },
        { id: 'GRSTR', value: 'GRSTR - Grocery Store', abbr: 'GRSTR' },
    ],
};

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

describe('Request Details component', () => {
    it('should render correctly', async () => {
        render(<RequestDetails pDetails={defaultFormValues} pOnEdit={() => {}} pStaticData={staticData} />);
        const title = await screen.findByText('Request details');
        expect(title).toBeDefined();
    });

    it('onchange for request type chips', async () => {
        const changeMock = jest.fn();
        render(<RequestDetails pDetails={defaultFormValues} pOnEdit={changeMock} pStaticData={staticData} />);
        const chip1 = await screen.findByText('PLT - Pallets');
        expect(chip1).toBeDefined();
        fireEvent.click(chip1);
        expect(changeMock).toBeCalledWith('requestType', 'PLT');
        const chip2 = await screen.findByText('CLM - Claims');
        expect(chip2).toBeDefined();
        fireEvent.click(chip2);
        expect(changeMock).toBeCalledWith('requestType', 'CLM');
    });
    it('Should render new load types when feature flag enableManualCreateLoadChanges and showGRSTR enabled', () => {
        const changeMock = jest.fn();
        render(
            <RequestDetails
                pDetails={defaultFormValues}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pFeatureFlags={{ enableManualCreateLoadChanges: true, showGRSTR: true }}
            />,
        );
        const chip1 = screen.queryByText('PLT - Pallets');
        expect(chip1).toBeNull();
        const chip2 = screen.queryByText('CLM - Claims');
        expect(chip2).toBeNull();

        const PLT = screen.getByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);
        expect(changeMock).toBeCalledWith('requestType', 'PLT');
        const CLM = screen.getByText('CLM');
        expect(CLM).toBeDefined();
        fireEvent.click(CLM);
        expect(changeMock).toBeCalledWith('requestType', 'CLM');
        const STR = screen.getByText('STR');
        expect(STR).toBeDefined();
        fireEvent.click(STR);
        expect(changeMock).toBeCalledWith('requestType', 'STR');
        const RTN = screen.getByText('RTN');
        expect(RTN).toBeDefined();
        fireEvent.click(RTN);
        expect(changeMock).toBeCalledWith('requestType', 'RTN');
        const BOB = screen.getByText('BOB');
        expect(BOB).toBeDefined();
        fireEvent.click(BOB);
        expect(changeMock).toBeCalledWith('requestType', 'BOB');
        const DHD = screen.getByText('DHD');
        expect(DHD).toBeDefined();
        fireEvent.click(DHD);
        expect(changeMock).toBeCalledWith('requestType', 'DHD');
        const BOX = screen.getByText('BOX');
        expect(BOX).toBeDefined();
        fireEvent.click(BOX);
        expect(changeMock).toBeCalledWith('requestType', 'BOX');
        const STK = screen.getByText('STK');
        expect(STK).toBeDefined();
        fireEvent.click(STK);
        expect(changeMock).toBeCalledWith('requestType', 'STK');
        const WMGW = screen.getByText('WMGW');
        expect(WMGW).toBeDefined();
        fireEvent.click(WMGW);
        expect(changeMock).toBeCalledWith('requestType', 'WMGW');
        const GRSTR = screen.getByText('GRSTR');
        expect(GRSTR).toBeDefined();
        fireEvent.click(GRSTR);
        expect(changeMock).toBeCalledWith('requestType', 'GRSTR');
    });
    it('Should render PLT, CLM when feature flag enableManualCreateLoadChanges true and allowOnlySingleStopLoadTypes true', () => {
        const changeMock = jest.fn();
        render(
            <RequestDetails
                pDetails={defaultFormValues}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pFeatureFlags={{ enableManualCreateLoadChanges: true, allowOnlySingleStopLoadTypes: true }}
            />,
        );
        const chip1 = screen.queryByText('PLT - Pallets');
        expect(chip1).toBeNull();
        const chip2 = screen.queryByText('CLM - Claims');
        expect(chip2).toBeNull();

        const PLT = screen.getByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);
        expect(changeMock).toBeCalledWith('requestType', 'PLT');
        const CLM = screen.getByText('CLM');
        expect(CLM).toBeDefined();
        fireEvent.click(CLM);
        expect(changeMock).toBeCalledWith('requestType', 'CLM');
    });
    it('Should render all load types when feature flag enableManualCreateLoadChanges true and allowOnlySingleStopLoadTypes false', () => {
        const changeMock = jest.fn();
        render(
            <RequestDetails
                pDetails={defaultFormValues}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pFeatureFlags={{ enableManualCreateLoadChanges: true, allowOnlySingleStopLoadTypes: false }}
            />,
        );
        const chip1 = screen.queryByText('PLT - Pallets');
        expect(chip1).toBeNull();
        const chip2 = screen.queryByText('CLM - Claims');
        expect(chip2).toBeNull();

        const PLT = screen.getByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);
        expect(changeMock).toBeCalledWith('requestType', 'PLT');
        const CLM = screen.getByText('CLM');
        expect(CLM).toBeDefined();
        fireEvent.click(CLM);
        expect(changeMock).toBeCalledWith('requestType', 'CLM');
        const STR = screen.getByText('STR');
        expect(STR).toBeDefined();
        fireEvent.click(STR);
        expect(changeMock).toBeCalledWith('requestType', 'STR');
        const RTN = screen.getByText('RTN');
        expect(RTN).toBeDefined();
        fireEvent.click(RTN);
        expect(changeMock).toBeCalledWith('requestType', 'RTN');
        const BOB = screen.getByText('BOB');
        expect(BOB).toBeDefined();
        fireEvent.click(BOB);
        expect(changeMock).toBeCalledWith('requestType', 'BOB');
        const DHD = screen.getByText('DHD');
        expect(DHD).toBeDefined();
        fireEvent.click(DHD);
        expect(changeMock).toBeCalledWith('requestType', 'DHD');
        const BOX = screen.getByText('BOX');
        expect(BOX).toBeDefined();
        fireEvent.click(BOX);
        expect(changeMock).toBeCalledWith('requestType', 'BOX');
        const STK = screen.getByText('STK');
        expect(STK).toBeDefined();
        fireEvent.click(STK);
        expect(changeMock).toBeCalledWith('requestType', 'STK');
        const WMGW = screen.getByText('WMGW');
        expect(WMGW).toBeDefined();
        fireEvent.click(WMGW);
        expect(changeMock).toBeCalledWith('requestType', 'WMGW');
    });
    it('Should not render new load types when feature flag enableManualCreateLoadChanges and showGRSTR disabled', () => {
        const changeMock = jest.fn();
        render(
            <RequestDetails
                pDetails={defaultFormValues}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pFeatureFlags={{ enableManualCreateLoadChanges: false, showGRSTR: false }}
            />,
        );
        const chip1 = screen.getByText('PLT - Pallets');
        expect(chip1).toBeDefined();
        const chip2 = screen.getByText('CLM - Claims');
        expect(chip2).toBeDefined();

        const PLT = screen.queryByText('PLT');
        expect(PLT).toBeNull();
        const CLM = screen.queryByText('CLM');
        expect(CLM).toBeNull();
        const STR = screen.queryByText('STR');
        expect(STR).toBeNull();
        const RTN = screen.queryByText('RTN');
        expect(RTN).toBeNull();
        const BOB = screen.queryByText('BOB');
        expect(BOB).toBeNull();
        const DHD = screen.queryByText('DHD');
        expect(DHD).toBeNull();
        const BOX = screen.queryByText('BOX');
        expect(BOX).toBeNull();
        const STK = screen.queryByText('STK');
        expect(STK).toBeNull();
        const WMGW = screen.queryByText('WMGW');
        expect(WMGW).toBeNull();
        const GRSTR = screen.queryByText('GRSTR');
        expect(GRSTR).toBeNull();
    });
    it('should display * label for mandatory fields', async () => {
        render(
            <RequestDetails
                pDetails={defaultFormValues}
                pOnEdit={() => {}}
                pStaticData={staticData}
                pFeatureFlags={{ enableManualCreateLoadChanges: false }}
            />,
        );
        const title = await screen.findByText('Request details');
        expect(title).toBeDefined();
        expect(await screen.findByText('Request type')).toBeDefined();
    });
});
