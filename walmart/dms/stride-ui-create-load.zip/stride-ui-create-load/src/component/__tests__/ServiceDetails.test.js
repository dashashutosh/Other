import React from 'react';
import { render, screen, fireEvent } from '../../utils/__tests__/test-utils';
import ServiceDetails from '../ServiceDetails';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from './mocks/mocks';
import ManageableCardsEnum from '../../utils/LoadConfigs/ManageableCardsEnum';

const staticData = {
    serviceLevelList: [
        { id: 'DEDF', value: 'DEDF' },
        { id: 'OCEAN', value: 'OCEAN' },
        { id: 'EMPTY', value: 'EMPTY' },
        { id: 'SINGLE', value: 'SINGLE' },
        { id: 'TEAM', value: 'TEAM' },
    ],
    serviceModeList: [
        { id: 'TL', value: 'TL (Full Truck Load)' },
        { id: 'IM', value: 'IM (Intermodal)' },
        { id: 'LTL', value: 'LTL (Less Than Truck Load)' },
    ],
};
const pageConfig = {
    fields: {
        MODE: {},
        LEVEL: {},
    },
    sections: [],
};

const pageConfigMandatoryField = {
    fields: {
        MODE: {
            validations: ['MANDATORY_FIELD'],
            isEditable: true,
        },
        LEVEL: {
            validations: ['MANDATORY_FIELD'],
            isEditable: true,
        },
    },
    sections: { [ManageableCardsEnum.CARRIER_DETAILS.name]: {} },
};

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

jest.mock('@gscope-mfe/common-components', () => {
    const actualModule = jest.requireActual('@gscope-mfe/common-components');
    const transalations = {
        'title.serviceDetails': 'Service details',
        'subTitle.mode': 'Mode',
        'subTitle.level': 'Level',
    };
    return {
        ...actualModule,
        LocalizeLang: {
            default: {
                ...actualModule.LocalizeLang.default,
                localizeLang: () => jest.fn((callback) => transalations[callback]),
            },
        },
    };
});

describe('Service Details component', () => {
    it('should render correctly', () => {
        render(
            <ServiceDetails
                pDetails={{
                    mode: 'TL',
                    serviceLevel: 'SINGLE',
                }}
                pOnEdit={() => {}}
                pStaticData={staticData}
                pPageConfig={pageConfig}
            />,
        );
        const title = screen.getByText('Service details');
        expect(title).toBeDefined();
        expect(screen.getByText('Mode')).toBeDefined();
        expect(screen.getByText('Level')).toBeDefined();
        expect(screen.getByText('TL (Full Truck Load)')).toBeDefined();
        expect(screen.getByText('LTL (Less Than Truck Load)')).toBeDefined();
        expect(screen.queryByText('IM (Intermodal)')).toBeNull();

        expect(screen.getByText('SINGLE')).toBeDefined();
        expect(screen.getByText('TEAM')).toBeDefined();
        expect(screen.queryByText('EMPTY')).toBeNull();
        expect(screen.queryByText('OCEAN')).toBeNull();
    });

    it('should display default values for mode and level', () => {
        const changeMock = jest.fn();
        render(
            <ServiceDetails
                pDetails={{
                    mode: 'TL',
                    serviceLevel: 'SINGLE',
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pPageConfig={pageConfig}
            />,
        );
        const title = screen.getByText('Service details');
        expect(title).toBeDefined();
        const modes = screen.queryAllByTestId('mode');
        expect(modes[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
        const levels = screen.queryAllByTestId('level');
        expect(levels[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
    });
    it('should call pOnEdit when mode is changed', () => {
        const changeMock = jest.fn();
        render(
            <ServiceDetails
                pDetails={{
                    mode: 'TL',
                    serviceLevel: 'SINGLE',
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pPageConfig={pageConfig}
            />,
        );
        const title = screen.getByText('Service details');
        expect(title).toBeDefined();
        const modes = screen.queryAllByTestId('mode');
        expect(modes[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
        expect(modes[1].className).toEqual('ld-sc-ui-segment ld-sc-ui-regular-segment');

        fireEvent.click(modes[1]);
        expect(changeMock).toBeCalledWith('mode', 'LTL');
    });
    it('should call pOnEdit when level is changed', () => {
        const changeMock = jest.fn();
        render(
            <ServiceDetails
                pDetails={{
                    mode: 'TL',
                    serviceLevel: 'SINGLE',
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pPageConfig={pageConfig}
            />,
        );
        const title = screen.getByText('Service details');
        expect(title).toBeDefined();
        const levels = screen.queryAllByTestId('level');
        expect(levels[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
        expect(levels[1].className).toEqual('ld-sc-ui-segment ld-sc-ui-regular-segment');

        fireEvent.click(levels[1]);
        expect(changeMock).toBeCalledWith('serviceLevel', 'TEAM');
    });
    it('should display * for mandatory fields', () => {
        render(
            <ServiceDetails
                pDetails={{
                    mode: 'TL',
                    serviceLevel: 'SINGLE',
                }}
                pOnEdit={() => {}}
                pStaticData={staticData}
                pPageConfig={pageConfigMandatoryField}
            />,
        );
        const title = screen.getByText('Service details');
        expect(title).toBeDefined();
        expect(screen.getByText('*Mode')).toBeDefined();
        expect(screen.getByText('*Level')).toBeDefined();
    });

    it('Service level DEDF should be visible and default DEDF selected for GRSTR load type and carrier other than WALM', () => {
        const changeMock = jest.fn();
        render(
            <ServiceDetails
                pDetails={{
                    serviceLevel: 'SINGLE',
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pPageConfig={pageConfigMandatoryField}
                pLoadType="GRSTR"
                pCarrier={{
                    id: 'BAGC',
                    value: 'BAGC - BLAIR LOGISTICS LLC',
                }}
            />,
        );
        const title = screen.getByText('Service details');
        expect(title).toBeDefined();
        expect(screen.getByText('*Level')).toBeDefined();
        expect(screen.getByText('DEDF')).toBeDefined();

        const levels = screen.queryAllByTestId('level');
        expect(levels[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment'); //DEDF
        expect(levels[1].className).toEqual('ld-sc-ui-segment ld-sc-ui-regular-segment'); // SINGLE
        expect(levels[2].className).toEqual('ld-sc-ui-segment ld-sc-ui-regular-segment'); // TEAM
    });
    it('Service level DEDF should be visible and SINGLE selected for GRSTR load type and for carrier WALM', () => {
        const changeMock = jest.fn();
        render(
            <ServiceDetails
                pDetails={{
                    serviceLevel: 'SINGLE',
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pPageConfig={pageConfigMandatoryField}
                pLoadType="GRSTR"
                pCarrier={{
                    id: 'WALM',
                    value: 'WALM - WALM LOGISTICS LLC',
                }}
            />,
        );
        const title = screen.getByText('Service details');
        expect(title).toBeDefined();
        expect(screen.getByText('*Level')).toBeDefined();
        expect(screen.getByText('DEDF')).toBeDefined();

        const levels = screen.queryAllByTestId('level');
        expect(levels[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-regular-segment'); //DEDF
        expect(levels[1].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment'); // SINGLE
        expect(levels[2].className).toEqual('ld-sc-ui-segment ld-sc-ui-regular-segment'); // TEAM

        fireEvent.click(levels[2]);
        expect(changeMock).toBeCalledWith('serviceLevel', 'TEAM');
    });
});
