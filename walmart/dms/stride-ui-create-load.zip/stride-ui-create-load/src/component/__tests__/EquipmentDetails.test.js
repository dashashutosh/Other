import React from 'react';
import { render, screen, fireEvent } from '../../utils/__tests__/test-utils';
import EquipmentDetails from '../EquipmentDetails';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from './mocks/mocks';

const staticData = {
    equipmentTypes: [
        { id: 'FL', value: 'FL' },
        { id: 'ST', value: 'ST' },
        { id: 'DRYV', value: 'DRYV' },
    ],
    equipmentLengths: [
        { id: '13.7', value: '13.7 m', uom: 'M' },
        { id: '60', value: '60 ft', uom: 'FT' },
        { id: '53', value: '53 ft', uom: 'FT' },
    ],
};
const pageConfig = {
    EQUIPMENT_TYPE: {},
    EQUIPMENT_LENGTH: {},
    EQUIPMENT_ID: {},
};

const pageConfigMandatoryField = {
    EQUIPMENT_TYPE: {
        validations: ['MANDATORY_FIELD'],
        isEditable: true,
    },
    EQUIPMENT_LENGTH: {
        validations: ['MANDATORY_FIELD'],
        isEditable: true,
    },
    EQUIPMENT_ID: {
        isEditable: true,
    },
};

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

jest.mock('@gscope-mfe/common-components', () => {
    const actualModule = jest.requireActual('@gscope-mfe/common-components');
    const transalations = {
        'title.equipmentDetails': 'Equipment details',
        'label.equipmentType': 'Equipment type',
        'label.equipmentLength': 'Equipment length',
        'label.equipmentID': 'Equipment ID',
    };
    return {
        ...actualModule,
        LocalizeLang: {
            default: {
                ...actualModule.LocalizeLang.default,
                localizeLang: () => jest.fn((callback) => transalations[callback]),
            },
        },
    };
});

describe('Equipment Details component', () => {
    it('should render correctly', () => {
        const changeMock = jest.fn();
        render(
            <EquipmentDetails
                pDetails={{
                    equipmentType: 'DRYV',
                    equipmentLength: '53',
                    equipmentId: null,
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pUOM={{ length: 'FT' }}
                pPageConfig={pageConfig}
            />,
        );
        const title = screen.getByText('Equipment details');
        expect(title).toBeDefined();
        expect(screen.getByText('Equipment type')).toBeDefined();
        expect(screen.getByText('Equipment length')).toBeDefined();
        expect(screen.getByText('Equipment ID')).toBeDefined();

        expect(screen.getByTestId('equipmentType').children[1].value).toEqual('DRYV');
        expect(screen.getByTestId('equipmentLength').children[1].value).toEqual('53 ft');
    });
    it('should call pOnEdit when equipment type is changed', () => {
        const changeMock = jest.fn();
        render(
            <EquipmentDetails
                pDetails={{
                    equipmentType: 'DRYV',
                    equipmentLength: '53',
                    equipmentId: null,
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pUOM={{ length: 'FT' }}
                pPageConfig={pageConfig}
            />,
        );
        const title = screen.getByText('Equipment details');
        expect(title).toBeDefined();
        expect(screen.getByText('Equipment type')).toBeDefined();
        expect(screen.getByText('Equipment length')).toBeDefined();
        expect(screen.getByText('Equipment ID')).toBeDefined();

        const equipmentType = screen.getByTestId('equipmentType');
        fireEvent.click(equipmentType);
        const flatbed = screen.getByText('FL');
        expect(flatbed).toBeDefined();
        fireEvent.click(flatbed);
        expect(changeMock).toBeCalledWith('equipmentType', 'FL');
    });
    it('should call pOnEdit when equipment length is changed', () => {
        const changeMock = jest.fn();
        render(
            <EquipmentDetails
                pDetails={{
                    equipmentType: 'DRYV',
                    equipmentLength: '53',
                    equipmentId: null,
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pUOM={{ length: 'FT' }}
                pPageConfig={pageConfig}
            />,
        );
        const title = screen.getByText('Equipment details');
        expect(title).toBeDefined();
        expect(screen.getByText('Equipment type')).toBeDefined();
        expect(screen.getByText('Equipment length')).toBeDefined();
        expect(screen.getByText('Equipment ID')).toBeDefined();

        const equipmentLength = screen.getByTestId('equipmentLength');
        fireEvent.click(equipmentLength);
        const option = screen.getByText('60 ft');
        expect(option).toBeDefined();
        fireEvent.click(option);
        expect(changeMock).toBeCalledWith('equipmentLength', '60');
    });
    it('should call pOnEdit when equipment ID is changed', () => {
        const changeMock = jest.fn();
        render(
            <EquipmentDetails
                pDetails={{
                    equipmentType: 'DRYV',
                    equipmentLength: '53',
                    equipmentId: null,
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pUOM={{ length: 'FT' }}
                pPageConfig={pageConfig}
            />,
        );
        const title = screen.getByText('Equipment details');
        expect(title).toBeDefined();
        expect(screen.getByText('Equipment type')).toBeDefined();
        expect(screen.getByText('Equipment length')).toBeDefined();
        expect(screen.getByText('Equipment ID')).toBeDefined();

        const equipmentId = screen.getByTestId('equipmentId');
        fireEvent.change(equipmentId, { target: { value: '1234' } });
        expect(changeMock).toBeCalledWith('equipmentId', '1234');
    });
    it('should display * for mandatory fields', () => {
        const changeMock = jest.fn();
        render(
            <EquipmentDetails
                pDetails={{
                    equipmentType: 'DRYV',
                    equipmentLength: '53',
                    equipmentId: null,
                }}
                pOnEdit={changeMock}
                pStaticData={staticData}
                pUOM={{ length: 'FT' }}
                pPageConfig={pageConfigMandatoryField}
            />,
        );
        const title = screen.getByText('Equipment details');
        expect(title).toBeDefined();
        expect(screen.getByText('*Equipment type')).toBeDefined();
        expect(screen.getByText('*Equipment length')).toBeDefined();
        expect(screen.getByText('Equipment ID')).toBeDefined();
    });
});
