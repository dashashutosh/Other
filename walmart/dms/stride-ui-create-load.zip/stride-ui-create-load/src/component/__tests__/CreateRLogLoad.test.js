import 'fake-indexeddb/auto';

import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { render, screen, fireEvent, wait, waitFor, within } from '../../utils/__tests__/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import {
    contextMock,
    locationAutoCompleteMock,
    staticDataMock,
    locationSearchMock,
    createLoadSuccessMock,
    destLocationAutoCompleteMock,
    staticDataErrorMock,
    locationSearchErrorMock,
    createLoadErrorMock,
    locationSearch2Mock,
    ccmAppConfigMock,
    createLoadV2PlanError,
    createLoadTOError,
    createLoadShipmentError,
    carrierAutoCompleteMock,
} from './mocks/mocks';
import CmsConfig from '../../service/__tests__/mocks/CmsConfig.json';
import CreateRLogLoad from '../CreateRLogLoad';
import SharedService from '../../service/SharedService';
import { UILoadTypeEnum } from '@walmart/stride-ui-commons';
import { getEquipment } from '../../service/CreateLoadServiceParams';

jest.mock('react-router-dom', () => ({
    useLocation: jest.fn().mockReturnValue({
        search: undefined,
    }),
}));

jest.mock('../../service/SharedService');

const server = setupServer(
    rest.post('api/gateway/v4/stride-ui-create-load-staticData/staticData', (req, res, ctx) =>
        res(ctx.json(staticDataMock)),
    ),
    rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(CmsConfig))),
    rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
        res(ctx.json(locationAutoCompleteMock)),
    ),
    rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
        res(ctx.json(locationSearchMock)),
    ),
    rest.post('/api/gateway/v4/stride-ui-create-load-createLoad/createLoad', (req, res, ctx) =>
        res(ctx.json(createLoadSuccessMock)),
    ),

    // API Calls used by the withStaticAndConfigDataHOC
    rest.post('api/gateway/v4/stride-ui-staticData-mdm/staticData', (req, res, ctx) =>
        res(ctx.json({ payload: staticDataMock.payload.mdm_static_data })),
    ),
    rest.post('api/gateway/v4/stride-ui-staticData-ltm/staticData', (req, res, ctx) =>
        res(ctx.json({ payload: staticDataMock.payload.om_static_data.payload })),
    ),
    rest.get('api/gateway/ccm/app/config-stride-ui-create-load-us', (req, res, ctx) => res(ctx.json(ccmAppConfigMock))),
    rest.post('/api/gateway/v4/stride-ui-create-load-createLoad/createLoadV2', (req, res, ctx) =>
        res(ctx.json(createLoadSuccessMock)),
    ),
);
afterEach(() => server.resetHandlers());

afterAll(() => server.close());
jest.setTimeout(70000);

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
    server.listen();
});
const userPermMock = JSON.stringify({
    permissions: ['us.stride.ltm-createLoad:READ', 'us.stride.ltm-createLoad:WRITE'],
    markets: ['us'],
});
const readPermMock = JSON.stringify({
    permissions: ['us.stride.ltm-createLoad:READ'],
    markets: ['us'],
});

describe('CreateRLogLoad component', () => {
    it('should render correctly', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();
        const locDetails = await screen.findAllByText('Location details');
        expect(locDetails).toBeDefined();
    });
});

describe('CreateRlogLoad flow with auto entity', () => {
    // To make react-window work on JSDOM - https://stackoverflow.com/a/62214834/1681255
    const originalOffsetHeight = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetHeight');
    const originalOffsetWidth = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetWidth');

    beforeAll(() => {
        Object.defineProperty(HTMLElement.prototype, 'offsetHeight', { configurable: true, value: 50 });
        Object.defineProperty(HTMLElement.prototype, 'offsetWidth', { configurable: true, value: 50 });
    });

    afterAll(() => {
        Object.defineProperty(HTMLElement.prototype, 'offsetHeight', originalOffsetHeight);
        Object.defineProperty(HTMLElement.prototype, 'offsetWidth', originalOffsetWidth);
    });

    it('submit button should be disabled when all data is not entered', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();
        const locDetails = await screen.findAllByText('Location details');
        expect(locDetails).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);
        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn).toBeDefined();
        expect(submitBtn.getAttribute('disabled')).toBe('');
    });

    it.skip('create load success flow', async () => {
        const date = new Date();
        date.setDate(date.getDate() + 5);

        const formValue = {
            originLocationId: null,
            originLocationIdInfo: null,
            destLocationId: null,
            destLocationIdInfo: null,
            pickUpDT: date,
            requestType: null,
        };
        render(<CreateRLogLoad pFormValue={formValue} />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();

        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();
        const chip1 = await screen.findByText('PLT - Trailer w/ Pallets only');
        expect(chip1).toBeDefined();
        fireEvent.click(chip1);

        // origin location
        const locDetails = await screen.findAllByText('Location details');
        expect(locDetails).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationLocDetails = await screen.findAllByText('Location details');
        expect(destinationLocDetails).toBeDefined();
        const destInputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(destInputs).toBeDefined();
        const destinationDropdown = destInputs[1];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(destLocationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
        );
        fireEvent.change(searchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        fireEvent.click(destination);

        // const submitBtn = screen.getByRole('button', { name: 'Submit Request' });
        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn).toBeDefined();
        await wait(() => {
            expect(submitBtn.getAttribute('disabled')).not.toBe('');
        });
        fireEvent.click(submitBtn);

        await screen.findByText('msg.createLoadSuccess');
        await screen.findByText("Click 'View load' to open the created load");

        const viewLoadBtn = await screen.findByText('View load');
        expect(viewLoadBtn).toBeDefined();
        fireEvent.click(viewLoadBtn);
        // fireEvent.click(origin.parentElement);
        expect(window.open).toBeCalledWith('/mfe/stride/planquery/loaddetails?planId=10080631');
    });

    it.skip('create load error', async () => {
        server.use(
            rest.post('/api/gateway/v4/stride-ui-create-load-createLoad/createLoad', (req, res, ctx) =>
                res(ctx.status(500), ctx.json(createLoadErrorMock)),
            ),
        );

        const date = new Date();
        date.setDate(date.getDate() + 5);

        const formValue = {
            originLocationId: null,
            originLocationIdInfo: null,
            destLocationId: null,
            destLocationIdInfo: null,
            pickUpDT: date,
            requestType: null,
        };
        render(<CreateRLogLoad pFormValue={formValue} />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();

        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();
        const chip1 = await screen.findByText('PLT - Trailer w/ Pallets only');
        expect(chip1).toBeDefined();
        fireEvent.click(chip1);

        // origin location
        const locDetails = await screen.findAllByText('Location details');
        expect(locDetails).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationLocDetails = await screen.findAllByText('Location details');
        expect(destinationLocDetails).toBeDefined();
        const destInputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(destInputs).toBeDefined();
        const destinationDropdown = destInputs[1];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(destLocationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
        );
        fireEvent.change(searchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        fireEvent.click(destination);

        // const submitBtn = screen.getByRole('button', { name: 'Submit Request' });
        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn).toBeDefined();
        await wait(() => {
            expect(submitBtn.getAttribute('disabled')).not.toBe('');
        });
        fireEvent.click(submitBtn);

        await screen.findByText('msg.createLoadSuccess');
        await screen.findByText("Click 'View load' to open the created load");

        const viewLoadBtn = await screen.findByText('View load');
        expect(viewLoadBtn).toBeDefined();
        fireEvent.click(viewLoadBtn);
        // fireEvent.click(origin.parentElement);
        expect(window.open).toBeCalledWith('/mfe/stride/planquery/loaddetails?planId=10080631');
    });

    it.skip('static data error', async () => {
        server.use(
            rest.post('/api/gateway/v4/stride-ui-create-load-staticData/staticData', (req, res, ctx) =>
                res(ctx.status(500), ctx.json(staticDataErrorMock)),
            ),
        );
        render(<CreateRLogLoad />);
        // Display Static Data Failure Alert.
        const msg = await screen.findByText("Couldn't process the request. Try again");
        expect(msg).toBeDefined();
    });

    it('Pickup date/time - Short timezone', async () => {
        const date = new Date();
        date.setDate(date.getDate() + 5);

        const formValue = {
            originLocationId: null,
            originLocationIdInfo: null,
            destLocationId: null,
            destLocationIdInfo: null,
            pickUpDT: date,
            requestType: null,
        };
        render(<CreateRLogLoad pFormValue={formValue} />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();

        // origin location
        const locDetails = await screen.findAllByText('Location details');
        expect(locDetails).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        const mainContainer = screen.getByTestId('create-rlog-load-container');
        await waitFor(() => {
            expect(mainContainer.dataset.loading).toBe('false');
        });

        const modelCalendar = await screen.findByText('Pickup date/time');
        expect(modelCalendar).toBeDefined();
        fireEvent.click(modelCalendar);
        const timezone = await screen.findByText('AR');
        expect(timezone).toBeDefined();
    });

    it('Pickup date/time - Display normal location timezone if no static data for the perticular olsenid', async () => {
        server.use(
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearch2Mock)),
            ),
        );
        const date = new Date();
        date.setDate(date.getDate() + 5);

        const formValue = {
            originLocationId: null,
            originLocationIdInfo: null,
            destLocationId: null,
            destLocationIdInfo: null,
            pickUpDT: date,
            requestType: null,
        };
        render(<CreateRLogLoad pFormValue={formValue} />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();

        // origin location
        const locDetails = await screen.findAllByText('Location details');
        expect(locDetails).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        const mainContainer = screen.getByTestId('create-rlog-load-container');
        await waitFor(() => {
            expect(mainContainer.dataset.loading).toBe('false');
        });

        const modelCalendar = await screen.findByText('Pickup date/time');
        expect(modelCalendar).toBeDefined();
        fireEvent.click(modelCalendar);
        const timezone = await screen.findByText('CDT');
        expect(timezone).toBeDefined();
    });

    it('location search error', async () => {
        server.use(
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.status(500), ctx.json(locationSearchErrorMock)),
            ),
        );
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();

        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();
        const chip1 = await screen.findByText('PLT - Trailer w/ Pallets only');
        expect(chip1).toBeDefined();
        fireEvent.click(chip1);

        // origin location
        const locDetails = await screen.findAllByText('Location details');
        expect(locDetails).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);
        // Display LocationTSSSearch Failure Alert.
        const msg = await screen.findByText('Error while fetching location info.');
        expect(msg).toBeDefined();
    }, 6000);
});

describe('CreateLoad component with feature flag enableManualCreateLoadChanges enabled', () => {
    beforeEach(() => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{"enableManualCreateLoadChanges": true, "showGRSTR": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
    });
    it('should render sections correctly', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();
        const equipmentDetails = await screen.findAllByText('Equipment details');
        expect(equipmentDetails).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        const serviceDetails = await screen.findAllByText('Service details');
        expect(serviceDetails).toBeDefined();
        const comments = await screen.findAllByText('Comments');
        expect(comments).toBeDefined();
    });

    it('should render the load types in request details', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        const CLM = await screen.findByText('CLM');
        expect(CLM).toBeDefined();
        const STR = await screen.findByText('STR');
        expect(STR).toBeDefined();
        const RTN = await screen.findByText('RTN');
        expect(RTN).toBeDefined();
        const BOB = await screen.findByText('BOB');
        expect(BOB).toBeDefined();
        const DHD = await screen.findByText('DHD');
        expect(DHD).toBeDefined();
        const BOX = await screen.findByText('BOX');
        expect(BOX).toBeDefined();
        const STK = await screen.findByText('STK');
        expect(STK).toBeDefined();
        const WMGW = await screen.findByText('WMGW');
        expect(WMGW).toBeDefined();
        const GRSTR = await screen.findByText('GRSTR');
        expect(GRSTR).toBeDefined();
    });
    it('should render the comments details', async () => {
        render(<CreateRLogLoad />);

        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();
        const comments = await screen.findAllByText('Comments');
        expect(comments).toBeDefined();
        const addComment = await screen.findByText('Add comment');
        expect(addComment).toBeDefined();
    });
    it('should add the comment', async () => {
        render(<CreateRLogLoad />);

        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const comments = await screen.findAllByText('Comments');
        expect(comments).toBeDefined();
        expect(await screen.findByText('No comments to show')).toBeDefined();
        const addComment = await screen.findByTestId('addButton');
        expect(addComment).toBeDefined();
        fireEvent.click(addComment);
        const commentInput = await screen.findByTestId('commentInput');
        fireEvent.change(commentInput, { target: { value: 'New test comment' } });
        fireEvent.click(await screen.findByTestId('post-comment-button'));
        const addedComment = await screen.findByText('New test comment');
        expect(addedComment).toBeDefined();
        expect(screen.queryByText('No comments to show')).toBeNull();
    });
    it('should edit the comment', async () => {
        render(<CreateRLogLoad />);

        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const comments = await screen.findAllByText('Comments');
        expect(comments).toBeDefined();
        expect(await screen.findByText('No comments to show')).toBeDefined();
        const addComment = await screen.findByTestId('addButton');
        expect(addComment).toBeDefined();
        fireEvent.click(addComment);
        const commentInput = await screen.findByTestId('commentInput');
        fireEvent.change(commentInput, { target: { value: 'New test comment' } });
        fireEvent.click(await screen.findByTestId('post-comment-button'));
        const addedComment = await screen.findByText('New test comment');
        expect(addedComment).toBeDefined();
        expect(screen.queryByText('No comments to show')).toBeNull();

        fireEvent.mouseOver(screen.getByText('New test comment'));
        fireEvent.click(screen.getByTestId('editIcon'));
        const commentInputEdit = screen.getByTestId('commentInput');
        fireEvent.change(commentInputEdit, { target: { value: 'Edited comment text' } });
        fireEvent.click(screen.getByTestId('post-comment-button'));
        expect(await screen.findByText('Edited comment text')).toBeDefined();
    });
    it('should delete the comment', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const comments = await screen.findAllByText('Comments');
        expect(comments).toBeDefined();
        expect(await screen.findByText('No comments to show')).toBeDefined();
        const addComment = await screen.findByTestId('addButton');
        expect(addComment).toBeDefined();
        fireEvent.click(addComment);
        const commentInput = await screen.findByTestId('commentInput');
        fireEvent.change(commentInput, { target: { value: 'New test comment' } });
        fireEvent.click(await screen.findByTestId('post-comment-button'));
        const addedComment = await screen.findByText('New test comment');
        expect(addedComment).toBeDefined();
        expect(screen.queryByText('No comments to show')).toBeNull();

        fireEvent.mouseOver(screen.getByText('New test comment'));
        fireEvent.click(screen.getByTestId('trashIcon'));
        expect(await screen.findByText('No comments to show')).toBeDefined();
    });
    it('should render the equipment details', async () => {
        render(<CreateRLogLoad />);

        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const equipDetails = await screen.findAllByText('Equipment details');
        expect(equipDetails).toBeDefined();
        expect(await screen.findByText('*Equipment type')).toBeDefined();
        expect(await screen.findByText('*Equipment length')).toBeDefined();
        expect(await screen.findByText('Equipment ID')).toBeDefined();

        expect(screen.getByTestId('equipmentType').children[1].value).toEqual('DRYV');
        expect(screen.getByTestId('equipmentLength').children[1].value).toEqual('53 ft');
    });
    it('should be able to edit equipment details', async () => {
        render(<CreateRLogLoad />);

        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const equipDetails = await screen.findAllByText('Equipment details');
        expect(equipDetails).toBeDefined();
        expect(await screen.findByText('*Equipment type')).toBeDefined();
        expect(await screen.findByText('*Equipment length')).toBeDefined();
        expect(await screen.findByText('Equipment ID')).toBeDefined();

        const equipmentType = await screen.findByTestId('equipmentType');
        expect(equipmentType).toBeDefined();
        expect(screen.getByTestId('equipmentType').children[1].value).toEqual('DRYV');

        fireEvent.click(equipmentType);
        const flatbed = screen.getByText('FL');
        expect(flatbed).toBeDefined();
        fireEvent.click(flatbed);
        expect(screen.getByTestId('equipmentType').children[1].value).toEqual('FL');

        const equipmentLength = await screen.findByTestId('equipmentLength');
        expect(equipmentLength).toBeDefined();
        expect(screen.getByTestId('equipmentLength').children[1].value).toEqual('53 ft');

        fireEvent.click(equipmentLength);
        const option = screen.getByText('60 ft');
        expect(option).toBeDefined();
        fireEvent.click(option);
        expect(screen.getByTestId('equipmentLength').children[1].value).toEqual('60 ft');

        const equipmentId = await screen.findByTestId('equipmentId');
        expect(equipmentId).toBeDefined();
        expect(screen.getByTestId('equipmentId').value).toEqual('');
        fireEvent.change(equipmentId, { target: { value: '1234' } });
        expect(screen.getByTestId('equipmentId').value).toEqual('1234');
    });
    it('should render the service details', async () => {
        render(<CreateRLogLoad />);

        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const serviceDetails = await screen.findAllByText('Service details');
        expect(serviceDetails).toBeDefined();
        expect(screen.getByText('*Mode')).toBeDefined();
        expect(screen.getByText('*Level')).toBeDefined();
        expect(screen.getByText('TL (Full Truck Load)')).toBeDefined();
        expect(screen.getByText('LTL (Less Than Truck Load)')).toBeDefined();
        expect(screen.queryByText('IM (Intermodal)')).toBeNull();

        expect(screen.getByText('SINGLE')).toBeDefined();
        expect(screen.getByText('TEAM')).toBeDefined();
        expect(screen.queryByText('EMPTY')).toBeNull();
        expect(screen.queryByText('OCEAN')).toBeNull();

        const modes = screen.queryAllByTestId('mode');
        expect(modes[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
        const levels = screen.queryAllByTestId('level');
        expect(levels[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
    });
    it('should be able to edit service details', async () => {
        render(<CreateRLogLoad />);

        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const serviceDetails = await screen.findAllByText('Service details');
        expect(serviceDetails).toBeDefined();
        expect(screen.getByText('*Mode')).toBeDefined();
        expect(screen.getByText('*Level')).toBeDefined();

        const modes = screen.queryAllByTestId('mode');
        expect(modes[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
        expect(modes[1].className).toEqual('ld-sc-ui-segment ld-sc-ui-regular-segment');
        fireEvent.click(modes[1]);
        expect(modes[1].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');

        const levels = screen.queryAllByTestId('level');
        expect(levels[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
        expect(levels[1].className).toEqual('ld-sc-ui-segment ld-sc-ui-regular-segment');
        fireEvent.click(levels[1]);
        expect(levels[1].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment');
    });
});

describe('getEquipment with enableDefaultEquipmentId true', () => {
    beforeEach(() => {
        SharedService.getFeatureFlags.mockReturnValue({
            enableDefaultEquipmentId: true,
        });
    });

    it('should default equipmentId to "P-" for all load types except BOB', () => {
        const formData = {
            equipment: {},
            requestType: UILoadTypeEnum.PLT.name,
        };
        const uom = { length: 'feet' };
        const equipment = getEquipment(formData, uom);
        expect(equipment.equipmentId).toBe('P-');

        formData.requestType = UILoadTypeEnum.BOB.name;
        const equipmentBob = getEquipment(formData, uom);
        expect(equipmentBob.equipmentId).toBe(null);

        formData.equipment.equipmentId = 'E123';
        const equipmentWithId = getEquipment(formData, uom);
        expect(equipmentWithId.equipmentId).toBe('E123');
    });

    it('should use the provided equipmentId if available', () => {
        const formData = {
            equipment: { equipmentId: 'E123' },
            requestType: UILoadTypeEnum.STR.name,
        };
        const uom = { length: 'feet' };
        const equipment = getEquipment(formData, uom);
        expect(equipment.equipmentId).toBe('E123');
    });

    it('should set equipmentId to null if load type is BOB and equipmentId is not provided', () => {
        const formData = {
            equipment: {},
            requestType: UILoadTypeEnum.BOB.name,
        };
        const uom = { length: 'feet' };
        const equipment = getEquipment(formData, uom);
        expect(equipment.equipmentId).toBe(null);
    });
});

describe('getEquipment with enableDefaultEquipmentId false', () => {
    beforeEach(() => {
        SharedService.getFeatureFlags.mockReturnValue({
            enableDefaultEquipmentId: false,
        });
    });

    it('should use the provided equipmentId if available', () => {
        const formData = {
            equipment: { equipmentId: 'E123' },
            requestType: UILoadTypeEnum.STR.name,
        };
        const uom = { length: 'feet' };
        const equipment = getEquipment(formData, uom);
        expect(equipment.equipmentId).toBe('E123');
    });

    it('should return undefined if equipmentId is not provided', () => {
        const formData = {
            equipment: {},
            requestType: UILoadTypeEnum.STR.name,
        };
        const uom = { length: 'feet' };
        const equipment = getEquipment(formData, uom);
        expect(equipment.equipmentId).toBe(undefined);
    });

    it('should return the provided equipmentId if load type is BOB and equipmentId is provided', () => {
        const formData = {
            equipment: { equipmentId: 'E123' },
            requestType: UILoadTypeEnum.BOB.name,
        };
        const uom = { length: 'feet' };
        const equipment = getEquipment(formData, uom);
        expect(equipment.equipmentId).toBe('E123');
    });

    it('should return undefined if load type is BOB and equipmentId is not provided', () => {
        const formData = {
            equipment: {},
            requestType: UILoadTypeEnum.BOB.name,
        };
        const uom = { length: 'feet' };
        const equipment = getEquipment(formData, uom);
        expect(equipment.equipmentId).toBe(undefined);
    });
});
describe('CreateLoad component with feature flag showGRSTR enabled', () => {
    beforeEach(() => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{"enableManualCreateLoadChanges": true, "showGRSTR": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
    });

    it('should render the load types in request details', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        const CLM = await screen.findByText('CLM');
        expect(CLM).toBeDefined();
        const STR = await screen.findByText('STR');
        expect(STR).toBeDefined();
        const RTN = await screen.findByText('RTN');
        expect(RTN).toBeDefined();
        const BOB = await screen.findByText('BOB');
        expect(BOB).toBeDefined();
        const DHD = await screen.findByText('DHD');
        expect(DHD).toBeDefined();
        const BOX = await screen.findByText('BOX');
        expect(BOX).toBeDefined();
        const STK = await screen.findByText('STK');
        expect(STK).toBeDefined();
        const WMGW = await screen.findByText('WMGW');
        expect(WMGW).toBeDefined();
        const GRSTR = await screen.findByText('GRSTR');
        expect(GRSTR).toBeDefined();
    });
});
describe('CreateLoad component with feature flag showGRSTR disabled', () => {
    beforeEach(() => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{"enableManualCreateLoadChanges": true, "showGRSTR": false }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
    });

    it('should not render GRSTR load type in request details', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const reqDetails = await screen.findAllByText('Request details');
        expect(reqDetails).toBeDefined();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        const CLM = await screen.findByText('CLM');
        expect(CLM).toBeDefined();
        const STR = await screen.findByText('STR');
        expect(STR).toBeDefined();
        const RTN = await screen.findByText('RTN');
        expect(RTN).toBeDefined();
        const BOB = await screen.findByText('BOB');
        expect(BOB).toBeDefined();
        const DHD = await screen.findByText('DHD');
        expect(DHD).toBeDefined();
        const BOX = await screen.findByText('BOX');
        expect(BOX).toBeDefined();
        const STK = await screen.findByText('STK');
        expect(STK).toBeDefined();
        const WMGW = await screen.findByText('WMGW');
        expect(WMGW).toBeDefined();
        expect(screen.queryByText('GRSTR')).toBeNull();
    });
});
describe('Stop sequuence component - feature flag enableManualCreateLoadChanges enabled', () => {
    beforeEach(() => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags: '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
    });
    // To make react-window work on JSDOM - https://stackoverflow.com/a/62214834/1681255
    const originalOffsetHeight = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetHeight');
    const originalOffsetWidth = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetWidth');

    beforeAll(() => {
        Object.defineProperty(HTMLElement.prototype, 'offsetHeight', { configurable: true, value: 50 });
        Object.defineProperty(HTMLElement.prototype, 'offsetWidth', { configurable: true, value: 50 });
    });

    afterAll(() => {
        Object.defineProperty(HTMLElement.prototype, 'offsetHeight', originalOffsetHeight);
        Object.defineProperty(HTMLElement.prototype, 'offsetWidth', originalOffsetWidth);
    });

    it('should render the stop sequence details', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);
    });

    it('should have auto as the default activity type for origin and destination', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);

        const segements = screen.queryAllByTestId('ld-sc-ui-segment');
        expect(segements?.length).toBe(6);
        const autoActivity = screen.queryAllByText('Auto');
        expect(autoActivity?.length).toBe(2);
        expect(autoActivity[0].parentElement.parentElement.className).toContain('ld-sc-ui-selected-segment');
        expect(autoActivity[1].parentElement.parentElement.className).toContain('ld-sc-ui-selected-segment');
    });

    it('should be able to edit activity type for origin and destination', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);

        const segements = screen.queryAllByTestId('ld-sc-ui-segment');
        expect(segements?.length).toBe(6);
        // origin activity type
        fireEvent.click(segements[0]);
        const liveActivity = screen.queryAllByText('Live load');
        expect(liveActivity?.length).toBe(1);
        expect(liveActivity[0].parentElement.parentElement.className).toContain('ld-sc-ui-selected-segment');

        // destination activity type
        fireEvent.click(segements[4]);
        const dropLoad = screen.queryAllByText('Drop load');
        expect(dropLoad?.length).toBe(1);
        expect(dropLoad[0].parentElement.parentElement.className).toContain('ld-sc-ui-selected-segment');
    });

    it('should have auto as the default activity type when a new stop is added', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        expect(screen.queryAllByText('Activity type').length).toBe(2);

        const addStopBtn = await screen.findByTestId('addStopBtn');
        expect(addStopBtn).toBeDefined();
        fireEvent.click(addStopBtn);

        const intermediateStop = await screen.findByText('*Stop Id');
        expect(intermediateStop).toBeDefined();
        expect(screen.queryAllByTestId('ld-sc-ui-text-input').length).toBe(4);
        expect(screen.queryAllByText('Activity type').length).toBe(3);

        const segements = screen.queryAllByTestId('ld-sc-ui-segment');
        expect(segements?.length).toBe(9);
        const autoActivity = screen.queryAllByText('Auto');
        expect(autoActivity?.length).toBe(3);
        expect(autoActivity[1].parentElement.parentElement.className).toContain('ld-sc-ui-selected-segment');
    });

    it('should be able to edit origin and destination', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[2];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(destLocationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
        );
        fireEvent.change(searchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);
    });

    it('should not be able to delete or reorder when stop seq has only origin and destination  ', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const deleteBtn = screen.queryAllByTestId('deleteBtn');
        expect(deleteBtn.length).toBe(0);

        const reOrderBtn = screen.queryAllByTestId('reOrderBtn');
        expect(reOrderBtn.length).toBe(0);
    });

    it('should be able to add an intermediate stop', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);

        const addStopBtn = await screen.findByTestId('addStopBtn');
        expect(addStopBtn).toBeDefined();
        fireEvent.click(addStopBtn);
        const intermediateStop = await screen.findByText('*Stop Id');
        expect(intermediateStop).toBeDefined();
        expect(screen.queryAllByTestId('ld-sc-ui-text-input').length).toBe(4);
        expect(screen.queryAllByText('Activity type').length).toBe(3);
    });

    it('should have delete and reorder buttons when more than 2 stops are present', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);

        const addStopBtn = await screen.findByTestId('addStopBtn');
        expect(addStopBtn).toBeDefined();
        fireEvent.click(addStopBtn);
        const intermediateStop = await screen.findByText('*Stop Id');
        expect(intermediateStop).toBeDefined();

        expect(screen.queryAllByTestId('deleteBtn').length).toBe(2);
        expect(screen.queryAllByTestId('reOrderBtn').length).toBe(2);
    });

    it('should be able to delete a stop', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const addStopBtn = await screen.findByTestId('addStopBtn');
        expect(addStopBtn).toBeDefined();
        fireEvent.click(addStopBtn);
        const intermediateStop = await screen.findByText('*Stop Id');
        expect(intermediateStop).toBeDefined();
        expect(screen.queryAllByTestId('ld-sc-ui-text-input').length).toBe(4);
        expect(screen.queryAllByText('Activity type').length).toBe(3);

        const deleteBtn = screen.queryAllByTestId('deleteBtn');
        expect(deleteBtn.length).toBe(2);
        fireEvent.click(deleteBtn[0]);
        expect(screen.queryByText('*Stop Id')).toBeNull();
        expect(screen.queryAllByText('Activity type').length).toBe(2);
        expect(screen.queryAllByTestId('deleteBtn').length).toBe(0);
        expect(screen.queryAllByTestId('reOrderBtn').length).toBe(0);
    });

    it('should have correct label for last stop when a stop is deleted', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const addStopBtn = await screen.findByTestId('addStopBtn');
        expect(addStopBtn).toBeDefined();
        fireEvent.click(addStopBtn);
        const intermediateStop = await screen.findByText('*Stop Id');
        expect(intermediateStop).toBeDefined();
        expect(screen.queryAllByTestId('ld-sc-ui-text-input').length).toBe(4);
        expect(screen.queryAllByText('Activity type').length).toBe(3);

        const deleteBtn = screen.queryAllByTestId('deleteBtn');
        expect(deleteBtn.length).toBe(2);
        fireEvent.click(deleteBtn[1]);
        expect(screen.queryByText('*Stop Id')).toBeNull();
        expect(screen.queryByText('*Origin Id')).not.toBeNull();
        expect(screen.queryByText('*Destination Id')).not.toBeNull();
    });
    it('should be able to edit the pickup date', async () => {
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();
        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);

        fireEvent.click(inputs[1]);
        fireEvent.click(screen.getByText('13'));
        fireEvent.click(screen.getByText('Apply'));
    });
});
describe('create load flow - feature flag enableManualCreateLoadChanges enabled', () => {
    beforeEach(() => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags: '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
    });
    // To make react-window work on JSDOM - https://stackoverflow.com/a/62214834/1681255
    const originalOffsetHeight = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetHeight');
    const originalOffsetWidth = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetWidth');

    beforeAll(() => {
        Object.defineProperty(HTMLElement.prototype, 'offsetHeight', { configurable: true, value: 50 });
        Object.defineProperty(HTMLElement.prototype, 'offsetWidth', { configurable: true, value: 50 });
    });

    afterAll(() => {
        Object.defineProperty(HTMLElement.prototype, 'offsetHeight', originalOffsetHeight);
        Object.defineProperty(HTMLElement.prototype, 'offsetWidth', originalOffsetWidth);
    });

    it('should enable the submit button when mandatory fileds are present', async () => {
        const { container } = render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();
        expect(screen.queryByText('*Delivery date/time')).toBeNull();

        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn.disabled).toBeTruthy();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const pickupDate = inputs[1];
        expect(pickupDate).toBeDefined();
        fireEvent.click(pickupDate);
        // eslint-disable-next-line testing-library/no-container
        const calanderPicker = container.querySelector('.react-datepicker');
        const datePickerButtons = within(calanderPicker).queryAllByTestId('ld-sc-ui-button');
        const datePickerRightArrowButton = datePickerButtons?.[2];
        fireEvent.click(datePickerRightArrowButton);
        fireEvent.click(screen.getByText('12'));
        fireEvent.click(screen.getByText('Apply'));

        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[2];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(locationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
        );
        const destinationSearchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(destinationSearchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);
        expect(submitBtn.disabled).toBeFalsy();
    });
    it('should display success toaster after load creation successful', async () => {
        const { container } = render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn.disabled).toBeTruthy();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const pickupDate = inputs[1];
        expect(pickupDate).toBeDefined();
        fireEvent.click(pickupDate);
        // eslint-disable-next-line testing-library/no-container
        const calanderPicker = container.querySelector('.react-datepicker');
        const datePickerButtons = within(calanderPicker).queryAllByTestId('ld-sc-ui-button');
        const datePickerRightArrowButton = datePickerButtons?.[2];
        fireEvent.click(datePickerRightArrowButton);
        fireEvent.click(screen.getByText('12'));
        fireEvent.click(screen.getByText('Apply'));

        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[2];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(locationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
        );
        const destinationSearchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(destinationSearchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);
        expect(submitBtn.disabled).toBeFalsy();
        fireEvent.click(submitBtn);
        expect(await screen.findByText('Load created')).toBeDefined();
        expect(await screen.findByText("Click 'View load' to open the created load")).toBeDefined();
        const viewLoad = await screen.findByText('View load');
        fireEvent.click(viewLoad);
    });
    it('should display error message when create load API fails', async () => {
        const { container } = render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn.disabled).toBeTruthy();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const pickupDate = inputs[1];
        expect(pickupDate).toBeDefined();
        fireEvent.click(pickupDate);
        // eslint-disable-next-line testing-library/no-container
        const calanderPicker = container.querySelector('.react-datepicker');
        const datePickerButtons = within(calanderPicker).queryAllByTestId('ld-sc-ui-button');
        const datePickerRightArrowButton = datePickerButtons?.[2];
        fireEvent.click(datePickerRightArrowButton);
        fireEvent.click(screen.getByText('12'));
        fireEvent.click(screen.getByText('Apply'));

        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[2];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(locationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-createLoad/createLoadV2', (req, res, ctx) =>
                res(ctx.status(500), ctx.json(createLoadV2PlanError)),
            ),
        );
        const destinationSearchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(destinationSearchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);
        expect(submitBtn.disabled).toBeFalsy();
        fireEvent.click(submitBtn);
        expect(await screen.findByText('Invalid value')).toBeDefined();
        expect(submitBtn.disabled).toBeTruthy();
    });
    it('should display error message when TO creation fails', async () => {
        const { container } = render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn.disabled).toBeTruthy();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const pickupDate = inputs[1];
        expect(pickupDate).toBeDefined();
        fireEvent.click(pickupDate);
        // eslint-disable-next-line testing-library/no-container
        const calanderPicker = container.querySelector('.react-datepicker');
        const datePickerButtons = within(calanderPicker).queryAllByTestId('ld-sc-ui-button');
        const datePickerRightArrowButton = datePickerButtons?.[2];
        fireEvent.click(datePickerRightArrowButton);
        fireEvent.click(screen.getByText('12'));
        fireEvent.click(screen.getByText('Apply'));

        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[2];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(locationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-createLoad/createLoadV2', (req, res, ctx) =>
                res(ctx.status(500), ctx.json(createLoadTOError)),
            ),
        );
        const destinationSearchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(destinationSearchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);
        expect(submitBtn.disabled).toBeFalsy();
        fireEvent.click(submitBtn);
        expect(
            await screen.findByText('Failed to create transportation order, please connect with Technical Support'),
        ).toBeDefined();
        expect(submitBtn.disabled).toBeTruthy();
    });
    it('should display error message when shipment creation fails', async () => {
        const { container } = render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn.disabled).toBeTruthy();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(3);

        const pickupDate = inputs[1];
        expect(pickupDate).toBeDefined();
        fireEvent.click(pickupDate);
        // eslint-disable-next-line testing-library/no-container
        const calanderPicker = container.querySelector('.react-datepicker');
        const datePickerButtons = within(calanderPicker).queryAllByTestId('ld-sc-ui-button');
        const datePickerRightArrowButton = datePickerButtons?.[2];
        fireEvent.click(datePickerRightArrowButton);
        fireEvent.click(screen.getByText('12'));
        fireEvent.click(screen.getByText('Apply'));

        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[2];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(locationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-createLoad/createLoadV2', (req, res, ctx) =>
                res(ctx.status(500), ctx.json(createLoadShipmentError)),
            ),
        );
        const destinationSearchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(destinationSearchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);
        expect(submitBtn.disabled).toBeFalsy();
        fireEvent.click(submitBtn);
        expect(
            await screen.findByText('Failed to create shipment, please connect with Technical Support'),
        ).toBeDefined();
        expect(submitBtn.disabled).toBeTruthy();
    });

    it('should display success toaster after load creation successful with destinations delivery datetime', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true, "showFinalDeliveryDate": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));

        const { container } = render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();
        expect(screen.getByText('*Delivery date/time')).toBeDefined();
        expect(screen.queryByText('Carrier details')).toBeNull();

        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn.disabled).toBeTruthy();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(4);

        const pickupDate = inputs[1];
        expect(pickupDate).toBeDefined();
        fireEvent.click(pickupDate);
        // eslint-disable-next-line testing-library/no-container
        const calanderPicker = container.querySelector('.react-datepicker');
        const datePickerButtons = within(calanderPicker).queryAllByTestId('ld-sc-ui-button');
        const datePickerRightArrowButton = datePickerButtons?.[2];
        fireEvent.click(datePickerRightArrowButton);
        fireEvent.click(screen.getByText('12'));
        fireEvent.click(screen.getByText('Apply'));

        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[2];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(locationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
        );
        const destinationSearchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(destinationSearchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);
        expect(submitBtn.disabled).toBeFalsy();
        fireEvent.click(submitBtn);
        expect(await screen.findByText('Load created')).toBeDefined();
        expect(await screen.findByText("Click 'View load' to open the created load")).toBeDefined();
        const viewLoad = await screen.findByText('View load');
        fireEvent.click(viewLoad);
    });

    it('onChange carrier value, servicelevels check and submit flow', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true, "showFinalDeliveryDate": true, "showCarrierSection": true, "showGRSTR": true}}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));

        const { container } = render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();
        const carrierDropdown = screen.getByText('Carrier ID');
        expect(carrierDropdown).toBeDefined();

        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn.disabled).toBeTruthy();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(5);

        // carrier dropdown should be disabled for other than GRSTR load type
        expect(inputs[0].disabled).toBeTruthy();
        // service levels should have 2
        const serviceLevels = screen.queryAllByTestId('level');
        expect(serviceLevels.length).toBe(2);
        expect(serviceLevels[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment'); //SINGLE

        const pickupDate = inputs[2];
        expect(pickupDate).toBeDefined();
        fireEvent.click(pickupDate);
        // eslint-disable-next-line testing-library/no-container
        const calanderPicker = container.querySelector('.react-datepicker');
        const datePickerButtons = within(calanderPicker).queryAllByTestId('ld-sc-ui-button');
        const datePickerRightArrowButton = datePickerButtons?.[2];
        fireEvent.click(datePickerRightArrowButton);
        fireEvent.click(screen.getByText('12'));
        fireEvent.click(screen.getByText('Apply'));

        const originDropdown = inputs[1];
        fireEvent.click(originDropdown);
        const searchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[3];
        fireEvent.click(destinationDropdown);
        const destinationSearchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(destinationSearchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);

        const GRSTR = await screen.findByText('GRSTR');
        expect(GRSTR).toBeDefined();
        fireEvent.click(GRSTR);

        // carrier dropdown should be enabled for GRSTR load type
        expect(inputs[0].disabled).toBeFalsy();
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(carrierAutoCompleteMock)),
            ),
        );
        const carrierDrpDwn = inputs[0];
        fireEvent.click(carrierDrpDwn);
        const carrierSearchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(carrierSearchTextBox, {
            target: {
                value: 'BBSE',
            },
        });

        const carrier = await screen.findByText('BBSE - B2B TRANSPORT MARKET, LLC');
        fireEvent.click(carrier);
        // service levels should have 3
        const levels = screen.queryAllByTestId('level');
        expect(levels.length).toBe(3);
        expect(levels[0].className).toEqual('ld-sc-ui-segment ld-sc-ui-selected-segment'); //DEDF

        expect(submitBtn.disabled).toBeFalsy();
        fireEvent.click(submitBtn);
        expect(await screen.findByText('Load created')).toBeDefined();
        expect(await screen.findByText("Click 'View load' to open the created load")).toBeDefined();
        const viewLoad = await screen.findByText('View load');
        fireEvent.click(viewLoad);
    });

    it('should show load id in success toaster for feature flag showLoadIdInToast true ', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true, "showFinalDeliveryDate": true, "showLoadIdInToast": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));

        const { container } = render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();
        expect(screen.getByText('*Delivery date/time')).toBeDefined();
        expect(screen.queryByText('Carrier details')).toBeNull();

        const submitBtn = await screen.findByTestId('submitBtn');
        expect(submitBtn.disabled).toBeTruthy();

        const PLT = await screen.findByText('PLT');
        expect(PLT).toBeDefined();
        fireEvent.click(PLT);

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        expect(inputs.length).toBe(4);

        const pickupDate = inputs[1];
        expect(pickupDate).toBeDefined();
        fireEvent.click(pickupDate);
        // eslint-disable-next-line testing-library/no-container
        const calanderPicker = container.querySelector('.react-datepicker');
        const datePickerButtons = within(calanderPicker).queryAllByTestId('ld-sc-ui-button');
        const datePickerRightArrowButton = datePickerButtons?.[2];
        fireEvent.click(datePickerRightArrowButton);
        fireEvent.click(screen.getByText('12'));
        fireEvent.click(screen.getByText('Apply'));

        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: '12',
            },
        });

        const location = await screen.findByText('STORE - 12');
        fireEvent.click(location);

        // destination location
        const destinationDropdown = inputs[2];
        fireEvent.click(destinationDropdown);
        server.use(
            rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
                res(ctx.json(locationAutoCompleteMock)),
            ),
            rest.post('/api/gateway/v4/stride-ui-create-load-locationDetails/locationTSSSearch', (req, res, ctx) =>
                res(ctx.json(locationSearchMock)),
            ),
        );
        const destinationSearchTextBox = await screen.findByPlaceholderText('Search');
        fireEvent.change(destinationSearchTextBox, {
            target: {
                value: '120',
            },
        });

        const destination = await screen.findByText('STORE - 120');
        expect(destination).toBeDefined();
        fireEvent.click(destination);

        const activityTypes = await screen.findAllByText('Activity type');
        expect(activityTypes).toBeDefined();
        expect(activityTypes.length).toBe(2);
        expect(submitBtn.disabled).toBeFalsy();
        fireEvent.click(submitBtn);
        expect(await screen.findByText('Load created: 10080631')).toBeDefined();
        expect(await screen.findByText("Click 'View load' to open the created load")).toBeDefined();
        const viewLoad = await screen.findByText('View load');
        fireEvent.click(viewLoad);
    });
});

describe('create load flow - permissions', () => {
    it('should display the submit button when enablePermissions is true and has WRITE permissions', async () => {
        const localStorageGetItem = jest.fn((arg) => {
            if (arg === 'ngStorage-permissionData') {
                return userPermMock;
            }
        });
        Object.defineProperty(global, 'localStorage', {
            value: {
                getItem: localStorageGetItem,
                setItem: () => {},
            },
            writable: true,
        });
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true, "enablePermissions": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();
        const submitBtn = screen.queryByTestId('submitBtn');
        expect(submitBtn).toBeDefined();
    });
    it('should not display the submit button when enablePermissions is true and has READ permissions', async () => {
        SharedService.setUserPermissions(null);
        const localStorageGetItem = jest.fn((arg) => {
            if (arg === 'ngStorage-permissionData') {
                return readPermMock;
            }
        });
        Object.defineProperty(global, 'localStorage', {
            value: {
                getItem: localStorageGetItem,
                setItem: () => {},
            },
            writable: true,
        });
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true, "enablePermissions": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        render(<CreateRLogLoad />);

        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();
        const stopseqDetails = await screen.findAllByText('Stop sequence details');
        expect(stopseqDetails).toBeDefined();
        expect(await screen.findByText('Stop sequence')).toBeDefined();
        expect(await screen.findByText('*Origin Id')).toBeDefined();
        expect(await screen.findByText('*Destination Id')).toBeDefined();

        const submitBtn = screen.queryByTestId('submitBtn');
        expect(submitBtn).toBeNull();
    });
    it('should display the submit button when enablePermissions is false and has WRITE permissions', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true, "enablePermissions": false }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        const localStorageGetItem = jest.fn((arg) => {
            if (arg === 'ngStorage-permissionData') {
                return userPermMock;
            }
        });
        Object.defineProperty(global, 'localStorage', {
            value: {
                getItem: localStorageGetItem,
                setItem: () => {},
            },
            writable: true,
        });
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();

        const submitBtn = screen.queryByTestId('submitBtn');
        expect(submitBtn).toBeDefined();
    });
    it('should not display the submit button when enablePermissions is true and has READ permissions', async () => {
        const config = {
            ...CmsConfig,
            payload: {
                ...CmsConfig.payload,
                custom: {
                    ...CmsConfig.payload.custom,
                    featureFlags:
                        '{"dev.createLoad.configs":{ "enableManualCreateLoadChanges": true, "enablePermissions": true }}',
                },
            },
        };
        server.use(rest.get('/api/gateway/v4/cms/getConfig', (req, res, ctx) => res(ctx.json(config))));
        const localStorageGetItem = jest.fn((arg) => {
            if (arg === 'ngStorage-permissionData') {
                return readPermMock;
            }
        });
        Object.defineProperty(global, 'localStorage', {
            value: {
                getItem: localStorageGetItem,
                setItem: () => {},
            },
            writable: true,
        });
        render(<CreateRLogLoad />);
        const title = await screen.findByText('New Load Request');
        expect(title).toBeDefined();

        const submitBtn = screen.queryByTestId('submitBtn');
        expect(submitBtn).toBeNull();
    });
});
