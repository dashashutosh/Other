import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { contextMock } from './mocks/mocks';
import CommentsCard from '../CommentsCard';

jest.mock('react-router-dom', () => ({
    useLocation: jest.fn().mockReturnValue({
        search: undefined,
    }),
}));

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
});

const commentList = [
    {
        commentId: '0',
        commentBy: 'Salma',
        commentTimestamp: '13th Feb, 2021',
        commentText: 'Lat long of the location seems to be wrong.',
        commentTimeZoneAbbr: 'PST',
    },
    {
        commentId: '1',
        commentBy: 'Salma',
        commentTimestamp: '13th Feb, 2021',
        commentText: 'The loading/unloading time will be changing soon',
        commentTimeZoneAbbr: 'PST',
    },
];

jest.mock('@gscope-mfe/common-components', () => {
    const actualModule = jest.requireActual('@gscope-mfe/common-components');
    const transalations = {
        'title.comments': 'Comments',
        'title.newComment': 'New comment',
        'title.editComment': 'Edit comment',
        'button.addComment': 'Add comment',
        'button.cancel': 'Cancel',
        'button.save': 'Save',
        'info.emptyComment': 'No comments to show',
        'label.enterComment': 'Enter comment',
        'label.bolInfo': 'Only the latest BOL comment will appear on the BOL',
        'label.commentType': 'Comment Type',
        'msg.commentSaveSuccess': 'Comment changes saved successfully',
    };
    return {
        ...actualModule,
        LocalizeLang: {
            default: {
                ...actualModule.LocalizeLang.default,
                localizeLang: () => jest.fn((callback) => transalations[callback]),
            },
        },
    };
});

describe('CommentsCard component', () => {
    it('should render no comments to show when comments are empty', () => {
        render(<CommentsCard pComments={[]} pEditable pOnUpdateResponse={() => {}} />);
        const comments = screen.queryByText('Comments');
        expect(comments).not.toBeNull();
        const addComment = screen.queryByText('Add comment');
        expect(addComment).not.toBeNull();
        expect(screen.queryByText('No comments to show')).not.toBeNull();
    });
    it('should render the comments', () => {
        render(<CommentsCard pComments={commentList} pEditable pOnUpdateResponse={() => {}} />);
        expect(screen.queryByText('Comments (2)')).not.toBeNull();
        expect(screen.queryByText('Lat long of the location seems to be wrong.')).not.toBeNull();
        expect(screen.queryByText('The loading/unloading time will be changing soon')).not.toBeNull();
        expect(screen.queryByText('No comments to show')).toBeNull();
    });
    it('should add the comment', () => {
        const mockFnc = jest.fn();
        render(<CommentsCard pComments={[]} pEditable pOnUpdateResponse={mockFnc} />);
        const comments = screen.queryByText('Comments');
        expect(comments).not.toBeNull();
        expect(screen.queryByText('Add comment')).not.toBeNull();
        expect(screen.queryByText('No comments to show')).not.toBeNull();
        const addComment = screen.getByTestId('addButton');
        expect(addComment).toBeDefined();
        fireEvent.click(addComment);
        const commentInput = screen.getByTestId('commentInput');
        fireEvent.change(commentInput, { target: { value: 'New test comment' } });
        fireEvent.click(screen.getByTestId('post-comment-button'));
        expect(mockFnc).toHaveBeenCalled();
    });
    it('should edit the comment', async () => {
        const mockFnc = jest.fn();
        render(<CommentsCard pComments={commentList} pEditable pOnUpdateResponse={mockFnc} />);
        expect(screen.queryByText('Comments (2)')).not.toBeNull();
        expect(screen.queryByText('Lat long of the location seems to be wrong.')).not.toBeNull();
        fireEvent.mouseOver(screen.getByText('Lat long of the location seems to be wrong.'));

        fireEvent.click(screen.getByTestId('editIcon'));
        const commentInput = screen.getByTestId('commentInput');
        fireEvent.change(commentInput, { target: { value: 'Edited comment text' } });
        fireEvent.click(screen.getByTestId('post-comment-button'));
        expect(mockFnc).toHaveBeenCalled();
    });
    it('should delete the comment', async () => {
        const mockFnc = jest.fn();
        render(<CommentsCard pComments={commentList} pEditable pOnUpdateResponse={mockFnc} />);
        expect(screen.queryByText('Comments (2)')).not.toBeNull();
        expect(screen.queryByText('The loading/unloading time will be changing soon')).not.toBeNull();
        fireEvent.mouseOver(await screen.findByText('The loading/unloading time will be changing soon'));

        fireEvent.click(await screen.findByTestId('trashIcon'));
        expect(mockFnc).toHaveBeenCalled();
    });
});
