import { getComments, applyValidations, carrierStaticDataTransformer } from '../DataModels';
import { commentsMock, commentsPayload } from './mocks/mocks';

describe('getComments tests', () => {
    it('should return comments payload correctly', () => {
        expect(getComments(commentsMock)).toEqual(commentsPayload);
        expect(getComments([])).toEqual([]);
        expect(getComments(null)).toEqual([]);
    });
});

describe('applyValidations tests', () => {
    const today = new Date();
    const yesterday = new Date(today);
    const tomorrow = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    tomorrow.setDate(tomorrow.getDate() + 1);
    it('should return validations correctly', () => {
        expect(applyValidations(['PICKUP_DATE_CANNOT_BE_IN_PAST'], null)).toEqual({
            result: false,
            reason: 'label.validation.emptyFormdata',
        });
        // pickUpDT is in past
        expect(
            applyValidations(['PICKUP_DATE_CANNOT_BE_IN_PAST'], {
                stops: [{ pickUpDT: yesterday, locationId: '123' }],
            }),
        ).toEqual({ result: false, reason: 'label.validation.pickupDateCannotBeInPast' });

        // requestType is null
        expect(
            applyValidations(['PICKUP_DATE_CANNOT_BE_IN_PAST'], {
                stops: [{ pickUpDT: tomorrow, locationId: '123' }],
                requestType: null,
                equipment: {
                    equipmentType: 'DRY',
                    equipmentLength: '53',
                },
            }),
        ).toEqual({ result: false, reason: 'label.validation.mandatory' });

        // equipmentType is null
        expect(
            applyValidations(['PICKUP_DATE_CANNOT_BE_IN_PAST'], {
                stops: [{ pickUpDT: tomorrow, locationId: '123' }],
                requestType: 'STR',
                equipment: {
                    equipmentType: null,
                    equipmentLength: '53',
                },
            }),
        ).toEqual({ result: false, reason: 'label.validation.mandatory' });

        // equipmentLength is null
        expect(
            applyValidations(['PICKUP_DATE_CANNOT_BE_IN_PAST'], {
                stops: [{ pickUpDT: tomorrow, locationId: '123' }],
                requestType: 'STR',
                equipment: {
                    equipmentType: 'DRY',
                    equipmentLength: null,
                },
            }),
        ).toEqual({ result: false, reason: 'label.validation.mandatory' });

        // when a stop is null
        expect(
            applyValidations([], {
                stops: [{ pickUpDT: tomorrow, locationId: '123' }, { locationId: null }],
                requestType: 'STR',
                equipment: {
                    equipmentType: 'DRY',
                    equipmentLength: '53',
                },
            }),
        ).toEqual({ result: false, reason: 'label.validation.mandatory' });

        // success case
        expect(
            applyValidations([], {
                stops: [{ pickUpDT: yesterday, locationId: '123' }],
                requestType: 'STR',
                equipment: {
                    equipmentType: 'DRY',
                    equipmentLength: '53',
                },
            }),
        ).toEqual({ result: true, reason: '' });
    });

    it('applyValidations success - pickUpDT provided, finalDeliveryDT not provided and feature flag showFinalDeliveryDate true', () => {
        expect(
            applyValidations(
                ['PICKUP_DATE_CANNOT_BE_IN_PAST', 'DELIVERY_DATE_CANNOT_BE_IN_PAST'],
                {
                    stops: [{ pickUpDT: tomorrow, locationId: '123' }],
                    requestType: 'STR',
                    equipment: {
                        equipmentType: 'DRY',
                        equipmentLength: '53',
                    },
                },
                { showFinalDeliveryDate: true },
            ),
        ).toEqual({ result: true, reason: '' });
    });

    it('applyValidations success - pickUpDT not provided, finalDeliveryDT provided and feature flag showFinalDeliveryDate true', () => {
        expect(
            applyValidations(
                ['PICKUP_DATE_CANNOT_BE_IN_PAST', 'DELIVERY_DATE_CANNOT_BE_IN_PAST'],
                {
                    stops: [{ finalDeliveryDT: tomorrow, locationId: '123' }],
                    requestType: 'STR',
                    equipment: {
                        equipmentType: 'DRY',
                        equipmentLength: '53',
                    },
                },
                { showFinalDeliveryDate: true },
            ),
        ).toEqual({ result: true, reason: '' });
    });

    it('applyValidations fail - pickUpDT and finalDeliveryDT not provided, and feature flag showFinalDeliveryDate true', () => {
        expect(
            applyValidations(
                ['PICKUP_DATE_CANNOT_BE_IN_PAST', 'DELIVERY_DATE_CANNOT_BE_IN_PAST'],
                {
                    stops: [{ locationId: '123' }],
                    requestType: 'STR',
                    equipment: {
                        equipmentType: 'DRY',
                        equipmentLength: '53',
                    },
                },
                { showFinalDeliveryDate: true },
            ),
        ).toEqual({ result: false, reason: 'label.validation.mandatory' });

        // final destination's delivery date is in past
        expect(
            applyValidations(['DELIVERY_DATE_CANNOT_BE_IN_PAST'], {
                stops: [{ finalDeliveryDT: yesterday, locationId: '123' }],
            }),
        ).toEqual({ result: false, reason: 'label.validation.deliveryDateCannotBeInPast' });
    });

    it('applyValidations - should return mandatory validatation for carrierId based on pageConfigs', () => {
        expect(
            applyValidations(
                ['PICKUP_DATE_CANNOT_BE_IN_PAST', 'DELIVERY_DATE_CANNOT_BE_IN_PAST'],
                {
                    stops: [
                        {
                            locationId: {
                                id: 2,
                                value: 'STORE - 2',
                                locationType: 'STORE',
                            },
                            pickUpDT: '2024-12-23T06:00:00.000Z',
                            activityType: 'Auto',
                        },
                        {
                            locationId: {
                                id: 6,
                                value: 'STORE - 6',
                                locationType: 'STORE',
                            },
                            activityType: 'Auto',
                        },
                    ],
                    requestType: 'STR',
                    equipment: {
                        equipmentType: 'DRYV',
                        equipmentLength: '53',
                    },
                    transitDetail: {
                        mode: 'TL',
                        serviceLevel: 'SINGLE',
                    },
                },
                { showFinalDeliveryDate: true },
                {
                    fields: {
                        CARRIER_ID: {
                            validations: ['MANDATORY_FIELD'],
                            isEditable: true,
                        },
                    },
                    sections: [],
                },
            ),
        ).toEqual({ result: false, reason: 'label.validation.mandatory' });
    });
    it('applyValidations - should not return mandatory validatation for carrierId based on pageConfigs', () => {
        expect(
            applyValidations(
                ['PICKUP_DATE_CANNOT_BE_IN_PAST', 'DELIVERY_DATE_CANNOT_BE_IN_PAST'],
                {
                    stops: [
                        {
                            locationId: {
                                id: 2,
                                value: 'STORE - 2',
                                locationType: 'STORE',
                            },
                            pickUpDT: '2024-12-23T06:00:00.000Z',
                            activityType: 'Auto',
                        },
                        {
                            locationId: {
                                id: 6,
                                value: 'STORE - 6',
                                locationType: 'STORE',
                            },
                            activityType: 'Auto',
                        },
                    ],
                    requestType: 'STR',
                    equipment: {
                        equipmentType: 'DRYV',
                        equipmentLength: '53',
                    },
                    transitDetail: {
                        mode: 'TL',
                        serviceLevel: 'SINGLE',
                    },
                },
                { showFinalDeliveryDate: true },
                {
                    fields: {
                        CARRIER_ID: {
                            validations: [null],
                            isEditable: true,
                        },
                    },
                    sections: [],
                },
            ),
        ).toEqual({ result: true, reason: '' });
    });
});

describe('carrierStaticDataTransformer', () => {
    it('carrierStaticDataTransformer - for success response', () => {
        expect(
            carrierStaticDataTransformer(null, {
                status: 'SUCCESS',
                payload: {
                    static_data: {
                        carrier_codes: [
                            {
                                carrier_id: 'BBCEFB',
                                mdm_carrier_id: 10473,
                                industry_scac: 'BFBBBE',
                                vendor_nbr: '268888',
                                carrier_name: 'Test 77751',
                                trp_carrier_ids: ['ACCBBD'],
                            },
                        ],
                    },
                },
            }),
        ).toEqual({
            data: [
                {
                    id: 'BBCEFB',
                    value: 'BBCEFB - Test 77751',
                },
            ],
        });
    });

    it('carrierStaticDataTransformer - for error response', () => {
        expect(carrierStaticDataTransformer({ error: 'fail' }, null)).toEqual({
            error: 'Error while fetching the data',
        });
    });
});
