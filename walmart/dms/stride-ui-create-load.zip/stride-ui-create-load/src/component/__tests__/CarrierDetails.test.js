import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { render, screen, fireEvent } from '../../utils/__tests__/test-utils';
import { AppUtils } from '@gscope-mfe/app-bridge';
import { carrierAutoCompleteMock, contextMock } from './mocks/mocks';
import CarrierDetails from '../CarrierDetails';
import ValidationsEnum from '../../utils/LoadConfigs/ValidationsEnum';

const pageConfig = {
    CARRIER_ID: {
        validations: [ValidationsEnum.MANDATORY_FIELD.code],
        defaultValue: {
            id: 'WALM',
            value: 'WALM - WAL-MART TRANSPORTATION LLC',
        },
        isEditable: true,
        isDisable: false,
    },
};

const server = setupServer(
    rest.post('/api/gateway/v4/stride-ui-trip-management-mdmAutoComplete/mdmAutoComplete', (req, res, ctx) =>
        res(ctx.json(carrierAutoCompleteMock)),
    ),
);

afterEach(() => server.resetHandlers());

afterAll(() => server.close());

beforeAll(() => {
    const spy = jest.spyOn(AppUtils, 'get');
    spy.mockImplementation(() => contextMock);
    server.listen();
});

jest.mock('@gscope-mfe/common-components', () => {
    const actualModule = jest.requireActual('@gscope-mfe/common-components');
    const transalations = {
        'title.carrierDetails': 'Carrier details',
        'label.carrierId': 'Carrier ID',
    };
    return {
        ...actualModule,
        LocalizeLang: {
            default: {
                ...actualModule.LocalizeLang.default,
                localizeLang: () => jest.fn((callback) => transalations[callback]),
            },
        },
    };
});

describe('Carrier Details component', () => {
    // To make react-window work on JSDOM - https://stackoverflow.com/a/62214834/1681255
    const originalOffsetHeight = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetHeight');
    const originalOffsetWidth = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetWidth');

    beforeAll(() => {
        Object.defineProperty(HTMLElement.prototype, 'offsetHeight', { configurable: true, value: 50 });
        Object.defineProperty(HTMLElement.prototype, 'offsetWidth', { configurable: true, value: 50 });
    });

    afterAll(() => {
        Object.defineProperty(HTMLElement.prototype, 'offsetHeight', originalOffsetHeight);
        Object.defineProperty(HTMLElement.prototype, 'offsetWidth', originalOffsetWidth);
    });
    it('carrier selection flow', async () => {
        const changeMock = jest.fn();
        render(
            <CarrierDetails
                pDetails={{
                    carrierId: {
                        id: 'WALM',
                        value: 'WALM - WALM LOGISTICS LLC',
                    },
                }}
                pOnEdit={changeMock}
                pPageConfig={pageConfig}
                pCmsConfig={{
                    autoCompleteMaxCount: 20,
                    autoCompleteMinSearchLength: 1,
                }}
            />,
        );
        const title = screen.getByText('Carrier details');
        expect(title).toBeDefined();
        expect(screen.getByText('*Carrier ID')).toBeDefined();

        const inputs = await screen.findAllByTestId('ld-sc-ui-text-input');
        expect(inputs).toBeDefined();
        const originDropdown = inputs[0];
        fireEvent.click(originDropdown);
        const searchTextBox = screen.getByPlaceholderText('Search');
        fireEvent.change(searchTextBox, {
            target: {
                value: 'BBSE',
            },
        });

        const carrier = await screen.findByText('BBSE - B2B TRANSPORT MARKET, LLC');
        fireEvent.click(carrier);
        expect(changeMock).toBeCalledWith('carrierId', {
            id: 'BBSE',
            value: 'BBSE - B2B TRANSPORT MARKET, LLC',
        });
    });
});
