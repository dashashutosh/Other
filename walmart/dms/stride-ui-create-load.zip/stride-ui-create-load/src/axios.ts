// @ts-ignore
import { Utilities } from '@gscope-mfe/app-bridge';

export default Utilities.createAxiosInstance();
