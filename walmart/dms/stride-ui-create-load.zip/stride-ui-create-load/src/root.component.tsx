import React, { Suspense, lazy } from 'react';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { Router, Switch, Route } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import {
    MaterialUiCore,
    MaterialUiPickers,
    MomentUtils,
    // @ts-ignore
} from '@gscope-mfe/common-libs';
// @ts-ignore
import { gscopeTheme, LocalizeLang, Loader } from '@gscope-mfe/common-components';
import enData from './lang/en.json';
import esData from './lang/es.json';

import '@walmart/living-design-sc-ui/src/www/styles.css';
import '@walmart/stride-ui-commons/dist/es/style.css';

const CreateLoadPage = lazy(() => import('./component/CreateRLogLoad'));

const history = createBrowserHistory();

const { MuiPickersUtilsProvider } = MaterialUiPickers;
const { ThemeProvider } = MaterialUiCore;
const { loadI18n } = LocalizeLang.default;
const { default: LoaderComponent } = Loader;

export default function Root() {
    loadI18n([
        ['en', enData],
        ['es', esData],
    ]);
    return (
        <div id="single-spa-application:@stride-mfe/create-load">
            <Suspense fallback={<LoaderComponent show />}>
                <MuiPickersUtilsProvider utils={MomentUtils}>
                    <ThemeProvider theme={gscopeTheme}>
                        <Router history={history}>
                            <Switch>
                                <Route path="/mfe/stride/create-load" exact>
                                    <CreateLoadPage />
                                </Route>
                            </Switch>
                        </Router>
                    </ThemeProvider>
                </MuiPickersUtilsProvider>
            </Suspense>
        </div>
    );
}
