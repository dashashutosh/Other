import { useLoadSupportedLanguages } from '@walmart/stride-ui-commons';
import useLoadSupportedLangs from '../useLoadSupportedLangs';
import { LocalizeLang } from '@gscope-mfe/common-components';
import { renderHook } from '@testing-library/react-hooks';

import enData from '../../lang/en.json';

jest.mock('@gscope-mfe/common-components', () => {
    const actualModule = jest.requireActual('@gscope-mfe/common-components');
    return {
        ...actualModule,
        LocalizeLang: {
            default: {
                ...actualModule.LocalizeLang.default,
                localizeLang: jest.fn(),
                loadI18n: jest.fn(),
            },
        },
    };
});

jest.mock('@walmart/stride-ui-commons', () => ({
    useLoadSupportedLanguages: jest.fn().mockImplementationOnce(() => {}),
}));

LocalizeLang.default.localizeLang.mockImplementation(() => {});

const { loadI18n } = LocalizeLang.default;

const languageDataMap = {
    en: enData,
};

describe('useLoadSupportedLangs', () => {
    it('should call useLoadSupportedLanguages', () => {
        renderHook(() => useLoadSupportedLangs('ca'));
        expect(useLoadSupportedLanguages).toHaveBeenCalledWith({ market: 'ca', loadI18n, languageDataMap });
    });
});
