import { useEffect } from 'react';
import { useLoadSupportedLanguages } from '@walmart/stride-ui-commons';
import SharedService from '../service/SharedService';
import enData from '../lang/en.json';
import { LocalizeLang } from '@gscope-mfe/common-components';
const { loadI18n } = LocalizeLang.default;
const languageDataMap = {
    en: enData,
};
const useLoadSupportedLangs = (market) => {
    const trans = useLoadSupportedLanguages({
        market,
        loadI18n,
        languageDataMap,
    });
    useEffect(() => {
        SharedService.setTrans(trans);
    }, [trans]);
    return trans;
};
export default useLoadSupportedLangs;
