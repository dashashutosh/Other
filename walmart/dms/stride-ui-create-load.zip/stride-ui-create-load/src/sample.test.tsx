import { Utilities } from '@gscope-mfe/app-bridge';
import { Loader as _Loader } from '@gscope-mfe/common-components';
import { render, screen } from '@testing-library/react';

const Loader = _Loader.default;

describe('yo suite', () => {
    it('some test', async () => {
        const environments = await Utilities.convertMapToList({});
        expect(environments).toStrictEqual([]);
    });
    it('some test1', async () => {
        const { debug } = render(<Loader show={true} />);
        // screen.getByRole('progressbar')
        // eslint-disable-next-line testing-library/no-debugging-utils
        debug();
        expect(screen.getByRole('progressbar')).toBeInTheDocument();
    });
});
