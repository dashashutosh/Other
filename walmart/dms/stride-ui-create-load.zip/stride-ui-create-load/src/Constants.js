import { StopActivityTypeEnum } from '@walmart/stride-ui-commons';
import ManageableFieldsEnum from './utils/LoadConfigs/ManageableFieldsEnum';

export const defaultTimeout = 30000;
export const toastTimer = 500000;
export const defaultFormValues = (featureFlags, pageConfig) => {
    if (featureFlags?.enableManualCreateLoadChanges) {
        return {
            stops: [
                {
                    locationId: null,
                    locationIdInfo: null,
                    pickUpDT: null,
                    activityType: StopActivityTypeEnum.AUTO.code,
                    activityTypes: [
                        StopActivityTypeEnum.LIVE_LOADED,
                        StopActivityTypeEnum.PICK_LOADED,
                        StopActivityTypeEnum.AUTO,
                    ],
                    isPickLoad: true,
                    canDeleteStop: false,
                    canReorderStop: false,
                    stopSequenceUiId: 1,
                    stopLocLabel: 'stop.origin.label',
                    finalDeliveryDT: null,
                },
                {
                    locationId: null,
                    locationIdInfo: null,
                    pickUpDT: null,
                    activityType: StopActivityTypeEnum.AUTO.code,
                    activityTypes: [
                        StopActivityTypeEnum.LIVE_UNLOADED,
                        StopActivityTypeEnum.DROP_LOADED,
                        StopActivityTypeEnum.AUTO,
                    ],
                    isPickLoad: false,
                    canDeleteStop: false,
                    canReorderStop: false,
                    stopSequenceUiId: 2,
                    stopLocLabel: 'stop.destination.label',
                    finalDeliveryDT: null,
                },
            ],
            requestType: null,
            comments: [],
            equipment: {
                equipmentType: pageConfig?.fields[ManageableFieldsEnum.EQUIPMENT_TYPE.name]?.defaultValue,
                equipmentLength: pageConfig?.fields[ManageableFieldsEnum.EQUIPMENT_LENGTH.name]?.defaultValue,
                equipmentId: null,
            },
            transitDetail: {
                mode: pageConfig?.fields[ManageableFieldsEnum.MODE.name]?.defaultValue,
                serviceLevel: pageConfig?.fields[ManageableFieldsEnum.LEVEL.name]?.defaultValue,
            },
            carrierId: pageConfig?.fields[ManageableFieldsEnum.CARRIER_ID.name]?.defaultValue,
        };
    }
    return {
        originLocationId: null,
        originLocationIdInfo: null,
        destLocationId: null,
        destLocationIdInfo: null,
        pickUpDT: null,
        requestType: null,
    };
};

export const DATE_TIME_FORMAT = 'dd MMM, yyyy; HH:mm';
export const INPUT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSxxx";
export const EQUIPMENT_LENGTH_DECIMAL_COUNT = 0;
export const featureConfig = {
    enableStaticAndConfigHoc: true,
};

export const BASE_URL = '/api/gateway/v4';

export const MODULE_NAME = 'stride-ui-create-load';

export const EQUIPMENT_TRLR = 'TRLR';

export const EQUIPMENT_DEFAULT = 'P-';

export const LENGTH_FEET = 'FT';

export const CARRIER_WALM = 'WALM';

export const COMMODITY_GM = 'GM';

export const IBOB_OB = 'OB';

export const PROGRAM_TYPE_REV = 'REV';

export const PROTECTION_LEVEL_DRY = 'DRY';

export const NON_DEDICATED_CARRIERS = ['WALM'];
