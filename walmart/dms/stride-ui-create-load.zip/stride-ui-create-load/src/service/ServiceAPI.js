import axios from '../axios';
import { ServiceBase, getTenant } from '@walmart/stride-ui-commons';
import TripSharedService from './SharedService';
import { BASE_URL, defaultTimeout } from '../Constants';

export function ServiceAPI(market, language, userId, userName) {
    const tenantHeaderValue = getTenant(market, {
        hostname: window.location.hostname,
        usUsTenant: true,
    });
    const headers = {
        languageCode: `${language}-${market.toUpperCase()}`,
        locale: `${language}_${market.toUpperCase()}`,
        userId,
        userName,
        'WM_SVC.TENANT_ID': tenantHeaderValue,
        'WM_CONSUMER.TENANT_ID': tenantHeaderValue,
        tenantId: tenantHeaderValue,
    };
    const headersV2 = {
        ...headers,
        source: 'CREATELOAD_UI',
        country: market.toUpperCase(),
    };
    const service = (type) =>
        ServiceBase({
            serviceType: type,
            headers,
            axios,
            opt: {
                timeout: TripSharedService.getConfig()
                    ? TripSharedService.getConfig().payload.custom.timeout
                    : defaultTimeout,
            },
            baseUrl: BASE_URL,
        });
    const serviceV2 = (type) =>
        ServiceBase({
            serviceType: type,
            headers: headersV2,
            axios,
            opt: {
                timeout: TripSharedService.getConfig()
                    ? TripSharedService.getConfig().payload.custom.timeout
                    : defaultTimeout,
            },
            baseUrl: BASE_URL,
        });

    const getStaticData = (data) =>
        service('stride-ui-create-load-staticData').post(
            {
                route: ['staticData'],
            },
            data,
        );
    const createLoad = (data) =>
        service('stride-ui-create-load-createLoad').post(
            {
                route: ['createLoad'],
            },
            data,
        );
    const createLoadV2 = (data) =>
        serviceV2('stride-ui-create-load-createLoad').post(
            {
                route: ['createLoadV2'],
            },
            data,
        );
    const locationTSSSearch = (data) =>
        service('stride-ui-create-load-locationDetails').post(
            {
                route: ['locationTSSSearch'],
            },
            data,
        );

    return {
        getStaticData,
        createLoad,
        createLoadV2,
        locationTSSSearch,
    };
}

export function CommonAPI(market) {
    const configService = ServiceBase({
        serviceType: 'cms',
        axios,
        opt: {
            timeout: TripSharedService.getConfig()
                ? TripSharedService.getConfig().payload.custom.timeout
                : defaultTimeout,
        },
        baseUrl: BASE_URL,
    });

    const getConfig = () =>
        configService.get({
            route: ['getConfig'],
            query: {
                path: '/stride/create-load',
                market,
            },
        });

    return {
        getConfig,
    };
}

export function PageLoadAPI(market, language, userId, userName) {
    const getPageLoadData = (staticDataRequest) =>
        Promise.all([
            CommonAPI(market).getConfig(),
            ServiceAPI(market, language, userId, userName).getStaticData(staticDataRequest),
        ]);
    return {
        getPageLoadData,
    };
}

export const getAutoEntityAPIParams = (currentMarket, lang, userInfo) => ({
    axios,
    language: lang,
    timeout: defaultTimeout,
    userId: userInfo.loggedInUserName,
    userName: '',
    // Todo
    currentMarket,
    usUsTenantFlag: true,
    baseUrl: BASE_URL,
});
