import { getBulkUploadEnvironment } from '@walmart/stride-ui-commons';
class SharedService {
    CMSData;
    currentLanguage;
    userPermissions;
    staticData;
    permissions;
    environment;
    featureFlags;
    trans;
    setConfig = (data) => {
        this.CMSData = data;
    };
    getConfig = () => this.CMSData;
    setCurrentLanguage = (lang) => {
        this.currentLanguage = lang;
    };
    getCurrentLanguage = () => this.currentLanguage;
    setStaticData = (data, language) => {
        this.setCurrentLanguage(language);
        this.staticData = data;
    };
    getStaticData = () => this.staticData;
    getEnvironment = () => this.environment;
    setEnvironment = (options) => {
        this.environment = getBulkUploadEnvironment(options);
    };
    setFeatureFlags = (flags) => {
        this.featureFlags = flags;
    };
    getFeatureFlags = () => this.featureFlags;
    setUserPermissions = (data) => {
        this.userPermissions = data;
    };
    getUserPermissions = () => this.userPermissions;
    setTrans = (trans) => {
        this.trans = trans;
    };
}
export default new SharedService();
