import { getCarrier, getSchedule } from '../CreateLoadServiceParams';
import SharedService from '../SharedService';
import { transformedScheduleReqPayload1, transformedScheduleReqPayload2 } from './mocks/Mapper.mock';

const formData1 = {
    stops: [
        {
            locationIdInfo: {
                timeZoneInfo: {
                    olsenTimezoneId: 'America/Winnipeg',
                    timeZoneCode: 'CDT',
                },
            },
            stopSequenceUiId: 1,
            pickUpDT: '2024-12-14T06:00:00.000Z',
        },
        {
            locationIdInfo: {
                timeZoneInfo: {
                    olsenTimezoneId: 'America/Chicago',
                    timeZoneCode: 'CT',
                },
            },
            pickUpDT: null,
            finalDeliveryDT: null,
            stopSequenceUiId: 2,
        },
    ],
};

const formData2 = {
    stops: [
        {
            locationIdInfo: {
                timeZoneInfo: {
                    olsenTimezoneId: 'America/Winnipeg',
                    timeZoneCode: 'CDT',
                },
            },
            stopSequenceUiId: 1,
            pickUpDT: null,
        },
        {
            locationIdInfo: {
                timeZoneInfo: {
                    olsenTimezoneId: 'America/Chicago',
                    timeZoneCode: 'CT',
                },
            },
            pickUpDT: null,
            stopSequenceUiId: 2,
            finalDeliveryDT: '2024-12-14T06:00:00.000Z',
        },
    ],
};

describe('should return getSchedule expected data', () => {
    it('should return pickup dates if feature flag disabled ', () => {
        SharedService.setFeatureFlags({ showFinalDeliveryDate: false });
        expect(getSchedule(formData1)).toEqual(transformedScheduleReqPayload1);
    });

    it('should return pickup dates if origin pickUpDT available ', () => {
        SharedService.setFeatureFlags({ showFinalDeliveryDate: true });
        expect(getSchedule(formData1)).toEqual(transformedScheduleReqPayload1);
    });

    it('should return due dates if origin finalDeliveryDT available and feature flag enabled', () => {
        SharedService.setFeatureFlags({ showFinalDeliveryDate: true });
        expect(getSchedule(formData2)).toEqual(transformedScheduleReqPayload2);
    });
});

describe('should return getCarrier expected data', () => {
    it('should return expected carrier as WALM ', () => {
        expect(
            getCarrier({
                carrierId: {
                    id: 'WALM',
                    value: 'WALM - WALM LOGISTICS LLC',
                },
            }),
        ).toEqual({ scac: 'WALM', carrierId: 'WALM' });
    });

    it('should return expected carrier as BBK', () => {
        expect(
            getCarrier({
                carrierId: {
                    id: 'BBK',
                    value: 'BBK - WALM LOGISTICS LLC',
                },
            }),
        ).toEqual({ scac: 'BBK', carrierId: 'BBK' });
    });
});
