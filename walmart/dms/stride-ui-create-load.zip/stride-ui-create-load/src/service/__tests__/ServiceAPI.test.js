import { ServiceBase, getTenant } from '@walmart/stride-ui-commons';
import axios from '../../axios';
import { CommonAPI, ServiceAPI } from '../ServiceAPI';
import SharedService from '../SharedService';

jest.mock('@walmart/stride-ui-commons', () => ({
    ...jest.requireActual('@walmart/stride-ui-commons'),
    ServiceBase: jest.fn(),
}));
const postMockFunction = jest.fn().mockReturnValue(() => {});
const getMockFunction = jest.fn().mockReturnValue(() => {});

const tenantHeaderValue = getTenant('ca', {
    hostname: 'dev.stride.walmartlabs.com',
    usUsTenant: true,
});

const headers = {
    languageCode: 'en-CA',
    locale: 'en_CA',
    userId: 'userId',
    userName: 'userName',
    'WM_SVC.TENANT_ID': tenantHeaderValue,
    'WM_CONSUMER.TENANT_ID': tenantHeaderValue,
    tenantId: tenantHeaderValue,
};

describe('ServiceAPI tests', () => {
    beforeAll(() => {
        ServiceBase.mockReturnValue({ post: postMockFunction });
    });
    it('should not return null', () => {
        expect(ServiceAPI('ca', 'en', 'userId', 'userName')).not.toBeNull();
    });
    it('should call ServiceBase with appropriate headers', () => {
        SharedService.setConfig({ payload: { custom: { timeout: 1000 } } });
        ServiceAPI('ca', 'en', 'userId', 'userName').getStaticData({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers,
            opt: {
                timeout: 1000,
            },
            serviceType: 'stride-ui-create-load-staticData',
            baseUrl: '/api/gateway/v4',
        });
    });
    it('should set timeout to default value when not present', () => {
        SharedService.setConfig(undefined);
        ServiceAPI('ca', 'en', 'userId', 'userName').createLoad({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            headers,
            opt: {
                timeout: 30000,
            },
            serviceType: 'stride-ui-create-load-createLoad',
            baseUrl: '/api/gateway/v4',
        });
    });
    it('should call post method of service base', () => {
        const result = ServiceAPI('ca', 'en', 'userId', 'userName');
        result.locationTSSSearch({});
        expect(ServiceBase).toHaveBeenCalled();
        expect(postMockFunction).toHaveBeenCalled();
        expect(postMockFunction).toHaveBeenCalledWith({ route: ['locationTSSSearch'] }, {});
    });
});

describe('CommonAPI tests', () => {
    it('should not return null', () => {
        expect(CommonAPI('ca')).not.toBeNull();
    });
    it('should call ServiceBase with appropriate headers', () => {
        SharedService.setConfig({ payload: { custom: { timeout: 1000 } } });

        CommonAPI('ca');
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            opt: {
                timeout: 1000,
            },
            serviceType: 'cms',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should set timeout to default value when not present', () => {
        SharedService.setConfig(undefined);
        CommonAPI('ca');
        expect(ServiceBase).toHaveBeenCalled();
        expect(ServiceBase).toHaveBeenCalledWith({
            axios,
            opt: {
                timeout: 30000,
            },
            serviceType: 'cms',
            baseUrl: '/api/gateway/v4',
        });
    });

    it('should call get method of service base', () => {
        ServiceBase.mockReturnValue({ get: getMockFunction });

        const result = CommonAPI('ca');
        expect(ServiceBase).toHaveBeenCalled();
        result.getConfig();
        expect(getMockFunction).toHaveBeenCalled();
        expect(getMockFunction).toHaveBeenCalledWith({
            route: ['getConfig'],
            query: { path: '/stride/create-load', market: 'ca' },
        });
    });
});
