export const staticDataMock = {
    mdm: {
        time_zones_juris: [
            {
                id: 290,
                code: 'CDT',
                abbr: 'CT',
                desc: 'Central Standard Time D/L YES',
                olsen_timezone_id: 'America/Winnipeg',
                daylight_offset_sec_qty: -18000,
                gmt_offset_sec_qty: -21600,
                daylight_saving_ind: 'Y',
            },
            {
                id: 414,
                code: 'GMT-03',
                abbr: 'GMT-03',
                desc: 'Argentine Time D/L NO',
                olsen_timezone_id: 'America/Argentina/Salta',
                daylight_offset_sec_qty: -10800,
                gmt_offset_sec_qty: -10800,
                daylight_saving_ind: 'N',
            },
        ],
        equipment_lengths: [
            {
                id: 34,
                code: '13.7',
                length: 13.7,
                uom: {
                    id: 8,
                    code: 'M',
                    abbr: 'M',
                    desc: 'Meter',
                },
            },
            {
                id: 30,
                code: '60.0',
                length: 60,
                uom: {
                    id: 4,
                    code: 'FT',
                    abbr: 'FT',
                    desc: 'Foot',
                },
            },
            {
                id: 21,
                code: '53.0',
                length: 53,
                uom: {
                    id: 4,
                    code: 'FT',
                    abbr: 'FT',
                    desc: 'Foot',
                },
            },
        ],
        master_equipment_types: [
            {
                id: 9,
                code: 'FL',
                abbr: 'FL',
                desc: 'Flatbed',
            },
            {
                id: 12,
                code: 'ST',
                abbr: 'ST',
                desc: 'Straight Truck',
            },
            {
                id: 23,
                code: 'DRYV',
                abbr: 'DRYV',
                desc: 'DRYV',
            },
        ],
        modes: [
            {
                id: 1,
                code: 'TL',
                abbr: 'TL',
                desc: 'Full Truck Load',
            },
            {
                id: 8,
                code: 'IM',
                abbr: 'IM',
                desc: 'Intermodal',
            },
            {
                id: 2,
                code: 'LTL',
                abbr: 'LTL',
                desc: 'Less Than Truck Load',
            },
        ],
        service_levels: [
            {
                id: 232,
                code: 'OCEAN',
                abbr: 'OCEAN',
                desc: 'OCEAN',
            },
            {
                id: 224,
                code: 'EMPTY',
                abbr: 'EMPTY',
                desc: 'EMPTY',
            },
            {
                id: 1,
                code: 'SINGLE',
                abbr: 'SINGLE',
                desc: 'SINGLE',
            },
            {
                id: 2,
                code: 'TEAM',
                abbr: 'TEAM',
                desc: 'TEAM',
            },
        ],
    },
    ltm: {
        planCategory: [
            {
                id: 1,
                code: 'STR',
                abbr: 'STR',
                description: 'DC Loading to Warehouse - Single Trailer',
            },
            {
                id: 2,
                code: 'PLT',
                abbr: 'PLT',
                description: 'Trailer w/ Pallets only',
            },
            {
                id: 3,
                code: 'CLM',
                abbr: 'CLM',
                description: 'Trailer w/ Claim only',
            },
            {
                id: 4,
                code: 'IMP_DRAY',
                abbr: 'IMP_DRAY',
                description: 'Imports - Dray',
            },
            {
                id: 5,
                code: 'IMP_OCEAN',
                abbr: 'IMP_OCEAN',
                description: 'Imports - Ocean',
            },
            {
                id: 6,
                code: 'IMP_MTDRAY',
                abbr: 'IMP_MTDRAY',
                description: 'Imports - MTDray',
            },
            {
                id: 7,
                code: 'IM',
                abbr: 'IM',
                description: 'Intermodal - WAMU',
            },
            {
                id: 8,
                code: 'IM_RAIL',
                abbr: 'IM_RAIL',
                description: 'Intermodal - Rail',
            },
            {
                id: 9,
                code: 'IM_DRAY',
                abbr: 'IM_DRAY',
                description: 'Intermodal - Dray',
            },
            {
                id: 10,
                code: 'OICC',
                abbr: 'OICC',
                description: 'WFS ICC',
            },
            {
                id: 11,
                code: 'PPD_BKHL',
                abbr: 'PPD_BKHL',
                description: 'Prepaid Backhaul',
            },
        ],
    },
};

export const transformedConfigResponseMock = {
    timeout: 5000,
    debounceTime: 500,
    country: {
        currency: ['USD'],
        id: '44',
        iso2: 'CA',
        iso3: 'CA',
        name: 'Canada',
    },
    openLoadDelayTimeInMillisecs: 2000,
    autoCompleteMaxCount: 200,
    autoCompleteMinSearchLength: 1,
    featureFlags: { 'dev.createLoad.configs': { enableShortTimezone: true } },
    UOM: {
        length: 'FT',
    },
    toastTimeout: 30000,
};

export const transformedScheduleReqPayload1 = {
    minPickupTs: '2024-12-14T00:00:00.000-06:00',
    maxPickupTs: '2024-12-14T00:00:00.000-06:00',
};

export const transformedScheduleReqPayload2 = {
    minDueTs: '2024-12-14T00:00:00.000-06:00',
    maxDueTs: '2024-12-14T00:00:00.000-06:00',
};
