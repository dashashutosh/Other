import { getUniqueValuesSorted } from '@walmart/stride-ui-commons';
import { validateCmsConfigData, transformStaticData, transformCmsData } from '../Mapper';
import configResponseMock from './mocks/CmsConfig.json';
import { staticDataMock, transformedConfigResponseMock } from './mocks/Mapper.mock';

describe('validate cms config data', () => {
    it('should return true when data is valid', () => {
        expect(validateCmsConfigData(configResponseMock)).toEqual(true);
    });

    it('should return false when data is invalid', () => {
        expect(validateCmsConfigData(undefined)).toEqual(false);
        expect(validateCmsConfigData(null)).toEqual(false);
        expect(
            validateCmsConfigData({
                payload: null,
            }),
        ).toEqual(false);
        expect(
            validateCmsConfigData({
                payload: {
                    custom: {
                        autoCompleteMaxCount: '100',
                    },
                },
            }),
        ).toEqual(false);
        expect(
            validateCmsConfigData({
                payload: {
                    custom: {
                        debounceTime: 15,
                    },
                },
            }),
        ).toEqual(false);
    });
});

describe('Mapper - transformStaticData', () => {
    it('transformStaticData should return transformed data', () => {
        const mdmStaticData = staticDataMock?.mdm;
        const omStaticData = staticDataMock?.ltm;

        const abbrData = (data) =>
            data?.map((item) => {
                // eslint-disable-next-line prefer-template
                const reqType = item?.code + ' - ' + item?.description;
                return { id: item?.code, value: reqType, abbr: item?.abbr };
            });
        const timeZoneJurisData = (data) =>
            data?.map((item) => ({
                id: item.code,
                olsenTimzoneId: item.olsen_timezone_id,
                abbrevation: item.abbr,
            }));
        const equipmentTypesData = (data) =>
            data?.map((eqpType) => ({
                id: eqpType.code,
                value: eqpType.abbr,
            }));
        const equipmentLengthsData = (data) =>
            data?.map((eqpLen) => ({
                id: eqpLen.length,
                value: eqpLen.length,
                uom: eqpLen.uom?.code,
            }));
        const serviceLevelData = (data) =>
            data?.map((type) => ({
                id: type.code,
                value: type.desc,
            }));
        const serviceModedata = (data) =>
            data?.map((type) => {
                // eslint-disable-next-line prefer-template
                const value = type?.code + ' (' + type?.desc + ')';
                return {
                    id: type.code,
                    value,
                };
            });
        expect(transformStaticData(staticDataMock).requestTypes).toStrictEqual(
            getUniqueValuesSorted(abbrData(omStaticData?.planCategory)),
        );

        expect(transformStaticData(staticDataMock).timezoneJuris).toStrictEqual(
            getUniqueValuesSorted(timeZoneJurisData(mdmStaticData?.time_zones_juris)),
        );
        expect(transformStaticData(staticDataMock).equipmentTypes).toStrictEqual(
            getUniqueValuesSorted(equipmentTypesData(mdmStaticData?.master_equipment_types)),
        );
        expect(transformStaticData(staticDataMock).equipmentLengths).toStrictEqual(
            getUniqueValuesSorted(equipmentLengthsData(mdmStaticData?.equipment_lengths)),
        );
        expect(transformStaticData(staticDataMock).serviceLevelList).toStrictEqual(
            getUniqueValuesSorted(serviceLevelData(mdmStaticData?.service_levels)),
        );
        expect(transformStaticData(staticDataMock).serviceModeList).toStrictEqual(
            getUniqueValuesSorted(serviceModedata(mdmStaticData?.modes)),
        );
    });
});

describe('transform cms config data checks', () => {
    it('should transform cms config data', () => {
        expect(transformCmsData(configResponseMock)).toEqual(transformedConfigResponseMock);
    });

    it('should return failure when input data is invalid', () => {
        try {
            transformCmsData(undefined);
        } catch (e) {
            expect(e).toEqual(new Error('Invalid CMS config data'));
        }
    });
});
