import {
    isNullOrUndefined,
    MarketCodeEnum,
    convertToISOStringWithOffset,
    StopActivityTypeEnum,
    UILoadTypeEnum,
} from '@walmart/stride-ui-commons';
import { v4 as uuidv4 } from 'uuid';
import {
    COMMODITY_GM,
    EQUIPMENT_DEFAULT,
    EQUIPMENT_TRLR,
    IBOB_OB,
    LENGTH_FEET,
    PROGRAM_TYPE_REV,
    PROTECTION_LEVEL_DRY,
} from '../Constants';
import SharedService from './SharedService';

function getOrigin(formData) {
    const origin = formData?.stops?.find((stop) => stop?.stopSequenceUiId === 1);
    if (isNullOrUndefined(origin)) return {};
    return {
        locationId: origin?.locationId?.id,
        locationType: origin?.locationId?.locationType,
        // when cross-country loads/trips are present, need to revisit this code
        countryCode: MarketCodeEnum.US.name,
    };
}

function getDestination(formData) {
    const sortedStopsDesc = formData?.stops?.sort((a, b) => b.stopSequenceUiId - a.stopSequenceUiId);
    const destination = sortedStopsDesc?.[0];
    if (isNullOrUndefined(destination)) return {};
    return {
        locationId: destination?.locationId?.id,
        locationType: destination?.locationId?.locationType,
        // when cross-country loads/trips are present, need to revisit this code
        countryCode: MarketCodeEnum.US.name,
    };
}

function getIdentifiers() {
    return {
        clientReferenceId: uuidv4(),
    };
}

export function getSchedule(formData) {
    const featureFlags = SharedService.getFeatureFlags();
    const origin = formData?.stops?.find((stop) => stop?.stopSequenceUiId === 1);
    const destination = formData?.stops?.find((stop) => stop?.stopSequenceUiId === formData?.stops?.length);
    if (isNullOrUndefined(origin)) return {};
    if (featureFlags?.showFinalDeliveryDate) {
        if (origin?.pickUpDT) {
            return {
                minPickupTs: convertToISOStringWithOffset(
                    origin?.pickUpDT,
                    origin?.locationIdInfo?.timeZoneInfo?.olsenTimezoneId,
                ),
                maxPickupTs: convertToISOStringWithOffset(
                    origin?.pickUpDT,
                    origin?.locationIdInfo?.timeZoneInfo?.olsenTimezoneId,
                ),
            };
        } else if (destination?.finalDeliveryDT) {
            return {
                minDueTs: convertToISOStringWithOffset(
                    destination?.finalDeliveryDT,
                    destination?.locationIdInfo?.timeZoneInfo?.olsenTimezoneId,
                ),
                maxDueTs: convertToISOStringWithOffset(
                    destination?.finalDeliveryDT,
                    destination?.locationIdInfo?.timeZoneInfo?.olsenTimezoneId,
                ),
            };
        }
    }
    return {
        minPickupTs: convertToISOStringWithOffset(
            origin?.pickUpDT,
            origin?.locationIdInfo?.timeZoneInfo?.olsenTimezoneId,
        ),
        maxPickupTs: convertToISOStringWithOffset(
            origin?.pickUpDT,
            origin?.locationIdInfo?.timeZoneInfo?.olsenTimezoneId,
        ),
    };
}
const defaultEquipmentId = (formData) => {
    let equipmentId = EQUIPMENT_DEFAULT;
    if (formData?.equipment?.equipmentId) {
        equipmentId = formData.equipment.equipmentId;
    } else if (formData?.requestType === UILoadTypeEnum.BOB.name) {
        equipmentId = null;
    }
    return equipmentId;
};

export function getEquipment(formData, uom) {
    const featureFlags = SharedService.getFeatureFlags();
    return {
        equipmentId: featureFlags?.enableDefaultEquipmentId
            ? defaultEquipmentId(formData)
            : formData?.equipment?.equipmentId,
        equipmentCode: EQUIPMENT_TRLR,
        equipmentType: formData?.equipment?.equipmentType,
        length: {
            unitOfMeasure: uom?.length || LENGTH_FEET,
            measurementValue: formData?.equipment?.equipmentLength,
        },
    };
}

export function getCarrier(formData) {
    return {
        carrierId: formData?.carrierId?.id,
        scac: formData?.carrierId?.id,
    };
}

function getPlanDetails() {
    return {
        commodity: COMMODITY_GM,
        // need to change in future when inbound is introduced
        ibob: IBOB_OB,
        programType: PROGRAM_TYPE_REV,
    };
}

function getStopType(stop) {
    // OB loads have origin as pickup and remaining locations as drop
    if (stop?.stopSequenceUiId === 1) return '3';
    return '7';
}

function getUnitDetails(formData) {
    return {
        mode: formData?.transitDetail?.mode,
        serviceLevel: formData?.transitDetail?.serviceLevel,
        // Add this to constants file
        protectionLevel: PROTECTION_LEVEL_DRY,
        // Add this to constants file
        commodity: COMMODITY_GM,
        // All measurements should be 1,
        totalCases: {
            unitOfMeasure: 'EA',
            measurementValue: 1,
        },
        totalWeight: {
            unitOfMeasure: 'LBS',
            measurementValue: 1,
        },
        totalCube: {
            unitOfMeasure: 'CFT',
            measurementValue: 1,
        },
        totalPallets: {
            unitOfMeasure: 'EA',
            measurementValue: 1,
        },
    };
}

function getAllUnits(formData) {
    const origin = formData?.stops?.find((stop) => stop?.stopSequenceUiId === 1);
    if (isNullOrUndefined(origin)) return {};
    const sortedStopsAsc = formData?.stops?.sort((a, b) => a.stopSequenceUiId < b.stopSequenceUiId);
    if (isNullOrUndefined(sortedStopsAsc) || sortedStopsAsc?.length <= 1) return {};
    const nextStops = sortedStopsAsc.slice(1);
    const units = [];
    nextStops?.forEach((stop) => {
        units.push({
            locations: {
                origin: getOrigin(formData),
                destination: {
                    locationId: stop?.locationId?.id,
                    locationType: stop?.locationId?.locationType,
                    countryCode: MarketCodeEnum.US.name,
                },
            },
            schedule: getSchedule(formData),
            unitDetails: getUnitDetails(formData, stop),
        });
    });
    return units;
}

function getUnitForThisStop(formData, stop) {
    const origin = formData?.stops?.find((s) => s?.stopSequenceUiId === 1);
    if (isNullOrUndefined(origin)) return {};
    const units = [];
    units.push({
        locations: {
            origin: getOrigin(formData),
            destination: {
                locationId: stop?.locationId?.id,
                locationType: stop?.locationId?.locationType,
                countryCode: MarketCodeEnum.US.name,
            },
        },
        schedule: getSchedule(formData),
        unitDetails: getUnitDetails(formData, stop),
    });
    return units;
}

function getUnits(formData, stop) {
    // OB origin is connected to all units, subsequent locations have one unit each.
    if (stop?.stopSequenceUiId === 1) return getAllUnits(formData);
    return getUnitForThisStop(formData, stop);
}

function getStopActivityType(stop) {
    // For “Auto” stopActivityType, UI needs to send null for stopActivityType
    // as backend is going to derive this flag based on MDM flag.
    if (stop?.activityType === StopActivityTypeEnum.AUTO.code) {
        return null;
    }
    return stop?.activityType;
}

function getStops(formData) {
    const stops = [];
    const sortedStops = formData?.stops?.sort((a, b) => a.stopSequenceUiId - b.stopSequenceUiId);
    sortedStops.forEach((stop) => {
        stops.push({
            stopSequenceNumber: stop?.stopSequenceUiId,
            stopType: getStopType(stop),
            stopActivityType: getStopActivityType(stop),
            location: {
                locationId: stop?.locationId?.id,
                locationType: stop?.locationId?.locationType,
                // Cross-country loads would be future use-case
                countryCode: MarketCodeEnum.US.name,
            },
            units: getUnits(formData, stop),
        });
    });
    return stops;
}

function getComments(formData) {
    const comments = [];
    const sortedComments = formData?.comments?.sort((a, b) => a.commentId < b.commentId);
    sortedComments.forEach((comment) => {
        comments.push({
            commentId: comment?.commentId,
            commentBy: comment?.commentBy,
            commentText: comment?.commentText,
            commentType: comment?.commentType,
            isNew: true,
        });
    });
    return comments?.length ? comments : null;
}

export const transformFormDataToAPIRequest = (formData, uom) => {
    return {
        origin: getOrigin(formData),
        destination: getDestination(formData),
        identifiers: getIdentifiers(),
        schedule: getSchedule(formData),
        plans: [
            {
                planCategory: formData.requestType,
                equipment: getEquipment(formData, uom),
                origin: getOrigin(formData),
                destination: getDestination(formData),
                schedule: getSchedule(formData),
                carrier: getCarrier(formData),
                planDetails: getPlanDetails(),
                stops: getStops(formData),
                comments: getComments(formData),
            },
        ],
    };
};
