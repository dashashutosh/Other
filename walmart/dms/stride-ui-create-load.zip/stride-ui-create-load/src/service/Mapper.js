import { isNullOrUndefined, getUniqueValuesSorted } from '@walmart/stride-ui-commons';
import { featureConfig } from '../Constants';

export function transformStaticData(serviceResponse) {
    const { enableStaticAndConfigHoc } = featureConfig;

    const omStaticData = enableStaticAndConfigHoc
        ? serviceResponse.ltm
        : serviceResponse?.payload?.om_static_data?.payload?.staticData;
    const mdmStaticData = enableStaticAndConfigHoc
        ? serviceResponse.mdm
        : serviceResponse.payload?.mdm_static_data?.static_data;

    return {
        requestTypes: getUniqueValuesSorted(
            omStaticData?.planCategory?.map((requestType) => {
                const reqType = requestType?.code + ' - ' + requestType?.description;
                return {
                    id: requestType?.code,
                    value: reqType,
                    abbr: requestType?.abbr,
                };
            }) || [],
        ),
        timezoneJuris: getUniqueValuesSorted(
            mdmStaticData?.time_zones_juris?.map((tmData) => ({
                id: tmData?.code,
                olsenTimzoneId: tmData?.olsen_timezone_id,
                abbrevation: tmData?.abbr,
            })) || [],
        ),
        equipmentTypes: getUniqueValuesSorted(
            mdmStaticData?.master_equipment_types?.map((eqpType) => ({
                id: eqpType?.code,
                value: eqpType?.abbr,
            })),
        ),
        equipmentLengths: getUniqueValuesSorted(
            mdmStaticData?.equipment_lengths?.map((eqpLen) => ({
                id: eqpLen?.length,
                value: eqpLen?.length,
                uom: eqpLen.uom?.code,
            })),
        ),
        serviceLevelList: getUniqueValuesSorted(
            mdmStaticData?.service_levels?.map((type) => ({
                id: type?.code,
                value: type?.desc,
            })),
        ),
        serviceModeList: getUniqueValuesSorted(
            mdmStaticData?.modes?.map((type) => {
                // eslint-disable-next-line prefer-template
                const value = type?.code + ' (' + type?.desc + ')';
                return {
                    id: type?.code,
                    value,
                };
            }),
        ),
    };
}
function isJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}
export function validateCmsConfigData(cmsConfigData) {
    if (!cmsConfigData || !cmsConfigData.payload || !cmsConfigData.payload.custom) return false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.timeout) ||
        typeof cmsConfigData?.payload?.custom?.timeout !== 'string'
    )
        return false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.debounceTime) ||
        typeof cmsConfigData?.payload?.custom?.debounceTime !== 'string'
    )
        return false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.country) ||
        typeof cmsConfigData?.payload?.custom?.country !== 'string' ||
        !isJsonString(cmsConfigData?.payload?.custom?.country)
    )
        return false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.openLoadDelayTimeInMillisecs) ||
        typeof cmsConfigData?.payload?.custom?.openLoadDelayTimeInMillisecs !== 'string'
    )
        return false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.autoCompleteMaxCount) ||
        typeof cmsConfigData?.payload?.custom?.autoCompleteMaxCount !== 'string'
    )
        return false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.autoCompleteMinSearchLength) ||
        typeof cmsConfigData?.payload?.custom?.autoCompleteMinSearchLength !== 'string'
    )
        return false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.UOM) ||
        typeof cmsConfigData?.payload?.custom?.UOM !== 'string'
    )
        return false;

    return true;
}
export function transformCmsData(cmsConfigData) {
    if (!validateCmsConfigData(cmsConfigData)) throw new Error('Invalid CMS config data');
    return {
        timeout: parseInt(cmsConfigData?.payload?.custom?.timeout, 10),
        debounceTime: parseInt(cmsConfigData?.payload?.custom?.debounceTime, 10),
        country: JSON.parse(cmsConfigData?.payload?.custom?.country),
        openLoadDelayTimeInMillisecs: parseInt(cmsConfigData?.payload?.custom?.openLoadDelayTimeInMillisecs, 10),
        autoCompleteMaxCount: parseInt(cmsConfigData?.payload?.custom?.autoCompleteMaxCount, 10) || 100,
        autoCompleteMinSearchLength: parseInt(cmsConfigData?.payload?.custom?.autoCompleteMinSearchLength, 10) || 1,
        featureFlags: JSON.parse(cmsConfigData?.payload?.custom?.featureFlags),
        UOM: cmsConfigData?.payload?.custom?.UOM ? JSON.parse(cmsConfigData?.payload?.custom?.UOM) : {},
        toastTimeout: parseInt(cmsConfigData?.payload?.custom?.toastTimeout, 10) || 30000,
    };
}
export function transformHOCStaticData(pStaticData) {
    const omStaticData = pStaticData;
    return {
        requestTypes: getUniqueValuesSorted(
            omStaticData?.[0]?.planCategory?.map((requestType) => {
                // eslint-disable-next-line prefer-template
                const reqType = requestType?.code + ' - ' + requestType?.description;
                return { id: requestType?.code, value: reqType };
            }),
        ),
        timezoneJuris: getUniqueValuesSorted(
            (pStaticData?.[1]?.time_zones_juris?.data || []).map((tmData) => ({
                id: tmData?.code,
                olsenTimzoneId: tmData?.olsen_timezone_id,
                abbrevation: tmData?.abbr,
            })),
        ),
    };
}
export function validateCCMConfigData(ccmConfigData) {
    if (!ccmConfigData) return false;

    if (isNullOrUndefined(ccmConfigData?.timeout) || typeof ccmConfigData?.timeout !== 'string') return false;

    if (isNullOrUndefined(ccmConfigData?.debounceTime) || typeof ccmConfigData?.debounceTime !== 'string') return false;

    if (isNullOrUndefined(ccmConfigData?.country) || typeof ccmConfigData?.country !== 'object') return false;

    if (
        isNullOrUndefined(ccmConfigData?.openLoadDelayTimeInMillisecs) ||
        typeof ccmConfigData?.openLoadDelayTimeInMillisecs !== 'string'
    )
        return false;

    if (
        isNullOrUndefined(ccmConfigData?.autoCompleteMaxCount) ||
        typeof ccmConfigData?.autoCompleteMaxCount !== 'string'
    )
        return false;

    if (
        isNullOrUndefined(ccmConfigData?.autoCompleteMinSearchLength) ||
        typeof ccmConfigData?.autoCompleteMinSearchLength !== 'string'
    )
        return false;

    return true;
}
export function transformCCMData(ccmConfigData) {
    if (!ccmConfigData) throw new Error('Invalid CMS config data');

    return {
        timeout: ccmConfigData?.timeout,
        debounceTime: ccmConfigData?.debounceTime,
        country: ccmConfigData?.country,
        openLoadDelayTimeInMillisecs: ccmConfigData?.openLoadDelayTimeInMillisecs,
        autoCompleteMaxCount: ccmConfigData?.autoCompleteMaxCount || 100,
        autoCompleteMinSearchLength: ccmConfigData?.autoCompleteMinSearchLength || 1,
    };
}
export function validateCMSConfigData(cmsConfigData) {
    let isValid = true;
    if (!cmsConfigData || !cmsConfigData?.payload || !cmsConfigData?.payload?.custom) {
        isValid = false;
    }
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.timeout) ||
        typeof cmsConfigData?.payload?.custom?.timeout !== 'string'
    )
        isValid = false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.debounceTime) ||
        typeof cmsConfigData?.payload?.custom?.debounceTime !== 'string'
    )
        isValid = false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.country) ||
        typeof cmsConfigData?.payload?.custom?.country !== 'string' ||
        !isJsonString(cmsConfigData?.payload?.custom?.country)
    )
        isValid = false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.openLoadDelayTimeInMillisecs) ||
        typeof cmsConfigData?.payload?.custom?.openLoadDelayTimeInMillisecs !== 'string'
    )
        isValid = false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.autoCompleteMaxCount) ||
        typeof cmsConfigData?.payload?.custom?.autoCompleteMaxCount !== 'string'
    )
        isValid = false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.autoCompleteMinSearchLength) ||
        typeof cmsConfigData?.payload?.custom?.autoCompleteMinSearchLength !== 'string'
    )
        isValid = false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.featureFlags) ||
        typeof cmsConfigData?.payload?.custom?.featureFlags !== 'string'
    )
        isValid = false;
    if (
        isNullOrUndefined(cmsConfigData?.payload?.custom?.featureFlags) ||
        typeof cmsConfigData?.payload?.custom?.UOM !== 'string'
    )
        isValid = false;
    return {
        isValid,
        errorMessage: 'Invalid CMS config data',
    };
}
